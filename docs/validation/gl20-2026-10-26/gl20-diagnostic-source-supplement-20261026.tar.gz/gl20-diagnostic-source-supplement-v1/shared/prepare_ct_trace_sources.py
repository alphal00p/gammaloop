"""Prepare isolated instrumentation-only owner crate copies; no compilation/run."""
import difflib
import hashlib
import json
from pathlib import Path
import shutil

HERE = Path(__file__).resolve().parent
OUT = HERE / "ct-real-point-diagnostic"
OWNERS = {
    "current": Path("/shared/codex-1/vakint_rustred/workspace/5l-push/vakint-gl20-current-runtime-save-oracle"),
    "historical": Path("/shared/codex-1/vakint_rustred/workspace/5l-push/vakint-gl20-historical-21cefae-capture"),
}
METHOD = r'''
    // Private diagnostic only: observe the existing eager dispatch without changing inputs.
    fn trace_gl20_retained_eager_call(
        &self,
        dispatch: &str,
        params: &[Complex<F<f64>>],
        out: &[Complex<F<f64>>],
    ) {
        use std::sync::{Mutex, OnceLock, atomic::{AtomicU64, Ordering}};
        static NEXT_CALL: AtomicU64 = AtomicU64::new(0);
        static SEEN: OnceLock<Mutex<std::collections::BTreeSet<usize>>> = OnceLock::new();
        let call_id = NEXT_CALL.fetch_add(1, Ordering::Relaxed);
        let evaluator_id = self as *const Self as usize;
        let first_use = SEEN.get_or_init(|| Mutex::new(std::collections::BTreeSet::new()))
            .lock().unwrap().insert(evaluator_id);
        let params_bits = params.iter().map(|z| [z.re.0.to_bits(), z.im.0.to_bits()]).collect::<Vec<_>>();
        let output_bits = out.iter().map(|z| [z.re.0.to_bits(), z.im.0.to_bits()]).collect::<Vec<_>>();
        let params_decimal = params.iter().map(|z| [z.re.0, z.im.0]).collect::<Vec<_>>();
        let output_decimal = out.iter().map(|z| [z.re.0, z.im.0]).collect::<Vec<_>>();
        let function_map = first_use.then(|| self.fn_map_entries.iter().map(|entry| {
            serde_json::json!({"lhs":entry.lhs.to_canonical_string(), "rhs":entry.rhs.to_canonical_string(),
                "args_debug":format!("{:?}",entry.args),
                "tags":entry.tags.iter().map(AtomCore::to_canonical_string).collect::<Vec<_>>()})
        }).collect::<Vec<_>>());
        let eager_debug = first_use.then(|| format!("{:?}", self.f64_eager));
        crate::debug_tags!(#integration, #inspect, #gl20_retained_probe;
            stage = "gl20_retained_f64_dispatch",
            call_id = call_id, evaluator_id = evaluator_id as u64,
            dispatch = dispatch, first_use = first_use,
            backend = ?self.active_f64_backend(),
            file.params_bits = ?params_bits, file.output_bits = ?output_bits,
            file.params_decimal = ?params_decimal, file.output_decimal = ?output_decimal,
            file.function_map = %serde_json::to_string(&function_map).unwrap(),
            file.eager_debug = ?eager_debug,
            "Retained GL20 eager dispatch observed"
        );
    }

'''


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


for owner, root in OWNERS.items():
    target = OUT / owner / "source/gammalooprs"
    shutil.copytree(root / "crates/gammalooprs", target)
    path = target / "src/integrands/process/evaluators.rs"
    original = path.read_text()
    source = original
    at = "    pub(crate) fn new_from_builder<I: IntoIterator<Item = Atom>>("
    assert source.count(at) == 1
    source = source.replace(at, METHOD + at)
    before = "        |params: &[Complex<F<f64>>]| match generic_evaluator.active_f64_backend() {"
    assert source.count(before) == 1
    source = source.replace(before, "        |params: &[Complex<F<f64>>]| {\n            let result = match generic_evaluator.active_f64_backend() {")
    end = "                out[0]\n            }\n        }\n    }\n\n    fn get_evaluator("
    assert source.count(end) == 1
    source = source.replace(end, "                out[0]\n            }\n        };\n            generic_evaluator.trace_gl20_retained_eager_call(\"single\", params, std::slice::from_ref(&result));\n            result\n        }\n    }\n\n    fn get_evaluator(")
    end = "            if let Some(dual_shape) = &generic_evaluator.dual_shape {\n                let dual_builder = HyperDual::<Complex<F<f64>>>::new(dual_shape.clone());"
    assert source.count(end) == 1
    source = source.replace(end, "            generic_evaluator.trace_gl20_retained_eager_call(\"vector\", params, &out);\n\n" + end)
    path.write_text(source)
    patch = OUT / owner / "instrumentation-only.diff"
    patch.write_text("".join(difflib.unified_diff(original.splitlines(True), source.splitlines(True), fromfile=f"{owner}-frozen/evaluators.rs", tofile=f"{owner}-private-trace/evaluators.rs")))
    files = []
    for p in sorted(target.rglob("*")):
        if p.is_file():
            rel = p.relative_to(target)
            expected = root / "crates/gammalooprs" / rel
            changed = sha(p) != sha(expected)
            assert not changed or str(rel) == "src/integrands/process/evaluators.rs"
            files.append({"path": str(rel), "original_sha256": sha(expected), "prepared_sha256": sha(p), "changed": changed})
    receipt = {"owner": owner, "original_source": str(root), "private_crate_source": str(target),
               "changed_paths": [r["path"] for r in files if r["changed"]], "files": files,
               "patch_sha256": sha(patch), "scope": "One private observation method and two concrete f64 dispatch capture calls. Existing branch bodies, params, outputs, return values, numerical settings and algorithms unchanged. Original source/target unmodified; no compilation or evaluation."}
    (OUT / owner / "source-freeze.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps({"owner": owner, "source_freeze_sha256": sha(OUT / owner / "source-freeze.json"), "patch_sha256": sha(patch), "prepared_evaluators_sha256": sha(path), "files": len(files)}))

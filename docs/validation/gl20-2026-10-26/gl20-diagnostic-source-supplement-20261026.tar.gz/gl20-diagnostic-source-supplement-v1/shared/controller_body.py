"""One matching-current direct rustc build and one read-only postprocess export."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import sys
import time
import traceback

os.umask(0o077)
HERE = Path(__file__).resolve().parent
RUN = HERE / "run1"
parser = argparse.ArgumentParser()
parser.add_argument("--manifest-sha256", required=True)
args = parser.parse_args()

# The historical controller's already-reviewed sha/atomic/identity/resources,
# signal_owned_group/reap_and_drain/phase definitions are copied above main by
# prepare_controller.py. Phase changes only add a supplied affinity assertion.


def guard():
    assert sha(HERE / "control-manifest.json") == args.manifest_sha256
    for row in M["controls"]:
        assert sha(row["path"]) == row["sha256"], row["path"]
    frozen = json.loads(Path(M["source_freeze"]).read_text())
    source = Path(frozen["source"])
    for path, checksum in frozen["files"].items():
        assert sha(source / path) == checksum, path
    for row in S["files"]:
        path = Path(row["path"])
        assert path.is_file() and not path.is_symlink()
        assert sha(path) == row["sha256"], str(path)
    assert {str(p.relative_to(S["root"])) for p in Path(S["root"]).rglob("*") if p.is_file()} == {row["relative"] for row in S["files"]}
    for row in D["selected_transitive_closure"]:
        for field in ("rlib", "fingerprint_marker", "fingerprint_json"):
            assert sha(row[field]["path"]) == row[field]["sha256"], row[field]["path"]
    for row in D["native_archives"]:
        assert sha(row["path"]) == row["sha256"], row["path"]
    for field in ("normal_test_fingerprint", "test_ELF", "normal_test_authentication", "linker"):
        assert sha(D[field]["path"]) == D[field]["sha256"], field
    assert sha(D["rustc"]["path"]) == D["rustc"]["sha256"]


def no_target_writers():
    prefix = D["current_target"] + "/"
    for proc in Path("/proc").iterdir():
        if not proc.name.isdigit():
            continue
        try:
            fds = list((proc / "fd").iterdir())
        except (FileNotFoundError, ProcessLookupError, PermissionError):
            continue
        for fd in fds:
            try:
                if not os.readlink(fd).startswith(prefix):
                    continue
                flags = int(next(x.split()[1] for x in (proc / "fdinfo" / fd.name).read_text().splitlines() if x.startswith("flags:")), 8)
                assert flags & os.O_ACCMODE == os.O_RDONLY, "Frozen target has a live writer"
            except (FileNotFoundError, ProcessLookupError, PermissionError):
                pass


def main():
    assert os.environ.get("SYMBOLICA_LICENSE")
    assert os.environ.get("INVOCATION_ID") and M["unit"] in Path("/proc/self/cgroup").read_text()
    assert os.sched_getaffinity(0) == {140, 145, 146}
    setup_start = time.monotonic()
    setup_deadline = setup_start + 1800
    guard()
    no_target_writers()
    saved = json.loads(Path(M["runtime_environment"]).read_text())
    env = os.environ.copy()
    env.update(saved["environment"])
    for key in list(env):
        if key.startswith("INSTA_") or key.startswith("BASH_FUNC_"):
            env.pop(key)
    for key in ("PYTHONHOME", "PYTHONPATH", "PYTHONSTARTUP", "PYTHONINSPECT", "BASH_ENV", "ENV", "PYO3_CONFIG_FILE", "PYO3_NO_PYTHON"):
        env.pop(key, None)
    env.update(NO_SYMBOLICA_OEM_LICENSE="1", SYMBOLICA_HIDE_BANNER="1", RUST_BACKTRACE="1",
               GL_DISPLAY_FILTER="off", GL_LOGFILE_FILTER="off", GL_ALL_LOG_FILTER="off",
               TMPDIR=str(RUN / "tmp"), XDG_CACHE_HOME=str(RUN / "cache"), GL_TEST_LOG_DIR=str(RUN / "logs"))
    for key in M["thread_environment"]:
        env[key] = "1"
    for name in ("tmp", "cache", "logs"):
        (RUN / name).mkdir()
    copied = RUN / "input-copy"
    copied.mkdir()
    for row in S["files"]:
        target = copied / row["relative"]
        target.parent.mkdir(parents=True, exist_ok=True)
        with Path(row["path"]).open("rb") as source, target.open("xb") as dest:
            shutil.copyfileobj(source, dest)
            dest.flush()
            os.fsync(dest.fileno())
        assert target.stat().st_ino != Path(row["path"]).stat().st_ino
        assert sha(target) == row["sha256"]
    version = subprocess.check_output([D["rustc"]["path"], "-Vv"], env=env, text=True, timeout=10)
    assert version.startswith("rustc 1.98.1 "), version
    atomic(RUN / "actual-compiler.json", {"rustc": D["rustc"], "verbose_version": version})
    executable = RUN / "decoder"
    build = [M["taskset"], "-c", "145,146", D["rustc"]["path"],
             "--crate-name", "gl20_current_readonly_decoder", "--edition=2024", "--crate-type=bin",
             "-C", "opt-level=0", "-C", "debuginfo=0", "-C", "linker=" + D["linker"]["path"],
             "-L", "dependency=" + str(Path(D["current_target"]) / "deps")]
    for directory in D["native_link_search_paths"]:
        build.extend(["-L", "native=" + directory])
    for row in D["selected_externs"]:
        build.extend(["--extern", row["crate"] + "=" + row["rlib"]["path"]])
    build.extend([str(HERE / "decoder.rs"), "-o", str(executable)])
    result = {"status": "STARTED_MATCHING_CURRENT_READ_ONLY_DECODER_NOT_PASS",
              "manifest_sha256": args.manifest_sha256, "unit": M["unit"],
              "invocation_id": os.environ["INVOCATION_ID"], "controller_identity": identity(os.getpid()),
              "retries": 0, "phases": [], "scientific_scope": M["scientific_scope"]}
    atomic(RUN / "STARTED.json", result, exclusive=True)
    code = 1
    try:
        result["phases"].append(phase("build", build, env, max(0, setup_deadline - time.monotonic()), D["rustc"]["path"], {145, 146}))
        assert executable.is_file() and not executable.is_symlink()
        atomic(RUN / "built-artifact.json", {"path": str(executable), "sha256": sha(executable),
               "bytes": executable.stat().st_size, "dependency_authentication_sha256": sha(HERE / "dependency-authentication.json"),
               "compiler_record_sha256": sha(RUN / "actual-compiler.json"), "helper_source_sha256": sha(HERE / "decoder.rs")})
        guard()
        assert time.monotonic() <= setup_deadline
        result["setup_seconds"] = time.monotonic() - setup_start
        result["phases"].append(phase("decode", [M["taskset"], "-c", "140", str(executable), str(copied), str(RUN / "export")], env, 600, executable, {140}))
        exported = json.loads((RUN / "export/completion.json").read_text())
        assert exported["status"] == "PASS_MATCHING_CURRENT_READ_ONLY_STATE_EXPORT"
        for key in ("event_evaluations", "generation_calls", "preprocessing_calls", "spin_sum_calls", "channel_construction_calls", "backend_activation_calls"):
            assert exported[key] == 0
        assert exported["owner_state_loads"] == 1 and exported["license_guard_passed"] is True
        for row in S["files"]:
            assert sha(copied / row["relative"]) == row["sha256"]
        no_target_writers()
        guard()
        result.update(status="PASS_MATCHING_CURRENT_READ_ONLY_FULL_STATE_EXPORT_NOT_GOLD_ACCEPTANCE",
                      outputs=[{"path": str(p), "sha256": sha(p), "bytes": p.stat().st_size} for p in sorted((RUN / "export").rglob("*")) if p.is_file()],
                      original_retained_state_unchanged=True, frozen_source_and_selected_dependencies_unchanged=True,
                      actual_compile_invocations=1, actual_decoder_invocations=1)
        code = 0
    except BaseException as error:
        traceback.print_exc()
        result.update(status="FAILED_NO_RETRY", error_type=type(error).__name__, error=str(error))
    finally:
        result.update(returncode=code, finished_utc=now(), resource_end=resources())
        atomic(RUN / "completion.json", result)
    return code


if __name__ == "__main__":
    assert re.fullmatch(r"[0-9a-f]{64}", args.manifest_sha256)
    assert sha(HERE / "control-manifest.json") == args.manifest_sha256
    M = json.loads((HERE / "control-manifest.json").read_text())
    D = json.loads((HERE / "dependency-authentication.json").read_text())
    S = json.loads((HERE / "retained-state-authentication.json").read_text())
    raise SystemExit(main())

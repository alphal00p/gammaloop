"""Compare retained matching-owner JSON exports without invoking evaluators."""
import collections
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
OLD = HERE.parent / "historical-generation-proposal/prepared-source-and-driver/historical-matched-decoder-20261026/controller-v2/run1/export"
NEW = HERE / "api-adapted-v2/run1/export"
OUT = HERE / "comparison"
OUT.mkdir(exist_ok=True)


def checksum(data):
    return hashlib.sha256(data).hexdigest()


def description(value):
    if isinstance(value, str) and len(value) > 500:
        return {"type": "string", "bytes": len(value.encode()), "sha256": checksum(value.encode()), "prefix": value[:200], "suffix": value[-100:]}
    if isinstance(value, (dict, list)):
        encoded = json.dumps(value, sort_keys=True, separators=(",", ":")).encode()
        return {"type": type(value).__name__, "length": len(value), "canonical_json_sha256": checksum(encoded)}
    return value


def differences(a, b, path=""):
    if type(a) is not type(b):
        return [{"path": path, "kind": "type", "old": description(a), "current": description(b)}]
    if isinstance(a, dict):
        result = []
        for key in sorted(a.keys() | b.keys()):
            if key not in a or key not in b:
                result.append({"path": path + "/" + key, "kind": "field_presence", "old": description(a.get(key)), "current": description(b.get(key)), "in_old": key in a, "in_current": key in b})
            else:
                result.extend(differences(a[key], b[key], path + "/" + key))
        return result
    if isinstance(a, list):
        result = []
        if len(a) != len(b):
            result.append({"path": path, "kind": "list_length", "old": len(a), "current": len(b)})
        for index, (left, right) in enumerate(zip(a, b)):
            result.extend(differences(left, right, path + "/" + str(index)))
        return result
    return [] if a == b else [{"path": path, "kind": "value", "old": description(a), "current": description(b)}]


def write(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n")


old = json.loads((OLD / "process-0-cross-section.json").read_text())
new = json.loads((NEW / "process-0-cross-section.json").read_text())
diff = differences(old, new)
write("all-process-field-differences.json", diff)
summary = {"scope": "Pure Python comparison of already-retained JSON. No evaluator/model/native generation or numerical evaluation invoked.",
           "old_process_sha256": checksum((OLD / "process-0-cross-section.json").read_bytes()),
           "current_process_sha256": checksum((NEW / "process-0-cross-section.json").read_bytes()),
           "raw_leaf_difference_count": len(diff), "top_level_differences": dict(collections.Counter(row["path"].split("/")[1] for row in diff)),
           "exact_equal_top_level_fields": [key for key in old if old[key] == new.get(key)],
           "supergraph_count": [len(old["supergraphs"]), len(new["supergraphs"])],
           "runtime_term_count": [len(old["runtime_graph_terms"]), len(new["runtime_graph_terms"])],
           "runtime_terms": []}
for index, (left, right) in enumerate(zip(old["runtime_graph_terms"], new["runtime_graph_terms"])):
    term = {"term_index": index, "exact_equal_fields": [key for key in left if left[key] == right.get(key)],
            "difference_counts": dict(collections.Counter(row["path"].split("/")[1] for row in differences(left, right))),
            "old_default_loop_edges": left["graph"]["default_lmb"]["loop_edges"],
            "current_default_loop_edges": right["graph"]["default_lmb"]["loop_edges"],
            "physical_lmb_counts": [len(left["all_lmbs"]), len(right["all_lmbs"])],
            "old_effective_channels": left["multi_channeling_setup"]["effective_channels_from_saved_settings"],
            "current_effective_channels": right["multi_channeling_setup"]["effective_channels_from_saved_settings"]}
    term["default_internal_K_rows_equal"] = [row["internal"] for row in left["graph"]["default_lmb"]["edge_signatures"]] == [row["internal"] for row in right["graph"]["default_lmb"]["edge_signatures"]]
    term["default_external_P_old"] = [row["external"] for row in left["graph"]["default_lmb"]["edge_signatures"]]
    term["default_external_P_current"] = [row["external"] for row in right["graph"]["default_lmb"]["edge_signatures"]]
    summary["runtime_terms"].append(term)
    write(f"runtime-term-{index}-graph-differences.json", differences(left["graph"], right["graph"]))
    write(f"runtime-term-{index}-param-builder-differences.json", differences(left["param_builder"], right["param_builder"]))
    write(f"runtime-term-{index}-evaluator-differences.json", differences(left["stored_evaluator_stacks"], right["stored_evaluator_stacks"]))
write("summary.json", summary)
print(json.dumps(summary, indent=2))

"""Read retained decoder JSON and align stored values by exact parameter names."""

import hashlib
import json
from pathlib import Path
import re

OUT = Path(__file__).resolve().parent
BASE = OUT.parent
EXPORTS = {
    "historical": BASE / "historical-generation-proposal/prepared-source-and-driver/historical-matched-decoder-20261026/controller-v2/run1/export",
    "current": OUT / "api-adapted-v2/run1/export",
}
Q_OLD = "gammalooprs::{spenso::rank1,spenso::tensor}::Q("
Q_CURRENT = "gammalooprs::{spenso::rank1,spenso::tensor,spenso::component-labels:subscript,spenso::tensor-label:q}::Q("


def read(path):
    return json.loads(path.read_text())


def bind(pb):
    assert len(pb["stored_value_rows"]) == 1, "This audit handles the single retained scalar row only"
    row = pb["stored_value_rows"][0]
    result = {}
    occupied = set()
    for group in pb["ordered_pairs"]:
        assert len(group["parameters"]) == group["end"] - group["start"]
        for slot, name in enumerate(group["parameters"], group["start"]):
            assert slot not in occupied and name not in result
            occupied.add(slot)
            result[name] = {"slot": slot, "stored_value": row[slot]}
    assert occupied == set(range(len(row)))
    return result


def parsed_stored_complex(value):
    match = re.fullmatch(r"\(([-+0-9.eE]+)\+([-+0-9.eE]+)i\)", value)
    assert match, value
    # JSON number parsing and equality only: no arithmetic or model evaluation.
    return json.loads("[" + match[1] + "," + match[2] + "]")


def q_presentation_candidate(text):
    # Used ONLY in explicitly labelled candidate sections. Primary matching is exact.
    return text.replace(Q_CURRENT, Q_OLD)


def main():
    inputs = {}
    states = {}
    for label, directory in EXPORTS.items():
        process_path, model_path = directory / "process-0-cross-section.json", directory / "model-by-name.json"
        for kind, path in (("process", process_path), ("model", model_path)):
            inputs[f"{label}_{kind}"] = {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}
        process, model = read(process_path), read(model_path)
        assert len(process["runtime_graph_terms"]) == 1
        term = process["runtime_graph_terms"][0]
        pb = term["param_builder"]
        bindings = bind(pb)
        model_values = {
            f'UFO::{{}}::{item["name"]}': item["value"]
            for group in ("couplings", "parameters") for item in model[group]
        }
        replacements = {record["lhs"]: record for record in pb["stored_function_replacements"]}
        assert len(replacements) == len(pb["stored_function_replacements"])
        states[label] = {
            "pb": pb, "bindings": bindings, "model_values": model_values, "replacements": replacements,
            "copies_equal": term["graph"]["param_builder"] == pb == term["multi_channeling_setup"]["graph"]["param_builder"],
        }
    h, c = states["historical"], states["current"]
    hb, cb = h["bindings"], c["bindings"]
    common = hb.keys() & cb.keys()
    ufo = sorted(name for name in common if name.startswith("UFO::{}::"))
    non_model = sorted(name for name in common if not name.startswith("UFO::{}::"))
    mismatches = [{"name": name, "historical": hb[name], "current": cb[name],
                   "historical_model_value": h["model_values"][name], "current_model_value": c["model_values"][name]}
                  for name in ufo if hb[name]["stored_value"] != cb[name]["stored_value"]]
    q_values = []
    for name in sorted(name for name in hb if name.startswith(Q_OLD)):
        candidate = Q_CURRENT + name[len(Q_OLD):]
        assert candidate in cb
        q_values.append({"historical_name": name, "current_name": candidate,
                         "historical_slot": hb[name]["slot"], "current_slot": cb[candidate]["slot"],
                         "stored_values_equal": hb[name]["stored_value"] == cb[candidate]["stored_value"]})
    hr, cr = h["replacements"], c["replacements"]
    exact_replacement_keys = sorted(hr.keys() & cr.keys())
    q_replacement_pairs = [(name, Q_CURRENT + name[len(Q_OLD):]) for name in hr if name.startswith(Q_OLD)]
    ose_pairs = []
    for old_name in hr:
        if old_name.startswith("gammalooprs::{scalar}::OSE("):
            current_name = old_name.replace("{scalar}", "{scalar,spenso::print-callback}")
            a, b = hr[old_name], cr[current_name]
            ose_pairs.append({"historical_lhs": old_name, "current_lhs": current_name,
                              "rhs_equal_only_after_Q_presentation_candidate": a["rhs"] == q_presentation_candidate(b["rhs"]),
                              "dispatch_tags_equal": a["tags"] == b["tags"],
                              "arguments_debug_equal": a["arguments_debug"] == b["arguments_debug"]})
    color_pairs = [
        ("spenso::{real}::CF", "spenso::{scalar,real}::cas(2,spenso::{spenso::representation,spenso::dualizable}::cof(3))"),
        ("spenso::{real}::CA", "spenso::{scalar,real}::cas(2,spenso::{spenso::representation,spenso::self_dual}::coad(8))"),
        ("spenso::{real}::TR", "spenso::{scalar,real}::idx(2,spenso::{spenso::representation,spenso::dualizable}::cof(3))"),
    ]
    mapped_h = set(exact_replacement_keys) | {name for name, _ in q_replacement_pairs} | {p["historical_lhs"] for p in ose_pairs} | {name for name, _ in color_pairs}
    mapped_c = set(exact_replacement_keys) | {name for _, name in q_replacement_pairs} | {p["current_lhs"] for p in ose_pairs} | {name for _, name in color_pairs}
    report = {
        "scope": "Single retained runtime_graph_terms[0] ParamBuilder in each matching-owner JSON export; name-based stored-value comparison.",
        "method": "Python JSON/string parsing, exact-name dictionary alignment and equality only. Slot ranges locate each name's retained value within its own file; no cross-file positional value comparison, model evaluation, symbolic manipulation, numerical arithmetic, Rust, or generation.",
        "inputs": inputs,
        "param_builder_layout": {
            label: {"ordered_pair_groups": len(s["pb"]["ordered_pairs"]), "stored_rows": len(s["pb"]["stored_value_rows"]),
                    "bindings": len(s["bindings"]), "term_graph_and_multichannel_copies_exactly_equal": s["copies_equal"]}
            for label, s in states.items()
        },
        "exact_name_comparison": {
            "common_names": len(common),
            "common_equal_stored_value_strings": sum(hb[n]["stored_value"] == cb[n]["stored_value"] for n in common),
            "UFO_common_names": len(ufo),
            "UFO_name_sets_equal": {n for n in hb if n.startswith("UFO::{}::")} == {n for n in cb if n.startswith("UFO::{}::")},
            "UFO_order_equal": [n for n in hb if n.startswith("UFO::{}::")] == [n for n in cb if n.startswith("UFO::{}::")],
            "UFO_equal_stored_value_strings": sum(hb[n]["stored_value"] == cb[n]["stored_value"] for n in ufo),
            "UFO_mismatches": mismatches,
            "UFO_bindings_match_own_model_values_after_JSON_number_parse": {
                label: {"bindings": len(s["model_values"]), "matching": sum(parsed_stored_complex(s["bindings"][n]["stored_value"]) == v for n, v in s["model_values"].items())}
                for label, s in states.items()
            },
            "non_model_common_names": non_model,
            "non_model_common_count": len(non_model),
            "non_model_common_values_all_equal_zero_strings": all(hb[n]["stored_value"] == cb[n]["stored_value"] == "(0+0i)" for n in non_model),
            "historical_only_non_Q_bindings": {n: hb[n] for n in sorted(hb.keys() - cb.keys()) if not n.startswith(Q_OLD)},
            "current_only_non_Q_bindings": {n: cb[n] for n in sorted(cb.keys() - hb.keys()) if not n.startswith(Q_CURRENT)},
        },
        "Q_binding_presentation_candidates_separate_from_exact_match": {
            "historical_Q_head": Q_OLD, "current_Q_head": Q_CURRENT,
            "candidate_only_tags": ["spenso::component-labels:subscript", "spenso::tensor-label:q"],
            "preserved_parts": ["gammalooprs namespace", "Q head", "spenso::rank1", "spenso::tensor", "all arguments", "cind component", "stored value"],
            "source_support": ["crates/feynkit-graph/src/symbols.rs:15 declares Q printing tags", "crates/spenso/src/network/tags.rs:776 component printing preserves cind payload", "crates/spenso/src/network/tags.rs:895 describes tensor-label as presentation-only"],
            "caveat": "These are separately reported candidate correspondences, not exact symbol/Atom equality or whole-program equivalence. No tags were stripped for primary binding comparison.",
            "candidate_count": len(q_values), "all_values_are_zero_strings": all(hb[p["historical_name"]]["stored_value"] == cb[p["current_name"]]["stored_value"] == "(0+0i)" for p in q_values),
            "candidates": q_values,
        },
        "stored_function_replacements": {
            "historical_count": len(hr), "current_count": len(cr),
            "exact_common_lhs_count": len(exact_replacement_keys),
            "exact_common_records_equal": all(hr[n] == cr[n] for n in exact_replacement_keys),
            "exact_common_lhs": exact_replacement_keys,
            "historical_only_after_separately_listed_correspondences": [hr[n] for n in sorted(hr.keys() - mapped_h)],
            "current_only_after_separately_listed_correspondences": [cr[n] for n in sorted(cr.keys() - mapped_c)],
            "non_Q_OSE_presentation_candidates": ose_pairs,
            "non_Q_color_key_changes_same_literal_rhs": [
                {"historical": hr[a], "current": cr[b], "literal_rhs_equal": hr[a]["rhs"] == cr[b]["rhs"]}
                for a, b in color_pairs
            ],
            "Q_replacement_candidates": {
                "count": len(q_replacement_pairs),
                "dispatch_tags_all_exact_equal": all(hr[a]["tags"] == cr[b]["tags"] for a, b in q_replacement_pairs),
                "arguments_debug_all_exact_equal": all(hr[a]["arguments_debug"] == cr[b]["arguments_debug"] for a, b in q_replacement_pairs),
                "rhs_equal_only_after_Q_presentation_candidate_count": sum(hr[a]["rhs"] == q_presentation_candidate(cr[b]["rhs"]) for a, b in q_replacement_pairs),
                "rhs_still_differ_historical_lhs": [a for a, b in q_replacement_pairs if hr[a]["rhs"] != q_presentation_candidate(cr[b]["rhs"])],
            },
            "dispatch_tags_caveat": "Replacement-record tags are leading function arguments used in dispatch, not symbol presentation attributes. They are compared exactly and never stripped.",
        },
        "findings": [
            "All 144 UFO bindings match their own matching-owner model values; historical/current runtime differences are exactly GC_57 and GC_63, the two retained model coupling differences.",
            "The 193-to-192 binding count includes removal of historical override_if at slot 16. UFO ordering also differs; comparing values by position would conflate names.",
            "All 31 common exact-name non-model bindings are retained zero strings. The 17 Q bindings are also zero under separately recorded, narrow presentation candidates.",
            "The 58-to-57 replacement count is fully accounted for by 4 exact common records, 40 Q metadata correspondences, 10 OSE metadata correspondences, 3 color-key replacements, and removal of the old pi rational replacement.",
            "Color RHS literals are unchanged for CF/cas, CA/cas, TR/idx; the LHS keys differ, so no identical dispatch semantics is inferred.",
            "The old pi replacement is absent; no inference is made about how the current evaluator handles pi.",
            "Stored runtime parameter or replacement agreement does not establish event-snapshot equivalence or explain a snapshot difference.",
        ],
    }
    output = OUT / "runtime-parameter-binding-comparison.json"
    output.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n")
    print(json.dumps({"report": str(output), "exact_common_bindings": len(common), "UFO_bindings": len(ufo), "UFO_mismatch_names": [v["name"] for v in mismatches], "non_model_common": len(non_model), "Q_candidates": len(q_values), "replacement_counts": [len(hr), len(cr)]}, indent=2))


if __name__ == "__main__":
    main()

"""Compare retained JSON only; never load, evaluate, or simplify a native model."""

from collections import Counter
import hashlib
import json
from pathlib import Path
import re


OUT = Path(__file__).resolve().parent
BASE = OUT.parent
HIST = BASE / "historical-generation-proposal/prepared-source-and-driver/historical-matched-decoder-20261026/controller-v2/run1/export"
CURRENT = BASE / "current-full-runtime-save-oracle/run1/test-state/gl20_multichannel_local_inspect_event_snapshot"
SOURCES = {
    "historical_model": HIST / "model-by-name.json",
    "historical_saved_parameters": HIST / "saved-model-parameters.json",
    "current_original_saved_model": CURRENT / "model.json",
    "current_original_saved_parameters": CURRENT / "model_parameters.json",
    "current_matching_owner_export": OUT / "api-adapted-v2/run1/export/model-by-name.json",
    "current_matching_owner_saved_parameters_export": OUT / "api-adapted-v2/run1/export/saved-model-parameters.json",
}


def read_json(path, tokens=False):
    options = {"parse_float": str, "parse_int": str} if tokens else {}
    return json.loads(path.read_text(), **options)


def by_name(items):
    answer = {item["name"]: item for item in items}
    assert len(answer) == len(items), "Duplicate names would invalidate a name-based comparison"
    return answer


def no_ufo_namespace(expression):
    return expression.replace("UFO::{}::", "") if isinstance(expression, str) else expression


def imaginary_scalar_spelling(expression):
    """Only compare explicit scalar text, without moving factors or terms."""
    if not isinstance(expression, str):
        return expression
    expression = re.sub(r"\((-?\d*𝑖(?:/\d+)?)\)", r"\1", expression)
    return re.sub(r"(?<![0-9])(-?)𝑖", r"\g<1>1𝑖", expression)


def expression_category(historical, current):
    if historical == current:
        return "exact_string_or_null"
    a, b = no_ufo_namespace(historical), no_ufo_namespace(current)
    if a == b:
        return "UFO_namespace_spelling_only"
    if imaginary_scalar_spelling(a) == imaginary_scalar_spelling(b):
        return "UFO_namespace_and_imaginary_scalar_spelling_only"
    if a == "ZERO" and b == "0":
        return "stored_definition_ZERO_reference_to_literal_0"
    return "remaining_text_order_or_other_difference_not_algebraically_checked"


def differing_fields(historical, current):
    return {
        field: {
            "historical_present": field in historical,
            "current_present": field in current,
            "historical": historical.get(field),
            "current": current.get(field),
        }
        for field in sorted(historical.keys() | current.keys())
        if (field in historical) != (field in current)
        or historical.get(field) != current.get(field)
    }


def compare_named_group(group, h, c, ht, ct):
    hm, cm = by_name(h[group]), by_name(c[group])
    htm, ctm = by_name(ht[group]), by_name(ct[group])
    names = sorted(hm.keys() & cm.keys())
    records = []
    for name in names:
        a, b = hm[name], cm[name]
        record = {"name": name, "differing_fields": differing_fields(a, b)}
        if group in ("parameters", "couplings"):
            record.update({
                "value_equal_after_JSON_parse": a["value"] == b["value"],
                "stored_value_number_tokens_equal": htm[name]["value"] == ctm[name]["value"],
                "historical_value_number_tokens": htm[name]["value"],
                "current_value_number_tokens": ctm[name]["value"],
                "expression_comparison_category": expression_category(a["expression"], b["expression"]),
                "historical_expression": a["expression"],
                "current_expression": b["expression"],
                "other_fields_equal": {
                    key: value for key, value in a.items() if key not in ("expression", "value")
                } == {
                    key: value for key, value in b.items() if key not in ("expression", "value")
                },
            })
        records.append(record)
    summary = {
        "historical_count": len(hm),
        "current_count": len(cm),
        "names_equal": hm.keys() == cm.keys(),
        "historical_only_names": sorted(hm.keys() - cm.keys()),
        "current_only_names": sorted(cm.keys() - hm.keys()),
        "exact_records_after_JSON_parse": sum(not item["differing_fields"] for item in records),
        "differing_field_counts": dict(Counter(field for item in records for field in item["differing_fields"])),
    }
    if group in ("parameters", "couplings"):
        summary.update({
            "equal_values_after_JSON_parse": sum(item["value_equal_after_JSON_parse"] for item in records),
            "equal_stored_value_number_tokens": sum(item["stored_value_number_tokens_equal"] for item in records),
            "equal_other_fields": sum(item["other_fields_equal"] for item in records),
            "expression_comparison_counts": dict(Counter(item["expression_comparison_category"] for item in records)),
            "numeric_mismatch_names": [item["name"] for item in records if not item["value_equal_after_JSON_parse"]],
        })
    return {"summary": summary, "records": records}


def main():
    h = read_json(SOURCES["historical_model"])
    original = read_json(SOURCES["current_original_saved_model"])
    c = read_json(SOURCES["current_matching_owner_export"])
    ht = read_json(SOURCES["historical_model"], tokens=True)
    original_tokens = read_json(SOURCES["current_original_saved_model"], tokens=True)
    ct = read_json(SOURCES["current_matching_owner_export"], tokens=True)
    hp = read_json(SOURCES["historical_saved_parameters"])["data"]
    cp = read_json(SOURCES["current_original_saved_parameters"])
    hpt = read_json(SOURCES["historical_saved_parameters"], tokens=True)["data"]
    cpt = read_json(SOURCES["current_original_saved_parameters"], tokens=True)
    owner_cp = read_json(SOURCES["current_matching_owner_saved_parameters_export"])["data"]
    owner_cpt = read_json(SOURCES["current_matching_owner_saved_parameters_export"], tokens=True)["data"]
    groups = {
        group: compare_named_group(group, h, c, ht, ct)
        for group in ("parameters", "couplings", "particles", "propagators", "lorentz_structures", "vertex_rules", "orders")
    }
    report = {
        "scope": "Historical matching-owner decoder export compared to current matching-owner decoder export, with a separate complete current original-saved-JSON retention check.",
        "method": [
            "Python standard library JSON parsing, dictionary/name comparison, string comparison, and input SHA-256 only.",
            "No Rust/toolchain invocation, native model loading, symbolic algebra, expression evaluation, or generation.",
            "Number-token comparison preserves decimal spelling and signed zero in the retained JSON values.",
            "Only the exact UFO::{}:: prefix is removed for namespace-spelling comparison.",
            "A separate explicitly limited textual rule removes parentheses around an imaginary scalar and spells its implicit coefficient 1; factors and terms are never rearranged.",
            "Remaining expression differences are retained verbatim; no mathematical equivalence or inequality is inferred from them.",
        ],
        "inputs": {
            name: {"path": str(path.resolve()), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}
            for name, path in SOURCES.items()
        },
        "current_original_retention": {
            "complete_model_JSON_values_equal": original == c,
            "complete_model_number_tokens_and_strings_equal": original_tokens == ct,
            "array_order_also_preserved": original_tokens == ct,
            "all_top_level_fields_equal": {
                name: original_tokens.get(name) == ct.get(name)
                and (name in original_tokens) == (name in ct)
                for name in sorted(original_tokens.keys() | ct.keys())
            },
            "parameter_values_retained_count": sum(
                by_name(original_tokens["parameters"])[item["name"]]["value"] == item["value"]
                for item in ct["parameters"]
            ),
            "coupling_values_retained_count": sum(
                by_name(original_tokens["couplings"])[item["name"]]["value"] == item["value"]
                for item in ct["couplings"]
            ),
            "saved_parameters_map_equal_to_owner_export_after_unwrapping": cp == owner_cp,
            "saved_parameters_number_tokens_equal_to_owner_export_after_unwrapping": cpt == owner_cpt,
            "conclusion": "Current matching-owner load/export preserves every JSON field, definition, value, and number token in original model.json. No recalculation changed the 72 parameter or 72 coupling values in this retained state.",
        },
        "top_level": {
            "name_equal": h["name"] == c["name"],
            "restriction_equal": h["restriction"] == c["restriction"],
            "historical_only_fields": sorted(h.keys() - c.keys()),
            "current_only_fields": {name: c[name] for name in sorted(c.keys() - h.keys())},
        },
        "saved_external_parameters": {
            "schema_difference": "Historical decoder wraps the map in data; current saved JSON is the map itself.",
            "historical_count": len(hp),
            "current_count": len(cp),
            "names_equal": hp.keys() == cp.keys(),
            "maps_equal_after_unwrapping": hp == cp,
            "stored_number_tokens_equal_after_unwrapping": hpt == cpt,
            "historical_and_current_owner_exports_equal_including_wrapper": read_json(SOURCES["historical_saved_parameters"], tokens=True)
            == read_json(SOURCES["current_matching_owner_saved_parameters_export"], tokens=True),
            "historical_map": hp,
            "current_map": cp,
        },
        "groups": groups,
        "schema_and_saved_definition_differences": {
            "current_only_empty_top_level_fields": ["functions", "form_factors"],
            "particle_schema_differences": {
                "historical_goldstone_current_goldstoneboson_all_43_values_equal": all(
                    item["goldstone"] == by_name(c["particles"])[item["name"]]["goldstoneboson"]
                    for item in h["particles"]
                ),
                "current_added_fields": {
                    field: sorted(set(json.dumps(item[field]) for item in c["particles"]))
                    for field in ("y_charge_right", "propagating", "propagator")
                },
                "historical_charge_to_current_charge_spelling_pairs": sorted(set(
                    (str(item["charge"]), by_name(c["particles"])[item["name"]]["charge"])
                    for item in h["particles"]
                )),
                "historical_y_charge_to_current_y_charge_spelling_pairs": sorted(set(
                    (str(item["y_charge"]), by_name(c["particles"])[item["name"]]["y_charge"])
                    for item in h["particles"]
                )),
            },
            "parameter_ZERO_reference_to_0_names": [
                item["name"] for item in groups["parameters"]["records"]
                if item["expression_comparison_category"] == "stored_definition_ZERO_reference_to_literal_0"
            ],
            "particle_mass_reference_changes": [
                {"name": item["name"], **item["differing_fields"]["mass"]}
                for item in groups["particles"]["records"]
                if "mass" in item["differing_fields"]
            ],
        },
        "interpretation_limits": [
            "Exactly 72/72 parameter value arrays and 70/72 coupling value arrays match, including retained number-token checks.",
            "GC_57 and GC_63 have different retained decimal numbers, so the original stored numeric model data are not exactly identical.",
            "Eleven parameter expression definitions change from ZERO references to literal 0; six particles change their mass reference from MC/Me/MM to ZERO. All referenced parameter values are zero in both JSON files.",
            "The size, origin, or effect of the two coupling-number differences is not established by this JSON/string audit.",
            "Model data agreement or disagreement does not by itself explain any amplitude event-snapshot difference.",
        ],
    }
    output_path = OUT / "model-saved-field-comparison.json"
    output_path.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n")
    print(json.dumps({"report": str(output_path), "group_summaries": {name: result["summary"] for name, result in groups.items()}, "saved_external_parameters_equal": hp == cp}, indent=2))


if __name__ == "__main__":
    main()

"""Summarize stored evaluator interfaces after the verified cut-group map."""
import hashlib
import json
import re
from pathlib import Path

HERE = Path(__file__).resolve().parent
OLD = HERE.parent / "historical-generation-proposal/prepared-source-and-driver/historical-matched-decoder-20261026/controller-v2/run1/export/process-0-cross-section.json"
NEW = HERE / "api-adapted-v2/run1/export/process-0-cross-section.json"
o = json.loads(OLD.read_text())["runtime_graph_terms"][0]
n = json.loads(NEW.read_text())["runtime_graph_terms"][0]
group_map = [2, 0, 3, 1]


def digest(value):
    return hashlib.sha256(value.encode()).hexdigest()


def metadata(e):
    data = e["stored_f64_eager_instruction_data_debug"]
    return {"expression_count": e["expression_count"], "stored_expressions": e["stored_expressions"],
            "backend_policy_debug": e["backend_policy_debug"], "dual_shape": e["dual_shape"],
            "compiled_code_present_not_loaded": e["compiled_code_present_not_loaded"],
            "stored_function_replacement_count": len(e["stored_function_replacements"]),
            "function_replacement_rhs_lengths": [len(r["rhs"]) for r in e["stored_function_replacements"]],
            "function_replacement_rhs_sha256": [digest(r["rhs"]) for r in e["stored_function_replacements"]],
            "f64_eager_debug_bytes": len(data.encode()), "f64_eager_debug_sha256": digest(data),
            "f64_eager_param_count": int(re.search(r"param_count: (\d+)", data).group(1)),
            "f64_eager_reserved_indices": int(re.search(r"reserved_indices: (\d+)", data).group(1)),
            "f64_eager_external_function_section": data.rsplit("external_fns: ", 1)[1]}


report = {"scope": "Stored data inspection only; no evaluator methods invoked. Raw canonical expressions and all eager instruction debug data remain in authenticated full exports.",
          "old_to_current_cut_group_map": group_map,
          "old_param_builder_value_count": len(o["param_builder"]["stored_value_rows"][0]),
          "current_param_builder_value_count": len(n["param_builder"]["stored_value_rows"][0]),
          "row_comparisons": [],
          "interpretation": "Interfaces agree with each owner's parameter builder after removal of old override_if. Current pi is a built-in external constant instead of historical rational replacement. Instruction/register/optimization differences and raw symbolic text differences do not establish mathematical inequality. Stored numerator/evaluator function equivalence remains UNPROVEN."}
for old_index, new_index in enumerate(group_map):
    old_row, new_row = o["stored_evaluator_stacks"][old_index], n["stored_evaluator_stacks"][new_index]
    assert len(old_row) == len(new_row) == 1
    a, b = old_row[0], new_row[0]
    row = {"historical_cut_group": old_index, "current_cut_group": new_index,
           "cut_cff_index_equal": a["cut_cff_index_debug"] == b["cut_cff_index_debug"],
           "cut_cff_index": a["cut_cff_index_debug"], "evaluators": {}}
    for kind in a["stack"]:
        x, y = a["stack"][kind], b["stack"][kind]
        if x is None or y is None:
            row["evaluators"][kind] = {"old_null": x is None, "current_null": y is None}
        else:
            row["evaluators"][kind] = {"historical": metadata(x), "current": metadata(y)}
            assert row["evaluators"][kind]["historical"]["f64_eager_param_count"] == report["old_param_builder_value_count"]
            assert row["evaluators"][kind]["current"]["f64_eager_param_count"] == report["current_param_builder_value_count"]
    report["row_comparisons"].append(row)
target = HERE / "comparison/evaluator-interface-comparison.json"
target.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n")
print(json.dumps({"path": str(target), "sha256": hashlib.sha256(target.read_bytes()).hexdigest(),
                  "cut_group_pairs": group_map, "old_parameters": report["old_param_builder_value_count"],
                  "current_parameters": report["current_param_builder_value_count"],
                  "parameter_counts_match_owner_builders": True}))

"""Recover existing current snapshot output from Insta's retained diff and gold.

This performs text reconstruction and comparisons of existing event numbers only;
it does not invoke any model, evaluator, generation or new sample evaluation.
"""
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
BASE = HERE.parent
GOLD = Path("/shared/codex-1/vakint_rustred/workspace/5l-push/vakint-gl20-current-runtime-save-oracle/tests/tests/snapshots/test_evaluation_api__gl20_multichannel_local_inspect_events.snap")
HISTORICAL_GOLD = Path("/shared/codex-1/vakint_rustred/workspace/5l-push/vakint-gl20-historical-21cefae-capture/tests/tests/snapshots/test_evaluation_api__gl20_multichannel_local_inspect_events.snap")
LOG = BASE / "current-full-runtime-save-oracle/run1/native.log"
OUT = HERE / "comparison"


def record(path):
    payload = Path(path).read_bytes()
    return {"path": str(path), "sha256": hashlib.sha256(payload).hexdigest(), "bytes": len(payload)}


source = GOLD.read_text().splitlines()
assert source[0] == "---"
second = source.index("---", 1)
original = source[second + 1:]
old = json.loads("\n".join(original))
lines = []
cursor = 1
verified = 0
additions = 0
removals = 0
for line in LOG.read_text().splitlines():
    if " │" not in line:
        continue
    gutter, body = line.split(" │", 1)
    if not body or not all(part.isdigit() for part in gutter.split()):
        continue
    numbers = [int(part) for part in gutter.split()]
    prefix = body[0]
    if prefix in "+-":
        assert len(numbers) == 1
        content = body[1:]
        if prefix == "-":
            index = numbers[0]
            assert index >= cursor
            lines.extend(original[cursor - 1:index - 1])
            assert original[index - 1] == content, (index, original[index - 1], content)
            cursor = index + 1
            removals += 1
            verified += 1
        else:
            assert len(lines) + 1 == numbers[0], (len(lines), numbers[0])
            lines.append(content)
            additions += 1
    else:
        assert prefix == " " and len(numbers) == 2
        index, new_index = numbers
        assert index >= cursor
        lines.extend(original[cursor - 1:index - 1])
        assert original[index - 1] == body[1:]
        assert len(lines) + 1 == new_index, (index, new_index, len(lines))
        lines.append(body[1:])
        cursor = index + 1
        verified += 1
lines.extend(original[cursor - 1:])
current_text = "\n".join(lines) + "\n"
new = json.loads(current_text)
target = OUT / "current-existing-snapshot-reconstructed-from-retained-diff.json"
target.write_text(current_text)
events_old = [e for group in old["event_groups"] for e in group]
events_new = [e for group in new["event_groups"] for e in group]
historical_lines = HISTORICAL_GOLD.read_text().splitlines()
historical = json.loads("\n".join(historical_lines[historical_lines.index("---", 1) + 1:]))
events_historical = [e for group in historical["event_groups"] for e in group]


def key(event):
    info = event["cut_info"]
    return (tuple(info["lmb_channel_edge_ids"]), info["cut_id"])


old_by_key = {key(e): e for e in events_old}
new_by_key = {key(e): e for e in events_new}
historical_by_key = {key(e): e for e in events_historical}
assert len(old_by_key) == len(events_old) == len(new_by_key) == len(events_new) == 16
assert old_by_key.keys() == new_by_key.keys()
assert old_by_key.keys() == historical_by_key.keys()
report = {"scope": "Existing retained runtime result only. Text reconstruction from authenticated old gold and current Insta diff; no fresh model/evaluator/sample invocation.",
          "column_old_is_current_committed_gold_NOT_historical_runtime": True,
          "current_committed_gold": record(GOLD), "historical_passed_test_gold": record(HISTORICAL_GOLD),
          "historical_and_current_committed_gold_JSON_equal": historical == old,
          "current_original_test_log": record(LOG), "reconstructed_current_json": record(target),
          "old_rows_verified_against_gold": verified, "removed_rows": removals, "added_rows": additions,
          "current_committed_gold_integrand_result": old["integrand_result"],
          "historical_passed_test_gold_integrand_result": historical["integrand_result"],
          "current_actual_integrand_result": new["integrand_result"],
          "unchanged_top_level_fields": [k for k in old if k != "event_groups" and old[k] == new.get(k)],
          "matched_events": []}
for k in sorted(old_by_key):
    a, b = old_by_key[k], new_by_key[k]
    h = historical_by_key[k]
    report["matched_events"].append({"channel_edges": list(k[0]), "physical_cut_id": k[1],
         "old_event_index": a["event_index"], "current_event_index": b["event_index"],
         "incoming_momenta_exactly_equal": a["incoming_momenta"] == b["incoming_momenta"],
         "old_cut_info": a["cut_info"], "current_cut_info": b["cut_info"],
         "old_outgoing_momenta": a["outgoing_momenta"], "current_outgoing_momenta": b["outgoing_momenta"],
         "current_committed_gold_weight": a["weight"], "historical_passed_test_gold_weight": h["weight"], "current_actual_weight": b["weight"],
         "current_committed_gold_additional_weights": a["additional_weights"],
         "historical_passed_test_gold_additional_weights": h["additional_weights"], "current_actual_additional_weights": b["additional_weights"]})
(OUT / "existing-runtime-snapshot-comparison.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps({k: v for k, v in report.items() if k != "matched_events"}, indent=2))
print("matched_events", len(report["matched_events"]))

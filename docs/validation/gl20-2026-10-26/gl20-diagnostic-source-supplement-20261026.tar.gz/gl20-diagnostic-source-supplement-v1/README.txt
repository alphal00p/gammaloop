Completed GL20 diagnostic source preservation.
Original input manifests, environments, retained states and build products are deliberately absent.
Source files retain their observed stage-local path and unit-label logic, but no bound runtime activation identities.
The archived controllers are not a standalone launch bundle. No helper is run by this archive builder.
The strict original GL20 numerical snapshot still fails; no numerical cause is claimed.

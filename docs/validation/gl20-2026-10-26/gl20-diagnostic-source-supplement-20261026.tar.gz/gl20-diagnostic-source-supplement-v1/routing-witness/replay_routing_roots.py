"""Replay only integer half-edge DFS on completed native JSON witnesses."""
from pathlib import Path
import hashlib
import json

HERE = Path(__file__).resolve().parent
MW = HERE.parent
CAND = MW.parent
SRC = CAND / "regression/source"
BASE = HERE.parents[6]
OLD = Path("/shared/codex-1/vakint_rustred/workspace/5l-push/vakint-gl20-historical-21cefae-capture")


def record(path):
    path = Path(path)
    return {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest(), "bytes": path.stat().st_size}


def reference(path, anchor):
    body = path.read_text()
    assert anchor in body
    return {"path": str(path), "line": body[:body.index(anchor)].count("\n") + 1, "anchor": anchor}


def dfs(edges, vertex_count, root):
    # Exact temporary ordered-graph construction: add_pair allocates source
    # then sink. Active owner uses nodestore-vec: crowns iterate hedge IDs up.
    crowns = [[] for _ in range(vertex_count)]
    opposite, owner, edge_of = {}, {}, {}
    for position, (edge, source, target) in enumerate(edges):
        source_h, target_h = 2 * position, 2 * position + 1
        crowns[source].append(source_h)
        crowns[target].append(target_h)
        opposite[source_h], opposite[target_h] = target_h, source_h
        owner[source_h], owner[target_h] = source, target
        edge_of[source_h] = edge_of[target_h] = edge
    for crown in crowns:
        crown.sort()
    seen = set(crowns[root])
    stack = sorted(seen)
    tree, visits = [], []
    while stack:
        hedge = stack.pop()
        connected = opposite[hedge]
        if connected in seen:
            continue
        tree.append(edge_of[hedge])
        node = owner[connected]
        visits.append({"from_temporary_hedge": hedge, "to_temporary_hedge": connected, "edge": edge_of[hedge], "new_node": node})
        for other in crowns[node]:
            seen.add(other)
            if opposite[other] not in seen:
                stack.append(other)
    return {"root_node": root, "tree_edges": sorted(tree), "tree_discovery_order": tree, "loop_edges": sorted({e for e, _, _ in edges} - set(tree)), "node_discovery_order": [root] + [v["new_node"] for v in visits], "visits": visits}


evidence_path = HERE / "observed-member-order-routing.json"
evidence = json.loads(evidence_path.read_text())
model_path = Path(evidence["model"]["path"])
model = json.loads(model_path.read_text())
by_name = {p["name"]: p for p in model["particles"]}
historical_path = Path(json.loads((CAND / "regression/decoded-physical-frame-comparison.json").read_text())["exports"]["historical"]["path"])
historical = json.loads(historical_path.read_text())["supergraphs"][0]["graph"]
assert all(e["endpoints"]["kind"] == "paired" for e in historical["edges"])
old_ports = {h: e["edge"] for e in historical["edges"] for h in [e["endpoints"]["source"], e["endpoints"]["sink"]]}
old_bits = historical["default_lmb"]["tree"]["set"]["data"]
old_tree_hedges = [i for i in range(historical["default_lmb"]["tree"]["set"]["bits"]) if old_bits[i // 64] & (1 << (i % 64))]
old_tree_edges = sorted({old_ports[h] for h in old_tree_hedges})
rows = []
for member in evidence["members"]:
    root_path = str(Path(member["postlabel"]["path"]))[:-4]
    for role in ("comparison", "physical"):
        native_path = Path(root_path + "." + role + ".json")
        native = json.loads(native_path.read_text())
        internals = []
        external_attachments = {}
        for edge, (endpoints, data) in enumerate(native["edges"]):
            source, target = endpoints["source"], endpoints["target"]
            if data["external"] is not None:
                external_attachments[data["external"]["connection"]] = (source, target)
                continue
            if data["is_dummy"]:
                continue
            particle = model["particles"][data["particle"]]
            if source <= target:
                key = (source, target, particle["pdg_code"], edge)
            else:
                key = (target, source, by_name[particle["antiname"]]["pdg_code"], edge)
            internals.append((key, edge, source, target))
        internals.sort(key=lambda item: item[0])
        ordered = [(edge, source, target) for _, edge, source, target in internals]
        first = native["half_edge_order"][0]
        first_owner = native["edges"][first["edge"]][0][first["endpoint"]]
        current_root = next(source if source is not None else target for _, (source, target) in sorted(external_attachments.items()))
        actual_root_replay = dfs(ordered, len(native["vertices"]), current_root)
        native_first_replay = dfs(ordered, len(native["vertices"]), first_owner)
        assert actual_root_replay["tree_edges"] == native["loop_momentum_basis"]["tree_edges"]
        assert actual_root_replay["loop_edges"] == native["loop_momentum_basis"]["loop_edges"]
        assert native_first_replay["tree_edges"] == old_tree_edges
        assert native_first_replay["loop_edges"] == historical["default_lmb"]["loop_edges"]
        rows.append({"source_diagram": member["source_diagram"], "role": role, "native": record(native_path), "first_native_half_edge": first, "first_native_half_edge_id": 0, "first_native_half_edge_owner": first_owner, "current_external_attachment_root": current_root, "canonical_internal_edge_order": [e for e, _, _ in ordered], "canonical_internal_order_keys": [list(k) for k, _, _, _ in internals], "actual_current_root_replay": actual_root_replay, "native_first_owner_replay": native_first_replay, "actual_current_tree_and_loops_exact": True, "native_first_owner_tree_and_loops_equal_historical_default": True})

old_parse = OLD / "crates/gammalooprs/src/graph/parse/mod.rs"
old_lmb = OLD / "crates/gammalooprs/src/graph/lmb.rs"
old_hedge = OLD / "crates/linnet/src/half_edge.rs"
current_lib = SRC / "crates/feynkit-graph/src/lib.rs"
current_tree = SRC / "crates/linnet/src/half_edge/tree.rs"
current_node = SRC / "crates/linnet/src/half_edge/nodestore/vec.rs"
result = {
    "schema": "gl20.native-first-half-edge-routing-root-integer-replay.v1",
    "status": "PASS_FOUR_ACTUAL_MEMBER_ROLE_REPLAYS_CURRENT_AND_HISTORICAL_ROOT_CONTRACTS",
    "scope": "Pure JSON/source and integer graph/half-edge traversal. No Rust/native process, generation, symbolic or numerical physics evaluation, basis signature calculation, or source patch.",
    "inputs": [record(evidence_path), record(model_path), record(historical_path)],
    "historical_default": {"loop_edges": historical["default_lmb"]["loop_edges"], "tree_edges_decoded_from_stored_integer_bitset": old_tree_edges, "initial_state_cut": historical["initial_state_cut"], "all_native_edges_paired": True, "native_hedge_zero_owner": next(e["endpoints"]["source_node"] if e["endpoints"]["source"] == 0 else e["endpoints"]["sink_node"] for e in historical["edges"] if e["endpoints"]["source"] == 0 or e["endpoints"]["sink"] == 0)},
    "actual_replays": rows,
    "historical_default_source_contract": {
        "chain": "process_cut_edges creates full_cut then removes sewn is_cut initial edge pairs. setup_loop_momentum_basis passes full graph as subgraph and full_cut as forest_guide into lmb_impl. All retained native edges are paired, so internal_crown(full) is empty. lmb_impl selects not_seen.included_iter().next()==Hedge0, resolves self.node_id(root), and empty-externals branch DFS-traverses forest_guide. This default-owner chain is distinct from generate_loop_momentum_bases enumeration of all spanning forests.",
        "references": [reference(old_parse, "let mut full_cut: SuBitGraph = graph.full_filter();"), reference(old_parse, "} else if let Some(h) = e.data.is_cut {"), reference(old_parse, "underlying.lmb_impl(&full, full_cut, external)?"), reference(old_hedge, "pub fn internal_crown<S: SubSetLike>"), reference(old_lmb, "let Some(mut root) = not_seen.included_iter().next()"), reference(old_lmb, "if forest_guide.is_empty() {"), reference(old_lmb, "SimpleTraversalTree::depth_first_traverse(self, forest_guide, &root_node, None)")],
    },
    "current_source_contract": {
        "chain": "with_canonical_loop_momentum_basis sorts internal edges by canonical_order_key. with_first_loop_momentum_basis_in_edge_order builds an undirected temporary graph in this order, roots by external_attachments source.or(target), then DFS with LIFO native half-edges. On all four observed members/roles, source6 is preferred while actual native Hedge0 belongs to7.",
        "references": [reference(current_lib, "pub fn with_canonical_loop_momentum_basis(self)"), reference(current_lib, "pub fn with_first_loop_momentum_basis_in_edge_order("), reference(current_lib, ".filter_map(|(source, target)| (*source).or(*target))"), reference(current_tree, "pub fn depth_first_traverse<"), reference(current_node, "fn get_neighbor_iterator(&self, node_id: NodeIndex)"), reference(current_lib, "pub fn half_edge_id("), reference(current_lib, "pub fn half_edges(&self)"), reference(current_lib, "pub fn underlying(&self)")],
    },
    "minimum_owner_fix_design": {
        "location": reference(current_lib, "let roots = external_attachments"),
        "proposal": "For paired/sewn external connections, prepend the actual native first-half-edge owner to the existing root candidates: self.half_edges().next() -> self.half_edge_id(first) -> self.underlying().node_id(native_hedge), convert native NodeIndex to the existing VertexId mapping. Retain remaining connection-order root candidates and the unchanged uncovered-component fallback. Do not change ordered internal edges, routing equations, loop-edge ordering policy, runtime constants, final representative selection, or supply a literal basis list.",
        "scope": "Paired connection detection can use external_attachments having both source and target. Preserve current amplitude/one-sided connection root path. The existing ordered.is_empty() early return preserves empty/vacuum behavior; keep current fallback for disconnected components whose candidate root has no remaining internal incidence.",
        "why_query": "Actual half_edge_order is owner metadata, so this does not assume first endpoint is Target, incoming, edge0, vertex7, or a fixed GL graph. Mirrors/imports retain whatever native first-half-edge owner their source actually supplies.",
    },
    "focused_test_plan": [
        {"name": "paired_native_first_hedge_owns_default_routing", "basis": "Extend existing generation.rs::default_loop_routing_matches_gl_multichannel_traversal 8-vertex topology from outgoing-only amplitude externals to sewn incoming/outgoing paired connections. Assert first native half-edge query resolves incoming attachment while endpoints.source is the other attachment. Assert the graph-derived source-exact tree and independent-edge order, stable half-edge order, and routing validation; no event evaluator."},
        {"name": "paired_mirror_and_native_hedge_order_counterpart", "basis": "Mirror paired attachments and add an owner-level imported/reordered half_edge_order counterpart so native first owner changes. Verify chosen traversal follows queried native owner, rather than hardcoded Target, incoming, source, vertex ID or a literal edge list. Verify expected forest via explicit topology fixture."},
        {"name": "amplitude_vacuum_and_disconnected_routing_unchanged", "basis": "Retain existing outgoing-only default_loop_routing_matches_gl_multichannel_traversal test and existing canonical topology order test. Add zero/internal-empty and disconnected-component fixtures; preserve old root candidates and uncovered-edge fallback, with complete spanning-forest/routing validation."},
    ],
    "test_gap": "Existing generation.rs::default_loop_routing_matches_gl_multichannel_traversal creates only outgoing externals at vertex7, so current source.or(target) already chooses7 there. It never exercised a paired source6/target7 connection.",
    "limits": "This proves exact integer forest/loop-edge consequences on the four completed observed member/role payloads and identifies the historical default-root source contract. It is not a new scientific evaluation or complete snapshot acceptance; no candidate source was patched.",
}
output = HERE / "native-first-hedge-routing-root-proof.json"
output.write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({"receipt": record(output), "status": result["status"], "actual_replays": len(rows), "roots": sorted({(r["current_external_attachment_root"], r["first_native_half_edge_owner"]) for r in rows}), "historical_tree": old_tree_edges, "historical_loops": historical["default_lmb"]["loop_edges"]}, indent=2))

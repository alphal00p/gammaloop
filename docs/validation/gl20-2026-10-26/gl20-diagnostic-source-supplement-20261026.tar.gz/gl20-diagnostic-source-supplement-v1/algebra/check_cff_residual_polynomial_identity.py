#!/usr/bin/env python3
"""Exact integer polynomial comparison of four already-exported CFF functions.

No numerical point substitution, floating-point arithmetic, Rust, native
evaluator, model/state loading, or CFF generation is performed.
"""
import collections
import datetime
import hashlib
import json
import resource
import time
from pathlib import Path

START = time.monotonic()
MEMORY_BYTES = 1_900_000_000
CPU_SECONDS = 50
WALL_SECONDS = 55
resource.setrlimit(resource.RLIMIT_AS, (MEMORY_BYTES, MEMORY_BYTES))
resource.setrlimit(resource.RLIMIT_CPU, (CPU_SECONDS, CPU_SECONDS))

HERE = Path(__file__).resolve().parent
BASE = HERE.parents[1]
OLD = BASE / "historical-generation-proposal/prepared-source-and-driver/historical-matched-decoder-20261026/controller-v2/run1/export/process-0-cross-section.json"
CURRENT = HERE.parent / "api-adapted-v2/run1/export/process-0-cross-section.json"
EXPECTED = [4, 38, 105, 139]


def budget():
    if time.monotonic() - START > WALL_SECONDS:
        raise TimeoutError("Exact polynomial comparison exceeded internal 55-second wall budget")


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def signed_shift(value):
    rows = value.items() if isinstance(value, dict) else value
    return tuple(sorted((int(key), coefficient) for key, coefficient in rows if coefficient))


def surface_signature(surface, negate=False):
    shift = signed_shift(surface["external_shift"])
    if negate:
        shift = tuple((key, -coefficient) for key, coefficient in shift)
    return tuple(surface["energies"]), shift


def paths(tree, tag, id_field):
    nodes = tree["nodes"]
    indexed = {node[id_field]: node for node in nodes}
    assert len(indexed) == len(nodes)
    roots = [node[id_field] for node in nodes if node["parent"] is None]
    assert len(roots) == 1
    result = []
    pending = [(roots[0], ())]
    while pending:
        budget()
        node_id, path = pending.pop()
        node = indexed[node_id]
        assert set(node["data"]) == {tag}
        path = path + (node["data"][tag],)
        if node["children"]:
            pending.extend((child, path) for child in node["children"])
        else:
            result.append(path)
    return result


old_json = json.loads(OLD.read_text())
current_json = json.loads(CURRENT.read_text())
old_cff = old_json["supergraphs"][0]["stored_global_cff_expression"]
current_cff = current_json["supergraphs"][0]["stored_global_cff_expression"]
old_surfaces = old_cff["surfaces"]["esurface_cache"]
current_surfaces = current_cff["surfaces"]["energy_surfaces"]
old_entries = old_cff["orientations"]
current_entries = current_cff["expression"]["orientations"]

lookup = {surface_signature(surface): index for index, surface in enumerate(current_surfaces)}
assert len(lookup) == len(current_surfaces) == len(old_surfaces) == 29
mapping = [lookup[surface_signature(surface, negate=True)] for surface in old_surfaces]
assert len(set(mapping)) == 29
assert len(old_entries) == len(current_entries) == 144
unit_prefactor = {"denominator": {"Single": 1}, "numerator": {"Single": 1}}
assert all(entry["prefactor"] == unit_prefactor for entry in current_entries)
assert [entry["data"]["orientation"] for entry in old_entries] == [
    entry["data"]["orientation"] for entry in current_entries
]

energy_ids = sorted({edge for surface in current_surfaces for edge in surface["energies"]})
external_ids = sorted({key for surface in current_surfaces for key, _ in signed_shift(surface["external_shift"])})
variable_names = [f"E{edge}" for edge in energy_ids] + [f"q{key}" for key in external_ids]
energy_variables = {edge: index for index, edge in enumerate(energy_ids)}
external_variables = {key: len(energy_ids) + index for index, key in enumerate(external_ids)}
zero = (0,) * len(variable_names)


def linear_form(surface):
    result = {}
    terms = [(energy_variables[edge], 1) for edge in surface["energies"]]
    terms.extend((external_variables[key], coefficient) for key, coefficient in signed_shift(surface["external_shift"]))
    for variable, coefficient in terms:
        assert isinstance(coefficient, int) and not isinstance(coefficient, bool)
        exponent = list(zero)
        exponent[variable] = 1
        exponent = tuple(exponent)
        result[exponent] = result.get(exponent, 0) + coefficient
    return {exponent: coefficient for exponent, coefficient in result.items() if coefficient}


forms = [linear_form(surface) for surface in current_surfaces]


def multiply(left, right):
    result = {}
    for exponents_a, coefficient_a in left.items():
        budget()
        for exponents_b, coefficient_b in right.items():
            exponent = tuple(a + b for a, b in zip(exponents_a, exponents_b))
            result[exponent] = result.get(exponent, 0) + coefficient_a * coefficient_b
    return {exponent: coefficient for exponent, coefficient in result.items() if coefficient}


def add_into(target, source, multiplier=1):
    for exponent, coefficient in source.items():
        target[exponent] = target.get(exponent, 0) + multiplier * coefficient
        if target[exponent] == 0:
            del target[exponent]


def product(surface_ids):
    result = {zero: 1}
    for surface_id in surface_ids:
        result = multiply(result, forms[surface_id])
    return result


def clear_denominators(term_paths, common):
    result = {}
    for path in term_paths:
        assert len(set(path)) == len(path), "Use multiplicity-aware LCM if any path is not squarefree"
        complement = sorted(common.difference(path))
        add_into(result, product(complement))
    return result


def polynomial_rows(poly):
    return [
        {"exponents": list(exponent), "coefficient": coefficient}
        for exponent, coefficient in sorted(poly.items())
    ]


def polynomial_sha(poly):
    return hashlib.sha256(json.dumps(polynomial_rows(poly), separators=(",", ":")).encode()).hexdigest()


def counter_rows(counter):
    return [
        {"surface_ids": list(path), "multiplicity": multiplicity}
        for path, multiplicity in sorted(counter.items())
    ]


rows = []
observed_residuals = []
for index, (old_entry, current_entry) in enumerate(zip(old_entries, current_entries)):
    historical_paths = [tuple(sorted(mapping[x] for x in path)) for path in paths(old_entry["expression"], "Esurface", "node_id")]
    current_paths = [tuple(sorted(path)) for path in paths(current_entry["expression"], "Energy", "id")]
    if collections.Counter(historical_paths) == collections.Counter(current_paths):
        continue
    observed_residuals.append(index)
    common = set().union(*map(set, historical_paths), *map(set, current_paths))
    assert all(len(path) == 5 and len(set(path)) == 5 for path in historical_paths + current_paths)
    historical_numerator = clear_denominators(historical_paths, common)
    current_numerator = clear_denominators(current_paths, common)
    difference = dict(historical_numerator)
    add_into(difference, current_numerator, -1)
    rows.append({
        "historical_and_current_orientation_index": index,
        "historical_normalized_denominator_paths": counter_rows(collections.Counter(historical_paths)),
        "current_denominator_paths": counter_rows(collections.Counter(current_paths)),
        "common_denominator_distinct_surface_ids": sorted(common),
        "common_denominator_degree": len(common),
        "cleared_numerator_degree": len(common) - 5,
        "historical_cleared_numerator_monomials": len(historical_numerator),
        "current_cleared_numerator_monomials": len(current_numerator),
        "historical_cleared_numerator_sha256": polynomial_sha(historical_numerator),
        "current_cleared_numerator_sha256": polynomial_sha(current_numerator),
        "difference_monomials": len(difference),
        "difference_polynomial": polynomial_rows(difference),
        "exact_zero_difference": not difference,
        "historical_cleared_numerator": polynomial_rows(historical_numerator),
        "current_cleared_numerator": polynomial_rows(current_numerator),
    })
assert observed_residuals == EXPECTED, observed_residuals
budget()
usage = resource.getrusage(resource.RUSAGE_SELF)
report = {
    "schema": "gl20.retained-cff-exact-integer-polynomial-identity.v1",
    "status": "PASS_ALL_FOUR_EXACT_ZERO" if all(row["exact_zero_difference"] for row in rows) else "NONZERO_FORMAL_POLYNOMIAL_DIFFERENCE",
    "created_utc": datetime.datetime.now(datetime.UTC).isoformat(),
    "script_sha256": digest(Path(__file__)),
    "inputs": {
        "historical_path": str(OLD), "historical_sha256": digest(OLD),
        "current_path": str(CURRENT), "current_sha256": digest(CURRENT),
    },
    "scope": "Pure Python integer polynomial bookkeeping over already-exported CFF trees and current surface linear forms; no point substitution, floats, native evaluator, generation, Rust execution, or state/model loading.",
    "normalization": {
        "historical_to_current_orientation_index": "Identity; all144 orientation vectors exactly equal in stored order",
        "historical_surface_external_shift": "Negated to account for already-identified external P routing convention",
        "historical_to_current_surface_id_map": mapping,
        "surface_id_key": "Exact ordered energy-edge IDs plus signed external-shift coefficients; all29 keys unique",
        "orientation_prefactors": "All current144 entries are1; historical entries have no additional prefactor",
    },
    "formal_variables": variable_names,
    "surface_linear_forms": [
        {"current_surface_id": index, "monomials": polynomial_rows(form)}
        for index, form in enumerate(forms)
    ],
    "method": "Represent each surface as an exact integer linear polynomial in independent E-edge and external-shift variables. Form the common denominator product of all distinct referenced surface IDs. For each squarefree five-factor denominator path, multiply its complementary surface factors, sum with integer coefficients including path multiplicity, and subtract current from historical. Canonical monomials are exponent tuples; zero coefficients are deleted. No rational simplification or sampled values are used.",
    "domain": "Identity of retained rational CFF functions wherever their denominator products are defined, after the explicit surface/routing map. This establishes no causal attribution and no equality of full numerators, evaluators, event weights, or complete integrands.",
    "results": rows,
    "limits": {"address_space_bytes": MEMORY_BYTES, "cpu_seconds": CPU_SECONDS, "internal_wall_seconds": WALL_SECONDS, "external_wall_seconds": 60},
    "usage": {"elapsed_seconds": time.monotonic() - START, "user_seconds": usage.ru_utime, "system_seconds": usage.ru_stime, "max_rss_kib": usage.ru_maxrss},
    "numerical_point_substitutions": 0,
    "floating_point_polynomial_operations": 0,
    "rust_executions": 0,
}
destination = HERE / "cff-residual-exact-integer-polynomial-identity.json"
with destination.open("x") as stream:
    json.dump(report, stream, indent=2)
    stream.write("\n")
print(json.dumps({
    "status": report["status"],
    "path": str(destination), "sha256": digest(destination),
    "results": [{key: row[key] for key in (
        "historical_and_current_orientation_index", "common_denominator_degree",
        "cleared_numerator_degree", "historical_cleared_numerator_monomials",
        "current_cleared_numerator_monomials", "difference_monomials", "exact_zero_difference"
    )} for row in rows],
    "usage": report["usage"],
}))


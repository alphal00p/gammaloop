"""Seal two sequential owner cohorts. Does not run compiler or numeric code."""
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
BASE = HERE.parent.parent
PYTHON = "/nix/store/jxyrvv4gbpnp3ap5iy7wxwl1sg4x2x88-python3-3.14.6/bin/python3.14"
TASKSET = "/nix/store/156fzvaz2nsq2hk0fkzn9jwk90bnzyn9-util-linux-2.42.2-bin/bin/taskset"


def record(path):
    path = Path(path).resolve()
    with path.open("rb") as stream:
        digest = hashlib.file_digest(stream, "sha256").hexdigest()
    return {"path": str(path), "sha256": digest, "bytes": path.stat().st_size}


for owner in ("current", "historical"):
    cohort = HERE / owner
    plan = json.loads((cohort / "build-plan.json").read_text())
    api = next(stage for stage in plan["stages"] if stage["stage"] == "gammaloop_api")
    gamma = next(stage for stage in plan["stages"] if stage["stage"] == "gammalooprs")
    aliases = {row["extern_alias"]: row for row in api["dependencies"]}
    driver_externs = {name: aliases[name]["artifact"]["path"] for name in ("ndarray", "serde_json", "symbolica", "color_eyre")}
    driver_externs.update(gammaloop_api=api["output"], gammalooprs=gamma["output"])
    driver = [plan["compiler"]["path"], "--crate-name", "gl20_retained_ct_driver", "--edition=2024", "--crate-type=bin",
              "-C", "opt-level=0", "-C", "debuginfo=0", "-C", "linker=" + plan["linker"]["path"],
              "-L", "dependency=" + plan["private_library_directory"], "-L", "dependency=" + str(Path(plan["frozen_target_read_only"]) / "deps")]
    for directory in plan["native_link_search_paths"]:
        driver += ["-L", "native=" + directory]
    for name, path in driver_externs.items():
        driver += ["--extern", name + "=" + path]
    output = str(cohort / "run1/driver")
    driver += [str(cohort / "driver.rs"), "-o", output]
    if owner == "current":
        state_auth = json.loads((HERE.parent / "retained-state-authentication.json").read_text())
    else:
        old_manifest = json.loads((BASE / "historical-generation-proposal/prepared-source-and-driver/historical-matched-decoder-20261026/controller-v2/control-manifest.json").read_text())
        state = Path(old_manifest["retained_state"])
        state_auth = {"root": str(state), "files": [{"relative": row["path"], "path": str(state / row["path"]), "sha256": row["sha256"], "bytes": row["bytes"]} for row in old_manifest["retained_state_files"]]}
    (cohort / "retained-state-authentication.json").write_text(json.dumps(state_auth, indent=2) + "\n")
    override = ""
    if owner == "historical":
        override = "source /shared/codex-1/vakint_rustred/workspace/5l-push/validation/gl20-historical-license-20261026/legacy-license.env >/dev/null 2>&1\nset +x\n"
    launcher = "#!/usr/bin/env bash\nset -euo pipefail\nset +x\numask 077\nsource /shared/codex-1/vakint_rustred/workspace/env.sh >/dev/null 2>&1\nset +x\n" + override
    launcher += '[[ -n ${SYMBOLICA_LICENSE:-} ]] || exit 2\nexec ' + PYTHON + ' -I -B ' + str(HERE / "run_trace.py") + ' ' + owner + ' --manifest-sha256 "$1"\n'
    (cohort / "launch.sh").write_text(launcher)
    controls = [record(cohort / name) for name in ("build-plan.json", "source-freeze.json", "instrumentation-only.diff", "driver.rs", "retained-state-authentication.json", "launch.sh")]
    controls += [record(HERE / name) for name in ("prepare_controls.py", "run_trace.py", "start_trace.py", "driver-template.rs", "independent-instrumentation-driver-review.json")]
    controls += [record(HERE.parent / "run_decoder.py")]
    manifest = {"schema": "gl20.retained-original-point-ct-private-observation.v1", "owner": owner,
                "unit": f"gl20-retained-ct-trace-{owner}-20261026.service", "taskset": TASKSET,
                "controls": controls, "driver_build": {"stage": "driver", "argv": driver, "cwd": str(cohort / "run1"), "output": output},
                "setup_seconds": 1800, "setup_cpus": [145, 146], "math_seconds": 600, "math_cpu": 140,
                "memory_max_bytes": 17179869184, "maximum_compiler_invocations": 3, "maximum_original_point_processes": 1,
                "maximum_EvaluateSamples_run_calls": 1, "whole_workspace_builds": 0, "retries": 0,
                "Root_authorization": "Root authorized minimal private in-crate original-point CT observations on both matching owners, sequential directGamma/API setup CPU145146/2cores16GiB1800s each; then one retained original-point process CPU140/math1/16GiB600s each. Original fixtures/golds/settings/models/tolerances unchanged, no generation/preprocessing/backend/5L activation. Full EvaluateSamples explicitly allowed to expose exact production cut and CT parameters.",
                "scope": "Instrumentation method and two f64 dispatcher capture calls only. Existing branch math is byte-identical after removing observers. All original settings, point, discrete group, selectors and model input values preserved. Runtime warm-up restores caches only. Both components of each complex argument/result retained as exact f64 bits. No golden assertion, golden edit or tolerance acceptance.",
                "profile_note": "Exact retained source flags opt2/debug0/assertions+overflow on. Current256/historical16 CGUs proven by archive object counts; no incremental cache used for new owners. API-onlyrlib output omits unusedcdylib while preserving cli/default features."}
    with (cohort / "control-manifest.json").open("x") as stream:
        json.dump(manifest, stream, indent=2)
        stream.write("\n")
    print(json.dumps({"owner": owner, "manifest": record(cohort / "control-manifest.json"), "driver_externs": list(driver_externs), "state_files": len(state_auth["files"])}))

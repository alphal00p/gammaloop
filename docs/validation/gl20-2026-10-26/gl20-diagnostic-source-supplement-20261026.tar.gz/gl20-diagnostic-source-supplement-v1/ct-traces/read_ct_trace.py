"""Read completed FileJsonFmt JSONL. No native execution or numerical evaluation.

Example, after the cohort has completed:
  python read_ct_trace.py --owner current --trace /absolute/gammalog.jsonl \
      --process-export /absolute/process-0-cross-section.json \
      --output-dir /absolute/current/parsed-trace

The original log is immutable. Output creation is exclusive. Addresses identify
evaluators only within this owner/run; joins use call order and observed context.
"""

import argparse
from collections import Counter
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import re


STAGE = "gl20_retained_f64_dispatch"
ANSI = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]")
MAX_U64 = 18446744073709551615


def digest(path):
    with path.open("rb") as stream:
        checksum = hashlib.file_digest(stream, "sha256").hexdigest()
    return {"path": str(path), "sha256": checksum, "bytes": path.stat().st_size}


def write_json(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, indent=2, ensure_ascii=False)
        stream.write("\n")


def number_field(event, field):
    value = event.get(field)
    if isinstance(value, str) and value.isdecimal():
        value = int(value)
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise ValueError(f"Invalid integer field {field}: {value!r}")
    return value


def bit_pairs(value, field):
    # Rust Debug for Vec<[u64; 2]> is valid JSON; FileJsonFmt stores Debug as text.
    pairs = json.loads(value) if isinstance(value, str) else value
    if not isinstance(pairs, list):
        raise ValueError(f"{field} must be an array")
    for pair in pairs:
        if not isinstance(pair, list) or len(pair) != 2:
            raise ValueError(f"Invalid complex pair in {field}")
        if any(isinstance(v, bool) or not isinstance(v, int) or not 0 <= v <= MAX_U64 for v in pair):
            raise ValueError(f"Invalid u64 component in {field}")
    return pairs


def rust_option_debug_string(value):
    if value in (None, "None"):
        return None, True
    if isinstance(value, str) and value.startswith("Some(") and value.endswith(")"):
        try:
            parsed = json.loads(value[5:-1])
            if isinstance(parsed, str):
                return parsed, True
        except json.JSONDecodeError:
            pass
    # Preserve the complete raw Debug value even when Rust-specific string escapes
    # cannot be decoded by JSON. Never evaluate an expression to interpret it.
    return None, False


def cut_index(message):
    result = {}
    for field in ("lu_cut_order", "left_threshold_order", "right_threshold_order"):
        match = re.search(rf"\b{field}:\s*(?:Some\((\d+)\)|(None))", message)
        if match:
            result[field] = int(match[1]) if match[1] else None
    return result or None


def message_integer(message, field):
    match = re.search(rf"\b{re.escape(field)}=(\d+)", message)
    return int(match[1]) if match else None


def exported_metadata(path):
    if path is None:
        return None
    data = json.loads(path.read_text())
    terms = data["runtime_graph_terms"]
    if len(terms) != 1:
        raise ValueError("Automatic semantic attachment requires exactly one runtime graph term")
    term = terms[0]
    graph = term["graph"]
    hedges = {item["hedge"]: item for item in graph["hedges"]}
    edges = {item["edge"]: item for item in graph["edges"]}
    cuts = []
    for cut_id, cut in enumerate(term["cuts"]):
        boundary = sorted({hedges[h]["edge"] for h in cut["left_cut_hedges"]})
        cuts.append({
            "owner_cut_id": cut_id,
            "boundary_edge_ids": boundary,
            "boundary_edge_names": [edges[i]["name"] for i in boundary],
            "left_cut_hedges": cut["left_cut_hedges"],
            "left_partition_node_ids": sorted({hedges[h]["node"] for h in cut["left_partition_hedges"]}),
            "right_partition_node_ids": sorted({hedges[h]["node"] for h in cut["right_partition_hedges"]}),
        })
    groups = {}
    for group_id, raw_cuts in re.findall(r"CutGroupId\((\d+)\):\s*CutGroup\s*\{\s*cuts:\s*\[([^\]]*)\]", term["cut_groups_debug"]):
        ids = [int(i) for i in re.findall(r"CutId\((\d+)\)", raw_cuts)]
        groups[str(int(group_id))] = [cuts[i] for i in ids]
    return {
        "source": digest(path), "graph_name": graph["name"], "cuts_by_group": groups,
        "effective_channels": term["multi_channeling_setup"]["effective_channels_from_saved_settings"],
        "parameter_order": [name for group in term["param_builder"]["ordered_pairs"] for name in group["parameters"]],
        "identity_caveat": "All edge/node/cut/channel IDs here remain owner-local. Cross-owner graph correspondence must be supplied by the semantic comparison, not by address or positional ID equality.",
    }


class Context:
    def __init__(self, metadata):
        self.metadata = metadata
        self.rotation_number = -1
        self.term_number = 0
        self.term_in_rotation = 0
        self.current = {"role": "unclassified", "context_evidence": {}}
        self.threshold = {}
        self.last_residue = None
        self.last_bare = None
        self.helpers = []

    def evidence(self, key, ref):
        self.current["context_evidence"][key] = ref

    def new_term(self, ref, basis):
        self.term_number += 1
        self.term_in_rotation += 1
        self.current.update(graph_invocation=self.term_number, graph_invocation_in_rotation=self.term_in_rotation)
        self.current["channel_assignment"] = {"basis": basis, "evidence": ref, "confidence": "serial-loop-order-inference"}
        channels = self.metadata["effective_channels"] if self.metadata else []
        if channels and self.term_in_rotation <= len(channels):
            self.current["channel_assignment"]["owner_channel"] = deepcopy(channels[self.term_in_rotation - 1])
        else:
            self.current["channel_assignment"]["owner_channel"] = None

    def update(self, event, ref):
        message = ANSI.sub("", str(event.get("message", "")))
        relevant = False
        precision = re.search(r"\b(f64|f128|ArbPrec) parameterization succeeded", message)
        if precision:
            self.current["pipeline_precision"] = precision[1]
            self.evidence("precision", ref)
            relevant = True
        rotation = re.search(r"Evaluating rotation:\s*(.*)", message)
        if rotation:
            self.rotation_number += 1
            self.term_in_rotation = 0
            self.current = {"role": "unclassified", "pipeline_precision": self.current.get("pipeline_precision"),
                            "rotation": rotation[1], "rotation_sequence": self.rotation_number,
                            "context_evidence": {"rotation": ref}}
            self.threshold, self.last_residue, self.last_bare, self.helpers = {}, None, None, []
            relevant = True
        if message.startswith("loop moms:"):
            self.new_term(ref, "observed CrossSectionGraphTerm loop-momenta marker; owner channel enumeration is serial")
            self.evidence("term_start", ref)
            relevant = True
        cut = re.search(r"START EVALUATION FOR CUT GROUP\s+(\d+)", message)
        if cut:
            group_id = int(cut[1])
            prior = self.current.get("cut_group_id")
            if "graph_invocation" not in self.current or (prior is not None and group_id <= prior and "term_start" not in self.current["context_evidence"]):
                self.new_term(ref, "cut-group sequence reset; no explicit term/channel marker")
            retained = {k: deepcopy(v) for k, v in self.current.items() if k in (
                "pipeline_precision", "rotation", "rotation_sequence", "graph_invocation", "graph_invocation_in_rotation", "channel_assignment")}
            self.current = {**retained, "role": "bare_ir", "cut_group_id": group_id, "context_evidence": {"cut_start": ref}}
            if self.metadata:
                self.current["physical_cuts"] = self.metadata["cuts_by_group"].get(str(group_id))
            self.threshold, self.last_residue, self.last_bare, self.helpers = {}, None, None, []
            relevant = True
        for label in ("esurface_id", "edges in esurface", "radius", "radius_star", "esurface_derivative", "uv_damp_plus", "uv_damp_minus", "h_function", "value of multi-channeling factor"):
            if message.startswith(label + ":"):
                self.threshold[label] = {"text": message[len(label) + 1:].strip(), "evidence": ref}
                relevant = True
        ct_input = re.search(r"LU (left|right|iterated) evaluator input:", message)
        if ct_input:
            side = ct_input[1]
            group_id = message_integer(message, "cut_group_id")
            if self.current.get("cut_group_id") != group_id:
                self.helpers = []
            self.current.update(role="ct_residue", side=side, cut_group_id=message_integer(message, "cut_group_id"),
                                cut_cff_index=cut_index(message), lu_order=message_integer(message, "lu_order"),
                                threshold_parameters_observed=deepcopy(self.threshold),
                                threshold_esurface_id_scope="side-local threshold slot; not a global surface-cache ID")
            if self.metadata:
                self.current["physical_cuts"] = self.metadata["cuts_by_group"].get(str(group_id))
            for key in ("left_threshold_id", "right_threshold_id"):
                value = message_integer(message, key)
                if value is None:
                    self.current.pop(key, None)
                else:
                    self.current[key] = value
            self.current.pop("depends_on_call_ids", None)
            self.evidence("ct_input", ref)
            self.last_residue = None
            relevant = True
        helper = re.search(r"LU threshold helper input \((single|iterated)\):", message)
        if helper:
            self.current.update(role="ct_helper", helper_kind=helper[1], cut_cff_index=cut_index(message),
                                declared_parameter_count=message_integer(message, "param_count"),
                                depends_on_call_ids=[] if self.last_residue is None else [self.last_residue])
            self.evidence("helper_input", ref)
            relevant = True
        if message.startswith("pass 1 result "):
            self.current.update(role="bare_pass_two", depends_on_call_ids=[] if self.last_bare is None else [self.last_bare])
            self.evidence("bare_first_pass_result", ref)
            relevant = True
        if message.startswith("pass_two_result:"):
            self.current["role"] = "ct_preparation"
            self.evidence("bare_pass_two_result", ref)
            relevant = True
        if message.startswith("LU pass-two evaluator input:"):
            self.current.update(role="ct_pass_two", cut_group_id=message_integer(message, "cut_group_id"),
                                lu_order=message_integer(message, "lu_order"),
                                declared_parameter_count=message_integer(message, "param_count"),
                                depends_on_call_ids=list(self.helpers))
            self.current.pop("side", None)
            self.current.pop("left_threshold_id", None)
            self.current.pop("right_threshold_id", None)
            self.current.pop("cut_cff_index", None)
            self.evidence("ct_pass_two_input", ref)
            relevant = True
        return relevant

    def dispatched(self, call_id):
        role = self.current["role"]
        if role == "bare_ir":
            self.last_bare = call_id
        elif role == "ct_residue":
            self.last_residue = call_id
        elif role == "ct_helper":
            self.helpers.append(call_id)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--owner", choices=("current", "historical"), required=True)
    parser.add_argument("--trace", type=Path, required=True, help="Completed FileJsonFmt JSONL file")
    parser.add_argument("--process-export", type=Path)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    trace = args.trace.resolve(strict=True)
    if not trace.is_file():
        parser.error("Trace must be an existing completed file")
    metadata = exported_metadata(args.process_export.resolve(strict=True)) if args.process_export else None
    output = args.output_dir.resolve()
    output.mkdir(parents=True, exist_ok=False)
    context = Context(metadata)
    catalog, roles, issues = {}, Counter(), []
    last_call, dispatch_count, context_count, line_count = None, 0, 0, 0
    input_before = digest(trace)
    with trace.open() as source, (output / "dispatches.jsonl").open("x") as calls, (output / "context-events.jsonl").open("x") as contexts:
        for line_count, line in enumerate(source, 1):
            if not line.endswith("\n"):
                raise ValueError(f"Incomplete final JSONL line {line_count}; do not parse a running trace")
            event = json.loads(line)
            if not isinstance(event, dict) or not {"timestamp", "level", "target"}.issubset(event):
                raise ValueError(f"Line {line_count} is not the actual flat FileJsonFmt schema")
            ref = {"trace_line": line_count, "timestamp": event["timestamp"]}
            relevant = context.update(event, ref)
            if relevant:
                contexts.write(json.dumps({"trace_line": line_count, "event": event}, ensure_ascii=False) + "\n")
                context_count += 1
            if event.get("stage") != STAGE:
                continue
            call_id, evaluator_id = number_field(event, "call_id"), number_field(event, "evaluator_id")
            if last_call is not None and call_id != last_call + 1:
                issues.append({"kind": "nonconsecutive_or_reordered_call_ids", "previous": last_call, "current": call_id, **ref})
            elif last_call is None and call_id != 0:
                issues.append({"kind": "trace_did_not_capture_initial_call", "first_call_id": call_id})
            last_call = call_id
            params = bit_pairs(event.get("params_bits"), "params_bits")
            result = bit_pairs(event.get("output_bits"), "output_bits")
            key = f"{args.owner}:{evaluator_id}"
            first = event.get("first_use")
            if not isinstance(first, bool):
                raise ValueError(f"Invalid first_use flag at line {line_count}")
            if event.get("backend") != "Eager":
                issues.append({"kind": "unexpected_backend", "backend": event.get("backend"), **ref})
            if key not in catalog:
                function_map_raw = event.get("function_map")
                function_map = json.loads(function_map_raw) if isinstance(function_map_raw, str) else function_map_raw
                ir, ir_decoded = rust_option_debug_string(event.get("eager_debug"))
                catalog[key] = {"owner_local_evaluator_id": evaluator_id, "first_observed_call_id": call_id,
                                "first_use_observed": first, "function_map": function_map, "function_map_raw": function_map_raw,
                                "eager_debug": ir, "eager_debug_raw": event.get("eager_debug"),
                                "eager_debug_string_decoded": ir_decoded, "roles_seen": [], "call_count": 0}
                if not first or function_map is None or event.get("eager_debug") in (None, "None"):
                    issues.append({"kind": "missing_first_use_payload", "owner_local_evaluator_key": key, **ref})
            elif first:
                issues.append({"kind": "duplicate_first_use", "owner_local_evaluator_key": key, **ref})
            role = context.current["role"]
            item = catalog[key]
            item["call_count"] += 1
            if role not in item["roles_seen"]:
                item["roles_seen"].append(role)
            record = {"owner": args.owner, "call_id": call_id, "owner_local_evaluator_key": key,
                      "trace_line": line_count, "timestamp": event["timestamp"], "dispatch": event.get("dispatch"),
                      "backend": event.get("backend"), "first_use": first, "params_complex_f64_bits": params,
                      "output_complex_f64_bits": result, "parameter_entry_count": len(params), "output_entry_count": len(result),
                      "params_decimal_debug": event.get("params_decimal"), "output_decimal_debug": event.get("output_decimal"),
                      "span_observed": event.get("span"), "context": deepcopy(context.current)}
            record["semantic_join_fields"] = {
                "role": role,
                "rotation": context.current.get("rotation"),
                "pipeline_precision": context.current.get("pipeline_precision"),
                "physical_cuts": context.current.get("physical_cuts"),
                "channel_assignment": context.current.get("channel_assignment"),
                "side": context.current.get("side"),
                "cut_cff_index": context.current.get("cut_cff_index"),
                "threshold_boundary_observed": context.current.get("threshold_parameters_observed", {}).get("edges in esurface"),
                "caveat": "Apply the independent graph/cut/side correspondence across owners; these owner-local boundaries and call order, not pointer equality, support that join.",
            }
            if metadata and len(params) == len(metadata["parameter_order"]):
                record["parameter_names_from_owner_export"] = metadata["parameter_order"]
            calls.write(json.dumps(record, ensure_ascii=False) + "\n")
            roles[role] += 1
            dispatch_count += 1
            context.dispatched(call_id)
    if not dispatch_count:
        issues.append({"kind": "no_dispatch_records"})
    after = digest(trace)
    if after != input_before:
        issues.append({"kind": "trace_changed_while_reading", "before": input_before, "after": after})
    write_json(output / "evaluator-catalog.json", catalog)
    write_json(output / "owner-semantic-metadata.json", metadata)
    summary = {"schema": "gl20.retained-ct-trace-reader.v1", "owner": args.owner,
               "status": "PASS_PARSED_COMPLETE_TRACE" if not issues else "TRACE_INTEGRITY_ISSUES_REVIEW_REQUIRED",
               "input": input_before, "input_unchanged": after == input_before, "lines": line_count,
               "dispatch_records": dispatch_count, "context_events": context_count, "evaluators": len(catalog),
               "dispatch_roles": dict(roles), "issues": issues,
               "reader": digest(Path(__file__).resolve()),
               "outputs": [digest(output / name) for name in ("dispatches.jsonl", "evaluator-catalog.json", "context-events.jsonl", "owner-semantic-metadata.json")],
               "interpretation": [
                   "Bit arrays are immutable pairs of u64 values for real/imaginary f64 components. No floating-point conversion or evaluator execution is performed.",
                   "Only flat FileJsonFmt records are parsed. It records the current span, not a complete parent span stack; observed spans and contextual event line references are retained.",
                   "CT left/right/iterated labels and CutCFFIndex derive from preceding explicit owner debug messages. Shared pass-two objects are joined to preceding residue/helper call IDs by execution order and those contexts, never by an evaluator address across owners.",
                   "The radial-root/classification esurface_id and LeftThresholdId/RightThresholdId are side-local threshold slots. They must not be interpreted as global surface-cache IDs or raw association-order positions.",
                   "Channel assignment is explicitly an inference from serial owner channel enumeration and graph-term/cut markers. Validate the channel sequence against the retained exported channel inventory; absent markers remain absent rather than being treated as exact labels.",
                   "The trace has no thread identifiers. Surrounding-context joins assume the authorized serial mathematical evaluation; raw event references permit auditing that assumption.",
                   "Owner-local cut/threshold/channel/edge/node IDs and pointer IDs are not cross-owner correspondences. Match semantic graph boundaries and channel bases separately.",
                   "Any higher-precision pipeline context is preserved even though this observer records concrete f64 dispatch calls only.",
               ]}
    write_json(output / "summary.json", summary)
    print(json.dumps({"status": summary["status"], "summary": str(output / "summary.json"), "dispatch_records": dispatch_count,
                      "evaluators": len(catalog), "roles": dict(roles), "issues": issues}, indent=2))
    return 0 if not issues else 2


if __name__ == "__main__":
    raise SystemExit(main())

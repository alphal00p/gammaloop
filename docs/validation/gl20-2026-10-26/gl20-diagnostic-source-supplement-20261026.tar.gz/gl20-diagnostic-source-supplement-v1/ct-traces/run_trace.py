"""One private instrumented owner build and one original-point observation."""
import argparse
import ast
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import sys
import time
import traceback

os.umask(0o077)
HERE = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument("owner", choices=("current", "historical"))
parser.add_argument("--manifest-sha256", required=True)
args = parser.parse_args()
OWNER = HERE / args.owner
RUN = OWNER / "run1"
PHASE_CWD = RUN

# Reuse reviewed ownership/cleanup/deadline code, without executing its CLI/main.
PRIMITIVES = HERE.parent / "run_decoder.py"
assert hashlib.sha256(PRIMITIVES.read_bytes()).hexdigest() == "0cb2a14879b12f448014f10ba8df12438a71edac58672a35baef86ac1eadcc70"
tree = ast.parse(PRIMITIVES.read_text())
names = {"sha", "now", "atomic", "identity", "resources", "signal_owned_group", "reap_and_drain", "phase"}
for node in tree.body:
    if isinstance(node, ast.FunctionDef) and node.name in names:
        source = ast.get_source_segment(PRIMITIVES.read_text(), node)
        if node.name == "phase":
            assert source.count("cwd=RUN") == 1
            source = source.replace("cwd=RUN", "cwd=PHASE_CWD")
        exec(compile(source, str(PRIMITIVES) + ":" + node.name, "exec"), globals())

assert sha(OWNER / "control-manifest.json") == args.manifest_sha256
M = json.loads((OWNER / "control-manifest.json").read_text())
P = json.loads((OWNER / "build-plan.json").read_text())
S = json.loads((OWNER / "retained-state-authentication.json").read_text())


def check_records(value, seen):
    if isinstance(value, dict):
        if isinstance(value.get("path"), str) and isinstance(value.get("sha256"), str) and re.fullmatch(r"[0-9a-f]{64}", value["sha256"]):
            path = value["path"]
            if path not in seen:
                assert sha(path) == value["sha256"], path
                seen.add(path)
        for child in value.values():
            check_records(child, seen)
    elif isinstance(value, list):
        for child in value:
            check_records(child, seen)


def guard():
    assert sha(OWNER / "control-manifest.json") == args.manifest_sha256
    check_records(M["controls"], set())
    check_records(P, set())
    frozen = json.loads((OWNER / "source-freeze.json").read_text())
    for row in frozen["files"]:
        assert sha(Path(frozen["private_crate_source"]) / row["path"]) == row["prepared_sha256"], row["path"]
        assert sha(Path(frozen["original_source"]) / "crates/gammalooprs" / row["path"]) == row["original_sha256"], row["path"]
    for row in S["files"]:
        assert sha(row["path"]) == row["sha256"], row["path"]


def has_stage(value):
    if isinstance(value, dict):
        return value.get("stage") == "gl20_retained_f64_dispatch" or any(has_stage(v) for v in value.values())
    return isinstance(value, list) and any(has_stage(v) for v in value)


def main():
    global PHASE_CWD
    assert os.environ.get("SYMBOLICA_LICENSE")
    assert M["unit"] in Path("/proc/self/cgroup").read_text() and os.environ.get("INVOCATION_ID")
    assert os.sched_getaffinity(0) == {140, 145, 146}
    start = time.monotonic()
    deadline = start + 1800
    guard()
    env = os.environ.copy()
    base = json.loads(Path(P["base_environment_source"]).read_text())[P["base_environment_key"]]
    env.update(base)
    for key in P["environment_unset"]:
        env.pop(key, None)
    for key in list(env):
        if key.startswith("INSTA_") or key.startswith("BASH_FUNC_"):
            env.pop(key)
    env.pop("GL_ALL_LOG_FILTER", None)
    env.update(NO_SYMBOLICA_OEM_LICENSE="1", SYMBOLICA_HIDE_BANNER="1", RUST_BACKTRACE="1",
               GL_DISPLAY_FILTER="off", GL_LOGFILE_FILTER="debug", INSTA_UPDATE="no",
               TMPDIR=str(RUN / "tmp"), XDG_CACHE_HOME=str(RUN / "cache"), GL_TEST_LOG_DIR=str(RUN / "logs"))
    env.update(P["thread_environment_values"])
    for directory in (RUN / "tmp", RUN / "cache", RUN / "logs", RUN / "lib"):
        directory.mkdir(exist_ok=True)
    copied = RUN / "input-copy"
    copied.mkdir()
    for row in S["files"]:
        target = copied / row["relative"]
        target.parent.mkdir(parents=True, exist_ok=True)
        with Path(row["path"]).open("rb") as source, target.open("xb") as destination:
            shutil.copyfileobj(source, destination)
            destination.flush()
            os.fsync(destination.fileno())
        assert sha(target) == row["sha256"] and target.stat().st_ino != Path(row["path"]).stat().st_ino
    compiler = subprocess.check_output([P["compiler"]["path"], "-Vv"], env=env, text=True, timeout=10)
    atomic(RUN / "actual-compiler.json", {"compiler": P["compiler"], "verbose_version": compiler})
    result = {"status": "PRIVATE_OWNER_SETUP_RUNNING_NOT_POINT_PASS", "owner": args.owner,
              "manifest_sha256": args.manifest_sha256, "unit": M["unit"], "invocation_id": os.environ["INVOCATION_ID"],
              "controller": identity(os.getpid()), "phases": [], "retries": 0}
    atomic(RUN / "STARTED.json", result, exclusive=True)
    code = 1
    try:
        for stage in P["stages"] + [M["driver_build"]]:
            for directory in stage.get("directories_controller_must_create", []):
                Path(directory).mkdir(parents=True, exist_ok=True)
            stage_env = env.copy()
            stage_env.update(stage.get("environment_overlay", {}))
            PHASE_CWD = Path(stage["cwd"])
            argv = [M["taskset"], "-c", "145,146"] + stage["argv"]
            result["phases"].append(phase("build-" + stage["stage"], argv, stage_env, max(0, deadline - time.monotonic()), P["compiler"]["path"], {145, 146}))
            artifact = Path(stage["output"])
            assert artifact.is_file() and not artifact.is_symlink()
            atomic(RUN / ("artifact-" + stage["stage"] + ".json"), {"path": str(artifact), "sha256": sha(artifact), "bytes": artifact.stat().st_size})
        guard()
        assert time.monotonic() <= deadline
        result["setup_seconds"] = time.monotonic() - start
        PHASE_CWD = RUN
        executable = Path(M["driver_build"]["output"])
        result["phases"].append(phase("original-point", [M["taskset"], "-c", "140", str(executable), str(copied), str(RUN / "output")], env, 600, executable, {140}))
        completion = json.loads((RUN / "output/completion.json").read_text())
        assert completion["status"] == "PASS_ONE_RETAINED_ORIGINAL_POINT_CT_TRACE_NOT_GOLD_ACCEPTANCE"
        assert completion["state_loads"] == completion["EvaluateSamples_run_calls"] == 1
        for field in ("graph_generation_calls", "preprocessing_calls", "backend_activation_calls", "five_loop_activation_calls"):
            assert completion[field] == 0
        trace_files = sorted((copied / "logs").glob("*.jsonl"))
        assert trace_files
        count = 0
        for path in trace_files:
            with path.open() as stream:
                for line in stream:
                    if "gl20_retained_f64_dispatch" in line:
                        assert has_stage(json.loads(line))
                        count += 1
            with path.open("rb") as stream:
                os.fsync(stream.fileno())
        assert count > 0, "No dispatcher observations; do not retry"
        for row in S["files"]:
            assert sha(copied / row["relative"]) == row["sha256"]
        guard()
        outputs = [path for folder in (RUN / "output", copied / "logs") for path in folder.rglob("*") if path.is_file()]
        result.update(status="PASS_ONE_RETAINED_ORIGINAL_POINT_CT_TRACE_NOT_GOLD_ACCEPTANCE",
                      dispatcher_observation_count=count, outputs=[{"path": str(path), "sha256": sha(path), "bytes": path.stat().st_size} for path in sorted(outputs)],
                      original_state_and_sources_unchanged=True, actual_original_point_invocations=1,
                      actual_direct_rustc_invocations=3)
        code = 0
    except BaseException as error:
        traceback.print_exc()
        result.update(status="FAILED_NO_RETRY", error_type=type(error).__name__, error=str(error))
    finally:
        result.update(returncode=code, finished_utc=now(), resource_end=resources())
        atomic(RUN / "completion.json", result)
    return code


if __name__ == "__main__":
    raise SystemExit(main())

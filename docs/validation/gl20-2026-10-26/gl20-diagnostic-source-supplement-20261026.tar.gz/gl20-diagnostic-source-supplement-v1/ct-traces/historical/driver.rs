//! One retained original-point observation. No graph generation or backend activation.
use std::{env, fs, io::Write, path::Path};
use gammaloop_api::{commands::evaluate_samples::EvaluateSamples, state::State};
use ndarray::Array2;
use serde_json::{Value, json};
use symbolica::LicenseManager;

fn write(path: &Path, value: &Value) -> color_eyre::Result<()> {
    let mut output = fs::OpenOptions::new().write(true).create_new(true).open(path)?;
    output.write_all(&serde_json::to_vec_pretty(value)?)?;
    output.write_all(b"\n")?;
    output.sync_all()?;
    Ok(())
}

fn main() -> color_eyre::Result<()> {
    let args = env::args().collect::<Vec<_>>();
    assert_eq!(args.len(), 3);
    assert!(LicenseManager::is_licensed(), "Matching owner license rejected; stop");
    let output = Path::new(&args[2]);
    fs::create_dir(output)?;
    let mut state = State::load(Path::new(&args[1]).to_path_buf(), None, Some("retained-gl20-ct-point".into()))?;
    let integrand = state.process_list.processes[0].get_integrand_mut("NLO")?;
    let original_settings = serde_json::to_value(integrand.get_settings())?;
    assert_eq!(format!("{:?}", integrand.active_f64_backend()), "Eager");
    write(&output.join("original-runtime-settings.json"), &original_settings)?;
    let point = vec![
        0.16580369091616945,
        0.526_257_890_741_737_3,
        0.13405592891503063,
        0.42630767453517626,
        0.483_232_064_156_230_6,
        0.28439282574429803,
        0.033_834_598_952_534_74,
        0.984_751_664_239_553_8,
        0.722_895_411_958_026_5,
    ];
    let points = Array2::from_shape_vec((1, 9), point.clone())?;
    let dims = Array2::from_shape_vec((1, 1), vec![0_usize])?;
    let result = EvaluateSamples {
        process_id: None,
        integrand_name: None,
        use_arb_prec: false,
        minimal_output: false,
        return_generated_events: None,
        momentum_space: false,
        points: points.view(),
        integrator_weights: None,
        discrete_dims: Some(dims.view()),
        graph_names: None,
        orientations: None,
    }.run(&mut state)?;
    assert_eq!(result.samples.len(), 1);
    // Match the original test's JSON boundary: AdditionalWeightKey is not a JSON map key.
    let evaluation = &result.samples[0].evaluation;
    let metadata = evaluation.evaluation_metadata.as_ref().expect("original point metadata");
    let event_groups = evaluation.event_groups.iter().enumerate().map(|(group_index, group)| {
        group.iter().enumerate().map(|(event_index, event)| {
            let additional = event.additional_weights.weights.iter().map(|(key, value)| {
                (key.to_string(), serde_json::json!(value))
            }).collect::<serde_json::Map<_, _>>();
            json!({"event_group_index":group_index,"event_index":event_index,
                "cut_info":&event.cut_info,"incoming_momenta":&event.kinematic_configuration.0,
                "outgoing_momenta":&event.kinematic_configuration.1,"weight":&event.weight,
                "additional_weights":additional})
        }).collect::<Vec<_>>()
    }).collect::<Vec<_>>();
    write(&output.join("original-point-result.json"), &json!({
        "process":"epem_a_tth","integrand":"NLO","graph":"GL20","point":point,
        "integrand_result":evaluation.integrand_result,"parameterization_jacobian":evaluation.parameterization_jacobian,
        "integrator_weight":evaluation.integrator_weight,
        "metadata":{"generated_event_count":metadata.generated_event_count,
          "accepted_event_count":metadata.accepted_event_count,"is_nan":metadata.is_nan},"event_groups":event_groups
    }))?;
    let integrand = state.process_list.processes[0].get_integrand_mut("NLO")?;
    assert_eq!(serde_json::to_value(integrand.get_settings())?, original_settings);
    assert_eq!(format!("{:?}", integrand.active_f64_backend()), "Eager");
    write(&output.join("completion.json"), &json!({
        "status":"PASS_ONE_RETAINED_ORIGINAL_POINT_CT_TRACE_NOT_GOLD_ACCEPTANCE",
        "owner":"historical", "point":point, "discrete_dims":[0],
        "state_loads":1,"EvaluateSamples_run_calls":1,"backend_before_and_after":"Eager",
        "graph_generation_calls":0,"preprocessing_calls":0,"backend_activation_calls":0,
        "five_loop_activation_calls":0,"original_runtime_settings_unchanged":true,
        "scope":"Original public production point pipeline on retained owner state. Warm-up only restores runtime kinematic caches; private f64 dispatcher observations record source-exact complex buffers and CT/helper outputs. No golden assertion invoked or changed."
    }))?;
    Ok(())
}

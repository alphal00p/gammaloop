"""Compare already observed CT traces. Never executes an evaluator or numerical model.

IEEE bits are decoded only for decimal display. Matching uses chord triples,
physical-cut energy sets and the reviewed side/local-slot correspondence.
"""

import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import struct

HERE = Path(__file__).resolve().parent
HELPER_ARGS = ["side_pass1_result", "eta_derivative", "radius", "radius_star", "uv_damp_plus", "uv_damp_minus", "h_function"]


def read(path):
    return json.loads(path.read_text())


def receipt(path):
    with path.open("rb") as stream:
        checksum = hashlib.file_digest(stream, "sha256").hexdigest()
    return {"path": str(path), "sha256": checksum, "bytes": path.stat().st_size}


def display_pair(bits):
    return {"bits_u64": bits, "decimal_repr": [repr(struct.unpack(">d", value.to_bytes(8, "big"))[0]) for value in bits]}


def compare_pair(historical, current):
    return {"historical": display_pair(historical), "current": display_pair(current),
            "real_bits_equal": historical[0] == current[0], "imaginary_bits_equal": historical[1] == current[1],
            "imaginary_sign_bits_equal": (historical[1] >> 63) == (current[1] >> 63)}


def parse_helper_ir(entry):
    text = entry["eager_debug"]
    match = re.fullmatch(r"ExpressionEvaluator \{ stack: \[(.*?)\], param_count: (\d+), reserved_indices: (\d+), instructions: (.*), result_indices: (.*), external_fns: (.*) \}", text)
    if not match:
        raise ValueError("Unexpected helper ExpressionEvaluator Debug schema")
    stack_text, param_count, reserved, instructions, result_indices, external = match.groups()
    stack = re.findall(r"\(F\([^)]*\)\+F\([^)]*\)i\)", stack_text)
    if ", ".join(stack) != stack_text:
        raise ValueError("Helper stack text was not completely parsed")
    param_count, reserved = int(param_count), int(reserved)
    return {"parameter_count": param_count, "reserved_indices": reserved,
            "constants_only": [{"stack_index": index, "literal": stack[index]} for index in range(param_count, reserved)],
            "instructions_debug": instructions, "result_indices_debug": result_indices, "external_functions_debug": external,
            "function_map": entry["function_map"],
            "caveat": "First-use Debug was captured after evaluation: inputs precede parameter_count and mutated scratch starts at reserved_indices. Neither region is a constant table."}


def load_dataset(directory):
    summary = read(directory / "summary.json")
    if summary["status"] != "PASS_PARSED_COMPLETE_TRACE" or summary["issues"]:
        raise ValueError(f"Trace reader did not pass: {directory}")
    calls = [json.loads(line) for line in (directory / "dispatches.jsonl").open()]
    return {"calls": calls, "catalog": read(directory / "evaluator-catalog.json"), "summary": summary}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--historical", type=Path, default=HERE / "historical/parsed-trace")
    parser.add_argument("--current", type=Path, default=HERE / "current/parsed-trace")
    parser.add_argument("--source-map", type=Path, default=HERE.parent / "comparison/ct-call-semantic-source-map.json")
    parser.add_argument("--conventions", type=Path, default=HERE.parent / "comparison/independent-cut-threshold-convention-comparison.json")
    parser.add_argument("--helper-source-review", type=Path, default=HERE.parent / "ct-imaginary-sign-source-review.json")
    parser.add_argument("--output-dir", type=Path, default=HERE / "mapped-comparison")
    args = parser.parse_args()
    datasets = {"historical": load_dataset(args.historical), "current": load_dataset(args.current)}
    source_map, conventions, helper_source = read(args.source_map), read(args.conventions), read(args.helper_source_review)
    physical = {item["cut_id_historical_and_current"]: tuple(item["energy_edges"]) for item in conventions["cuts"]}
    surfaces = {item["historical_id"]: item for item in conventions["surfaces"]}
    threshold_maps = {"historical": {}, "current": {}}
    for role in source_map["threshold_roles"]:
        for pair in role.get("slot_pairs", []):
            surface = surfaces[pair["historical_global_surface"]]
            if surface["current_id"] != pair["current_global_surface"]:
                raise ValueError("Threshold surface convention map contradicts source slot map")
            semantic = {"physical_cut_energy_edges": list(physical[role["physical_cut"]]),
                        "threshold_energy_edges": surface["energies"], "threshold_signed_external_shift": surface["external_shift"],
                        "historical_group": role["historical_group"], "current_group": role["current_group"],
                        "historical_side": role["historical_side"], "current_side": role["current_side"], **pair}
            for owner in threshold_maps:
                key = (role[f"{owner}_group"], role[f"{owner}_side"], pair[f"{owner}_local_slot"])
                threshold_maps[owner][key] = semantic

    def semantic_key(owner, call):
        context = call["context"]
        channel = context.get("channel_assignment", {}).get("owner_channel")
        cuts = context.get("physical_cuts")
        if not channel or not cuts or len(cuts) != 1:
            raise ValueError(f"Missing unique channel/physical cut context for {owner} call {call['call_id']}")
        chords = tuple(sorted(channel["loop_edges"]))
        cut_edges = tuple(sorted(cuts[0]["boundary_edge_ids"]))
        if list(chords) not in source_map["channel_bases"] or cut_edges not in physical.values():
            raise ValueError("Observed channel or physical cut is outside the reviewed correspondence")
        role = context["role"]
        threshold = None
        if role in ("ct_residue", "ct_helper"):
            side = context["side"]
            slot = context[f"{side}_threshold_id"]
            threshold = threshold_maps[owner][(context["cut_group_id"], side, slot)]
            if tuple(threshold["physical_cut_energy_edges"]) != cut_edges:
                raise ValueError("Mapped threshold belongs to a different physical cut")
        normalized = {"pipeline_precision": context.get("pipeline_precision"), "rotation": context.get("rotation"),
                      "channel_chord_edges": list(chords), "physical_cut_energy_edges": list(cut_edges), "role": role,
                      "threshold_energy_edges": threshold["threshold_energy_edges"] if threshold else None,
                      "threshold_signed_external_shift": threshold["threshold_signed_external_shift"] if threshold else None}
        return json.dumps(normalized, sort_keys=True), normalized, threshold

    indexed = {}
    for owner, dataset in datasets.items():
        table = {}
        for call in dataset["calls"]:
            key, semantic, threshold = semantic_key(owner, call)
            if key in table:
                raise ValueError(f"Ambiguous repeated semantic call for {owner}: {semantic}")
            table[key] = (call, semantic, threshold)
        indexed[owner] = table
    if indexed["historical"].keys() != indexed["current"].keys():
        raise ValueError("Owner traces have unmatched semantic call roles")

    pairs, helper_ir, ufo_observations = [], {}, {}
    for key, (h, semantic, threshold) in sorted(indexed["historical"].items(), key=lambda item: item[1][0]["call_id"]):
        c = indexed["current"][key][0]
        role = semantic["role"]
        row = {"semantic": semantic, "threshold_correspondence": threshold,
               "historical_call_id": h["call_id"], "current_call_id": c["call_id"],
               "historical_owner_local_evaluator_key": h["owner_local_evaluator_key"], "current_owner_local_evaluator_key": c["owner_local_evaluator_key"],
               "historical_context": h["context"], "current_context": c["context"],
               "output_bits_exact_equal": h["output_complex_f64_bits"] == c["output_complex_f64_bits"],
               "outputs": [compare_pair(a, b) for a, b in zip(h["output_complex_f64_bits"], c["output_complex_f64_bits"])],
               "parameter_entry_counts": [h["parameter_entry_count"], c["parameter_entry_count"]]}
        if len(h["output_complex_f64_bits"]) != len(c["output_complex_f64_bits"]):
            raise ValueError("Mapped output shapes differ")
        if role == "ct_helper":
            if h["parameter_entry_count"] != 7 or c["parameter_entry_count"] != 7:
                raise ValueError("This retained first-order helper must have exactly seven complex arguments")
            row["seven_helper_arguments"] = [{"argument": name, **compare_pair(a, b)} for name, a, b in zip(HELPER_ARGS, h["params_complex_f64_bits"], c["params_complex_f64_bits"])]
            row["all_six_geometry_arguments_bit_identical"] = h["params_complex_f64_bits"][1:] == c["params_complex_f64_bits"][1:]
            ir_key = json.dumps({k: semantic[k] for k in ("physical_cut_energy_edges", "threshold_energy_edges", "threshold_signed_external_shift")}, sort_keys=True)
            if ir_key not in helper_ir:
                hi = parse_helper_ir(datasets["historical"]["catalog"][h["owner_local_evaluator_key"]])
                ci = parse_helper_ir(datasets["current"]["catalog"][c["owner_local_evaluator_key"]])
                helper_ir[ir_key] = {"threshold_correspondence": threshold, "historical": hi, "current": ci,
                                     "constants_exact_equal": hi["constants_only"] == ci["constants_only"],
                                     "instructions_exact_equal": hi["instructions_debug"] == ci["instructions_debug"],
                                     "same_single_helper_source_function_sha256": helper_source["single_helper"]["function_sha256"]}
            row["helper_ir_pair_key"] = ir_key
        elif role in ("bare_pass_two", "ct_pass_two"):
            if h["parameter_entry_count"] != 2 or c["parameter_entry_count"] != 2:
                raise ValueError("This retained first-order pass-two evaluator must have exactly two complex arguments")
            row["pass_two_arguments"] = [{"argument": name, **compare_pair(a, b)} for name, a, b in zip(
                ("first_pass_result_or_accumulated_CT", "cut_surface_derivative"), h["params_complex_f64_bits"], c["params_complex_f64_bits"])]
        else:
            hm = dict(zip(h["parameter_names_from_owner_export"], h["params_complex_f64_bits"]))
            cm = dict(zip(c["parameter_names_from_owner_export"], c["params_complex_f64_bits"]))
            ufo = sorted(name for name in hm if name.startswith("UFO::{}::"))
            row["UFO_binding_count"] = len(ufo)
            row["UFO_binding_mismatches"] = [name for name in ufo if hm[name] != cm[name]]
            for name in row["UFO_binding_mismatches"]:
                value = {"name": name, **compare_pair(hm[name], cm[name])}
                ufo_observations[json.dumps(value, sort_keys=True)] = value
        pairs.append(row)
    witness = next((p for p in pairs if p["semantic"]["role"] == "ct_helper" and p["all_six_geometry_arguments_bit_identical"]
                    and any(not value["imaginary_sign_bits_equal"] for value in p["outputs"])), None)
    output = args.output_dir.resolve()
    output.mkdir(parents=True, exist_ok=False)
    def write(name, value):
        with (output / name).open("x") as stream:
            json.dump(value, stream, indent=2, ensure_ascii=False)
            stream.write("\n")
    write("mapped-dispatch-comparisons.json", pairs)
    write("paired-threshold-helper-IR.json", helper_ir)
    summary = {"status": "PASS_SEMANTIC_TRACE_ALIGNMENT_NUMERICAL_DIFFERENCES_REPORTED_NOT_TOLERANCE_ACCEPTANCE",
               "mapped_calls": len(pairs), "roles": dict(Counter(p["semantic"]["role"] for p in pairs)),
               "exact_output_bit_matches_by_role": dict(Counter(p["semantic"]["role"] for p in pairs if p["output_bits_exact_equal"])),
               "helper_pairs_with_six_bit_identical_geometry_arguments": sum(p.get("all_six_geometry_arguments_bit_identical", False) for p in pairs),
               "first_exact_output_bit_mismatch": next((p for p in pairs if not p["output_bits_exact_equal"]), None),
               "first_helper_witness_six_geometry_arguments_bit_identical_and_imaginary_sign_changed": witness,
               "observed_UFO_binding_differences": list(ufo_observations.values()),
               "source_helper_fact": helper_source["single_helper"],
               "inputs": [receipt(args.source_map), receipt(args.conventions), receipt(args.helper_source_review)] + [
                   receipt(directory / name) for directory in (args.historical, args.current) for name in ("summary.json", "dispatches.jsonl", "evaluator-catalog.json")],
               "reader": receipt(Path(__file__).resolve()),
               "outputs": [receipt(output / name) for name in ("mapped-dispatch-comparisons.json", "paired-threshold-helper-IR.json")],
               "interpretation_limits": [
                   "Pairing uses channel chord triples, physical-cut energy sets and the reviewed side-local threshold slot/surface correspondence. Neither pointer identities nor raw cutgroup/threshold IDs are compared across owners.",
                   "Output and helper arguments are compared exactly as IEEE bit pairs. Decimal strings are only representation decoding via struct.unpack; no absolute errors, ratios, tolerances, conjugation transforms, evaluator executions or model calculations are performed.",
                   "The earliest exact mismatch can be a last-digit or very small imaginary residual. The separate helper witness records exact agreement of six geometry inputs with changed output imaginary sign, without a tolerance-based equivalence claim for the complex residue input.",
                   "Captured eager Debug includes already-mutated inputs and scratch. The helper IR report isolates constants [param_count,reserved_indices), instructions and result indices; full raw Debug remains in each reader catalog.",
                   "Two retained own-model coupling differences remain reported explicitly. Their presence is not silently excused or treated as proof of the helper sign discrepancy's cause.",
                   "This localizes an observed boundary. It does not authorize a scientific sign flip or establish the physical correctness of either side convention.",
               ]}
    write("summary.json", summary)
    print(json.dumps({"summary": str(output / "summary.json"), "mapped_calls": len(pairs), "roles": summary["roles"],
                      "helper_geometry_exact_pairs": summary["helper_pairs_with_six_bit_identical_geometry_arguments"],
                      "first_helper_witness": None if witness is None else {"semantic": witness["semantic"], "historical_call_id": witness["historical_call_id"],
                          "current_call_id": witness["current_call_id"], "outputs": witness["outputs"]},
                      "UFO_difference_names": sorted({row["name"] for row in ufo_observations.values()})}, indent=2))


if __name__ == "__main__":
    main()

//! Source-only prepared driver: replay exactly the original fixture's diagram-only prefix.
//! Usage: driver ORIGINAL_WORKSPACE PRIVATE_FRESH_STATE PRIVATE_FRESH_OUTPUT
//! FeynKit generation witness hooks are supplied by the separately reviewed private generator.
use std::{env, fs, io::Write, ops::ControlFlow, path::Path};

use gammaloop_api::{
    commands::{Commands, generate::GenerateCmd},
    state::{RunHistory, State, SyncSettings},
};
use gammalooprs::{
    initialisation::initialise,
    processes::ProcessCollection,
    utils::load_generic_model,
};
use serde_json::{Value, json};
use symbolica::license::LicenseManager;

fn write(path: &Path, value: &Value) -> color_eyre::Result<()> {
    let mut output = fs::OpenOptions::new().write(true).create_new(true).open(path)?;
    output.write_all(&serde_json::to_vec_pretty(value)?)?;
    output.write_all(b"\n")?;
    output.sync_all()?;
    Ok(())
}

fn main() -> color_eyre::Result<()> {
    let args = env::args().collect::<Vec<_>>();
    assert_eq!(args.len(), 4);
    assert!(LicenseManager::is_licensed(), "Matching current owner license rejected; stop");
    let workspace = Path::new(&args[1]).canonicalize()?;
    let state_path = Path::new(&args[2]);
    let output = Path::new(&args[3]);
    assert!(state_path.is_absolute() && output.is_absolute());
    assert!(!state_path.exists(), "Fresh witness state path must not already exist");
    assert!(!output.exists(), "Fresh witness output path must not already exist");
    assert!(!state_path.starts_with(&workspace) && !output.starts_with(&workspace));
    fs::create_dir(output)?;

    // Exact run_card/new_cli_for_test/build_cli_for_run_history prefix from tests/src/lib.rs.
    // No integration-test helper crate, test function, cleanup or final SaveState is invoked.
    env::set_current_dir(&workspace)?;
    initialise()?;
    let fixture = workspace.join("tests/resources/run_cards/test_epem_tth_multichannel_gl20.toml");
    let mut run_history = RunHistory::load(&fixture)?;
    assert_eq!(run_history.commands.len(), 10);
    assert!(run_history.command_blocks.is_empty());
    let raw_commands = run_history.commands.iter().map(|entry| {
        entry.raw_string.clone().expect("Original fixture commands must retain their source strings")
    }).collect::<Vec<_>>();
    assert_eq!(raw_commands[0].trim(), "import model sm-default.json");
    for command in &raw_commands[1..9] {
        assert!(command.trim().starts_with("set model "));
    }
    match &run_history.commands[9].command {
        Commands::Generate(generate) => match &generate.mode {
            Some(GenerateCmd::Xs(spec)) => assert!(spec.only_diagrams),
            _ => panic!("Original prefix must end in diagram-only cross-section generation"),
        },
        _ => panic!("Original prefix must contain exactly the expected generation command"),
    }
    let mut state = State::new(state_path, Some("generation-frame-witness".into()));
    state.model = load_generic_model("sm");
    let mut cli_settings = run_history.cli_settings.clone();
    cli_settings.state.folder = state_path.to_path_buf();
    cli_settings.sync_settings()?;
    let mut default_runtime_settings = run_history.default_runtime_settings.clone();
    assert_eq!(cli_settings.global.n_cores.feyngen, 1);
    assert!(!cli_settings.global.generation.evaluator.compile);
    write(&output.join("original-fixture-prefix.json"), &json!({
        "fixture":fixture,
        "raw_commands":raw_commands,
        "cli_settings_used":cli_settings,
        "default_runtime_settings_used":default_runtime_settings,
        "source":"Original tests/src/lib.rs get_test_cli/run_card/new_cli_for_test/build_cli_for_run_history prefix; only state.folder redirects to a fresh private location."
    }))?;
    let flow = run_history.run(&mut state, &mut cli_settings, &mut default_runtime_settings)?;
    assert!(matches!(flow, ControlFlow::Continue(())));

    // Inspect already generated native objects only. No generate-existing, CFF construction,
    // runtime backend preparation, event evaluation, integrand evaluation or golden assertion.
    let mut inventory = Vec::new();
    for (process_id, process) in state.process_list.processes.iter().enumerate() {
        let ProcessCollection::CrossSections(collection) = &process.collection else {
            panic!("Original fixture must generate only a cross-section process");
        };
        for (name, cross_section) in collection {
            assert!(cross_section.integrand.is_none(), "Diagram-only generation produced a runtime integrand");
            let graphs = cross_section.supergraphs.iter().map(|supergraph| {
                assert!(supergraph.derived_data.global_cff_expression.is_none(),
                    "Diagram-only generation unexpectedly constructed a global CFF");
                json!({
                    "graph_name":supergraph.graph.name,
                    "group_id":supergraph.graph.group_id.map(|id|id.0),
                    "is_group_master":supergraph.graph.is_group_master,
                    "finalized_physical_cut_count":supergraph.cuts.len(),
                    "finalized_topology_threshold_candidate_count":supergraph.topology_threshold_candidates.len(),
                    "global_cff_present":false
                })
            }).collect::<Vec<_>>();
            inventory.push(json!({
                "process_id":process_id,"process_folder":process.definition.folder_name,
                "integrand_name":name,"native_supergraphs":graphs,
                "runtime_integrand_present":false
            }));
        }
    }
    assert_eq!(inventory.len(), 1);
    write(&output.join("generated-native-inventory.json"), &json!(inventory))?;
    write(&output.join("generated-model-by-name.json"), &serde_json::to_value(&state.model)?)?;
    write(&output.join("generated-model-parameters.json"), &serde_json::to_value(state.model_parameters.to_serializable())?)?;
    write(&output.join("completion.json"), &json!({
        "status":"PASS_ONE_ORIGINAL_FIXTURE_DIAGRAM_GENERATION_FRAME_WITNESS_NOT_A_PRODUCTION_FIX",
        "fixture":fixture,"state_folder":state_path,
        "RunHistory_run_calls":1,"diagram_generation_commands":1,
        "State_load_calls":0,"generate_existing_commands":0,
        "postprocess_commands":0,"event_or_integrand_evaluation_calls":0,
        "backend_activation_calls":0,"five_loop_campaign_calls":0,
        "runtime_integrands_constructed":0,"global_CFFs_constructed":0,
        "scope":"One fresh generation-only replay of the exact original fixture prefix. The separately instrumented FeynKit generator must capture the actual current orientation population and both canonicalization candidates; this driver performs no candidate selection, sign fix or numerical point replay."
    }))?;
    Ok(())
}

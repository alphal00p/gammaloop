"""Prepare observer-only private FeynKit generation witness. Never invoke Rust."""
import difflib
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ORIGINAL = Path('/shared/codex-1/vakint_rustred/workspace/5l-push/vakint-gl20-current-runtime-save-oracle/crates/feynkit-generator')
PRIVATE = HERE / 'source/feynkit-generator'

HELPERS = r'''
// Private generation-frame witness; observers never choose or mutate a graph.
fn frame_witness_scope_id() -> Option<u64> {
    use std::sync::atomic::{AtomicU64, Ordering};
    static NEXT: AtomicU64 = AtomicU64::new(0);
    std::env::var_os("GL20_GENERATION_FRAME_WITNESS_ROOT")
        .map(|_| NEXT.fetch_add(1, Ordering::Relaxed))
}

pub(crate) fn frame_witness_emit(
    stage: &str,
    make_payloads: impl FnOnce() -> Vec<(&'static str, String)>,
) {
    use std::io::Write;
    use std::sync::atomic::{AtomicU64, Ordering};
    static NEXT: AtomicU64 = AtomicU64::new(0);
    let Some(root) = std::env::var_os("GL20_GENERATION_FRAME_WITNESS_ROOT") else { return; };
    let root = std::path::PathBuf::from(root);
    std::fs::create_dir_all(&root).expect("generation-frame witness directory");
    let sequence = NEXT.fetch_add(1, Ordering::Relaxed);
    for (suffix, payload) in make_payloads() {
        let path = root.join(format!("{sequence:07}-{stage}.{suffix}"));
        let mut file = std::fs::OpenOptions::new().write(true).create_new(true)
            .open(path).expect("exclusive generation-frame witness output");
        file.write_all(payload.as_bytes()).expect("generation-frame witness write");
        file.flush().expect("generation-frame witness flush");
    }
}

fn frame_witness_raw_colored(graph: &Graph<ColoredNode, EdgeColor>, model: &Model) -> String {
    let nodes = graph.nodes().iter().enumerate().map(|(index, node)| {
        let (external_tag, rule_name) = match &node.data {
            ColoredNode::External(external) => (external.index as i64 + 1, "external".to_owned()),
            ColoredNode::Interaction(rule) => (0, model.vertex_rule_by_id(*rule)
                .expect("witness vertex rule").name.clone()),
        };
        (index, external_tag, rule_name, node.edges.clone(), node.valence,
         format!("{:?}", node.data))
    }).collect::<Vec<_>>();
    let external_rows = graph.nodes().iter().enumerate().filter_map(|(index, node)| {
        let ColoredNode::External(external) = &node.data else { return None; };
        let particle = model.particle_by_id(external.particle).expect("witness external particle");
        Some((index, external.index, format!("{:?}", external.state), external.particle.index(),
              particle.name.clone(), particle.pdg_code))
    }).collect::<Vec<_>>();
    let edges = graph.edges().iter().enumerate().map(|(index, edge)| {
        let particle = model.particle_by_id(edge.data.particle).expect("witness particle");
        let mass = model.parameter_by_id(particle.mass).expect("witness mass parameter");
        (index, edge.vertices, edge.directed, particle.pdg_code, particle.name.clone(),
         particle.mass.index(), mass.name.clone(), particle.spin, edge.data.particle.index(),
         edge.data.direction)
    }).collect::<Vec<_>>();
    format!("model_name={:?}\nnode_row_fields=(index,external_tag,vertex_rule_name,incident_edges_in_stored_order,valence,native_color_debug)\nnode_rows={nodes:#?}\nexternal_row_fields=(node_index,external_index,state,particle_id,particle_name,signed_pdg)\nexternal_rows={external_rows:#?}\nedge_row_fields=(index,endpoints,directed,signed_pdg,particle_name,mass_parameter_id,mass_parameter_name,spin,particle_id,color_direction)\nedge_rows={edges:#?}\nraw_native_graph_debug={graph:#?}\nlegacy_note=legacy external vertex_rule name is represented by literal external; native external data remain in color_debug; legacy pre-normalization comparison made all edges directed=true, while actual current directed fields are retained here\n", model.name())
}

'''

changes = []
def replace(text, before, after, label):
    assert text.count(before) == 1, (label, text.count(before))
    changes.append(label)
    return text.replace(before, after)

path = ORIGINAL / 'src/generation.rs'
original = path.read_text()
text = original
text = replace(text, '#[cfg(test)]\n#[path = "main_generation_regressions.rs"]', HELPERS + '#[cfg(test)]\n#[path = "main_generation_regressions.rs"]', 'private std-only observer helpers')
text = replace(text, '        let mut grouped = BTreeMap::new();\n        for assignment in assignments {', '        let frame_witness_assignment_count = assignments.len();\n        let mut grouped = BTreeMap::new();\n        for assignment in assignments {', 'retain assignment count')
text = replace(text, '            *grouped.entry(colored.canonize().graph).or_insert(0) += 1;', r'''            let frame_witness_canonical = colored.canonize();
            frame_witness_emit("assignment-colored-canonicalization", || vec![("txt", format!(
                "assignment_count={frame_witness_assignment_count}\nPRE_COLORED_FRAME\n{}\nPOST_COLORED_FRAME\n{}\ncolored_vertex_map={:#?}\n",
                frame_witness_raw_colored(&colored, &self.model),
                frame_witness_raw_colored(&frame_witness_canonical.graph, &self.model),
                frame_witness_canonical.vertex_map,
            ))]);
            *grouped.entry(frame_witness_canonical.graph).or_insert(0) += 1;''', 'observe existing colored canonicalization once')
text = replace(text, '        let mut candidates = Vec::new();\n        let mut remappings', '        let frame_witness_scope = frame_witness_scope_id();\n        let mut candidates = Vec::new();\n        let mut remappings', 'correlate each numerator canonicalization pass')
text = replace(text, '            candidates.push((swapped, remapping, skeleton.canonize()));', r'''            let frame_witness_canonical = skeleton.canonize();
            frame_witness_emit("global-lr-candidate-BEFORE-SORT", || vec![("txt", format!(
                "scope={frame_witness_scope:?}\ninclude_external_remapping={include_external_remapping}\nuse_sewn_external_colors={use_sewn_external_colors}\nexact_internal_particles={exact_internal_particles}\nleft_right_swapped={swapped}\nexternal_remapping={remapping:#?}\nPRE_SKELETON_INPUT_FRAME\n{}\nraw_reduced_skeleton={skeleton:#?}\ncanonical_reduced_nodes={:#?}\ncanonical_reduced_edges={:#?}\ncanonical_vertex_map={:#?}\n",
                frame_witness_raw_colored(graph, model), frame_witness_canonical.graph.nodes(),
                frame_witness_canonical.graph.edges(), frame_witness_canonical.vertex_map,
            ))]);
            candidates.push((swapped, remapping, frame_witness_canonical));''', 'observe both existing global LR candidate keys before sorting')
text = replace(text, '        let inverse_remapping = remapping\n', r'''        frame_witness_emit("global-lr-selected-AFTER-SORT", || vec![("txt", format!(
            "scope={frame_witness_scope:?}\nselected_left_right_swapped={left_right_swapped}\nselected_remapping={remapping:#?}\nselected_canonical_nodes={:#?}\nselected_canonical_edges={:#?}\nselected_vertex_map={:#?}\n",
            canonical.graph.nodes(), canonical.graph.edges(), canonical.vertex_map,
        ))]);
        let inverse_remapping = remapping
''', 'observe selected LR candidate without changing sorting')
text = replace(text, '            let normalized = resolved.normalize_fermion_flows(&topology.graph, &self.model)?;\n            let representative = ColoredTopology {', r'''            let normalized = resolved.normalize_fermion_flows(&topology.graph, &self.model)?;
            frame_witness_emit("raw-normalized-comparison-pair", || vec![("txt", format!(
                "retained_diagram_input_index={}\ncolored_enumeration_index={index}\nNORMALIZATION_INPUT_COMPARISON\n{}\nNORMALIZATION_OUTPUT_PHYSICAL\n{}\nreversed_edges={:#?}\nnormalization_signs={:#?}\ninput_cuts={:#?}\ninput_topology_thresholds={:#?}\n",
                diagram_inputs.len(), frame_witness_raw_colored(&topology.graph, &self.model),
                frame_witness_raw_colored(&normalized.graph, &self.model), normalized.reversed_edges,
                normalized.signs, topology.cut_partitions, topology.topology_threshold_candidates,
            ))]);
            let representative = ColoredTopology {''', 'observe raw normalization pair with legacy Ord fields')
text = replace(text, '            .map(|pair| Ok((pair.comparison.canonical_key()?, pair)))', r'''            .map(|pair| {
                let frame_witness_comparison_key = pair.comparison.canonical_key()?;
                frame_witness_emit("native-pair-PRELABELS", || vec![
                    ("txt", format!("construction_name={:?}\ncomparison_id={:?}\nphysical_id={:?}\nreversed_edges={:#?}\nACTUAL_COMPARISON_SORT_KEY={:#?}\nDIAGNOSTIC_ONLY_PHYSICAL_CANONICAL_KEY={:#?}\ncomparison_native_debug={:#?}\nphysical_native_debug={:#?}\n",
                        pair.comparison.name(), pair.comparison.id(), pair.representative.id(),
                        pair.reversed_edges, frame_witness_comparison_key,
                        pair.representative.canonical_key().expect("diagnostic physical key"),
                        pair.comparison, pair.representative)),
                    ("comparison.json", pair.comparison.to_json().expect("witness comparison JSON")),
                    ("physical.json", pair.representative.to_json().expect("witness physical JSON")),
                ]);
                Ok((frame_witness_comparison_key, pair))
            })''', 'retain actual comparison key and diagnostic physical key without replacing comparator')
text = replace(text, '        for (index, (_, mut pair)) in keyed_diagrams.into_iter().enumerate() {\n            let name', '        for (index, (_, mut pair)) in keyed_diagrams.into_iter().enumerate() {\n            let frame_witness_construction_name = pair.comparison.name().to_owned();\n            let name', 'retain prelabel construction index crosslink')
text = replace(text, '            comparison_diagrams.push(pair.comparison);\n            representatives.push((pair.representative, pair.reversed_edges));', r'''            frame_witness_emit("native-pair-POSTLABELS", || vec![
                ("txt", format!("source_diagram_index={index}\nfinal_source_name={name:?}\nconstruction_name={frame_witness_construction_name:?}\ncomparison_id={:?}\nphysical_id={:?}\nreversed_edges={:#?}\n",
                    pair.comparison.id(), pair.representative.id(), pair.reversed_edges)),
                ("comparison.json", pair.comparison.to_json().expect("postlabel comparison JSON")),
                ("physical.json", pair.representative.to_json().expect("postlabel physical JSON")),
            ]);
            comparison_diagrams.push(pair.comparison);
            representatives.push((pair.representative, pair.reversed_edges));''', 'retain all actual postlabel native pairs including 4 and 6')
text = replace(text, '            diagrams.push(representative);\n\n            for member in &mut group.members {', r'''            frame_witness_emit("group-final-physical-exposure", || vec![
                ("txt", format!("output_group_index={output_index}\nselected_source_diagram={source_diagram}\ngroup_before_member_provenance_update={group:#?}\nselected_reversed_edges={reversed_edges:#?}\n")),
                ("comparison-master.json", comparison_master.to_json().expect("group comparison JSON")),
                ("selected-paired-physical.json", source_representative.to_json().expect("group paired physical JSON")),
                ("final-physical.json", representative.to_json().expect("group final physical JSON")),
            ]);
            diagrams.push(representative);

            for member in &mut group.members {''', 'observe final group physical frame and transported inventory')
(PRIVATE / 'src/generation.rs').write_text(text)

path2 = ORIGINAL / 'src/grouping.rs'
original2 = path2.read_text()
text2 = replace(original2, '        let canonical = canonical_topology(diagram, model, options, symmetrize_left_right)?;\n        let key', r'''        let canonical = canonical_topology(diagram, model, options, symmetrize_left_right)?;
        crate::generation::frame_witness_emit("grouping-canonical-frame", || vec![("txt", format!(
            "retained_index={index}\nsource_diagram_index={}\nsource_name={:?}\nsource_id={:?}\nleft_right_swapped={}\nvertex_map={:#?}\ncanonical_topology_key={:#?}\n",
            source_diagrams[index], diagram.name(), diagram.id(), canonical.left_right_swapped,
            canonical.vertex_map, canonical.key,
        ))]);
        let key''', 'observe grouping canonical side flag and vertex transport frame')
(PRIVATE / 'src/grouping.rs').write_text(text2)

diff = ''.join(difflib.unified_diff(original.splitlines(True), text.splitlines(True), fromfile='original/src/generation.rs', tofile='private-witness/src/generation.rs'))
diff += ''.join(difflib.unified_diff(original2.splitlines(True), text2.splitlines(True), fromfile='original/src/grouping.rs', tofile='private-witness/src/grouping.rs'))
(HERE / 'instrumentation-only.diff').write_text(diff)
def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()
record = {
    'status': 'PREPARED_PRIVATE_OBSERVERS_ONLY_NO_RUST_OR_GENERATION_EXECUTED',
    'original_source': str(ORIGINAL), 'private_source': str(PRIVATE),
    'enable_environment_variable': 'GL20_GENERATION_FRAME_WITNESS_ROOT',
    'observer_output': 'Exclusive numbered text/native-JSON files under the supplied private root; no original source/state writes.',
    'changed_paths': ['src/generation.rs', 'src/grouping.rs'], 'observer_sites': changes,
    'private_files': [{'path': str(p.relative_to(PRIVATE)), 'sha256': digest(p), 'original_sha256': digest(ORIGINAL / p.relative_to(PRIVATE))} for p in sorted(PRIVATE.rglob('*')) if p.is_file()],
    'diff_sha256': digest(HERE / 'instrumentation-only.diff'),
    'no_runtime_serde_json_extern_needed': True,
    'computation_note': 'Existing colored/skeleton canonize and comparison canonical_key calls are evaluated exactly once then reused unchanged. Diagnostic physical canonical_key is computed read-only only when observer env is set and never feeds algorithmic sorting or selection. Native to_json serialization and model name/PDG/rule/mass lookups are observer-only.',
    'crosslinks': ['assignment PRE/POST raw exact graph descriptors', 'LR pass scope plus input graph descriptors', 'retained_diagram_input_index joins native construction name', 'native prelabel to postlabel construction_name', 'postlabel source index/name/id joins grouping canonical frames and final group provenance'],
    'required_review': 'Static peer review, final source/control seal and separate build/run authorization remain necessary; no compile compatibility claim.',
}
(HERE / 'preparation.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({'status': record['status'], 'diff_sha256': record['diff_sha256'], 'preparation_sha256': digest(HERE/'preparation.json'), 'sites': len(changes)}))

"""Prepare a direct three-library generation-frame witness build, no execution."""
import copy
import hashlib
import json
from pathlib import Path
import subprocess
import tomllib

HERE = Path(__file__).resolve().parent
BASE = HERE.parent
OLD = json.loads((BASE / "current/build-plan.json").read_text())
TARGET = Path(OLD["frozen_target_read_only"])
SOURCE = Path(OLD["original_source"])
RUN = HERE / "run1"


def record(path):
    path = Path(path).resolve()
    with path.open("rb") as stream:
        checksum = hashlib.file_digest(stream, "sha256").hexdigest()
    return {"path": str(path), "sha256": checksum, "bytes": path.stat().st_size}


markers = {}
for path in (TARGET / ".fingerprint").glob("*/lib-*"):
    if path.suffix:
        continue
    text = path.read_text().strip()
    if len(text) != 16:
        continue
    try:
        number = int.from_bytes(bytes.fromhex(text), "little")
    except ValueError:
        continue
    markers.setdefault((path.name.removeprefix("lib-"), number), []).append(path)


def dependency(alias, number):
    found = markers.get((alias, number), [])
    if not found:
        found = [p for (name, value), paths in markers.items() if value == number for p in paths]
    assert len(found) == 1, (alias, len(found))
    marker = found[0]
    name = marker.name.removeprefix("lib-")
    suffix = marker.parent.name.rsplit("-", 1)[1]
    artifacts = list((TARGET / "deps").glob(f"lib{name}-{suffix}.*"))
    artifact = next((p for p in artifacts if p.suffix == ".rlib"), None)
    if artifact is None:
        artifact = next(p for p in artifacts if p.suffix == ".so")
    return {"extern_alias": alias, "actual_crate_name": name,
            "fingerprint_value_u64": number, "fingerprint_marker": record(marker),
            "fingerprint_json": record(marker.with_suffix(".json")), "artifact": record(artifact)}


gamma = copy.deepcopy(OLD["stages"][0])
api = copy.deepcopy(OLD["stages"][1])
gen_dep = next(row for row in gamma["dependencies"] if row["extern_alias"] == "feynkit_generator")
fp = json.loads(Path(gen_dep["fingerprint_json"]["path"]).read_text())
deps = [dependency(row[1], row[3]) for row in fp["deps"] if not row[1].startswith("build_script_")]
assert not any(row[1].startswith("build_script_") for row in fp["deps"])
artifacts = []
current = SOURCE.parent / "validation/gl20-native-frame-f767-readonly/current-full-runtime-save-oracle/run1/build.log"
for line in current.read_text().splitlines():
    try:
        row = json.loads(line)
    except json.JSONDecodeError:
        continue
    if row.get("reason") == "compiler-artifact" and row["target"]["name"] == "feynkit_generator":
        artifacts.append(row)
assert len(artifacts) == 1
profile = artifacts[0]["profile"]
package = tomllib.loads((SOURCE / "crates/feynkit-generator/Cargo.toml").read_text())["package"]
workspace = tomllib.loads((SOURCE / "Cargo.toml").read_text()).get("workspace", {}).get("package", {})


def field(name, default=""):
    value = package.get(name, default)
    return workspace[name] if isinstance(value, dict) and value.get("workspace") else value


metadata = "gl20_generation_frame_witness"
gen_output = str(RUN / "lib/libfeynkit_generator-gl20_generation_frame_witness.rlib")
features = json.loads(fp["features"])
declared = json.loads(fp["declared_features"])
argv = [OLD["compiler"]["path"], "--crate-name", "feynkit_generator", "--edition=" + str(field("edition", "2024")),
        "--crate-type=rlib", "--emit=link", "-C", "opt-level=" + str(profile["opt_level"]), "-C", "debuginfo=0",
        "-C", "debug-assertions=" + ("on" if profile["debug_assertions"] else "off"),
        "-C", "overflow-checks=" + ("on" if profile["overflow_checks"] else "off"),
        "-C", "embed-bitcode=no", "-C", "metadata=" + metadata, "-C", "codegen-units=256",
        "-C", "linker=" + OLD["linker"]["path"], "--check-cfg", "cfg(docsrs,test)",
        "--check-cfg", "cfg(feature, values(" + ", ".join(json.dumps(v) for v in declared) + "))",
        "-L", "dependency=" + str(RUN / "lib"), "-L", "dependency=" + str(TARGET / "deps")]
for feature in features:
    argv += ["--cfg", "feature=" + json.dumps(feature)]
for directory in OLD["native_link_search_paths"]:
    argv += ["-L", "native=" + directory]
for row in deps:
    argv += ["--extern", row["extern_alias"] + "=" + row["artifact"]["path"]]
argv += [str(HERE / "source/feynkit-generator/src/lib.rs"), "-o", gen_output]
env = gamma["environment_overlay"].copy()
env.update(CARGO_MANIFEST_DIR=str(SOURCE / "crates/feynkit-generator"),
           CARGO_MANIFEST_PATH=str(SOURCE / "crates/feynkit-generator/Cargo.toml"),
           CARGO_CRATE_NAME="feynkit_generator", CARGO_PKG_NAME="feynkit-generator", CARGO_PKG_VERSION=str(field("version")),
           CARGO_PKG_DESCRIPTION=str(field("description")), OUT_DIR=str(RUN / "out/feynkit_generator"))
version, _, prerelease = str(field("version")).partition("-")
major, minor, patch = version.split(".")
env.update(CARGO_PKG_VERSION_MAJOR=major, CARGO_PKG_VERSION_MINOR=minor,
           CARGO_PKG_VERSION_PATCH=patch, CARGO_PKG_VERSION_PRE=prerelease)
for key in list(env):
    if key.startswith("CARGO_FEATURE_"):
        env.pop(key)
for feature in features:
    env["CARGO_FEATURE_" + feature.upper().replace("-", "_")] = "1"
gen = {"stage": "feynkit_generator", "argv": argv, "cwd": str(SOURCE / "crates/feynkit-generator"),
       "environment_overlay": env, "output": gen_output, "dependencies": deps,
       "source": str(HERE / "source/feynkit-generator/src/lib.rs"), "source_input_kind": "Private observation-only copy",
       "selected_fingerprint": gen_dep["fingerprint_json"], "original_profile": profile,
       "original_features": features, "original_declared_features": declared,
       "original_manifest": record(SOURCE / "crates/feynkit-generator/Cargo.toml"),
       "directories_controller_must_create": [str(RUN / "lib"), str(RUN / "out/feynkit_generator")]}
old_prefix = str(BASE / "current/run1")
for stage in (gamma, api):
    for key in ("argv", "directories_controller_must_create"):
        stage[key] = [value.replace(old_prefix, str(RUN)) for value in stage[key]]
    stage["output"] = stage["output"].replace(old_prefix, str(RUN))
    stage["environment_overlay"] = {key: value.replace(old_prefix, str(RUN)) for key, value in stage["environment_overlay"].items()}
    for index, value in enumerate(stage["argv"]):
        if value.startswith("metadata="):
            stage["argv"][index] = "metadata=" + metadata
    for index, value in enumerate(stage["argv"]):
        if value.startswith("feynkit_generator="):
            stage["argv"][index] = "feynkit_generator=" + gen_output
    for row in stage["dependencies"]:
        if row["extern_alias"] == "feynkit_generator":
            row["original_artifact"] = row["artifact"]
            row["artifact"] = {"path": gen_output, "sha256": "TO_BE_AUTHENTICATED_AFTER_BUILD", "bytes": None}
        elif row["extern_alias"] == "gammalooprs":
            row["artifact"]["path"] = row["artifact"]["path"].replace(old_prefix, str(RUN))
plan = copy.deepcopy(OLD)
plan.update(schema="gl20.private-generation-frame-direct-rustc-plan.v1", owner="current-generation-frame-witness",
            run_root=str(RUN), private_library_directory=str(RUN / "lib"), metadata_prefix=metadata,
            stages=[gen, gamma, api], build_scope="Direct patched FeynKit-generator and relinked Gamma/API only. All other original dependencies reused; no Cargo, build scripts or workspace rebuild.")
plan["notes"] += ["Original fixture generation only; no GenerateExisting/FORM or point evaluation. Gamma observer copy reused but no runtime integrand is built/evaluated."]
with (HERE / "build-plan.json").open("x") as stream:
    json.dump(plan, stream, indent=2)
    stream.write("\n")
print(json.dumps({"plan": record(HERE / "build-plan.json"), "generator_dependencies": len(deps), "generator_profile": profile,
                  "generator_features": features, "stages": [stage["stage"] for stage in plan["stages"]]}))

"""Seal the authorized one-shot original-fixture generation-only witness."""
import ast
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
PARENT = HERE.parent
SOURCE = Path("/shared/codex-1/vakint_rustred/workspace/5l-push/vakint-gl20-current-runtime-save-oracle")
base = (PARENT / "run_trace.py").read_text()
base = base.replace('parser.add_argument("owner", choices=("current", "historical"))\n', '')
base = base.replace('OWNER = HERE / args.owner', 'OWNER = HERE')
base = base.replace('PRIMITIVES = HERE.parent / "run_decoder.py"', 'PRIMITIVES = HERE.parent.parent / "run_decoder.py"')
base = base.replace('S = json.loads((OWNER / "retained-state-authentication.json").read_text())\n', '')
begin = base.index('    frozen = json.loads((OWNER / "source-freeze.json").read_text())')
end = base.index('\n\ndef has_stage', begin)
base = base[:begin] + '''    original = json.loads(Path(M["original_full_source_freeze"]).read_text())
    for relative, expected in original["files"].items():
        assert sha(Path(original["source"]) / relative) == expected, relative
    frozen = json.loads((OWNER / "preparation.json").read_text())
    for row in frozen["private_files"]:
        assert sha(Path(frozen["private_source"]) / row["path"]) == row["sha256"], row["path"]
        assert sha(Path(frozen["original_source"]) / row["path"]) == row["original_sha256"], row["path"]
    gamma = json.loads(Path(M["gamma_source_freeze"]).read_text())
    for row in gamma["files"]:
        assert sha(Path(gamma["private_crate_source"]) / row["path"]) == row["prepared_sha256"]
        assert sha(Path(gamma["original_source"]) / "crates/gammalooprs" / row["path"]) == row["original_sha256"]
''' + base[end:]
begin = base.index('    copied = RUN / "input-copy"')
end = base.index('    compiler = subprocess.check_output', begin)
base = base[:begin] + '    env["GL20_GENERATION_FRAME_WITNESS_ROOT"] = str(RUN / "witness")\n    (RUN / "witness").mkdir()\n' + base[end:]
base = base.replace('"owner": args.owner', '"owner": "current-generation-frame-witness"')
base = base.replace('"original-point", [M["taskset"], "-c", "140", str(executable), str(copied), str(RUN / "output")]', '"generation-witness", [M["taskset"], "-c", "140", str(executable), M["original_source"], str(RUN / "new-state"), str(RUN / "output")]')
begin = base.index('        assert completion["status"] ==')
end = base.index('        code = 0', begin)
base = base[:begin] + '''        assert completion["status"] == "PASS_ONE_ORIGINAL_FIXTURE_DIAGRAM_GENERATION_FRAME_WITNESS_NOT_A_PRODUCTION_FIX"
        assert completion["RunHistory_run_calls"] == completion["diagram_generation_commands"] == 1
        for field in ("State_load_calls", "generate_existing_commands", "postprocess_commands", "event_or_integrand_evaluation_calls", "backend_activation_calls", "five_loop_campaign_calls", "runtime_integrands_constructed", "global_CFFs_constructed"):
            assert completion[field] == 0
        witnesses = sorted(path for path in (RUN / "witness").rglob("*") if path.is_file())
        assert witnesses
        for fragment in M["required_witness_name_fragments"]:
            assert any(fragment in path.name for path in witnesses), fragment
        guard()
        outputs = [path for folder in (RUN / "output", RUN / "witness") for path in folder.rglob("*") if path.is_file()]
        result.update(status="PASS_ONE_ORIGINAL_FIXTURE_GENERATION_FRAME_WITNESS_NOT_PRODUCTION_FIX",
                      witness_file_count=len(witnesses), outputs=[{"path": str(path), "sha256": sha(path), "bytes": path.stat().st_size} for path in sorted(outputs)],
                      original_sources_unchanged=True, actual_generation_witness_invocations=1,
                      actual_direct_rustc_invocations=4)
''' + base[end:]
base = base.replace('One private instrumented owner build and one original-point observation.', 'One private instrumented generator build and one original-fixture generation-only observation.')
ast.parse(base)
(HERE / "run_witness.py").write_text(base)

starter = (PARENT / "start_trace.py").read_text()
starter = starter.replace('parser.add_argument("owner", choices=("current", "historical"))\n', '')
starter = starter.replace('OWNER = HERE / args.owner', 'OWNER = HERE')
starter = starter.replace('"owner": args.owner', '"owner": "current-generation-frame-witness"')
starter = starter.replace('"state": state}))', '"state": state}))')
starter = starter.replace('for owner in ("current", "historical"):', 'for owner in ("current", "historical"):')
ast.parse(starter)
(HERE / "start_witness.py").write_text(starter)


def record(path):
    path = Path(path).resolve()
    with path.open("rb") as stream:
        checksum = hashlib.file_digest(stream, "sha256").hexdigest()
    return {"path": str(path), "sha256": checksum, "bytes": path.stat().st_size}


plan = json.loads((HERE / "build-plan.json").read_text())
api = next(stage for stage in plan["stages"] if stage["stage"] == "gammaloop_api")
gamma = next(stage for stage in plan["stages"] if stage["stage"] == "gammalooprs")
gen = next(stage for stage in plan["stages"] if stage["stage"] == "feynkit_generator")
deps = {row["extern_alias"]: row for row in api["dependencies"]}
externs = {name: deps[name]["artifact"]["path"] for name in ("serde_json", "symbolica", "color_eyre")}
externs.update(gammaloop_api=api["output"], gammalooprs=gamma["output"], feynkit_generator=gen["output"])
argv = [plan["compiler"]["path"], "--crate-name", "gl20_original_generation_frame_witness", "--edition=2024", "--crate-type=bin",
        "-C", "opt-level=0", "-C", "debuginfo=0", "-C", "linker=" + plan["linker"]["path"],
        "-L", "dependency=" + plan["private_library_directory"], "-L", "dependency=" + str(Path(plan["frozen_target_read_only"]) / "deps")]
for directory in plan["native_link_search_paths"]:
    argv += ["-L", "native=" + directory]
for name, path in externs.items():
    argv += ["--extern", name + "=" + path]
argv += [str(HERE / "driver.rs"), "-o", str(HERE / "run1/driver")]
launcher = '''#!/usr/bin/env bash
set -euo pipefail
set +x
umask 077
source /shared/codex-1/vakint_rustred/workspace/env.sh >/dev/null 2>&1
set +x
[[ -n ${SYMBOLICA_LICENSE:-} ]] || exit 2
exec /nix/store/jxyrvv4gbpnp3ap5iy7wxwl1sg4x2x88-python3-3.14.6/bin/python3.14 -I -B ''' + str(HERE / "run_witness.py") + ''' --manifest-sha256 "$1"
'''
(HERE / "launch.sh").write_text(launcher)
controls = [record(HERE / name) for name in ("prepare_build_plan.py", "prepare_controls.py", "build-plan.json", "driver.rs", "source-driver-plan.json", "preparation.json", "source-equivalence-check.json", "instrumentation-only.diff", "run_witness.py", "start_witness.py", "launch.sh")]
controls += [record(PARENT / "current/source-freeze.json"), record(PARENT.parent / "run_decoder.py"), record(SOURCE / "tests/resources/run_cards/test_epem_tth_multichannel_gl20.toml")]
manifest = {"schema": "gl20.original-fixture-generation-frame-witness.v1", "unit": "gl20-original-generation-frame-witness-20261026.service",
            "original_source": str(SOURCE), "controls": controls,
            "gamma_source_freeze": str(PARENT / "current/source-freeze.json"),
            "driver_build": {"stage": "driver", "argv": argv, "cwd": str(HERE / "run1"), "output": str(HERE / "run1/driver")},
            "taskset": "/nix/store/156fzvaz2nsq2hk0fkzn9jwk90bnzyn9-util-linux-2.42.2-bin/bin/taskset",
            "setup_seconds": 1800, "setup_CPUs": [145, 146], "generation_seconds": 600, "generation_CPU": 140,
            "memory_max_bytes": 17179869184, "maximum_direct_rustc_invocations": 4, "maximum_generation_witness_processes": 1,
            "whole_workspace_builds": 0, "retries": 0,
            "required_witness_name_fragments": ["assignment-colored-canonicalization", "global-lr-candidate-BEFORE-SORT", "global-lr-selected-AFTER-SORT", "native-pair-POSTLABELS", "group-final-physical-exposure"],
            "Root_authorization": "Root explicitly authorized one fresh original-fixture generation-only orientation witness, unchanged scientific model/settings/diagrams, CPU140/math1/16GiB/external600s once, minimal direct setup as before CPU145146/2cores/16GiB1800s. No additional permission needed after source-exact scoped commands. Capture both L/R and PRE/POST assignment frames. No production fix, generation-existing, postprocessing, event/point evaluation, gold/tolerance edits or 5L campaign.",
            "scope": "One original fixture ten-command prefix, ending in only-diagrams. Private FeynKit observations only; remove observer code/bookkeeping to restore original source byte-for-byte. The extra physical key is data-only and does not influence comparison/sorting/selection."}
with (HERE / "control-manifest.json").open("x") as stream:
    json.dump(manifest, stream, indent=2)
    stream.write("\n")
print(json.dumps({"manifest": record(HERE / "control-manifest.json"), "controller": record(HERE / "run_witness.py"), "starter": record(HERE / "start_witness.py")}))

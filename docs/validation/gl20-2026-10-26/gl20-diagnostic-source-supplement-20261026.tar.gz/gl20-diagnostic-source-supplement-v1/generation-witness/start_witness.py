"""Start one sealed owner cohort; run the two owners sequentially."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess

os.umask(0o077)
HERE = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
args = parser.parse_args()
OWNER = HERE


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


M = json.loads((OWNER / "control-manifest.json").read_text())
for row in M["controls"]:
    assert sha(row["path"]) == row["sha256"], row["path"]
assert {140, 145, 146}.issubset(os.sched_getaffinity(0))
for owner in ("current", "historical"):
    unit = f"gl20-retained-ct-trace-{owner}-20261026.service"
    state = subprocess.check_output(["systemctl", "--user", "show", unit, "--property=SubState", "--value"], text=True).strip()
    assert state != "running", "Owner cohorts must run sequentially"
assert subprocess.check_output(["systemctl", "--user", "show", M["unit"], "--property=LoadState", "--value"], text=True).strip() == "not-found"
overlap = []
for proc in Path("/proc").iterdir():
    if not proc.name.isdigit() or int(proc.name) == os.getpid():
        continue
    try:
        cpus = os.sched_getaffinity(int(proc.name))
        if len(cpus) <= 16 and cpus.intersection({140, 145, 146}) and (proc / "cmdline").read_bytes():
            overlap.append({"pid": int(proc.name), "comm": (proc / "comm").read_text().strip(), "affinity": sorted(cpus)})
    except (FileNotFoundError, ProcessLookupError, PermissionError):
        pass
assert not overlap, overlap
available = next(row for row in Path("/proc/meminfo").read_text().splitlines() if row.startswith("MemAvailable:"))
assert int(available.split()[1]) * 1024 >= 34359738368
RUN = OWNER / "run1"
RUN.mkdir(mode=0o700)
(RUN / "supervisor.log").touch(mode=0o600, exist_ok=False)
checksum = sha(OWNER / "control-manifest.json")
(RUN / "request.json").write_text(json.dumps({"manifest_sha256": checksum, "owner": "current-generation-frame-witness", "unit": M["unit"], "MemAvailable": available,
    "setup_seconds": 1800, "point_seconds": 600, "memory_max_bytes": 17179869184, "bounded_overlap": overlap, "retries": 0}, indent=2) + "\n")
argv = ["systemd-run", "--user", "--unit=" + M["unit"], "--property=Type=exec", "--property=Restart=no", "--property=RemainAfterExit=yes",
        "--property=KillMode=control-group", "--property=CPUAffinity=140 145 146", "--property=AllowedCPUs=140,145,146", "--property=CPUQuota=200%",
        "--property=MemoryAccounting=yes", "--property=MemoryMax=17179869184", "--property=RuntimeMaxSec=2460", "--property=TimeoutStopSec=10",
        "--property=UMask=0077", "--property=WorkingDirectory=" + str(OWNER), "--property=StandardOutput=append:" + str(RUN / "supervisor.log"),
        "--property=StandardError=append:" + str(RUN / "supervisor.log"), "env", "-u", "BASH_ENV", "-u", "ENV", "bash", "--noprofile", "--norc",
        str(OWNER / "launch.sh"), checksum]
result = subprocess.run(argv, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
(RUN / "submit.log").write_text(result.stdout)
assert result.returncode == 0, "Submission failed; no retry"
state = subprocess.check_output(["systemctl", "--user", "show", M["unit"], "--property=ActiveState,SubState,MainPID,InvocationID,CPUAffinity,ControlGroup"], text=True)
(RUN / "initial-unit-state.txt").write_text(state)
print(json.dumps({"status": "SUBMITTED_OWNER_SETUP_NOT_POINT_PASS", "owner": "current-generation-frame-witness", "unit": M["unit"], "manifest_sha256": checksum, "state": state}))

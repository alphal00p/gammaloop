#!/usr/bin/env python3
"""Parse retained witness records; replay recorded index maps only, never canonize."""
import argparse
import copy
import hashlib
import json
import re
from pathlib import Path

GEN = Path(__file__).resolve().parents[1]
BASE = GEN.parents[2]
LEGACY = BASE / "historical-generation-proposal/prepared-source-and-driver/legacy-license-replay-20261026/run1/capture-data/pre-collapse-members"


class RustDebug:
    """Small non-executing parser for the captured derived-Debug data grammar."""
    def __init__(self, text, offset=0):
        self.text, self.pos = text, offset

    def space(self):
        while self.pos < len(self.text) and self.text[self.pos].isspace():
            self.pos += 1

    def take(self, token):
        self.space()
        if not self.text.startswith(token, self.pos):
            raise ValueError(f"Expected {token!r} at {self.pos}")
        self.pos += len(token)

    def sequence(self, close):
        values = []
        self.space()
        while not self.text.startswith(close, self.pos):
            values.append(self.value())
            self.space()
            if self.text.startswith(",", self.pos):
                self.pos += 1
                self.space()
            elif not self.text.startswith(close, self.pos):
                raise ValueError(f"Sequence separator at {self.pos}")
        self.take(close)
        return values

    def value(self):
        self.space()
        ch = self.text[self.pos]
        if ch == '"':
            start = self.pos
            self.pos += 1
            escaped = False
            while True:
                c = self.text[self.pos]
                self.pos += 1
                if escaped:
                    escaped = False
                elif c == "\\":
                    escaped = True
                elif c == '"':
                    break
            raw = self.text[start:self.pos]
            raw = re.sub(r"\\u\{([0-9a-fA-F]+)\}", lambda m: json.dumps(chr(int(m[1], 16)))[1:-1], raw)
            raw = raw.replace(r"\0", r"\u0000")
            return json.loads(raw)
        if ch == "[":
            self.pos += 1
            return self.sequence("]")
        if ch == "(":
            self.pos += 1
            return tuple(self.sequence(")"))
        if ch == "{":
            self.pos += 1
            result = {}
            set_values = []
            self.space()
            while not self.text.startswith("}", self.pos):
                key = self.value()
                self.space()
                if self.text.startswith(":", self.pos):
                    if set_values:
                        raise ValueError("Mixed mapping/set Debug data")
                    if isinstance(key, dict) and set(key) == {"__variant__"}:
                        key = key["__variant__"]
                    self.take(":")
                    result[key] = self.value()
                else:
                    if result:
                        raise ValueError("Mixed mapping/set Debug data")
                    set_values.append(key)
                self.space()
                if self.text.startswith(",", self.pos):
                    self.pos += 1
                    self.space()
                elif not self.text.startswith("}", self.pos):
                    raise ValueError(f"Mapping separator at {self.pos}")
            self.take("}")
            return {"__set__": set_values} if set_values else result
        number = re.match(r"-?\d+", self.text[self.pos:])
        if number:
            self.pos += len(number[0])
            return int(number[0])
        ident = re.match(r"[A-Za-z_][A-Za-z0-9_]*(?:::[A-Za-z_][A-Za-z0-9_]*)*", self.text[self.pos:])
        if not ident:
            raise ValueError(f"Unsupported Debug token at {self.pos}: {self.text[self.pos:self.pos+50]!r}")
        name = ident[0]
        self.pos += len(name)
        if name in ("true", "false", "None"):
            return {"true": True, "false": False, "None": None}[name]
        self.space()
        if self.text.startswith("(", self.pos):
            self.pos += 1
            args = self.sequence(")")
            return args[0] if name == "Some" and len(args) == 1 else {"__variant__": name, "args": args}
        if self.text.startswith("{", self.pos):
            fields = self.value()
            return {"__type__": name, **fields}
        return {"__variant__": name}


def field(text, key):
    found = re.search(r"(?m)^" + re.escape(key) + "=", text)
    if not found:
        raise ValueError(f"Missing captured field {key!r}")
    return RustDebug(text, found.end()).value()


def section(text, start, end=None):
    text = text.split(start + "\n", 1)[1]
    return text.split(end + "\n", 1)[0] if end else text


def graph_from(text):
    return field(text, "raw_native_graph_debug")


def signature(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def file_record(path):
    with path.open("rb") as stream:
        sha = hashlib.file_digest(stream, "sha256").hexdigest()
    return {"path": str(path), "sha256": sha}


def variant(value, name):
    return isinstance(value, dict) and value.get("__variant__") == name


def unwrap_id(value):
    return value["args"][0]


def remap_pairs(value):
    return {int(k): int(v) for k, v in value.items()}


def raw_key(graph):
    # Descriptor equality preserves node/edge/incidence stored order; no canonicalization.
    return signature(graph)


def replay_selected(source, selected, particles):
    """Replay generation.rs4190-4269's captured map; no graph/key search."""
    mapping = remap_pairs(selected["remapping"])
    inverse = {v: k for k, v in mapping.items()}
    vertex_map = selected["vertex_map"]
    count = len(source["nodes"])
    assert sorted(vertex_map) == list(range(count))
    canonical_to_input = [0] * count
    for old_index, canonical in enumerate(vertex_map):
        canonical_to_input[canonical] = inverse.get(old_index, old_index)
    input_to_canonical = {old: new for new, old in enumerate(canonical_to_input)}
    nodes = []
    for old in canonical_to_input:
        data = copy.deepcopy(source["nodes"][mapping.get(old, old)]["data"])
        nodes.append({"__type__": "Node", "data": data, "edges": [], "valence": 0})
    edges = []
    for edge in source["edges"]:
        left, right = edge["vertices"]
        external = variant(source["nodes"][left]["data"], "External") or variant(source["nodes"][right]["data"], "External")
        flipped = variant(source["nodes"][right]["data"], "External") or (not external and input_to_canonical[left] > input_to_canonical[right])
        vertices = (input_to_canonical[right], input_to_canonical[left]) if flipped else (input_to_canonical[left], input_to_canonical[right])
        data = copy.deepcopy(edge["data"])
        particle_id = unwrap_id(data["particle"])
        if edge["directed"] and flipped:
            particle_id = particles[particle_id]["anti_id"]
        p = particles[particle_id]
        neutral_adjoint_ghost = p.get("ghost_number", 0) != 0 and p["color"] == 8 and p["charge"] in (0, "0", "0/1")
        if edge["directed"] and selected["swapped"] and not neutral_adjoint_ghost:
            particle_id = p["anti_id"]
        data["particle"]["args"][0] = particle_id
        edges.append((vertices, edge["directed"], data, particles[particle_id]["pdg_code"]))
    edges.sort(key=lambda row: (row[0][0], row[0][1], row[3]))
    graph = {"__type__": "Graph", "nodes": nodes, "edges": []}
    for vertices, directed, data, _ in edges:
        source_id, target_id = vertices
        stored = tuple(sorted(vertices)) if not directed else vertices
        index = len(graph["edges"])
        graph["edges"].append({"__type__": "Edge", "vertices": stored, "directed": directed, "data": data})
        nodes[source_id]["edges"].append(index)
        nodes[source_id]["valence"] += 1
        nodes[target_id]["valence"] += 1
        if source_id != target_id:
            nodes[target_id]["edges"].append(index)
    return graph


def native_summary(value, particles, rules):
    def endpoints(row):
        return row[0]
    edge_rows = [{"edge": i, **endpoints(row), "pdg": particles[row[1]["particle"]]["pdg_code"],
                  "particle": particles[row[1]["particle"]]["name"],
                  "orientation": row[1].get("orientation"), "external": row[1].get("external")}
                 for i, row in enumerate(value["edges"])]
    incoming = [row for row in edge_rows if row["external"] and row["external"]["state"] == "incoming"]
    anchors = []
    for row in incoming:
        target = row.get("target")
        photons = [e["edge"] for e in edge_rows if e["pdg"] == 22 and target in (e.get("source"), e.get("target"))]
        anchors.append({"external_edge": row["edge"], "external_index": row["external"]["index"],
                        "native_carrier_target": target, "incident_photon_edges": photons})
    return {"name": value["name"], "id": value["id"], "edges": edge_rows, "incoming_target_anchors": anchors,
            "vertex_rule_names": [None if v.get("interaction") is None else rules[v["interaction"]]["name"] for v in value["vertices"]]}


def legacy_dot(path):
    text = path.read_text()
    edges = {}
    for line in text.splitlines():
        m = re.match(r'\s*(\d+):(\d+)\s*->\s*(\d+):(\d+)\s*\[id=(\d+).*particle="([^"]+)"', line)
        if m:
            edges[int(m[5])] = {"source": int(m[1]), "source_hedge": int(m[2]),
                               "target": int(m[3]), "target_hedge": int(m[4]), "particle": m[6]}
    return {"input": file_record(path), "edges": edges,
            "incoming_gamma_anchor": {"hedges": [0, 1], "node": edges[0]["target"],
                                     "photon_edges": [i for i, e in edges.items() if e["particle"] == "a" and edges[0]["target"] in (e["source"], e["target"])]},
            "limit": "DOT is a compact post-sewing anchor/flow witness, not the full pre-sewing legacy Graph Ord key."}


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("--witness", type=Path, default=GEN / "run1/witness")
    cli.add_argument("--model", type=Path, default=GEN / "run1/output/generated-model-by-name.json")
    cli.add_argument("--output", type=Path, default=GEN / "analysis/generation-frame-map.json")
    cli.add_argument("--target-name")
    cli.add_argument("--target-group", type=int)
    cli.add_argument("--no-replay-recorded-maps", action="store_true")
    args = cli.parse_args()
    assert args.witness.is_dir() and args.model.is_file(), "Consume completed witness only"
    completion_path = args.witness.parent / "completion.json"
    completion = json.loads(completion_path.read_text())
    assert completion.get("returncode") == 0 and completion.get("actual_generation_witness_invocations") == 1
    assert completion.get("original_sources_unchanged") is True
    model = json.loads(args.model.read_text())
    particles = copy.deepcopy(model["particles"])
    names = {p["name"]: i for i, p in enumerate(particles)}
    for p in particles:
        p["anti_id"] = names[p["antiname"]]
    rules = model["vertex_rules"]
    paths = sorted(args.witness.glob("*.txt"))
    parse_errors, assignments, scopes, normalizations, posts, groups = [], [], {}, {}, [], []
    prelabels = {}
    for path in paths:
        text = path.read_text()
        try:
            if "-assignment-colored-canonicalization." in path.name:
                pre = graph_from(section(text, "PRE_COLORED_FRAME", "POST_COLORED_FRAME"))
                post = graph_from(section(text, "POST_COLORED_FRAME"))
                assignments.append({"file": str(path), "assignment_count": field(text, "assignment_count"),
                                    "pre_signature": raw_key(pre), "post_signature": raw_key(post),
                                    "pre_equals_post": pre == post, "vertex_map": field(text, "colored_vertex_map")})
            elif "-global-lr-candidate-BEFORE-SORT." in path.name:
                scope = scopes.setdefault(field(text, "scope"), {"candidates": []})
                graph = graph_from(section(text, "PRE_SKELETON_INPUT_FRAME"))
                scope["input_graph"] = graph
                scope["input_signature"] = raw_key(graph)
                scope["candidates"].append({"file": str(path), "swapped": field(text, "left_right_swapped"),
                    "include_external_remapping": field(text, "include_external_remapping"),
                    "use_sewn_external_colors": field(text, "use_sewn_external_colors"),
                    "remapping": field(text, "external_remapping"),
                    "canonical_nodes": field(text, "canonical_reduced_nodes"),
                    "canonical_edges": field(text, "canonical_reduced_edges"),
                    "vertex_map": field(text, "canonical_vertex_map")})
            elif "-global-lr-selected-AFTER-SORT." in path.name:
                scopes.setdefault(field(text, "scope"), {"candidates": []})["selected"] = {
                    "file": str(path), "swapped": field(text, "selected_left_right_swapped"),
                    "remapping": field(text, "selected_remapping"), "vertex_map": field(text, "selected_vertex_map")}
            elif "-raw-normalized-comparison-pair." in path.name:
                index = field(text, "retained_diagram_input_index")
                before = graph_from(section(text, "NORMALIZATION_INPUT_COMPARISON", "NORMALIZATION_OUTPUT_PHYSICAL"))
                after = graph_from(section(text, "NORMALIZATION_OUTPUT_PHYSICAL"))
                normalizations[index] = {"file": str(path), "comparison_signature": raw_key(before),
                    "physical_signature": raw_key(after), "comparison_graph": before, "physical_graph": after,
                    "reversed_edges": field(text, "reversed_edges")}
            elif "-native-pair-PRELABELS." in path.name:
                prelabels[field(text, "construction_name")] = {"file": str(path)}
            elif "-native-pair-POSTLABELS." in path.name:
                root = str(path)[:-4]
                physical = json.loads(Path(root + ".physical.json").read_text())
                posts.append({"file": str(path), "source_diagram_index": field(text, "source_diagram_index"),
                    "source_name": field(text, "final_source_name"),
                    "construction_name": field(text, "construction_name"),
                    "physical_json": root + ".physical.json", "comparison_json": root + ".comparison.json",
                    "summary": native_summary(physical, particles, rules)})
            elif "-group-final-physical-exposure." in path.name:
                root = str(path)[:-4]
                physical = json.loads(Path(root + ".final-physical.json").read_text())
                group = field(text, "group_before_member_provenance_update")
                groups.append({"file": str(path), "group_index": field(text, "output_group_index"),
                    "selected_source_diagram": field(text, "selected_source_diagram"),
                    "members": group["members"], "final_physical_json": root + ".final-physical.json",
                    "final_summary": native_summary(physical, particles, rules)})
        except Exception as error:
            parse_errors.append({"file": str(path), "error": str(error)})
    assignment_by_post = {}
    for row in assignments:
        assignment_by_post.setdefault(row["post_signature"], []).append(row)
    scope_by_output = {}
    for sid, scope in scopes.items():
        candidates = scope["candidates"]
        if candidates:
            scope["candidate_keys_equal"] = len(candidates) == 2 and all(
                candidates[0][key] == candidates[1][key] for key in ("canonical_nodes", "canonical_edges"))
        scope["assignment_exact_post_matches"] = assignment_by_post.get(scope.get("input_signature"), [])
        if "selected" in scope and "input_graph" in scope and not args.no_replay_recorded_maps:
            try:
                output = replay_selected(scope["input_graph"], scope["selected"], particles)
                scope["replayed_output_signature"] = raw_key(output)
                scope_by_output.setdefault(raw_key(output), []).append(sid)
            except Exception as error:
                scope["replay_error"] = str(error)
    # The source_diagram field indexes the filtered comparison_diagrams vector.
    posts.sort(key=lambda row: row["source_diagram_index"])
    post_by_source = {}
    for filtered_index, post in enumerate(posts):
        post["filtered_source_index"] = filtered_index
        post_by_source[filtered_index] = post
    chosen = [g for g in groups if (args.target_name is None or g["final_summary"]["name"] == args.target_name)
              and (args.target_group is None or g["group_index"] == args.target_group)]

    def scope_report(sid, depth=0):
        scope = scopes[sid]
        result = {key: value for key, value in scope.items() if key != "input_graph"}
        result["scope_id"] = sid
        parents = scope_by_output.get(scope.get("input_signature"), [])
        result["exact_replayed_parent_scopes"] = parents
        # No forced link: multiple exact descriptors remain explicitly ambiguous.
        result["link_status"] = "EXACT_UNIQUE" if len(parents) == 1 else "UNLINKED" if not parents else "AMBIGUOUS_EXACT"
        if depth < 1:
            result["parent_scope_details"] = [scope_report(parent, depth + 1) for parent in parents if parent != sid]
        return result

    targets = []
    for group in chosen:
        target = copy.deepcopy(group)
        target["member_chains"] = []
        for member in group["members"]:
            source = member["source_diagram"]
            chain = {"source_index": source, "source_name": member["source_name"]}
            post = post_by_source.get(source)
            if post is None:
                chain["status"] = "UNLINKED_NO_POSTLABEL_SOURCE"
            else:
                chain["postlabel"] = post
                construction = post["construction_name"]
                match = re.search(r"(\d+)$", construction)
                normalized = normalizations.get(int(match[1])) if match else None
                if normalized is None:
                    chain["status"] = "UNLINKED_NO_RAW_NORMALIZATION"
                else:
                    chain["raw_normalization"] = {key: val for key, val in normalized.items() if not key.endswith("_graph")}
                    joins = scope_by_output.get(normalized["comparison_signature"], [])
                    chain["last_lr_scope_candidates"] = joins
                    chain["status"] = "EXACT_UNIQUE_CHAIN" if len(joins) == 1 else "UNLINKED_LR_OUTPUT" if not joins else "AMBIGUOUS_EXACT_LR_OUTPUT"
                    chain["lr_scope_details"] = [scope_report(sid) for sid in joins]
                    chain["prelabel_pair"] = prelabels.get(construction)
            target["member_chains"].append(chain)
        targets.append(target)
    result = {
        "schema": "gl20.generation-frame-observed-map.v1",
        "status": "PARSED_WITH_ERRORS" if parse_errors else "PARSED_OBSERVED_FRAMES",
        "scope": "Stored JSON/Rust-Debug parsing, equality/hashing and replay of already-captured vertex/endpoint/particle permutations only. No canonize/canonical_key computation, generation, state loading or numerical/symbolic evaluation.",
        "model": file_record(args.model), "completion": file_record(completion_path), "witness_root": str(args.witness),
        "counts": {"text_files": len(paths), "assignments": len(assignments), "singleton_assignment_records": sum(a["assignment_count"] == 1 for a in assignments),
                   "lr_scopes": len(scopes), "raw_normalizations": len(normalizations), "postlabel_sources": len(posts), "groups": len(groups), "selected_groups": len(chosen)},
        "parse_errors": parse_errors,
        "group_inventory": [{"group_index": g["group_index"], "name": g["final_summary"]["name"],
                             "selected_source_diagram": g["selected_source_diagram"],
                             "member_source_names": [m["source_name"] for m in g["members"]]} for g in groups],
        "targets": targets,
        "legacy_anchors": [legacy_dot(LEGACY / f"member-{member}.dot") for member in (20, 21)],
        "interpretation_guards": [
            "Singleton assignment_count is original Cartesian assignment count, not post-canonical grouped length.",
            "Both owners run two reduced-skeleton passes; include_external_remapping distinguishes the first from fixed-assignment second pass.",
            "Anchor-photon8 alone does not establish legacy full-frame identity. Exact colored node/edge/incidence descriptors are needed.",
            "Only exact observed descriptor equality accepts a replayed link; ambiguous or missing links remain explicit.",
            "Recorded map replay does not reproduce repair_cp_interaction_rules; if it changes a rule, exact join can fail and must stay UNLINKED rather than guessed.",
            "No causal fix or canonical_key sorting shortcut is inferred from this report."
        ],
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("x") as stream:
        json.dump(result, stream, indent=2)
        stream.write("\n")
    print(json.dumps({"status": result["status"], "output": str(args.output), "counts": result["counts"],
                      "group_inventory": result["group_inventory"]}))


if __name__ == "__main__":
    main()


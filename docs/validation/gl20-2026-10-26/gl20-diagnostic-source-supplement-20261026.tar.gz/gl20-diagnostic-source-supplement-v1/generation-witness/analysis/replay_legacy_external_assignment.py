"""Literal legacy sewn-slot metadata replay on already captured current graphs."""
import copy
import importlib.util
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location("frame_parser", HERE / "parse_generation_frames.py")
P = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(P)


def external_tag(node):
    data = node["data"]
    return data["args"][0]["index"] + 1 if P.variant(data, "External") else 0


def replay(graph, particles, incoming_count):
    # Legacy1932-2090 uses1-based slots and does not reorder graph nodes/edges.
    tags = [external_tag(n) for n in graph["nodes"]]
    colors = {i + 1: -2001 - i for i in range(incoming_count)}
    colors.update({i + 1 + incoming_count: -3001 - i for i in range(incoming_count)})
    all_slots = list(range(1, 2 * incoming_count + 1))
    changes, before_rows, after_rows = [], [], []
    # All actual fixture external colors are<-2000, so steps0/2 have no action.
    assert all(colors[t] < -2000 for t in tags if t)
    for edge_id, edge in enumerate(graph["edges"]):
        source, target = edge["vertices"]
        assert tags[target] == 0 and tags[source] >= 0
        tag = tags[source]
        if tag == 0:
            continue
        pid = P.unwrap_id(edge["data"]["particle"])
        pdg = particles[pid]["pdg_code"]
        row = {"raw_edge": edge_id, "external_raw_node": source, "attachment_raw_node": target,
               "external_tag": tag, "external_index": tag - 1,
               "state": "Incoming" if tag <= incoming_count else "Outgoing",
               "signed_pdg": pdg, "particle": particles[pid]["name"]}
        before_rows.append(row)
        # Exact legacy passstep1: first INITIAL matching paired position, then FINAL.
        position = (-colors[tag]) % 1000
        if position in all_slots:
            new_tag, is_initial_match = position, True
        elif position + incoming_count in all_slots:
            new_tag, is_initial_match = position + incoming_count, False
        else:
            raise AssertionError("Legacy slot matching unreachable")
        all_slots.remove(new_tag)
        changed_role = (tag <= incoming_count) != is_initial_match
        after_pid = particles[pid]["anti_id"] if changed_role else pid
        after = {**row, "external_tag": new_tag, "external_index": new_tag - 1,
                 "state": "Incoming" if is_initial_match else "Outgoing",
                 "signed_pdg": particles[after_pid]["pdg_code"], "particle": particles[after_pid]["name"]}
        after_rows.append(after)
        changes.append({"raw_edge": edge_id, "old_tag": tag, "new_tag": new_tag,
                        "role_changed": changed_role, "pdg_conjugated": changed_role,
                        "old_pdg": pdg, "new_pdg": particles[after_pid]["pdg_code"]})
    assert not all_slots
    return {"before": before_rows, "after": after_rows, "changes": changes,
            "node_edge_order_unchanged": True, "internal_data_unchanged": True}


def anchors(rows, graph, native, particles):
    # Actual native vertex names vN directly retain raw interaction-node identity.
    mapping = {int(v["name"][1:]): i for i,v in enumerate(native["vertices"])}
    answer = []
    for row in rows:
        if row["state"] != "Incoming":
            continue
        raw_node = row["attachment_raw_node"]
        photons = []
        for eid,edge in enumerate(graph["edges"]):
            if particles[P.unwrap_id(edge["data"]["particle"])]["pdg_code"] == 22 and raw_node in edge["vertices"]:
                native_ends = {mapping[n] for n in edge["vertices"]}
                matches = [i for i,(ends,data) in enumerate(native["edges"])
                           if particles[data["particle"]]["pdg_code"] == 22 and {ends["source"],ends["target"]} == native_ends]
                assert len(matches) == 1
                photons.append({"raw_edge": eid, "existing_native_edge": matches[0]})
        answer.append({"incoming_index": row["external_index"], "raw_attachment": raw_node,
                       "existing_native_attachment": mapping[raw_node], "photons": photons})
    return sorted(answer, key=lambda x:x["incoming_index"])


def main():
    summary_path = HERE / "ci-GL04-target-frame-summary.json"
    summary = json.loads(summary_path.read_text())
    model_path = HERE.parent / "run1/output/generated-model-by-name.json"
    particles = copy.deepcopy(json.loads(model_path.read_text())["particles"])
    names = {p["name"]: i for i,p in enumerate(particles)}
    for p in particles:
        p["anti_id"] = names[p["antiname"]]
    report_path = HERE / "generation-frame-map-ci-GL04.json"
    native_path = Path(json.loads(report_path.read_text())["targets"][0]["final_physical_json"])
    native = json.loads(native_path.read_text())
    results = []
    for chain in summary["chains"]:
        # The single fixed-pass candidate contains the observed global-pass output.
        selected = Path(chain["second_pass"]["selected_file"])
        candidate_path = next(selected.parent.glob(f"{int(selected.name.split('-')[0])-1:07}-global-lr-candidate-BEFORE-SORT.txt"))
        fixed_input = P.graph_from(P.section(candidate_path.read_text(), "PRE_SKELETON_INPUT_FRAME"))
        normalization_path = Path(chain["normalization_file"])
        fixed_output = P.graph_from(P.section(normalization_path.read_text(), "NORMALIZATION_INPUT_COMPARISON", "NORMALIZATION_OUTPUT_PHYSICAL"))
        for boundary, graph, path in [("observed_global_pass_output_before_current_fixed_pass",fixed_input,candidate_path),
                                      ("observed_current_fixed_pass_output_before_flow_normalization",fixed_output,normalization_path)]:
            change = replay(graph, particles, 2)
            results.append({"member": chain["source_name"], "boundary": boundary, "captured_input": P.file_record(path),
                            **change, "before_anchors": anchors(change["before"],graph,native,particles),
                            "after_anchors_in_existing_native_coordinates": anchors(change["after"],graph,native,particles)})
    out = {"schema":"gl20.literal-legacy-external-slot-replay.v1", "status":"PASS_METADATA_REPLAY_SHOWS_OPPOSITE_INCOMING_ATTACHMENT_NOT_FULL_PIPELINE_FIX",
           "scope":"Literal legacy passstep1 on independently captured current boundary descriptors only; no canon, generation, numerical or symbolic evaluation.",
           "source_summary":P.file_record(summary_path), "model":P.file_record(model_path), "native_coordinates":P.file_record(native_path),
           "legacy_source":"crates/gammalooprs/src/feyngen/diagram_generator.rs1932-2090; invoked2391 after each canonicalize_edge_and_vertex_ordering pass",
           "results":results,
           "legacy_dot_anchor":{"members":[20,21],"incoming_attachment":7,"incident_photon_edge":8},
           "limits":["Post-replay attachment agrees with legacy DOT anchor only; full precolored frame identity is not claimed.",
                     "Each current boundary replay is independent. In the full legacy pipeline, normalizing the first-pass output changes the second-pass input and requires its actual canonicalization; this replay does not recompute that pass.",
                     "Existing native coordinates are used only as a named vertex/photon lookup. No new sewn graph, cuts, projectors, routing, numerator, evaluator or integrand was constructed.",
                     "Current and legacy grouping defaults both differentiate masses only; singleton restoration already produced a baseline-identical point and is not a fix."]}
    path = HERE / "legacy-external-assignment-replay.json"
    with path.open('x') as stream:
        json.dump(out,stream,indent=2);stream.write('\n')
    print(json.dumps({"output":str(path),"status":out["status"],"sha256":P.file_record(path)["sha256"],
                      "anchors":[{"member":r["member"],"boundary":r["boundary"],"before":r["before_anchors"],"after":r["after_anchors_in_existing_native_coordinates"],"changes":r["changes"]} for r in results]}))


if __name__ == '__main__':
    main()

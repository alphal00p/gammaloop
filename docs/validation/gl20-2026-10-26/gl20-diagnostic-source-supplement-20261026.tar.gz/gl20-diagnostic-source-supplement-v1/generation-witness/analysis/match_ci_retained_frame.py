#!/usr/bin/env python3
"""Replay the source's finite topology predicate on retained native JSON only."""
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
GEN = HERE.parent
OUT = GEN.parents[1]
BASE = GEN.parents[2]
CLASSES = ["V_141", "V_134", "V_137", "V_98"]
EXPECTED = sorted([(6,7,11),(6,7,11),(0,1,25),(0,3,6),(0,5,6),(1,2,6),(1,5,6),(2,4,6),(2,7,22),(3,4,6),(3,6,22),(4,5,21)])


def record(path):
    return {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def native_descriptor(graph, model):
    return {
        "vertices": [{"name": v["name"], "rule": None if v["interaction"] is None else model["vertex_rules"][v["interaction"]]["name"]} for v in graph["vertices"]],
        "edges": [{"endpoints": row[0], "particle": model["particles"][row[1]["particle"]]["name"],
                   "pdg": model["particles"][row[1]["particle"]]["pdg_code"],
                   **{k: row[1].get(k) for k in ("directed", "orientation", "external", "source_slot", "target_slot")}}
                  for row in graph["edges"]],
        "half_edge_order": graph["half_edge_order"],
    }


def predicate(graph, model):
    groups = [[i for i,v in enumerate(graph["vertices"]) if v["interaction"] is not None and model["vertex_rules"][v["interaction"]]["name"] == rule] for rule in CLASSES]
    if any(len(g) != 2 for g in groups):
        return []
    witnesses = []
    for swaps in range(16):
        node_map = {}
        for cls, nodes in enumerate(groups):
            swap = (swaps >> cls) & 1
            node_map[nodes[swap]], node_map[nodes[1-swap]] = cls*2, cls*2+1
        actual = []
        for endpoints, edge in graph["edges"]:
            if endpoints["source"] not in node_map or endpoints["target"] not in node_map:
                break
            a,b = node_map[endpoints["source"]],node_map[endpoints["target"]]
            actual.append((min(a,b),max(a,b),abs(model["particles"][edge["particle"]]["pdg_code"])))
        else:
            if sorted(actual) == EXPECTED:
                witnesses.append({"swap_bits": swaps, "node_map": node_map})
    return witnesses


def main():
    model_path = GEN / "run1/output/generated-model-by-name.json"
    model = json.loads(model_path.read_text())
    report_path = HERE / "generation-frame-map-ci-GL04.json"
    report = json.loads(report_path.read_text())
    target_path = Path(report["targets"][0]["final_physical_json"])
    target = json.loads(target_path.read_text())
    retained_path = BASE / "future-runtime-run1/private-owner-output/loaded-GL04.json"
    retained = json.loads(retained_path.read_text())
    runtime_path = OUT / "api-adapted-v2/run1/export/process-0-cross-section.json"
    runtime = json.loads(runtime_path.read_text())["supergraphs"][0]["graph"]
    fresh_descriptor = native_descriptor(target, model)
    retained_descriptor = native_descriptor(retained, model)
    runtime_descriptor = {
        "vertices": [{"name": n["name"], "rule": n["rule"]} for n in runtime["nodes"]],
        "edges": [{"endpoints": {"source": e["endpoints"]["source_node"], "target": e["endpoints"]["sink_node"]},
                   "particle": e["particle"]["particle"]["name"], "pdg": e["particle"]["particle"]["pdg"],
                   "orientation": e["orientation"]} for e in runtime["edges"]],
    }
    comparable_native = {"vertices": fresh_descriptor["vertices"], "edges": [{k:v for k,v in e.items() if k in ("endpoints","particle","pdg","orientation")} for e in fresh_descriptor["edges"]]}
    matches = []
    for path in sorted((GEN / "run1/witness").glob("*-group-final-physical-exposure.final-physical.json")):
        graph = json.loads(path.read_text())
        choices = predicate(graph, model)
        if choices:
            matches.append({"name": graph["name"], "file": str(path), "predicate_witnesses": choices})
    output = {
        "schema": "gl20.ci-topology-predicate-retained-frame-match.v1",
        "scope": "Exact source finite16-choice colored undirected connectivity predicate and equality of resolved ordered frame descriptors; no canonicalization, state load, generation or evaluation.",
        "source_predicate_path": str(BASE.parents[1] / "vakint-gl20-current-runtime-save-oracle/tests/tests/test_evaluation_api.rs"),
        "vertex_classes": CLASSES, "expected_edges": EXPECTED,
        "predicate_matches_all_final_groups": matches,
        "target": record(target_path), "retained_native": record(retained_path), "retained_runtime": record(runtime_path), "model": record(model_path),
        "fresh_retained_native_full_ordered_descriptor_equal": fresh_descriptor == retained_descriptor,
        "fresh_retained_runtime_ordered_nodes_and_physical_edges_equal": comparable_native == runtime_descriptor,
        "fresh_retained_native_id_equal": target["id"] == retained["id"],
        "fresh_descriptor": fresh_descriptor, "retained_native_descriptor": retained_descriptor,
        "runtime_descriptor": runtime_descriptor,
        "limits": "Descriptor equality includes ordered named vertex rules, signed PDG/name, edge endpoint order, orientation, native direction/external/slots and native half-edge order. Symbolic numerators, parameters, routing, factors and group IDs are outside this structural claim."
    }
    destination = HERE / "ci-GL04-retained-frame-match.json"
    with destination.open("x") as stream:
        json.dump(output, stream, indent=2)
        stream.write("\n")
    print(json.dumps({"output": str(destination), "predicate_matches": [m["name"] for m in matches], "native_equal": output["fresh_retained_native_full_ordered_descriptor_equal"], "runtime_equal": output["fresh_retained_runtime_ordered_nodes_and_physical_edges_equal"], "id_equal": output["fresh_retained_native_id_equal"]}))


if __name__ == "__main__":
    main()

"""Bounded exact lookup/composition of retained maps; never canonize a new graph."""
import copy
import importlib.util
import json
import resource
import time
from pathlib import Path

resource.setrlimit(resource.RLIMIT_AS,(2*1024**3,2*1024**3))
resource.setrlimit(resource.RLIMIT_CPU,(60,60))
HERE=Path(__file__).resolve().parent
SPEC=importlib.util.spec_from_file_location('observed_parser',HERE/'parse_generation_frames.py')
P=importlib.util.module_from_spec(SPEC);SPEC.loader.exec_module(P)
REPLAY_SPEC=importlib.util.spec_from_file_location('legacy_external_replay',HERE/'replay_legacy_external_assignment.py')
R=importlib.util.module_from_spec(REPLAY_SPEC);REPLAY_SPEC.loader.exec_module(R)


def module_name(value):
    return value['__variant__']


def external_rows(graph,particles):
    rows=[]
    for i,node in enumerate(graph['nodes']):
        if P.variant(node['data'],'External'):
            ext=node['data']['args'][0];pid=P.unwrap_id(ext['particle'])
            rows.append([i,ext['index'],module_name(ext['state']),pid,particles[pid]['name'],particles[pid]['pdg_code']])
    return rows


def apply_legacy_assignment(graph,particles):
    change=R.replay(graph,particles,2)
    new=copy.deepcopy(graph)
    for row in change['changes']:
        edge=new['edges'][row['raw_edge']]
        ext=new['nodes'][edge['vertices'][0]]['data']['args'][0]
        ext['index']=row['new_tag']-1
        ext['state']={'__variant__':'Incoming' if row['new_tag']<=2 else 'Outgoing'}
        if row['pdg_conjugated']:
            pid=P.unwrap_id(edge['data']['particle'])
            edge['data']['particle']['args'][0]=particles[pid]['anti_id']
    return new,change


def main():
    start=time.monotonic()
    summary_path=HERE/'ci-GL04-target-frame-summary.json'
    summary=json.loads(summary_path.read_text())
    model_path=HERE.parent/'run1/output/generated-model-by-name.json'
    particles=json.loads(model_path.read_text())['particles'];names={p['name']:i for i,p in enumerate(particles)}
    for p in particles:p['anti_id']=names[p['antiname']]
    targets=[]
    for chain in summary['chains']:
        selected=Path(chain['second_pass']['selected_file']);seq=int(selected.name.split('-')[0])-1
        path=next(selected.parent.glob(f'{seq:07}-global-lr-candidate-BEFORE-SORT.txt'))
        graph=P.graph_from(P.section(path.read_text(),'PRE_SKELETON_INPUT_FRAME'))
        graph,changes=apply_legacy_assignment(graph,particles)
        targets.append({'member':chain['source_name'],'input':P.file_record(path),'graph':graph,
                        'signature':P.raw_key(graph),'external_rows':external_rows(graph,particles),'literal_changes':changes['changes'],
                        'external_filter_matching_records':[],'exact_raw_graph_matches':[]})
    witness=HERE.parent/'run1/witness';paths=sorted(witness.glob('*-global-lr-candidate-BEFORE-SORT.txt'))
    scopes=set();patterns={};raw_graph_parses=0;flags={}
    for path in paths:
        text=path.read_text();scope=P.field(text,'scope');scopes.add(scope)
        rows=P.field(P.section(text,'PRE_SKELETON_INPUT_FRAME'),'external_rows')
        # Convert parser tuple rows to lists solely for storage/type-neutral comparison.
        rows=[list(row) for row in rows]
        pattern=tuple((row[0],row[1],row[2],row[3]) for row in rows)
        patterns[pattern]=patterns.get(pattern,0)+1
        flags[scope]=P.field(text,'include_external_remapping')
        selected_targets=[target for target in targets if rows==target['external_rows']]
        if not selected_targets:continue
        graph=P.graph_from(P.section(text,'PRE_SKELETON_INPUT_FRAME'));raw_graph_parses+=1
        for target in selected_targets:
            target['external_filter_matching_records'].append({'path':str(path),'scope':scope})
            if graph==target['graph']:
                target['exact_raw_graph_matches'].append({'path':str(path),'scope':scope,'include_external_remapping':flags[scope]})
    # A full raw descriptor equality implies equality of the observer's derived
    # external rows. Exhaustively excluding that necessary condition proves no
    # exact stored-map input exists; no guessed transport is permitted.
    any_match=any(target['exact_raw_graph_matches'] for target in targets)
    status='EXACT_FIRST_STEP_MATCHES_FOUND_FURTHER_COMPOSITION_REQUIRED' if any_match else 'UNPROVEN_NO_EXACT_CAPTURED_INPUT_AFTER_PAIRED_ASSIGNMENT'
    result={'schema':'gl20.paired-external-captured-map-composition-search.v1','status':status,
        'scope':'Literal legacy assignment on retained first-pass output, then exhaustive necessary-field/full-descriptor equality lookup against every captured canonicalization-pass input. No new canonicalization, key computation, state loading, graph generation, evaluator or numerical/symbolic evaluation.',
        'source_summary':P.file_record(summary_path),'model':P.file_record(model_path),
        'counts':{'candidate_records_scanned':len(paths),'distinct_scopes':len(scopes),'first_pass_scopes':sum(flags.values()),'fixed_pass_scopes':sum(not x for x in flags.values()),'full_graph_parses_after_necessary_filter':raw_graph_parses},
        'captured_external_row_patterns':[{'pattern':list(key),'record_count':count} for key,count in patterns.items()],
        'targets':[{key:value for key,value in target.items() if key!='graph'} for target in targets],
        'result':'No exact recorded canonicalization map is applicable to the modified graph. Discarded candidate2 member7 physical frame cannot be composed from this baseline witness without a fresh owner canonicalization.' if not any_match else 'Recorded first-step inputs exist; no claim about completed composition yet.',
        'next_minimal_witness_if_unproven':'One bounded candidate2 generation-only original fixture with read-only observers after the now-modified global and fixed passes, normalization input/output and pre/postlabel comparison/paired physical payloads for all retained members. Reuse candidate2 libs where possible; no GenerateExisting, evaluator, point run or guessed role flip.',
        'elapsed_seconds':time.monotonic()-start,'resource_maxrss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
        'limits':['The exact master decoded frame is independently known to equal old member21, but this does not determine the discarded member7 payload.','Failure of exact input lookup is not failure of isomorphism; no isomorphism search was attempted.','External-row filtering uses source-observed rows deterministically derived from that same raw Graph, so a mismatch rejects full descriptor equality.']}
    path=HERE/'paired-assignment-map-composition-search.json'
    with path.open('x') as f:json.dump(result,f,indent=2);f.write('\n')
    print(json.dumps({'report':P.file_record(path),'status':status,'counts':result['counts'],'targets':[{'member':t['member'],'external_filter_matches':len(t['external_filter_matching_records']),'full_descriptor_matches':len(t['exact_raw_graph_matches'])} for t in targets],'elapsed_seconds':result['elapsed_seconds'],'maxrss_kib':result['resource_maxrss_kib']}))


if __name__=='__main__':main()

"""Preserve completed GL20 diagnostic source; never runs archived helpers."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import tarfile

HERE = Path(__file__).resolve().parent
OUT = HERE.parents[2]
CT = OUT / "ct-real-point-diagnostic"
GEN = CT / "generation-frame-witness"
REG = HERE / "regression-valid-cut-fixtures"
PUBLICATION = HERE / "publication-worktree"
DESTINATION = PUBLICATION / "docs/validation/gl20-2026-10-26"
PREFIX = "gl20-diagnostic-source-supplement-v1"
SOURCES = {}


def add(prefix, folder, names):
    for name in names:
        path = folder / name
        assert path.is_file(), path
        assert path.suffix in (".py", ".rs", ".diff")
        logical = prefix + "/" + name
        assert logical not in SOURCES
        data = path.read_bytes()
        assert len(data) < 250000
        assert not re.search(rb"\b[0-9a-f]{32}\b", data), (logical, "literal runtime identity requires review")
        assert not re.search(rb"(?:EXPECTED_PID|CONTROLLER_PID)\s*=\s*[1-9][0-9]{2,}", data), logical
        SOURCES[logical] = (path, data)


add("shared", OUT, ["compare_exports.py", "compare_evaluator_interfaces.py", "compare_runtime_parameter_bindings.py", "compare_saved_model_fields.py", "reconstruct_existing_snapshot.py", "run_decoder.py", "controller_body.py", "prepare_ct_trace_sources.py"])
add("decoder", OUT / "api-adapted-v2", ["decoder.rs"])
add("algebra", OUT / "comparison", ["check_cff_residual_polynomial_identity.py"])
add("ct-traces", CT, ["compare_mapped_ct_traces.py", "read_ct_trace.py", "driver-template.rs", "prepare_controls.py", "run_trace.py", "start_trace.py"])
add("ct-traces/current", CT / "current", ["driver.rs", "instrumentation-only.diff"])
add("ct-traces/historical", CT / "historical", ["driver.rs", "instrumentation-only.diff"])
add("generation-witness", GEN, ["driver.rs", "instrumentation-only.diff", "prepare_build_plan.py", "prepare_controls.py", "prepare_source_witness.py", "run_witness.py", "start_witness.py"])
add("generation-witness/analysis", GEN / "analysis", ["parse_generation_frames.py", "match_ci_retained_frame.py", "replay_legacy_external_assignment.py", "search_paired_assignment_map_composition.py"])
add("routing-witness", GEN / "candidate-paired-external-momenta-restoration/member-generation-witness/analysis", ["replay_routing_roots.py"])
add("candidate3", REG, ["prepare_plan.py", "prepare_controls.py", "run_regression.py", "start_regression.py", "compare_decoded_frames.py", "reconstruct_candidate_snapshot.py"])
add("candidate3/decoder-control", REG / "matched-state-decode", ["prepare_decode.py", "run_decode.py", "start_decode.py"])
add("candidate3/stored-ir", REG / "stored-evaluator-comparison", ["compare_stored_programs.py"])
add("packaging", HERE, ["prepare_source_supplement.py"])

manifest = {"schema": "gl20.completed-diagnostic-source-supplement.v1", "captured_at": "2026-10-26", "scope": "Completed diagnostic helper and reusable controller source only. Source preserves successful, failed and read-only diagnostic methods; it does not establish GL20 snapshot acceptance or an unfinished numerical cause.", "exclusions": ["state and model payloads", "generated scientific outputs and logs", "ELFs, libraries and build products", "environment files, licence and secret values", "bound control manifests and runtime activation/PID/UUID records", "superseded singleton and unexecuted source variants", "unfinished causal conclusions"], "members": []}
for logical, (path, data) in sorted(SOURCES.items()):
    manifest["members"].append({"path": logical, "source_origin": str(path.relative_to(OUT)), "sha256": hashlib.sha256(data).hexdigest(), "bytes": len(data)})
manifest_bytes = (json.dumps(manifest, indent=2) + "\n").encode()
readme = b"Completed GL20 diagnostic source preservation.\nOriginal input manifests, environments, retained states and build products are deliberately absent.\nSource files retain their observed stage-local path and unit-label logic, but no bound runtime activation identities.\nThe archived controllers are not a standalone launch bundle. No helper is run by this archive builder.\nThe strict original GL20 numerical snapshot still fails; no numerical cause is claimed.\n"


def archive_bytes():
    destination = io.BytesIO()
    with gzip.GzipFile(filename="", mode="wb", compresslevel=9, fileobj=destination, mtime=0) as zipped:
        with tarfile.open(fileobj=zipped, mode="w", format=tarfile.USTAR_FORMAT) as archive:
            items = {name: data for name, (_, data) in SOURCES.items()}
            items["MANIFEST.json"] = manifest_bytes
            items["README.txt"] = readme
            for name, data in sorted(items.items()):
                info = tarfile.TarInfo(PREFIX + "/" + name)
                info.size, info.mode, info.mtime = len(data), 0o644, 0
                info.uid = info.gid = 0
                info.uname = info.gname = ""
                archive.addfile(info, io.BytesIO(data))
    return destination.getvalue()


archive = archive_bytes()
assert archive == archive_bytes(), "Archive must be byte-deterministic"
DESTINATION.mkdir(parents=True, exist_ok=True)
archive_name = "gl20-diagnostic-source-supplement-20261026.tar.gz"
(DESTINATION / archive_name).write_bytes(archive)
archive_sha = hashlib.sha256(archive).hexdigest()
(DESTINATION / "source-supplement-manifest.json").write_bytes(manifest_bytes)
checksums = [archive_sha + "  " + archive_name] + [row["sha256"] + "  " + row["path"] for row in manifest["members"]]
(DESTINATION / "source-supplement.sha256").write_text("\n".join(checksums) + "\n")
text = "= GL20 diagnostic source supplement\n\nThis deterministic source-only archive preserves completed decoder, comparison,\ntrace, generation-witness and controller helper source. It contains no retained\nstate payloads, binary artifacts, environments, licence values, or bound runtime\nactivation identities. The current original numerical snapshot still fails; the\nremaining cause is unproved.\n\n"
text += "Archive: `" + archive_name + "`\n\nSHA256: `" + archive_sha + "`\n\nSource files: " + str(len(SOURCES)) + ". Tar ownership and times, gzip time, member order, and modes\nare fixed; two independent serializations were byte-identical.\n\n"
text += "The complete per-file hashes and original source-relative paths are retained in\n`source-supplement-manifest.json`; `source-supplement.sha256` also lists every\nsource member. Stage-local unit labels and environment variable names in source\nare logic, not captured runtime activations or secret values. Original qualified\ninput manifests are required separately; this is not a standalone launch bundle.\n"
(DESTINATION / "source-manifest.typ").write_text(text)
print(json.dumps({"archive": str(DESTINATION / archive_name), "sha256": archive_sha, "bytes": len(archive), "source_files": len(SOURCES), "manifest_sha256": hashlib.sha256(manifest_bytes).hexdigest(), "deterministic_repeat_equal": True}))

"""Compare completed stored graph frames and integer routing rows only."""
import hashlib
import json
import re
from pathlib import Path

HERE = Path(__file__).resolve().parent
OUT = HERE.parents[3]
DECODE = HERE / "matched-state-decode/run1"
PATHS = {
    "historical": OUT.parent / "historical-generation-proposal/prepared-source-and-driver/historical-matched-decoder-20261026/controller-v2/run1/export/process-0-cross-section.json",
    "baseline": OUT / "api-adapted-v2/run1/export/process-0-cross-section.json",
    "candidate3": DECODE / "export/process-0-cross-section.json",
}


def record(path):
    data = path.read_bytes()
    return {"path": str(path), "sha256": hashlib.sha256(data).hexdigest(), "bytes": len(data)}


def particle(edge):
    return edge["particle"]["particle"]


def frame(process):
    assert len(process["supergraphs"]) == 1
    s = process["supergraphs"][0]
    g = s["graph"]
    hedges = {h["hedge"]:h for h in g["hedges"]}
    nodes = [{"node":n["node"],"rule":n["rule"],"hedges":n["hedges"]} for n in g["nodes"]]
    edges = [{"edge":e["edge"],"source_node":e["endpoints"]["source_node"],"sink_node":e["endpoints"]["sink_node"],
              "source_hedge":e["endpoints"]["source"],"sink_hedge":e["endpoints"]["sink"],
              "orientation":e["orientation"],"particle":particle(e)["name"],"pdg":particle(e)["pdg"]} for e in g["edges"]]
    def hrows(ids):
        return [{"hedge":h,"edge":hedges[h]["edge"],"node":hedges[h]["node"],"flow":hedges[h]["flow"]} for h in ids]
    cuts = []
    for i,c in enumerate(s["cuts"]):
        cuts.append({"index":i,"energy_edges":sorted({hedges[h]["edge"] for h in c["left_cut_hedges"]}),
                     **c,"left_nodes":sorted({hedges[h]["node"] for h in c["left_partition_hedges"]}),
                     "right_nodes":sorted({hedges[h]["node"] for h in c["right_partition_hedges"]})})
    cache=g["surface_cache"]
    surfaces=[]
    for i,v in enumerate(cache.get("energy_surfaces",cache.get("esurface_cache",[]))):
        shift=v["external_shift"]
        if isinstance(shift,list):shift={str(k):value for k,value in shift}
        vertex_set=v["vertex_set"]
        if isinstance(vertex_set,dict):vertex_set=vertex_set["vertex_set"]
        surfaces.append({"id":i,"energies":v["energies"],"external_shift":shift,"vertex_set":vertex_set})
    return {"reported_name_not_join_key":g["name"],"group_id":g["group_id"],"nodes":nodes,"edges":edges,
            "source":hrows(s["source_node_hedges"]),"target":hrows(s["target_node_hedges"]),
            "initial_state_cut":g["initial_state_cut"],"cuts":cuts,"cut_esurfaces":s["cut_esurfaces"],
            "surfaces":surfaces,"threshold_candidate_ids":s["threshold_candidates"],
            "default_lmb":g["default_lmb"],"all_lmbs":s["all_lmbs"],
            "effective_channels":s["multi_channeling_setup"]["effective_channels_from_saved_settings"],
            "overall_factor":g["overall_factor"],"member_ids_from_overall_factor":list(map(int,re.findall(r"NumeratorDependentGrouping\((\d+),",g["overall_factor"]))),
            "graph_group_structure":process["graph_group_structure"],"runtime_group_structure":process["runtime_group_structure"],
            "runtime_term_count":len(process["runtime_graph_terms"])}


def matrix_rows(lmb,key):
    return [r[key] for r in lmb["edge_signatures"]]


def lmb_pair(a,b,signs):
    assert a["loop_edges"] == b["loop_edges"]
    ka,kb=matrix_rows(a,"internal"),matrix_rows(b,"internal")
    pa,pb=matrix_rows(a,"external"),matrix_rows(b,"external")
    loop_signs=[signs[i] for i in a["loop_edges"]]
    # Stored-integer sign relation only, no basis inversion or kinematics.
    transported_k=[[signs[e]*loop_signs[i]*v for i,v in enumerate(row)] for e,row in enumerate(ka)]
    transported_p=[[signs[e]*v for v in row] for e,row in enumerate(pa)]
    return {"loop_edges":a["loop_edges"],"tree_exact_equal":a["tree"]==b["tree"],"K_exact_equal":ka==kb,"P_exact_equal":pa==pb,
            "K_satisfies_endpoint_and_loop_sign_relation":transported_k==kb,"P_satisfies_endpoint_sign_relation":transported_p==pb,
            "K_changed_edge_rows":[i for i,(x,y) in enumerate(zip(ka,kb)) if x!=y],
            "P_changed_edge_rows":[i for i,(x,y) in enumerate(zip(pa,pb)) if x!=y]}


def surface_key(s):
    return tuple(s["energies"]),tuple(sorted(s["external_shift"].items()))


def compare(a,b):
    assert len(a["edges"]) == len(b["edges"])
    changes,signs=[],[]
    for old,new in zip(a["edges"],b["edges"]):
        assert old["edge"]==new["edge"]
        same=(old["source_node"],old["sink_node"])==(new["source_node"],new["sink_node"])
        reverse=(old["source_node"],old["sink_node"])==(new["sink_node"],new["source_node"])
        signs.append(1 if same else -1 if reverse else None)
        if old!=new:changes.append({"edge":old["edge"],"old":old,"new":new,"endpoints_reversed":reverse and not same})
    literal_identity_verified=([n["rule"] for n in a["nodes"]]==[n["rule"] for n in b["nodes"]] and
        all(sign is not None for sign in signs) and all(x["pdg"]==y["pdg"] and x["particle"]==y["particle"] for x,y in zip(a["edges"],b["edges"])))
    assert literal_identity_verified,"No exact literal edge-frame join; do not force graph-name/isomorphism match"
    def bases(rows):
        result={tuple(r["loop_edges"]):(i,r) for i,r in enumerate(rows)}
        assert len(result)==len(rows)
        return result
    aa,bb=bases(a["all_lmbs"]),bases(b["all_lmbs"])
    lmb_rows=[]
    for key,(i,lmb) in aa.items():
        if key in bb:
            j,new=bb[key];lmb_rows.append({"old_index":i,"new_index":j,**lmb_pair(lmb,new,signs)})
    ca={tuple(c["energy_edges"]):c for c in a["cuts"]};cb={tuple(c["energy_edges"]):c for c in b["cuts"]};assert len(ca)==len(a["cuts"]) and len(cb)==len(b["cuts"])
    cut_rows=[]
    core={n["node"] for n in a["nodes"] if n["rule"]!="V_98"}
    for key,c in ca.items():
        if key not in cb:continue
        d=cb[key];al=set(c["left_nodes"])&core;ar=set(c["right_nodes"])&core;bl=set(d["left_nodes"])&core;br=set(d["right_nodes"])&core
        cut_rows.append({"energy_edges":list(key),"old_index":c["index"],"new_index":d["index"],
                         "left_right_core_node_relation":"same" if (al,ar)==(bl,br) else "swapped" if (al,ar)==(br,bl) else "different",
                         "old_left_nodes":c["left_nodes"],"new_left_nodes":d["left_nodes"],"old_right_nodes":c["right_nodes"],"new_right_nodes":d["right_nodes"],
                         "left_cut_hedges_exact_equal":c["left_cut_hedges"]==d["left_cut_hedges"],"right_cut_hedges_exact_equal":c["right_cut_hedges"]==d["right_cut_hedges"],
                         "old_left_cut_hedges":c["left_cut_hedges"],"new_left_cut_hedges":d["left_cut_hedges"],"old_right_cut_hedges":c["right_cut_hedges"],"new_right_cut_hedges":d["right_cut_hedges"]})
    surface_rows=[]
    for old in a["surfaces"]:
        matches=[n["id"] for n in b["surfaces"] if surface_key(n)==surface_key(old)]
        surface_rows.append({"old_id":old["id"],"new_exact_energy_shift_matches":matches,"old_vertex_set":old["vertex_set"],"new_vertex_sets":[b["surfaces"][i]["vertex_set"] for i in matches]})
    return {"literal_ordered_rule_undirected_connectivity_signed_particle_join_verified":literal_identity_verified,
            "ordered_rules_equal":[n["rule"] for n in a["nodes"]]==[n["rule"] for n in b["nodes"]],
            "edge_changes":changes,"endpoint_signs_old_to_new":signs,
            "source_exact_equal":a["source"]==b["source"],"target_exact_equal":a["target"]==b["target"],
            "cut_energy_keys_equal":ca.keys()==cb.keys(),"cut_rows":cut_rows,
            "all_lmb_counts":[len(aa),len(bb)],"loop_edge_key_sets_equal":aa.keys()==bb.keys(),"lmb_index_map_by_exact_loop_edges":[r["new_index"] for r in lmb_rows],"matched_lmb_rows":lmb_rows,
            "default_loop_edges_old":a["default_lmb"]["loop_edges"],"default_loop_edges_new":b["default_lmb"]["loop_edges"],
            "default_lmb_exact_equal":a["default_lmb"]==b["default_lmb"],
            "effective_channels_exact_equal":a["effective_channels"]==b["effective_channels"],"effective_channels_old":a["effective_channels"],"effective_channels_new":b["effective_channels"],
            "surface_energy_shift_map":surface_rows,"threshold_ids_old":a["threshold_candidate_ids"],"threshold_ids_new":b["threshold_candidate_ids"],
            "overall_factor_exact_equal":a["overall_factor"]==b["overall_factor"],"member_ids_old":a["member_ids_from_overall_factor"],"member_ids_new":b["member_ids_from_overall_factor"]}


def main():
    completion_path=DECODE/"completion.json";completion=json.loads(completion_path.read_text())
    assert completion["status"]=="PASS_ONE_CANDIDATE3_MATCHED_READ_ONLY_FULL_STATE_EXPORT_NOT_SNAPSHOT_ACCEPTANCE"
    export_completion=json.loads((DECODE/"export/completion.json").read_text())
    assert export_completion["status"]=="PASS_MATCHING_CURRENT_READ_ONLY_STATE_EXPORT" and export_completion["owner_state_loads"]==1
    processes={name:json.loads(path.read_text()) for name,path in PATHS.items()}
    frames={name:frame(value) for name,value in processes.items()}
    pairs={"historical_to_baseline":compare(frames["historical"],frames["baseline"]),"historical_to_candidate3":compare(frames["historical"],frames["candidate3"]),"baseline_to_candidate3":compare(frames["baseline"],frames["candidate3"])}
    report={"schema":"gl20.three-owner-stored-physical-frame-comparison.v1","status":"COMPARED_COMPLETED_EXPORTS_ONLY_NOT_REGRESSION_ACCEPTANCE",
            "scope":"Already-retained JSON descriptors, exact edge/chord/energy-set joins and stored integer row/sign comparisons. No canonization, graph generation, state loading, evaluator or new numerical/symbolic calculation.",
            "completion":record(completion_path),"exports":{n:record(p) for n,p in PATHS.items()},"frames":frames,"pairs":pairs,
            "limits":["Each retained process contains exactly one selected physical supergraph. Names are reported only; ordered rule/edge/particle descriptors establish literal frame identity.","Group member IDs come from retained NumeratorDependentGrouping factor provenance; no pre-collapse member graph payload or new canonical-isomorphism search is reconstructed.","Core cut-side comparison excludes the two V_98 external attachment vertices to expose old/current stored partition-convention differences; complete literal node/hedge sets are retained.","Default LMB changes matter even when matched basis matrices obey sign relations. Stored event equality or remaining helper-sign cause does not follow from graph-frame restoration.","The earlier literal lastpass replay did not re-run the changed fixed-pass input, full flow normalization, master selection or default basis selection; actual decoded result must supersede its limited anchor prediction."]}
    destination=HERE/"decoded-physical-frame-comparison.json"
    with destination.open('x') as stream:json.dump(report,stream,indent=2);stream.write('\n')
    print(json.dumps({"report":record(destination),"pairs":{n:{"changed_edges":[r["edge"] for r in p["edge_changes"]],"source_equal":p["source_exact_equal"],"target_equal":p["target_exact_equal"],"default_loops":[p["default_loop_edges_old"],p["default_loop_edges_new"]],"lmb_counts":p["all_lmb_counts"],"loop_keys_equal":p["loop_edge_key_sets_equal"],"matched_lmbs":len(p["matched_lmb_rows"]),"K_sign_relation_all":all(r["K_satisfies_endpoint_and_loop_sign_relation"] for r in p["matched_lmb_rows"]),"P_sign_relation_all":all(r["P_satisfies_endpoint_sign_relation"] for r in p["matched_lmb_rows"]),"cut_sides":[r["left_right_core_node_relation"] for r in p["cut_rows"]]} for n,p in pairs.items()}}))


if __name__=='__main__':main()

"""Prepare candidate3 focused-owner/full-original-regression sealed controller."""
import ast
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
GEN = HERE.parent.parent
PREVIOUS = GEN / "candidate-paired-external-momenta-restoration/regression"
PM = json.loads((PREVIOUS / "control-manifest.json").read_text())
P = json.loads((HERE / "build-plan.json").read_text())


def record(path):
    path = Path(path).resolve()
    with path.open("rb") as stream:
        checksum = hashlib.file_digest(stream, "sha256").hexdigest()
    return {"path": str(path), "sha256": checksum, "bytes": path.stat().st_size}


controller = (PREVIOUS / "run_regression.py").read_text()
controller = controller.replace("PRIVATE_PAIRED_EXTERNAL_MOMENTA_SETUP_NOT_REGRESSION_PASS", "PRIVATE_PHYSICAL_MASTER_AND_NATIVE_ROOT_SETUP_NOT_REGRESSION_PASS")
begin = controller.index('        build(P["focused_build"], env, deadline, result)')
end = controller.index('        guard()\n        assert time.monotonic() <= deadline', begin)
controller = controller[:begin] + '''        build(P["focused_graph_build"], env, deadline, result)
        guard()
        PHASE_CWD = Path(P["private_source"])
        host_check("pre-graph-focused")
        graph_test = Path(P["focused_graph_build"]["output"])
        result["phases"].append(phase("focused-graph-tests", [M["taskset"], "-c", "140", str(graph_test), P["graph_focused_filter"], "--nocapture", "--test-threads=1"], env, 600, graph_test, {140}))
        assert str(P["graph_focused_count"]) + " passed; 0 failed" in (RUN / "focused-graph-tests.log").read_text()
        result["focused_graph_tests_passed"] = P["graph_focused_count"]
        # Compile only the six affected support owners before Generator contracts.
        support = [stage for stage in P["stages"] if stage["stage"] not in ("gammalooprs", "gammaloop_api", "gammaloop_integration_tests", "test_evaluation_api")]
        assert len(support) == 6
        for stage in support:
            build(stage, env, deadline, result)
        build(P["focused_generator_build"], env, deadline, result)
        guard()
        PHASE_CWD = Path(P["private_source"])
        host_check("pre-generator-focused")
        generator_test = Path(P["focused_generator_build"]["output"])
        result["phases"].append(phase("focused-generator-tests", [M["taskset"], "-c", "140", str(generator_test), P["generator_focused_filter"], "--nocapture", "--test-threads=1"], env, 600, generator_test, {140}))
        assert str(P["generator_focused_count"]) + " passed; 0 failed" in (RUN / "focused-generator-tests.log").read_text()
        result["focused_generator_tests_passed"] = P["generator_focused_count"]
        # A failed focused compile or contract process prevents original evaluation.
        for stage in P["stages"]:
            if stage not in support:
                build(stage, env, deadline, result)
''' + controller[end:]
marker = '        executable = Path(P["stages"][-1]["output"])'
assert controller.count(marker) == 1
controller = controller.replace(marker, '        host_check("pre-original-regression")\n' + marker)
controller = controller.replace('actual_direct_rustc_invocations=6', 'actual_direct_rustc_invocations=12')
controller = controller.replace('    for freeze_path in (M["original_source_freeze"], M["private_source_freeze"]):', '    for freeze_path in (M["original_source_freeze"], M["candidate2_source_freeze"], M["private_source_freeze"]):')
insert = controller.index('\n\ndef main():')
controller = controller[:insert] + '''

def host_check(label):
    available = next(x for x in Path("/proc/meminfo").read_text().splitlines() if x.startswith("MemAvailable:"))
    assert int(available.split()[1]) * 1024 >= 50000000000
    cgroup = Path("/sys/fs/cgroup") / Path("/proc/self/cgroup").read_text().strip().split(":", 2)[2].lstrip("/")
    assert (cgroup / "memory.swap.max").read_text().strip() == "0"
    atomic(RUN / (label + "-host-check.json"), {"utc": now(), "MemAvailable": available, "minimum_available_bytes": 50000000000, "memory_swap_max": "0"})
''' + controller[insert:]
controller = controller.replace('M["candidate2_source_freeze"], M["private_source_freeze"]', 'M["candidate2_source_freeze"], M["candidate3_parent_source_freeze"], M["private_source_freeze"]')
controller = controller.replace('PRIVATE_PHYSICAL_MASTER_AND_NATIVE_ROOT_SETUP_NOT_REGRESSION_PASS', 'PRIVATE_PHYSICAL_MASTER_NATIVE_ROOT_VALID_CUT_FIXTURES_SETUP_NOT_REGRESSION_PASS')
ast.parse(controller)
(HERE / "run_regression.py").write_text(controller)
starter = (PREVIOUS / "start_regression.py").read_text().replace('"current-paired-external-momenta-candidate"', '"candidate3-valid-cut-fixtures"')
starter = starter.replace('"--property=MemoryMax=17179869184",', '"--property=MemoryMax=17179869184", "--property=MemorySwapMax=0",')
starter = starter.replace(">= 34359738368", ">= 50000000000")
ast.parse(starter)
(HERE / "start_regression.py").write_text(starter)
launch = (PREVIOUS / "launch.sh").read_text().replace(str(PREVIOUS / "run_regression.py"), str(HERE / "run_regression.py"))
(HERE / "launch.sh").write_text(launch)
frozen = {"source": str(HERE / "source"), "files": {str(path.relative_to(HERE / "source")): record(path)["sha256"]
          for path in sorted((HERE / "source").rglob("*")) if path.is_file()}}
baseline = json.loads((PREVIOUS / "source-freeze.json").read_text())
changed = [relative for relative, checksum in baseline["files"].items() if frozen["files"][relative] != checksum]
assert sorted(changed) == ["crates/feynkit-generator/src/generation.rs", "crates/feynkit-graph/src/lib.rs"], changed
added = sorted(set(frozen["files"]) - set(baseline["files"]))
assert len(added) == 2 and len(frozen["files"]) == 2813, added
assert frozen["files"]["crates/feynkit-generator/src/focused-tests.rs"] == "fd722d3b4a83ef11d31372b7cd5e8c9d52917309f4b634b7cec357d41af35a05"
parent_frozen = json.loads((HERE.parent / "regression/source-freeze.json").read_text())
assert set(frozen["files"]) == set(parent_frozen["files"])
parent_changed = [relative for relative, checksum in parent_frozen["files"].items() if frozen["files"][relative] != checksum]
assert parent_changed == ["crates/feynkit-graph/src/gl20_frame_routing_tests.rs"], parent_changed

with (HERE / "source-freeze.json").open("x") as stream:
    json.dump(frozen, stream, indent=2)
    stream.write("\n")
paths = [HERE / name for name in ("prepare_plan.py", "build-plan.json", "prepare_controls.py", "run_regression.py", "start_regression.py", "launch.sh", "source-freeze.json", "source-preparation-initial.json", "independent-c3-build-plan-review.json", "independent-fixture-source-review.json", "fixture-source-preparation.json", "fixture-correction.diff")]
paths += [HERE.parent / name for name in ("generator-candidate.diff", "generator-source-preparation.json", "generator-independent-source-review.json", "graph-candidate.diff", "graph-source-and-tests-static-review.json", "graph-box-contract-split-source-proof.json")]
paths += [HERE.parent / "regression/source-freeze.json", HERE.parent / "regression/control-manifest.json", HERE.parent / "regression/run1/completion.json", Path(PM["original_source_freeze"]), PREVIOUS / "source-freeze.json", PREVIOUS / "control-manifest.json",
          PREVIOUS.parent / "member-generation-witness/analysis/observed-member-order-routing.json",
          PREVIOUS.parent / "member-generation-witness/analysis/native-first-hedge-routing-root-proof.json"]
manifest = {"schema": "gl20.candidate3-physical-order-and-native-root-controls.v1", "unit": "gl20-candidate3-valid-cut-fixtures-original-regression-20261026.service",
            "taskset": PM["taskset"], "original_source_freeze": PM["original_source_freeze"], "candidate2_source_freeze": str(PREVIOUS / "source-freeze.json"),
            "candidate3_parent_source_freeze": str(HERE.parent / "regression/source-freeze.json"), "private_source_freeze": str(HERE / "source-freeze.json"), "controls": [record(path) for path in paths],
            "scope": "Root-authorized scoped raw physical semantic ordering + native first-included-half-edge paired routing root on candidate2. Test-only metadata correction follows retained prior 2PASS/2FAIL MissingCrossSectionCuts gate. Production Graph/Generator source unchanged from parent C3. Exact original GL20 fixture/semantic selector/default automatic routing/model/point/golden/assertions preserved. No literal basis override, CT phase patch, worker changes or five-loop physical execution.",
            "budgets": {"setup_affinity": [145, 146], "setup_seconds_including_focused_runtime": 1800, "runtime_affinity": [140],
                        "focused_process_seconds_each": 600, "original_test_seconds": 600, "memory_max_bytes": 17179869184, "memory_swap_max": 0,
                        "minimum_host_available_bytes": 50000000000, "math_threads": 1, "direct_rustc_invocations": 12, "complete_original_test_invocations": 1, "retries": 0},
            "acceptance": "Focused Graph4 then Generator7 must pass before the one complete original GL20 test. Stop on focused failure; unchanged source/fixture/gold guards after success or failure. Only passing unchanged original snapshot establishes this targeted regression success.",
            "source_changed_paths_from_candidate2": changed, "candidate3_parent_changed_paths": parent_changed, "candidate3_parent_delta": "Only the new Graph focused fixture child receives required physical-cut metadata; prior production Graph/Generator source unchanged.", "source_added_paths": added, "no_main_or_dependency_pin_change": True}
with (HERE / "control-manifest.json").open("x") as stream:
    json.dump(manifest, stream, indent=2)
    stream.write("\n")
print(json.dumps({"manifest": record(HERE / "control-manifest.json"), "source_freeze": record(HERE / "source-freeze.json"),
                  "controls": len(paths), "changed": changed, "added": added, "expected_focused": [4, 7]}))

"""One exact-body, matching-writer read-only decode of retained candidate3 state."""
import argparse
import ast
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import sys
import time
import traceback

os.umask(0o077)
HERE = Path(__file__).resolve().parent
RUN = HERE / "run1"
PHASE_CWD = RUN
parser = argparse.ArgumentParser()
parser.add_argument("--manifest-sha256", required=True)
args = parser.parse_args()
PRIMITIVES = HERE.parents[4] / "run_decoder.py"
assert hashlib.sha256(PRIMITIVES.read_bytes()).hexdigest() == "0cb2a14879b12f448014f10ba8df12438a71edac58672a35baef86ac1eadcc70"
tree = ast.parse(PRIMITIVES.read_text())
for node in tree.body:
    if isinstance(node, ast.FunctionDef) and node.name in {"sha", "now", "atomic", "identity", "resources", "signal_owned_group", "reap_and_drain", "phase"}:
        source = ast.get_source_segment(PRIMITIVES.read_text(), node)
        if node.name == "phase":
            assert source.count("cwd=RUN") == 1
            source = source.replace("cwd=RUN", "cwd=PHASE_CWD")
        exec(compile(source, str(PRIMITIVES) + ":" + node.name, "exec"), globals())
assert sha(HERE / "control-manifest.json") == args.manifest_sha256
M = json.loads((HERE / "control-manifest.json").read_text())
P = json.loads(Path(M["writer_build_plan"]).read_text())
S = json.loads((HERE / "retained-state-authentication.json").read_text())
D = json.loads((HERE / "dependency-authentication.json").read_text())


def check_records(value, seen):
    if isinstance(value, dict):
        if isinstance(value.get("path"), str) and isinstance(value.get("sha256"), str) and re.fullmatch(r"[0-9a-f]{64}", value["sha256"]):
            if value["path"] not in seen:
                assert sha(value["path"]) == value["sha256"], value["path"]
                seen.add(value["path"])
        for child in value.values():
            check_records(child, seen)
    elif isinstance(value, list):
        for child in value:
            check_records(child, seen)


def guard():
    assert sha(HERE / "control-manifest.json") == args.manifest_sha256
    for data in (M["controls"], D, P, S):
        check_records(data, set())
    for filename in (M["original_source_freeze"], M["writer_source_freeze"]):
        frozen = json.loads(Path(filename).read_text())
        for relative, expected in frozen["files"].items():
            assert sha(Path(frozen["source"]) / relative) == expected, relative
    root = Path(S["root"])
    payloads = {str(p.relative_to(root)) for p in root.rglob("*") if p.is_file() and "logs" not in p.relative_to(root).parts}
    assert payloads == {r["relative"] for r in S["files"]}


def no_target_writers():
    prefixes = tuple(str(Path(root)) + "/" for root in (P["frozen_target_read_only"], P["private_library_directory"]))
    for proc in Path("/proc").iterdir():
        if not proc.name.isdigit():
            continue
        try:
            fds = list((proc / "fd").iterdir())
        except (FileNotFoundError, ProcessLookupError, PermissionError):
            continue
        for fd in fds:
            try:
                if not os.readlink(fd).startswith(prefixes):
                    continue
                flags = int(next(x.split()[1] for x in (proc / "fdinfo" / fd.name).read_text().splitlines() if x.startswith("flags:")), 8)
                assert flags & os.O_ACCMODE == os.O_RDONLY, "Frozen dependency directories have a live writer"
            except (FileNotFoundError, ProcessLookupError, PermissionError):
                pass


def main():
    assert os.environ.get("SYMBOLICA_LICENSE")
    assert M["unit"] in Path("/proc/self/cgroup").read_text() and os.environ.get("INVOCATION_ID")
    assert os.sched_getaffinity(0) == {140, 145, 146}
    setup_start = time.monotonic()
    guard()
    no_target_writers()
    env = os.environ.copy()
    env.update(json.loads(Path(P["base_environment_source"]).read_text())[P["base_environment_key"]])
    for key in P["environment_unset"]:
        env.pop(key, None)
    for key in list(env):
        if key.startswith("INSTA_") or key.startswith("BASH_FUNC_") or key.startswith("GL20_"):
            env.pop(key)
    env.update(NO_SYMBOLICA_OEM_LICENSE="1", SYMBOLICA_HIDE_BANNER="1", RUST_BACKTRACE="1",
               GL_DISPLAY_FILTER="off", GL_LOGFILE_FILTER="off", GL_ALL_LOG_FILTER="off",
               TMPDIR=str(RUN / "tmp"), XDG_CACHE_HOME=str(RUN / "cache"), GL_TEST_LOG_DIR=str(RUN / "logs"))
    env.update(P["thread_environment_values"])
    for folder in ("tmp", "cache", "logs"):
        (RUN / folder).mkdir()
    copied = RUN / "input-copy"
    copied.mkdir()
    for row in S["files"]:
        target = copied / row["relative"]
        target.parent.mkdir(parents=True, exist_ok=True)
        with Path(row["path"]).open("rb") as source, target.open("xb") as dest:
            shutil.copyfileobj(source, dest)
            dest.flush()
            os.fsync(dest.fileno())
        assert target.stat().st_ino != Path(row["path"]).stat().st_ino
        assert sha(target) == row["sha256"]
    compiler = subprocess.check_output([P["compiler"]["path"], "-Vv"], env=env, text=True, timeout=10)
    assert compiler.startswith("rustc 1.98.1 ")
    atomic(RUN / "actual-compiler.json", {"compiler": P["compiler"], "verbose_version": compiler})
    result = {"status": "CANDIDATE3_MATCHED_READ_ONLY_DECODE_SETUP_NOT_PASS", "manifest_sha256": args.manifest_sha256,
              "unit": M["unit"], "invocation_id": os.environ["INVOCATION_ID"], "phases": [], "retries": 0}
    atomic(RUN / "STARTED.json", result, exclusive=True)
    code = 1
    try:
        build = [M["taskset"], "-c", "145,146", P["compiler"]["path"], "--crate-name", "gl20_candidate3_readonly_decoder", "--edition=2024", "--crate-type=bin",
                 "-C", "opt-level=0", "-C", "debuginfo=0", "-C", "linker=" + P["linker"]["path"],
                 "-L", "dependency=" + P["private_library_directory"], "-L", "dependency=" + str(Path(P["frozen_target_read_only"]) / "deps")]
        for directory in P["native_link_search_paths"]:
            build += ["-L", "native=" + directory]
        for row in D["selected_externs"]:
            build += ["--extern", row["crate"] + "=" + row["rlib"]["path"]]
        executable = RUN / "decoder"
        build += [str(HERE / "decoder.rs"), "-o", str(executable)]
        result["phases"].append(phase("build", build, env, max(0, setup_start + 1800 - time.monotonic()), P["compiler"]["path"], {145, 146}))
        atomic(RUN / "built-artifact.json", {"path": str(executable), "sha256": sha(executable), "bytes": executable.stat().st_size,
               "helper_source_sha256": sha(HERE / "decoder.rs"), "dependency_authentication_sha256": sha(HERE / "dependency-authentication.json")})
        guard()
        no_target_writers()
        result["setup_seconds"] = time.monotonic() - setup_start
        assert result["setup_seconds"] <= 1800
        available = next(x for x in Path("/proc/meminfo").read_text().splitlines() if x.startswith("MemAvailable:"))
        assert int(available.split()[1]) * 1024 >= 50000000000
        cgroup = Path("/sys/fs/cgroup") / Path("/proc/self/cgroup").read_text().strip().split(":", 2)[2].lstrip("/")
        assert (cgroup / "memory.swap.max").read_text().strip() == "0"
        atomic(RUN / "pre-decode-host-check.json", {"utc": now(), "MemAvailable": available, "minimum_available_bytes": 50000000000, "memory_swap_max": "0"})
        result["phases"].append(phase("decode", [M["taskset"], "-c", "140", str(executable), str(copied), str(RUN / "export")], env, 600, executable, {140}))
        exported = json.loads((RUN / "export/completion.json").read_text())
        assert exported["status"] == "PASS_MATCHING_CURRENT_READ_ONLY_STATE_EXPORT"
        assert exported["owner_state_loads"] == 1 and exported["license_guard_passed"] is True
        for key in ("event_evaluations", "generation_calls", "preprocessing_calls", "spin_sum_calls", "channel_construction_calls", "backend_activation_calls"):
            assert exported[key] == 0
        for row in S["files"]:
            assert sha(copied / row["relative"]) == row["sha256"]
        guard()
        no_target_writers()
        result.update(status="PASS_ONE_CANDIDATE3_MATCHED_READ_ONLY_FULL_STATE_EXPORT_NOT_SNAPSHOT_ACCEPTANCE",
                      outputs=[{"path": str(p), "sha256": sha(p), "bytes": p.stat().st_size} for p in sorted((RUN / "export").rglob("*")) if p.is_file()],
                      original_state_and_copy_unchanged=True, sources_and_dependencies_unchanged=True,
                      actual_direct_rustc_invocations=1, actual_state_loads=1, numerical_samples=0, generation_invocations=0)
        code = 0
    except BaseException as error:
        traceback.print_exc()
        result.update(status="FAILED_NO_RETRY", error_type=type(error).__name__, error=str(error))
    finally:
        result.update(returncode=code, finished_utc=now(), resource_end=resources())
        atomic(RUN / "completion.json", result)
    return code


if __name__ == "__main__":
    raise SystemExit(main())

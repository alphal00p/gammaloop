"""Prepare exact prior decoder body with actual candidate3 writer dependencies."""
import ast
import copy
import hashlib
import json
from pathlib import Path
import shutil

HERE = Path(__file__).resolve().parent
CAND = HERE.parent
OUT = HERE.parents[4]
OLD = OUT / "api-adapted-v2"
P = json.loads((CAND / "build-plan.json").read_text())
CM = json.loads((CAND / "control-manifest.json").read_text())
state = CAND / "source/tests/artifacts/gl20_multichannel_local_inspect_event_snapshot"


def record(path):
    path = Path(path).resolve()
    with path.open("rb") as stream:
        checksum = hashlib.file_digest(stream, "sha256").hexdigest()
    return {"path": str(path), "sha256": checksum, "bytes": path.stat().st_size}


assert record(OLD / "decoder.rs")["sha256"] == "4640b199ccfb1b5879020add8a170642142a5795418184a52ce72a1f3a6ec2cd"
shutil.copy2(OLD / "decoder.rs", HERE / "decoder.rs")
old = json.loads((OLD / "dependency-authentication.json").read_text())
selected = copy.deepcopy(old["selected_externs"])
for row in selected:
    if row["crate"] in ("gammaloop_api", "gammalooprs"):
        stage = next(s for s in P["stages"] if s["stage"] == row["crate"])
        row["original_artifact_provenance"] = row["rlib"]
        row["rlib"] = record(stage["output"])
actual = []
for stage in P["stages"]:
    authenticated = json.loads((CAND / "run1" / ("artifact-" + stage["stage"] + ".json")).read_text())
    assert authenticated == record(stage["output"])
    actual.append({"owner": stage["stage"], **authenticated})
D = {"schema": "gl20.candidate3-actual-writer-decoder-dependencies.v1", "compiler": P["compiler"], "linker": P["linker"],
     "selected_externs": selected, "actual_candidate_writer_artifacts": actual,
     "actual_candidate_writer_build_plan": record(CAND / "build-plan.json"),
     "actual_candidate_writer_source_freeze": record(CAND / "source-freeze.json"),
     "actual_candidate_writer_compiler_record": record(CAND / "run1/actual-compiler.json"),
     "actual_candidate_test_terminal": record(CAND / "run1/original-gl20-regression-terminal.json"),
     "original_matching_cargo_dependency_closure": old["selected_transitive_closure"],
     "original_dependency_authentication": record(OLD / "dependency-authentication.json"),
     "native_archives": P["native_archives"], "helper": record(HERE / "decoder.rs"),
     "selection": "Reuse prior selected seven extern aliases. Gamma/API are rebound to exact candidate3 actual writer artifacts, with its private library directory first for all eight actual modified Graph reverse-closure owners. Original matching dependencies and fingerprints remain sealed."}
(HERE / "dependency-authentication.json").write_text(json.dumps(D, indent=2) + "\n")
files, auxiliary = [], []
for path in sorted(state.rglob("*")):
    if not path.is_file():
        continue
    row = {**record(path), "relative": str(path.relative_to(state))}
    (auxiliary if "logs" in path.relative_to(state).parts else files).append(row)
assert len(files) == 12
S = {"schema": "gl20.candidate3-retained-postprocess-state.v1", "root": str(state), "files": files, "auxiliary_logs_unchanged": auxiliary,
     "writer_scope": "Completed single original candidate3 GL20 test. It failed the unchanged snapshot; state is retained after postprocessing before original evaluation. No fresh generation or evaluation in this decode."}
(HERE / "retained-state-authentication.json").write_text(json.dumps(S, indent=2) + "\n")
starter = Path('/shared/codex-1/vakint_rustred/workspace/5l-push/validation/gl20-native-frame-f767-readonly/current-matched-decode-and-compare-20261026/ct-real-point-diagnostic/generation-frame-witness/candidate-paired-external-momenta-restoration/regression/matched-state-decode/start_decode.py').read_text().replace("current-paired-state-decode", "candidate3-matched-state-decode")
ast.parse(starter)
(HERE / "start_decode.py").write_text(starter)
launch = (CAND / "launch.sh").read_text().replace(str(CAND / "run_regression.py"), str(HERE / "run_decode.py"))
(HERE / "launch.sh").write_text(launch)
ast.parse((HERE / "run_decode.py").read_text())
paths = [HERE / name for name in ("prepare_decode.py", "run_decode.py", "start_decode.py", "launch.sh", "decoder.rs", "dependency-authentication.json", "retained-state-authentication.json")]
paths += [CAND / "build-plan.json", CAND / "source-freeze.json", CAND / "control-manifest.json", CAND / "run1/completion.json", Path(CM["original_source_freeze"])]
M = {"schema": "gl20.candidate3-exact-body-matched-readonly-decode.v1", "unit": "gl20-candidate3-matched-state-readonly-decode-20261026.service",
     "taskset": CM["taskset"], "writer_build_plan": str(CAND / "build-plan.json"), "writer_source_freeze": str(CAND / "source-freeze.json"),
     "original_source_freeze": CM["original_source_freeze"], "controls": [record(path) for path in paths],
     "scope": "One exact previous 4640 decoder body compiled with current 1.98.1 actual candidate3 Gamma/API/FeynKit writer dependencies. One StateLoad/export on a byte-copy. No sample evaluation, generation, preprocessing, backend activation, retries or production pin.",
     "state_load_disclosure": "State::load restores Symbolica StateMap, rehydrates dependent model scalar values and saved card, initializes fixed Vakint topology registry. Stored evaluator IR is exported but never invoked.",
     "resources": {"setup_cpus": [145, 146], "decode_cpus": [140], "setup_seconds": 1800, "decode_seconds": 600,
                   "memory_max_bytes": 17179869184, "memory_swap_max": 0, "minimum_host_available_bytes": 50000000000, "math_threads": 1, "retries": 0},
     "admission_scope": "Root withdrew new 5L PIDFD admission infrastructure for this small non5L read-only StateLoad. Existing qualified source/dependency/group/deadline controller reused with fresh host-available check and swap0. Live q0 guard untouched."}
with (HERE / "control-manifest.json").open("x") as stream:
    json.dump(M, stream, indent=2)
    stream.write("\n")
print(json.dumps({"manifest": record(HERE / "control-manifest.json"), "helper": record(HERE / "decoder.rs"), "state_files": len(files), "writer_artifacts": len(actual)}))

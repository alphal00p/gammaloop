#!/usr/bin/env python3
"""Inspect retained eager IR only. No expressions or numerical samples are evaluated."""
import collections
import hashlib
import json
from pathlib import Path
import re
import resource

resource.setrlimit(resource.RLIMIT_CPU, (60, 60))
resource.setrlimit(resource.RLIMIT_AS, (2 * 1024**3, 2 * 1024**3))
HERE = Path(__file__).resolve().parent
OUT = next(p for p in HERE.parents if p.name == "current-matched-decode-and-compare-20261026")
BASE = OUT.parent
EXPORTS = {
    "historical": BASE / "historical-generation-proposal/prepared-source-and-driver/historical-matched-decoder-20261026/controller-v2/run1/export/process-0-cross-section.json",
    "candidate3": HERE.parent / "matched-state-decode/run1/export/process-0-cross-section.json",
}
TRACE = OUT / "ct-real-point-diagnostic/historical/parsed-trace/dispatches.jsonl"
Q_OLD = "gammalooprs::{spenso::rank1,spenso::tensor}::Q("
Q_NEW = "gammalooprs::{spenso::rank1,spenso::tensor,spenso::component-labels:subscript,spenso::tensor-label:q}::Q("
INSTRUCTION = re.compile(r"\(([A-Za-z]+)\((.*?)\), (Any|Real|Imag|PartialReal\(\d+\))\)")
COMPLEX = re.compile(r"\(F\(([^()]*)\)\+F\(([^()]*)\)i\)")


def digest(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, separators=(",", ":")).encode()).hexdigest()


def record(path):
    return {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest(), "bytes": path.stat().st_size}


def canonical_name(name):
    # This narrow presentation correspondence is explicitly separate from exact symbol equality.
    return name.replace(Q_NEW, Q_OLD)


def bindings(pb):
    names = {}
    for group in pb["ordered_pairs"]:
        assert len(group["parameters"]) == group["end"] - group["start"]
        for i, name in enumerate(group["parameters"], group["start"]):
            assert i not in names
            names[i] = name
    assert set(names) == set(range(len(pb["stored_value_rows"][0])))
    return names


def parse(debug):
    pc = int(re.search(r"param_count: (\d+)", debug)[1])
    reserved = int(re.search(r"reserved_indices: (\d+)", debug)[1])
    stack_text = debug.split("stack: ", 1)[1].split(", param_count:", 1)[0]
    stack = COMPLEX.findall(stack_text)
    assert len(stack) >= reserved
    assert len(COMPLEX.sub("", stack_text).strip("[], ")) == 0
    section = debug.split("instructions: [", 1)[1].split("], result_indices:", 1)[0]
    instructions = []
    pos = 0
    for match in INSTRUCTION.finditer(section):
        assert not section[pos:match.start()].strip(" ,"), section[pos:match.start()][:100]
        op, raw_args, phase = match.groups()
        ns = list(map(int, re.findall(r"-?\d+", raw_args)))
        d = {"index": len(instructions), "op": op, "phase": phase, "raw": match[0]}
        if op in ("Add", "Mul"):
            d.update(output=ns[0], sources=ns[1:])
        elif op == "Pow":
            assert len(ns) == 3
            d.update(output=ns[0], sources=ns[1:2], exponent=ns[2])
        elif op == "Powf":
            d.update(output=ns[0], sources=ns[1:])
        elif op == "BuiltinFun":
            assert len(ns) == 2
            d.update(output=ns[0], sources=ns[1:], function=raw_args.split(",")[1].strip())
        elif op == "IfElse":
            assert len(ns) == 2
            d.update(sources=ns[:1], target=ns[1])
        elif op in ("Goto", "Label"):
            assert len(ns) == 1
            d.update(sources=[], target=ns[0])
        elif op == "Join":
            assert len(ns) == 4
            d.update(output=ns[0], sources=ns[1:])
        else:
            raise AssertionError(f"Unreviewed instruction {op}")
        instructions.append(d)
        pos = match.end()
    assert not section[pos:].strip(" ,")
    result = json.loads(debug.split("result_indices: ", 1)[1].split(", external_fns:", 1)[0])
    for ins in instructions:
        if ins["op"] in ("Goto", "IfElse"):
            target = instructions[ins["target"]]
            assert target["op"] == "Label" and target["target"] == ins["target"]
    return {"param_count": pc, "reserved_indices": reserved, "stack": stack,
            "instructions": instructions, "result_indices": result,
            "external_functions_debug": debug.split(", external_fns: ", 1)[1].removesuffix(" }")}


def reads(instructions, names):
    occurrences = collections.defaultdict(list)
    for ins in instructions:
        for slot in ins["sources"]:
            if slot in names:
                occurrences[slot].append(ins["index"])
    return [{"slot": slot, "name": names[slot], "read_occurrences": len(indices),
             "instruction_indices": indices} for slot, indices in sorted(occurrences.items())]


def specialize_observed_one(program, owner):
    """Follow stored control addresses only. Never compute arithmetic/other conditions."""
    instructions = program["instructions"]
    active, controls = [], []
    index = 0
    while index < len(instructions):
        ins = instructions[index]
        op = ins["op"]
        if op == "IfElse":
            assert owner == "historical" and ins["sources"] == [16]
            controls.append({"instruction_index": index, "instruction": ins["raw"],
                             "observed_condition": "complex one at historical input16",
                             "selected": "fall through to true branch", "unselected_else_start": ins["target"]})
        elif op == "Goto":
            controls.append({"instruction_index": index, "instruction": ins["raw"], "selected_target": ins["target"]})
            index = ins["target"]
            continue
        elif op == "Label":
            pass
        elif op == "Join":
            assert owner == "historical" and ins["sources"][0] == 16
            controls.append({"instruction_index": index, "instruction": ins["raw"],
                             "selected_true_source_register": ins["sources"][1],
                             "unselected_false_source_register": ins["sources"][2]})
            active.append({**ins, "op": "ObservedTrueAlias", "sources": ins["sources"][1:2]})
        else:
            active.append(ins)
        index += 1
    assert not any(i["op"] in ("IfElse", "Goto", "Label", "Join") for i in active)
    return active, controls


def provenance(program, active, names):
    """Construct a versioned ordered def-use DAG. No algebraic simplification/arithmetic."""
    nodes = []
    registers = {}
    for slot in range(program["reserved_indices"]):
        if slot < program["param_count"]:
            payload = ["input", canonical_name(names[slot])]
            node = {"kind": "input", "slot": slot, "name": names[slot]}
        else:
            payload = ["constant", *program["stack"][slot]]
            node = {"kind": "constant", "slot": slot, "literal": program["stack"][slot]}
        registers[slot] = len(nodes)
        nodes.append({**node, "sha256": digest(payload), "children": []})
    for ins in active:
        children = [registers[s] for s in ins["sources"]]
        if ins["op"] == "ObservedTrueAlias":
            registers[ins["output"]] = children[0]
            continue
        payload = [ins["op"], ins.get("function"), ins.get("exponent"), ins["phase"],
                   [nodes[c]["sha256"] for c in children]]
        registers[ins["output"]] = len(nodes)
        nodes.append({"kind": "operation", "instruction_index": ins["index"], "op": ins["op"],
                      "function": ins.get("function"), "exponent": ins.get("exponent"),
                      "raw": ins["raw"], "sha256": digest(payload), "children": children})
    roots = [registers[r] for r in program["result_indices"]]
    pending, live = list(roots), set()
    while pending:
        node = pending.pop()
        if node not in live:
            live.add(node)
            pending.extend(nodes[node]["children"])
    inputs = sorted((nodes[n] for n in live if nodes[n]["kind"] == "input"), key=lambda n: n["slot"])
    constants = sorted((nodes[n] for n in live if nodes[n]["kind"] == "constant"), key=lambda n: n["slot"])
    operations = sorted((nodes[n] for n in live if nodes[n]["kind"] == "operation"), key=lambda n: n["instruction_index"])
    summary = {
        "method": "Ordered def-use DAG with versioned registers; preserves operand order, n-ary grouping, builtin name, exponent, complex phase and literal constant strings. Only source-validated Q printing-head correspondence is applied to cross-owner fingerprints. No commutation, reassociation, arithmetic or numerical evaluation.",
        "result_dag_sha256": [nodes[r]["sha256"] for r in roots],
        "result_operations": [{k: nodes[r][k] for k in ("op", "instruction_index", "raw", "sha256")} for r in roots],
        "live_operation_nodes": len(operations),
        "live_operation_counts": dict(collections.Counter(n["op"] for n in operations)),
        "root_input_dependencies": [{k: n[k] for k in ("slot", "name")} for n in inputs],
        "root_constant_dependencies": [{k: n[k] for k in ("slot", "literal")} for n in constants],
        "root_dependency_scope": "Exact syntactic dependency for this retained straight-line path; historical path selected solely by all32 already-recorded main/residue buffers containing override_if=one. It is not a proof that an input has nonzero mathematical influence at a particular sample.",
    }
    return summary, {"nodes": nodes, "operations": operations, "live": live}


def short_node(node, dag):
    children = []
    for c in node["children"]:
        n = dag["nodes"][c]
        children.append({k: n[k] for k in ("kind", "sha256", "slot", "name", "literal", "op", "instruction_index") if k in n})
    return {"instruction_index": node["instruction_index"], "instruction": node["raw"],
            "ordered_dag_sha256": node["sha256"], "children": children}


def main():
    states = {}
    for owner, path in EXPORTS.items():
        process = json.loads(path.read_text())
        assert len(process["runtime_graph_terms"]) == 1
        term = process["runtime_graph_terms"][0]
        states[owner] = {"record": record(path), "term": term, "names": bindings(term["param_builder"])}
    h, c = states["historical"], states["candidate3"]
    cuts = lambda t: [int(x) for x in re.findall(r"cuts: \[CutId\((\d+)\)\]", t["cut_groups_debug"])]
    assert cuts(h["term"]) == cuts(c["term"]) == [1, 2, 0, 3]
    trace_rows = [json.loads(line) for line in TRACE.open()]
    large_trace_rows = [d for d in trace_rows if d["parameter_entry_count"] == 193]
    assert len(large_trace_rows) == 32
    assert all(d["params_complex_f64_bits"][16] == [4607182418800017408, 0] for d in large_trace_rows)
    trace_evidence = {"input": record(TRACE), "all_dispatches": len(trace_rows),
                      "all_193_parameter_dispatches": len(large_trace_rows),
                      "slot16_unique_bits": [[4607182418800017408, 0]],
                      "slot16_interpretation": "complex1.0+0.0i, not the builder initialization zero",
                      "roles": dict(collections.Counter(d["context"]["role"] for d in large_trace_rows)),
                      "calls": [{"call_id": d["call_id"], "trace_line": d["trace_line"], "role": d["context"]["role"],
                                 "slot16_bits": d["params_complex_f64_bits"][16]} for d in large_trace_rows]}
    hn, cn = h["names"], c["names"]
    reverse_current = {canonical_name(n): i for i, n in cn.items()}
    assert len(reverse_current) == len(cn)
    remap = []
    for old_slot, name in hn.items():
        if old_slot == 16:
            assert name == "gammalooprs::{}::override_if"
            continue
        current_slot = reverse_current[canonical_name(name)]
        remap.append({"historical_slot": old_slot, "candidate3_slot": current_slot,
                      "historical_name": name, "candidate3_name": cn[current_slot],
                      "correspondence": "exact name" if name == cn[current_slot] else "narrow Q presentation tags"})
    assert len(remap) == 192 and len({r["candidate3_slot"] for r in remap}) == 192
    report = {"schema": "gl20.c3.retained-stored-eager-program-comparison.v1",
              "scope": "Stored main evaluator stacks only, runtime_graph_terms[0], four cut groups. Private CT evaluator programs are not included in the matching decoder JSON.",
              "method": "Bounded pure-Python JSON/text parsing and ordered def-use analysis only. No Rust, state loading, expression evaluation, generation, sampled substitution, floating-point arithmetic or model calculation.",
              "inputs": {owner: s["record"] for owner, s in states.items()},
              "cut_group_identity_join": {"historical_and_candidate3_cut_ids": [1, 2, 0, 3], "map": [0, 1, 2, 3]},
              "override_observation": trace_evidence, "rows": []}
    dags = {}
    for owner, state in states.items():
        names = state["names"]
        for group, stacks in enumerate(state["term"]["stored_evaluator_stacks"]):
            assert len(stacks) == 1
            for kind in ("single_parametric", "summed_function_map"):
                evaluator = stacks[0]["stack"][kind]
                debug = evaluator["stored_f64_eager_instruction_data_debug"]
                p = parse(debug)
                assert p["param_count"] == len(names)
                all_reads = reads(p["instructions"], names)
                read_by_slot = {r["slot"]: r for r in all_reads}
                couplings = [r for r in all_reads if r["name"].startswith("UFO::{}::GC_")]
                row = {"owner": owner, "cut_group": group, "kind": kind,
                       "debug_sha256": hashlib.sha256(debug.encode()).hexdigest(), "debug_characters": len(debug),
                       "param_count": p["param_count"], "reserved_indices": p["reserved_indices"],
                       "instruction_count": len(p["instructions"]), "instruction_counts": dict(collections.Counter(i["op"] for i in p["instructions"])),
                       "full_instruction_parse_coverage": True,
                       "coupling_input_reads": couplings,
                       "GC57_GC63_reads": [{"slot": slot, "name": name, "read_occurrences": read_by_slot.get(slot, {}).get("read_occurrences", 0)} for slot, name in names.items() if name.endswith(("::GC_57", "::GC_63"))],
                       "all_input_reads": all_reads,
                       "constant_slots": [{"slot": slot, "literal": p["stack"][slot]} for slot in range(p["param_count"], p["reserved_indices"])],
                       "result_indices": p["result_indices"], "external_functions_debug": p["external_functions_debug"],
                       "function_replacements": [{"lhs": f["lhs"], "rhs_sha256": hashlib.sha256(f["rhs"].encode()).hexdigest(), "rhs_characters": len(f["rhs"]), "tags": f["tags"], "arguments_debug": f["arguments_debug"]} for f in evaluator["stored_function_replacements"]]}
                if kind == "summed_function_map":
                    active, controls = specialize_observed_one(p, owner)
                    summary, dag = provenance(p, active, names)
                    row.update(observed_main_path_controls=controls,
                               observed_main_path_arithmetic_instructions=sum(i["op"] != "ObservedTrueAlias" for i in active),
                               observed_main_path_counts=dict(collections.Counter(i["op"] for i in active)),
                               observed_main_path_input_reads=reads(active, names), ordered_provenance=summary)
                    dags[(owner, group)] = dag
                report["rows"].append(row)
    comparisons = []
    for group in range(4):
        old, new = dags[("historical", group)], dags[("candidate3", group)]
        old_hashes = {old["nodes"][n]["sha256"] for n in old["live"]}
        new_hashes = {new["nodes"][n]["sha256"] for n in new["live"]}
        comparisons.append({"cut_group": group,
                            "common_exact_ordered_subtree_hashes_under_Q_printing_correspondence": len(old_hashes & new_hashes),
                            "historical_unique_live_subtree_hashes": len(old_hashes - new_hashes),
                            "candidate3_unique_live_subtree_hashes": len(new_hashes - old_hashes),
                            "earliest_historical_live_operations_whose_exact_ordered_subtree_is_absent_current": [short_node(n, old) for n in old["operations"] if n["sha256"] not in new_hashes][:5],
                            "earliest_candidate3_live_operations_whose_exact_ordered_subtree_is_absent_historical": [short_node(n, new) for n in new["operations"] if n["sha256"] not in old_hashes][:5],
                            "caveat": "Different DAG fingerprints/operation groupings establish stored-program structural differences, not mathematical nonidentity, floating-point inequality or a causal explanation for a snapshot difference."})
    report["ordered_program_comparisons"] = comparisons
    report["findings"] = [
        "Historical override_if slot16 is builder-initialized zero but ALL32 retained main/residue dispatch buffers contain complex one after the old runtime all-orientation override. Pruning it as zero would select the wrong program branch.",
        "Following only that proven-one branch removes all historical conditional instructions from the active main path. The1008–1680 old IfElse/Join total counts therefore overstate the actual original-point path complexity.",
        "GC_57 and GC_63 have zero input-read occurrences in every retained main single-parametric and summed-function-map program, historical and C3. Only GC_2,GC_3,GC_11,GC_94 coupling slots are read; root dependencies are also reported for actual summed paths.",
        "The old and C3 stored pi literals are exactly3.141592653589793; new external symbolica_pi metadata alone does not establish a different retained eager constant.",
        "The stored main eager programs and ordered def-use DAGs differ after correct override selection and parameter-name remapping. This analysis does not evaluate or attribute the remaining snapshot rounding differences.",
    ]
    (HERE / "stored-evaluator-program-comparison.json").write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n")
    mapping = {"schema": "gl20.c3.retained-main-input-name-remap.v1", "inputs": report["inputs"],
               "method": "Exact parameter names except the17 explicitly labelled Q printing-head correspondences; stored-frame equality is supplied by independent graph/routing/cut evidence. No old-to-new positional shift is assumed for UFO ordering.",
               "removed_historical_slot": {"slot": 16, "name": hn[16], "builder_stored_value": h["term"]["param_builder"]["stored_value_rows"][0][16], "actual_recorded_main_residue_value_bits": [4607182418800017408, 0]},
               "mapping_count": len(remap), "exact_name_count": sum(r["correspondence"] == "exact name" for r in remap),
               "Q_presentation_correspondence_count": sum(r["correspondence"] != "exact name" for r in remap), "mapping": remap,
               "limitations": "A future authorized probe can feed the same retained old193-entry buffer to the old eager object and a192-entry name-remapped buffer to the C3 eager object. That would compare programs under common inputs, not prove that C3 runtime constructed identical private sample buffers. No probe is run here."}
    (HERE / "parameter-input-remap.json").write_text(json.dumps(mapping, indent=2, ensure_ascii=False) + "\n")
    (HERE / "override-trace-observation.json").write_text(json.dumps(trace_evidence, indent=2, ensure_ascii=False) + "\n")
    print(json.dumps({"report": record(HERE / "stored-evaluator-program-comparison.json"), "remap": record(HERE / "parameter-input-remap.json"),
                      "summed_paths": [{"owner": r["owner"], "cut_group": r["cut_group"], "active_arithmetic": r["observed_main_path_arithmetic_instructions"], "root_live": r["ordered_provenance"]["live_operation_nodes"], "root_couplings": [p["name"] for p in r["ordered_provenance"]["root_input_dependencies"] if p["name"].startswith("UFO::{}::GC_")]} for r in report["rows"] if r["kind"] == "summed_function_map"]}, indent=2))


if __name__ == "__main__":
    main()

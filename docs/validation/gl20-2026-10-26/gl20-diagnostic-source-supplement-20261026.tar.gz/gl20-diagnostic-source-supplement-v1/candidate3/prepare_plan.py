"""Direct exact-profile Graph reverse-closure build; no compilation or execution."""
import copy
import hashlib
import json
from pathlib import Path
import re
import tomllib

HERE = Path(__file__).resolve().parent
GEN = HERE.parent.parent
OUT = GEN.parent.parent
PREVIOUS = GEN / "candidate-paired-external-momenta-restoration/regression"
BASE = json.loads((PREVIOUS / "build-plan.json").read_text())
AUTH = json.loads((OUT / "api-adapted-v2/dependency-authentication.json").read_text())
SOURCE = HERE / "source"
TARGET = Path(BASE["frozen_target_read_only"])
RUN = HERE / "run1"
METADATA = "gl20_physical_master_and_native_hedge_root"
BUILD_LOG = OUT.parent / "current-full-runtime-save-oracle/run1/build.log"


def record(path):
    path = Path(path).resolve()
    with path.open("rb") as stream:
        checksum = hashlib.file_digest(stream, "sha256").hexdigest()
    return {"path": str(path), "sha256": checksum, "bytes": path.stat().st_size}


messages = []
for line in BUILD_LOG.read_text().splitlines():
    try:
        messages.append(json.loads(line))
    except json.JSONDecodeError:
        pass
markers = {}
for path in (TARGET / ".fingerprint").glob("*/lib-*"):
    if path.suffix:
        continue
    raw = path.read_text().strip()
    if not re.fullmatch("[0-9a-f]{16}", raw):
        continue
    markers.setdefault((path.name.removeprefix("lib-"), int.from_bytes(bytes.fromhex(raw), "little")), []).append(path)


def dependency(alias, number):
    found = markers.get((alias, number), [])
    if not found:
        found = [p for (name, value), paths in markers.items() if value == number for p in paths]
    assert len(found) == 1, (alias, len(found))
    marker = found[0]
    name, suffix = marker.name.removeprefix("lib-"), marker.parent.name.rsplit("-", 1)[1]
    options = list((TARGET / "deps").glob(f"lib{name}-{suffix}.*"))
    artifact = next((p for p in options if p.suffix == ".rlib"), None)
    if artifact is None and name == "gammaloop_api":
        artifact = TARGET / "deps/libgammaloop_api.rlib"
    if artifact is None:
        artifact = next(p for p in options if p.suffix == ".so")
    return {"extern_alias": alias, "actual_crate_name": name, "fingerprint_value_u64": number,
            "fingerprint_marker": record(marker), "fingerprint_json": record(marker.with_suffix(".json")), "artifact": record(artifact)}


selected = {}
for row in AUTH["selected_transitive_closure"]:
    marker = Path(row["fingerprint_marker"]["path"])
    num = int.from_bytes(bytes.fromhex(marker.read_text().strip()), "little")
    selected[(row["crate"], num)] = (row, json.loads(Path(row["fingerprint_json"]["path"]).read_text()))
seed = [key for key in selected if key[0] == "feynkit_graph"]
assert len(seed) == 1
affected = set(seed)
while True:
    added = {key for key, (_, fp) in selected.items() if key not in affected and any((dep[1], dep[3]) in affected for dep in fp["deps"])}
    if not added:
        break
    affected |= added
expected = {"feynkit_graph", "feynkit_tensor", "feynkit_amplitude", "feynkit_cff", "vakint", "feynkit_generator", "gammalooprs", "gammaloop_api"}
assert {key[0] for key in affected} == expected
order = []
pending = set(affected)
while pending:
    ready = sorted(key for key in pending if not any((dep[1], dep[3]) in pending for dep in selected[key][1]["deps"]))
    assert ready
    for key in ready:
        order.append(key)
        pending.remove(key)

owned = {}
generated = []
workspace = tomllib.loads((SOURCE / "Cargo.toml").read_text()).get("workspace", {}).get("package", {})


def make_stage(name, fp_path, package_folder, source_relative, is_test=False, original_target=None):
    fp = json.loads(Path(fp_path).read_text())
    deps = [dependency(row[1], row[3]) for row in fp["deps"] if not row[1].startswith("build_script_")]
    artifacts = [row for row in messages if row.get("reason") == "compiler-artifact" and row["target"]["name"] == (original_target or name)]
    assert len(artifacts) == 1, (name, len(artifacts))
    original = artifacts[0]
    profile = original["profile"]
    package = tomllib.loads((SOURCE / package_folder / "Cargo.toml").read_text())["package"]
    def field(key, default=""):
        value = package.get(key, default)
        return workspace[key] if isinstance(value, dict) and value.get("workspace") else value
    features, declared = json.loads(fp["features"]), json.loads(fp["declared_features"])
    out = RUN / ("bin" if is_test else "lib") / (name if is_test else f"lib{name}-{METADATA}.rlib")
    source = SOURCE / source_relative
    argv = [BASE["compiler"]["path"], "--crate-name", name, "--edition=" + original["target"]["edition"],
            "--test" if is_test else "--crate-type=rlib", "--emit=link", "-C", "opt-level=" + profile["opt_level"],
            "-C", "debuginfo=0", "-C", "debug-assertions=" + ("on" if profile["debug_assertions"] else "off"),
            "-C", "overflow-checks=" + ("on" if profile["overflow_checks"] else "off"), "-C", "embed-bitcode=no", "-C", "codegen-units=256",
            "-C", "metadata=" + METADATA, "-C", "linker=" + BASE["linker"]["path"],
            "--check-cfg", "cfg(docsrs,test)", "--check-cfg", "cfg(feature, values(" + ", ".join(json.dumps(v) for v in declared) + "))",
            "-L", "dependency=" + str(RUN / "lib"), "-L", "dependency=" + str(TARGET / "deps")]
    for feature in features:
        argv += ["--cfg", "feature=" + json.dumps(feature)]
    for path in BASE["native_link_search_paths"]:
        argv += ["-L", "native=" + path]
    for row in deps:
        if row["extern_alias"] in owned:
            row["original_artifact"] = copy.deepcopy(row["artifact"])
            row["artifact"] = {"path": owned[row["extern_alias"]], "sha256": "TO_BE_AUTHENTICATED_AFTER_BUILD", "bytes": None}
        argv += ["--extern", row["extern_alias"] + "=" + row["artifact"]["path"]]
    if name == "gammaloop_integration_tests":
        argv += ["-l", "static=fjcore_test", "-l", "stdc++", "-l", "stdc++"]
    argv += [str(source), "-o", str(out)]
    env = BASE["stages"][0]["environment_overlay"].copy()
    for key in list(env):
        if key.startswith("CARGO_FEATURE_"):
            env.pop(key)
    version, _, pre = str(field("version")).partition("-")
    major, minor, patch = version.split(".")
    env.update(CARGO_MANIFEST_DIR=str(SOURCE / package_folder), CARGO_MANIFEST_PATH=str(SOURCE / package_folder / "Cargo.toml"),
               CARGO_CRATE_NAME=name, CARGO_PKG_NAME=str(field("name")), CARGO_PKG_VERSION=str(field("version")),
               CARGO_PKG_VERSION_MAJOR=major, CARGO_PKG_VERSION_MINOR=minor, CARGO_PKG_VERSION_PATCH=patch, CARGO_PKG_VERSION_PRE=pre,
               CARGO_PKG_DESCRIPTION=str(field("description")), CARGO_PKG_README=str(field("readme")),
               CARGO_PKG_HOMEPAGE=str(field("homepage")), CARGO_PKG_REPOSITORY=str(field("repository")),
               CARGO_PKG_LICENSE=str(field("license")), CARGO_PKG_LICENSE_FILE=str(field("license-file")),
               CARGO_PKG_RUST_VERSION=str(field("rust-version")),
               CARGO_PKG_AUTHORS=":".join(field("authors", [])), OUT_DIR=str(RUN / "out" / name))
    for feature in features:
        env["CARGO_FEATURE_" + feature.upper().replace("-", "_")] = "1"
    scripts = [row for row in messages if row.get("reason") == "build-script-executed" and row["package_id"] == original["package_id"]]
    assert len(scripts) <= 1
    if scripts:
        script = scripts[0]
        assert (not script["cfgs"] and not script["linked_paths"] and not script["linked_libs"]) or field("name") == "gammaloop-integration-tests"
        for key, value in script["env"]:
            env[key] = value
        env["OUT_DIR"] = script["out_dir"]
        if name == "vakint":
            for path in Path(script["out_dir"]).rglob("*"):
                if path.is_file():
                    generated.append(record(path))
                    if path.suffix == ".rs":
                        for included in re.findall(r'include_bytes!\("([^\"]+)"\)', path.read_text()):
                            generated.append(record(included))
    return {"stage": name, "argv": argv, "cwd": str(SOURCE / package_folder), "source": str(source), "output": str(out),
            "environment_overlay": env, "dependencies": deps, "selected_fingerprint": record(fp_path),
            "original_profile": profile, "original_features": features, "original_declared_features": declared,
            "original_cargo_artifact": original, "reused_build_script_output": scripts[0] if scripts else None,
            "directories_controller_must_create": [str(out.parent), str(RUN / "out" / name)]}


stages = []
for key in order:
    row, fp = selected[key]
    original = next(r for r in messages if r.get("reason") == "compiler-artifact" and r["target"]["name"] == key[0])
    original_path = Path(original["target"]["src_path"])
    original_source = Path(BASE["original_source"])
    relative = original_path.relative_to(original_source)
    folder = str(relative.parent.parent)
    stage = make_stage(key[0], row["fingerprint_json"]["path"], folder, str(relative))
    owned[key[0]] = stage["output"]
    stages.append(stage)
helper = make_stage("gammaloop_integration_tests", TARGET / ".fingerprint/gammaloop-integration-tests-d0ffee5b6cc2833f/lib-gammaloop_integration_tests.json", "tests", "tests/src/lib.rs")
owned["gammaloop_integration_tests"] = helper["output"]
harness = make_stage("test_evaluation_api", TARGET / ".fingerprint/gammaloop-integration-tests-5ea1db0153a4c6fe/test-integration-test-test_evaluation_api.json", "tests", "tests/tests/test_evaluation_api.rs", True)
stages += [helper, harness]


def focused(stage, label):
    result = copy.deepcopy(stage)
    result["stage"] = label
    result["argv"][result["argv"].index("--crate-type=rlib")] = "--test"
    result["output"] = str(RUN / "bin" / label)
    result["argv"][result["argv"].index("-o") + 1] = result["output"]
    result["argv"] = [v.replace("metadata=" + METADATA, "metadata=" + METADATA + "_" + label) for v in result["argv"]]
    result["directories_controller_must_create"].append(str(RUN / "bin"))
    return result


graph_focused = focused(stages[0], "focused_graph_tests")
assert stages[0]["stage"] == "feynkit_graph"
gen_focused = focused(next(stage for stage in stages if stage["stage"] == "feynkit_generator"), "focused_generator_tests")
serde_json = next(copy.deepcopy(row) for row in helper["dependencies"] if row["extern_alias"] == "serde_json")
gen_focused["dependencies"].append(serde_json)
gen_focused["argv"] += ["--extern", "serde_json=" + serde_json["artifact"]["path"]]
plan = copy.deepcopy(BASE)
plan.update(schema="gl20.candidate3-physical-frame-and-native-root-direct-build.v1", owner="candidate3-physical-master-and-native-root",
            private_source=str(SOURCE), run_root=str(RUN), private_library_directory=str(RUN / "lib"), metadata_prefix=METADATA,
            stages=stages, focused_graph_build=graph_focused, focused_generator_build=gen_focused,
            graph_focused_filter="gl20_frame_", generator_focused_filter="gl20_frame_", graph_focused_count=4, generator_focused_count=7,
            graph_reverse_closure=[key[0] for key in order], original_dependency_authentication=record(OUT / "api-adapted-v2/dependency-authentication.json"),
            reused_generated_build_inputs=generated,
            build_scope="Only eight actual selected-test reverse Graph owners, integration helper and original test harness, plus two focused owner harnesses. Original fingerprint-selected dependencies/build outputs reused; no Cargo, build scripts, workspace rebuild, worker changes or 5L physical execution.")
plan.pop("focused_build", None)
plan["notes"] = ["Original profile/features are selected from actual current f767 Cargo artifact/fingerprint evidence, with 256 CGUs inherited from ci-optim/dev policy.",
                 "Vakint source is unchanged; its existing generated vendored-data include and referenced bytes are authenticated and reused read-only. No build script or 5L physical evaluation is invoked.",
                 "Scoped raw physical semantic ordering, paired native-first-hedge routing owner, and existing paired external normalization compose the candidate. Original fixture/semantic selector/point/model/gold/assertions remain unchanged."]
(HERE / "build-plan.json").write_text(json.dumps(plan, indent=2) + "\n")
print(json.dumps({"plan": record(HERE / "build-plan.json"), "owner_order": [stage["stage"] for stage in stages],
                  "focused": [graph_focused["stage"], gen_focused["stage"]], "generated_inputs": len(generated), "compiler_invocations": len(stages) + 2}))

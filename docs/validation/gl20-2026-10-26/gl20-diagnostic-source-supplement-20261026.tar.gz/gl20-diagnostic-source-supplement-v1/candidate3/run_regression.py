"""One paired-external-momenta compatibility candidate and one complete original GL20 test."""
import argparse
import ast
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import time
import traceback

os.umask(0o077)
HERE = Path(__file__).resolve().parent
RUN = HERE / "run1"
PHASE_CWD = RUN
parser = argparse.ArgumentParser()
parser.add_argument("--manifest-sha256", required=True)
args = parser.parse_args()
PRIMITIVES = HERE.parents[3] / "run_decoder.py"
assert hashlib.sha256(PRIMITIVES.read_bytes()).hexdigest() == "0cb2a14879b12f448014f10ba8df12438a71edac58672a35baef86ac1eadcc70"
tree = ast.parse(PRIMITIVES.read_text())
for node in tree.body:
    if isinstance(node, ast.FunctionDef) and node.name in {"sha", "now", "atomic", "identity", "resources", "signal_owned_group", "reap_and_drain", "phase"}:
        source = ast.get_source_segment(PRIMITIVES.read_text(), node)
        if node.name == "phase":
            assert source.count("cwd=RUN") == 1
            source = source.replace("cwd=RUN", "cwd=PHASE_CWD")
        exec(compile(source, str(PRIMITIVES) + ":" + node.name, "exec"), globals())
assert sha(HERE / "control-manifest.json") == args.manifest_sha256
M = json.loads((HERE / "control-manifest.json").read_text())
P = json.loads((HERE / "build-plan.json").read_text())


def check_records(value, seen):
    if isinstance(value, dict):
        if isinstance(value.get("path"), str) and isinstance(value.get("sha256"), str) and re.fullmatch(r"[0-9a-f]{64}", value["sha256"]):
            if value["path"] not in seen:
                assert sha(value["path"]) == value["sha256"], value["path"]
                seen.add(value["path"])
        for child in value.values():
            check_records(child, seen)
    elif isinstance(value, list):
        for child in value:
            check_records(child, seen)


def guard():
    assert sha(HERE / "control-manifest.json") == args.manifest_sha256
    check_records(M["controls"], set())
    check_records(P, set())
    for freeze_path in (M["original_source_freeze"], M["candidate2_source_freeze"], M["candidate3_parent_source_freeze"], M["private_source_freeze"]):
        frozen = json.loads(Path(freeze_path).read_text())
        for relative, checksum in frozen["files"].items():
            assert sha(Path(frozen["source"]) / relative) == checksum, relative


def build(stage, env, deadline, result):
    global PHASE_CWD
    for directory in stage.get("directories_controller_must_create", []):
        Path(directory).mkdir(parents=True, exist_ok=True)
    stage_env = env.copy()
    stage_env.update(stage.get("environment_overlay", {}))
    PHASE_CWD = Path(stage["cwd"])
    argv = [M["taskset"], "-c", "145,146"] + stage["argv"]
    result["phases"].append(phase("build-" + stage["stage"], argv, stage_env, max(0, deadline - time.monotonic()), P["compiler"]["path"], {145, 146}))
    artifact = Path(stage["output"])
    assert artifact.is_file() and not artifact.is_symlink()
    atomic(RUN / ("artifact-" + stage["stage"] + ".json"), {"path": str(artifact), "sha256": sha(artifact), "bytes": artifact.stat().st_size})


def host_check(label):
    available = next(x for x in Path("/proc/meminfo").read_text().splitlines() if x.startswith("MemAvailable:"))
    assert int(available.split()[1]) * 1024 >= 50000000000
    cgroup = Path("/sys/fs/cgroup") / Path("/proc/self/cgroup").read_text().strip().split(":", 2)[2].lstrip("/")
    assert (cgroup / "memory.swap.max").read_text().strip() == "0"
    atomic(RUN / (label + "-host-check.json"), {"utc": now(), "MemAvailable": available, "minimum_available_bytes": 50000000000, "memory_swap_max": "0"})


def main():
    global PHASE_CWD
    assert os.environ.get("SYMBOLICA_LICENSE")
    assert M["unit"] in Path("/proc/self/cgroup").read_text() and os.environ.get("INVOCATION_ID")
    assert os.sched_getaffinity(0) == {140, 145, 146}
    start = time.monotonic()
    deadline = start + 1800
    guard()
    env = os.environ.copy()
    base = json.loads(Path(P["base_environment_source"]).read_text())[P["base_environment_key"]]
    env.update(base)
    for key in P["environment_unset"]:
        env.pop(key, None)
    for key in list(env):
        if key.startswith("INSTA_") or key.startswith("BASH_FUNC_") or key.startswith("GL20_"):
            env.pop(key)
    env.pop("GL_ALL_LOG_FILTER", None)
    env.update(NO_SYMBOLICA_OEM_LICENSE="1", SYMBOLICA_HIDE_BANNER="1", RUST_BACKTRACE="1", INSTA_UPDATE="no",
               GL_DISPLAY_FILTER="off", GL_LOGFILE_FILTER="debug", TMPDIR=str(RUN / "tmp"), XDG_CACHE_HOME=str(RUN / "cache"),
               GL_TEST_LOG_DIR=str(RUN / "logs"))
    env.update(P["thread_environment_values"])
    for folder in ("tmp", "cache", "logs", "lib", "bin"):
        (RUN / folder).mkdir(exist_ok=True)
    compiler = subprocess.check_output([P["compiler"]["path"], "-Vv"], env=env, text=True, timeout=10)
    atomic(RUN / "actual-compiler.json", {"compiler": P["compiler"], "verbose_version": compiler})
    result = {"status": "PRIVATE_PHYSICAL_MASTER_NATIVE_ROOT_VALID_CUT_FIXTURES_SETUP_NOT_REGRESSION_PASS", "manifest_sha256": args.manifest_sha256,
              "unit": M["unit"], "invocation_id": os.environ["INVOCATION_ID"], "controller": identity(os.getpid()), "phases": [], "retries": 0}
    atomic(RUN / "STARTED.json", result, exclusive=True)
    code = 1
    try:
        build(P["focused_graph_build"], env, deadline, result)
        guard()
        PHASE_CWD = Path(P["private_source"])
        host_check("pre-graph-focused")
        graph_test = Path(P["focused_graph_build"]["output"])
        result["phases"].append(phase("focused-graph-tests", [M["taskset"], "-c", "140", str(graph_test), P["graph_focused_filter"], "--nocapture", "--test-threads=1"], env, 600, graph_test, {140}))
        assert str(P["graph_focused_count"]) + " passed; 0 failed" in (RUN / "focused-graph-tests.log").read_text()
        result["focused_graph_tests_passed"] = P["graph_focused_count"]
        # Compile only the six affected support owners before Generator contracts.
        support = [stage for stage in P["stages"] if stage["stage"] not in ("gammalooprs", "gammaloop_api", "gammaloop_integration_tests", "test_evaluation_api")]
        assert len(support) == 6
        for stage in support:
            build(stage, env, deadline, result)
        build(P["focused_generator_build"], env, deadline, result)
        guard()
        PHASE_CWD = Path(P["private_source"])
        host_check("pre-generator-focused")
        generator_test = Path(P["focused_generator_build"]["output"])
        result["phases"].append(phase("focused-generator-tests", [M["taskset"], "-c", "140", str(generator_test), P["generator_focused_filter"], "--nocapture", "--test-threads=1"], env, 600, generator_test, {140}))
        assert str(P["generator_focused_count"]) + " passed; 0 failed" in (RUN / "focused-generator-tests.log").read_text()
        result["focused_generator_tests_passed"] = P["generator_focused_count"]
        # A failed focused compile or contract process prevents original evaluation.
        for stage in P["stages"]:
            if stage not in support:
                build(stage, env, deadline, result)
        guard()
        assert time.monotonic() <= deadline
        result["setup_seconds"] = time.monotonic() - start
        PHASE_CWD = Path(P["private_source"])
        host_check("pre-original-regression")
        executable = Path(P["stages"][-1]["output"])
        result["phases"].append(phase("original-gl20-regression", [M["taskset"], "-c", "140", str(executable), "--exact", P["original_test_filter"], "--nocapture", "--test-threads=1"], env, 600, executable, {140}))
        log = (RUN / "original-gl20-regression.log").read_text()
        assert "1 passed; 0 failed" in log
        guard()
        result.update(status="PASS_FOCUSED_CONTRACTS_AND_ONE_COMPLETE_ORIGINAL_GL20_SNAPSHOT_UNCHANGED_GOLD",
                      original_source_and_fixture_gold_unchanged=True, private_science_source_matches_seal=True,
                      actual_complete_original_test_invocations=1, actual_direct_rustc_invocations=12,
                      scientific_run_scope="Original fixture generation, semantic topology selector, preprocessing and evaluation under exact test assertion. No model/fixture/gold/tolerance changes or five-loop activation.")
        code = 0
    except BaseException as error:
        traceback.print_exc()
        result.update(status="FAILED_NO_RETRY", error_type=type(error).__name__, error=str(error))
        # Authenticated state/output evidence is retained even if the original snapshot fails.
        try:
            guard()
            result["source_fixture_gold_guard_after_failure"] = "PASS"
        except BaseException as guard_error:
            result["source_fixture_gold_guard_after_failure"] = str(guard_error)
    finally:
        result.update(returncode=code, finished_utc=now(), resource_end=resources())
        atomic(RUN / "completion.json", result)
    return code


if __name__ == "__main__":
    raise SystemExit(main())

"""Recover retained Insta output and compare stored JSON only; no evaluation."""
import hashlib
import json
from decimal import Decimal
from pathlib import Path

HERE = Path(__file__).resolve().parent
GEN = HERE.parents[1]
OUT = GEN.parents[1]
SOURCE = HERE / "source"
GOLD = SOURCE / "tests/tests/snapshots/test_evaluation_api__gl20_multichannel_local_inspect_events.snap"
LOG = HERE / "run1/original-gl20-regression.log"
BASELINE = OUT / "comparison/current-existing-snapshot-reconstructed-from-retained-diff.json"
HISTORICAL_GOLD = Path("/shared/codex-1/vakint_rustred/workspace/5l-push/vakint-gl20-historical-21cefae-capture/tests/tests/snapshots/test_evaluation_api__gl20_multichannel_local_inspect_events.snap")


def record(path):
    data = path.read_bytes()
    return {"path": str(path), "sha256": hashlib.sha256(data).hexdigest(), "bytes": len(data)}


def load(text):
    return json.loads(text, parse_float=Decimal)


def gold_text(path):
    lines = path.read_text().splitlines()
    assert lines[0] == "---"
    return lines[lines.index("---", 1) + 1:]


def reconstruct(original, log):
    lines, cursor, verified, added, removed = [], 1, 0, 0, 0
    for line in log.read_text().splitlines():
        if " │" not in line:
            continue
        gutter, body = line.split(" │", 1)
        if not body or not gutter.split() or not all(p.isdigit() for p in gutter.split()):
            continue
        numbers = [int(p) for p in gutter.split()]
        prefix = body[0]
        if prefix in "+-":
            assert len(numbers) == 1
            if prefix == "-":
                index = numbers[0]
                assert index >= cursor
                lines.extend(original[cursor - 1:index - 1])
                assert original[index - 1] == body[1:], (index, original[index - 1], body[1:])
                cursor = index + 1
                removed += 1
                verified += 1
            else:
                assert len(lines) + 1 == numbers[0]
                lines.append(body[1:])
                added += 1
        else:
            assert prefix == " " and len(numbers) == 2
            index, new_index = numbers
            assert index >= cursor
            lines.extend(original[cursor - 1:index - 1])
            assert original[index - 1] == body[1:]
            assert len(lines) + 1 == new_index
            lines.append(body[1:])
            cursor = index + 1
            verified += 1
    lines.extend(original[cursor - 1:])
    assert added and removed and verified
    return "\n".join(lines) + "\n", {"verified_gold_rows": verified, "added_rows": added, "removed_rows": removed}


def events(value):
    return [e for group in value["event_groups"] for e in group]


def key(event):
    cut = event["cut_info"]
    return tuple(cut["lmb_channel_edge_ids"]), cut["cut_id"]


def relation(a, b):
    return {"exact_equal": a == b,
            "components": {k: {"reference": a[k], "candidate": b[k], "exact_equal": a[k] == b[k],
                               "exact_sign_reverse": a[k].copy_negate() == b[k],
                               "exact_magnitude_equal": a[k].copy_abs() == b[k].copy_abs()}
                           for k in a}}


def main():
    original = gold_text(GOLD)
    text, reconstruction = reconstruct(original, LOG)
    candidate_path = HERE / "candidate-actual-snapshot-reconstructed.json"
    with candidate_path.open("x") as stream:
        stream.write(text)
    gold, candidate = load("\n".join(original)), load(text)
    baseline = load(BASELINE.read_text())
    historical = load("\n".join(gold_text(HISTORICAL_GOLD)))
    source_freeze = json.loads((HERE / "source-freeze.json").read_text())
    assert source_freeze["files"][str(GOLD.relative_to(SOURCE))] == record(GOLD)["sha256"]
    by = {name: {key(e): e for e in events(value)} for name,value in (("gold",gold),("baseline",baseline),("candidate",candidate),("historical_gold",historical))}
    assert all(len(v) == 16 for v in by.values())
    assert all(v.keys() == by["candidate"].keys() for v in by.values())
    rows = []
    for k in sorted(by["candidate"]):
        c = by["candidate"][k]
        row = {"literal_channel_edges": list(k[0]), "literal_cut_id": k[1], "candidate_event_index": c["event_index"],
               "candidate_cut_info": c["cut_info"], "candidate_incoming_momenta": c["incoming_momenta"],
               "candidate_outgoing_momenta": c["outgoing_momenta"], "candidate_weight": c["weight"],
               "candidate_additional_weights": c["additional_weights"], "references": {}}
        for label in ("gold","baseline","historical_gold"):
            r = by[label][k]
            row["references"][label] = {"reference_event_index": r["event_index"], "event_index_equal": r["event_index"] == c["event_index"],
                "cut_info_exact_equal": r["cut_info"] == c["cut_info"], "reference_cut_info": r["cut_info"],
                "incoming_momenta_exact_equal": r["incoming_momenta"] == c["incoming_momenta"],
                "outgoing_momenta_exact_equal": r["outgoing_momenta"] == c["outgoing_momenta"],
                "reference_outgoing_momenta": r["outgoing_momenta"],
                "weight_relation": relation(r["weight"],c["weight"]),
                "additional_weights": {name: {"reference": r["additional_weights"].get(name), "candidate": c["additional_weights"].get(name),
                    "relation": relation(r["additional_weights"][name],c["additional_weights"][name]) if name in r["additional_weights"] and name in c["additional_weights"] else None}
                    for name in sorted(r["additional_weights"].keys() | c["additional_weights"].keys())}}
        rows.append(row)
    report = {"schema":"gl20.physical-master-native-root-candidate-retained-snapshot-comparison.v1",
        "status":"ACTUAL_ORIGINAL_SNAPSHOT_FAILED_RECONSTRUCTED_READ_ONLY",
        "scope":"Full actual output recovered from retained candidate Insta diff and authenticated unchanged current committed gold. Decimal strings report existing values; equality/sign-bit comparisons only, no new sample, evaluator, generation or physical calculation.",
        "inputs":{"candidate_log":record(LOG),"current_committed_gold":record(GOLD),"baseline_actual":record(BASELINE),"historical_passed_test_gold":record(HISTORICAL_GOLD)},
        "candidate_actual":record(candidate_path), "reconstruction":reconstruction,
        "baseline_byte_equal":candidate_path.read_bytes() == BASELINE.read_bytes(),
        "candidate_parsed_equal_current_committed_gold": candidate == gold,
        "candidate_parsed_equal_baseline_actual": candidate == baseline,
        "current_and_historical_committed_gold_parsed_equal":gold == historical,
        "top_level_field_equalities":{name:{k: value[k] == candidate.get(k) for k in value if k != "event_groups"} for name,value in (("gold",gold),("baseline",baseline))},
        "integrand_results":{"gold":gold["integrand_result"],"baseline_actual":baseline["integrand_result"],"candidate_actual":candidate["integrand_result"],"historical_gold":historical["integrand_result"]},
        "integrand_result_relations":{"gold":relation(gold["integrand_result"],candidate["integrand_result"]),"baseline_actual":relation(baseline["integrand_result"],candidate["integrand_result"])},
        "event_count":len(rows), "chord_sets": [list(chord) for chord in sorted({k[0] for k in by["candidate"]})],
        "event_summary":{label:{field:sum(row["references"][label][field] for row in rows) for field in ("event_index_equal","cut_info_exact_equal","incoming_momenta_exact_equal","outgoing_momenta_exact_equal")} for label in ("gold","baseline","historical_gold")},
        "matched_events":rows,
        "interpretation_limits":["Event alignment uses literal chord IDs and cut_id only. It does not assert independent physical cut/momentum convention equivalence after the frame change.","Snapshot values alone do not identify which numerator/counterterm/evaluator boundary causes remaining failure.","Historical passed-test gold is shown separately because it differs from current committed gold.","No rewritten gold, baseline or historical report; candidate reconstruction/comparison are new artifacts only."]}
    destination = HERE / "candidate-retained-snapshot-comparison.json"
    with destination.open("x") as stream:
        json.dump(report,stream,indent=2,default=str);stream.write("\n")
    print(json.dumps({"report":record(destination),"candidate":record(candidate_path),"reconstruction":reconstruction,
                     "results":report["integrand_results"],"event_summary":report["event_summary"],"chords":report["chord_sets"]},default=str))


if __name__ == "__main__":
    main()

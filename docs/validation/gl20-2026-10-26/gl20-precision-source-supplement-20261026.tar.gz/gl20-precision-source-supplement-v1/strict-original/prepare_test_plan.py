"""Prepare one direct strict-original-test compile; never execute Rust or a test."""
from __future__ import annotations

import copy
import hashlib
import json
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
C3 = HERE.parent
REG = C3 / "regression-valid-cut-fixtures"
MAIN = C3 / "final-publication-main-a20"
RUN = HERE / "run1"
EXPECTED_HEAD = "a20b7d7d3cb3e6fff62734823bf3bca9552f6613"
EXPECTED_BRANCH = "gl20-physical-frame-strict-regression"
TEST_REL = "tests/tests/test_evaluation_api.rs"
GOLD_REL = "tests/tests/snapshots/test_evaluation_api__gl20_multichannel_local_inspect_events.snap"
CARD_REL = "tests/resources/run_cards/test_epem_tth_multichannel_gl20.toml"
EXPECTED_TEST_SHA = "7dd595b85bc806c678bda779269b5cd27681febf3dfbfd9f38c7aa4186bfa297"
EXPECTED_GOLD_SHA = "32acac110c9e3859753585e17787bbd559bd3f5547dea7c26c4092a59e8151a2"
EXPECTED_GOLD_BODY_SHA = "c5aec14431034a6ed8099563f4f6807299a7f241f73532c8466feed3276287c8"
RUST_FILES = [
    "crates/feynkit-generator/src/generation.rs",
    "crates/feynkit-generator/src/focused-tests.rs",
    "crates/feynkit-generator/src/physical-order-tests.rs",
    "crates/feynkit-graph/src/lib.rs",
    "crates/feynkit-graph/src/gl20_frame_routing_tests.rs",
]
CACHE = {}


def info(path):
    path = Path(path)
    key = str(path)
    if key not in CACHE:
        assert path.is_file() and not path.is_symlink(), key
        digest = hashlib.sha256()
        with path.open("rb") as stream:
            while block := stream.read(1024 * 1024):
                digest.update(block)
        CACHE[key] = {"path": key, "sha256": digest.hexdigest(), "bytes": path.stat().st_size}
    return copy.deepcopy(CACHE[key])


def authenticate(record):
    actual = info(record["path"])
    assert actual["sha256"] == record["sha256"], record["path"]
    if record.get("bytes") is not None:
        assert actual["bytes"] == record["bytes"], record["path"]
    return actual


def git(*args):
    return subprocess.check_output(["git", "-C", str(MAIN), *args]).decode().strip()


def prepare():
    assert git("rev-parse", "HEAD") == EXPECTED_HEAD
    assert git("branch", "--show-current") == EXPECTED_BRANCH
    parent_path = REG / "build-plan.json"
    parent = json.loads(parent_path.read_text())
    original = parent["stages"][-1]
    assert original["stage"] == "test_evaluation_api"
    assert len(original["dependencies"]) == 26
    assert original["argv"].count("--extern") == 26
    assert original["argv"][0] == parent["compiler"]["path"]
    assert "--test" in original["argv"]
    assert "--crate-type=rlib" not in original["argv"]
    test = info(MAIN / TEST_REL)
    assert test["sha256"] == EXPECTED_TEST_SHA
    head_test = subprocess.check_output(["git", "-C", str(MAIN), "show", "HEAD:" + TEST_REL])
    assert head_test == (MAIN / TEST_REL).read_bytes()
    retained_test = Path(original["source"]).read_bytes()
    save_marker = b'    cli.run_command("generate existing -p epem_a_tth -i NLO")?;\n    cli.save_state()?;\n'
    assert retained_test.count(save_marker) == 1
    assert retained_test.replace(save_marker, save_marker.replace(b'    cli.save_state()?;\n', b'')) == head_test
    gold = info(MAIN / GOLD_REL)
    assert gold["sha256"] == EXPECTED_GOLD_SHA
    gold_bytes = (MAIN / GOLD_REL).read_bytes()
    assert gold_bytes.startswith(b"---\n")
    body = gold_bytes.split(b"---\n", 2)[2]
    assert hashlib.sha256(body).hexdigest() == EXPECTED_GOLD_BODY_SHA
    rust_bindings = []
    for relative in RUST_FILES:
        target, retained = info(MAIN / relative), info(REG / "source" / relative)
        assert target["sha256"] == retained["sha256"], relative
        rust_bindings.append({"relative": relative, "main": target, "retained_C3": retained})
    for relative in ["tests/src/lib.rs", CARD_REL]:
        assert info(MAIN / relative)["sha256"] == info(REG / "source" / relative)["sha256"]

    owned = []
    for producer in parent["stages"]:
        if not producer["output"].endswith(".rlib"):
            continue
        artifact_record = REG / "run1" / ("artifact-" + producer["stage"] + ".json")
        retained = json.loads(artifact_record.read_text())
        assert retained["path"] == producer["output"]
        owned.append({
            "stage": producer["stage"],
            "artifact": authenticate(retained),
            "completed_artifact_record": info(artifact_record),
            "producer_source": info(producer["source"]),
            "original_selected_fingerprint": authenticate(producer["selected_fingerprint"]),
        })
    assert len(owned) == 9
    assert {entry["artifact"]["path"] for entry in owned} == {
        str(path) for path in (REG / "run1/lib").glob("*.rlib")
    }
    stage = copy.deepcopy(original)
    stage["source"] = str(MAIN / TEST_REL)
    stage["cwd"] = str(MAIN)
    stage["output"] = str(RUN / "test_evaluation_api")
    stage["argv"] = [stage["source"] if arg == original["source"] else
                     stage["output"] if arg == original["output"] else arg
                     for arg in original["argv"]]
    stage["environment_overlay"]["CARGO_MANIFEST_DIR"] = str(MAIN / "tests")
    stage["environment_overlay"]["CARGO_MANIFEST_PATH"] = str(MAIN / "tests/Cargo.toml")
    stage["directories_controller_must_create"] = [str(RUN)]
    for dependency in stage["dependencies"]:
        previous_artifact = dependency["artifact"]
        if previous_artifact["sha256"] != "TO_BE_AUTHENTICATED_AFTER_BUILD":
            authenticate(previous_artifact)
        else:
            assert previous_artifact["path"] in {row["artifact"]["path"] for row in owned}
        dependency["artifact"] = info(previous_artifact["path"])
        authenticate(dependency["fingerprint_marker"])
        authenticate(dependency["fingerprint_json"])
        if "original_artifact" in dependency:
            authenticate(dependency["original_artifact"])
    for expected, actual in zip(original["argv"], stage["argv"], strict=True):
        assert expected == actual or (expected, actual) in {
            (original["source"], stage["source"]), (original["output"], stage["output"])
        }
    for position, arg in enumerate(stage["argv"]):
        if arg == "--extern":
            alias, path = stage["argv"][position + 1].split("=", 1)
            matches = [d for d in stage["dependencies"] if d["extern_alias"] == alias]
            assert len(matches) == 1 and matches[0]["artifact"]["path"] == path
    assert len(stage["argv"]) == len(original["argv"])
    fingerprint = authenticate(stage["selected_fingerprint"])
    fingerprint_files = [info(p) for p in sorted(Path(fingerprint["path"]).parent.iterdir()) if p.is_file()]
    authentication = authenticate(parent["reviewed_dependency_authentication"])
    auth = json.loads(Path(authentication["path"]).read_text())
    # Bind the retained read-only transitive cohort as well as the newly owned C3 roots.
    for row in auth["selected_transitive_closure"]:
        for key in ["rlib", "fingerprint_marker", "fingerprint_json"]:
            if row.get(key):
                authenticate(row[key])
    compiler = authenticate(parent["compiler"])
    linker = authenticate(parent["linker"])
    native = [authenticate(row) for row in parent["native_archives"]]
    environment = authenticate(parent["reviewed_runtime_environment"])
    copied_keys = ["frozen_target_read_only", "private_library_directory", "base_environment_source",
                   "base_environment_key", "thread_environment_values", "environment_unset",
                   "metadata_prefix", "native_link_search_paths", "profile", "reused_dependency_graph"]
    plan = {key: copy.deepcopy(parent[key]) for key in copied_keys}
    plan.update({
        "schema": "gl20.main-a20.strict-original-test-only-direct-build.v1",
        "status": "PREPARED_SOURCE_AND_ARTIFACTS_BOUND_NO_RUST_OR_TEST_EXECUTED",
        "owner": "final-main-a20-original-strict-regression",
        "source_plan": info(parent_path),
        "preparer": info(Path(__file__).resolve()),
        "private_source": str(MAIN), "source": str(MAIN), "run_root": str(RUN),
        "main_head": EXPECTED_HEAD, "main_branch": EXPECTED_BRANCH,
        "compiler": compiler, "compiler_expected": "rustc 1.98.1 (48a229cea 2026-09-01)",
        "linker": linker, "reviewed_dependency_authentication": authentication,
        "reviewed_runtime_environment": environment,
        "original_dependency_authentication": authentication,
        "native_archives": native,
        "stages": [stage], "stage": stage, "original_test_filter": parent["original_test_filter"],
        "test_source": test, "test_source_byte_identical_to_main_a20_HEAD": True,
        "retained_C3_test_source": info(original["source"]),
        "test_source_delta_from_retained_C3": "Main original omits only retained diagnostic cli.save_state()? after generate existing; no original assertion or tolerance changed.",
        "current_gold": gold, "current_gold_body_sha256": EXPECTED_GOLD_BODY_SHA,
        "fixture_cards": [info(MAIN / CARD_REL)],
        "integration_test_support_source": info(MAIN / "tests/src/lib.rs"),
        "test_manifest": info(MAIN / "tests/Cargo.toml"),
        "five_C3_rust_source_bindings": rust_bindings,
        "reused_owner_libraries": owned,
        "reused_owner_library_count": 9, "direct_extern_count": 26,
        "retained_test_fingerprint_files": fingerprint_files,
        "authenticated_read_only_files": sorted(CACHE.values(), key=lambda row: row["path"]),
        "resource_bounds": {"setup_CPUs": [145, 146], "compile_seconds_limit": 1800,
                            "MemoryMax": "16G", "maximum_compiler_processes": 1},
        "build_scope": {"direct_test_compile_invocations": 1, "library_compile_invocations": 0,
                        "cargo_invocations": 0, "workspace_build_invocations": 0},
        "argv_changes_from_exact_retained_last_stage": ["source path", "output path"],
        "environment_overlay_changes": ["CARGO_MANIFEST_DIR", "CARGO_MANIFEST_PATH"],
        "runtime_fixture_resolution": "Run from Main workspace root; existing tests/src/lib.rs workspace_root chooses current_dir before embedded retained manifest fallback.",
        "profile_limit": parent["profile"]["codegen_units"]["limitation"],
        "notes": ["No new model, graph, eager evaluation, compiler or test execution in preparation.",
                  "Nine owned rlibs are already built and hash-matched to completed C3 artifact records.",
                  "All26 extern arguments, metadata, cfg/features, optimization/debug/overflow/codegen and native link flags retain the exact reviewed C3 last-stage argv.",
                  "Snapshot migration is separately owned; this script verifies its exact current bytes and body digest."],
    })
    output = HERE / "test-build-plan.json"
    with output.open("x") as stream:
        json.dump(plan, stream, indent=2, sort_keys=True)
        stream.write("\n")
    print(json.dumps({"status": plan["status"], "plan": info(output), "owned_libraries": 9,
                      "externs": 26, "stages": 1, "authenticated_read_only_files": len(CACHE)}))


if __name__ == "__main__":
    prepare()

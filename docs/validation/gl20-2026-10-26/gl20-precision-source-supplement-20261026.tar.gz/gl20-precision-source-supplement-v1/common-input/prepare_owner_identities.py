#!/usr/bin/env python3
"""Copy exact existing owner authentication records; never open private license override."""
import hashlib,json,pathlib
HERE=pathlib.Path(__file__).resolve().parent
C3=HERE.parent; CT=C3.parent.parent; OUT=CT.parent; BASE=OUT.parent
H=BASE/'historical-generation-proposal/prepared-source-and-driver/historical-matched-decoder-20261026'
REG=C3/'regression-valid-cut-fixtures'; N=REG/'matched-state-decode'
def load(p): return json.loads(pathlib.Path(p).read_text())
def info(p):
 p=pathlib.Path(p); h=hashlib.sha256()
 with p.open('rb') as f:
  for chunk in iter(lambda:f.read(4*1024*1024),b''):h.update(chunk)
 return {'path':str(p),'sha256':h.hexdigest(),'bytes':p.stat().st_size}
def verify(r):
 a=info(r['path']);assert a['sha256']==r['sha256'],r['path']
 if 'bytes' in r: assert a['bytes']==r['bytes'],r['path']
 return a
hm=load(H/'controller-v2/control-manifest.json'); hd=load(H/'dependency-authentication.json')
nm=load(N/'control-manifest.json'); nd=load(N/'dependency-authentication.json'); ns=load(N/'retained-state-authentication.json'); p=load(REG/'build-plan.json')
assert info(H/'dependency-authentication.json')['sha256']=='d702a3a3b20488a13a5ba479fbcf36347dbda0568d4ad66f3c90b13bd81e2e1f'
assert info(N/'dependency-authentication.json')['sha256']=='b8f8e26ec84269e80566ada8892ab0f066f5b296cbdf0a6d4e514df8d69e8ef6'
assert info(REG/'build-plan.json')['sha256']=='9b0686b60fe04be93c6ab4cfa78c0909aaa8859d7630c620779f44bd962d1a59'
for manifest in (hm,nm):
 for row in manifest['controls']:
  if row['path'] in [str(H/'dependency-authentication.json'),str(N/'dependency-authentication.json'),str(REG/'build-plan.json'),str(REG/'source-freeze.json')]:verify(row)
old_freeze=load(hm['source_freeze']); new_freeze=load(nm['writer_source_freeze']); original_freeze=load(nm['original_source_freeze'])
assert len(hd['selected_externs'])==len(nd['selected_externs'])==7
old_states=[{'path':str(pathlib.Path(hm['retained_state'])/r['path']),'relative':r['path'],'sha256':r['sha256'],'bytes':r['bytes']} for r in hm['retained_state_files']]
new_states=ns['files'];assert len(old_states)==len(new_states)==12
old_sources=[{'path':str(pathlib.Path(hm['source'])/r['path']),'relative':r['path'],'sha256':r['prepared_sha256']} for r in old_freeze['prepared_files']]
new_sources=[{'path':str(pathlib.Path(new_freeze['source'])/rel),'relative':rel,'sha256':sha} for rel,sha in new_freeze['files'].items()]
original_sources=[{'path':str(pathlib.Path(original_freeze['source'])/rel),'relative':rel,'sha256':sha} for rel,sha in original_freeze['files'].items()]
for row in old_states+new_states+old_sources+new_sources+original_sources:verify(row)
for d in (hd,nd):
 for key in ('rustc','compiler','linker'):
  if key in d:verify(d[key])
 for row in d['selected_externs']:verify(row['rlib'])
 for row in d['native_archives']:verify(row)
private_writer_rlibs=[r for r in nd['actual_candidate_writer_artifacts'] if r['owner'] in ('feynkit_graph','feynkit_amplitude','feynkit_cff','feynkit_tensor','feynkit_generator','vakint','gammalooprs','gammaloop_api')]
assert len(private_writer_rlibs)==8
for row in private_writer_rlibs:verify(row)
threads={k:str(hm['library_thread_environment_values']) for k in hm['thread_environment']};assert set(threads.values())=={'1'}
assert p['thread_environment_values']==threads
old_env=pathlib.Path(hm['runtime_environment']);new_env=pathlib.Path(p['base_environment_source'])
# Do not load environment values, license text, or private override file.
for envfile,controls in [(old_env,hm['controls']),(new_env,[p['reviewed_runtime_environment']])]:
 matches=[r for r in controls if r['path']==str(envfile)];assert len(matches)==1;verify(matches[0])
owners={
 'historical':{
  'owner':'historical','compiler':hd['rustc'],'linker':hd['linker'],
  'selected_externs':hd['selected_externs'],
  'dependency_library_directories':[str(pathlib.Path(hd['old_target'])/'deps')],
  'native_link_search_paths':hd['native_link_search_paths'],'native_archives':hd['native_archives'],
  'state_root':hm['retained_state'],'state_files':old_states,
  'source_root':hm['source'],'source_freeze':info(hm['source_freeze']),'source_guard_records':old_sources,
  'dependency_authentication_source':info(H/'dependency-authentication.json'),
  'dependency_authentication_keys':{'compiler':'rustc','selected_externs':'selected_externs','link_search_closure':'read_only_linker_search_closure','native_search':'native_link_search_paths'},
  'control_manifest_source':info(H/'controller-v2/control-manifest.json'),
  'controller_source':info(H/'controller-v2/run_decoder.py'),
  'base_environment_source':str(old_env),'base_environment_source_record':info(old_env),'base_environment_key':'environment','thread_environment_values':threads,
  'private_license_override':hm['private_license_override'],
  'private_license_override_policy':'PATH ONLY: not opened, not read, not hashed, no contents or values copied.',
 },
 'candidate3':{
  'owner':'candidate3','compiler':nd['compiler'],'linker':nd['linker'],
  'selected_externs':nd['selected_externs'],
  'dependency_library_directories':[p['private_library_directory'],str(pathlib.Path(p['frozen_target_read_only'])/'deps')],
  'native_link_search_paths':p['native_link_search_paths'],'native_archives':nd['native_archives'],
  'actual_private_writer_rlibs':private_writer_rlibs,
  'state_root':ns['root'],'state_files':new_states,'state_authentication_source':info(N/'retained-state-authentication.json'),
  'source_root':new_freeze['source'],'source_freeze':info(nm['writer_source_freeze']),'source_guard_records':new_sources,
  'original_source_freeze':info(nm['original_source_freeze']),'original_source_root':original_freeze['source'],'original_source_guard_records':original_sources,
  'dependency_authentication_source':info(N/'dependency-authentication.json'),
  'dependency_authentication_keys':{'compiler':'compiler','selected_externs':'selected_externs','link_search_closure':'original_matching_cargo_dependency_closure'},
  'original_dependency_authentication_source':nd['original_dependency_authentication'],
  'writer_build_plan_source':info(REG/'build-plan.json'),
  'control_manifest_source':info(N/'control-manifest.json'),'controller_source':info(N/'run_decode.py'),
  'base_environment_source':str(new_env),'base_environment_source_record':info(new_env),'base_environment_key':p['base_environment_key'],'thread_environment_values':p['thread_environment_values'],'environment_unset':p['environment_unset'],
 }
}
packet={'schema':'gl20.common-input-eager-owner-identities.v1','status':'SOURCE_DATA_PREPARED_NO_NATIVE_EXECUTION','owners':owners,
 'source_guard_counts':{'historical':len(old_sources),'candidate3':len(new_sources),'original_current':len(original_sources)},
 'validation':'All compiler/linker,7selectedrlibs/owner,8privatewriterRLIBs,nativearchive,state12/owner,andexistingfullsourcefreeze records independently rehashed. Existing D closure records remain authoritative through hash-bound source JSON; no new dependency inventory was created.',
 'environment_policy':'Only authenticated base-environment file path/hash/key and forced thread values copied. Base environment values and private override contents are not read or reproduced.',
 'preparer':info(__file__)}
target=HERE/'owner-identities.json';target.write_text(json.dumps(packet,indent=2)+'\n');print(json.dumps({'output':info(target),'source_guard_counts':packet['source_guard_counts'],'externs_per_owner':7,'states_per_owner':12,'private_writer_rlibs':8}))

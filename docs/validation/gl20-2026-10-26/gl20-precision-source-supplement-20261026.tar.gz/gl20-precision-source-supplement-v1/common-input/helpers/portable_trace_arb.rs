//! Private selected Arb1000 diagnostic interpreter for retained main eager streams.
//!
//! This module uses only public portable instructions and the owner's original scalar type.
//! It does not load states, build evaluators, resolve constants, activate backends, or write files.
//! The driver must call the actual stored eager evaluator on the same inputs, then use
//! `TraceRecord::validated_json` before accepting or publishing a trace.
//!
//! Add/Mul/Pow follow the generic native interpreter's operand order and scalar methods.
//! Public real-prefix/phase hints are deliberately ignored, as in `evaluate_single`.
//! This mechanical adaptation records at most 64 reviewed instruction ordinals and does not
//! normalize stored constants or the actual inner precision of any working scalar.

use color_eyre::Result;
use color_eyre::eyre::eyre;
use gammalooprs::utils::{ArbPrec, F};
use serde_json::{self, Value, json};
use spenso::algebra::complex::Complex;
use std::mem;
use symbolica::atom::Symbol;
use symbolica::domains::float::{Float as SymbolicaFloat, FloatLike, Real};
use symbolica::evaluate::{ExportedInstructions, Instruction, Slot};

pub(crate) type Scalar = Complex<F<ArbPrec>>;

const MAX_INSTRUCTIONS: usize = 150_000;
const MAX_STORAGE_SLOTS: usize = 16_384;
const MAX_OPERATION_VALUES: usize = 64;
const MAX_TRACE_JSON_BYTES: usize = 2 * 1024 * 1024;

/// A selected register write at an original exported instruction ordinal.
#[derive(Debug, Clone)]
pub(crate) struct OperationValue {
    pub(crate) instruction_index: usize,
    pub(crate) value: Scalar,
}

/// Unaccepted trace data; compare its root with the actual native eager result first.
#[derive(Debug)]
pub(crate) struct TraceRecord {
    pub(crate) root_value: Scalar,
    pub(crate) operations: Vec<OperationValue>,
    pub(crate) executed_instruction_count: usize,
    pub(crate) executed_arithmetic_count: usize,
}

impl TraceRecord {
    /// Require exact component PartialEq, actual inner precisions and signed zeros.
    ///
    /// The numeric comparison performs no subtraction or decimal tolerance test. The public
    /// observation path clones the underlying Float without changing its precision.
    pub(crate) fn validate_native(&self, native_value: &Scalar) -> Result<()> {
        if &self.root_value != native_value {
            return Err(eyre!("Portable Arb root differs from native eager root"));
        }
        let portable = scalar_record(&self.root_value);
        let native = scalar_record(native_value);
        for component in ["re", "im"] {
            if portable[component]["actual_inner_precision_bits"]
                != native[component]["actual_inner_precision_bits"]
                || portable[component]["is_zero"] != native[component]["is_zero"]
                || (portable[component]["is_zero"] == true
                    && portable[component]["is_sign_negative"]
                        != native[component]["is_sign_negative"])
            {
                return Err(eyre!(
                    "Portable Arb root inner precision or signed zero differs from native"
                ));
            }
        }
        Ok(())
    }

    /// Borrow a selected value after the driver has passed the exact native-root gate.
    pub(crate) fn operation_value(&self, instruction_index: usize) -> Option<&Scalar> {
        self.operations
            .iter()
            .find(|operation| operation.instruction_index == instruction_index)
            .map(|operation| &operation.value)
    }

    /// Validate the native root and return selected values with actual inner precisions.
    ///
    /// Driver sequence: export the stored Arb eager object, obtain its native evaluate_single
    /// result on identical inputs, call trace with reviewed selected instruction ordinals,
    /// then call this method. No unselected register values are serialized.
    pub(crate) fn validated_json(&self, native_value: &Scalar) -> Result<Value> {
        self.validate_native(native_value)?;
        let operations = self
            .operations
            .iter()
            .map(|operation| {
                json!({
                    "instruction_index": operation.instruction_index,
                    "value": scalar_record(&operation.value),
                })
            })
            .collect::<Vec<_>>();
        let value = json!({
            "schema": "gl20.portable-main-arb1000-selected-trace.v1",
            "native_root_verified": true,
            "root_gate": "exact PartialEq plus actual inner precision and signed-zero equality",
            "root": scalar_record(&self.root_value),
            "native_root": scalar_record(native_value),
            "executed_instruction_count": self.executed_instruction_count,
            "executed_arithmetic_count": self.executed_arithmetic_count,
            "operation_value_count": self.operations.len(),
            "operation_values": operations,
        });
        if serde_json::to_vec(&value)?.len() >= MAX_TRACE_JSON_BYTES
            || serde_json::to_vec_pretty(&value)?.len() >= MAX_TRACE_JSON_BYTES
        {
            return Err(eyre!(
                "Accepted trace would exceed the 2 MiB per-case bound"
            ));
        }
        Ok(value)
    }
}

#[derive(Clone, Copy)]
struct Layout {
    input_count: usize,
    constant_count: usize,
    temporary_count: usize,
    total_count: usize,
}

impl Layout {
    fn new(program: &ExportedInstructions<Scalar>, input_count: usize) -> Result<Self> {
        if !matches!(input_count, 192 | 193) {
            return Err(eyre!("Unexpected retained main input count {input_count}"));
        }
        let constant_count = program.constants.len();
        let temporary_count = program.temporary_count;
        let total_count = input_count
            .checked_add(constant_count)
            .and_then(|count| count.checked_add(temporary_count))
            .and_then(|count| count.checked_add(1))
            .ok_or_else(|| eyre!("Portable storage size overflow"))?;
        if total_count > MAX_STORAGE_SLOTS {
            return Err(eyre!("Portable storage exceeds the qualified slot bound"));
        }
        Ok(Self {
            input_count,
            constant_count,
            temporary_count,
            total_count,
        })
    }

    fn index(self, slot: Slot) -> Result<usize> {
        match slot {
            Slot::Param(index) if index < self.input_count => Ok(index),
            Slot::Const(index) if index < self.constant_count => Ok(self.input_count + index),
            Slot::Temp(index) if index < self.temporary_count => {
                Ok(self.input_count + self.constant_count + index)
            }
            Slot::Out(0) => Ok(self.total_count - 1),
            _ => Err(eyre!("Out-of-range portable slot {slot}")),
        }
    }

    fn destination(self, slot: Slot) -> Result<usize> {
        if matches!(slot, Slot::Param(_) | Slot::Const(_)) {
            return Err(eyre!(
                "Instruction attempts to overwrite input/constant {slot}"
            ));
        }
        self.index(slot)
    }
}

struct Storage {
    layout: Layout,
    values: Vec<Scalar>,
    initialized: Vec<bool>,
}

impl Storage {
    fn new(layout: Layout, program: &ExportedInstructions<Scalar>, params: &[Scalar]) -> Self {
        let mut values = vec![Scalar::new_zero(); layout.total_count];
        let mut initialized = vec![false; layout.total_count];
        for (index, value) in params.iter().chain(&program.constants).enumerate() {
            values[index].set_from(value);
            initialized[index] = true;
        }
        Self {
            layout,
            values,
            initialized,
        }
    }

    fn read(&self, slot: Slot) -> Result<&Scalar> {
        let index = self.layout.index(slot)?;
        if !self.initialized[index] {
            return Err(eyre!(
                "Portable instruction reads unwritten temporary {slot}"
            ));
        }
        Ok(&self.values[index])
    }

    fn write(&mut self, slot: Slot, value: Scalar) -> Result<()> {
        let index = self.layout.destination(slot)?;
        self.values[index] = value;
        self.initialized[index] = true;
        Ok(())
    }

    fn swap_from(&mut self, slot: Slot, value: &mut Scalar) -> Result<()> {
        let index = self.layout.destination(slot)?;
        mem::swap(&mut self.values[index], value);
        self.initialized[index] = true;
        Ok(())
    }
}

/// Observe a precision-preserving public clone of each actual inner rug::Float.
///
/// VarFloat.float is private. Both matched owners implement From<&VarFloat<N>> for
/// SymbolicaFloat by cloning that field: historical utils/mod.rs:924 and current:978.
/// The historical public into_inner and current public into_raw return that same clone.
/// No conversion to f64, reconstruction from text, arithmetic, or set_prec occurs here.
pub(crate) fn scalar_record(value: &Scalar) -> Value {
    let re = SymbolicaFloat::from(&value.re.0);
    let im = SymbolicaFloat::from(&value.im.0);
    #[cfg(legacy)]
    let (re, im) = (re.into_inner(), im.into_inner());
    #[cfg(not(legacy))]
    let (re, im) = (re.into_raw(), im.into_raw());
    json!({
        "declared_wrapper_precision_bits": 1000,
        "inner_observation": "public precision-preserving clone of actual inner rug::Float",
        "re": {
            "decimal": re.to_string(),
            "actual_inner_precision_bits": re.prec(),
            "is_sign_negative": re.is_sign_negative(),
            "is_zero": re.is_zero(),
            "is_finite": re.is_finite(),
        },
        "im": {
            "decimal": im.to_string(),
            "actual_inner_precision_bits": im.prec(),
            "is_sign_negative": im.is_sign_negative(),
            "is_zero": im.is_zero(),
            "is_finite": im.is_finite(),
        },
    })
}

fn historical_override_is_one(value: &Scalar) -> bool {
    let re = SymbolicaFloat::from(&value.re.0);
    let im = SymbolicaFloat::from(&value.im.0);
    #[cfg(legacy)]
    let (re, im) = (re.into_inner(), im.into_inner());
    #[cfg(not(legacy))]
    let (re, im) = (re.into_raw(), im.into_raw());
    re == 1 && im.is_zero() && !im.is_sign_negative()
}

fn validate_target(
    instructions: &[Instruction],
    instruction_index: usize,
    target: usize,
) -> Result<()> {
    if target <= instruction_index
        || !matches!(instructions.get(target), Some(Instruction::Label(label)) if *label == target)
    {
        return Err(eyre!(
            "Invalid/non-forward portable target {target} at instruction {instruction_index}"
        ));
    }
    Ok(())
}

/// Check the complete portable stream without performing scalar arithmetic.
///
/// The driver may call this before its native eager call. The supported contract is one main
/// output and the exact retained input layout. Unknown functions/Powf fail before tracing.
pub(crate) fn validate_program(
    program: &ExportedInstructions<Scalar>,
    params: &[Scalar],
) -> Result<()> {
    if program.instructions.is_empty() || program.instructions.len() > MAX_INSTRUCTIONS {
        return Err(eyre!(
            "Portable instruction count is outside the qualified bound"
        ));
    }
    let layout = Layout::new(program, params.len())?;
    if params.len() == 193 && !historical_override_is_one(&params[16]) {
        return Err(eyre!(
            "Historical retained override_if input16 must be complex ONE"
        ));
    }
    for (instruction_index, instruction) in program.instructions.iter().enumerate() {
        match instruction {
            Instruction::Add(output, sources, _) | Instruction::Mul(output, sources, _) => {
                layout.destination(*output)?;
                if sources.is_empty() {
                    return Err(eyre!(
                        "Empty operand list at instruction {instruction_index}"
                    ));
                }
                for source in sources {
                    layout.index(*source)?;
                }
            }
            Instruction::Pow(output, base, _, _) | Instruction::Assign(output, base) => {
                layout.destination(*output)?;
                layout.index(*base)?;
            }
            Instruction::Fun(output, function, _) => {
                let (symbol, tags, arguments) = &**function;
                if *symbol != Symbol::SQRT || !tags.is_empty() || arguments.len() != 1 {
                    return Err(eyre!(
                        "Unsupported function at instruction {instruction_index}"
                    ));
                }
                layout.destination(*output)?;
                layout.index(arguments[0])?;
            }
            Instruction::IfElse(condition, target) => {
                layout.index(*condition)?;
                validate_target(&program.instructions, instruction_index, *target)?;
            }
            Instruction::Goto(target) => {
                validate_target(&program.instructions, instruction_index, *target)?;
            }
            Instruction::Label(label) => {
                if *label != instruction_index {
                    return Err(eyre!(
                        "Portable label ordinal mismatch at {instruction_index}"
                    ));
                }
            }
            Instruction::Join(output, condition, true_source, false_source) => {
                layout.destination(*output)?;
                for source in [condition, true_source, false_source] {
                    layout.index(*source)?;
                }
            }
            Instruction::Powf(..) => {
                return Err(eyre!("Unsupported Powf at instruction {instruction_index}"));
            }
        }
    }
    Ok(())
}

/// Trace a retained program using the original owner's Arb1000 complex operations.
///
/// No result is accepted by this function alone. Call `TraceRecord::validated_json` with the
/// direct `evaluate_single` result on the identical eager object and input buffer. Errors stop
/// the case; callers must not repair, retry, or publish an incomplete trace as verified.
pub(crate) fn trace(
    program: &ExportedInstructions<Scalar>,
    params: &[Scalar],
    selected: &[usize],
) -> Result<TraceRecord> {
    validate_program(program, params)?;
    if selected.is_empty() || selected.len() > MAX_OPERATION_VALUES {
        return Err(eyre!(
            "Selected operation count is outside the qualified 1..=64 bound"
        ));
    }
    for (position, index) in selected.iter().enumerate() {
        if selected[..position].contains(index) {
            return Err(eyre!("Duplicate selected instruction ordinal {index}"));
        }
        if !matches!(
            program.instructions.get(*index),
            Some(
                Instruction::Add(..)
                    | Instruction::Mul(..)
                    | Instruction::Pow(..)
                    | Instruction::Fun(..)
                    | Instruction::Assign(..)
                    | Instruction::Join(..)
            )
        ) {
            return Err(eyre!(
                "Selected instruction {index} is not a supported register write"
            ));
        }
    }
    let layout = Layout::new(program, params.len())?;
    let mut storage = Storage::new(layout, program, params);
    let mut tmp = Scalar::new_zero();
    let mut instruction_index = 0;
    let mut executed_instruction_count = 0;
    let mut executed_arithmetic_count = 0;
    let mut operations = Vec::new();
    while instruction_index < program.instructions.len() {
        executed_instruction_count += 1;
        if executed_instruction_count > MAX_INSTRUCTIONS {
            return Err(eyre!(
                "Portable execution exceeded the qualified instruction bound"
            ));
        }
        let mut next_instruction = instruction_index + 1;
        let mut written = None;
        match &program.instructions[instruction_index] {
            Instruction::Add(output, sources, _) => {
                tmp.set_from(storage.read(sources[0])?);
                for source in &sources[1..] {
                    tmp += storage.read(*source)?;
                }
                storage.swap_from(*output, &mut tmp)?;
                written = Some(*output);
                executed_arithmetic_count += 1;
            }
            Instruction::Mul(output, sources, _) => {
                tmp.set_from(storage.read(sources[0])?);
                for source in &sources[1..] {
                    tmp *= storage.read(*source)?;
                }
                storage.swap_from(*output, &mut tmp)?;
                written = Some(*output);
                executed_arithmetic_count += 1;
            }
            Instruction::Pow(output, base, exponent, _) => {
                let base = storage.read(*base)?;
                let value = if *exponent == -1 {
                    base.inv()
                } else if *exponent >= 0 {
                    base.pow(*exponent as u64)
                } else {
                    base.pow(exponent.unsigned_abs()).inv()
                };
                storage.write(*output, value)?;
                written = Some(*output);
                executed_arithmetic_count += 1;
            }
            Instruction::Fun(output, function, _) => {
                let (_, _, arguments) = &**function;
                let value = storage.read(arguments[0])?.sqrt();
                storage.write(*output, value)?;
                written = Some(*output);
                executed_arithmetic_count += 1;
            }
            Instruction::Assign(output, source) => {
                let value = storage.read(*source)?.clone();
                storage.write(*output, value)?;
                written = Some(*output);
            }
            Instruction::IfElse(condition, target) => {
                if storage.read(*condition)?.is_fully_zero() {
                    next_instruction = *target;
                }
            }
            Instruction::Goto(target) => next_instruction = *target,
            Instruction::Label(_) => {}
            Instruction::Join(output, condition, true_source, false_source) => {
                let source = if !storage.read(*condition)?.is_fully_zero() {
                    *true_source
                } else {
                    *false_source
                };
                let value = storage.read(source)?.clone();
                storage.write(*output, value)?;
                written = Some(*output);
            }
            Instruction::Powf(..) => {
                return Err(eyre!("Unreviewed Powf reached after portable preflight"));
            }
        }
        if let Some(output) = written.filter(|_| selected.contains(&instruction_index)) {
            if operations.len() == MAX_OPERATION_VALUES {
                return Err(eyre!(
                    "Portable trace exceeds the qualified operation-value bound"
                ));
            }
            operations.push(OperationValue {
                instruction_index,
                value: storage.read(output)?.clone(),
            });
        }
        instruction_index = next_instruction;
    }
    if operations.len() != selected.len() {
        return Err(eyre!(
            "Not every selected register write was reached on the retained branch"
        ));
    }
    Ok(TraceRecord {
        root_value: storage.read(Slot::Out(0))?.clone(),
        operations,
        executed_instruction_count,
        executed_arithmetic_count,
    })
}

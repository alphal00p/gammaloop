#![recursion_limit = "512"]
//! One formal dependent-energy replay; this is not a native-equivalent sample.
use color_eyre::Result;
use color_eyre::eyre::eyre;
use gammaloop_api::state::State;
use gammalooprs::integrands::process::ProcessIntegrand;
use gammalooprs::processes::process::ProcessCollection;
use gammalooprs::utils::{ArbPrec, F};
use serde_json::{Value, json};
use spenso::algebra::complex::Complex;
use std::env;
use std::fs;
use std::io::Write;
use std::path::Path;
#[cfg(legacy)]
use symbolica::LicenseManager;
use symbolica::domains::float::Float as SymbolicaFloat;
#[cfg(not(legacy))]
use symbolica::license::LicenseManager;

#[path = "portable_trace_arb_cut_constraint.rs"]
mod portable;

type Scalar = Complex<F<ArbPrec>>;

fn write(path: &Path, value: &Value) -> Result<()> {
    let mut file = fs::OpenOptions::new()
        .write(true)
        .create_new(true)
        .open(path)?;
    file.write_all(&serde_json::to_vec_pretty(value)?)?;
    file.write_all(b"\n")?;
    file.sync_all()?;
    Ok(())
}

fn parse_observed(record: &Value) -> Result<Scalar> {
    let value = Complex::new(
        F(record["re"]["decimal"]
            .as_str()
            .unwrap()
            .parse::<ArbPrec>()
            .map_err(|error| eyre!("Observed real value cannot be parsed: {error}"))?),
        F(record["im"]["decimal"]
            .as_str()
            .unwrap()
            .parse::<ArbPrec>()
            .map_err(|error| eyre!("Observed imaginary value cannot be parsed: {error}"))?),
    );
    assert_eq!(
        portable::scalar_record(&value),
        *record,
        "Observed baseline value must round-trip exactly, including inner precision and signed zero"
    );
    Ok(value)
}

fn main() -> Result<()> {
    assert!(
        LicenseManager::is_licensed(),
        "Matching owner licence rejected; no retry"
    );
    let args: Vec<_> = env::args().collect();
    assert_eq!(args.len(), 5);
    let owner = &args[1];
    assert!(owner == "historical" || owner == "candidate3");
    assert_eq!(cfg!(legacy), owner == "historical");
    let packet: Value = serde_json::from_slice(&fs::read(&args[3])?)?;
    let cases = packet["cases"].as_array().unwrap();
    assert_eq!(cases.len(), 1);
    let case = &cases[0];
    assert_eq!(case["case_id"], "channel_0_cut_group_2_historical_call_14");
    assert_eq!(case["cut_group_id"], 2);
    let contract = &packet["program_contract"]["owners"][owner];
    let accepted_completion: Value = serde_json::from_slice(&fs::read(
        contract["accepted_completion"]["path"].as_str().unwrap(),
    )?)?;
    assert_eq!(
        accepted_completion["status"],
        "PASS_GROUP2_INTERMEDIATES_OWNER_NOT_GL20_ACCEPTANCE"
    );
    assert_eq!(
        accepted_completion["sources_dependencies_original_and_copied_state_unchanged"],
        true
    );
    let baseline: Value = serde_json::from_slice(&fs::read(
        contract["accepted_output"]["path"].as_str().unwrap(),
    )?)?;
    assert_eq!(baseline["owner"], *owner);
    assert_eq!(baseline["case_id"], case["case_id"]);
    assert_eq!(baseline["f64_trace"]["native_root_verified"], true);
    assert_eq!(baseline["arb_trace"]["native_root_verified"], true);
    assert_eq!(baseline["arb_trace"]["root"], baseline["native_arb"]);
    assert_eq!(baseline["arb_trace"]["native_root"], baseline["native_arb"]);
    assert_eq!(
        baseline["native_f64_bits"],
        packet["native_anchors"][owner]["f64_bits"]
    );
    assert_eq!(
        baseline["native_arb"]["re"]["decimal"],
        packet["native_anchors"][owner]["arb_re"]
    );
    assert_eq!(
        baseline["native_arb"]["im"]["decimal"],
        packet["native_anchors"][owner]["arb_im"]
    );
    let out = Path::new(&args[4]);
    fs::create_dir(out)?;
    // Standard matching-owner hydration only; no full evaluator or API call.
    let state = State::load(Path::new(&args[2]).to_path_buf(), None, None)?;
    assert_eq!(state.process_list.processes.len(), 1);
    let ProcessCollection::CrossSections(collection) = &state
        .process_list
        .processes
        .iter()
        .next()
        .unwrap()
        .collection
    else {
        return Err(eyre!("Expected cross section"));
    };
    assert_eq!(collection.len(), 1);
    let Some(ProcessIntegrand::CrossSection(integrand)) =
        &collection.values().next().unwrap().integrand
    else {
        return Err(eyre!("Missing retained integrand"));
    };
    assert_eq!(integrand.data.graph_terms.len(), 1);
    let term = integrand.data.graph_terms.iter().next().unwrap();
    let group = term.integrand.iter().nth(2).unwrap();
    assert_eq!(group.len(), 1);
    let evaluator = group
        .iter()
        .next()
        .unwrap()
        .1
        .summed_function_map
        .as_ref()
        .ok_or_else(|| eyre!("Missing summed evaluator"))?;
    let debug = format!("{:?}", evaluator.arb);
    let instruction_section = debug
        .split_once("instructions: [")
        .unwrap()
        .1
        .split_once("], result_indices:")
        .unwrap()
        .0;
    let expected = fs::read_to_string(
        contract["instruction_section_file"]["path"]
            .as_str()
            .unwrap(),
    )?;
    assert_eq!(
        instruction_section, expected,
        "The entire stored Arb instruction sequence must equal the accepted baseline contract before any replay"
    );
    let constants = evaluator.arb.get_constants();
    let constant_values = contract["constant_values"].as_array().unwrap();
    assert_eq!(constants.len(), constant_values.len());
    assert_eq!(
        evaluator.arb.get_input_len(),
        contract["param_count"].as_u64().unwrap() as usize
    );
    assert_eq!(evaluator.arb.get_output_len(), 1);
    assert_eq!(
        evaluator.arb.get_input_len() + constants.len(),
        contract["reserved_indices"].as_u64().unwrap() as usize
    );
    let result_suffix = debug.split_once("], result_indices: ").unwrap().1;
    let result_text = format!("{}]", result_suffix.split_once(']').unwrap().0);
    let actual_result_indices: Value = serde_json::from_str(&result_text)?;
    assert_eq!(actual_result_indices, contract["result_indices"]);
    for (actual, expected) in constants.iter().zip(constant_values) {
        assert_eq!(actual.re.to_string(), expected["re"].as_str().unwrap());
        assert_eq!(actual.im.to_string(), expected["im"].as_str().unwrap());
    }
    let key = if cfg!(legacy) {
        "historical_params_bits"
    } else {
        "candidate3_params_bits"
    };
    let params = case[key]
        .as_array()
        .unwrap()
        .iter()
        .map(|pair| {
            Complex::new(
                F(ArbPrec::from(SymbolicaFloat::with_val(
                    1000,
                    f64::from_bits(pair[0].as_u64().unwrap()),
                ))),
                F(ArbPrec::from(SymbolicaFloat::with_val(
                    1000,
                    f64::from_bits(pair[1].as_u64().unwrap()),
                ))),
            )
        })
        .collect::<Vec<_>>();
    assert_eq!(
        params.len(),
        contract["param_count"].as_u64().unwrap() as usize
    );
    if cfg!(legacy) {
        assert_eq!(case[key][16], json!([4607182418800017408u64, 0]));
    }
    let q_slots = packet["selection"]["delta_physical_cut"]["temporal_input_slots"][owner]
        .as_array()
        .unwrap();
    assert_eq!(q_slots.len(), 2);
    let observed = baseline["selected_values"].as_array().unwrap();
    let energy = |edge: u64| -> Result<Scalar> {
        let row = observed
            .iter()
            .find(|row| {
                row["selection"]["role"] == "ose" && row["selection"]["physical_edge_id"] == edge
            })
            .ok_or_else(|| eyre!("Missing accepted energy{edge}"))?;
        parse_observed(&row["arb"])
    };
    let q0 = params[q_slots[0].as_u64().unwrap() as usize].clone();
    let q1 = params[q_slots[1].as_u64().unwrap() as usize].clone();
    let e2 = energy(2)?;
    let e6 = energy(6)?;
    let e9 = energy(9)?;
    let old_e11 = energy(11)?;
    let replacement = q0.clone() + &q1 - &e2 - &e6 - &e9;
    let index = contract["e11_instruction_index"].as_u64().unwrap() as usize;
    assert_eq!(index, if cfg!(legacy) { 515 } else { 68 });
    let program = evaluator.arb.export_instructions();
    let record = portable::replay_cut_constraint(&program, &params, &[index], index, &replacement)?;
    let formal = record.formal_json()?;
    write(&out.join("formal-replay-before-postchecks.json"), &formal)?;
    assert_eq!(
        formal["original_sqrt_value"],
        portable::scalar_record(&old_e11)
    );
    assert_eq!(
        formal["replacement_value"],
        portable::scalar_record(&replacement)
    );
    let mut delta_after = e2;
    delta_after += &e6;
    delta_after += &e9;
    delta_after += &replacement;
    delta_after -= &q0;
    delta_after -= &q1;
    let result = json!({
        "schema":"gl20.one-formal-cut-constraint-counterfactual.v1",
        "status":"FORMAL_DIAGNOSTIC_NOT_NATIVE_EQUIVALENT_NOT_A_NEW_PHYSICAL_SAMPLE",
        "owner":owner,"case_id":case["case_id"],"native_calls":0,"full_API_calls":0,"shadow_replays":1,
        "baseline_native_gates_reused_from_authenticated_outputs":true,
        "entire_program_instruction_contract_verified":true,"stored_constants_unchanged":true,
        "replacement_formula_in_order":"Q0_0 + Q1_0 - E2 - E6 - E9",
        "accepted_E11_before":portable::scalar_record(&old_e11),"replacement_E11":portable::scalar_record(&replacement),
        "accepted_delta_before":baseline["physical_cut_residual"],
        "derived_delta_after_common_order_E2_E6_E9_E11_q0_q1":portable::scalar_record(&delta_after),
        "counterfactual":formal,
        "actual_constant_records":constants.iter().map(portable::scalar_record).collect::<Vec<_>>(),
        "limits":"Only the formal dependent energy E11 is replaced. This is not a native-equivalent trace, physical sample, general symbolic identity, accuracy proof, gold acceptance or production fix. Actual pi coefficients remain unchanged."
    });
    write(&out.join("formal-cut-constraint.json"), &result)?;
    write(
        &out.join("completion.json"),
        &json!({"status":"PASS_FORMAL_CUT_CONSTRAINT_DIAGNOSTIC_NOT_NATIVE_EQUIVALENT","state_loads":1,"f64_calls":0,"stored_arb1000_calls":0,"shadow_calls":1,"case_count":1,"intervention_count":1}),
    )?;
    Ok(())
}

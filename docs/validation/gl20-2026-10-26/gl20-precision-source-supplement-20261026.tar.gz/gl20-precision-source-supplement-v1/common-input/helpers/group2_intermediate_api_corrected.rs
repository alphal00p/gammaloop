#![recursion_limit = "512"]
//! One retained group2 buffer: native-gated selected portable intermediates only.
use color_eyre::Result;
use color_eyre::eyre::eyre;
use gammaloop_api::state::State;
use gammalooprs::integrands::process::ProcessIntegrand;
use gammalooprs::processes::process::ProcessCollection;
use gammalooprs::utils::{ArbPrec, F};
use serde_json::{Value, json};
use spenso::algebra::complex::Complex;
use std::env;
use std::fs;
use std::io::Write;
use std::path::Path;
#[cfg(legacy)]
use symbolica::LicenseManager;
use symbolica::atom::Symbol;
use symbolica::domains::float::{Float as SymbolicaFloat, FloatLike as SymbolicaFloatLike};
use symbolica::evaluate::{Instruction, Slot};
#[cfg(not(legacy))]
use symbolica::license::LicenseManager;

#[path = "portable_trace_arb_api_corrected.rs"]
mod arb_trace;
#[path = "portable_trace_selected.rs"]
mod f64_trace;

type Scalar = Complex<F<f64>>;

fn bits(value: &Scalar) -> [u64; 2] {
    [value.re.0.to_bits(), value.im.0.to_bits()]
}

fn slot_record(slot: Slot) -> Value {
    let (kind, index) = match slot {
        Slot::Param(index) => ("Param", index),
        Slot::Const(index) => ("Const", index),
        Slot::Temp(index) => ("Temp", index),
        Slot::Out(index) => ("Out", index),
    };
    json!({"kind":kind,"index":index})
}

fn validate_selection(instructions: &[Instruction], selected: &[Value]) -> Result<()> {
    for row in selected {
        let index = row["instruction_index"].as_u64().unwrap() as usize;
        let (kind, output, sources, exponent, real_hint) = match &instructions[index] {
            Instruction::Add(output, sources, real_count) => {
                assert_eq!(*real_count, 0);
                ("Add", *output, sources.clone(), None, None)
            }
            Instruction::Mul(output, sources, real_count) => {
                assert_eq!(*real_count, 0);
                ("Mul", *output, sources.clone(), None, None)
            }
            Instruction::Pow(output, base, exponent, hint) => {
                ("Pow", *output, vec![*base], Some(*exponent), Some(*hint))
            }
            Instruction::Fun(output, function, hint) => {
                let (symbol, tags, arguments) = &**function;
                assert_eq!(*symbol, Symbol::SQRT);
                assert!(tags.is_empty());
                ("Fun", *output, arguments.clone(), None, Some(*hint))
            }
            _ => return Err(eyre!("Unexpected selected portable opcode at {index}")),
        };
        assert_eq!(row["expected_portable_kind"], kind);
        assert_eq!(row["expected_portable_output"], slot_record(output));
        assert_eq!(
            row["expected_portable_sources"],
            json!(sources.into_iter().map(slot_record).collect::<Vec<_>>())
        );
        if let Some(value) = exponent {
            assert_eq!(row["expected_integer_exponent"], value);
        }
        if let Some(value) = real_hint {
            assert_eq!(row["expected_real_hint"], value);
        }
    }
    Ok(())
}

fn write(path: &Path, value: &Value) -> Result<()> {
    let mut file = fs::OpenOptions::new()
        .write(true)
        .create_new(true)
        .open(path)?;
    file.write_all(&serde_json::to_vec_pretty(value)?)?;
    file.write_all(b"\n")?;
    file.sync_all()?;
    Ok(())
}

fn main() -> Result<()> {
    assert!(
        LicenseManager::is_licensed(),
        "Matching owner licence rejected; no retry"
    );
    let args: Vec<_> = env::args().collect();
    assert_eq!(args.len(), 5);
    let owner = &args[1];
    assert!(owner == "historical" || owner == "candidate3");
    assert_eq!(cfg!(legacy), owner == "historical");
    let packet: Value = serde_json::from_slice(&fs::read(&args[3])?)?;
    let rows = packet["cases"]
        .as_array()
        .ok_or_else(|| eyre!("Missing case"))?;
    assert_eq!(rows.len(), 1);
    let case = &rows[0];
    assert_eq!(case["case_id"], "channel_0_cut_group_2_historical_call_14");
    assert_eq!(case["cut_group_id"], 2);
    let selection = &packet["selection"]["owners"][owner]["selected"];
    let selected_rows = selection
        .as_array()
        .ok_or_else(|| eyre!("Missing static selection"))?;
    let mut selected = selected_rows
        .iter()
        .map(|row| row["instruction_index"].as_u64().unwrap() as usize)
        .collect::<Vec<_>>();
    selected.sort_unstable();
    selected.dedup();
    assert_eq!(selected.len(), selected_rows.len());
    assert!(selected.len() <= 64);
    let out = Path::new(&args[4]);
    fs::create_dir(out)?;
    // Standard matching-owner hydration restores StateMap, dependent model/card
    // values and the fixed Vakint registry; no generation or backend activation.
    let state = State::load(Path::new(&args[2]).to_path_buf(), None, None)?;
    assert_eq!(state.process_list.processes.len(), 1);
    let ProcessCollection::CrossSections(collection) = &state
        .process_list
        .processes
        .iter()
        .next()
        .unwrap()
        .collection
    else {
        return Err(eyre!("Expected cross section"));
    };
    assert_eq!(collection.len(), 1);
    let Some(ProcessIntegrand::CrossSection(integrand)) =
        &collection.values().next().unwrap().integrand
    else {
        return Err(eyre!("Missing retained integrand"));
    };
    assert_eq!(integrand.data.graph_terms.len(), 1);
    let term = integrand.data.graph_terms.iter().next().unwrap();
    let group = term.integrand.iter().nth(2).unwrap();
    assert_eq!(group.len(), 1);
    let mut evaluator = group
        .iter()
        .next()
        .unwrap()
        .1
        .summed_function_map
        .as_ref()
        .ok_or_else(|| eyre!("Missing summed evaluator"))?
        .clone();
    let key = if cfg!(legacy) {
        "historical_params_bits"
    } else {
        "candidate3_params_bits"
    };
    let params = case[key]
        .as_array()
        .unwrap()
        .iter()
        .map(|pair| {
            Complex::new(
                F(f64::from_bits(pair[0].as_u64().unwrap())),
                F(f64::from_bits(pair[1].as_u64().unwrap())),
            )
        })
        .collect::<Vec<_>>();
    assert_eq!(params.len(), if cfg!(legacy) { 193 } else { 192 });
    if cfg!(legacy) {
        assert_eq!(bits(&params[16]), [1.0f64.to_bits(), 0]);
    }
    let q_slots = packet["input_slots"][owner]["q_time_slots"]
        .as_array()
        .unwrap()
        .iter()
        .map(|value| value.as_u64().unwrap() as usize)
        .collect::<Vec<_>>();
    assert_eq!(q_slots.len(), 2);
    assert!(
        q_slots
            .iter()
            .all(|index| bits(&params[*index]) == [500.0f64.to_bits(), 0])
    );
    let precise_params = params
        .iter()
        .map(|value| {
            Complex::new(
                F(ArbPrec::from(SymbolicaFloat::with_val(1000, value.re.0))),
                F(ArbPrec::from(SymbolicaFloat::with_val(1000, value.im.0))),
            )
        })
        .collect::<Vec<_>>();
    let program = evaluator.f64_eager.export_instructions();
    let precise_program = evaluator.arb.export_instructions();
    validate_selection(&program.instructions, selected_rows)?;
    validate_selection(&precise_program.instructions, selected_rows)?;
    let native = evaluator.f64_eager.evaluate_single(&params);
    write(
        &out.join("native-f64-before-shadow-gate.json"),
        &json!({"status":"OBSERVED_NATIVE_ONLY_NOT_SHADOW_ACCEPTANCE","bits":bits(&native)}),
    )?;
    let anchor = &packet["native_anchors"][owner];
    assert_eq!(
        bits(&native),
        [
            anchor["f64_bits"][0].as_u64().unwrap(),
            anchor["f64_bits"][1].as_u64().unwrap()
        ],
        "Native f64 must reproduce completed stage1 exactly"
    );
    let trace = f64_trace::trace(&program, &params, &selected)?;
    let accepted_f64 = trace.validated_json(&native)?;
    let precise_native = evaluator.arb.evaluate_single(&precise_params);
    write(
        &out.join("native-arb-before-shadow-gate.json"),
        &json!({"status":"OBSERVED_NATIVE_ONLY_NOT_SHADOW_ACCEPTANCE","value":arb_trace::scalar_record(&precise_native)}),
    )?;
    assert_eq!(
        precise_native.re.to_string(),
        anchor["arb_re"].as_str().unwrap()
    );
    assert_eq!(
        precise_native.im.to_string(),
        anchor["arb_im"].as_str().unwrap()
    );
    let precise_trace = arb_trace::trace(&precise_program, &precise_params, &selected)?;
    let accepted_arb = precise_trace.validated_json(&precise_native)?;
    // The selected writes have passed exact native-root gates before deriving
    // the source-exact physical cut residual from their four OSE values.
    let mut delta = Complex::new(F(0.0), F(0.0));
    let mut precise_delta = precise_params[0].zero();
    let mut selected_values = Vec::new();
    let mut cut_edges = Vec::new();
    for row in selected_rows {
        let index = row["instruction_index"].as_u64().unwrap() as usize;
        let value = trace
            .operation_value(index)
            .ok_or_else(|| eyre!("Selected f64 write not executed"))?;
        let precise_value = precise_trace
            .operation_value(index)
            .ok_or_else(|| eyre!("Selected Arb write not executed"))?;
        if row["role"] == "ose" {
            let edge = row["physical_edge_id"].as_u64().unwrap();
            if [2, 6, 9, 11].contains(&edge) {
                cut_edges.push(edge);
            }
        }
        selected_values.push(json!({"selection":row,"f64_bits":bits(value),"arb":arb_trace::scalar_record(precise_value)}));
    }
    cut_edges.sort_unstable();
    assert_eq!(cut_edges, [2, 6, 9, 11]);
    // Use the same explicit diagnostic summation order on both owners.
    for edge in [2, 6, 9, 11] {
        let row = selected_rows
            .iter()
            .find(|row| row["role"] == "ose" && row["physical_edge_id"] == edge)
            .unwrap();
        let index = row["instruction_index"].as_u64().unwrap() as usize;
        delta += trace.operation_value(index).unwrap();
        precise_delta += precise_trace.operation_value(index).unwrap();
    }
    for index in &q_slots {
        delta -= &params[*index];
        precise_delta -= &precise_params[*index];
    }
    let outputs = json!({
        "schema":"gl20.one-group2-native-gated-intermediates.v1", "owner":owner,"case_id":case["case_id"],
        "native_f64_bits":bits(&native),"native_arb":arb_trace::scalar_record(&precise_native),
        "f64_trace":accepted_f64,"arb_trace":accepted_arb,"selected_values":selected_values,
        "physical_cut_residual":{"formula":"E2+E6+E9+E11−Q0_0−Q1_0","energy_sum_order":[2,6,9,11],"external_subtraction_slots_in_order":q_slots,"f64_bits":bits(&delta),"arb":arb_trace::scalar_record(&precise_delta)},
        "input_component_precision_observations":precise_params.iter().enumerate().map(|(index,value)|{
            let observed = arb_trace::scalar_record(value);
            json!({"slot":index,"re_actual_inner_precision_bits":observed["re"]["actual_inner_precision_bits"],"im_actual_inner_precision_bits":observed["im"]["actual_inner_precision_bits"]})
        }).collect::<Vec<_>>(),
        "scope":"One retained original binary64 buffer, exact binary lift, two native eager calls and two exact-root-gated portable traces. No new physical point or complete integrand/API evaluation; no gold acceptance."
    });
    write(&out.join("selected-intermediates.json"), &outputs)?;
    write(
        &out.join("completion.json"),
        &json!({"status":"PASS_GROUP2_INTERMEDIATES_NATIVE_EXACT_GATED_NOT_GL20_ACCEPTANCE","state_loads":1,"f64_calls":1,"stored_arb1000_calls":1,"shadow_calls":2,"case_count":1,"native_f64_stage1_anchor_exact":true,"native_arb_stage1_anchor_exact":true}),
    )?;
    Ok(())
}

#![recursion_limit = "512"]
//! Roots-only comparison of retained eager siblings at retained binary64 inputs.
use color_eyre::{Result, eyre::eyre};
use gammaloop_api::state::State;
use gammalooprs::{
    integrands::process::ProcessIntegrand,
    processes::process::ProcessCollection,
    utils::{ArbPrec, F},
};
use serde_json::{Value, json};
use spenso::algebra::complex::Complex;
use std::{env, fs, io::Write, path::Path};
#[cfg(legacy)]
use symbolica::LicenseManager;
use symbolica::domains::float::{Float as SymbolicaFloat, FloatLike as SymbolicaFloatLike};
#[cfg(not(legacy))]
use symbolica::license::LicenseManager;

type Scalar = Complex<F<f64>>;
fn bits(value: &Scalar) -> [u64; 2] {
    [value.re.0.to_bits(), value.im.0.to_bits()]
}
fn write(path: &Path, value: &Value) -> Result<()> {
    let mut f = fs::OpenOptions::new()
        .write(true)
        .create_new(true)
        .open(path)?;
    f.write_all(&serde_json::to_vec_pretty(value)?)?;
    f.write_all(b"\n")?;
    f.sync_all()?;
    Ok(())
}
fn main() -> Result<()> {
    assert!(
        LicenseManager::is_licensed(),
        "Matching owner license rejected; stop without retry"
    );
    let a: Vec<_> = env::args().collect();
    assert_eq!(a.len(), 5);
    let owner = &a[1];
    assert!(owner == "historical" || owner == "candidate3");
    assert_eq!(cfg!(legacy), owner == "historical");
    let cases: Value = serde_json::from_slice(&fs::read(&a[3])?)?;
    let rows = cases["cases"]
        .as_array()
        .ok_or_else(|| eyre!("Missing exact cases"))?;
    assert_eq!(rows.len(), 16);
    let out = Path::new(&a[4]);
    fs::create_dir(out)?;
    // Standard matching-owner hydration only: restores Symbolica StateMap,
    // dependent model values/card and fixed Vakint registry. No runtime activation.
    let state = State::load(Path::new(&a[2]).to_path_buf(), None, None)?;
    assert_eq!(state.process_list.processes.len(), 1);
    let ProcessCollection::CrossSections(collection) = &state
        .process_list
        .processes
        .iter()
        .next()
        .unwrap()
        .collection
    else {
        return Err(eyre!("Expected cross section"));
    };
    assert_eq!(collection.len(), 1);
    let cs = collection.values().next().unwrap();
    let Some(ProcessIntegrand::CrossSection(integrand)) = &cs.integrand else {
        return Err(eyre!("Missing retained integrand"));
    };
    assert_eq!(integrand.data.graph_terms.len(), 1);
    let term = integrand.data.graph_terms.iter().next().unwrap();
    let mut evaluators = Vec::new();
    for row in term.integrand.iter() {
        assert_eq!(row.len(), 1);
        evaluators.push(
            row.iter()
                .next()
                .unwrap()
                .1
                .summed_function_map
                .as_ref()
                .ok_or_else(|| eyre!("Missing retained summed function map"))?
                .clone(),
        );
    }
    assert_eq!(evaluators.len(), 4);
    let parameter_key = if cfg!(legacy) {
        "historical_params_bits"
    } else {
        "candidate3_params_bits"
    };
    let expected_count = if cfg!(legacy) { 193 } else { 192 };
    let mut programs = Vec::new();
    for (group, e) in evaluators.iter().enumerate() {
        assert_eq!(e.f64_eager.get_input_len(), expected_count);
        assert_eq!(e.arb.get_input_len(), expected_count);
        assert_eq!(e.f64_eager.get_output_len(), 1);
        assert_eq!(e.arb.get_output_len(), 1);
        programs.push(json!({"cut_group_id":group,
            "f64_constants_bits":e.f64_eager.get_constants().iter().map(bits).collect::<Vec<_>>(),
            "arb_constants":e.arb.get_constants().iter().map(|c|json!({"re":c.re.to_string(),"im":c.im.to_string(),"re_precision_bits":c.re.get_precision(),"im_precision_bits":c.im.get_precision()})).collect::<Vec<_>>() }));
    }
    write(&out.join("program-constants.json"), &json!(programs))?;
    let mut outputs = Vec::new();
    let mut groups = [0usize; 4];
    for row in rows {
        let group = row["cut_group_id"].as_u64().unwrap() as usize;
        assert!(group < 4);
        groups[group] += 1;
        let raw = row[parameter_key]
            .as_array()
            .ok_or_else(|| eyre!("Missing owner bit buffer"))?;
        assert_eq!(raw.len(), expected_count);
        let params = raw
            .iter()
            .map(|pair| {
                let p = pair.as_array().unwrap();
                assert_eq!(p.len(), 2);
                Complex::new(
                    F(f64::from_bits(p[0].as_u64().unwrap())),
                    F(f64::from_bits(p[1].as_u64().unwrap())),
                )
            })
            .collect::<Vec<_>>();
        if cfg!(legacy) {
            assert_eq!(bits(&params[16]), [1.0f64.to_bits(), 0]);
        }
        let e = &mut evaluators[group];
        let actual = e.f64_eager.evaluate_single(&params);
        let actual_bits = bits(&actual);
        if cfg!(legacy) {
            let expected = row["historical_output_bits"].as_array().unwrap();
            assert_eq!(expected.len(), 1);
            let expected = expected[0].as_array().unwrap();
            assert_eq!(
                actual_bits,
                [expected[0].as_u64().unwrap(), expected[1].as_u64().unwrap()],
                "Old native output must reproduce retained trace exactly"
            );
        }
        let precise_params = params
            .iter()
            .map(|v| {
                Complex::new(
                    F(ArbPrec::from(SymbolicaFloat::with_val(1000, v.re.0))),
                    F(ArbPrec::from(SymbolicaFloat::with_val(1000, v.im.0))),
                )
            })
            .collect::<Vec<_>>();
        assert!(
            precise_params
                .iter()
                .all(|v| v.re.get_precision() == 1000 && v.im.get_precision() == 1000)
        );
        let precise = e.arb.evaluate_single(&precise_params);
        outputs.push(json!({"case_id":row["case_id"],"cut_group_id":group,"f64_bits":actual_bits,
            "arb_re":precise.re.to_string(),"arb_im":precise.im.to_string(),
            "arb_re_precision_bits":precise.re.get_precision(),"arb_im_precision_bits":precise.im.get_precision()}));
    }
    assert_eq!(groups, [4, 4, 4, 4]);
    write(
        &out.join("results.json"),
        &json!({"owner":owner,"results":outputs}),
    )?;
    write(
        &out.join("completion.json"),
        &json!({"status":"PASS_ROOTS_ONLY_COMMON_BINARY64_INPUTS_NOT_FULL_INTEGRAND_ACCEPTANCE","owner":owner,
        "state_loads":1,"f64_calls":16,"stored_arb1000_calls":16,"shadow_calls":0,"new_samples":0,"generation_calls":0,"backend_activation_calls":0,
        "scope":"Existing exact-tree high-precision sibling at exactly lifted retained binary64 inputs; no fresh high-precision physical kinematics or final-integrand accuracy claim."}),
    )?;
    Ok(())
}

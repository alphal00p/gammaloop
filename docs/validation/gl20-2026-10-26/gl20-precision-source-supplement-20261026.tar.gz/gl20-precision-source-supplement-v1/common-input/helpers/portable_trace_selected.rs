//! Private diagnostic interpreter for the two retained main eager instruction streams.
//!
//! This module uses only public portable instructions and the owner's original scalar type.
//! It does not load states, build evaluators, resolve constants, activate backends, or write files.
//! The driver must call the actual stored eager evaluator on the same inputs, then use
//! `TraceRecord::validated_json` before accepting or publishing a trace.
//!
//! Add/Mul/Pow follow the generic native interpreter's operand order and scalar methods.
//! Public real-prefix/phase hints are deliberately ignored, as in `evaluate_single`.

use color_eyre::Result;
use color_eyre::eyre::eyre;
use gammalooprs::utils::F;
use serde_json::{self, Value, json};
use spenso::algebra::complex::Complex;
use std::fmt::Write;
use std::mem;
use symbolica::atom::Symbol;
use symbolica::domains::float::{FloatLike, Real};
use symbolica::evaluate::{ExportedInstructions, Instruction, Slot};

pub(crate) type Scalar = Complex<F<f64>>;

const MAX_INSTRUCTIONS: usize = 150_000;
const MAX_STORAGE_SLOTS: usize = 16_384;
const MAX_OPERATION_VALUES: usize = 64;
const MAX_TRACE_JSON_BYTES: usize = 128 * 1024;
const ONE_BITS: [u64; 2] = [0x3ff0_0000_0000_0000, 0];

/// A register write at an original exported instruction ordinal.
#[derive(Debug, Clone, Copy)]
pub(crate) struct OperationValue {
    pub(crate) instruction_index: usize,
    pub(crate) value_bits: [u64; 2],
    pub(crate) value: Scalar,
}

/// Unaccepted trace data; compare its root with the actual native eager result first.
#[derive(Debug)]
pub(crate) struct TraceRecord {
    pub(crate) root_bits: [u64; 2],
    pub(crate) operations: Vec<OperationValue>,
    pub(crate) executed_instruction_count: usize,
    pub(crate) executed_arithmetic_count: usize,
}

impl TraceRecord {
    /// Require exact component bits from `evaluate_single` on the same program and inputs.
    ///
    /// Errors on any difference, including a signed-zero or NaN-payload difference. No trace
    /// should be accepted if this check fails; the driver must stop without retrying.
    pub(crate) fn operation_value(&self, index: usize) -> Option<&Scalar> {
        self.operations
            .iter()
            .find(|row| row.instruction_index == index)
            .map(|row| &row.value)
    }

    pub(crate) fn validate_native(&self, native_value: &Scalar) -> Result<()> {
        let native_bits = scalar_bits(native_value);
        if self.root_bits != native_bits {
            return Err(eyre!(
                "Portable trace root {:?} differs from native eager root {:?}",
                self.root_bits,
                native_bits
            ));
        }
        Ok(())
    }

    /// Validate the native root and return a bounded, accepted JSON record.
    ///
    /// Driver sequence: export the actual eager object, obtain its native `evaluate_single`
    /// value, call `trace(&exported, &params)`, then call `record.validated_json(&native)`.
    /// The CSV string has no header: each row is `instruction_index,real_u64_bits,imag_u64_bits`.
    /// A string keeps all active operation writes below 2 MiB even under pretty JSON encoding.
    /// Join and terminal Assign writes are included; labels and jumps do not write values.
    pub(crate) fn validated_json(&self, native_value: &Scalar) -> Result<Value> {
        self.validate_native(native_value)?;
        let mut rows = String::new();
        for operation in &self.operations {
            writeln!(
                &mut rows,
                "{},{},{}",
                operation.instruction_index, operation.value_bits[0], operation.value_bits[1]
            )?;
        }
        let value = json!({
            "schema": "gl20.portable-main-eager-trace.v1",
            "native_root_verified": true,
            "root_bits": self.root_bits,
            "executed_instruction_count": self.executed_instruction_count,
            "executed_arithmetic_count": self.executed_arithmetic_count,
            "operation_value_count": self.operations.len(),
            "operation_value_columns": ["instruction_index", "real_u64_bits", "imag_u64_bits"],
            "operation_values_csv": rows,
        });
        if serde_json::to_vec(&value)?.len() >= MAX_TRACE_JSON_BYTES
            || serde_json::to_vec_pretty(&value)?.len() >= MAX_TRACE_JSON_BYTES
        {
            return Err(eyre!(
                "Accepted trace would exceed the 2 MiB per-case bound"
            ));
        }
        Ok(value)
    }
}

#[derive(Clone, Copy)]
struct Layout {
    input_count: usize,
    constant_count: usize,
    temporary_count: usize,
    total_count: usize,
}

impl Layout {
    fn new(program: &ExportedInstructions<Scalar>, input_count: usize) -> Result<Self> {
        if !matches!(input_count, 192 | 193) {
            return Err(eyre!("Unexpected retained main input count {input_count}"));
        }
        let constant_count = program.constants.len();
        let temporary_count = program.temporary_count;
        let total_count = input_count
            .checked_add(constant_count)
            .and_then(|count| count.checked_add(temporary_count))
            .and_then(|count| count.checked_add(1))
            .ok_or_else(|| eyre!("Portable storage size overflow"))?;
        if total_count > MAX_STORAGE_SLOTS {
            return Err(eyre!("Portable storage exceeds the qualified slot bound"));
        }
        Ok(Self {
            input_count,
            constant_count,
            temporary_count,
            total_count,
        })
    }

    fn index(self, slot: Slot) -> Result<usize> {
        match slot {
            Slot::Param(index) if index < self.input_count => Ok(index),
            Slot::Const(index) if index < self.constant_count => Ok(self.input_count + index),
            Slot::Temp(index) if index < self.temporary_count => {
                Ok(self.input_count + self.constant_count + index)
            }
            Slot::Out(0) => Ok(self.total_count - 1),
            _ => Err(eyre!("Out-of-range portable slot {slot}")),
        }
    }

    fn destination(self, slot: Slot) -> Result<usize> {
        if matches!(slot, Slot::Param(_) | Slot::Const(_)) {
            return Err(eyre!(
                "Instruction attempts to overwrite input/constant {slot}"
            ));
        }
        self.index(slot)
    }
}

struct Storage {
    layout: Layout,
    values: Vec<Scalar>,
    initialized: Vec<bool>,
}

impl Storage {
    fn new(layout: Layout, program: &ExportedInstructions<Scalar>, params: &[Scalar]) -> Self {
        let mut values = vec![Scalar::new_zero(); layout.total_count];
        let mut initialized = vec![false; layout.total_count];
        for (index, value) in params.iter().chain(&program.constants).enumerate() {
            values[index].set_from(value);
            initialized[index] = true;
        }
        Self {
            layout,
            values,
            initialized,
        }
    }

    fn read(&self, slot: Slot) -> Result<&Scalar> {
        let index = self.layout.index(slot)?;
        if !self.initialized[index] {
            return Err(eyre!(
                "Portable instruction reads unwritten temporary {slot}"
            ));
        }
        Ok(&self.values[index])
    }

    fn write(&mut self, slot: Slot, value: Scalar) -> Result<()> {
        let index = self.layout.destination(slot)?;
        self.values[index] = value;
        self.initialized[index] = true;
        Ok(())
    }

    fn swap_from(&mut self, slot: Slot, value: &mut Scalar) -> Result<()> {
        let index = self.layout.destination(slot)?;
        mem::swap(&mut self.values[index], value);
        self.initialized[index] = true;
        Ok(())
    }
}

fn scalar_bits(value: &Scalar) -> [u64; 2] {
    [value.re.0.to_bits(), value.im.0.to_bits()]
}

fn validate_target(
    instructions: &[Instruction],
    instruction_index: usize,
    target: usize,
) -> Result<()> {
    if target <= instruction_index
        || !matches!(instructions.get(target), Some(Instruction::Label(label)) if *label == target)
    {
        return Err(eyre!(
            "Invalid/non-forward portable target {target} at instruction {instruction_index}"
        ));
    }
    Ok(())
}

/// Check the complete portable stream without performing scalar arithmetic.
///
/// The driver may call this before its native eager call. The supported contract is one main
/// output and the exact retained input layout. Unknown functions/Powf fail before tracing.
pub(crate) fn validate_program(
    program: &ExportedInstructions<Scalar>,
    params: &[Scalar],
) -> Result<()> {
    if program.instructions.is_empty() || program.instructions.len() > MAX_INSTRUCTIONS {
        return Err(eyre!(
            "Portable instruction count is outside the qualified bound"
        ));
    }
    let layout = Layout::new(program, params.len())?;
    if params.len() == 193 && scalar_bits(&params[16]) != ONE_BITS {
        return Err(eyre!(
            "Historical retained override_if input16 must be complex ONE"
        ));
    }
    for (instruction_index, instruction) in program.instructions.iter().enumerate() {
        match instruction {
            Instruction::Add(output, sources, _) | Instruction::Mul(output, sources, _) => {
                layout.destination(*output)?;
                if sources.is_empty() {
                    return Err(eyre!(
                        "Empty operand list at instruction {instruction_index}"
                    ));
                }
                for source in sources {
                    layout.index(*source)?;
                }
            }
            Instruction::Pow(output, base, _, _) | Instruction::Assign(output, base) => {
                layout.destination(*output)?;
                layout.index(*base)?;
            }
            Instruction::Fun(output, function, _) => {
                let (symbol, tags, arguments) = &**function;
                if *symbol != Symbol::SQRT || !tags.is_empty() || arguments.len() != 1 {
                    return Err(eyre!(
                        "Unsupported function at instruction {instruction_index}"
                    ));
                }
                layout.destination(*output)?;
                layout.index(arguments[0])?;
            }
            Instruction::IfElse(condition, target) => {
                layout.index(*condition)?;
                validate_target(&program.instructions, instruction_index, *target)?;
            }
            Instruction::Goto(target) => {
                validate_target(&program.instructions, instruction_index, *target)?;
            }
            Instruction::Label(label) => {
                if *label != instruction_index {
                    return Err(eyre!(
                        "Portable label ordinal mismatch at {instruction_index}"
                    ));
                }
            }
            Instruction::Join(output, condition, true_source, false_source) => {
                layout.destination(*output)?;
                for source in [condition, true_source, false_source] {
                    layout.index(*source)?;
                }
            }
            Instruction::Powf(..) => {
                return Err(eyre!("Unsupported Powf at instruction {instruction_index}"));
            }
        }
    }
    Ok(())
}

/// Trace only selected writes of a retained program using the original fixed f64 operations.
///
/// No result is accepted by this function alone. Call `TraceRecord::validated_json` with the
/// direct `evaluate_single` result on the identical eager object and input buffer. Errors stop
/// the case; callers must not repair, retry, or publish an incomplete trace as verified.
pub(crate) fn trace(
    program: &ExportedInstructions<Scalar>,
    params: &[Scalar],
    selected: &[usize],
) -> Result<TraceRecord> {
    validate_program(program, params)?;
    let layout = Layout::new(program, params.len())?;
    let mut storage = Storage::new(layout, program, params);
    let mut tmp = Scalar::new_zero();
    let mut instruction_index = 0;
    let mut executed_instruction_count = 0;
    let mut executed_arithmetic_count = 0;
    let mut operations = Vec::new();
    while instruction_index < program.instructions.len() {
        executed_instruction_count += 1;
        if executed_instruction_count > MAX_INSTRUCTIONS {
            return Err(eyre!(
                "Portable execution exceeded the qualified instruction bound"
            ));
        }
        let mut next_instruction = instruction_index + 1;
        let mut written = None;
        match &program.instructions[instruction_index] {
            Instruction::Add(output, sources, _) => {
                tmp.set_from(storage.read(sources[0])?);
                for source in &sources[1..] {
                    tmp += storage.read(*source)?;
                }
                storage.swap_from(*output, &mut tmp)?;
                written = Some(*output);
                executed_arithmetic_count += 1;
            }
            Instruction::Mul(output, sources, _) => {
                tmp.set_from(storage.read(sources[0])?);
                for source in &sources[1..] {
                    tmp *= storage.read(*source)?;
                }
                storage.swap_from(*output, &mut tmp)?;
                written = Some(*output);
                executed_arithmetic_count += 1;
            }
            Instruction::Pow(output, base, exponent, _) => {
                let base = storage.read(*base)?;
                let value = if *exponent == -1 {
                    base.inv()
                } else if *exponent >= 0 {
                    base.pow(*exponent as u64)
                } else {
                    base.pow(exponent.unsigned_abs()).inv()
                };
                storage.write(*output, value)?;
                written = Some(*output);
                executed_arithmetic_count += 1;
            }
            Instruction::Fun(output, function, _) => {
                let (_, _, arguments) = &**function;
                let value = storage.read(arguments[0])?.sqrt();
                storage.write(*output, value)?;
                written = Some(*output);
                executed_arithmetic_count += 1;
            }
            Instruction::Assign(output, source) => {
                let value = storage.read(*source)?.clone();
                storage.write(*output, value)?;
                written = Some(*output);
            }
            Instruction::IfElse(condition, target) => {
                if storage.read(*condition)?.is_fully_zero() {
                    next_instruction = *target;
                }
            }
            Instruction::Goto(target) => next_instruction = *target,
            Instruction::Label(_) => {}
            Instruction::Join(output, condition, true_source, false_source) => {
                let source = if !storage.read(*condition)?.is_fully_zero() {
                    *true_source
                } else {
                    *false_source
                };
                let value = storage.read(source)?.clone();
                storage.write(*output, value)?;
                written = Some(*output);
            }
            Instruction::Powf(..) => {
                return Err(eyre!("Unreviewed Powf reached after portable preflight"));
            }
        }
        if let Some(output) = written.filter(|_| selected.contains(&instruction_index)) {
            if operations.len() == MAX_OPERATION_VALUES {
                return Err(eyre!(
                    "Portable trace exceeds the qualified operation-value bound"
                ));
            }
            operations.push(OperationValue {
                instruction_index,
                value_bits: scalar_bits(storage.read(output)?),
                value: *storage.read(output)?,
            });
        }
        instruction_index = next_instruction;
    }
    Ok(TraceRecord {
        root_bits: scalar_bits(storage.read(Slot::Out(0))?),
        operations,
        executed_instruction_count,
        executed_arithmetic_count,
    })
}

"""Seal the one final roots-only probe packet; no compilation or evaluation."""
import ast
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
OUT = next(p for p in HERE.parents if p.name == "current-matched-decode-and-compare-20261026")
def record(path):
    path=Path(path).resolve()
    with path.open("rb") as stream: checksum=hashlib.file_digest(stream,"sha256").hexdigest()
    return {"path":str(path),"sha256":checksum,"bytes":path.stat().st_size}
identities=json.loads((HERE/"owner-identities.json").read_text())
owners={}
for name,o in identities["owners"].items():
    n=dict(o)
    n.update(unit="gl20-common-input-roots-precision-"+name+"-20261026.service", compiler_version="1.97.0" if name=="historical" else "1.98.1", externs=o["selected_externs"], library_dirs=o["dependency_library_directories"], native_search=o["native_link_search_paths"], base_env_source=o["base_environment_source"], base_env_key=o["base_environment_key"], thread_environment=o["thread_environment_values"], source_freezes=[o["source_freeze"]["path"]])
    if "original_source_freeze" in o:n["source_freezes"].append(o["original_source_freeze"]["path"])
    assert len(n["state_files"])==12 and len(n["externs"])==7
    owners[name]=n
for name in ["run_roots.py","start_roots.py","prepare_roots_packet.py"]: ast.parse((HERE/name).read_text())
cases=json.loads((HERE/"cases.json").read_text())["cases"];assert len(cases)==16
assert all(len(c["historical_params_bits"])==193 and len(c["candidate3_params_bits"])==192 and c["historical_params_bits"][16]==[4607182418800017408,0] and c["historical_params_bits"][80]==c["candidate3_params_bits"][79] for c in cases)
controls=[HERE/name for name in ["prepare_roots_packet.py","run_roots.py","start_roots.py","launch_roots.sh","helpers/roots_only.rs","roots-only-source-review.json","owner-identities.json","cases.json","caseprep.py","cases-preparation-review.json"]]
controls += [OUT/"run_decoder.py",HERE.parent/"regression-valid-cut-fixtures/stored-evaluator-comparison/parameter-input-remap.json", HERE.parent/"regression-valid-cut-fixtures/stored-evaluator-comparison/override-if-source-contract.json", HERE.parent/"regression-valid-cut-fixtures/stored-evaluator-comparison/active-model-inputs.json"]
m={"schema":"gl20.common-input-roots-f64-and-stored-arb1000.final-packet.v1","status_at_freeze":"PREPARED_NOT_EXECUTED_AWAITING_ROOT_FINAL_GO","taskset":"/nix/store/156fzvaz2nsq2hk0fkzn9jwk90bnzyn9-util-linux-2.42.2-bin/bin/taskset","helper":record(HERE/"helpers/roots_only.rs"),"cases":record(HERE/"cases.json"),"controls":[record(p) for p in controls],"owners":owners,
"scope":"Stage1 roots only. Two sequential matching-owner helpers; each one copied StateLoad,16 native f64 eager calls anchored against all16 historical retained outputs for old owner,16 existing exact-tree ArbPrec1000 sibling calls on exactly lifted same binary64 inputs. No shadow compiled or invoked. No sample construction, new physical kinematics, full integrand/evaluation API, generation/preprocessing, backend activation, 5L physical work or production/gold/model/tolerance edits.",
"counts_per_owner":{"direct_rustc_invocations":1,"helper_invocations":1,"state_loads":1,"retained_cases":16,"cut_groups":4,"native_f64_calls":16,"stored_arb1000_calls":16,"shadow_calls":0,"new_sample_evaluations":0,"generation_calls":0,"backend_activation_calls":0,"retries":0},
"bounds_per_owner":{"setup_cpus":[145,146],"setup_seconds":1800,"runtime_cpus":[140],"runtime_seconds":600,"math_threads":1,"memory_max_bytes":17179869184,"memory_swap_max":0,"minimum_host_available_bytes":50000000000,"unit_runtime_max_seconds":2460},
"admission":"Root explicitly re-authorized prior qualified GL20 PID/starttick+PGID ownership, source/dependency/copy guards, MemoryMax/swap0/fresh50GB/bounded cleanup for this pure small non5L storedIR math probe. No PIDFD/bb322/936/2a8 system is added or borrowed; active q0 PIDFD guard is untouched.",
"input_binding":"Use exact full named192map,175 literal names+17explicitQ-presentation correspondences, including ZERO reorder; dropping historical slot16 alone is wrong at20entries percase. Historical override_if slot16 is literalONE in allcases; GC94oldslot80 maps C3slot79. No GC85-to94 rewrite or FnMap RHS compilation.",
"precision":"Public SymbolicaFloat::with_val(1000,raw_f64) -> public ArbPrec::from preserves each recorded binary64 component exactly (including signedzero), then evaluates existing separately built exact-Rational-tree arb sibling. Record actual input/output/coefficient precision and all coefficient values. This diagnoses IR/coefficient arithmetic at the common rounded input; it does not regenerate highprecision physical momenta or establish full-integrand/currentgold accuracy.",
"success_and_limits":"All16 oldnative outputs must bitmatch retained oldtrace before acceptance. Compare C3native roots and owner-native stored1000bit roots under exact input mapping. Keep historicalgold,currentgold,oldactualtrace separate. A common-input highprecision agreement diagnoses evaluator-stage math only, not full CT/aggregate or snapshot acceptance; mismatch preserves coefficient/IR/binding evidence. No rootcausal claim without actual results.",
"excluded_pending_stage2":{"helper":"helpers/portable_trace.rs","scope":"Preserved source only; no import, build, shadow arithmetic or intermediate trace in stage1."}}
with (HERE/"final-probe-packet.json").open("x") as f:json.dump(m,f,indent=2);f.write("\n")
print(json.dumps({"packet":record(HERE/"final-probe-packet.json"),"helper":m["helper"],"cases":m["cases"],"owners":list(owners),"counts":m["counts_per_owner"],"bounds":m["bounds_per_owner"]}))

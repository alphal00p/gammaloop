#!/usr/bin/env python3
"""Prepare retained common-input bits. JSON/string/integer copying only; no evaluator."""
import collections
import hashlib
import json
import pathlib
import re

HERE = pathlib.Path(__file__).resolve().parent
C3 = HERE.parent
CT = C3.parent.parent
OUT = CT.parent
BASE = OUT.parent
TRACE = CT / 'historical/parsed-trace/dispatches.jsonl'
SUMMARY = CT / 'historical/parsed-trace/summary.json'
C3_PROCESS = C3 / 'regression-valid-cut-fixtures/matched-state-decode/run1/export/process-0-cross-section.json'
H_PROCESS = BASE / 'historical-generation-proposal/prepared-source-and-driver/historical-matched-decoder-20261026/controller-v2/run1/export/process-0-cross-section.json'
BINDINGS = OUT / 'runtime-parameter-binding-comparison.json'
ONE = [4607182418800017408, 0]


def file_info(path):
    data = path.read_bytes()
    return {'path': str(path), 'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}


def ordered_names(term):
    names = []
    for part in term['param_builder']['ordered_pairs']:
        assert part['start'] == len(names)
        assert part['end'] - part['start'] == len(part['parameters'])
        names.extend(part['parameters'])
    assert len(names) == len(set(names))
    return names


def cut_groups(term):
    result = {}
    for group, cuts in re.findall(r'CutGroupId\((\d+)\): CutGroup \{ cuts: \[([^]]*)\]', term['cut_groups_debug']):
        result[int(group)] = [int(x) for x in re.findall(r'CutId\((\d+)\)', cuts)]
    assert set(result) == set(range(4))
    return result


def edge_boundary(term, cut_id):
    hedge_edge = {h['hedge']: h['edge'] for h in term['graph']['hedges']}
    cut = term['cuts'][cut_id]
    left = sorted(hedge_edge[x] for x in cut['left_cut_hedges'])
    right = sorted(hedge_edge[x] for x in cut['right_cut_hedges'])
    assert left == right
    return left


def valid_bits(rows, count):
    assert len(rows) == count
    assert all(isinstance(pair, list) and len(pair) == 2 and
               all(type(x) is int and 0 <= x < 2**64 for x in pair) for pair in rows)


summary = json.loads(SUMMARY.read_text())
raw_log = pathlib.Path(summary['input']['path'])
assert file_info(raw_log) == summary['input']
all_records = [json.loads(line) for line in TRACE.read_text().splitlines()]
records = [r for r in all_records if r['context']['role'] == 'bare_ir']
assert len(all_records) == 72 and len(records) == 16
hterm = json.loads(H_PROCESS.read_text())['runtime_graph_terms'][0]
cterm = json.loads(C3_PROCESS.read_text())['runtime_graph_terms'][0]
hnames, cnames = ordered_names(hterm), ordered_names(cterm)
assert len(hnames) == 193 and len(cnames) == 192
assert hnames[16] == 'gammalooprs::{}::override_if'
assert 'gammalooprs::{}::override_if' not in cnames
qrows = json.loads(BINDINGS.read_text())['Q_binding_presentation_candidates_separate_from_exact_match']['candidates']
assert len(qrows) == 17
qmap = {row['historical_name']: row['current_name'] for row in qrows}
assert len(qmap) == 17
h_to_c = {}
map_rows = []
for hi, name in enumerate(hnames):
    if hi == 16:
        continue
    mapped_name = qmap.get(name, name)
    ci = cnames.index(mapped_name)
    assert ci not in h_to_c.values()
    h_to_c[hi] = ci
    map_rows.append({'historical_slot': hi, 'candidate3_slot': ci,
                     'historical_name': name, 'candidate3_name': mapped_name,
                     'match': 'explicit_Q_presentation_correspondence' if name in qmap else 'exact_name'})
assert set(h_to_c.values()) == set(range(192))
assert h_to_c[89] == 114  # ZERO's position also changed; name-based mapping is essential.
assert all(h_to_c[hi] == hi - 2 for hi in range(90, 116))
assert all(ci == hi - (hi > 16) for hi, ci in h_to_c.items() if hi not in range(89, 116))
assert sum(row['match'] == 'exact_name' for row in map_rows) == 175
assert hnames[80] == cnames[79] == 'UFO::{}::GC_94'
hgroups, cgroups = cut_groups(hterm), cut_groups(cterm)
hchannels = hterm['multi_channeling_setup']['effective_channels_from_saved_settings']
cchannels = cterm['multi_channeling_setup']['effective_channels_from_saved_settings']
assert hchannels == cchannels and len(hchannels) == 4
raw_records = {}
wanted_lines = {r['trace_line'] for r in records}
with raw_log.open() as stream:
    for lineno, line in enumerate(stream, 1):
        if lineno in wanted_lines:
            raw_records[lineno] = json.loads(line)
assert len(raw_records) == 16
cases = []
for record in records:
    context = record['context']
    assert record['owner'] == 'historical' and record['backend'] == 'Eager' and record['dispatch'] == 'vector'
    assert record['parameter_names_from_owner_export'] == hnames
    bits, output = record['params_complex_f64_bits'], record['output_complex_f64_bits']
    valid_bits(bits, 193)
    valid_bits(output, 1)
    assert bits[16] == ONE
    raw = raw_records[record['trace_line']]
    assert raw['stage'] == 'gl20_retained_f64_dispatch'
    assert raw['call_id'] == record['call_id'] and raw['backend'] == 'Eager'
    assert json.loads(raw['params_bits']) == bits
    assert json.loads(raw['output_bits']) == output
    candidate = [None] * 192
    for hi, ci in h_to_c.items():
        candidate[ci] = bits[hi]
    valid_bits(candidate, 192)
    assert all(candidate[ci] == bits[hi] for hi, ci in h_to_c.items())
    assert collections.Counter(map(tuple, candidate)) == collections.Counter(map(tuple, bits[:16] + bits[17:]))
    assert candidate[79] == bits[80]
    hg = context['cut_group_id']
    cuts = context['physical_cuts']
    assert len(cuts) == 1 and hgroups[hg] == [cuts[0]['owner_cut_id']]
    boundary = cuts[0]['boundary_edge_ids']
    assert edge_boundary(hterm, cuts[0]['owner_cut_id']) == boundary
    matches = [(cg, cid) for cg, cutids in cgroups.items() for cid in cutids
               if edge_boundary(cterm, cid) == boundary]
    assert len(matches) == 1
    cg, cc = matches[0]
    # Owner-local group/cut IDs happen to agree only after this actual boundary join.
    assert cg == hg and cc == cuts[0]['owner_cut_id']
    channel = context['channel_assignment']['owner_channel']
    assert channel == hchannels[channel['channel']] == cchannels[channel['channel']]
    cases.append({
        'case_id': 'channel_%d_cut_group_%d_historical_call_%d' % (channel['channel'], cg, record['call_id']),
        'cut_group_id': cg,
        'historical_cut_group_id': hg,
        'candidate3_cut_group_id': cg,
        'historical_cut_id': cuts[0]['owner_cut_id'],
        'candidate3_cut_id': cc,
        'channel_id': channel['channel'],
        'channel_lmb_id': channel['lmb_id'],
        'channel_chord_edges': channel['loop_edges'],
        'physical_cut_boundary_edge_ids': boundary,
        'physical_cut_key': 'edges:' + ','.join(map(str, boundary)),
        'historical_params_bits': bits,
        'candidate3_params_bits': candidate,
        'historical_output_bits': output,
        'historical_call_id': record['call_id'],
        'historical_trace_line': record['trace_line'],
        'historical_timestamp': record['timestamp'],
        'historical_evaluator_key_owner_local_only': record['owner_local_evaluator_key'],
        'historical_dispatch': record['dispatch'],
        'historical_context': context,
        'historical_physical_cuts': cuts,
        'candidate3_physical_cut': cterm['cuts'][cc],
        'common_input_origin': 'retained historical post-override f64 dispatch; exact u64 bits copied; no model-value substitution',
    })
assert collections.Counter(c['cut_group_id'] for c in cases) == {0: 4, 1: 4, 2: 4, 3: 4}
assert collections.Counter(c['channel_id'] for c in cases) == {0: 4, 1: 4, 2: 4, 3: 4}
assert len({(c['channel_id'], c['cut_group_id']) for c in cases}) == 16
packet = {
    'schema': 'gl20.common-input-retained-bits.v1',
    'status': 'PREPARED_WITHOUT_EVALUATION',
    'scope': '16 retained historical bare_ir inputs; lossless name-verified mapping to candidate3, no f64 arithmetic or evaluator invocation',
    'case_count': len(cases),
    'historical_parameter_entry_count': 193,
    'candidate3_parameter_entry_count': 192,
    'bits_encoding': 'Each entry is [real_f64_to_bits_u64, imaginary_f64_to_bits_u64]; signed zeros and all payload bits preserved.',
    'source_files': [file_info(path) for path in [pathlib.Path(__file__), TRACE, SUMMARY, raw_log, H_PROCESS, C3_PROCESS, BINDINGS]],
    'parameter_mapping': {
        'historical_names': hnames,
        'candidate3_names': cnames,
        'rows': map_rows,
        'exact_name_count': 175,
        'explicit_Q_presentation_correspondence_count': 17,
        'Q_caveat': 'The 17 correspondences use the individually recorded old/current names and preserve every Q argument; they are not a claim of exact Atom identity. No blanket tag stripping.',
        'dropped': {'historical_slot': 16, 'name': hnames[16], 'verified_bits_all_16_cases': ONE},
        'GC94': {'name': hnames[80], 'historical_slot': 80, 'candidate3_slot': 79, 'all_16_bit_pairs_preserved': True},
        'index_mapping_verified_after_name_join': 'slots0..15 unchanged; old16 dropped; old89 ZERO moves to114; old90..115 map to88..113; all other old17..192 shift down one',
        'drop_only_mapping_is_insufficient': True,
    },
    'semantic_join': {
        'historical_cut_groups': hgroups,
        'candidate3_cut_groups': cgroups,
        'historical_channels': hchannels,
        'candidate3_channels': cchannels,
        'basis': 'Actual exported cut boundary edge sets and exact channel chord triples; graph frame already restored in candidate3. No evaluator-pointer join.',
        'channel_trace_caveat': 'Channel trace markers are a serial-loop-order inference retained from the reader; exact four-entry saved channel inventories agree.',
        'all_cut_group_ids_agree_after_physical_boundary_match': True,
    },
    'cases': cases,
    'limits': [
        'No eager, Arb, model, kinematic, or IR expression evaluation was performed.',
        'No function-map RHS compilation or GC85-to-GC94 normalization was performed.',
        'Candidate3 input bits deliberately retain historical coupling values, including any inactive last-bit model differences.',
        'The historical output is a retained native f64 result, not a recomputed value or a tolerance acceptance.',
        'The packet can be converted losslessly from f64 bits to an Arb binary point by an authorized driver; no higher-precision execution occurs in this preparation.',
    ],
}
output = HERE / 'cases.json'
output.write_text(json.dumps(packet, indent=2, ensure_ascii=False) + '\n')
print(json.dumps({'output': file_info(output), 'preparer': file_info(pathlib.Path(__file__)), 'cases': len(cases), 'cut_groups': dict(collections.Counter(c['cut_group_id'] for c in cases)), 'exact_names': 175, 'explicit_Q_names': 17, 'dropped_slot': 16, 'GC94': [80, 79]}, indent=2))

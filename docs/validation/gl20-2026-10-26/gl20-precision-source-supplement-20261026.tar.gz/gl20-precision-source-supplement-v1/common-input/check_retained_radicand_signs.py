"""Exact positivity of exported quadratic radicands at retained input bits.

This checks finite rational linear/quadratic forms only. It does not compute a
square root, interpret an eager program, invoke an evaluator, or create a point.
"""

import hashlib
import json
import re
from fractions import Fraction
from pathlib import Path


ROOT = Path(__file__).resolve().parent


def seal(path):
    return {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def binary64_rational(bits):
    sign = -1 if bits >> 63 else 1
    exponent = (bits >> 52) & 2047
    mantissa = bits & ((1 << 52) - 1)
    assert exponent != 2047, "finite retained input required"
    if exponent:
        mantissa += 1 << 52
        power = exponent - 1023 - 52
    else:
        power = -1074
    return sign * Fraction(mantissa) * Fraction(2) ** power


def polynomial(terms):
    result = {}
    for monomial, coefficient in terms:
        key = tuple(sorted(monomial))
        result[key] = result.get(key, Fraction(0)) + Fraction(coefficient)
    return {key: value for key, value in result.items() if value}


def expand_squares(squares):
    result = {}
    for square in squares:
        weight = Fraction(square["weight"])
        assert weight >= 0
        linear = polynomial(square["linear_form"])
        assert all(len(key) <= 1 for key in linear)
        for left, a in linear.items():
            for right, b in linear.items():
                key = tuple(sorted(left + right))
                result[key] = result.get(key, Fraction(0)) + weight * a * b
    return {key: value for key, value in result.items() if value}


def evaluate_form(terms, values):
    total = Fraction(0)
    for monomial, coefficient in terms:
        term = Fraction(coefficient)
        for variable in monomial:
            term *= values[variable]
        total += term
    return total


def inputs(names, bits):
    result = {}
    for name, (real, imaginary) in zip(names, bits, strict=True):
        match = re.search(r"::Q\((\d+),.*::cind\((\d+)\)\)", name)
        if match:
            key = "Q" + match[1] + "_" + match[2]
        elif name.startswith("UFO::{}::"):
            key = name.removeprefix("UFO::{}::")
        else:
            continue
        if key in {"MT", "MH", "Me"} or key.startswith("Q"):
            assert binary64_rational(imaginary) == 0
            result[key] = binary64_rational(real)
    return result


def main():
    audit_path = ROOT / "group2-structural-radicand-reciprocal-audit.json"
    cases_path = ROOT / "cases.json"
    audit = json.loads(audit_path.read_text())
    cases = json.loads(cases_path.read_text())
    observations = []
    proof_count = 0
    for row in audit["rows"]:
        for argument in row["sqrt_arguments"]:
            assert expand_squares(argument["weighted_sum_of_squares"]) == polynomial(
                argument["argument_polynomial"]
            )
            proof_count += 1
        for case in cases["cases"]:
            if case["cut_group_id"] != row["cut_group"]:
                continue
            owner = row["owner"]
            values = inputs(
                cases["parameter_mapping"][owner + "_names"],
                case[owner + "_params_bits"],
            )
            signs = []
            for argument in row["sqrt_arguments"]:
                value = evaluate_form(argument["argument_polynomial"], values)
                assert value > 0
                signs.append({"alias": argument["alias"], "strictly_positive": True})
            observations.append(
                {"owner": owner, "case_id": case["case_id"], "radicands": signs}
            )
    result = {
        "schema": "gl20.retained-exact-radicand-positivity.v1",
        "status": "PASS_ALL_256_RADICANDS_STRICTLY_POSITIVE",
        "scope": "Exact Fraction bookkeeping on the existing 16 binary64 input buffers and exported quadratic forms. No sqrt, eager interpreter, evaluator, new point, StateLoad, generation or backend call.",
        "inputs": [seal(audit_path), seal(cases_path), seal(Path(__file__).resolve())],
        "sum_of_squares_polynomial_identities": proof_count,
        "retained_buffer_owner_pairs": len(observations),
        "strictly_positive_radicands": sum(len(row["radicands"]) for row in observations),
        "interpretation": "All square-root arguments are strictly positive real rationals on these retained buffers. The identical polar sqrt implementations take atan2(0, positive), so a negative-axis phase or hidden pi approximation inside sqrt cannot explain the four group2 residuals.",
        "observations": observations,
    }
    (ROOT / "retained-exact-radicand-positivity.json").write_text(
        json.dumps(result, indent=2) + "\n"
    )
    print(result["status"])


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""Arithmetic on already-produced decimal output/constants only. No IR/evaluator calls."""
import collections,hashlib,json,pathlib
from decimal import Decimal,localcontext
HERE=pathlib.Path(__file__).resolve().parent
C3=HERE.parent; CT=C3.parent.parent; OUT=CT.parent; BASE=OUT.parent
HIST=pathlib.Path('/shared/codex-1/vakint_rustred/workspace/5l-push/vakint-gl20-historical-21cefae-capture')
CURRENT=C3/'regression-valid-cut-fixtures/source'
def load(p):return json.loads(p.read_text())
def info(p):return {'path':str(p.resolve()),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size}
def binary64_decimal(bits):
    sign=-1 if bits>>63 else 1
    exponent=(bits>>52)&2047;fraction=bits&((1<<52)-1)
    assert exponent!=2047
    if exponent==0:
        mantissa=fraction;power=-1074
    else:
        mantissa=(1<<52)+fraction;power=exponent-1075
    with localcontext() as ctx:
        ctx.prec=1600
        return Decimal(sign)*Decimal(mantissa)*(Decimal(2)**power)
def short(x):return format(x,'.18E')
def source_record(root,rel,start,end):
    path=root/rel;lines=path.read_text().splitlines()
    return {**info(path),'lines':[start,end],'text':'\n'.join(lines[start-1:end])}
paths={}
for owner in ('historical','candidate3'):
    for name in ('results.json','program-constants.json','completion.json'):
        paths[owner+'/'+name]=HERE/owner/'run1/outputs'/name
old_results=load(paths['historical/results.json'])['results']
new_results=load(paths['candidate3/results.json'])['results']
old_constants=load(paths['historical/program-constants.json'])
new_constants=load(paths['candidate3/program-constants.json'])
cases=load(HERE/'cases.json')['cases']; assert len(old_results)==len(new_results)==len(cases)==16
assert len(old_constants)==len(new_constants)==4
constant_rows=[]
for group,(old,new) in enumerate(zip(old_constants,new_constants)):
    assert old['cut_group_id']==new['cut_group_id']==group
    assert len(old['arb_constants'])==len(old['f64_constants_bits'])==11
    assert len(new['arb_constants'])==len(new['f64_constants_bits'])==9
    assert old['f64_constants_bits'][4]==new['f64_constants_bits'][4]==[4614256656552045848,0]
    assert all(c['re_precision_bits']==c['im_precision_bits']==1000 for c in old['arb_constants']+new['arb_constants'])
    for owner,row in [('historical',old),('candidate3',new)]:
        constant_rows.append({'owner':owner,'cut_group_id':group,'coefficients':[
            {'constant_index':i,'f64_bits':bits,**arb}
            for i,(bits,arb) in enumerate(zip(row['f64_constants_bits'],row['arb_constants']))]})
assert all(row['arb_constants'][4]==old_constants[0]['arb_constants'][4] for row in old_constants)
assert all(row['arb_constants'][4]==new_constants[0]['arb_constants'][4] for row in new_constants)
with localcontext() as ctx:
    ctx.prec=420
    old_pi=Decimal(old_constants[0]['arb_constants'][4]['re'])
    new_pi=Decimal(new_constants[0]['arb_constants'][4]['re'])
    assert old_pi==binary64_decimal(4614256656552045848)
    assert old_pi!=new_pi
    factor=(old_pi/new_pi)**8
    output_rows=[]
    for old,new,case in zip(old_results,new_results,cases):
        assert old['case_id']==new['case_id']==case['case_id']
        assert old['cut_group_id']==new['cut_group_id']==case['cut_group_id']
        assert old['f64_bits']==case['historical_output_bits'][0]
        assert old['arb_re_precision_bits']==old['arb_im_precision_bits']==new['arb_re_precision_bits']==new['arb_im_precision_bits']==1000
        ore,oim=Decimal(old['arb_re']),Decimal(old['arb_im'])
        nre,nim=Decimal(new['arb_re']),Decimal(new['arb_im'])
        assert ore!=0
        scale=max(abs(ore),abs(oim));ratio=nre/ore
        residual_re=nre-factor*ore;residual_im=nim-factor*oim
        old_f64_re,old_f64_im=map(binary64_decimal,old['f64_bits'])
        new_f64_re,new_f64_im=map(binary64_decimal,new['f64_bits'])
        output_rows.append({
            'case_id':case['case_id'],'cut_group_id':case['cut_group_id'],'channel_id':case['channel_id'],
            'physical_cut_key':case['physical_cut_key'],'channel_chord_edges':case['channel_chord_edges'],
            'historical_native_trace_anchor_exact':True,
            'f64_bits_equal':old['f64_bits']==new['f64_bits'],
            'f64_real_bits_equal':old['f64_bits'][0]==new['f64_bits'][0],
            'f64_imaginary_bits_equal':old['f64_bits'][1]==new['f64_bits'][1],
            'historical_f64_bits':old['f64_bits'],'candidate3_f64_bits':new['f64_bits'],
            'historical_f64_re_exact_decimal':str(old_f64_re),'candidate3_f64_re_exact_decimal':str(new_f64_re),
            'historical_f64_im_exact_decimal':str(old_f64_im),'candidate3_f64_im_exact_decimal':str(new_f64_im),
            'f64_re_difference':str(new_f64_re-old_f64_re),'f64_im_difference':str(new_f64_im-old_f64_im),
            'historical_arb_re':old['arb_re'],'candidate3_arb_re':new['arb_re'],
            'historical_arb_im':old['arb_im'],'candidate3_arb_im':new['arb_im'],
            'arb_new_over_old_real_ratio':str(ratio),
            'arb_relative_max_component_difference':str(max(abs(nre-ore),abs(nim-oim))/scale),
            'real_ratio_minus_pi_inverse_eighth_prediction':str(ratio-factor),
            'real_residual_after_pi_factor':str(residual_re),
            'imaginary_residual_after_pi_factor':str(residual_im),
            'relative_max_component_residual_after_pi_factor':str(max(abs(residual_re),abs(residual_im))/scale),
            'old_f64_error_to_own_arb_max_component_relative':str(max(abs(old_f64_re-ore),abs(old_f64_im-oim))/scale),
            'new_f64_error_to_own_arb_max_component_relative':str(max(abs(new_f64_re-nre),abs(new_f64_im-nim))/max(abs(nre),abs(nim))),
        })
    summary={
        'all16_historical_native_trace_anchors_exact':True,
        'f64_complex_bit_equal_cases':sum(r['f64_bits_equal'] for r in output_rows),
        'f64_real_bit_equal_cases':sum(r['f64_real_bits_equal'] for r in output_rows),
        'f64_imaginary_bit_equal_cases':sum(r['f64_imaginary_bits_equal'] for r in output_rows),
        'shared_pi_factor_candidate3_over_historical':str(factor),
        'one_minus_shared_pi_factor':str(1-factor),
        'post_pi_factor_residual_by_group':{str(group):[
            {'channel_id':r['channel_id'],'real_ratio_residual':r['real_ratio_minus_pi_inverse_eighth_prediction'],
             'relative_max_component_residual':r['relative_max_component_residual_after_pi_factor']}
            for r in output_rows if r['cut_group_id']==group] for group in range(4)},
        'groups0_1_3_max_relative_component_residual':str(max(Decimal(r['relative_max_component_residual_after_pi_factor']) for r in output_rows if r['cut_group_id']!=2)),
        'group2_max_relative_component_residual':str(max(Decimal(r['relative_max_component_residual_after_pi_factor']) for r in output_rows if r['cut_group_id']==2)),
    }
report={
 'schema':'gl20.independent-produced-root-constant-comparison.v1',
 'status':'OBSERVED_CONSTANT_BOUNDARY_AND_FOUR_RESIDUALS_REMAIN',
 'method':'Decimal precision420 arithmetic solely on already-produced constants and root decimal strings. Binary64 bits decoded by integer significand/exponent to exact Decimal. No IR execution, evaluator invocation, StateLoad, graph generation, native jobs, or function-map compilation.',
 'sources':[info(path) for path in [*paths.values(),HERE/'cases.json',HERE/'roots-only-numeric-comparison.json',HERE/'helpers/roots_only.rs',pathlib.Path(__file__)]],
 'source_contract':[
  source_record(HIST,'crates/gammalooprs/src/integrands/process/param_builder.rs',1255,1262),
  source_record(CURRENT,'crates/gammalooprs/src/integrands/process/param_builder.rs',1250,1255),
  source_record(HIST,'crates/gammalooprs/src/cff/mod.rs',183,190),
  source_record(CURRENT,'crates/gammalooprs/src/cff/mod.rs',183,190),
  source_record(HIST,'crates/gammalooprs/src/processes/cross_section.rs',1754,1760),
  source_record(CURRENT,'crates/gammalooprs/src/processes/cross_section.rs',1613,1619),
 ],
 'constant_boundary':{
  'historical_pi_constant_index':4,'candidate3_pi_constant_index':4,
  'historical_pi_absolute_eager_slot':197,'candidate3_pi_absolute_eager_slot':196,
  'historical_input_count':193,'candidate3_input_count':192,
  'f64_pi_bits_identical_all4_groups':[4614256656552045848,0],
  'historical_arb_pi':str(old_pi),'candidate3_arb_pi':str(new_pi),
  'all_arb_constant_precision_bits':1000,
  'historical_arb_pi_equals_exact_lift_of_stored_f64_pi':True,
  'source_difference':'Historical ParamBuilder registers the exact rational obtained from binary64 std::f64::consts::PI. Candidate3 retains current source leaving pi to native constant evaluation at runtime precision.',
  'pi_exponent_evidence':'Peer independently inspected all4 old/current stored eager programs: constant4 is squared3times then inverted, giving pi^-8. All8 stored main function-map RHS also literally contain pi^(-8). Source CFF normalization pi^(-3L) and LU energy-delta factor2*pi agree for3loops.',
  'coefficient_array_caveat':'Arrays are ordered compiler coefficients, not a positional semantic equivalence map. Old has11 coefficients including +1/32768 and +/-4; C3 has9 including -1/32768 and +/-2. Full exact arrays are retained below; no array-index normalization beyond explicit shared pi was assumed.',
 },
 'constant_arrays':constant_rows,'rows':output_rows,'summary':summary,
 'findings':[
  'The two stored Arb programs use different pi constants. The repeated dominant real factor is predicted by their explicit inverse-eighth pi dependence.',
  'After applying that predicted factor only to stored output decimals,12cases in cut groups0,1,3 have relative max-component residuals of roughly1e-301..5e-299; this is an observation, not an acceptance tolerance or exact program-equivalence proof.',
  'Four cut_group2 cases retain additional relative residuals8.63e-24..2.685e-23. The pi constant distinction does not account for these remaining differences.',
  'All16 native f64 complex outputs differ, including all16 real and imaginary bit components. The actual f64 pi constant is identical in both owners; the Arb pi distinction alone cannot explain those native f64 mismatches.',
  'These are common fixed binary64 inputs to retained programs. Neither the Arb outputs nor their agreement establishes accuracy of a newly generated physical point, fixes the strict snapshot, or identifies a production patch.',
 ],
}
report_path=HERE/'independent-roots-output-constant-comparison.json'
report_path.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'report':info(report_path),'summary':{k:v for k,v in summary.items() if k!='post_pi_factor_residual_by_group'}},indent=2))

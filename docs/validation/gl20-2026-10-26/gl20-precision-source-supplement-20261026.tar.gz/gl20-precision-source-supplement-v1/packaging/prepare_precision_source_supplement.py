"""Package selected completed GL20 diagnostic source; never execute archived helpers."""
import ast
import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import tarfile

HERE = Path(__file__).resolve().parent
C3 = HERE.parent
OUT = C3.parents[2]
COMMON = C3 / "common-input-eager-proposal"
DESTINATION = HERE / "docs/validation/gl20-2026-10-26"
PREFIX = "gl20-precision-source-supplement-v1"
ARCHIVE_NAME = "gl20-precision-source-supplement-20261026.tar.gz"
OLD_ARCHIVE = C3 / "publication-worktree/docs/validation/gl20-2026-10-26/gl20-diagnostic-source-supplement-20261026.tar.gz"
OLD_ARCHIVE_SHA256 = "ea893fed318da3f058c3b832470d39337ae9cef98ceba04fa48d5a089adb6e89"
SOURCES = {}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def add(prefix, folder, names, stage):
    for name in names:
        path = folder / name
        assert path.is_file() and not path.is_symlink(), path
        assert path.suffix in (".py", ".rs", ".sh"), path
        logical = prefix + "/" + name
        assert logical not in SOURCES
        data = path.read_bytes()
        assert len(data) < 250000 and b"\x00" not in data, logical
        assert not re.search(rb"\b[0-9a-fA-F]{32}\b", data), (logical, "bound runtime identity")
        assert not re.search(rb"\b[0-9a-fA-F]{8}(?:-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}\b", data), logical
        assert not re.search(rb"(?:EXPECTED_PID|CONTROLLER_PID)\s*=\s*[1-9][0-9]{2,}", data), logical
        for pattern in (
            rb"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----",
            rb"\b(?:ghp_|github_pat_|sk-proj-|xox[baprs]-)[A-Za-z0-9_-]{12,}",
            rb"\bAKIA[A-Z0-9]{16}\b",
        ):
            assert not re.search(pattern, data), (logical, "credential signature")
        if path.suffix == ".py":
            ast.parse(data, filename=str(path))
        SOURCES[logical] = (path, data, stage)


def completed(path, expected):
    value = json.loads(path.read_text())
    assert value["status"] == expected, path
    return value


# The archive contains source, not the terminal records used to select it.
completed(COMMON / "historical/run1/completion.json", "PASS_ROOTS_ONLY_OWNER_NOT_FULL_GL20_ACCEPTANCE")
completed(COMMON / "candidate3/run1/completion.json", "PASS_ROOTS_ONLY_OWNER_NOT_FULL_GL20_ACCEPTANCE")
completed(COMMON / "group2-intermediate-probe/historical/run1/completion.json", "FAILED_NO_RETRY")
for owner in ("historical", "candidate3"):
    completed(COMMON / "group2-intermediate-probe-api-corrected-v2" / owner / "run1/completion.json", "PASS_GROUP2_INTERMEDIATES_OWNER_NOT_GL20_ACCEPTANCE")
    completed(COMMON / "group2-cut-constraint-counterfactual" / owner / "run1/completion.json", "PASS_FORMAL_CUT_CONSTRAINT_OWNER_NOT_GL20_ACCEPTANCE")
completed(C3 / "fullpoint-precise-proposal/candidate3/run1/completion.json", "PASS_ONE_CURRENT_FORCED_ARB_FULLPOINT_REFERENCE_NOT_GOLD_ACCEPTANCE")
strict = completed(C3 / "strict-original-regression-controller-v2/run1/completion.json", "PASS_ONE_COMPLETE_ORIGINAL_STRICT_GL20_REGRESSION")
assert strict["actual_complete_original_test_invocations"] == 1 and strict["insta_update"] == "no"
assert strict["original_main_test_source_unchanged"] and strict["updated_snapshot_unchanged_during_test"]

add("common-input", COMMON, ["caseprep.py", "prepare_owner_identities.py", "prepare_roots_packet.py", "run_roots.py", "start_roots.py", "launch_roots.sh", "compare_roots_constants.py", "check_retained_radicand_signs.py"], "completed roots and read-only comparisons")
add("common-input/helpers", COMMON / "helpers", ["roots_only.rs", "portable_trace.rs", "portable_trace_selected.rs", "portable_trace_arb.rs", "group2_intermediate.rs", "portable_trace_arb_api_corrected.rs", "group2_intermediate_api_corrected.rs", "portable_trace_arb_cut_constraint.rs", "cut_constraint_counterfactual.rs"], "completed helper/control sources, including executed failed group2 API precursor")
add("group2-failed-build", COMMON / "group2-intermediate-probe", ["prepare_group2_packet.py", "run_group2.py", "start_group2.py", "launch_group2.sh", "independent_group2_review.py"], "actual failed build; no successful numerical run in this cohort")
add("group2-accepted-v2", COMMON / "group2-intermediate-probe-api-corrected-v2", ["prepare_group2_packet.py", "run_group2.py", "start_group2.py", "launch_group2.sh", "compare_produced_intermediates.py"], "completed native-gated intermediate comparison")
add("formal-cut-counterfactual", COMMON / "group2-cut-constraint-counterfactual", ["prepare_packet.py", "run_group2.py", "start_group2.py", "launch_group2.sh", "compare_produced_formal_counterfactual.py"], "completed formal cut-constraint counterfactual; not a new physical point")
add("fullpoint-reference", C3 / "fullpoint-precise-proposal", ["prepare_fullpoint_packet.py", "run_roots.py", "start_roots.py", "launch_roots.sh", "compare_produced_fullpoint.py", "compare_produced_complex_norms.py", "helpers/fullpoint_precise.rs"], "completed single fullpoint precision reference and stored-result comparisons")
add("strict-prebuild-precursor", C3 / "strict-original-regression", ["run_strict.py", "launch_strict.sh"], "actual missing-datetime controller precursor; no harness or mathematical run")
add("strict-original", C3 / "strict-original-regression", ["prepare_test_plan.py"], "completed matching original-test plan preparer")
add("strict-original-v2", C3 / "strict-original-regression-controller-v2", ["run_strict.py", "launch_strict.sh"], "completed once-only original strict test controller")
add("packaging", HERE, ["prepare_precision_source_supplement.py"], "this source-only packager; executes no archived helper")
assert len(SOURCES) == 45

# Require the archived executed helper variants to match their accepted/failed control packets.
for packet_path in (
    COMMON / "final-probe-packet.json",
    COMMON / "group2-intermediate-probe/final-probe-packet.json",
    COMMON / "group2-intermediate-probe-api-corrected-v2/final-probe-packet.json",
    COMMON / "group2-cut-constraint-counterfactual/final-probe-packet.json",
    C3 / "fullpoint-precise-proposal/final-probe-packet.json",
    C3 / "strict-original-regression/control-manifest.json",
    C3 / "strict-original-regression-controller-v2/control-manifest.json",
):
    packet = json.loads(packet_path.read_text())
    for record in packet.get("controls", []):
        for path, data, _ in SOURCES.values():
            if record["path"] == str(path):
                assert record["sha256"] == sha(data), path

assert sha(OLD_ARCHIVE.read_bytes()) == OLD_ARCHIVE_SHA256
manifest = {
    "schema": "gl20.completed-precision-diagnostic-source-supplement.v1",
    "captured_at": "2026-10-26",
    "scope": "Exact completed diagnostic helper/controller/comparison sources since the d8dd6d16 source checkpoint. Includes actual failed build/prebuild precursors with their scope labels. No source here is a standalone activation bundle or a proof of numerical causality.",
    "exclusions": ["scientific state/model/case/input/output JSON payloads", "cohort/control/runtime manifests", "ELFs, libraries and build products", "environment files, licence or secret values", "bound activation/PID/UUID records", "unexecuted pre-review variants and lint-only composite controllers", "production source trees and snapshots", "unfinished conclusions"],
    "members": [{"path": name, "source_origin": str(path.relative_to(OUT)), "stage": stage, "sha256": sha(data), "bytes": len(data)} for name, (path, data, stage) in sorted(SOURCES.items())],
}
manifest_bytes = (json.dumps(manifest, indent=2) + "\n").encode()
readme = b"Completed GL20 precision diagnostic source preservation.\nThis supplements the unchanged d8dd6d16 source capsule.\nState, cases, outputs, binaries, environments and bound activation identities are absent.\nSource-local paths, unit labels and environment-variable names are source logic, not runtime records.\nExecuted failed API-build and prebuild controller sources are labelled; unexecuted variants are excluded.\nThe corrected strict controller completed the original test once with INSTA_UPDATE=no against the reviewed snapshot.\nThis source-only archive neither executes that test nor establishes broader CI, physics or causal acceptance.\nOriginal qualified manifests and inputs remain external; this is not a standalone launch bundle.\n"


def archive_bytes():
    buffer = io.BytesIO()
    with gzip.GzipFile(filename="", fileobj=buffer, mode="wb", compresslevel=9, mtime=0) as zipped:
        with tarfile.open(fileobj=zipped, mode="w", format=tarfile.USTAR_FORMAT) as archive:
            items = {name: data for name, (_, data, _) in SOURCES.items()}
            items.update({"MANIFEST.json": manifest_bytes, "README.txt": readme})
            for name, data in sorted(items.items()):
                info = tarfile.TarInfo(PREFIX + "/" + name)
                info.size, info.mode, info.mtime = len(data), 0o644, 0
                info.uid = info.gid = 0
                info.uname = info.gname = ""
                archive.addfile(info, io.BytesIO(data))
    return buffer.getvalue()


archive = archive_bytes()
assert archive == archive_bytes()
DESTINATION.mkdir(parents=True, exist_ok=True)
(DESTINATION / ARCHIVE_NAME).write_bytes(archive)
(DESTINATION / "precision-source-supplement-manifest.json").write_bytes(manifest_bytes)
checksums = [sha(archive) + "  " + ARCHIVE_NAME] + [row["sha256"] + "  " + row["path"] for row in manifest["members"]]
(DESTINATION / "precision-source-supplement.sha256").write_text("\n".join(checksums) + "\n")
typst = "= GL20 precision diagnostic source supplement\n\n"
typst += "This deterministic source-only supplement preserves 45 completed helper,\ncontroller and stored-data comparison sources after the d8dd6d16 checkpoint.\nIt includes the roots-only comparison, accepted group2 intermediate tracing,\nformal cut counterfactual, fullpoint precision reference and original strict-test\ncontrollers. Actual failed API-build and missing-datetime prebuild precursors\nare labelled separately; they do not imply a successful numerical run.\n\n"
typst += "Archive: `" + ARCHIVE_NAME + "`\n\nSHA256: `" + sha(archive) + "`\n\n"
typst += "Bytes: " + str(len(archive)) + ". Source members: 45. Tar member order, ownership, times and\nmodes and gzip time are fixed. Two serializations were byte-identical.\n\n"
typst += "The corrected strict controller completed the original GL20 test once with\n`INSTA_UPDATE=no` against the reviewed snapshot and unchanged strict assertion.\nThat recorded result is distinct from broader CI, physics or causal acceptance;\nthis packager runs no test or archived helper. The formal cut counterfactual is\na diagnostic on the retained input contract, not a new physical point.\n\n"
typst += "State, cases, scientific outputs, binaries, environments, licence values and\nbound activation records are excluded. The JSON manifest records original\nsource-relative paths, stage scope, byte counts and hashes; the checksum list\nalso records every source member. Original qualified manifests and inputs are\nrequired separately. This is not a standalone launch bundle. The prior 43-source\narchive is unchanged.\n"
(DESTINATION / "precision-source-manifest.typ").write_text(typst)
assert sha(OLD_ARCHIVE.read_bytes()) == OLD_ARCHIVE_SHA256
print(json.dumps({"destination": str(DESTINATION), "archive_sha256": sha(archive), "archive_bytes": len(archive), "manifest_sha256": sha(manifest_bytes), "source_files": len(SOURCES), "deterministic_repeat_equal": True, "old_archive_unchanged": True}))

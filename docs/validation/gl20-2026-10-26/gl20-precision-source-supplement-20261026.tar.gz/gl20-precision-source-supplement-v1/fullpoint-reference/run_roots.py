"""Qualified GL20 owner controller: roots only, once, no retries."""
import argparse
import ast
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import sys
import time
import traceback

os.umask(0o077)
HERE = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument("--owner", choices=("candidate3",), required=True)
parser.add_argument("--manifest-sha256", required=True)
args = parser.parse_args()
RUN = HERE / args.owner / "run1"
PHASE_CWD = RUN
OUT = next(p for p in HERE.parents if p.name == "current-matched-decode-and-compare-20261026")
PRIMITIVES = OUT / "run_decoder.py"
assert hashlib.sha256(PRIMITIVES.read_bytes()).hexdigest() == "0cb2a14879b12f448014f10ba8df12438a71edac58672a35baef86ac1eadcc70"
for node in ast.parse(PRIMITIVES.read_text()).body:
    if isinstance(node, ast.FunctionDef) and node.name in {"sha", "now", "atomic", "identity", "resources", "signal_owned_group", "reap_and_drain", "phase"}:
        code = ast.get_source_segment(PRIMITIVES.read_text(), node)
        if node.name == "phase":
            assert code.count("cwd=RUN") == 1
            code = code.replace("cwd=RUN", "cwd=PHASE_CWD")
        exec(compile(code, str(PRIMITIVES) + ":" + node.name, "exec"), globals())
assert sha(HERE / "final-probe-packet.json") == args.manifest_sha256
M = json.loads((HERE / "final-probe-packet.json").read_text())
O = M["owners"][args.owner]
M["unit"] = O["unit"]

def records(value, seen):
    if isinstance(value, dict):
        if isinstance(value.get("path"), str) and isinstance(value.get("sha256"), str) and re.fullmatch(r"[0-9a-f]{64}", value["sha256"]):
            path = value["path"]
            if path not in seen:
                assert sha(path) == value["sha256"], path
                seen.add(path)
        for child in value.values(): records(child, seen)
    elif isinstance(value, list):
        for child in value: records(child, seen)

def guard():
    assert sha(HERE / "final-probe-packet.json") == args.manifest_sha256
    records(M, set())
    for owner in M["owners"].values():
        for filename in owner["source_freezes"]:
            frozen = json.loads(Path(filename).read_text())
            if "files" in frozen:
                source_rows = frozen["files"].items()
            else:
                source_rows = [(r["path"], r["prepared_sha256"]) for r in frozen["prepared_files"]]
            for relative, checksum in source_rows:
                assert sha(Path(frozen["source"]) / relative) == checksum, relative
        root = Path(owner["state_root"])
        actual = {str(p.relative_to(root)) for p in root.rglob("*") if p.is_file() and "logs" not in p.relative_to(root).parts}
        assert actual == {r["relative"] for r in owner["state_files"]}

def no_writers():
    prefixes = tuple(str(Path(path)) + "/" for path in O["library_dirs"])
    for proc in Path("/proc").iterdir():
        if not proc.name.isdigit(): continue
        try: fds = list((proc / "fd").iterdir())
        except (FileNotFoundError, ProcessLookupError, PermissionError): continue
        for fd in fds:
            try:
                if not os.readlink(fd).startswith(prefixes): continue
                flags = int(next(x.split()[1] for x in (proc / "fdinfo" / fd.name).read_text().splitlines() if x.startswith("flags:")), 8)
                assert flags & os.O_ACCMODE == os.O_RDONLY, "Frozen dependency directory has a writer"
            except (FileNotFoundError, ProcessLookupError, PermissionError): pass

def host_check():
    available = next(x for x in Path("/proc/meminfo").read_text().splitlines() if x.startswith("MemAvailable:"))
    assert int(available.split()[1]) * 1024 >= 50000000000
    cgroup = Path("/sys/fs/cgroup") / Path("/proc/self/cgroup").read_text().strip().split(":", 2)[2].lstrip("/")
    assert (cgroup / "memory.swap.max").read_text().strip() == "0"
    atomic(RUN / "pre-roots-host-check.json", {"utc": now(), "MemAvailable": available, "minimum_bytes": 50000000000, "memory_swap_max": "0"})

def main():
    assert os.environ.get("SYMBOLICA_LICENSE")
    assert O["unit"] in Path("/proc/self/cgroup").read_text() and os.environ.get("INVOCATION_ID")
    assert os.sched_getaffinity(0) == {140,145,146}
    start = time.monotonic()
    guard(); no_writers()
    env = os.environ.copy()
    license_value = env["SYMBOLICA_LICENSE"]
    env.update(json.loads(Path(O["base_env_source"]).read_text())[O["base_env_key"]])
    env["SYMBOLICA_LICENSE"] = license_value
    for key in list(env):
        if key.startswith("INSTA_") or key.startswith("GL20_") or key.startswith("BASH_FUNC_"): env.pop(key)
    env.update(NO_SYMBOLICA_OEM_LICENSE="1", SYMBOLICA_HIDE_BANNER="1", RUST_BACKTRACE="1", GL_DISPLAY_FILTER="off", GL_LOGFILE_FILTER="off", GL_ALL_LOG_FILTER="off", TMPDIR=str(RUN / "tmp"), XDG_CACHE_HOME=str(RUN / "cache"))
    env.update(O["thread_environment"])
    for name in ("tmp", "cache"): (RUN / name).mkdir()
    copied = RUN / "input-copy"; copied.mkdir()
    for row in O["state_files"]:
        source = Path(row["path"]); target = copied / row["relative"]; target.parent.mkdir(parents=True, exist_ok=True)
        with source.open("rb") as src, target.open("xb") as dst:
            shutil.copyfileobj(src, dst); dst.flush(); os.fsync(dst.fileno())
        assert target.stat().st_ino != source.stat().st_ino and sha(target) == row["sha256"]
    compiler = subprocess.check_output([O["compiler"]["path"], "-Vv"], env=env, text=True, timeout=10)
    assert compiler.startswith("rustc " + O["compiler_version"] + " ")
    atomic(RUN / "actual-compiler.json", {"compiler": O["compiler"], "verbose_version": compiler})
    result = {"status": "SETUP_NOT_NUMERICAL_PASS", "owner": args.owner, "unit": O["unit"], "invocation_id": os.environ["INVOCATION_ID"], "manifest_sha256": args.manifest_sha256, "phases": [], "retries": 0}
    atomic(RUN / "STARTED.json", result, exclusive=True)
    code = 1
    try:
        executable = RUN / "fullpoint"
        build = [M["taskset"], "-c", "145,146", O["compiler"]["path"], "--crate-name", "gl20_fullpoint_precise_reference", "--edition=2024", "--crate-type=bin", "--check-cfg", "cfg(legacy)", "-C", "opt-level=2", "-C", "debuginfo=0", "-C", "debug-assertions=on", "-C", "overflow-checks=on", "-C", "codegen-units=256", "-C", "linker=" + O["linker"]["path"]]
        if args.owner == "historical": build += ["--cfg", "legacy"]
        for directory in O["library_dirs"]: build += ["-L", "dependency=" + directory]
        for directory in O["native_search"]: build += ["-L", "native=" + directory]
        for row in O["externs"]: build += ["--extern", row["crate"] + "=" + row["rlib"]["path"]]
        build += [M["helper"]["path"], "-o", str(executable)]
        result["phases"].append(phase("build", build, env, max(0, start + 1800 - time.monotonic()), O["compiler"]["path"], {145,146}))
        atomic(RUN / "built-artifact.json", {"path": str(executable), "sha256": sha(executable), "bytes": executable.stat().st_size, "helper_source_sha256": M["helper"]["sha256"]})
        guard(); no_writers(); host_check()
        result["setup_seconds"] = time.monotonic() - start; assert result["setup_seconds"] <= 1800
        result["phases"].append(phase("fullpoint", [M["taskset"], "-c", "140", str(executable), args.owner, str(copied), M["cases"]["path"], str(RUN / "outputs")], env, 600, executable, {140}))
        done = json.loads((RUN / "outputs/completion.json").read_text())
        assert done["status"] == "PASS_ONE_FORCED_ARB_PUBLIC_API_REFERENCE_NOT_GOLD_ACCEPTANCE"
        assert done["state_loads"] == 1 and done["precise_api_calls"] == 1 and done["actual_precision_bits"] == 1000 and done["event_count"] == 16
        for row in O["state_files"]: assert sha(copied / row["relative"]) == row["sha256"]
        guard(); no_writers()
        result.update(status="PASS_ONE_CURRENT_FORCED_ARB_FULLPOINT_REFERENCE_NOT_GOLD_ACCEPTANCE", actual_state_loads=1, precise_api_calls=1, actual_precision_bits=1000, sources_dependencies_original_and_copied_state_unchanged=True, outputs=[{"path":str(p),"sha256":sha(p),"bytes":p.stat().st_size} for p in sorted((RUN / "outputs").iterdir())])
        code = 0
    except BaseException as error:
        traceback.print_exc(); result.update(status="FAILED_NO_RETRY", error_type=type(error).__name__, error=str(error))
        try: guard(); result["guard_after_failure"] = "PASS"
        except BaseException as failure: result["guard_after_failure"] = str(failure)
    finally:
        result.update(returncode=code, finished_utc=now(), resource_end=resources()); atomic(RUN / "completion.json", result)
    return code

if __name__ == "__main__": raise SystemExit(main())

"""Seal one current original-point precise-API diagnostic; no compile or call."""
import ast
import copy
import hashlib
import json
from pathlib import Path
HERE=Path(__file__).resolve().parent
PREVIOUS=HERE.parent/"common-input-eager-proposal"
REG=HERE.parent/"regression-valid-cut-fixtures"
def record(path):
    path=Path(path).resolve()
    with path.open("rb") as f:checksum=hashlib.file_digest(f,"sha256").hexdigest()
    return {"path":str(path),"sha256":checksum,"bytes":path.stat().st_size}
previous=json.loads((PREVIOUS/"final-probe-packet.json").read_text())
o=copy.deepcopy(previous["owners"]["candidate3"])
o["unit"]="gl20-current-fullpoint-forced-arb-reference-20261026.service"
plan=json.loads((REG/"build-plan.json").read_text())
api=next(x for x in plan["stages"] if x["stage"]=="gammaloop_api")
ndarray=next(x for x in api["dependencies"] if x["extern_alias"]=="ndarray")
assert ndarray["artifact"]==record(ndarray["artifact"]["path"])
o["externs"].append({"crate":"ndarray","rlib":ndarray["artifact"],"selected_fingerprint_marker":ndarray["fingerprint_marker"],"selected_fingerprint_json":ndarray["fingerprint_json"]})
assert len(o["externs"])==8
spec=json.loads((HERE/"scientific-input-spec.json").read_text())
gold=REG/"source/tests/tests/snapshots/test_evaluation_api__gl20_multichannel_local_inspect_events.snap"
lines=gold.read_text().splitlines();g=json.loads("\n".join(lines[lines.index("---",1)+1:]))
import struct
assert [struct.unpack("Q",struct.pack("d",x))[0] for x in g["point"]]==spec["point_bits"]
for name in ["run_roots.py","start_roots.py","prepare_fullpoint_packet.py"]:ast.parse((HERE/name).read_text())
files=[HERE/x for x in ["prepare_fullpoint_packet.py","run_roots.py","start_roots.py","launch_roots.sh","helpers/fullpoint_precise.rs","scientific-input-spec.json"]]
files += [PREVIOUS/"final-probe-packet.json",REG/"build-plan.json",REG/"source/tests/tests/test_evaluation_api.rs",gold]
m={"schema":"gl20.current-fullpoint-forced-arb-public-api.final-packet.v1","status_at_freeze":"PREPARED_NOT_EXECUTED_AWAITING_ROOT_FINAL_GO","taskset":previous["taskset"],"helper":record(HERE/"helpers/fullpoint_precise.rs"),"cases":record(HERE/"scientific-input-spec.json"),"controls":[record(x) for x in files],"owners":{"candidate3":o},
"counts":{"direct_rustc_invocations":1,"helper_invocations":1,"state_loads":1,"EvaluateSamplesPrecise_calls":1,"original_xspace_points":1,"expected_generated_events":16,"expected_accepted_events":16,"fixture_generation_calls":0,"shadow_calls":0,"retries":0},
"bounds":previous["bounds_per_owner"],
"scope":"One matching-current helper, one byte-copy StateLoad, existing EvaluateSamplesPrecise forcedArb=true on original9f64bitpoint andgraph-group0, allotheroriginalrequestfields unchanged. Standard public API warm_up permitted. No graph/fixture generation, model/settings/gold/tolerance/source mutation, newruntimeprecisionmachinery or Native5Lphysical execution. Retain rawDebug before manuallyserializing precision-preservingArb aggregate, events, original/CTadditionalweights, momenta,metadata andobservables.",
"precision_limit":"ArbPrec is existing fixed VarFloat<1000>. Public API coordinate conversion intentionally uses its existing decimal-display lift of userf64 values, unlike stage1 exact binary64 embedding. Point f64bits are original. This is one forced-precision reference, not rigorous interval, convergence, common-rawinput or fullgoldacceptance proof. Single Identity rotation still returns no stability accuracy estimate.",
"input_witness":{"original_test":record(REG/"source/tests/tests/test_evaluation_api.rs"),"unchanged_current_gold":record(gold),"original_point_bits_verified_against_current_gold":True,"selected_ndarray":ndarray},
"admission":"Reuse prior qualified GL20 PID/starttick+PGID ownership, source/dependency/copyguards, MemoryMax/swap0/fresh50GB/boundedcleanup under Root fullpointscopeapproval; no newPIDFDinfrastructure or q0guardchanges. Numericalexecution still awaits finalGO on this exact packet."}
with (HERE/"final-probe-packet.json").open("x") as f:json.dump(m,f,indent=2);f.write("\n")
print(json.dumps({"packet":record(HERE/"final-probe-packet.json"),"helper":m["helper"],"spec":m["cases"],"ndarray":ndarray["artifact"],"counts":m["counts"],"bounds":m["bounds"]}))

//! One existing precise-API call on the retained original fixture and point.
use color_eyre::{Result, eyre::eyre};
use gammaloop_api::{commands::evaluate_samples::EvaluateSamplesPrecise, state::State};
use gammalooprs::integrands::evaluation::PreciseEvaluationResultOutput;
use ndarray::Array2;
use serde_json::{Value, json};
use std::{env, fs, io::Write, path::Path};
use symbolica::{domains::float::FloatLike, license::LicenseManager};
fn write(path: &Path, value: &Value) -> Result<()> {
    let mut file = fs::OpenOptions::new()
        .write(true)
        .create_new(true)
        .open(path)?;
    file.write_all(&serde_json::to_vec_pretty(value)?)?;
    file.write_all(b"\n")?;
    file.sync_all()?;
    Ok(())
}
fn main() -> Result<()> {
    assert!(
        LicenseManager::is_licensed(),
        "Current matching license required; no retry"
    );
    let a: Vec<_> = env::args().collect();
    assert_eq!(a.len(), 5);
    assert_eq!(a[1], "candidate3");
    let spec: Value = serde_json::from_slice(&fs::read(&a[3])?)?;
    let point = spec["point_bits"]
        .as_array()
        .unwrap()
        .iter()
        .map(|x| f64::from_bits(x.as_u64().unwrap()))
        .collect::<Vec<_>>();
    assert_eq!(point.len(), 9);
    let points = Array2::from_shape_vec((1, 9), point.clone())?;
    let discrete = Array2::from_shape_vec((1, 1), vec![0usize])?;
    let out = Path::new(&a[4]);
    fs::create_dir(out)?;
    let mut state = State::load(Path::new(&a[2]).to_path_buf(), None, None)?;
    let request = EvaluateSamplesPrecise {
        process_id: Some(0),
        integrand_name: Some("NLO".into()),
        use_arb_prec: true,
        minimal_output: false,
        return_generated_events: None,
        momentum_space: false,
        points: points.view(),
        integrator_weights: None,
        discrete_dims: Some(discrete.view()),
        graph_names: None,
        orientations: None,
    };
    // Existing public API performs its standard warm_up and forced-Arb stability path.
    // No generation, preprocessing, model/fixture/settings mutation or f64 retry.
    let batch = request.run(&mut state)?;
    let mut debug = fs::OpenOptions::new()
        .write(true)
        .create_new(true)
        .open(out.join("raw-precise-result.debug.txt"))?;
    debug.write_all(format!("{batch:#?}").as_bytes())?;
    debug.sync_all()?;
    assert_eq!(batch.samples.len(), 1);
    let PreciseEvaluationResultOutput::Arb(result) = &batch.samples[0].evaluation else {
        return Err(eyre!("Requested Arb but received a different numeric type"));
    };
    assert_eq!(result.integrand_result.re.get_precision(), 1000);
    assert_eq!(result.integrand_result.im.get_precision(), 1000);
    let metadata = result
        .evaluation_metadata
        .as_ref()
        .ok_or_else(|| eyre!("Missing full evaluation metadata"))?;
    let events = result
        .event_groups
        .iter()
        .enumerate()
        .map(|(group_index, group)| {
            group
                .iter()
                .enumerate()
                .map(|(event_index, event)| {
                    // Stringify the enum keys exactly as the original test; direct event-map
                    // JSON serialization is not a valid AdditionalWeightKey object boundary.
                    let weights = event
                        .additional_weights
                        .weights
                        .iter()
                        .map(|(key, value)| Ok((key.to_string(), serde_json::to_value(value)?)))
                        .collect::<Result<serde_json::Map<String, Value>>>()?;
                    Ok(
                        json!({"event_group_index":group_index,"event_index":event_index,
                "cut_info":event.cut_info,"incoming_momenta":event.kinematic_configuration.0,
                "outgoing_momenta":event.kinematic_configuration.1,"weight":event.weight,
                "additional_weights":weights}),
                    )
                })
                .collect::<Result<Vec<_>>>()
        })
        .collect::<Result<Vec<_>>>()?;
    let count: usize = events.iter().map(Vec::len).sum();
    assert_eq!(count, 16);
    assert_eq!(metadata.generated_event_count, 16);
    assert_eq!(metadata.accepted_event_count, 16);
    assert!(!metadata.is_nan);
    write(
        &out.join("precise-fullpoint.json"),
        &json!({
            "precision":"Arb","actual_precision_bits":1000,"point":point,
            "process":"epem_a_tth","integrand":"NLO","logical_snapshot_label":"GL20",
            "integrand_result":result.integrand_result,"parameterization_jacobian":result.parameterization_jacobian,
            "integrator_weight":result.integrator_weight,"event_groups":events,
            "metadata":metadata,"observables":batch.observables,
            "scope":"One precision-preserving public API call on retained state. Original f64 API coordinates and settings retained; the owner uses its existing decimal-lift policy for Arb coordinates. No common-binary64-kinematics or interval accuracy claim. Single identity rotation still yields no stability accuracy estimate."
        }),
    )?;
    write(
        &out.join("completion.json"),
        &json!({"status":"PASS_ONE_FORCED_ARB_PUBLIC_API_REFERENCE_NOT_GOLD_ACCEPTANCE", "state_loads":1,"precise_api_calls":1,"requested_precision":"Arb","actual_precision_bits":1000,"event_count":count,"fixture_generation_calls":0,"original_gold_unchanged":true}),
    )?;
    Ok(())
}

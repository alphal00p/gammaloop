#!/usr/bin/env python3
"""Complex norms of retained decimal outputs only. No numerical evaluator/job."""
import hashlib,json,pathlib
from decimal import Decimal,localcontext
HERE=pathlib.Path(__file__).resolve().parent; C3=HERE.parent;OUT=C3.parent.parent.parent
D=Decimal

def info(p):return {'path':str(p.resolve()),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size}
def load(p):
 t=p.read_text();return json.loads(t[t.index('{'):],parse_float=D)
def fmt(v):return format(v,'.18E') if v is not None else None
def norm_delta(a,r):
 ar,ai=D(str(a['re'])),D(str(a['im']));rr,ri=D(str(r['re'])),D(str(r['im']))
 den=(ar*ar+ai*ai).sqrt();num=((rr-ar)**2+(ri-ai)**2).sqrt()
 return num/den if den else (D(0) if not num else None)
def vector(z):return {c:fmt(D(str(z[c]))) for c in ('re','im')}
def key(e):return tuple(e['cut_info']['lmb_channel_edge_ids']),e['cut_info']['cut_id']
arp=HERE/'candidate3/run1/outputs/precise-fullpoint.json';arb=load(arp)
refs=json.loads((C3/'regression-valid-cut-fixtures/independent-numeric-leaf-comparison.json').read_text())['references']
assert info(arp)['sha256']=='a775c1abab992bc44f0dab3b70631e6a493c6f85f423e40e2aabd7477421d630'
baselinepath=OUT/'comparison/current-existing-snapshot-reconstructed-from-retained-diff.json';baselineproofpath=OUT/'comparison/existing-runtime-snapshot-comparison.json'
baselineproof=json.loads(baselineproofpath.read_text());assert info(baselinepath)==baselineproof['reconstructed_current_json']
assert info(pathlib.Path(baselineproof['current_original_test_log']['path']))==baselineproof['current_original_test_log']
base=load(baselinepath);ae=arb['event_groups'][0];assert len(ae)==16
sources={'arb':info(arp),'f767_actual_retained_snapshot':info(baselinepath),'f767_snapshot_provenance':info(baselineproofpath),'f767_original_test_log':baselineproof['current_original_test_log']};comparisons={}
with localcontext() as ctx:
 ctx.prec=420
 for label,record in refs.items():
  rp=pathlib.Path(record['path']);assert info(rp)==record;sources[label]=record;ref=load(rp);re=ref['event_groups'][0];assert len(re)==16
  rows=[];maxima={}
  for a,r in zip(ae,re):
   assert all(a[k]==r[k] for k in ('event_group_index','event_index','cut_info'))
   threshold_keys=sorted(k for k in a['additional_weights'] if k.startswith('threshold_counterterm:'))
   assert threshold_keys==sorted(k for k in r['additional_weights'] if k.startswith('threshold_counterterm:'))
   values={'original':(a['additional_weights']['original'],r['additional_weights']['original']),'weight':(a['weight'],r['weight'])}
   values.update({k:(a['additional_weights'][k],r['additional_weights'][k]) for k in threshold_keys})
   row={'event_index':a['event_index'],'cut_id':a['cut_info']['cut_id'],'channel_id':a['cut_info']['lmb_channel_id'],'channel_chord_edges':a['cut_info']['lmb_channel_edge_ids'],'relative_complex_norm':{}}
   for k,(av,rv) in values.items():
    delta=norm_delta(av,rv);row['relative_complex_norm'][k]=fmt(delta)
    if delta is not None and (k not in maxima or delta>maxima[k][0]):
     maxima[k]=(delta,{'event_index':a['event_index'],'cut_id':a['cut_info']['cut_id'],'channel_id':a['cut_info']['lmb_channel_id'],'relative_complex_norm':fmt(delta),'arb':vector(av),'reference':vector(rv)})
   rows.append(row)
  comparisons[label]={'aggregate_relative_complex_norm':fmt(norm_delta(arb['integrand_result'],ref['integrand_result'])),'all16_identity_exact':True,'all16_event_rows':rows,'maxima':{k:v[1] for k,v in maxima.items()}}
 bm={key(e):e for e in base['event_groups'][0]};assert len(bm)==16 and set(bm)=={key(e) for e in ae}
 meaningful=[]
 for a in ae:
  if a['cut_info']['cut_id']!=2:continue
  r=bm[key(a)];ak=a['additional_weights'];rk=r['additional_weights'];assert 'threshold_counterterm:0' in ak and 'threshold_counterterm:0' in rk
  av,rv=ak['threshold_counterterm:0'],rk['threshold_counterterm:0'];ai,ri=D(av['im']),D(rv['im']);assert ai<0<ri
  meaningful.append({'arb_event_index':a['event_index'],'baseline_event_index':r['event_index'],'cut_id':a['cut_info']['cut_id'],'channel_id':a['cut_info']['lmb_channel_id'],'channel_chord_edges':a['cut_info']['lmb_channel_edge_ids'],'threshold_key':'threshold_counterterm:0','arb_CT':vector(av),'f767_baseline_CT':vector(rv),'imaginary_signs':{'arb':-1,'f767_baseline':1},'imaginary_component_relative_difference':fmt(abs(ri-ai)/abs(ai)),'CT_relative_complex_norm':fmt(norm_delta(av,rv)),'weight_relative_complex_norm':fmt(norm_delta(a['weight'],r['weight'])),'same_raw_cut_info':a['cut_info']==r['cut_info'],'same_raw_outgoing_momenta':a['outgoing_momenta']==r['outgoing_momenta']})
 assert len(meaningful)==4
 report={'schema':'gl20.independent-retained-output-complex-norm-comparison.v1','status':'METRICS_ONLY_NO_TOLERANCE_SELECTED_OR_ASSERTED','definition':'sqrt((reference.re-Arb.re)^2+(reference.im-Arb.im)^2) / sqrt(Arb.re^2+Arb.im^2). Complete corresponding complex norm is denominator for every event original, each threshold counterterm, weight, and aggregate. Both zero ->0; nonzero reference /zero Arb ->undefined(null).','method':'Decimal precision420 arithmetic on already-produced serialized decimal values only, with Decimal.sqrt. No IR/model/evaluator execution, StateLoad, source edits, native jobs or new sampling. Results displayed to19significant digits.','sources':sources,'comparisons':comparisons,'f767_baseline_sign_witness':{'retained_actual_output_exists':True,'provenance':'Existing snapshot reconstructed from authenticated current committed gold and retained original f767 Insta diff/native.log, previously979removed+979added rows. Source hash and reconstructed output hash independently checked here. It is actual f767 baseline output, not historical gold.','mapping':'Exact unique (channel_chord_edge_ids, physical_cut_id) join, consistent with retained existing-runtime-snapshot comparison. No positional event-index join.','mapping_limit':'Baseline native physical frame has different outgoing spatial signs and particle PDG order; those differences are preserved explicitly. This join is a retained semantic correspondence, not a claim of identical internal kinematics.','aggregate_relative_complex_norm':fmt(norm_delta(arb['integrand_result'],base['integrand_result'])),'arb_aggregate':vector(arb['integrand_result']),'f767_baseline_aggregate':vector(base['integrand_result']),'four_cut2_meaningful_CT_imaginary_sign_rows':meaningful},'limits':['This one Arb1000 public API reference uses existing decimal-display lifting of the original f64 point, distinct from stage1 exact binary64 input buffers.','The reference metadata remains Unknown with no estimated accuracy; metrics do not establish an interval, convergence, a gold choice or a regression tolerance.','Nearzero imaginary components are included in complete complex vectors; no componentwise tiny denominator is used for the main metrics.','The baseline sign rows are a comparison of existing retained outputs, not a proposed conjugation, constant change, tolerance or acceptance result.'],'script':info(pathlib.Path(__file__))}
 p=HERE/'independent-fullpoint-complex-norm-comparison.json';p.write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps({'report':info(p),'metrics':{k:{'aggregate':v['aggregate_relative_complex_norm'],'maxima':{n:z['relative_complex_norm'] for n,z in v['maxima'].items()}} for k,v in comparisons.items()},'f767_aggregate':report['f767_baseline_sign_witness']['aggregate_relative_complex_norm'],'f767_CT_sign_norms':[x['CT_relative_complex_norm'] for x in meaningful]},indent=2))

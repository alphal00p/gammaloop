#!/usr/bin/env python3
"""Compare retained output decimal data only; no model/evaluator calls."""
from decimal import Decimal,localcontext
import hashlib,json,pathlib,collections
HERE=pathlib.Path(__file__).resolve().parent; C3=HERE.parent
REF_REPORT=C3/'regression-valid-cut-fixtures/independent-numeric-leaf-comparison.json'
ARB=HERE/'candidate3/run1/outputs/precise-fullpoint.json'
D=Decimal

def info(p):return {'path':str(p.resolve()),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size}
def load(p):
 t=p.read_text();return json.loads(t[t.index('{'):],parse_float=D)
def dec(x):return x if isinstance(x,D) else D(str(x))
def fmt(x):return format(x,'.18E') if x is not None else None
def compare(arb,ref,path):
 a,r=dec(arb),dec(ref);delta=r-a
 return {'path':path,'arb':str(a),'reference':str(r),'signed_difference':fmt(delta),'absolute_difference':fmt(abs(delta)),'relative_component_difference':fmt(abs(delta)/abs(a)) if a else ('0' if not r else None),'arb_zero':not a}
def scalar_momenta(event):
 out={}
 for category in ('incoming_momenta','outgoing_momenta'):
  for i,p in enumerate(event[category]):
   out[f'{category}/{i}/temporal/value']=p['temporal']['value']
   for c in ('px','py','pz'):out[f'{category}/{i}/spatial/{c}']=p['spatial'][c]
 return out
def max_rel(rows):
 valid=[r for r in rows if r['relative_component_difference'] is not None]
 return max(valid,key=lambda r:D(r['relative_component_difference'])) if valid else None
def summaries(rows):
 return {'count':len(rows),'exact_decimal_equal_count':sum(D(r['absolute_difference'])==0 for r in rows),'arb_zero_count':sum(r['arb_zero'] for r in rows),'undefined_relative_count':sum(r['relative_component_difference'] is None for r in rows),'max_relative_cell':max_rel(rows),'max_absolute_cell':max(rows,key=lambda r:D(r['absolute_difference'])) if rows else None}
refs=json.loads(REF_REPORT.read_text())['references'];a=load(ARB); assert info(ARB)['sha256']=='a775c1abab992bc44f0dab3b70631e6a493c6f85f423e40e2aabd7477421d630'
assert a['actual_precision_bits']==1000 and a['metadata']['generated_event_count']==a['metadata']['accepted_event_count']==16
assert a['metadata']['stability_results'][0]['status']=='Unknown' and a['metadata']['stability_results'][0]['estimated_relative_accuracy'] is None
assert len(a['event_groups'])==1 and len(a['event_groups'][0])==16
events=a['event_groups'][0]; comparators={}; source_records={'arb':info(ARB)}
with localcontext() as ctx:
 ctx.prec=420
 for label,record in refs.items():
  path=pathlib.Path(record['path']);actual=info(path);assert actual==record;source_records[label]=actual;d=load(path)
  assert d['point']==a['point'] and len(d['event_groups'])==1 and len(d['event_groups'][0])==16
  categories=collections.defaultdict(list);event_rows=[]
  for ae,re in zip(events,d['event_groups'][0]):
   idx=ae['event_index'];prefix=f'/event_groups/0/{idx}'
   assert {k:ae[k] for k in ('event_group_index','event_index','cut_info')}=={k:re[k] for k in ('event_group_index','event_index','cut_info')}
   assert set(ae['additional_weights'])==set(re['additional_weights'])
   row={'event_index':idx,'cut_id':ae['cut_info']['cut_id'],'channel_id':ae['cut_info']['lmb_channel_id'],'channel_chord_edges':ae['cut_info']['lmb_channel_edge_ids']}
   for key in ('original','threshold_counterterm:0','full multiplicative factor','weight'):
    for component in ('re','im'):
     av=(ae['weight'] if key=='weight' else ae['additional_weights'][key])[component]
     rv=(re['weight'] if key=='weight' else re['additional_weights'][key])[component]
     cell=compare(av,rv,prefix+('/weight/' if key=='weight' else '/additional_weights/'+key+'/')+component)
     categories[key+'/'+component].append(cell);row[key+'/'+component+'_rel']=cell['relative_component_difference']
   am,rm=scalar_momenta(ae),scalar_momenta(re);assert set(am)==set(rm)
   cells=[compare(am[k],rm[k],prefix+'/'+k) for k in am]
   for cell in cells:categories['momenta'].append(cell);categories['incoming_momenta' if '/incoming_momenta/' in cell['path'] else 'outgoing_momenta'].append(cell)
   mr=max_rel(cells);row['momenta_max_relative_difference']=mr['relative_component_difference'];row['momenta_max_relative_path']=mr['path'];row['momenta_exact_equal_components']=sum(D(r['absolute_difference'])==0 for r in cells);row['momenta_component_count']=len(cells)
   event_rows.append(row)
  aggregate={c:compare(a['integrand_result'][c],d['integrand_result'][c],'/integrand_result/'+c) for c in ('re','im')}
  comparators[label]={'identity_exact':{'event_indices':16,'event_groups':16,'cut_info_including_channel_chords':16,'point_coordinates':9},'aggregate':aggregate,'parameterization_jacobian':compare(a['parameterization_jacobian'],d['parameterization_jacobian'],'/parameterization_jacobian'),'integrator_weight':compare(a['integrator_weight'],d['integrator_weight'],'/integrator_weight'),'category_summaries':{k:summaries(v) for k,v in categories.items()},'all16_event_component_relative_differences':event_rows}
 for label,comp in comparators.items():
  comp['imaginary_component_relative_differences_by_physical_cut']={}
  for cut in range(4):
   selected=[r for r in comp['all16_event_component_relative_differences'] if r['cut_id']==cut]
   stats={}
   for key in ('original/im_rel','threshold_counterterm:0/im_rel','weight/im_rel'):
    valid=[r for r in selected if r[key] is not None]
    worst=max(valid,key=lambda r:D(r[key]))
    stats[key]={'max_relative_difference':worst[key],'event_index':worst['event_index']}
   comp['imaginary_component_relative_differences_by_physical_cut'][str(cut)]=stats
 run_completion=HERE/'candidate3/run1/completion.json'
 done=json.loads(run_completion.read_text())
 assert done['actual_state_loads']==done['precise_api_calls']==1 and done['retries']==done['returncode']==0
 assert done['sources_dependencies_original_and_copied_state_unchanged']
 for output in done['outputs']:assert info(pathlib.Path(output['path']))==output
 run_evidence={'controller_completion':info(run_completion),'completed_outputs':done['outputs'],'returncode':0,'state_loads':1,'precise_api_calls':1,'retries':0,'guards_reported_pass':True,'scope':'Controller completion and all3produced file hashes independently verified; this output comparison does not repeat compilation/evaluation.'}
 cancellation=[]
 for e in events:
  terms=[dec(v['re']) for k,v in e['additional_weights'].items() if k=='original' or k.startswith('threshold_counterterm:')]
  den=abs(sum(terms,D(0)));ratio=sum(map(abs,terms),D(0))/den if den else None
  cancellation.append({'event_index':e['event_index'],'cut_id':e['cut_info']['cut_id'],'channel_id':e['cut_info']['lmb_channel_id'],'sum_absolute_original_and_CT_re_over_absolute_sum':fmt(ratio)})
 weights=[dec(e['weight']['re']) for e in events];sumweight=sum(weights,D(0));sumabs=sum(map(abs,weights),D(0));event_cancellation={'definition':'sum(abs(stored event weight.real))/abs(sum(stored event weight.real)); this is a diagnostic of this list, not a re-evaluation or an assumed reconstruction of integrand_result','sum_real_event_weights':fmt(sumweight),'sum_absolute_real_event_weights':fmt(sumabs),'ratio':fmt(sumabs/abs(sumweight)),'largest_original_CT_real_cancellation':max(cancellation,key=lambda x:D(x['sum_absolute_original_and_CT_re_over_absolute_sum']))}
 imag_scales=[]
 for e in events:
  imag_scales.append({'event_index':e['event_index'],'cut_id':e['cut_info']['cut_id'],'channel_id':e['cut_info']['lmb_channel_id'],'original_im':fmt(dec(e['additional_weights']['original']['im'])),'CT_im':fmt(dec(e['additional_weights']['threshold_counterterm:0']['im'])),'event_weight_im':fmt(dec(e['weight']['im']))})
 report={'schema':'gl20.independent-produced-fullpoint-decimal-comparison.v1','status':'COMPARISON_COMPLETE_NO_TOLERANCE_OR_ACCURACY_ACCEPTANCE','method':{'relative_component_difference':'abs(reference_decimal - Arb_decimal) / abs(Arb_decimal); undefined if Arb=0 and reference!=0; both zero ->0','decimal_precision':420,'stored_decimal_policy':'Snapshot JSON floating tokens are parsed directly as Decimal; no new evaluator or binary64 arithmetic. Reported relative differences use source decimal displays, not a claim that the two computations had identical internal kinematics.','point_lift_caveat':'This public EvaluateSamplesPrecise run uses the existing decimal-display lift of original f64 coordinates; it differs from stage1 exact-binary64 buffer embedding.','precision_caveat':'Existing ArbPrec=VarFloat<1000>; metadata status Unknown and estimated_relative_accuracy=None. One reference, no interval, convergence, threshold acceptance, gold mutation or causal conclusion.'},'sources':source_records,'run_evidence':run_evidence,'arb_metadata':{'actual_precision_bits':1000,'generated_event_count':16,'accepted_event_count':16,'is_nan':a['metadata']['is_nan'],'stability_status':a['metadata']['stability_results'][0]['status'],'estimated_relative_accuracy':None},'comparisons':comparators,'stored_event_cancellation':event_cancellation,'all16_original_CT_real_cancellation_ratios':cancellation,'all16_arb_imaginary_component_scales':imag_scales,'interpretation':['All16 event index/cut/channel identities agree with each comparator independently; incoming momenta are exact displayed decimal matches while outgoing momenta may differ numerically.','Nearzero imaginary denominators produce huge component relative ratios. Their absolute values and whole event category are retained; no large wholecomplex physical error or exact physical zero is inferred.','Current gold, historical gold and C3 actual are separate provenance rows. Numerical closeness to this reference is not a selection of which gold is correct.'],'preparer':info(pathlib.Path(__file__))}
 out=HERE/'independent-fullpoint-numeric-comparison.json';out.write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps({'report':info(out),'aggregate_relative_differences':{k:{c:v['aggregate'][c]['relative_component_difference'] for c in ('re','im')} for k,v in comparators.items()},'momentum_maxima':{k:{'count':v['category_summaries']['momenta']['count'],'exact':v['category_summaries']['momenta']['exact_decimal_equal_count'],'max_rel':v['category_summaries']['momenta']['max_relative_cell']['relative_component_difference'],'path':v['category_summaries']['momenta']['max_relative_cell']['path']} for k,v in comparators.items()},'stored_event_cancellation':event_cancellation},indent=2))

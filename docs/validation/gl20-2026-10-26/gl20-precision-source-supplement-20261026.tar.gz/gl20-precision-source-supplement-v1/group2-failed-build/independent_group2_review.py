#!/usr/bin/env python3
import ast,hashlib,json,pathlib
HERE=pathlib.Path(__file__).resolve().parent;COMMON=HERE.parent
MP=HERE/'final-probe-packet.json';M=json.loads(MP.read_text())
EXPECTED='5f3c90b5a52c1a3d5f66c400f3ace529f5f5c8d5235f44f8d85147824adedd09'
def info(p):return {'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size}
assert info(MP)['sha256']==EXPECTED
seen={}
def check(v):
 if isinstance(v,dict):
  if isinstance(v.get('path'),str) and isinstance(v.get('sha256'),str):
   p=pathlib.Path(v['path'])
   if p not in seen:
    with p.open('rb') as f:h=hashlib.file_digest(f,'sha256').hexdigest()
    assert h==v['sha256'],str(p);seen[p]=h
    if 'bytes' in v:assert p.stat().st_size==v['bytes'],str(p)
  for x in v.values():check(x)
 elif isinstance(v,list):
  for x in v:check(x)
check(M)
P=json.loads(pathlib.Path(M['cases']['path']).read_text());assert len(P['cases'])==1;case=P['cases'][0]
CP=json.loads((COMMON/'cases.json').read_text());assert case==next(c for c in CP['cases'] if c['case_id']=='channel_0_cut_group_2_historical_call_14');assert case['cut_group_id']==2
oldM=json.loads((COMMON/'final-probe-packet.json').read_text());selection={};owner_deltas={}
for owner,s in P['selection']['owners'].items():
 n=9 if owner=='historical' else 28;assert len(s['selected'])==s['selected_count']==M['selected_write_counts'][owner]==n
 assert len({r['instruction_index'] for r in s['selected']})==n
 e=json.loads(pathlib.Path(s['source_export']['path']).read_text())['runtime_graph_terms'][0]['stored_evaluator_stacks'][2][0]['stack']['summed_function_map'];assert hashlib.sha256(e['stored_f64_eager_instruction_data_debug'].encode()).hexdigest()==s['native_f64_debug_sha256']
 a=P['native_anchors'][owner];r=next(r for r in json.loads(pathlib.Path(a['source']['path']).read_text())['results'] if r['case_id']==case['case_id']);assert all(a[k]==r[k] for k in ('f64_bits','arb_re','arb_im','arb_re_precision_bits','arb_im_precision_bits'))
 slots=P['input_slots'][owner]['q_time_slots'];bits=case['historical_params_bits' if owner=='historical' else 'candidate3_params_bits'];names=CP['parameter_mapping']['historical_names' if owner=='historical' else 'candidate3_names']
 assert all(bits[i]==[4647503709213818880,0] and '::Q(' in names[i] and 'cind(0)' in names[i] for i in slots)
 assert sorted(r['physical_edge_id'] for r in s['selected'] if r['role']=='ose')==[2,3,4,5,6,7,9,11]
 assert all(r['expected_native_complex_phase']=='Any' for r in s['selected'])
 owner_deltas[owner]=sorted(k for k in set(M['owners'][owner])|set(oldM['owners'][owner]) if M['owners'][owner].get(k)!=oldM['owners'][owner].get(k));assert owner_deltas[owner]==['unit']
 selection[owner]={'count':n,'selected_ordinals':[r['instruction_index'] for r in s['selected']],'native_instruction_count':s['native_f64_instruction_count'],'native_debug_hash_exact':True,'native_f64_stage1_bits_exact':True,'native_Arb_stage1_decimal_strings_exact':True,'q_time_slots':slots,'q_time_bits':[4647503709213818880,0]}
for f in ('prepare_group2_packet.py','run_group2.py','start_group2.py'):ast.parse((HERE/f).read_text())
hp=COMMON/'helpers/group2_intermediate.rs';helper=hp.read_text();assert info(hp)['sha256']=='432df3514cd897273e684744eac42cd36e6cabb380400beeeb12ccf7376b74f2'
original=(COMMON/'helpers/portable_trace.rs').read_text();selected=(COMMON/'helpers/portable_trace_selected.rs').read_text();arb=(COMMON/'helpers/portable_trace_arb.rs').read_text()
def arithmetic(s):return s[s.index('        match &program.instructions[instruction_index] {'):s.index('        if let Some(output) = written')]
assert arithmetic(original)==arithmetic(selected)
assert helper.count('State::load(')==1 and helper.count('evaluator.f64_eager.evaluate_single(')==helper.count('evaluator.arb.evaluate_single(')==1
assert helper.index('validate_selection(&precise_program.instructions')<helper.index('evaluator.f64_eager.evaluate_single(')
assert 'if &self.root_value != native_value' in arb and 're.prec()' in arb and 'im.prec()' in arb and 're.into_inner()' in arb and 're.into_raw()' in arb
assert 'for edge in [2, 6, 9, 11]' in helper and 'for index in &q_slots' in helper and '"energy_sum_order":[2,6,9,11]' in helper
oldhelper=(HERE/'source-revision-v1/group2_intermediate.rs').read_text();assert helper[:helper.index('    let mut delta =')]==oldhelper[:oldhelper.index('    let mut delta =')]
review={'schema':'gl20.group2-intermediate.independent-static-review.v1','status':'PASS_STATIC_API_SELECTED_GATES_AND_BOUNDED_CONTROLLER','packet':info(MP),'helper':info(hp),'casefile':info(pathlib.Path(M['cases']['path'])),'verified_existing_hash_records':len(seen),'selection':selection,'owner_delta_from_qualified_stage1':owner_deltas,'API_and_actual_precision_review':{'matched_public_Instruction_Slot_ExportedInstructions_compatible':True,'legacy_Float_into_inner':'Matched old Symbolica lib/numerica/src/domains/float/multiprecision.rs675 publicly returns self.0 backend value.','current_Float_into_raw':'Matched current Symbolica lib/numerica/src/domains/float/multiprecision.rs863 publicly returns self.0 backend value.','Gamma_borrowed_VarFloat_to_SymbolicaFloat':'Both matching owners clone actual private inner float; no rounding or precision reset.','actual_observation':'Cloned underlying rug::Float.prec/is_zero/is_sign_negative/is_finite, not wrapper VarFloat<N>::get_precision=N.','static_import_type_blocker_found':False},'arithmetic_review':{'f64_selected_opcode_arithmetic_body_byte_exact_to_original':True,'Arb_Add_Mul_operand_order_set_from_and_swap_match_native':True,'Arb_Pow_integer_and_inverse_match_native':True,'native_SQRT_scalar_method_only':True,'portable_control_and_slot_bounds_preserved':True,'selected_outputs_sources_opcodes_exponents_function_tags_phase_guards_both_programs':True,'native_f64_stage1_anchor':'exact u64 bits','native_Arb_stage1_anchor':'exact retained decimal strings; source stage1 did not expose raw Arb mantissas','native_vs_Arb_shadow_gate':'Exact Scalar PartialEq plus actual inner precision and signed-zero equality','native_results_fsynced_before_gates':True},'derived_delta_review':{'former_v1_issue':'Selected-row order yielded different owner energy summation orders.','current_fixed_order':[2,6,9,11],'then_subtract_Q_order':'q_time_slots[0],q_time_slots[1]','order_recorded_in_output':True,'only_derived_diagnostic_changed_from_v1':True,'native_and_trace_path_before_delta_byte_exact_to_v1':True,'formula':'E2+E6+E9+E11-Q0_0-Q1_0'},'controller_review':{'qualified_hashed_primitives_and_cleanup_reused':True,'sequential_once_per_owner_no_retry':True,'private_deps_first_matching_owners_state12_and_source_freezes_guarded':True,'setup145146_1800_runtime140_600_math1_16GiB_swap0_fresh50GB':True,'native_calls_each_owner':{'StateLoad':1,'f64':1,'stored_Arb':1,'portable_f64':1,'portable_Arb':1},'full_integrand_API_generation_backend_calls':0},'limits':['No compile, native execution, StateLoad, evaluator, generation, scientific arithmetic, source/control mutation or new job by reviewer.','API compatibility and exact-root gates are static-reviewed and must still pass the authorized run. Gate failures remain failures without retry.','This is bounded diagnostic trace acceptance, not GL20/gold/tolerance acceptance.'],'source_hashes':[info(COMMON/'helpers'/f) for f in ('portable_trace.rs','portable_trace_selected.rs','portable_trace_arb.rs')]}
out=HERE/'independent-group2-packet-review.json';out.write_text(json.dumps(review,indent=2)+'\n');print(json.dumps({'receipt':info(out),'hash_records':len(seen),'counts':M['selected_write_counts'],'delta_order':[2,6,9,11]}))

#!/usr/bin/env bash
set -euo pipefail
set +x
umask 077
source /shared/codex-1/vakint_rustred/workspace/env.sh >/dev/null 2>&1
set +x
[[ -n ${SYMBOLICA_LICENSE:-} ]] || exit 2
exec /nix/store/jxyrvv4gbpnp3ap5iy7wxwl1sg4x2x88-python3-3.14.6/bin/python3.14 -I -B "/shared/codex-1/vakint_rustred/workspace/5l-push/validation/gl20-native-frame-f767-readonly/current-matched-decode-and-compare-20261026/ct-real-point-diagnostic/generation-frame-witness/candidate-physical-master-and-hedge-root-restoration/strict-original-regression-controller-v2/run_strict.py" --manifest-sha256 "$1"

"""One original strict GL20 harness compile and one test; no retries."""

import argparse
import ast
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import time
import traceback


os.umask(0o077)
HERE = Path(__file__).resolve().parent
RUN = HERE / "run1"
parser = argparse.ArgumentParser()
parser.add_argument("--manifest-sha256", required=True)
args = parser.parse_args()
OUT = next(path for path in HERE.parents if path.name == "current-matched-decode-and-compare-20261026")
PRIMITIVES = OUT / "run_decoder.py"
assert hashlib.sha256(PRIMITIVES.read_bytes()).hexdigest() == "0cb2a14879b12f448014f10ba8df12438a71edac58672a35baef86ac1eadcc70"
PHASE_CWD = RUN
for node in ast.parse(PRIMITIVES.read_text()).body:
    if isinstance(node, ast.FunctionDef) and node.name in {"sha", "now", "atomic", "identity", "resources", "signal_owned_group", "reap_and_drain", "phase"}:
        source = ast.get_source_segment(PRIMITIVES.read_text(), node)
        if node.name == "phase":
            assert source.count("cwd=RUN") == 1
            source = source.replace("cwd=RUN", "cwd=PHASE_CWD")
        exec(compile(source, str(PRIMITIVES) + ":" + node.name, "exec"), globals())
assert sha(HERE / "control-manifest.json") == args.manifest_sha256
M = json.loads((HERE / "control-manifest.json").read_text())
P = json.loads(Path(M["plan"]["path"]).read_text())


def records(value, seen):
    if isinstance(value, dict):
        if isinstance(value.get("path"), str) and isinstance(value.get("sha256"), str) and re.fullmatch(r"[0-9a-f]{64}", value["sha256"]):
            if value["path"] not in seen:
                assert sha(value["path"]) == value["sha256"], value["path"]
                seen.add(value["path"])
        for child in value.values():
            records(child, seen)
    elif isinstance(value, list):
        for child in value:
            records(child, seen)


def guard():
    assert sha(HERE / "control-manifest.json") == args.manifest_sha256
    records(M, set())
    records(P, set())
    for record in M["source_freezes"]:
        frozen = json.loads(Path(record["path"]).read_text())
        for relative, checksum in frozen["files"].items():
            assert sha(Path(frozen["source"]) / relative) == checksum, relative


def host_check(label):
    available = next(line for line in Path("/proc/meminfo").read_text().splitlines() if line.startswith("MemAvailable:"))
    assert int(available.split()[1]) * 1024 >= 50000000000
    group = Path("/sys/fs/cgroup") / Path("/proc/self/cgroup").read_text().strip().split(":", 2)[2].lstrip("/")
    assert (group / "memory.swap.max").read_text().strip() == "0"
    atomic(RUN / (label + "-host-check.json"), {"utc": now(), "MemAvailable": available, "minimum_bytes": 50000000000, "swap_max": "0"})


def main():
    global PHASE_CWD
    assert os.environ.get("SYMBOLICA_LICENSE")
    assert M["unit"] in Path("/proc/self/cgroup").read_text()
    assert os.environ.get("INVOCATION_ID")
    assert os.sched_getaffinity(0) == {140, 145, 146}
    start = time.monotonic()
    guard()
    env = os.environ.copy()
    licence = env["SYMBOLICA_LICENSE"]
    env.update(json.loads(Path(P["base_environment_source"]).read_text())[P["base_environment_key"]])
    env["SYMBOLICA_LICENSE"] = licence
    for key in list(env):
        if key.startswith("INSTA_") or key.startswith("GL20_") or key.startswith("BASH_FUNC_"):
            env.pop(key)
    env.pop("GAMMALOOP_TESTS_NO_CLEAN_STATE", None)
    env.update(NO_SYMBOLICA_OEM_LICENSE="1", SYMBOLICA_HIDE_BANNER="1", RUST_BACKTRACE="1", INSTA_UPDATE="no", GL_DISPLAY_FILTER="off", GL_LOGFILE_FILTER="off", GL_ALL_LOG_FILTER="off", TMPDIR=str(RUN / "tmp"), XDG_CACHE_HOME=str(RUN / "cache"), GL_TEST_LOG_DIR=str(RUN / "logs"), TESTS_GAMMALOOP_STATE_PATH=str(RUN / "test-state"))
    env.update(P["thread_environment_values"])
    for name in ("tmp", "cache", "logs", "bin", "out", "test-state"):
        (RUN / name).mkdir(parents=True, exist_ok=True)
    compiler = subprocess.check_output([P["compiler"]["path"], "-Vv"], env=env, text=True, timeout=10)
    assert compiler.startswith("rustc 1.98.1 ")
    atomic(RUN / "actual-compiler.json", {"compiler": P["compiler"], "verbose_version": compiler})
    result = {"status": "SETUP_NOT_STRICT_GL20_PASS", "unit": M["unit"], "invocation_id": os.environ["INVOCATION_ID"], "manifest_sha256": args.manifest_sha256, "phases": [], "retries": 0}
    atomic(RUN / "STARTED.json", result, exclusive=True)
    code = 1
    try:
        stage = P["stage"]
        for directory in stage.get("directories_controller_must_create", []):
            Path(directory).mkdir(parents=True, exist_ok=True)
        build_env = env.copy()
        build_env.update(stage["environment_overlay"])
        PHASE_CWD = Path(stage["cwd"])
        host_check("pre-build")
        result["phases"].append(phase("build-original-test-harness", [M["taskset"], "-c", "145,146"] + stage["argv"], build_env, max(0, start + 1800 - time.monotonic()), P["compiler"]["path"], {145, 146}))
        executable = Path(stage["output"])
        atomic(RUN / "built-harness.json", {"path": str(executable), "sha256": sha(executable), "bytes": executable.stat().st_size})
        guard()
        result["setup_seconds"] = time.monotonic() - start
        assert result["setup_seconds"] <= 1800
        PHASE_CWD = Path(P["source"])
        host_check("pre-original-test")
        result["phases"].append(phase("original-gl20-strict-regression", [M["taskset"], "-c", "140", str(executable), "--exact", "gl20_multichannel_local_inspect_event_snapshot", "--nocapture", "--test-threads=1"], env, 600, executable, {140}))
        log = (RUN / "original-gl20-strict-regression.log").read_text()
        assert "test result: ok. 1 passed; 0 failed" in log
        guard()
        result.update(status="PASS_ONE_COMPLETE_ORIGINAL_STRICT_GL20_REGRESSION", original_main_test_source_unchanged=True, updated_snapshot_unchanged_during_test=True, reused_owned_rlibs=9, actual_test_harness_compiles=1, actual_complete_original_test_invocations=1, insta_update="no", no_numerical_tolerance_change=True)
        code = 0
    except BaseException as error:
        traceback.print_exc()
        result.update(status="FAILED_NO_RETRY", error_type=type(error).__name__, error=str(error))
        try:
            guard()
            result["guard_after_failure"] = "PASS"
        except BaseException as failure:
            result["guard_after_failure"] = str(failure)
    finally:
        result.update(returncode=code, finished_utc=now(), resource_end=resources())
        atomic(RUN / "completion.json", result)
    return code


if __name__ == "__main__":
    raise SystemExit(main())

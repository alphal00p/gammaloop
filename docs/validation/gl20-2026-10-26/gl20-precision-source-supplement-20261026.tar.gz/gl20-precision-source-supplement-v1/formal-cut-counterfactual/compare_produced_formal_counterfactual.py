#!/usr/bin/env python3
"""Existing formal-output comparison only: no helper/evaluator/job invocation."""
from decimal import Decimal,localcontext
import hashlib,json,pathlib
HERE=pathlib.Path(__file__).resolve().parent;COMMON=HERE.parent;D=Decimal

def load(p):return json.loads(p.read_text())
def info(p):return {'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size}
def value(record):return tuple(D(record[c]['decimal']) for c in ('re','im'))
def text(pair):return [str(x) for x in pair]
def compare(old,new):
    dr,di=new[0]-old[0],new[1]-old[1]
    den=(old[0]*old[0]+old[1]*old[1]).sqrt();num=(dr*dr+di*di).sqrt()
    return {'old':text(old),'candidate3':text(new),'signed_component_differences':text((dr,di)),'relative_complex_norm':str(num/den) if den else ('0' if not num else None)}

def main():
    mp=HERE/'final-probe-packet.json';m=load(mp)
    assert info(mp)['sha256']=='387969dbb1f05845332b370e25fcd682b60bd707cce2b9bd8faddce3f1acc02b'
    p=load(pathlib.Path(m['cases']['path']));contract=p['program_contract']['owners'];owners={};sources=[info(mp),info(pathlib.Path(__file__))]
    for owner in ('historical','candidate3'):
        run=HERE/owner/'run1';cp=run/'completion.json'
        if not cp.is_file():raise SystemExit('Both successful formal controllers are required; no wait or job invocation.')
        done=load(cp);assert done['status']=='PASS_FORMAL_CUT_CONSTRAINT_OWNER_NOT_GL20_ACCEPTANCE' and done['returncode']==0
        assert done['actual_state_loads']==1 and done['f64_calls']==done['stored_arb1000_calls']==0 and done['shadow_calls']==1
        assert done['sources_dependencies_original_and_copied_state_unchanged'] and done['retries']==0
        for record in done['outputs']:assert info(pathlib.Path(record['path']))==record
        fp=run/'outputs/formal-cut-constraint.json';f=load(fp);raw=load(run/'outputs/formal-replay-before-postchecks.json')
        assert f['status']=='FORMAL_DIAGNOSTIC_NOT_NATIVE_EQUIVALENT_NOT_A_NEW_PHYSICAL_SAMPLE'
        cf=f['counterfactual'];assert cf==raw and cf['intervention_count']==1 and cf['native_root_verified'] is False and cf['native_equivalent'] is False
        assert f['native_calls']==f['full_API_calls']==0 and f['shadow_replays']==1
        bp=pathlib.Path(contract[owner]['accepted_output']['path']);b=load(bp);assert info(bp)==contract[owner]['accepted_output']
        assert b['arb_trace']['root']==b['arb_trace']['native_root']==b['native_arb'] and b['arb_trace']['native_root_verified']
        assert cf['original_sqrt_value']==f['accepted_E11_before'] and cf['replacement_value']==f['replacement_E11']
        pi=f['actual_constant_records'][4];baseconst=load(COMMON/owner/'run1/outputs/program-constants.json')[2]['arb_constants'][4]
        assert all(pi[c]['decimal']==baseconst[c] for c in ('re','im'))
        assert D(pi['im']['decimal'])==0
        owners[owner]={'before_native_gated_root':b['native_arb'],'after_formal_NOT_native_equivalent_root':cf['root'],'accepted_E11':f['accepted_E11_before'],'replacement_E11':f['replacement_E11'],'replacement_minus_original':text(tuple(x-y for x,y in zip(value(f['replacement_E11']),value(f['accepted_E11_before'])))),'delta_before':f['accepted_delta_before']['arb'],'delta_after_common_order':f['derived_delta_after_common_order_E2_E6_E9_E11_q0_q1'],'actual_pi_constant':pi,'intervention_ordinal':cf['intervention_instruction_index'],'root_actual_inner_precision_bits':{c:cf['root'][c]['actual_inner_precision_bits'] for c in ('re','im')}}
        sources.extend([info(cp),info(fp),info(bp)])
    oldpi=D(owners['historical']['actual_pi_constant']['re']['decimal']);newpi=D(owners['candidate3']['actual_pi_constant']['re']['decimal']);factor=(oldpi/newpi)**8
    rows={}
    for when,key in [('before','before_native_gated_root'),('after_formal','after_formal_NOT_native_equivalent_root')]:
        old=value(owners['historical'][key]);current=value(owners['candidate3'][key]);normalized=tuple(v/factor for v in current)
        rows[when]={'raw_current_vs_historical':compare(old,current),'pi_corrected_current_vs_historical':compare(old,normalized),'normalization':'candidate3 divided by (stored_old_pi/stored_current_pi)^8; existing decimal values only'}
    before=D(rows['before']['pi_corrected_current_vs_historical']['relative_complex_norm']);after=D(rows['after_formal']['pi_corrected_current_vs_historical']['relative_complex_norm'])
    report={'schema':'gl20.formal-cut-constraint.before-after-produced-comparison.v1','status':'FORMAL_DIAGNOSTIC_COMPARISON_NO_NATIVE_EQUIVALENCE_OR_ACCEPTANCE','sources':sources,'case_id':'channel_0_cut_group_2_historical_call_14','method':'Decimal420 arithmetic only on already-produced native-gated baseline and formal replay outputs. Complex norm relative to historical owner. No evaluator, StateLoad, job, new sample or precision promotion.','actual_stored_pi_factor_current_over_historical':str(factor),'owners':owners,'comparisons':rows,'pi_corrected_after_over_before_relative_difference':str(after/before) if before else None,'limits':['The after values deliberately replace only E11 and are NOT native-equivalent outputs or a new independently physical point.','The common replacement uses accepted E2/E6/E9; future C3E9 is explicitly sourced from the prior gated observation.','A collapse or persistence under this sole formal intervention supplies evidence for this retained case only; no general symbolic identity, interval/convergence guarantee, production fix, tolerance or GL20/gold acceptance is inferred.','Actual old/current pi coefficients remain unchanged inside the replays; pi adjustment is an offline decimal comparison only.']}
    out=HERE/'independent-formal-cut-constraint-produced-comparison.json';out.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({'report':info(out),'pi_corrected_relative_difference_before':str(before),'pi_corrected_relative_difference_after_formal':str(after),'after_over_before':report['pi_corrected_after_over_before_relative_difference'],'root_actual_inner_precision_bits':{o:owners[o]['root_actual_inner_precision_bits'] for o in owners}},indent=2))

if __name__=='__main__':
    with localcontext() as ctx:
        ctx.prec=420
        main()

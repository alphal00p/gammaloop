"""Submit one owner roots-only cohort; enforce sequential once-only runs."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess

os.umask(0o077)
HERE = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(); parser.add_argument("--owner", choices=("historical", "candidate3"), required=True); args = parser.parse_args()
def sha(path):
    with Path(path).open("rb") as f: return hashlib.file_digest(f, "sha256").hexdigest()
M = json.loads((HERE / "final-probe-packet.json").read_text()); O = M["owners"][args.owner]
for record in M["controls"]: assert sha(record["path"]) == record["sha256"], record["path"]
assert {140,145,146}.issubset(os.sched_getaffinity(0))
if args.owner == "candidate3":
    previous = json.loads((HERE / "historical/run1/completion.json").read_text())
    assert previous["status"] == "PASS_FORMAL_CUT_CONSTRAINT_OWNER_NOT_GL20_ACCEPTANCE"
for owner in M["owners"].values():
    state = subprocess.check_output(["systemctl", "--user", "show", owner["unit"], "--property=SubState", "--value"], text=True).strip()
    assert state != "running", "Owners must run sequentially"
assert subprocess.check_output(["systemctl", "--user", "show", O["unit"], "--property=LoadState", "--value"], text=True).strip() == "not-found"
overlap = []
for proc in Path("/proc").iterdir():
    if not proc.name.isdigit() or int(proc.name) == os.getpid(): continue
    try:
        cpus = os.sched_getaffinity(int(proc.name))
        if len(cpus) <= 16 and cpus.intersection({140,145,146}) and (proc / "cmdline").read_bytes(): overlap.append({"pid":int(proc.name),"comm":(proc / "comm").read_text().strip(),"affinity":sorted(cpus)})
    except (FileNotFoundError, ProcessLookupError, PermissionError): pass
assert not overlap, overlap
available = next(x for x in Path("/proc/meminfo").read_text().splitlines() if x.startswith("MemAvailable:")); assert int(available.split()[1]) * 1024 >= 50000000000
RUN = HERE / args.owner / "run1"; RUN.mkdir(parents=True, mode=0o700); (RUN / "supervisor.log").touch(mode=0o600, exist_ok=False)
checksum = sha(HERE / "final-probe-packet.json")
(RUN / "request.json").write_text(json.dumps({"owner":args.owner,"manifest_sha256":checksum,"unit":O["unit"],"MemAvailable":available,"retries":0,"setup_seconds":1800,"runtime_seconds":600,"math_threads":1},indent=2)+"\n")
argv = ["systemd-run","--user","--unit="+O["unit"],"--property=Type=exec","--property=Restart=no","--property=RemainAfterExit=yes","--property=KillMode=control-group","--property=CPUAffinity=140 145 146","--property=AllowedCPUs=140,145,146","--property=CPUQuota=200%","--property=MemoryAccounting=yes","--property=MemoryMax=17179869184","--property=MemorySwapMax=0","--property=RuntimeMaxSec=2460","--property=TimeoutStopSec=10","--property=UMask=0077","--property=WorkingDirectory="+str(HERE),"--property=StandardOutput=append:"+str(RUN/"supervisor.log"),"--property=StandardError=append:"+str(RUN/"supervisor.log"),"env","-u","BASH_ENV","-u","ENV","bash","--noprofile","--norc",str(HERE/"launch_group2.sh"),args.owner,checksum]
r=subprocess.run(argv,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);(RUN/"submit.log").write_text(r.stdout);assert r.returncode==0,"Submission failed; no retry"
state=subprocess.check_output(["systemctl","--user","show",O["unit"],"--property=ActiveState,SubState,MainPID,InvocationID,CPUAffinity,ControlGroup"],text=True);(RUN/"initial-unit-state.txt").write_text(state)
print(json.dumps({"status":"SUBMITTED_ROOTS_SETUP_NOT_NUMERICAL_PASS","owner":args.owner,"unit":O["unit"],"manifest_sha256":checksum,"state":state}))

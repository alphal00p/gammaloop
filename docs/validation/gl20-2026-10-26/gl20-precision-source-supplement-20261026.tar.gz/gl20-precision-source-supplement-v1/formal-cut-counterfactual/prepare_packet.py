"""Seal one formal cut-constraint replay per matched owner; no execution."""

import ast
import hashlib
import json
from pathlib import Path


HERE = Path(__file__).resolve().parent
COMMON = HERE.parent
BASE = COMMON / "group2-intermediate-probe-api-corrected-v2"


def record(path):
    path = Path(path).resolve()
    with path.open("rb") as stream:
        checksum = hashlib.file_digest(stream, "sha256").hexdigest()
    return {"path": str(path), "sha256": checksum, "bytes": path.stat().st_size}


def main():
    packet = json.loads((BASE / "final-probe-packet.json").read_text())
    case = json.loads((BASE / "case.json").read_text())
    contract = json.loads((HERE / "program-contract.json").read_text())
    assert len(case["cases"]) == 1
    assert case["cases"][0]["case_id"] == "channel_0_cut_group_2_historical_call_14"
    case["program_contract"] = contract
    with (HERE / "case.json").open("x") as stream:
        json.dump(case, stream, indent=2)
        stream.write("\n")
    for owner, values in packet["owners"].items():
        values["unit"] = "gl20-formal-cut-constraint-" + owner + "-20261026.service"
    scripts = [HERE / name for name in ["prepare_packet.py", "run_group2.py", "start_group2.py"]]
    for path in scripts:
        ast.parse(path.read_text())
    controls = scripts + [
        HERE / "launch_group2.sh", HERE / "program-contract.json",
        COMMON / "helpers/cut_constraint_counterfactual.rs",
        COMMON / "helpers/portable_trace_arb_cut_constraint.rs",
        COMMON / "helpers/portable_trace_arb_api_corrected.rs",
        BASE / "final-probe-packet.json", BASE / "case.json",
        BASE / "independent-group2-api-correction-review.json",
        BASE / "independent-group2-observed-boundary-summary.json",
    ]
    packet.update(
        schema="gl20.formal-cut-constraint-counterfactual.final-packet.v1",
        status_at_freeze="PREPARED_NOT_EXECUTED_AWAITING_ROOT_FINAL_GO",
        helper=record(COMMON / "helpers/cut_constraint_counterfactual.rs"),
        cases=record(HERE / "case.json"),
        controls=[record(path) for path in controls],
        program_contract=contract,
        counts_per_owner={
            "direct_rustc_invocations": 1, "helper_invocations": 1,
            "state_loads": 1, "retained_cases": 1,
            "native_f64_calls": 0, "stored_arb1000_calls": 0,
            "counterfactual_arb_shadow_replays": 1,
            "formal_E11_interventions": 1, "new_physical_points": 0,
            "full_integrand_or_API_calls": 0, "generation_or_backend_calls": 0,
            "retries": 0,
        },
        selected_write_counts={"historical": 1, "candidate3": 1},
        scope="Two sequential matching-owner helpers, each one readonly StateLoad and one formally modified Arb portable replay on the already retained group2 buffer. No new native evaluator or full API calls. Authenticate accepted native/shadow artifacts, full unchanged instruction sequence, input bits, constants, writer libraries, source and12state payloads before replay. Replace ONLY physical E11 sqrt output by commonordered Q0_0+Q1_0−E2−E6−E9, using exact-roundtrip accepted OSEs, including C3E9 computed later in the original stream. Require positive-real original/replacement and exactlyone intervention. Preserve numerator factorization and all original dispatch/scalar-operation order apartfrom that explicit write.",
        precision_and_gates="Existing native/portable root gates are preserved byte-identically in the new module and are NOT reused or weakened to certify this modified replay. Its distinct type and formal_json explicitly state NOT_NATIVE_EQUIVALENT and NOT_A_NEW_PHYSICAL_SAMPLE. Already accepted native/shadow artifacts are verified without executing new baseline calls. Observe actual inner precision via the same nonpromoting public clone. Actual old/current pi coefficients are unchanged; their known inverse-eighth factor is applied only offline to produced output comparisons.",
        success_and_limits="Diagnostic completion is not native equivalence, a general symbolic identity, an independently physical point, interval/convergence proof, gold acceptance or a production fix. A collapse or persistence of the observed1e−23residual under this sole formal cut constraint is causal evidence for this retained case only. No fixture/gold/model/settings/tolerance/cache/pin changes and no5Lphysical execution.",
    )
    with (HERE / "final-probe-packet.json").open("x") as stream:
        json.dump(packet, stream, indent=2)
        stream.write("\n")
    print(json.dumps({"packet": record(HERE / "final-probe-packet.json"), "helper": packet["helper"], "case": packet["cases"]}))


if __name__ == "__main__":
    main()

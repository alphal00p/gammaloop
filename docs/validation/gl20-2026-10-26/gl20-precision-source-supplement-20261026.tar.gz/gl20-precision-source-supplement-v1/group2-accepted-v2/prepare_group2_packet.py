"""Prepare exactly one retained case and its inactive native-gated probe packet."""

import ast
import hashlib
import json
from pathlib import Path


HERE = Path(__file__).resolve().parent
COMMON = HERE.parent
OUT = next(path for path in HERE.parents if path.name == "current-matched-decode-and-compare-20261026")


def record(path):
    path = Path(path).resolve()
    with path.open("rb") as stream:
        checksum = hashlib.file_digest(stream, "sha256").hexdigest()
    return {"path": str(path), "sha256": checksum, "bytes": path.stat().st_size}


def main():
    identities = json.loads((COMMON / "owner-identities.json").read_text())
    selection = json.loads((COMMON / "group2-intermediate-selection.json").read_text())
    cases = json.loads((COMMON / "cases.json").read_text())
    assert selection["case_id"] == "channel_0_cut_group_2_historical_call_14"
    case = next(row for row in cases["cases"] if row["case_id"] == selection["case_id"])
    assert case["historical_params_bits"][16] == [4607182418800017408, 0]
    assert case["historical_params_bits"][80] == case["candidate3_params_bits"][79]
    owners = {}
    for name, original in identities["owners"].items():
        owner = dict(original)
        owner.update(
            unit="gl20-group2-selected-intermediates-api-corrected-" + name + "-20261026.service",
            compiler_version="1.97.0" if name == "historical" else "1.98.1",
            externs=original["selected_externs"],
            library_dirs=original["dependency_library_directories"],
            native_search=original["native_link_search_paths"],
            base_env_source=original["base_environment_source"],
            base_env_key=original["base_environment_key"],
            thread_environment=original["thread_environment_values"],
            source_freezes=[original["source_freeze"]["path"]],
        )
        if "original_source_freeze" in owner:
            owner["source_freezes"].append(owner["original_source_freeze"]["path"])
        assert len(owner["state_files"]) == 12
        assert len(owner["externs"]) == 7
        owners[name] = owner
    input_slots = {
        name: {"q_time_slots": selection["delta_physical_cut"]["temporal_input_slots"][name]}
        for name in owners
    }
    prepared_case = {
        "schema": "gl20.one-retained-group2-case-and-static-selection.v1",
        "cases": [case],
        "selection": selection,
        "native_anchors": selection["stage1_anchors"],
        "input_slots": input_slots,
        "sources": [record(COMMON / "cases.json"), record(COMMON / "group2-intermediate-selection.json")],
    }
    with (HERE / "case.json").open("x") as stream:
        json.dump(prepared_case, stream, indent=2)
        stream.write("\n")
    scripts = [HERE / filename for filename in ("prepare_group2_packet.py", "run_group2.py", "start_group2.py")]
    for path in scripts:
        ast.parse(path.read_text())
    controls = scripts + [
        HERE / "launch_group2.sh",
        COMMON / "helpers/group2_intermediate_api_corrected.rs",
        COMMON / "helpers/portable_trace_selected.rs",
        COMMON / "helpers/portable_trace_arb_api_corrected.rs",
        COMMON / "helpers/portable_trace.rs",
        COMMON / "owner-identities.json",
        COMMON / "cases.json",
        COMMON / "group2-intermediate-selection.json",
        COMMON / "group2-coefficient-contract-followup.json",
        COMMON / "retained-exact-radicand-positivity.json",
        COMMON / "final-probe-packet.json",
        OUT / "run_decoder.py",
    ]
    packet = {
        "schema": "gl20.one-group2-native-gated-selected-intermediate.final-packet.v1",
        "status_at_freeze": "PREPARED_NOT_EXECUTED_AWAITING_ROOT_FINAL_GO",
        "taskset": "/nix/store/156fzvaz2nsq2hk0fkzn9jwk90bnzyn9-util-linux-2.42.2-bin/bin/taskset",
        "helper": record(COMMON / "helpers/group2_intermediate_api_corrected.rs"),
        "cases": record(HERE / "case.json"),
        "controls": [record(path) for path in controls],
        "owners": owners,
        "case_id": selection["case_id"],
        "selected_write_counts": {name: len(selection["owners"][name]["selected"]) for name in owners},
        "counts_per_owner": {
            "direct_rustc_invocations": 1,
            "helper_invocations": 1,
            "state_loads": 1,
            "retained_cases": 1,
            "native_f64_calls": 1,
            "stored_arb1000_calls": 1,
            "f64_portable_shadow_calls": 1,
            "arb_portable_shadow_calls": 1,
            "new_physical_points": 0,
            "full_integrand_or_API_calls": 0,
            "generation_or_backend_calls": 0,
            "retries": 0,
        },
        "bounds_per_owner": {
            "setup_cpus": [145, 146], "setup_seconds": 1800,
            "runtime_cpus": [140], "runtime_seconds": 600,
            "math_threads": 1, "memory_max_bytes": 17179869184,
            "memory_swap_max": 0, "minimum_host_available_bytes": 50000000000,
            "unit_runtime_max_seconds": 2460,
        },
        "admission": "Prior qualified GL20 PID/starttick+PGID ownership, source/dependency/original-and-copy guards, MemoryMax/swap0/fresh50GB/bounded cleanup explicitly reauthorized by Root for small non5L storedIR work. No new PIDFD/bb322/936/2a8 infrastructure; active q0 guard untouched.",
        "scope": "One already-retained group2 buffer on two sequential matching owners. Preserve historical slot16 ONE, actual GC94 slot80→79 and complete named193→192 mapping. Native f64 and native storedArb1000 must exactly reproduce completed stage1 roots. Each portable trace must exactly match its native root before selected intermediates are accepted. No full-integrand call, fixture generation, settings/model/gold/tolerance/pin/production edit, backend activation or additional point.",
        "precision_and_gates": "Inputs are exact binary64 embeddings via SymbolicaFloat::with_val(1000,raw_f64). Arb gate uses exact Scalar PartialEq, actual component precision and signed-zero equality, never decimal closeness. Public SymbolicaFloat clones observe actual inner rug precision rather than VarFloat<N>::get_precision, which returns N. Record only8OSE writes plus the sealed C3coefficient frontier and one proven signed old counterpart; unproved oldprefactors/products are omitted. Derived delta uses physical E2+E6+E9+E11−Q0_0−Q1_0 in the explicit common edge order[2,6,9,11], then q0,q1 subtraction, withoutretuning inputs.",
        "success_and_limits": "Native↔shadow gates establish accepted diagnostic traces, notGL20/snapshot acceptance. Primitiveprecision drift vs a nonzero cut residual and rational coefficient lineage are tobe distinguished from actual values. Existing oldπ-upcast versus current nativeπ remains unchanged and separate. Any failure is preserved without retry or guessed API substitution.",
    }
    with (HERE / "final-probe-packet.json").open("x") as stream:
        json.dump(packet, stream, indent=2)
        stream.write("\n")
    print(json.dumps({"packet": record(HERE / "final-probe-packet.json"), "helper": packet["helper"], "case": packet["cases"], "selected": packet["selected_write_counts"]}))


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""Read completed G2 JSON only. Never invoke any evaluator, helper, StateLoad or job."""
import hashlib,json,pathlib
from collections import Counter
from decimal import Decimal,localcontext
HERE=pathlib.Path(__file__).resolve().parent
D=Decimal; SIGN=1<<63

def info(p):
    with p.open('rb') as f:h=hashlib.file_digest(f,'sha256').hexdigest()
    return {'path':str(p),'sha256':h,'bytes':p.stat().st_size}
def load(p):return json.loads(p.read_text())
def decbits(b):
    exponent=(b>>52)&2047;fraction=b&((1<<52)-1)
    if exponent==2047:return D('NaN') if fraction else D('-Infinity' if b&SIGN else 'Infinity')
    if not exponent and not fraction:return D('-0' if b&SIGN else '0')
    mantissa=fraction if not exponent else (1<<52)+fraction
    power=-1074 if not exponent else exponent-1075
    with localcontext() as ctx:
        ctx.prec=1600
        v=D(mantissa)*(D(2)**power)
        return v.copy_negate() if b&SIGN else v

def pairbits(bits):return tuple(map(decbits,bits))
def pairarb(record):return tuple(D(record[c]['decimal']) for c in ('re','im'))
def short(v):return format(v,'.18E') if v is not None else None
def pairstrings(p):return [str(v) for v in p]
def compare(reference,value):
    if not all(v.is_finite() for v in reference+value):return {'finite':False}
    delta=tuple(v-r for r,v in zip(reference,value));den=sum((r*r for r in reference),D(0)).sqrt();num=sum((v*v for v in delta),D(0)).sqrt()
    return {'finite':True,'signed_component_differences':list(map(short,delta)),'relative_complex_norm':short(num/den) if den else ('0' if not num else None),'reference_norm_zero':not den,'numeric_components_exact':[r==v for r,v in zip(reference,value)]}
def stored_value(row):return {'f64_bits':row['f64_bits'],'f64_exact_decimal':pairstrings(pairbits(row['f64_bits'])),'arb_decimal':pairstrings(pairarb(row['arb'])),'actual_inner_precision_bits':{c:row['arb'][c]['actual_inner_precision_bits'] for c in ('re','im')},'arb_zero_and_sign':{c:{k:row['arb'][c][k] for k in ('is_zero','is_sign_negative','is_finite')} for c in ('re','im')}}
def own_error(row):return compare(pairarb(row['arb']),pairbits(row['f64_bits']))

def main():
    packet_path=HERE/'final-probe-packet.json';packet=load(packet_path)
    assert info(packet_path)['sha256']=='c1f70f9f0c6fe9f74a648dfe3e7f1ee95f4c10f6972af61bfcbae40c5fc7d050'
    data={};sources=[info(packet_path),info(pathlib.Path(__file__))];owners={}
    for owner in ('historical','candidate3'):
        run=HERE/owner/'run1';completion_path=run/'completion.json'
        if not completion_path.is_file():raise SystemExit('Both successful controller completions are required; no waiting or job invocation.')
        completion=load(completion_path)
        assert completion['status']=='PASS_GROUP2_INTERMEDIATES_OWNER_NOT_GL20_ACCEPTANCE' and completion['returncode']==0
        assert completion['actual_state_loads']==completion['f64_calls']==completion['stored_arb1000_calls']==1 and completion['shadow_calls']==2
        assert completion['sources_dependencies_original_and_copied_state_unchanged'] and completion['retries']==0
        sources.append(info(completion_path))
        for record in completion['outputs']:assert info(pathlib.Path(record['path']))==record
        p=run/'outputs/selected-intermediates.json';d=load(p);sources.append(info(p));data[owner]=d
        assert d['owner']==owner and d['case_id']=='channel_0_cut_group_2_historical_call_14'
        assert d['f64_trace']['native_root_verified'] and d['arb_trace']['native_root_verified']
        assert d['physical_cut_residual']['energy_sum_order']==[2,6,9,11]
        selected=d['selected_values'];assert len(selected)==(9 if owner=='historical' else 28)
        assert len(d['input_component_precision_observations'])==(193 if owner=='historical' else 192)
        owners[owner]={
          'controller_success_and_native_trace_gates_passed':True,
          'input_actual_inner_precision_histograms':{c:dict(Counter(row[c+'_actual_inner_precision_bits'] for row in d['input_component_precision_observations'])) for c in ('re','im')},
          'selected_actual_inner_precision_histograms':{c:dict(Counter(row['arb'][c]['actual_inner_precision_bits'] for row in selected)) for c in ('re','im')},
          'native_Arb_root_actual_inner_precisions':{c:d['native_arb'][c]['actual_inner_precision_bits'] for c in ('re','im')},
          'physical_cut_residual':{**stored_value(d['physical_cut_residual']),'energy_sum_order':d['physical_cut_residual']['energy_sum_order'],'external_subtraction_slots_in_order':d['physical_cut_residual']['external_subtraction_slots_in_order'],'f64_vs_own_Arb':own_error(d['physical_cut_residual'])},
          'selected_precision_rows':[{'instruction_index':r['selection']['instruction_index'],'role':r['selection']['role'],'physical_edge_id':r['selection'].get('physical_edge_id'),'re_actual_inner_precision_bits':r['arb']['re']['actual_inner_precision_bits'],'im_actual_inner_precision_bits':r['arb']['im']['actual_inner_precision_bits']} for r in selected],
        }
    historical,current=data['historical'],data['candidate3']
    def rows(role,owner):return [r for r in data[owner]['selected_values'] if r['selection']['role']==role]
    hm={r['selection']['physical_edge_id']:r for r in rows('ose','historical')};cm={r['selection']['physical_edge_id']:r for r in rows('ose','candidate3')};assert set(hm)==set(cm)=={2,3,4,5,6,7,9,11}
    ose=[]
    for edge in sorted(hm):
        h,c=hm[edge],cm[edge]
        ose.append({'physical_edge_id':edge,'historical_instruction':h['selection']['instruction_index'],'candidate3_instruction':c['selection']['instruction_index'],'historical':stored_value(h),'candidate3':stored_value(c),'f64_bits_exact':h['f64_bits']==c['f64_bits'],'f64_cross_owner':compare(pairbits(h['f64_bits']),pairbits(c['f64_bits'])),'Arb_cross_owner':compare(pairarb(h['arb']),pairarb(c['arb'])),'historical_f64_vs_own_Arb':own_error(h),'candidate3_f64_vs_own_Arb':own_error(c)})
    hs=rows('signed_shared_inverse','historical');cs=rows('signed_shared_inverse','candidate3');assert len(hs)==len(cs)==1
    hs,cs=hs[0],cs[0];assert hs['selection']['instruction_index']==505 and cs['selection']['instruction_index']==102
    negative_current_bits=[b^SIGN for b in cs['f64_bits']];negative_current_arb=tuple(v.copy_negate() for v in pairarb(cs['arb']))
    inverse={'historical_instruction':505,'candidate3_instruction':102,'candidate3_explicit_comparison_sign':-1,'sign_source':'Sealed selection/signed-counterpart proof, not an inferred conjugation.','historical':stored_value(hs),'candidate3_unmodified':stored_value(cs),'historical_vs_negative_candidate3_f64_bits_exact':hs['f64_bits']==negative_current_bits,'historical_vs_negative_candidate3_f64':compare(pairbits(hs['f64_bits']),pairbits(negative_current_bits)),'historical_vs_negative_candidate3_Arb':compare(pairarb(hs['arb']),negative_current_arb),'historical_f64_vs_own_Arb':own_error(hs),'candidate3_f64_vs_own_Arb':own_error(cs)}
    coefficients=[]
    for r in current['selected_values']:
        if r['selection']['role'] not in ('ose','signed_shared_inverse'):
            coefficients.append({'instruction_index':r['selection']['instruction_index'],'role':r['selection']['role'],'value':stored_value(r),'f64_vs_own_Arb':own_error(r)})
    assert [r['instruction_index'] for r in coefficients[:3]]==[104,1742,1762]
    assert sum(r['role']=='orientation_product' for r in coefficients)==16 and len(coefficients)==19
    hd,cd=historical['physical_cut_residual'],current['physical_cut_residual']
    delta={'formula':hd['formula'],'common_energy_sum_order':[2,6,9,11],'f64_cross_owner':compare(pairbits(hd['f64_bits']),pairbits(cd['f64_bits'])),'Arb_cross_owner':compare(pairarb(hd['arb']),pairarb(cd['arb'])),'f64_bits_exact':hd['f64_bits']==cd['f64_bits']}
    report={'schema':'gl20.group2.already-produced-intermediate-comparison.v1','status':'EXISTING_OUTPUT_COMPARISON_NO_ACCEPTANCE_THRESHOLD','case_id':historical['case_id'],'sources':sources,'method':'Decimal420 on already-produced decimal strings and exact integer-decoded binary64 values; complete complex norm denominator for relative differences. No evaluator, helper, StateLoad, native job, sampling or input retuning.','owners':owners,'eight_OSE_correspondences':ose,'explicit_signed_shared_inverse':inverse,'candidate3_104_1742_1762_and16_products_vs_own_Arb':coefficients,'physical_cut_residual_cross_owner':delta,'limits':['Observed actual inner rug precision comes from owner public precision-preserving clones; declared wrapperN=1000 is not used as evidence of working precision.','Shadow intermediates are read only after successful controllers and native↔shadow gates. Exact storedArb stage1 reproduction is the existing decimal-string anchor.','Different old/current pi constants remain unchanged. A working precision observation, a finite cut residual and a rational coefficient lineage are distinct facts; no causal patch or GL20/gold/tolerance acceptance is inferred.']}
    out=HERE/'independent-group2-produced-output-comparison.json';out.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({'report':info(out),'input_precision_sets':{o:{c:list(owners[o]['input_actual_inner_precision_histograms'][c]) for c in ('re','im')} for o in owners},'selected_precision_sets':{o:{c:list(owners[o]['selected_actual_inner_precision_histograms'][c]) for c in ('re','im')} for o in owners},'OSE_f64_exact_count':sum(r['f64_bits_exact'] for r in ose),'signed_inverse_f64_exact_after_explicit_minus':inverse['historical_vs_negative_candidate3_f64_bits_exact'],'coefficient_errors':[{k:r[k] for k in ('instruction_index','role','f64_vs_own_Arb')} for r in coefficients[:3]],'delta':{o:owners[o]['physical_cut_residual'] for o in owners}},indent=2))

if __name__=='__main__':
    with localcontext() as ctx:
        ctx.prec=420
        main()

# Direct-3D comparisons within existing main's numerator support

**Prepared and approved by root; initial pairs are authorized.** No source edits,
builds, tests, or benchmark runs were performed during preparation. Use source
`f1cb64c162fba1ab35ef25a89affb61597d1013d` for the candidate and current-main pin
`226b7bea45398023f767fb4e53a1b5c6c3a43a2d`, with matching preserved binary receipts.

| Case | Main card | Candidate card | Eligibility |
| --- | --- | --- | --- |
| Established GL1 without UV | `cards/main/g_gl1_no_uv.toml` | `cards/candidate/g_gl1_no_uv.toml` | UV disabled; raw numerator degree in each internal edge energy is at most one. |
| Existing GL0 top-quark box, local logarithmic UV | `cards/main/aa_aa_GL0_log_only.toml` | `cards/candidate/aa_aa_GL0_log_only.toml` | Four distinct linear fermion edge factors, full UV degree zero, no proper cycle subgraph; only zeroth-order Taylor subtraction. |

Per the user's latest instruction, candidate cards use the best previously observed
native setting, `intermediate_cost`; main uses its supported `sparse_atom_aware`.
This difference is intentional. Each parsed main/candidate pair differs **only**
in this setting and the candidate’s explicit false route defaults (which main lacks). The earlier C17 GL1 intermediate and matched-sparse observations
remain preserved; these cards do not introduce another strategy matrix.

## Actual graph and Taylor-order certificates

`no-uv-certificate.json` references the independent source/topology review at
`../acceptance-audits/live-main-comparison-eligibility-20260917.md`. GL1 has three
linear quark propagator numerators (e2/e3/e4), constant gluon propagator numerators,
three momentum-independent FFV vertices, and one triple-gluon vertex linear in
e5/e6 and an external momentum. No internal edge energy has degree above one.
`subtract_uv=false` makes the existing `classified_spinneys` owner return only the
empty spinney. `generate_integrated=false` is also explicit in both cards; the exact change from
the historical source is retained under `adaptations/`.

`log-only-certificate.json` describes the **actual selected GL0 graph**, extracted
byte-for-byte from the first complete digraph in the established
`examples/cli/aa_aa/1L/aa_aa_1L.dot`. The full source DOT is identical in current main
and the candidate. Extraction omits GL2/GL4 without changing GL0's graph body,
projector, grouping factor, routing, edge numerators, or vertex numerators.

The internal edges are 4, 5, 6, and 7, forming one four-edge cycle. The certificate
enumerates all fourteen proper nonempty edge subsets: each has loop rank zero.
The only nonempty UV component is therefore the complete cycle. Each of its four
fermion numerator factors is linear in its own distinct Q(edge); each denominator
is quadratic. The four V_134/FFV1 vertices and the graph numerator are independent
of loop momentum. Thus its actual superficial degree is

```
4 × 1 loop + 4 × 1 numerator degree − 4 × 2 denominator degree = 0.
```

Under the existing hard-momentum scaling with the integration measure, the leading
power is t^0. Both implementations retain the rescaled series through absolute
order zero, so this graph requires only its leading coefficient: no positive-order
external-momentum or mass Taylor derivatives and no nested UV operation. This
conclusion comes from graph incidence and numerator factors, not the MUV label.
The certificate is source-backed; native execution has not yet independently
exported the forest. The log-only card includes `save uv-forest` without `--computed`
so the run retains a native structural cross-check without requesting expanded
numerator output.

Native photon/top particle definitions and propagators, V_134, FFV1, GC_2, and its
relevant parameters compare identically between the two model assets; the default
restriction files are also identical. Selected entries and model hashes are in the
certificate. Model parameter overrides are copied from the existing aa_aa test card.

## Inspection and timing

Each card saves its generated state and performs two identical native momentum-space inspections:

- GL1: `[0.23, 0.31, -0.17, 0.41, -0.29, 0.13]`, the existing UV regression's fixed
  coordinate array truncated by its existing `point.len()` rule to two loops.
  This point has not yet been certified on the selected no-UV workload. Compare
  saved external kinematics before accepting main/candidate point agreement.
- GL0 box: `[0.11, -0.07, 0.19]`, existing `aa_aa_local_inspect_backend_consistency`
  case a, helicities `++--`, graph zero. Its established external momenta and
  `m_uv=mu_r=20` are retained. Threshold subtraction is disabled equally on both
  sides to isolate the requested local-UV comparison.

Require successful generation, finite nonzero inspect values, the expected graph
and evaluator inventories, unchanged source/binary/input hashes, and the certified
UV scope. Do not replace coordinates after seeing a failure. Report raw complex
values; any convention normalization must use the independently established phase
rule and be reported explicitly. This preparation does not certify numerical parity.

Process wall time includes inspection and, for GL0, structural forest export.
Use native generation-summary buckets for generation comparisons; there is no
separate evaluator-runtime benchmark in these cards. Individual observations are
not timing distributions. Root authorized two further alternating pairs per case only if all four initial
cards finish below30 seconds and numerical checks pass. Otherwise stop and report.
No extra workload is prepared here.

## Guard and launch

`command.json` records the unchanged runner interface. For one authorized case:

```bash
TASK_BUNDLE=/tmp/raised-energy-restoration-results-20260915/final-direct3d-valid-main-comparison-bundle-20260917
python3 "$TASK_BUNDLE/tools/run-card.py" \
  /path/to/matching/checkout /path/to/preserved/gammaloop \
  "$TASK_BUNDLE/cards/main/g_gl1_no_uv.toml" \
  /path/to/fresh/external/output 900
```

Use the matching licensed development environment. The historical
`/tmp/raised-stack/run` wrapper overwrites the license; supply the compatible value
after that wrapper without saving it in this bundle. The runner and watchdog are
byte-identical to the established bundle, retain the original shared lock, use a
30 GB memory limit and 900-second cap, and never retry. The preceding guarded campaign has handed off; root authorized initial order
main→candidate for noUV, then candidate→main for log-only.

`cards-manifest.json` pins all four cards, seven fixtures, and both helpers.
Shared summary/CFF/inspect logfile filtering and display warn are explicit.
TOML parsing, pair-difference checks, fixture/helper hashes, and the shared lock
target have been verified. Repository source remains unchanged.

#!/usr/bin/env python3
"""Run one fresh physical card under the shared 30 GB guard; never retry."""

import argparse
import copy
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time
import tomllib

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("checkout", type=Path)
parser.add_argument("binary", type=Path)
parser.add_argument("card", type=Path)
parser.add_argument("output", type=Path)
parser.add_argument("timeout_seconds", type=int, nargs="?", default=900)
args = parser.parse_args()
bundle = Path(__file__).resolve().parent.parent
checkout, binary, card, output = (
    path.resolve() for path in (args.checkout, args.binary, args.card, args.output)
)
watchdog = bundle / "tools/ram-watchdog.py"
if args.timeout_seconds <= 0:
    parser.error("timeout_seconds must be positive")
if output.is_relative_to(checkout) or output.is_relative_to(bundle):
    parser.error("output must be outside the source checkout and extracted bundle")
if output.exists():
    parser.error("output already exists; retain it and choose a fresh attempt directory")
if not all(path.is_file() for path in (binary, card, watchdog, checkout / "Cargo.lock")):
    parser.error("binary, card, watchdog and checkout Cargo.lock must exist")
if not shutil.which("timeout") or not shutil.which("jj"):
    parser.error("GNU timeout and jj must be on PATH; use your licensed toolchain environment")


def sha256(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def source_identity():
    # jj snapshots tracked candidate edits; outputs must live outside the checkout.
    revision = subprocess.check_output(
        ["jj", "log", "--no-graph", "-r", "@", "-T", "commit_id"],
        cwd=checkout, text=True,
    ).strip()
    return {
        "jj_commit": revision,
        "cargo_toml_sha256": sha256(checkout / "Cargo.toml"),
        "cargo_lock_sha256": sha256(checkout / "Cargo.lock"),
    }


manifest_path = bundle / "cards-manifest.json"
manifest = json.loads(manifest_path.read_text())
inputs = {entry["path"]: entry["sha256"] for entry in manifest["fixtures"] + manifest["cards"]}
try:
    card_key = str(card.relative_to(bundle))
except ValueError:
    parser.error("select a manifest-listed bundled card; record new controls in a new bundle manifest")
if card_key not in inputs:
    parser.error("card is absent from cards-manifest.json")
verified_inputs = {key: sha256(bundle / key) for key in inputs}
if verified_inputs != inputs:
    parser.error("bundled card or fixture hashes differ from cards-manifest.json")
manifest_hash = sha256(manifest_path)

text = card.read_text()
original = tomllib.loads(text)
expected = copy.deepcopy(original)
expected["cli_settings"]["state"]["folder"] = str(output / "state")
state_table = re.search(r"(?ms)^\[cli_settings\.state\]\s*\n(.*?)(?=^\[|\Z)", text)
if state_table is None:
    parser.error("card requires an explicit [cli_settings.state] table")
state_body, replacements = re.subn(
    r'(?m)^folder\s*=.*$',
    lambda _: "folder = " + json.dumps(str(output / "state")),
    state_table.group(1),
)
if replacements != 1:
    parser.error("card must contain exactly one state.folder assignment")
effective = text[:state_table.start(1)] + state_body + text[state_table.end(1):]
if tomllib.loads(effective) != expected:
    parser.error("effective card changed more than state.folder")

before = source_identity()
binary_hash = sha256(binary)
receipt_path = Path(str(binary) + ".build.json")
if not receipt_path.is_file():
    parser.error("missing BINARY.build.json; follow the build receipt command in MEASURE.md")
build = json.loads(receipt_path.read_text())
if build.get("source") != before or build.get("binary_sha256") != binary_hash:
    parser.error("binary build receipt does not match this checkout and preserved binary")
output.mkdir(parents=True)
(output / "run.toml").write_text(effective)
settings = {
    "CARGO_BUILD_JOBS": "4", "RAYON_NUM_THREADS": "8",
    "RUST_MIN_STACK": "134217728", "NEXTEST_TEST_THREADS": "4",
    "INSTA_UPDATE": "no", "NEXTEST_RETRIES": "0", "LC_ALL": "C",
}
env = os.environ.copy()
env.update(settings)
# Preserve each card's native logging; external filters otherwise override it.
for key in (
    "GL_ALL_LOG_FILTER", "GL_DISPLAY_FILTER", "GL_LOGFILE_FILTER", "INSTA_FORCE_PASS",
    "SPENSO_NETWORK_PROFILE", "SPENSO_NETWORK_PROFILE_VERBOSE", "SPENSO_NETWORK_PROFILE_ATOM_BYTES",
    "SPENSO_NETWORK_LAZY_TENSOR_SUMS", "SPENSO_NETWORK_MAX_LAZY_DISTRIBUTED_TERMS",
):
    env.pop(key, None)
command = [
    sys.executable, str(watchdog), "--log", str(output / "memory.jsonl"),
    "--limit-gb", "30", "--", "timeout", "--verbose", "--signal=TERM",
    "--kill-after=15s", f"{args.timeout_seconds}s", str(binary), "-n", "-s",
    str(output / "state"), str(output / "run.toml"), "run", "generate",
]
metadata = {
    "source_before": before, "build_receipt": build,
    "binary": str(binary), "binary_sha256": binary_hash,
    "template": str(card), "template_sha256": sha256(card),
    "effective_card_sha256": sha256(output / "run.toml"),
    "watchdog_sha256": sha256(watchdog),
    "cards_manifest_sha256": manifest_hash, "verified_inputs_sha256": verified_inputs,
    "argv": command, "cwd": str(bundle), "settings": settings,
    "started_utc": datetime.now(timezone.utc).isoformat(),
    "timeout_seconds": args.timeout_seconds, "limit_bytes": 30_000_000_000,
}
(output / "attempt.json").write_text(json.dumps(metadata, indent=2) + "\n")
started = time.monotonic()
with (output / "stdout.log").open("wb") as stdout, (output / "stderr.log").open("wb") as stderr:
    result = subprocess.run(command, cwd=bundle, env=env, stdout=stdout, stderr=stderr)
metadata.update(
    ended_utc=datetime.now(timezone.utc).isoformat(),
    wall_seconds=time.monotonic() - started, returncode=result.returncode,
)
log = output / "memory.jsonl"
events = [json.loads(line) for line in log.read_text().splitlines()] if log.exists() else []
names = {event["event"] for event in events}
metadata["peak_tree_bytes"] = max(
    (event.get("peak_tree_bytes", event.get("tree_bytes", 0)) for event in events), default=0
)
if "memory_limit" in names:
    status = "MEMORY_CAP"
elif "watchdog_error" in names:
    status = "MONITOR_FAILURE"
elif "complete" not in names:
    status = "GUARD_OR_LAUNCH_FAILURE"
elif result.returncode in (124, 137) and "timeout: sending signal" in (output / "stderr.log").read_text(errors="replace"):
    status = "TIME_LIMIT"
elif result.returncode == 0:
    status = "PASS_EXECUTION"
else:
    status = "CHILD_FAILURE"
metadata["execution_status"] = status
metadata["source_after"] = source_identity()
metadata["binary_sha256_after"] = sha256(binary)
metadata["input_integrity_after"] = (
    sha256(manifest_path) == manifest_hash
    and all(sha256(bundle / key) == digest for key, digest in verified_inputs.items())
)
if metadata["source_after"] != before or metadata["binary_sha256_after"] != binary_hash or not metadata["input_integrity_after"]:
    status = "SOURCE_INTEGRITY_FAILURE"
metadata["status"] = status
(output / "result.json").write_text(json.dumps(metadata, indent=2) + "\n")
print(json.dumps({key: metadata[key] for key in ("status", "returncode", "wall_seconds", "peak_tree_bytes")}))
sys.exit(0 if status == "PASS_EXECUTION" else (result.returncode if result.returncode > 0 else 1))

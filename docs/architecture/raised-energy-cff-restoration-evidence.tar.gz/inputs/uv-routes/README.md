# Final established-workload benchmark bundle

Prepared only; **no benchmark or CLI execution was performed while preparing this bundle**. Source checkouts, earlier bundles, and their manifests remain unchanged. Wait for the root agent to finish the required source gate and builds before running these cards.

## Scope and pairing

| Workload | Main card | Candidate card | Interpretation |
| --- | --- | --- | --- |
| Sunrise integrated | `cards/main/sunrise_integrated_sparse.toml` | `cards/candidate/sunrise_integrated_sparse.toml` | Cards are byte-identical. Both explicitly use `sparse_atom_aware`. |
| GL1 local UV, direct 3D | `cards/main/g_gl1_local_only.toml` | `cards/candidate/g_gl1_local3d_intermediate.toml` | Main uses its supported local-UV route and native `sparse_atom_aware` default; candidate retains the established `intermediate_cost` card. |
| GL1 local UV, projected 4D | Reuse the same main local-UV observation above | `cards/candidate/g_gl1_local4d_intermediate.toml` | Main has no corresponding projected local-4D route. Candidate differs from its direct-3D card only in the two existing required route flags. |
| Orientation58 interpreted | `cards/main/orientation58_sparse_runtime_interpreted.toml` | `cards/candidate/orientation58_sparse_runtime_interpreted.toml` | Existing sparse runtime pair; inspect, full benchmark, minimal-integrand benchmark, inspect. |
| Orientation58 compiled | `cards/main/orientation58_sparse_runtime_compiled.toml` | `cards/candidate/orientation58_sparse_runtime_compiled.toml` | Same existing pair with only `compile = true`; report compilation separately. |

This is nine cards, not a new strategy or physics matrix. The single main GL1 observation serves both route comparisons. Current main does **not** support `intermediate_cost`; do not transplant the candidate GL1 setting into its card. Main's `final_integrand = "FourD"` is not a substitute for the candidate projected local-4D mode.

The current main reference is `226b7bea45398023f767fb4e53a1b5c6c3a43a2d`. Use the final candidate source revision and matching preserved binary receipt, not the intermediate C14 binary.

## Corrected CLI assumption

Current main226 already exposes `--number-of-fermion-loops` at `crates/gammaloop-api/src/commands/generate.rs:255`. Its original cards are preserved byte-for-byte. Only the three candidate generated-process cards needed their prior `--number-of-anticommutating-loops` spelling changed to `--number-of-fermion-loops`.

Those cards restrict particles to `g u`, so no ghost enters their graph inventories and the filter semantics agree on these workloads. The orientation cards import a fixed DOT graph and contain no loop-count option. The requested production fix still matters for general ghost-containing generation.

The three exact candidate spelling patches are under `adaptations/`. The new manifest records original source paths and hashes, the verified parent manifests, and all final card/fixture hashes. No old manifest was modified.

## Running a selected card

Use the matching checkout's licensed Nix development environment. In particular, the main native build uses Rust 1.98.1/GCC 15.3, while the candidate uses Rust 1.97.0/GCC 15.2. Compiled evaluator timings must run under the corresponding environment. Keep the supplied compatible `SYMBOLICA_LICENSE`; the historical `/tmp/raised-stack/run` wrapper overwrites this variable, so pass the desired license after that wrapper or export it after sourcing its environment. Both production binaries must be built with `NO_SYMBOLICA_OEM_LICENSE=1` as recorded by the root agent.

For each row, set the appropriate checkout/binary/card/label and run once:

```bash
TASK_BENCH_BUNDLE=/tmp/raised-energy-restoration-results-20260915/final-established-benchmark-bundle-20260917
TASK_RUNS=/tmp/raised-energy-restoration-results-20260915/campaigns
TASK_CHECKOUT=/path/to/exact/source/checkout
TASK_BINARY=/path/to/preserved/gammaloop
TASK_CARD=cards/main/sunrise_integrated_sparse.toml
TASK_LABEL=final-main226-sunrise-20260917
python3 "$TASK_BENCH_BUNDLE/tools/run-card.py" \
  "$TASK_CHECKOUT" "$TASK_BINARY" "$TASK_BENCH_BUNDLE/$TASK_CARD" \
  "$TASK_RUNS/$TASK_LABEL" 900
```

The prepared main checkout and build output are:

```text
/tmp/raised-energy-restoration-results-20260915/native-references/workspaces/main-226b7bea-current
/tmp/raised-energy-restoration-results-20260915/builds/main-226b7bea-native-personal-license-20260917/gammaloop
```

Confirm build completion and the exact output filename before using it. `gammaloop.build.json` must sit beside the binary and match both its hash and the checkout's exact jj revision. Each run requires a fresh output directory. The runner changes only `cli_settings.state.folder`, uses the shared 30 GB guard, fixes execution settings, and verifies source/binary/card integrity afterward. `tools/heavy-run.lock` points to the original shared lock; do not run another guarded build or campaign concurrently.

Run the selected rows sequentially after heavy builds/checks settle. Do not retry failures silently or change runtime coordinates after inspecting their values.

## Reading results

- Generation-only cards report full process wall time and peak process-tree bytes in `result.json`; use native stage logs for generation, expression preparation, Symbolica construction, and compilation.
- Orientation runtime cards include four extra commands. Their total wall time includes benchmarking and cannot be called generation time. Extract native generation stages and full/minimal runtime measurements separately.
- The runtime coordinates, external kinematics, and selection are unchanged. Require finite, nonzero inspection values, stable before/after values, and compare main versus candidate before accepting runtime parity claims. `PASS_EXECUTION` by itself is not numerical equivalence certification.
- Main's native source/dependencies/toolchain use Symbolica 3; candidate uses its pinned 2.2 fork. Native UV conventions/settings also differ. These are end-to-end measurements, not an isolated attribution to factorized numerators or series preservation.
- Bundled model JSON files are historical verification references; cards import each binary's native built-in model, not these snapshots. Used QCD rules and selected graph topology must remain the comparison basis.
- All cards retain `summed = false`. These measurements do not exercise the removed whole-orientation alias path.
- One observation is not a distribution. Preserve exact revisions, build profiles, strategy differences, receipt files, and any time/memory cap when reporting.

## Preparation validation

All inputs in all three parent manifests were verified before copying. All nine final cards parse with `tomllib`; all declared parsed changes match exactly; main cards remain byte-identical to their sources; the Sunrise pair is byte-identical; each runtime compile pair differs only by its compile boolean; main/candidate runtime pairs differ only by the two explicit candidate false flags; candidate GL1 routes differ only by the two required route flags. All generation core counts remain one. The shared runner/watchdog are byte-identical to the originals.

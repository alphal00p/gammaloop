#!/usr/bin/env python3
"""Sequential scratch measurements; root prepares PREFIX, this never checks out code."""
import argparse
import datetime
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import shlex
import shutil
import stat
import subprocess
import sys
import time
import tomllib

BASE = Path('/tmp/raised-energy-expression-perf-20260914')
ROOT = Path('/common/dev/gammaloop/higher-power-energies-review')
PREFIX = Path('/tmp/raised-stack/prefix')
PYTHON = '/tmp/raised-stack/python'
WATCH = Path('/tmp/raised-stack-latest-review-20260914/ram-watchdog-ps10.py')
WATCH_SHA = 'e94c98f65399e4cd0791ba050497ecaf4e745b4fdefc36fe036aae748f8152b9'


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def write(path, value):
    Path(path).write_text(json.dumps(value, indent=2) + '\n')


def audit(revision):
    head = subprocess.check_output(['jj', '--ignore-working-copy', 'log', '-r', '@',
                                   '--no-graph', '-T', 'commit_id'], cwd=PREFIX, text=True).strip()
    rows = subprocess.check_output(['git', '-C', str(ROOT), 'ls-tree', '-rz', revision['commit']])
    mismatches, count = [], 0
    for row in rows.split(b'\0'):
        if not row:
            continue
        metadata, name = row.split(b'\t', 1)
        mode, kind, blob = metadata.split()
        path = PREFIX / os.fsdecode(name)
        try:
            status = path.lstat()
            if stat.S_ISLNK(status.st_mode):
                actual_mode, data = b'120000', os.readlink(os.fsencode(path))
            elif stat.S_ISREG(status.st_mode):
                actual_mode = b'100755' if status.st_mode & stat.S_IXUSR else b'100644'
                data = path.read_bytes()
            else:
                raise ValueError('not a regular file or symlink')
            actual_blob = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest().encode()
            if (actual_mode, b'blob', actual_blob) != (mode, kind, blob):
                mismatches.append(os.fsdecode(name))
            count += 1
        except OSError:
            mismatches.append(os.fsdecode(name))
    tree = subprocess.check_output(['git', '-C', str(ROOT), 'rev-parse', revision['commit'] + '^{tree}'], text=True).strip()
    head_tree = subprocess.check_output(['git', '-C', str(ROOT), 'rev-parse', head + '^{tree}'], text=True).strip()
    return dict(passed=head_tree == tree == revision['tree'] and not mismatches,
                head=head, head_tree=head_tree, tree=tree, checked_paths=count, mismatches=mismatches)


def guarded(out, name, command, overrides):
    stage = out / name
    stage.mkdir()
    argv = ['/tmp/raised-stack/run', 'env', '-u', 'GL_ALL_LOG_FILTER', '-u', 'GL_DISPLAY_FILTER',
            '-u', 'GL_LOGFILE_FILTER', *[f'{key}={value}' for key, value in overrides.items()],
            PYTHON, str(WATCH), '--log', str(stage / 'memory.jsonl'), '--limit-gb', '30', '--', *command]
    env = os.environ.copy()
    for key in ('GL_ALL_LOG_FILTER', 'GL_DISPLAY_FILTER', 'GL_LOGFILE_FILTER', 'INSTA_FORCE_PASS', 'RUN_PYSECDEC_TESTS'):
        env.pop(key, None)
    record = dict(argv=argv, cwd=str(PREFIX), started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    write(stage / 'command.json', record)
    started = time.monotonic()
    with (stage / 'stdout.log').open('wb') as stream:
        code = subprocess.run(argv, cwd=PREFIX, env=env, stdin=subprocess.DEVNULL, stdout=stream, stderr=subprocess.STDOUT).returncode
    events = [json.loads(line) for line in (stage / 'memory.jsonl').read_text().splitlines()] if (stage / 'memory.jsonl').exists() else []
    complete = next((event for event in reversed(events) if event['event'] == 'complete'), None)
    status = ('MEMORY_CAP' if any(e['event'] == 'memory_limit' for e in events) else
              'MONITOR_FAILURE' if complete is None else 'PASS' if code == 0 else 'CHILD_FAILURE')
    record.update(status=status, exit_code=code, wall_seconds=time.monotonic() - started,
                  watchdog_seconds=complete.get('elapsed_s') if complete else None,
                  peak_tree_rss_bytes=max((e.get('peak_tree_bytes', e.get('tree_bytes', 0)) for e in events), default=0))
    write(stage / 'result.json', record)
    return record


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['build', 'run'])
    parser.add_argument('revision')
    parser.add_argument('--attempt', required=True)
    parser.add_argument('--card')
    parser.add_argument('--build-receipt', type=Path)
    args = parser.parse_args()
    if not re.fullmatch(r'[A-Za-z0-9_-]+', args.attempt):
        parser.error('attempt must contain only letters, digits, underscores or hyphens')
    revisions = {item['label']: item for item in json.loads((BASE / 'revisions.json').read_text())}
    revision = revisions[args.revision]
    lock = (BASE / 'measurement.lock').open('a')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    out = BASE / 'measurements' / args.revision / f'{args.action}-{args.attempt}'
    out.mkdir(parents=True, exist_ok=False)
    receipt = dict(revision=revision['commit'], tree=revision['tree'], label=args.revision,
                   action=args.action, status='STARTED', stages=[], driver_sha256=digest(__file__),
                   watchdog_adapter_sha256=WATCH_SHA)
    write(out / 'receipt.json', receipt)
    try:
        assert digest(WATCH) == WATCH_SHA, 'watchdog adapter changed'
        receipt['tracked_before'] = audit(revision)
        assert receipt['tracked_before']['passed'], 'PREFIX differs from expected source'
        receipt['source_hashes'] = {p: digest(PREFIX / p) for p in ['Cargo.lock', 'Cargo.toml',
            'assets/models/json/sm/sm.json', 'assets/models/json/sm/restrict_default.json']}
        overrides = dict(CARGO_TARGET_DIR=str(ROOT / 'target'), CARGO_BUILD_JOBS='4',
                         RAYON_NUM_THREADS='8', RUST_MIN_STACK='134217728', INSTA_UPDATE='no', NEXTEST_RETRIES='0')
        if args.action == 'build':
            for action in ('check', 'build'):
                result = guarded(out, action, ['cargo', action, '--locked', '-p', 'gammaloop-api',
                    '--bin', 'gammaloop', '--profile', 'dev-optim'], overrides)
                receipt['stages'].append(result)
                if result['status'] != 'PASS':
                    receipt['status'] = result['status']
                    break
            else:
                binary = out / 'gammaloop'
                shutil.copy2(ROOT / 'target/dev-optim/gammaloop', binary)
                receipt.update(status='PASS', binary=str(binary), binary_sha256=digest(binary))
                assert receipt['binary_sha256'] == digest(ROOT / 'target/dev-optim/gammaloop')
        else:
            assert args.card and args.build_receipt, 'run requires --card and --build-receipt'
            build = json.loads(args.build_receipt.read_text())
            assert build['status'] == 'PASS' and build['revision'] == revision['commit'] and build['tree'] == revision['tree']
            assert digest(build['binary']) == build['binary_sha256'], 'preserved binary changed'
            inventory_path = BASE / 'attachments/run-card-inventory.json'
            inventory = json.loads(inventory_path.read_text())
            label = {'main-current': 'main', 'main-base': 'oldmain'}.get(args.revision, args.revision)
            choices = inventory['revisions'][label]
            assert choices['commit'] == revision['commit']
            card = next(item for item in choices['cards'] if item['card'] == args.card)
            assert card.get('path'), card.get('reason', 'card unavailable')
            assert digest(card['path']) == card['sha256'], 'card changed'
            text = Path(card['path']).read_text()
            before = tomllib.loads(text)
            graph_paths = [shlex.split(command)[2] for block in before['command_blocks']
                           for command in block['commands'] if command.startswith('import graphs ')]
            assert all(Path(path).is_absolute() for path in graph_paths), 'graph inputs must be absolute'
            receipt['imported_graph_sha256'] = {path: digest(path) for path in graph_paths}
            # The supplied ZIP contains the only imported graph used by these cards.
            expected_graphs = {item['path']: item['sha256'] for item in inventory['graph_inputs']}
            assert all(expected_graphs.get(path) == value for path, value in
                       receipt['imported_graph_sha256'].items()), 'supplied graph input changed'
            state = out / 'state'
            folder = before.get('cli_settings', {}).get('state', {}).get('folder')
            if folder is not None:
                old = re.search(r'(?ms)^\[cli_settings\.state\]\s*\n.*?(?=^\[|\Z)', text)
                assert old is not None
                changed, count = re.subn(r'(?m)^folder\s*=.*$', 'folder = ' + json.dumps(str(state)), old.group())
                assert count == 1
                text = text[:old.start()] + changed + text[old.end():]
            else:
                text += '\n[cli_settings.state]\nfolder = ' + json.dumps(str(state)) + '\n'
            after = tomllib.loads(text)
            before.setdefault('cli_settings', {}).setdefault('state', {})['folder'] = str(state)
            assert before == after, 'card change exceeded state folder'
            effective = out / 'run.toml'
            effective.write_text(text)
            receipt.update(card=card, inventory_sha256=digest(inventory_path), effective_card_sha256=digest(effective),
                           binary=build['binary'], binary_sha256=build['binary_sha256'], build_receipt=str(args.build_receipt),
                           build_receipt_sha256=digest(args.build_receipt))
            result = guarded(out, 'runtime', [build['binary'], '-n', '-s', str(state), str(effective), 'run', 'generate'], overrides)
            receipt['stages'].append(result)
            receipt['status'] = result['status']
            assert digest(build['binary']) == build['binary_sha256'], 'preserved binary changed during run'
            receipt['generation_summaries'] = [dict(path=str(p), sha256=digest(p)) for p in state.rglob('generation_summary.json')]
            receipt['trace_logs'] = [str(p) for p in state.rglob('*.jsonl')]
    except Exception as error:
        receipt.update(status='DRIVER_FAILURE', error=str(error))
    finally:
        try:
            receipt['tracked_after'] = audit(revision)
            if not receipt['tracked_after']['passed']:
                receipt['status'] = 'SOURCE_INTEGRITY_FAILURE'
        except Exception as error:
            receipt.update(status='SOURCE_INTEGRITY_FAILURE', audit_error=str(error))
        receipt['completed_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        write(out / 'receipt.json', receipt)
    print(json.dumps(dict(receipt=str(out / 'receipt.json'), status=receipt['status'])), flush=True)
    return 0 if receipt['status'] == 'PASS' else 1


if __name__ == '__main__':
    sys.exit(main())

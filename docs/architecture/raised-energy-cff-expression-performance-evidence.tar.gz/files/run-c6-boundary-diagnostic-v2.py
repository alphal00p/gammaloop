"""Execute the prepared C6 input-boundary diagnostic once, with explicit censoring."""
from pathlib import Path
import datetime
import fcntl
import hashlib
import importlib.util
import json
import os
import subprocess
import time

BASE=Path('/tmp/raised-energy-expression-perf-20260914')
lock=(BASE/'measurement.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
for relative in ['remaining-sweep-02/state.json','controls/post-sweep-01/state.json']:
    p=BASE/relative
    if p.exists():
        state=json.loads(p.read_text());assert state['status'] not in ['RUNNING','STARTED'],relative
        if 'proc_start_ticks' in state:
            proc=Path('/proc')/str(state['pid'])/'stat'
            if proc.exists():
                fields=proc.read_text().rsplit(') ',1)[1].split()
                assert fields[19]!=state['proc_start_ticks'] or fields[0]=='Z',relative
assert json.loads((BASE/'remaining-sweep-02/state.json').read_text())['status']=='FINISHED_SWEEP'
recipe_path=BASE/'diagnostics/c6-gl1-upstream-boundaries/recipe-v2.json'
recipe=json.loads(recipe_path.read_text())
def sha(path):
    with Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
assert sha(recipe_path)=='259275548bf1f8173a087437d1fe95fd84471fba35726a3cf845ccef3ab8500f'
for name in ['source_audit','driver_for_read_only_pre_post_audit','card','timeout','watchdog']:
    row=recipe[name];assert sha(row['path'])==row['sha256'],name
build=recipe['native_build'];assert sha(build['receipt'])==build['receipt_sha256'];assert sha(build['binary'])==build['binary_sha256']
assert sha(recipe['card']['source'])==recipe['card']['source_sha256']
spec=importlib.util.spec_from_file_location('measure',recipe['driver_for_read_only_pre_post_audit']['path']);measure=importlib.util.module_from_spec(spec);spec.loader.exec_module(measure)
measure.PREFIX=Path(recipe['source_workspace']);before=measure.audit(recipe['revision']);assert before['passed']
out=Path(recipe['fresh_run_directory']);out.mkdir(exist_ok=False)
record={'status':'STARTED','recipe':str(recipe_path),'recipe_sha256':sha(recipe_path),'argv':recipe['argv'],'cwd':recipe['cwd'],'tracked_before':before,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
measure.write(out/'receipt.json',record)
phase='prepare_environment'
try:
    env=os.environ.copy()
    for key in ['GL_ALL_LOG_FILTER','GL_DISPLAY_FILTER','GL_LOGFILE_FILTER','INSTA_FORCE_PASS','RUN_PYSECDEC_TESTS']:env.pop(key,None)
    phase='execute'
    start=time.monotonic()
    with Path(recipe['stdout']).open('wb') as stream:
        code=subprocess.run(recipe['argv'],cwd=recipe['cwd'],env=env,stdin=subprocess.DEVNULL,stdout=stream,stderr=subprocess.STDOUT).returncode
    record.update(exit_code=code,observation_seconds=time.monotonic()-start,finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    phase='collect_evidence'
    memory=out/'memory.jsonl';events=[json.loads(s) for s in memory.read_text().splitlines()] if memory.exists() else []
    complete=next((e for e in reversed(events) if e['event']=='complete'),None)
    signal_lines=[line for line in Path(recipe['stdout']).read_text(errors='replace').splitlines() if line.startswith('timeout: sending signal ') and build['binary'] in line]
    record.update(timeout_signal_lines=signal_lines,monitor_complete=complete,peak_tree_rss_bytes=max((e.get('peak_tree_bytes',e.get('tree_bytes',0)) for e in events),default=0))
    if any(e['event']=='memory_limit' for e in events):status='MEMORY_CAP'
    elif not complete or any(e['event']=='watchdog_error' for e in events):status='MONITOR_FAILURE'
    elif complete['returncode'] in [124,137] and signal_lines:status='TIME_LIMIT'
    elif complete['returncode'] in [124,125,126,127,137]:status='TIMEOUT_TOOL_FAILURE'
    elif code==0:status='PASS_DIAGNOSTIC'
    else:status='CHILD_FAILURE'
    record['status']=status
    record['execution_status']=status
    phase='post_run_audit'
    record['tracked_after']=measure.audit(recipe['revision']);assert record['tracked_after']['passed']
    assert sha(build['binary'])==build['binary_sha256'] and sha(recipe['card']['path'])==recipe['card']['sha256']
    phase='collect_evidence'
    record['payload_logs']=[{'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(Path(recipe['state']).glob('logs/*.jsonl'))]
except BaseException as error:
    record.update(status='SOURCE_INTEGRITY_FAILURE' if phase=='post_run_audit' else 'EVIDENCE_FAILURE' if phase=='collect_evidence' else 'LAUNCH_FAILURE',
                  failed_phase=phase,error=repr(error),finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    raise
finally:
    measure.write(out/'receipt.json',record)
print(json.dumps({'status':status,'receipt':str(out/'receipt.json')}),flush=True)

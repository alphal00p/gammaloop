# Source pipeline review for expression-growth investigation

Reviewer: `/root/perf_pipeline_boundaries`. Scope: read-only source inspection; no production changes, checkouts, ref changes, tests or benchmarks performed by this reviewer. `source-pipeline-fingerprints.json` binds the exact revisions and seven pipeline files per revision. The inspected current remote-main revision is `bc8bfbad`; the caller must reconcile it with its fetch checkpoint if the remote has moved.

## Proven first change

**C3 `3ea313789a1a5290093579febd7d1c601b92594e` changes the root assembly from one shared numerator with parametric edge signs to a sum of separately mapped exact-residue numerators.** C1 and C2 retain the previous root assembly. This proves where the representation changes; it does not prove a measured performance regression or algebraic distributive expansion.

At main `bc8bfbad` and old main `39561014`:

- `uv/approx/local_3d.rs:462–471`: `Local3DCts::root` regenerates CFF, calls `expression_with_selectors()`, and multiplies tree denominators.
- `cff/mod.rs:36–41`: `expression_with_selectors` adds each CFF expression multiplied by its physical-edge theta selector.
- `uv/approx/final_integrand.rs:99–143`: `build_3d` adds local/integrated pieces, obtains **one** cograph numerator, adds parametric energy signs, multiplies it into the CFF expression, then calls `collect_factors`, metric/color simplification, and dot expansion. The compact covariant numerator need not have its vector momenta decomposed at this export boundary.
- `uv/hedge_poset.rs:1029–1030,1137`: the default HedgePoset route calls this root and builder. This is not restricted to the optional legacy forest.

At C3 (and C8 `01982f688`):

- `uv/approx/direct_3d/forest.rs:117–178` at C8: `Direct3dCts::root` recovers the stored production CFF and retains exact production IDs/maps as separate branches. No numerator distribution occurs in this method; it collects denominators and their branch metadata.
- `uv/approx/final_integrand.rs:109–120` at C3: `build_direct` calls `multiply_key_mapped` with the complete cograph numerator, then `materialize`.
- `uv/approx/direct_3d/branches.rs:199–232` at C8: the complete numerator is mapped once **per key**, multiplied by its branch integrand; `materialize` finally adds `sigma(key) * mapped_body`.
- `uv/approx/mod.rs:376–393` and `cff/expression.rs:142–179` at C8: the exact energy map substitutes each internal four-vector with its spatial part plus a temporal delta times the branch-owned energy expression. External momenta are excluded. For ordinary poles this gives the user's `(spatial_q + or - E delta)` factors; generalized residues can need more than a sign.
- `uv/hedge_poset.rs:1084–1085,1222–1224` at C8: default root takes the direct lane and uses the same builder. Expanded-4D mode only changes proper UV nodes; it cannot change the bare root lane.
- C3 also removes the final-builder `collect_factors()` pass. C7 `6d7a92201` adds early cograph `color_simplify()` before branchwise mapping and the two numerator dump stages; it does not introduce branchwise mapping.

Thus the last common **conceptual** input boundary is the graph numerator plus its CFF denominator/orientation catalog. The branch attachment differs. Actual equality of those inputs for the requested generated graphs still needs captured evidence, especially across model changes in C5 and symbolic changes in C1. They must not be assumed identical solely from the run-card text.

## Ordered complete routes

The cards select amplitudes, 3D direct local UV, no thresholds, no tropical generation, no native compilation, and algebra enabled. Default UV orchestration is **HedgePoset** (`uv/settings.rs:80–84`). Precise effective card differences are in the sibling run-card inventory.

| Stage | Main/C1/C2 | C3–C8 | Shared/different and attribution use |
|---|---|---|---|
| Model import, diagram generation/filtering/grouping | Existing SM and graph rules | Symbolic foundations C1; graph/model/sewing changes C5 | Same requested process is not itself proof of identical selected graph. Capture topology, particles, numerator, prefactors and LMB. |
| Amplitude preprocessing/CFF generation | `AmplitudeGraph::generate_cff` uses older denominator/orientation CFF | Provision exact maps from complete factorized numerator; call shared `generate_3d_expression_for_integrand` | First CFF-engine integration is C3, not C2's addition of the shared crate. |
| UV wood/unfold | HedgePoset forest | Same orchestration purpose with rewritten local representations | Need node count/keys and operation coverage, not just total timing. |
| 4D forest pass | `compute` unconditionally invokes `integrate`; each node Taylor-expands 4D source, optionally invokes Vakint | Same ordering; C6 changes integrated algebra; C7 changes Taylor/projection/caching | **`generate_integrated=false` still computes local 4D Taylor expressions.** `hedge_poset.rs:1243–1267,1280`; 4D `uv_limit` precedes the integration flag at 1060–1064. It excludes Vakint evaluation, not all 4D work. |
| Per-cut direct 3D root and proper Taylor nodes | Shared parametric numerator assembled into theta-selected CFF | Exact maps retained, branch-owned numerator replacement, opaque residue-ID selection | C3 is the root-shape boundary described above. Proper direct-Taylor operations also changed. |
| Final-node simplification | Collect factors; metric/color/dot operations | No factor collection; C7 additionally pre-simplifies cograph color | Separately measure before/after color and factor sizes. Do not restore factor collection speculatively. |
| Forest aggregation | Collect color per node, add final integrands, split remaining internal momenta, remove denominator wrappers | Same high-level tail | C8 `hedge_poset.rs:1319–1358`. The bare-node export is **before this aggregate tail**, not the final evaluator input. |
| Evaluator algebra | Color → gamma → metrics → dots if `do_algebra` | Same named sequence (`evaluators.rs:593–609`) | Different incoming expressions invalidate blaming shared gamma algebra without input comparison. |
| Tensor preparation/execution | Parse a single network; alias large scalar refs; execute configured contractions; resolve aliases | C3 parses existing top-level summands independently, prepares finite sum boundaries, contracts, resolves aliases and recombines | C3 `evaluators.rs:631–830`. Does not distribute nested graph products. Contraction default also changes SparseAtomAware → IntermediateCost at C3; hold it fixed for attribution. |
| Symbolica evaluator construction | Single parametric evaluator; optional modes according to settings | Exact residue IDs alongside physical directions; same optional-mode intent | Given all optional modes false, single parametric still builds (`evaluators.rs:975–978`). `compile=false` excludes native compilation, not this construction. |
| Computed UV-forest export | Recompute forest from cloned graph; extra spatial-measure postfactor | Recompute forest with stored exact CFF; C5 removes duplicate amplitude postfactor | Current `uv/export.rs:271–292`; exports can incur another full forest cost and must be timed separately. |
| Save DOT/state | Serialization | C4 workflow/state changes; C8 docs only | Separate save/state/export elapsed time from generation. C8 has no `crates/` diff. |

`git diff --stat 39561014 bc8bfbad --` over UV, CFF, amplitude pipeline, and evaluator source shows only a four-line UV-profile edit. The currently inspected main retains the old pipeline for these source boundaries.

## The user's two formulas are different representations, not a sufficient correctness test

Use `S+ = theta(s0) theta(-s1) theta(-s2)` and `S- = theta(-s0) theta(s1) theta(s2)`. A shared factorized root is schematically `C * (S+ + S-) * N(q0,q1)`, with parametric on-shell energy substitutions deferred. The new root is `C * [id_plus * N(q0|+,q1|-) + id_minus * N(q0|-,q1|+)]`, after substituting branch energies into the same covariant numerator. The temporal plus/minus factors differ, so a simple common-numerator extraction cannot undo this without retaining the branch parameters or map action. Shared gamma/color factors may still be common.

The identifiers **`sigma(k)`** are discrete exact-map selectors, while **`σ(edge)`** are physical ±1 edge directions. They are not interchangeable. Different exact numerator/M samples can share physical directions; the production catalog deliberately retains both (`integrands/process/amplitude/mod.rs:166–179`). A sign-only rewrite must first establish whether every actual map is a simple ±OSE map with a one-to-one physical orientation.

There is also a separate normalization difference in the quoted exports. Main's `uv/export.rs:84–93` divides the already normalized amplitude node by `(2*pi)^(3L)`; C5 removes that extra division. This directly explains an extra `pi^6` in a two-loop export. C5 also changes native CFF phase conversion from `(-i)^L` to `i^L`; these agree for the bare L=2 root but can differ for one-loop subpieces. Neither scale change proves expression growth. Retain and reconcile complete prefactors rather than dropping them silently.

## Smallest discriminating checks

1. Fix one generated sunrise graph, empty UV forest/root, uncut residue, one LMB, direct 3D, no integrated contribution, thresholds off. Capture actual source numerator, CFF scalar coefficients, exact edge-energy maps, and physical orientation catalog. Use the same contraction order when comparing evaluator work.
2. Before contour/recursion investigation, evaluate the **complete** selector truth table. For the quoted two branches, all eight assignments of `(s0,s1,s2)` must give only `(+,-,-) -> B+` and `(-,+,+) -> B-`; the other six give zero. The discrete selector table must select B+ and B- once each. Require `sum_selected_bodies == sum_explicit_bodies`, preserving each factorized body. Existing patterns are `projected_source_sum_prefers_a_compatible_physical_host` at `local_3d/tests.rs:659` and `cut_valid_ids_host_one_inner_representative_per_outer_sector` at 1663; these are patterns, not fresh validation of the user workload.
3. Compare complete selected old/new root values **after** the same energy substitution and known measure conversion. Prefer structural equality or factor-preserving rewrites; never expand graph numerators. Numeric samples supplement but do not prove the identity. Once equal, record native atom bytes, number of mapped bodies, and stage time/peak RSS to test the storage hypothesis.
4. Toggle only one feature per attribution run: no UV vs local UV; integrated false/true on the same base card; `do_algebra` false/true; fixed SparseAtomAware vs IntermediateCost; exact selectors vs explicit sum on C3+. The existing integrated/nonintegrated sunrise cards also differ in sampling defaults, so they are not themselves a one-toggle experiment.
5. If root inputs agree but measured growth first appears after gamma simplification or finite contraction, inspect that exact pair next. Do not label an expensive shared engine the cause merely because its timing is large.

## Existing diagnostics

Use quiet display plus structured logfile filters; payload dumps add overhead and should be separated from measured timing runs.

- `#generation,#profile` summaries: amplitude preprocessing, CFF, UV orchestration, evaluator Spenso vs Symbolica times. `processes/amplitude.rs:1213–1283`; `integrands/process/amplitude/mod.rs:231–261`.
- C7+: `#generation,#profile,#uv,#numerator,#dump`, stages `final_cograph_numerator_ready` and `final_integrand_before_color`, exact canonical `file.atom` and `numerator_bytes`. `final_integrand.rs:103–109,312–318`.
- Evaluator `#generation,#profile,#compile,#term,#dump`: `evaluator_stack_parse_atom_after_simplify_gamma`, `...before_network_parse`; `...network_dump` also exports a DOT network. Summaries record top-level `term_count`, alias bytes, per-term execution time, restored scalar bytes and final result bytes. `evaluators.rs:599–838`.
- Default HedgePoset node records: `hedge_poset_4d_node_done` contains operation key, source, local4D, integrated pole and finite atoms (`hedge_poset.rs:1252–1263`). Separate bare-node `save uv-forest --computed` DOT records contain `full_num` in Typst notation (`uv/export.rs:336–345`), not plain Symbolica syntax.
- Inspected main has existing `GAMMALOOP_DUMP_EVALUATOR_PRE_NETWORK_PARSE` and `GAMMALOOP_STOP_AFTER_EVALUATOR_PRE_NETWORK_PARSE` (`evaluators.rs:71–73,534–545`). The stack uses tagged logs instead; do not assume those variables exist on C3+ or add new environment hooks.

No performance claim follows from this source review alone. The root representation change is proven at C3; its measured runtime/memory contribution, any independent C1/C6/C7 effects, and the validity of a compact deferred-map representation remain to be established by the caller's pinned workload runs.

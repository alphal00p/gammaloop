# Expression-generation performance investigation

Source of scope: goal-objective.md and the user-attached uv-scalar-growth-reproducer.zip.

## Required outcomes and evidence

1. Push reviewed C8 `01982f68` to the existing reviewed branch: push-result.json plus exact remote ref verification. Complete.
2. Measure all four distinct physical cards on current remote main and every C1–C8. Include original main as a control. Revisions are fixed in revisions.json; cards and every adaptation are bound by attachments/run-card-inventory.json.
3. Preserve native locked dependencies, models and requested settings. The attached intermediate_cost setting is unavailable before C3; record that exact limitation and measure the same physical workload with the explicitly labeled common sparse_atom_aware control.
4. Bind each actual run to its source tree, CLI binary hash, lockfile, model assets, parsed card and settings. Use fresh independent state/output folders; do not reuse generated states.
5. Separate build time, full-card wall time, generation stages and export/recomputation costs. Measure Linux process-tree RSS under the existing 30 GB watchdog. Infrastructure failure, memory cap and completed generation are distinct outcomes.
6. Compare complete pipeline stages before attributing a slowdown. Trace first changed representation and adjacent commit; distinguish orientation mapping, contraction-order defaults, model changes, physical/export normalization and numerical evaluator work.
7. Preserve graph-numerator factorization in diagnostics. For selectors, check the complete truth table and selected bodies before blaming contour/residue machinery.
8. Repeat material onset comparisons with fresh states, and vary one setting at a time to isolate the cause. Existing historical timings do not certify these inputs or revisions.
9. Produce a current report with the complete matrix, measured uncertainty/censoring, causal evidence, source references, reproducible commands and unresolved limits. Do not claim an implementation cause from textual appearance alone.

## Execution constraints

Use pinned /tmp/raised-stack/run only by invocation, never inspect or archive its contents/environment. Four Cargo build workers; fixed eight Rayon workers and 128 MiB Rust worker stacks for runtimes; cards retain their requested generation core count. Run guarded benchmarks one at a time without competing builds. Preserve existing original history and reviewed source commits. Investigation is authorized; no production fix is being inferred from a suspected slowdown.

## Current state

Push verified. All 46 primary attempts are terminal: 37 passes, six memory caps,
two program failures and one monitor failure. Four exact intermediate-cost
combinations are unsupported and reported alongside labeled sparse controls.
All 10 native builds and recorded source/binary/model/card audits pass. The
complete matrix is in measurements.json/.csv and measurement-matrix.md.

All seven repetitions and six one-setting controls are terminal: 12 passes,
one memory cap and zero aggregate evidence issues. They reproduce the material
C3 onset. Four complete C1/C3 upstream captures, exact common-gamma witnesses,
GL1 graph/model certificates and the complete sunrise runtime sign truth table
are retained without graph-numerator expansion.

Both fixed-C3 factor replays completed. Their exact input identity is proved;
complete returned Atoms are structurally unequal. The separate checker also
completed (execution PASS) and records NUMERICAL_DISAGREEMENT at all three
predetermined points, with relative residuals near 1e-16 despite requested
256-bit evaluation. Precision qualification belongs to its separate source
audit; this result certifies neither an output identity nor a contraction bug.
The unchanged minimal C8 public color probe reproduces the slot-inference bug:
its two controls pass, the symmetric trace loses exposed slots, and the native
decomposed sum is rejected. Its CHILD_FAILURE is the observed contract failure.

C6's native GL1 observation remains infrastructure-censored. The first logging
diagnostic was explicitly stopped for inert selectors and is retained as a
setup failure. The corrected diagnostic reached its declared TIME_LIMIT after
1200.742 seconds (629,071,872-byte sampled process-tree peak); its full final
43-event trace matches the preserved snapshot. GDB attachment was denied and
captured zero frames. These diagnostics do not replace the native timing.

No scheduled workload execution remains pending. No production fix was applied.
There is no independent export/recomputation-only timer; full-card minus
generation time is not presented as export cost. One implementation cause for
the entire C3 regression, matched C1/C3 proper-UV ownership, GL1 complete scalar
CFF-weight equivalence and full-integrand equality remain unproved. These are
explicit limits on the completed investigation, not omitted scheduled runs.

Final report review is bound by final-report-review.json. Archive completion is
certified by the external raised-energy-cff-expression-performance-evidence.json
manifest after packaging; the audit does not embed a self-referential archive
hash. The root task is completing that report/precision qualification and final
archive verification from the terminal evidence.

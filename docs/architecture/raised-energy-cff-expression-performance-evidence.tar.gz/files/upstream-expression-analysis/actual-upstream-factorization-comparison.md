# Actual C1–C3 upstream expression comparison

The measured onset is C3, and the complete captured expressions already differ before evaluator algebra or tensor execution. This report identifies specific grouping changes and an exact common-factor witness. It does not identify the runtime cost of each transformation separately.

The source pins are C1 `665658b168981c5c508e6cd51d3b57bbb55a27fb`, C2 `a9397ee0f86b115fdfab50e81c48dde2137692e7`, and C3 `3ea313789a1a5290093579febd7d1c601b92594e`. C1 and C2 CLI binaries are byte-identical. Both C1 and C3 precede C5's physical-phase changes; no later normalization was applied to this comparison. The adjacent measured receipts and source timeline are in `../orientation58-strategy-source-diagnosis.md`.

## Complete artifacts and capture boundary

`extracted-payloads.json` records the full payload paths, SHA-256 hashes, exact logfiles, line numbers, hook fields, revisions, trees and reported packed sizes. Each `*-structure.json` includes an inventory of every complete signed top-level term. Every `*-terms/*.atom` contains the actual whole term, with subtraction retained; local ordinals are locators, not semantic identities.

The raw amplitude hook is before color/gamma algebra and hides symbol namespaces and attributes. The `after_gamma` and `pre_network` hooks use namespace-preserving plain Symbolica text. The attached card has `do_algebra=false`; GL1 has `do_algebra=true`. For GL1, C3's complete after-gamma and pre-network payloads are byte-identical (SHA-256 `d3faeff48c44e7fee22d05e1647c1257fc2a5837a7b74c2bc28833a3f500bd61`). The C1 and C3 raw GL1 payloads are already different before that stage, so this is not solely a contraction-strategy observation.

## Proper-UV witness, with namespaces retained

The strongest witness is `c3-orientation58-pre_network-common-gamma-witness/`. Its `original-complete-sum.atom` is a complete 559,179-byte UV subexpression with three summands. Each summand contains the same product `G` of eight fully qualified `spenso::gamma` factors. Their complete spinor and Lorentz arguments are preserved in `common-gamma-product.atom`; equal display names are not the basis for equality.

Its complete enclosing contribution has the form

```
-2 * (G*R0 + G*R1 + G*R2)
   * spenso::g(spenso::mink(4,gammalooprs::hedge(0)),
               spenso::mink(4,gammalooprs::hedge(1)))
   * three_dimensional_reps::sigma(58)
```

This notation summarizes the complete files; it omits no factors from the saved witness. `branch-00-original.atom` through `branch-02-original.atom` and their corresponding `*-remainder.atom` files retain all coefficients, signs, UV mass terms, routing expressions, powers and denominators. The remainders include nested sums; none was expanded or rationally simplified.

`factored-equivalent-complete-sum.atom` contains `G*(R0+R1+R2)`. The proof checks every original branch's full signed direct-factor multiset against `G` plus its complete remainder. It also reparses each written remainder, permitting only associative multiplication, unit factors, unary signs and commutative Add/Mul order. Inverses, powers and function arguments stay intact. Gamma matrices keep all ordered spinor arguments; commuting these indexed tensor factors does not reorder matrix multiplication.

`factored-equivalent-complete-enclosing-term.atom` and `factored-equivalent-whole-payload.atom` replace exactly this one subexpression. Reversing the replacement restores each original text exactly. The whole evaluator input therefore differs only by the proven reverse-distributivity identity. These are scratch text alternatives: no Symbolica parsing, tensor execution or production edit was performed on them.

`attachment-witness-namespace-crosscheck.json` additionally confirms that removing namespace prefixes from the entire pre-network sum yields the raw pre-algebra sum character-for-character. Its complete enclosing term and `G` also match exactly. Thus this particular grouping is already present at the raw hook and reaches network parsing unchanged for the attached card.

A raw GL1 proper-UV witness in `c3-g_gl1-raw_pre_algebra-common-gamma-witness/` similarly contains three summands with six common gamma factors, with complete coefficient/denominator-preserving remainders. Its hidden-namespace limitation remains explicit: GL1 gamma algebra removes these factors before the namespace-preserving capture. `common-gamma-witnesses.json` indexes all three witness/proof records and hashes.

C1 visibly keeps large UV sums multiplied by gamma products outside those sums. For example, `c1-orientation58-pre_network-000-terms/002.atom` retains twelve fully qualified direct gamma factors outside its 604,972-byte tensor-bearing sum, together with its coefficient, common denominator and theta selectors. This is a descriptive comparison of actual grouping. It is not a claim that this ordinal is the same forest sector as the C3 witness: individual owner/routing correspondence and equality of the two complete UV sectors have not been established.

## Bare contributions: two distinct observations

The complete attachment audit is `orientation58-bare-factor-audit.md` and `.json`. C1 and C3 retain the same physical denominator, coefficient, six vertex-gamma factors and six factorized fermion numerators. C1 writes each as a compact slashed sum; C3 writes an explicit edge-slot gamma times a two-term on-shell vector. The six vector sums are not cross-multiplied out. C3 has only the selected `sigma(58)` channel, so multiple selected production orientations cannot explain this card's growth. The actual attached graph has no three-gluon vertex: it has a quark loop and a quark bubble on a gluon line.

The physical GL1 graph does have the three-gluon vertex (`V_36`, `VVV1`, `GC_10`), and its saved C1/C3 graphs are byte-identical. `gl1-bare-factor-audit.md` and `.json` show C1's intact six-term three-gluon sum and three compact slash factors multiplying a scalar 18-selector CFF sum. In C3, each of the 18 branches carries the intact three-gluon sum, three factorized vector/gamma pairs and the same three vertex gammas. The three-gluon sum itself is not distributed against the quark numerator.

All eighteen C3 three-gluon factors match C1's whole factor after the recorded signs on energies 5 and 6; all remaining gamma/vector factors are accounted for. The complete five-edge sign-support table matches eighteen sectors one-to-one. C3's outer `6i` times inner `-i/16384` reproduces C1's `3/8192`, with the same `GC_10 * GC_11^3`. The audit preserves complete scalar CFF weights but does not prove their full rational equivalence or independently decode the runtime orientation catalog.

## Source boundaries

Source paths below are relative to `crates/` in the immutable `../diagnostic-workspaces/c1/` and `c3/` trees.

1. **Common-factor collection:** C1 `gammalooprs/src/uv/approx/final_integrand.rs:130–143` multiplies the residual cograph numerator and calls `collect_factors()` at line 135, then simplifies metrics/color and expands dots. C3 `final_integrand.rs:109–121` maps that numerator per residue key and materializes the selector sum; its `simplify_final` at lines 283–297 omits the factor-collection call. Its comment at lines 288–289 specifically preserves denominator sums. This is a concrete changed factoring boundary consistent with the UV witness; it is not an isolated measurement of that call's effect.
2. **Vector split before compacting:** C1 `gammalooprs/src/uv/hedge_poset.rs:1256–1262` splits four-vectors after final-integrand aggregation. C3 `gammalooprs/src/uv/approx/direct_3d/branches.rs:205–211` invokes the per-key numerator map, through `uv/approx/mod.rs:389–393` and `cff/expression.rs:169–172`, before final simplification. That map replaces an indexed `Q` with `Q3 + energy*delta`.
3. **Shared compacting rule, changed input:** `simplify_metrics()` disables rank-one compacting in both revisions, but `idenso/src/shorthands/metric.rs:451–454` calls `to_dots()` from `expand_dots()`. `idenso/src/shorthands/schoonschip/api.rs:298–300` enables rank-one compacting there. The rule at `idenso/src/shorthands/schoonschip/with_settings.rs:199–210` matches a tensor multiplied by a rank-one function; it does not distribute that tensor across an additive vector factor. C1 reaches it with unsplit `Q`, whereas C3 reaches it with a vector sum. The four relevant Idenso files are byte-identical, as recorded in the bare audit. Changed ordering explains the compact-versus-explicit placement without assuming a distributed numerator product.

## Scope of the conclusion

The captures establish an upstream representation change at the measured C3 onset, specific preserved or repeated numerator factors, and a fully qualified proper-UV common-factor extraction that is exact within the C3 input. They justify investigating factor preservation before tensor execution. They do not yet determine which C3 transformation accounts for how much time or memory, prove a full C1/C3 UV integrand identity, or establish that this one factored alternative fixes the cap. No production change or new physics workload was run for this analysis.

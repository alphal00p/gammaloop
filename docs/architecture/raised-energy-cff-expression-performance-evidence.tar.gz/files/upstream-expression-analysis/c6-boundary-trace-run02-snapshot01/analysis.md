# C6 integrated UV expression boundaries: captured run-02 prefix

The full captured inputs include a common color product outside two local sums and a later integrated expression repeating that product in all 248 summands, followed within seconds by several smaller integrated-algebra entries whose structure is consistent with projected numerators. They do not identify the operation responsible for the later long wait. This is an input-structure finding, not a performance attribution or an algebraic-equality certificate.

Scope: C6 `8e4e4664f3f9303760eb18d7972b91ff867b12ea`, tree `82e9ef7f1ef2362d61f0a9d8fe39059f590cefc5`. All source references below use the immutable `diagnostic-workspaces/c6` directory under the evidence root. No source changes, tensor execution, numerical evaluation, expression expansion, or extra workload occurred for this analysis.

## Capture and provenance

`captured-log-prefix.jsonl` preserves the complete 43-line prefix of corrected diagnostic run-02's `gammalog-2026-09-14T22-08-21.232Z.jsonl`. Its 3,596,965 bytes have SHA256 `3877fae22b862175543deae1047cb19a658084bfb98a3909d4a7686c9f872c08`. The snapshot was taken while the process was live. Each complete plain-Symbolica payload is preserved in `event-NNN-FIELD.atom`; only the fixed `n-terms: ..., byte size: ...,expr:` metadata header is removed. `timeline.json` records full payload hashes, packed Atom sizes, UTF-8 sizes, source module/line, timestamp, and every other field. `timeline.csv` provides the same event sequence compactly.

The records run from 22:08:21.337 to 22:08:26.258 UTC: 4.921 seconds. Ordinals are artifact locators, not semantic owner identities. These events do not include forest/node/current/given/reduced identities. In particular, adjacency alone does not prove that event32 is the complete owner input producing event33. Forest signs, markers, multiple sectors and the integrated loop-scale replacement occur between local `t` and `Integrated::run`.

| Event | Stage | Top-level terms | Packed Atom bytes | Complete payload UTF-8 bytes |
|---|---|---:|---:|---:|
|24|two-loop local rescaled input|1|3,707|7,230|
|26|local Taylor result at t=1|3|29,844|58,122|
|32|local After dots|1|30,243|58,672|
|33|integrated After gamma chain collection|248|1,188,746|2,357,013|
|34|next integrated collection input|3|14,036|21,543|
|43|last captured integrated collection input|2|19,387|29,397|

## Full expression structure, not just counts

Event32 is one product of two intact additive factors (53,940 and 4,189 UTF-8 bytes), three explicit `spenso::t` factors and one explicit `spenso::f` factor. The latter four factors are a complete common color product. It has no `spenso::gamma`, `spenso::trace`, `spenso::chain` or `spenso::bis` function anywhere in its full payload. It still contains momentum factors, Lorentz metrics, scalar dots, 56 denominator functions and momentum-provenance functions.

Event33 contains 248 top-level summands. Every summand contains exactly the same namespace-and-argument-qualified direct color product as event32: three `t` and one `f`. The complete check accounts for all 744 `t` and 248 `f` appearances. This is an observed distributed representation with repeated common color factors, in contrast with event32's common product outside the two sums. `color-factor-sharing.json` includes the exact four factors and per-event function inventories. All scalar coefficients, signs, denominators and other factors remain untouched in the preserved complete payloads; this check does not equate the two complete expressions.

The hypothesis that a remaining compact color trace alone triggers the `gamma || trace` analytic expansion is rejected for event32: there is no compact trace of any representation. `SPENSO_TAG.trace` is the literal symbol `trace` (`crates/spenso/src/network/tags.rs:467`). The same absence holds for event33 and events34–43. Earlier event9 has three gamma functions and one chain, so the conditional analytic spin path can be relevant to an earlier contribution. That does not establish its use for the later, spin-reduced input.

Events34–43 have no gamma, bispinor, chain or trace functions. They also have no original `gammalooprs::denom` or `momentum_provenance` functions. They contain scalar momentum products written with `vakint::dot` and `vakint::k` arguments, repeated color factors and an external Lorentz basis. The only indexed Minkowski arguments are `mink(dim,hedge(0))` and `mink(dim,hedge(1))`. Thus these are spin-reduced expressions with external Lorentz/color tensors, not wholly scalar final answers and not remaining open spin chains. Event43 retains one metric and Q factors on that external basis, with scalar momentum expressions in nested coefficients.

The syntax parser is the already-existing `analyze-captured-structure.py`, loaded only through its parser definitions. No distributing or algebraic rewrite is performed. Its older `direct_scalar_factors`/`direct_tensor_factors` heuristic in `selected-structures.json` is not a semantic classification: its name list omits Q and lowercase t. The qualified function inventories and exact direct-color-factor check in `color-factor-sharing.json` are the basis for the conclusions here.

## Ordered source boundary and current blind spot

1. `crates/gammalooprs/src/uv/approx/mod.rs:466` obtains the recursive input, runs `local_4d::uv_limit` and then `Integrated::run` when integrated terms are enabled.
2. `local_4d.rs:850` logs the rescaled input. Lines861–906 log Taylor expansion, evaluation at t=1, tensor collection, gamma simplification, Schoonschip and dots. The resulting local sector is signed/marked at1086; `FourDSectors::new` at100–106 sums sectors. `Local4dCts::atom` at277 returns the stored atom.
3. `integrated.rs:333` replaces the integrated loop scale by one and calls `simplify` at337. Its conditional symbolic spin parser and `.expand()` at169–221 run only when gamma or trace is present. If event32 were the relevant complete input, its gamma/trace absence would skip this branch. The still-unisolated next boundary is `collect_rep(Minkowski) -> simplify_metrics -> collect_rep(Bispinor) -> collect_gamma_chains` at224–228, before the selected event at229.
4. Tensor collection can reorganize tensor-bearing products/sums: `crates/spenso/src/shadowing/collect.rs:131` wraps selected tensor functions, protects complete unselected scalar coefficients, and at178 calls `collect_symbol(...).collect_collects()`. This identifies an existing boundary to inspect; it does not establish which individual call created event33 or caused the long wait.
5. The initial simplify result enters `integrate` at343. That method converts to Vakint at408, canonicalizes at433, and tensor-reduces at442. It then calls `simplify_projected_numerator` on each resulting numerator at451–453.
6. That second caller converts the projected numerator to dot notation at524, restores the external tensor leaves at525, and calls the same `simplify` at526. It therefore emits the identical source event229. Afterward it validates Lorentz contractions, dimensionally regularizes, undoes shorthand notation and returns to Vakint format at527–533. The late payloads' `vakint::dot`/`k`, external basis and lack of original propagator denominators are consistent with this projected-numerator path; the log itself does not encode caller/owner identity.
7. After all projected numerators finish, `evaluate_integral` runs at461. Further unselected work includes reconstruction at478–480, chain cleanup at490–503, final analytic expansion at512 and Laurent projection in `run` at348.

The large event33 is followed by ten more collection events. The current filter captures neither completion of the final `simplify` nor completion of projected-numerator conversion or backend evaluation. Therefore the silent interval cannot be assigned to event33, tensor reduction, a particular simplify operation or Vakint evaluation. Failure to obtain a stack sample under the host ptrace policy adds no execution location evidence.

The smallest additional existing milestones, if a separate diagnostic is justified, are:

```
gammalooprs::uv::approx::integrated[{profile,dots}]=debug,
gammalooprs::uv::approx::integrated[{stage,term_index,!reduced}]=debug,
gammalooprs::uv::approx::integrated[{evaluate}]=debug
```

These select, respectively, final simplify dots at269, completed projected-numerator algebra at454 (excluding the conversion-stage events that also have a `reduced` field), and completed integral evaluation at463. They require no production logging changes and select no DOT export. The first event is before unresolved-trace validation, and the second is after Lorentz validation and conversion; their interval would still contain those operations. These are a bounded optional discriminator, not a requirement to run an open-ended sequence of diagnostics. Field-presence selectors operate on raw tracing metadata; routed payload names such as `expr` cannot substitute for `file.expr`, and dotted identifiers are unsupported by this revision's filter grammar.

## Evidence hashes

- `timeline.json`: `477c4ac0124082b76d29f8351fc159a8e26bc70eefa80ab49dd0b8c4ad70e8bc`
- `color-factor-sharing.json`: `54fcf1e45d1bb62ad5204596d76b40f722aca2272ad051380a48042cc8692e42`
- C6 `local_4d.rs`: `e40b80007e2ab72fcccb51c1fc3825c21e041879c230b6e8953d75c003ed42f1`
- C6 `integrated.rs`: `91c4528eb1a0533f5f9fd02a518e7de4b68468164c62f686e9ade0d4ac1c0597`
- C6 `approx/mod.rs`: `1491219aaf2a2c6eed20bf85200521f5f61bb3064de902b865f7f07033aa1d30`
- C6 `shadowing/collect.rs`: `08b88cd7e8dfed9a80d3566be625d5618fcc6cd2c0598209f8e3d85ff428983f`

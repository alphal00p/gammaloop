"""Read captured text only. Preserve Add/Mul/Pow/Fun grouping; never distribute."""
from pathlib import Path
import collections
import hashlib
import json
import re

BASE=Path('/tmp/raised-energy-expression-perf-20260914')
OUT=BASE/'upstream-expression-analysis'
TENSOR_NAMES={'gamma','g','Q3','δ','chain','tr','T','f'}

# Balanced splitting follows compare-sunrise-bare-pair.py, extended because these
# plain/raw printers also use binary subtraction and division.
def unparen(text):
    while text.startswith('(') and text.endswith(')'):
        depth=0
        for i,ch in enumerate(text):
            depth+=(ch=='(')-(ch==')')
            if depth==0: break
        if i!=len(text)-1: break
        text=text[1:-1]
    return text

def positions(text, operators):
    depth=0; found=[]
    for i,ch in enumerate(text):
        if ch=='(': depth+=1
        elif ch==')':
            depth-=1
            assert depth>=0
        elif depth==0 and ch in operators:
            if ch in '+-' and (i==0 or text[i-1] in '+-*/^,'):
                continue
            if ch in '+-' and i>1 and text[i-1] in 'eE' and text[i-2].isdigit():
                continue
            found.append((i,ch))
    assert depth==0
    return found

def split_at(text,found):
    starts=[0]+[i+1 for i,_ in found];ends=[i for i,_ in found]+[len(text)]
    return [text[a:b] for a,b in zip(starts,ends)]

class Node:
    __slots__=('kind','name','children','text','digest','tensor','counts','max_add_depth')
    def __init__(self,kind,name,children,text):
        self.kind=kind;self.name=name;self.children=children;self.text=text
        childkeys=[c.digest for c in children]
        if kind in ['add','mul']: childkeys.sort()
        self.digest=hashlib.sha256(json.dumps([kind,name,childkeys],ensure_ascii=False).encode()).hexdigest()
        self.tensor=(kind=='fun' and name.split('::')[-1] in TENSOR_NAMES) or any(c.tensor for c in children)
        self.counts=collections.Counter([kind])
        for child in children:self.counts.update(child.counts)
        self.max_add_depth=(kind=='add')+max((c.max_add_depth for c in children),default=0)

def parse(text):
    s=unparen(text.strip())
    found=positions(s,'+-')
    if found:
        pieces=split_at(s,found); children=[parse(pieces[0])]
        for (_,op),part in zip(found,pieces[1:]):
            child=parse(part)
            if op=='-':child=Node('neg','',[child],'-'+part)
            children.append(child)
        return Node('add','',children,s)
    found=positions(s,'*/')
    if found:
        pieces=split_at(s,found); children=[parse(pieces[0])]
        for (_,op),part in zip(found,pieces[1:]):
            child=parse(part)
            if op=='/':child=Node('inv','',[child],'1/('+part+')')
            children.append(child)
        return Node('mul','',children,s)
    if s.startswith('-'):return Node('neg','',[parse(s[1:])],s)
    if s.startswith('+'):return parse(s[1:])
    found=positions(s,'^')
    if found:
        i,_=found[0]
        return Node('pow','',[parse(s[:i]),parse(s[i+1:])],s)
    left=s.find('(')
    if left>0 and s.endswith(')'):
        name=s[:left];args=s[left+1:-1]
        return Node('fun',name,[parse(p) for p in split_at(args,positions(args,','))] if args else [],s)
    return Node('leaf',s,[],s)

def walk(node,path='root'):
    yield path,node
    for i,c in enumerate(node.children):yield from walk(c,f'{path}/{node.kind}[{i}]')

def factors(node):
    while node.kind=='neg':node=node.children[0]
    return node.children if node.kind=='mul' else [node]

def describe(node):
    fs=factors(node)
    return {'kind':node.kind,'digest':node.digest,'utf8_bytes':len(node.text.encode()),'counts':dict(node.counts),'max_nested_add_depth':node.max_add_depth,'direct_factor_count':len(fs),'direct_tensor_factors':[{'kind':f.kind,'name':f.name,'sha256':f.digest,'utf8_bytes':len(f.text.encode()),'preview':f.text[:160]} for f in fs if f.tensor],'direct_scalar_factors':[{'kind':f.kind,'sha256':f.digest,'utf8_bytes':len(f.text.encode()),'text':f.text if len(f.text)<180 else f.text[:160]+'...'} for f in fs if not f.tensor]}

records=[]
for log in sorted((BASE/'controls/measurements').glob('*/run-*expression_boundaries-01/state/logs/*.jsonl')):
    run=log.parents[2];rev=run.parent.name;workload=run.name.split('run-',1)[1].split('_expression_boundaries',1)[0]
    receipt=json.loads((run/'receipt.json').read_text())
    for lineno,line in enumerate(log.open(),1):
        try:row=json.loads(line)
        except json.JSONDecodeError:continue
        for key,stage in [('orientation_parametric_integrand','raw_pre_algebra'),('after_gamma','after_gamma'),('atom','pre_network')]:
            if key not in row:continue
            if key=='atom' and row.get('stage')!='evaluator_stack_parse_atom_before_network_parse':continue
            if key=='after_gamma' and row.get('stage')!='evaluator_stack_parse_atom_after_simplify_gamma':continue
            body=row[key];packed=None;nterms=None
            if key!='orientation_parametric_integrand':
                m=re.match(r'n-terms: (\d+), byte size: (\d+),expr:',body);assert m
                nterms,packed=map(int,m.groups());body=body[m.end():]
            label=f'{rev}-{workload}-{stage}-{row.get("atom_index",0):03d}'
            path=OUT/f'{label}.atom';path.write_text(body)
            tree=parse(body);terms=tree.children if tree.kind=='add' else [tree]
            if nterms is not None:assert len(terms)==nterms,(label,len(terms),nterms)
            termdir=OUT/f'{label}-terms';termdir.mkdir(exist_ok=True)
            trows=[]
            for i,term in enumerate(terms):
                termpath=termdir/f'{i:03d}.atom';termpath.write_text(term.text)
                trows.append({'local_index':i,'path':str(termpath),**describe(term)})
            sums=[]
            for astpath,node in walk(tree):
                if node.kind!='add' or not node.tensor:continue
                direct_tensor=sum(c.tensor for c in node.children)
                if len(node.text)<500:continue
                factor_sets=[collections.Counter(f.digest for f in factors(c)) for c in node.children]
                common=factor_sets[0].copy()
                for fs in factor_sets[1:]:common&=fs
                examples={f.digest:f.text for f in factors(node.children[0])}
                sums.append({'path':astpath,'digest':node.digest,'utf8_bytes':len(node.text.encode()),'summands':len(node.children),'tensor_bearing_summands':direct_tensor,'common_intact_direct_factors':[{'digest':d,'multiplicity':n,'text':examples[d] if len(examples[d])<180 else examples[d][:160]+'...'} for d,n in common.items()],'preview':node.text[:180]})
            sums.sort(key=lambda x:x['utf8_bytes'],reverse=True)
            record={'revision':receipt['revision'],'tree':receipt['tree'],'run':str(run),'log':str(log),'line':lineno,'field':key,'stage':stage,'atom_index':row.get('atom_index',0),'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'utf8_bytes':len(body.encode()),'packed_atom_bytes':packed,'top_level_terms_reported':nterms,'namespace_scope':'hidden all namespaces and attributes' if key=='orientation_parametric_integrand' else 'plain Symbolica syntax','structure':describe(tree),'terms':trows,'tensor_sums':sums}
            (OUT/f'{label}-structure.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
            records.append({k:v for k,v in record.items() if k not in ['terms','tensor_sums','structure']})
            print(json.dumps({'label':label,'topterms':len(terms),'bytes':len(body.encode()),'tensor_sum_count':len(sums),'max_add_depth':tree.max_add_depth,'top_term_tensor_factor_counts':[len(t['direct_tensor_factors']) for t in trows]},ensure_ascii=False),flush=True)
(OUT/'extracted-payloads.json').write_text(json.dumps(records,indent=2)+'\n')

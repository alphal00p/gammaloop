"""Exact syntax witnesses for common gamma factors; no algebra runtime or expansion."""
import ast
import collections
import hashlib
import json
import re
from pathlib import Path

OUT=Path('/tmp/raised-energy-expression-perf-20260914/upstream-expression-analysis')
source=ast.parse((OUT/'analyze-captured-structure.py').read_text())
ns={}
allowed=[]
for node in source.body:
    if isinstance(node,ast.For):break
    allowed.append(node)
exec(compile(ast.Module(body=allowed,type_ignores=[]),'<existing text parser definitions>','exec'),ns)
parse=ns['parse'];unparen=ns['unparen'];positions=ns['positions'];split_at=ns['split_at']

def lazy(node):
    if 'kind' in node:return node
    s=unparen(node['text'].strip());node['text']=s
    found=positions(s,'+-')
    if found:
        parts=split_at(s,found);children=[{'text':parts[0]}]
        for (_,op),part in zip(found,parts[1:]):
            child={'text':part}
            if op=='-':child={'kind':'neg','text':'-'+part,'children':[child]}
            children.append(child)
        node.update(kind='add',children=children);return node
    found=positions(s,'*/')
    if found:
        parts=split_at(s,found);children=[{'text':parts[0]}]
        for (_,op),part in zip(found,parts[1:]):
            child={'text':part}
            if op=='/':child={'kind':'inv','text':'1/('+part+')','children':[child]}
            children.append(child)
        node.update(kind='mul',children=children);return node
    if s.startswith('-'):
        node.update(kind='neg',children=[{'text':s[1:]}]);return node
    if s.startswith('+'):return lazy({'text':s[1:]})
    found=positions(s,'^')
    if found:
        i,_=found[0];node.update(kind='pow',children=[{'text':s[:i]},{'text':s[i+1:]}]);return node
    i=s.find('(')
    if i>0 and s.endswith(')'):
        args=s[i+1:-1];node.update(kind='fun',children=[{'text':p} for p in split_at(args,positions(args,','))] if args else []);return node
    node.update(kind='leaf',children=[]);return node

def locate(text,path):
    node={'text':text}
    for step in path.split('/')[1:]:
        kind,index=step[:-1].split('[');node=lazy(node)
        assert node['kind']==kind,(step,node['kind'])
        node=node['children'][int(index)]
    return lazy(node)

def product_parts(node):
    sign=1
    while node.kind=='neg':sign=-sign;node=node.children[0]
    return sign,node.children if node.kind=='mul' else [node]

def normalize_product(nodes):
    # Only associative products, signs, and the multiplicative identity are
    # normalized. Inverse/power/function nodes stay whole and untouched.
    sign=1; factors=[]
    def visit(node):
        nonlocal sign
        if node.kind=='neg':sign=-sign;visit(node.children[0])
        elif node.kind=='mul':
            for child in node.children:visit(child)
        elif node.kind=='leaf' and node.name=='1':pass
        else:factors.append(node.digest)
    for node in nodes:visit(node)
    return sign,collections.Counter(factors)

def fingerprint(path):
    return {'path':str(path),'utf8_bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}

records=[]
for workload,stage in [('orientation58','raw_pre_algebra'),('orientation58','pre_network'),('g_gl1','raw_pre_algebra')]:
    data=json.loads((OUT/f'c3-{workload}-{stage}-000-structure.json').read_text())
    witness=next(s for s in data['tensor_sums'] if len([f for f in s['common_intact_direct_factors'] if f['text'].split('(',1)[0].split('::')[-1]=='gamma'])>=4)
    raw=Path(data['path']).read_text()
    located=locate(raw,witness['path']);node=parse(located['text'])
    assert node.kind=='add' and node.digest==witness['digest']
    common=[f for f in witness['common_intact_direct_factors'] if f['text'].split('(',1)[0].split('::')[-1]=='gamma']
    target=collections.Counter({f['digest']:f['multiplicity'] for f in common})
    directory=OUT/f'c3-{workload}-{stage}-common-gamma-witness';directory.mkdir(exist_ok=True)
    original=directory/'original-complete-sum.atom';original.write_text(node.text)
    gamma_text='*'.join('('+f['text']+')' for f in common for _ in range(f['multiplicity']))
    gamma_path=directory/'common-gamma-product.atom';gamma_path.write_text(gamma_text)
    remainder_texts=[];branches=[]
    for i,branch in enumerate(node.children):
        sign,fs=product_parts(branch);pending=target.copy();remaining=[];removed=[]
        for factor in fs:
            if pending[factor.digest]:pending[factor.digest]-=1;removed.append(factor)
            else:remaining.append(factor)
        assert not any(pending.values())
        assert collections.Counter(f.digest for f in removed)==target
        assert collections.Counter(f.digest for f in remaining)+target==collections.Counter(f.digest for f in fs)
        # Preserve the branch's outside sign; every denominator and scalar
        # coefficient remains in exactly one untouched remainder factor.
        rest=('*'.join('('+f.text+')' for f in remaining) or '1')
        if sign<0:rest='-('+rest+')'
        remainder_texts.append(rest)
        original_branch=directory/f'branch-{i:02d}-original.atom';original_branch.write_text(branch.text)
        remainder=directory/f'branch-{i:02d}-remainder.atom';remainder.write_text(rest)
        # Parse written remainder and compare complete intact direct factors;
        # only redundant parentheses/Add-Mul order are ignored.
        reparsed=parse(rest);rest_sign,rest_fs=product_parts(reparsed)
        # A leading negative product may parse as a negative first factor;
        # the explicit enclosing -(...) above avoids that ambiguity.
        expected_sign,expected_factors=normalize_product(remaining)
        actual_sign,actual_factors=normalize_product([reparsed])
        assert actual_sign==sign*expected_sign
        assert actual_factors==expected_factors
        branches.append({'index':i,'sign':sign,'original':fingerprint(original_branch),'remainder':fingerprint(remainder),'original_direct_factor_digests':[f.digest for f in fs],'remaining_direct_factor_digests':[f.digest for f in remaining],'common_removed_exactly_once':True,'complete_factor_multiset_reassembly_equal':True})
    alternative=directory/'factored-equivalent-complete-sum.atom'
    alternative.write_text('('+gamma_text+')*('+'+'.join('('+s+')' for s in remainder_texts)+')')
    enclosing_path='/'.join(witness['path'].split('/')[:2]);enclosing=locate(raw,enclosing_path)
    enclosing_file=directory/'original-complete-enclosing-term.atom';enclosing_file.write_text(enclosing['text'])
    record={'workload':workload,'stage':stage,'revision':data['revision'],'complete_payload':fingerprint(Path(data['path'])),'source_log':data['log'],'source_line':data['line'],'ast_locator_only':witness['path'],'original_sum':fingerprint(original),'enclosing_term':fingerprint(enclosing_file),'common_gamma_product':fingerprint(gamma_path),'common_gamma_factors':common,'branch_count':len(branches),'branches':branches,'alternative':fingerprint(alternative),'proof':'For every full original summand, retain its outside sign and all intact scalar/tensor/denominator factors; remove precisely the identical gamma-factor multiset G. Reassembly G*R_i equals that original signed factor multiset. Hence sum_i original_i = G*(sum_i R_i) by distributivity in reverse. No product or power in the graph numerator was expanded, no denominator simplified or cancelled, and no Symbolica/tensor/numeric execution occurred.','scope_limit':'Within-C3 complete captured subexpression identity, not a proof that this is an individually matched C1 forest sector or the cause of measured slowdown. Exact selector context is retained in the enclosing term; it is not discarded by the subexpression witness.','namespace_scope':data['namespace_scope'],'text_reparse_normalization':'Associative product grouping, unit factors 1, unary signs, and Add/Mul ordering only; inverses, powers, function arguments, and all other factors remain intact.'}
    # Substitute only this proved sum; preserve the whole evaluator context.
    assert raw.count(node.text)==1 and enclosing['text'].count(node.text)==1
    for label,context in [('factored-equivalent-complete-enclosing-term',enclosing['text']),('factored-equivalent-whole-payload',raw)]:
        alt=context.replace(node.text,alternative.read_text(),1)
        assert alt.count(alternative.read_text())==1
        assert alt.replace(alternative.read_text(),node.text,1)==context
        dest=directory/(label+'.atom');dest.write_text(alt)
        record[label]={**fingerprint(dest),'one_subexpression_replaced':True,'inverse_text_replacement_restores_original_exactly':True}
    dest=directory/'proof.json';dest.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
    records.append({'workload':workload,'stage':stage,'proof':fingerprint(dest),'sum_bytes':original.stat().st_size,'gamma_factors':sum(target.values()),'branches':len(branches),'alternative_bytes':alternative.stat().st_size,'ast_path':witness['path']})
    print(json.dumps(records[-1]),flush=True)
(OUT/'common-gamma-witnesses.json').write_text(json.dumps(records,indent=2)+'\n')
# Remove only the superseded scratch inventories from the initial plus-only
# parser. The immutable captured payloads and all current signed terms remain.
for pattern in ['c?-orientation58-raw-term-*.atom','c?-orientation58-top-factor-inventory.json']:
    for path in OUT.glob(pattern):path.unlink()

raw_directory=OUT/'c3-orientation58-raw_pre_algebra-common-gamma-witness'
plain_directory=OUT/'c3-orientation58-pre_network-common-gamma-witness'
checks=[]
for name in ['common-gamma-product.atom','original-complete-sum.atom','original-complete-enclosing-term.atom']:
    a=(raw_directory/name).read_text();b=(plain_directory/name).read_text()
    assert a==re.sub(r'(?:[A-Za-z_]\w*::)+','',b)
    checks.append({'file':name,'raw_sha256':hashlib.sha256(a.encode()).hexdigest(),'plain_sha256':hashlib.sha256(b.encode()).hexdigest(),'plain_after_removing_namespace_prefixes_exactly_equals_raw':True})
(OUT/'attachment-witness-namespace-crosscheck.json').write_text(json.dumps({'checks':checks,'operation':'Remove only qualified symbol namespace prefixes from the fully qualified pre-network copy, for comparison; captured source files remain unchanged.','scope':'This establishes the complete selected UV subexpression and its complete enclosing term have the same text grouping at both capture hooks. It does not merge distinct namespaces within the proof; the pre-network factorization proof retains them.'},indent=2)+'\n')

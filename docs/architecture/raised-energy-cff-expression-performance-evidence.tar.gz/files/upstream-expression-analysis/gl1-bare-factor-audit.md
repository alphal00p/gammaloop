# GL1 bare-factor comparison and source ordering

The saved C1 and C3 GL1 graphs are byte-identical. Both contain the `V_36`
three-gluon vertex: the actual saved model identifies its particles as
`[g, g, g]`, Lorentz structure `VVV1`, and coupling `GC_10`. The other three
vertices are quark-gluon vertices on the up-quark triangle.

The complete bare contribution is the unique signed top-level term without
`mUV` and with all physical `OSE(2..6)` energies. Exact captured terms are in
`c1-gl1-complete-bare-signed.atom` and `c3-gl1-complete-bare-signed.atom`.
The audit preserves their coefficients, numerator factors, selectors and full
denominator expressions; it does not expand either numerator.

C1 has one product of three compact slashed-momentum factors, the intact
six-term three-gluon vertex sum and three quark-gluon vertex gammas, multiplying
a scalar sum of 18 theta-selected CFF weights over a common denominator.

C3 has a sum of 18 `sigma(id)` branches. Each branch contains three intact
two-term on-shell vector factors, their three explicit edge-slot gamma factors,
the three same quark-gluon vertex gammas, and an intact six-term three-gluon
vertex sum. The three-gluon sum is therefore repeated under the orientation
sum, with the time components specialized to that branch. It has not been
distributed into separate products with the quark numerator.

The four resulting three-gluon variants differ only in the signs of `OSE(5)`
and `OSE(6)`:

| Signs on edges 5, 6 | C3 selector IDs |
|---|---|
| `+, +` | 0, 1, 2, 3, 4, 5 |
| `-, +` | 6, 7, 8 |
| `+, -` | 9, 10, 11 |
| `-, -` | 12, 13, 14, 15, 16, 17 |

Every variant was compared against C1's complete vertex factor after replacing
only these signs and allowing local signed-term reordering. Every comparison
passed. No tensor term was dropped or expanded. Three fermionic signs were
read independently from the three explicit vector factors in each C3 branch.
Together, the complete 18 five-edge sign vectors match C1's 18 selector-support
rows exactly, with one branch per sector. The JSON preserves the complete
32-row support table, without claiming independent runtime catalog decoding.

C1's coefficient is `3/8192 * GC_10 * GC_11^3`. Every C3 branch has inner
coefficient `-i/16384 * GC_10 * GC_11^3` and the bare contribution has outer
factor `6i`, yielding the same coefficient. All scalar CFF expressions are
preserved in the audit; full rational equivalence of their differing denominator
representations is not asserted here.

The source also identifies the compact-slash versus explicit-vector boundary:

- C1 `uv/approx/final_integrand.rs:130–143` multiplies the residual numerator,
  collects factors, simplifies metrics/color and calls `expand_dots`.
  `uv/hedge_poset.rs:1256–1262` splits `Q(edge,mink)` into spatial and temporal
  parts later, after the final-integrand aggregation.
- C3 `uv/approx/final_integrand.rs:109–121` first maps the residual numerator
  per residue key, materializes the selector sum, then simplifies it.
  `direct_3d/branches.rs:205–211` maps and multiplies the factor per key;
  `uv/approx/mod.rs:389–393` applies those replacements; and
  `cff/expression.rs:169–172` replaces the full vector by `Q3 + energy*delta`.
- `simplify_metrics` disables rank-one compacting in both revisions. However,
  `expand_dots` calls `to_dots` (`idenso/shorthands/metric.rs:451–454`), which
  explicitly enables rank-one compacting (`schoonschip/api.rs:298–300`). The
  relevant rule matches a tensor times a rank-one function and contracts it
  into a compact argument (`schoonschip/with_settings.rs:199–210`). It does not
  distribute a tensor across an additive vector factor.

Thus this rule encounters unsplit `Q` in C1 and an existing vector sum in C3.
The ordering explains the recorded compact-slash sum versus explicit
`gamma * (Q3 ± E delta)` placement. C3 does not need to pull a gamma factor out
of a pre-existing local sum to produce the observed result. The four relevant
Idenso rule/API files are byte-identical between these C1 and C3 snapshots;
changed call ordering and inputs are the distinguishing boundary.

The JSON includes absolute source paths, line numbers and hashes in the
immutable diagnostic workspaces, plus exact logfile provenance. All inspected
inputs were rehashed unchanged. This is a structural/source attribution, not
a runtime or allocation attribution. No workloads, builds, algebra-engine
runs, production edits or numerator expansion were performed.

# C6–C7 analytic color input boundary

The measured immediate GL1 analytic-parser error first occurs at C7 and also occurs at C8. C6's parser-path introduction does not prove that same C6 failure: its native run ended as MONITOR_FAILURE when the ps snapshot exceeded its deadline at roughly 856 seconds, followed by cleanup. That is not an analytic-parser rejection or a completed timing measurement. The corrected, separately limited input-boundary diagnostic is recorded under `diagnostics/c6-gl1-upstream-boundaries/run-02`; it does not replace the native observation. The original run-01 logging setup was invalid and explicitly stopped. Terminal prefix and diagnostic outcomes must be reported separately.

Pins: C6 `8e4e4664f3f9303760eb18d7972b91ff867b12ea`, C7 `6d7a9220129c0fac37bdc0e04ebefccb1688c7be`, C8 `01982f688b6810d5152f0317713db412ae7ea794`.

## Changed input before the unchanged parser

C7 adds `.color_simplify()` to `crates/gammalooprs/src/uv/approx/local_4d.rs:1595`, after obtaining the reduced numerator and converting Minkowski dimensions, before division by its denominators and Taylor expansion. C6's counterpart at lines 787–795 has no such color simplification. The corresponding Numerator operation calls Idenso `simplify_color()` (numerator/mod.rs:910–915).

The existing Idenso rule in `crates/idenso/src/color/simplify.rs:317–328` transforms the complete open three-generator trace into a symmetric trace plus `i/2 * idx(2,rep) * f(a,b,c)`. Lines 1523–1528 build the symmetric trace with `trace_sym`. This is precisely the two-color-summand shape reported by the C8 error. It is a legitimate tensor sum with three exposed adjoint slots, not a scalar-plus-tensor mathematical inconsistency.

C7 also removes the local Taylor Dirac pipeline. C6 local_4d.rs:866–911 collected gamma chains, compacted rank-one vectors, collected traces/color, simplified gamma algebra and converted to dots before returning the local Taylor result. C7 local_4d.rs:1671–1674 returns only `evaluated.simplify_metrics()`, explicitly deferring Dirac algebra to integrated::simplify. This is a second input change: the analytic simplifier can now receive unresolved spin factors along with the early simplified open-color trace.

`crates/gammalooprs/src/uv/approx/integrated.rs` is byte-identical C6→C7. Its `simplify` first tests for gamma or trace at lines 168–169; only then does it protect scalar spectators and invoke the symbolic parser at 207–219, with full Schoonschip, trace=false, chain=true. The run method invokes simplify at 337 before the backend integrate call at 343. Thus the reported error occurs before Vakint evaluation. C6 may have preclosed spin algebra or a different color form before this conditional parser, while C7 deliberately feeds the less reduced numerator. This is source-supported reachability reasoning. The native prefix measurements establish C7/C8 as the observed immediate failure onset. The corrected C6 diagnostic captures complete local and integrated collection payloads, but it does not prove their exact owner/caller correspondence or capture an identity-matched C6/C7 parser-entry pair; see `c6-boundary-trace-run02-snapshot01/analysis.md`.

The complete Idenso, Spenso, Spenso-HEP and Spenso macro crate diffs C6→C8 are empty. The parser code's presence and the form/reachability of its input are therefore distinct attribution axes. C7's other early color calls in final_integrand/direct_3d concern later or other routes; local_4d::grow is the pertinent upstream call for this analytic integration path.

## Superseded invalid logging recipe retained as setup evidence

**Do not use the selectors in this section.** The original recipe below mixed routed JSON payload names (`res`/`expr`) with raw tracing metadata fields. The `debug_tags!` macro emits `display.res`/`file.res` or `display.expr`/`file.expr`; routed logfile names appear only afterward. These presence guards therefore captured no payloads. Dotted metadata identifiers are also unsupported by this revision's filter grammar. Run-01 was explicitly terminated as a diagnostic setup failure; its raw termination receipt and explanatory sidecar are preserved.

The valid replacement is `diagnostics/c6-gl1-upstream-boundaries/recipe-v2.json` with `card-v2.toml`, using existing boolean tags and a fresh run-02 directory. The actual 43-payload capture and source-qualified conclusions are in `c6-boundary-trace-run02-snapshot01/analysis.md`. The hook locations and routing observations below remain useful source evidence; their claims that the listed selectors emit payloads were the original setup error, not successful validation.

The remainder of this section preserves that **invalid, superseded proposal** verbatim as setup evidence:

Keep the native card's physics settings and display logging. Add only the following to the existing logfile directive:

```
gammalooprs::uv::approx::local_4d[{series,res}]=debug,gammalooprs::uv::approx::integrated[{collect,expr,!profile}]=debug
```

The local selector emits two namespace-preserving complete expressions per Taylor operation: `Series expanded` (C6 local_4d.rs:861) and `Evaluated at t = 1` (864). The latter is immediately before the local tensor/algebra chain at866. Decode JSON and retain its full `res` field after the single `expr:` header. It is the actual factored input, including denominator powers, before that work.

The integrated selector emits `After gamma chain collection` (integrated.rs:229), the first whole-expression log inside simplify. The `!profile` presence guard excludes the later similarly tagged collection logs. This event is AFTER the conditional symbolic parse/simple_execute/expand path and cannot be labeled its input.

There is no existing full-expression entry log immediately before integrated::simplify's parser. `compute_4d` passes the local result into Integrated::run without a payload event (approx/mod.rs:466–470). The last local `After dots` payload is subsequently negated and optionally UV-marked (local_4d.rs:1086–1094), combined over sectors (1099–1106), and has integrated_loop_scale replaced by1 (integrated.rs:333–337). That last local payload therefore cannot be substituted blindly for the complete integrated entry input.

If the goal is to identify which C6 local algebra operation fails to finish, add this existing selector:

```
gammalooprs::uv::approx::local_4d[{expr}]=debug
```

It emits the six complete local milestones: After gamma chain collection (870), After gamma schoonschip (879–882), After gamma collection (890–893), After gamma simplification (896–899), After Schoonschip net (901–904), and After dots (906–909). An emitted payload is the next operation's complete input; absence of the following milestone bounds the running operation. Payload formatting time is included, so use this to locate structure, not certify clean timings.

For all six integrated simplifier milestones, the existing static selectors are `[{collect,expr,!profile}]`, `[{start,expr}]` and `[{dots,expr}]` scoped to the integrated module. The start guard excludes later backend chainify logs. This is optional; the minimal pair above captures the requested first boundaries without backend dumps or network DOT files.

These hooks use LogMessage::log_file -> complete to_plain_string (`gammaloop-tracing-filter/src/log_message.rs:36–43`), preserving namespaces. Field-presence guards are checked at event metadata level. A later separately labeled diagnostic observation limit may stop the workload after 1200 seconds; that would be a diagnostic timeout, not a native failure, and missing later payloads would remain incomplete coverage. No numerical disk-size bound is justified before capture. No production logging or workload was added or executed in this source review.

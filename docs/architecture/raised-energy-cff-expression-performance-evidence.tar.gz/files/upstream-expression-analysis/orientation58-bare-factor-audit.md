# Attached workload: complete bare-factor comparison

The actual raw pre-algebra C1 and C3 bare contributions both retain a product
of six fermion numerator factors and six common vertex-gamma factors. This pair
does **not** show the graph numerator being expanded across its six two-term
vector factors, or the shared vertex product being lost. Every numerator factor,
the complete denominator, coefficient and selectors have been accounted for.

The attached graph contains two external photons, a four-vertex down-quark
loop and a gluon exchange dressed by a two-vertex down-quark bubble. It has no
three-gluon vertex. It therefore cannot establish how a three-gluon vertex sum
is preserved; the separately captured GL1 workload is needed for that question.

The complete bare term was selected from the raw signed sum by its physical
`OSE(2)` through `OSE(9)` dependence, absence of `mUV`, and full denominator,
not by term position. The formatter uses binary subtraction; splitting on
`+` alone incorrectly joins the bare term to UV contributions. The signed
split reproduces each original payload exactly by concatenation.

Both bare terms have coefficient `i/65536 * GC_1^2 * GC_11^4`,
`tree_denoms(1)`, and the exact same denominator:

```text
𝜋^9*(-Q(0,cind(0))+OSE(2)+OSE(5))*(-Q(0,cind(0))+OSE(3)+OSE(4))*(-Q(0,cind(0))+OSE(2)+OSE(4)+OSE(6))*(-Q(0,cind(0))+OSE(2)+OSE(4)+OSE(7))*(-Q(0,cind(0))+OSE(2)+OSE(4)+OSE(8)+OSE(9))*OSE(2)*OSE(3)*OSE(4)*OSE(5)*OSE(6)*OSE(7)*OSE(8)*OSE(9)
```

C1 retains each slashed propagator as one compact two-term factor. For edge 2:

```text
(σ(2)*OSE(2)*gamma(bis(4,hedge(3)),bis(4,hedge(2)),δ(cind(0),mink(4)))+gamma(bis(4,hedge(3)),bis(4,hedge(2)),Q3(2,mink(4))))
```

C3 writes its explicit edge-slot gamma and keeps the vector sum as one factor:

```text
gamma(bis(4,hedge(3)),bis(4,hedge(2)),mink(4,edge(2,1))) * (Q3(2,mink(4,edge(2,1)))+δ(cind(0),mink(4,edge(2,1)))*OSE(2))
```

The same correspondence holds for edges 3, 4, 5, 8 and 9, with selected signs
`[+, +, -, -, +, -]` in edge order `[2, 3, 4, 5, 8, 9]`. The six vertex-gamma
factors have the exact same spinor endpoints and Lorentz indices in both terms.
The JSON lists all six compact factors, all six explicit gamma/vector pairs,
and the complete shared vertex factors without abbreviation.

C1's complete selector remains
`theta(sigma2) theta(sigma3) theta(sigma6) theta(sigma7) theta(sigma8)
 theta(-sigma4) theta(-sigma5) theta(-sigma9)`; C3's is `sigma(58)`.
The two raw spellings (`σ` and `sigma`) are distinct and preserved in the JSON.
Their runtime catalog association is not independently proved in this audit.
C1's signed bare payload has 1,447 characters; C3's has 1,351 including its
leading binary `+`. These are strings, not Atom storage or an allocation measure.

Exact raw payload provenance:

- C1: `/tmp/raised-energy-expression-perf-20260914/controls/measurements/c1/run-orientation58_expression_boundaries-01/state/logs/gammalog-2026-09-14T20-10-12.121Z.jsonl`, JSONL line 299, field `orientation_parametric_integrand`; source event `crates/gammalooprs/src/integrands/process/amplitude/mod.rs:193`. Complete extracted bare term: `c1-orientation58-complete-bare-signed.atom`.
- C3: `/tmp/raised-energy-expression-perf-20260914/controls/measurements/c3/run-orientation58_expression_boundaries-01/state/logs/gammalog-2026-09-14T20-10-57.742Z.jsonl`, JSONL line 186, field `orientation_parametric_integrand`; source event `crates/gammalooprs/src/integrands/process/amplitude/mod.rs:222`. Complete extracted bare term: `c3-orientation58-complete-bare-signed.atom`.

All inspected input files were rehashed unchanged. No symbolic expansion,
algebra engine, finite-component contraction, workload, build or source edit
was performed. Namespaces are hidden by these raw log displays, so equality
claims concern the complete recorded spellings and their documented compact
notation correspondence. Proper UV contributions, numerical equivalence and
performance attribution are outside this bounded bare-factor audit.

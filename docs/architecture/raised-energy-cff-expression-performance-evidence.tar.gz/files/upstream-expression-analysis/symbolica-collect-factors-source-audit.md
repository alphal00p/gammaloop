# Locked Symbolica `collect_factors` audit

The captured C3 build locks `alphal00p/symbolica` revision `4d0a833eb8e059d1f95bdae5abed2559830b235f` (version 2.2.0), not an unspecified latest development checkout. Both the diagnostic workspace's Cargo.lock and the inspected dependency checkout HEAD agree.

**The existing method would recover the common gamma product, but a whole-integrand call also combines denominator factors. It is not a drop-in implementation of the denominator-preserving witness.**

## Recursion and factor identity

The public API in `src/atom/core.rs:278–289` documents collection from nested sums and forwards to `src/collect.rs:1193–1223`. The implementation recursively visits each Add summand (1231–1237), each Mul factor (1302–1310), and each Pow base (1313–1345). Thus it is not confined to a root sum. Num, Var and entire Fun atoms are leaves (1228–1229); it does not descend into function arguments.

The witness's eight fully qualified gamma atoms are identical complete Fun keys in every summand. Their shared exponent is one, so the recursive Add procedure extracts each into the factor map. This predicts extraction of `G` from the existing C3 input. The result need not be exactly our minimal `G*(R0+R1+R2)`: the method recursively transforms other sums and extracts every eligible factor as well. It also does not perform the tensor compacting that would change explicit `gamma * (Q3+E*delta)` into compact slash notation.

## Negative powers combine denominator topologies

The Add procedure takes the minimum factor exponent across summands (`collect.rs:1243–1248`). For a factor missing in any summand it compares with zero (1255–1259), then subtracts the chosen exponent from every summand, inserting a missing factor with the opposite power (1262–1266). Integer powers, including negative ones, multiply the collected exponents (1319–1322).

Consequently the following behavior follows directly from those source operations; it was not evaluated in Symbolica during this task:

```
G*A/D1 + G*B/D2
  -> G * D1^(-1) * D2^(-1) * (A*D2 + B*D1)
```

For `D1`, the powers are `-1` and implicit `0`, hence the extracted power is `-1`. The second remainder gains `D1`. The same argument extracts `D2^(-1)` and adds `D2` to the first remainder. `D1` and `D2` can themselves be intact different additive denominator expressions. Even without expanding their products, this creates a common denominator and puts denominator factors into the numerator.

The routine constructs products and sums and normalizes them; this implementation does not call polynomial `expand`, `together`, `cancel` or a polynomial GCD. Absence of those calls does not make it denominator-preserving: the signed-exponent rule already performs the combination above. C3's `final_integrand.rs:288–289` comment explicitly intends to preserve the sum of separate denominator topologies, so restoring the old unconditional `collect_factors()` there would go beyond the exact gamma-only witness and oppose that representation constraint.

## Residue-map ownership

The function treats `sigma(k)` as an opaque Fun atom. It does not equate different IDs, inspect the residue key, or apply energy maps. Thus it preserves the symbolic weighted sum's value; it does not reinterpret a source map. It has no GammaLoop ownership metadata, however, and may pull identical factors across materialized selector branches and combine their denominators. Calling it before materialization on each key would keep keys separate, but still combines different denominator terms within each key.

The source-supported distinction is therefore: recovering the same common `G` is possible with this existing method; preserving all separate denominator terms and branch grouping with a global call is not guaranteed and is contradicted by the negative-power rule. Our saved text witness removes only an already-identical positive gamma product and preserves every denominator inside its original remainder. Any diagnostic comparison between those two operations should remain separate from a production change and from the measured prefix sweep.

This was a source-only inspection. No Symbolica execution, tensor workload, production edit, denominator combination on the real payload, or performance claim was made. The JSON records exact files, lines and hashes.

# C3 saved-artifact addendum

C3 is the first sampled stack revision with a changed local sunrise expression
export. Main, C1 and C2 have identical complete values at all eight forest
nodes; none of C3's eight `num` values equals main's. The GL0 graph DOT,
forest DOT, node identity set and every recorded forest/residue/term/projector
metadata field remain exactly equal. These are comparisons of completed saved
artifacts, without new workload execution or symbolic algebra.

| Node | Main = C1 = C2 UTF-8 bytes | C3 UTF-8 bytes | C8 UTF-8 bytes |
|---|---:|---:|---:|
| 0 `∅` | 536 | 1,416 | 1,397 |
| 1 `{y}` | 1,399 | 4,386 | 4,379 |
| 2 `{p}` | 1,399 | 4,386 | 4,379 |
| 3 `{F}` | 6,961 | 18,975 | 18,978 |
| 4 `{11}` | 23,573 | 53,954 | 53,899 |
| 5 `{y} · {11}` | 6,960 | 32,387 | 32,416 |
| 6 `{p} · {11}` | 6,960 | 32,387 | 32,416 |
| 7 `{F} · {11}` | 41,012 | 78,233 | 78,270 |
| Total | 88,800 | 226,124 | 226,134 |

The C3 bare node is a product of an outer `1/16 * pi^(-6)` and a sum of two
mapped numerator products, selected by `three_dimensional_reps::sigma(0)` and
`three_dimensional_reps::sigma(1)`. Each inner branch carries `-i/1024 * pi^(-6)`,
so the written factors multiply to `-i/16384 * pi^(-12)` per branch: native
main's normalization before the C5 phase correction. C8 has `-i/256 * pi^(-6)`
per branch. No normalization was applied to these saved artifacts.

C3 therefore establishes a representation boundary already before C5 or C8;
it does not establish a measured time, memory or allocation regression. These
numbers are UTF-8 lengths of decoded `num` strings, not native Atom storage or
process RSS. Complete physical or algebraic equivalence is outside this
addendum. The JSON preserves exact bare values, equality predicates and file
hashes. All 44 inspected input files were rehashed unchanged.

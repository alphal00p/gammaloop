"""Bounded text-AST comparison of completed main/C8 bare exports; no physics execution."""
from pathlib import Path
import hashlib
import itertools
import json
import re

BASE = Path('/tmp/raised-energy-expression-perf-20260914')
REL = Path('state/processes/amplitudes/quark_sunrise/2L')
NODE = Path('GL0_nodes/forest_000/node_000_key_term_000_all_none.dot')


def attr(path, name):
    lines = [line.strip() for line in path.read_text().splitlines()
             if line.strip().startswith(name + ' = ')]
    assert len(lines) == 1
    return json.loads(lines[0].removeprefix(name + ' = ').removesuffix(';'))


def split_top(text, separator):
    depth = 0
    start = 0
    result = []
    for index, char in enumerate(text):
        if char == '(':
            depth += 1
        elif char == ')':
            depth -= 1
            assert depth >= 0
        elif char == separator and depth == 0:
            result.append(text[start:index])
            start = index + 1
    assert depth == 0
    result.append(text[start:])
    return result


def unparen(text):
    while text.startswith('(') and text.endswith(')'):
        depth = 0
        for index, char in enumerate(text):
            depth += (char == '(') - (char == ')')
            if depth == 0:
                break
        if index != len(text) - 1:
            break
        text = text[1:-1]
    return text


def factor_tree(text):
    """Only ignore Add/Mul order and redundant outer parens; do not distribute."""
    text = unparen(text)
    for separator, kind in [('+', 'add'), ('*', 'mul')]:
        parts = split_top(text, separator)
        if len(parts) > 1:
            return (kind, tuple(sorted(factor_tree(part) for part in parts)))
    return ('leaf', text)


runs = {label: BASE / 'measurements' / label / 'run-sunrise-local-01'
        for label in ['main-current', 'c8']}
nodes = {label: run / REL / NODE for label, run in runs.items()}
graphs = {label: run / REL / 'GL0.dot' for label, run in runs.items()}
nums = {label: attr(path, 'num') for label, path in nodes.items()}
assert graphs['main-current'].read_bytes() == graphs['c8'].read_bytes()
for name in ['forest_node_key', 'forest_residue_index', 'overall_factor',
             'overall_factor_evaluated', 'projector']:
    assert attr(nodes['main-current'], name) == attr(nodes['c8'], name)
models = {}
for label, run in runs.items():
    model = json.loads((run / 'state/model.json').read_text())
    models[label] = {
        field: [record for record in model[field]
                if record['particle' if field == 'propagators' else 'name']
                in {'V_135', 'GC_11', 'FFV1', 'g', 'u', 'u~', 'ZERO', 'G', 'aS'}]
        for field in ['vertex_rules', 'couplings', 'lorentz_structures',
                      'particles', 'propagators', 'parameters']
    }
assert models['main-current'] == models['c8']

main_factors = split_top(nums['main-current'], '*')
selectors = [factor for factor in main_factors if 'θ(' in factor]
assert len(selectors) == 1
expected_selectors = ('θ(σ(0))*θ(-1*σ(1))*θ(-1*σ(2))'
                      '+θ(-1*σ(0))*θ(σ(1))*θ(σ(2))')
assert factor_tree(selectors[0]) == factor_tree(expected_selectors)
main_body = [factor for factor in main_factors if factor != selectors[0]]
assert main_body.count('-1𝑖/16384') == 1
assert main_body.count('𝜋^(-12)') == 1
main_body = [ {'-1𝑖/16384': '-1𝑖/256', '𝜋^(-12)': '𝜋^(-6)'}.get(x, x)
              for x in main_body ]

terms = split_top(nums['c8'], '+')
assert len(terms) == 2
branches = []
for term in terms:
    factors = split_top(term, '*')
    selector = [x for x in factors if 'three_dimensional_reps::sigma(' in x]
    assert len(selector) == 1
    match = re.fullmatch(r'three_dimensional_reps::sigma\(([01])\)', selector[0])
    assert match
    branch_id = int(match.group(1))
    # These sign associations are read from the actual term, then checked below.
    signs = [-1, 1] if branch_id == 0 else [1, -1]
    expected = list(main_body)
    for edge, sign in enumerate(signs):
        compact = f'Q({edge},spenso::mink(4))'
        slot = f'spenso::mink(4,edge({edge},1))'
        matches = [i for i, x in enumerate(expected) if compact in x]
        assert len(matches) == 1
        i = matches[0]
        assert expected[i].startswith('spenso::gamma(')
        expected[i] = expected[i].replace(compact, slot)
        temporal = f'OSE({edge})*spenso::δ(spenso::cind(0),{slot})'
        expected.append(f'(Q3({edge},{slot})+{"-1*" if sign < 0 else ""}{temporal})')
    actual = [factor for factor in factors if factor != selector[0]]
    expected_tree = sorted(factor_tree(x) for x in expected)
    actual_tree = sorted(factor_tree(x) for x in actual)
    assert expected_tree == actual_tree, (branch_id, expected, actual)
    branches.append({
        'sigma_id': branch_id,
        'temporal_coefficients_of_E0_E1': signs,
        'uniquely_corresponding_main_sign_branch': [-1,1,1] if branch_id == 0 else [1,-1,-1],
        'edge2_sign_source': 'unique main selector support; not directly present in C8 numerator',
        'normalized_main_factor_count': len(expected),
        'c8_nonselector_factor_count': len(actual),
        'complete_factor_tree_equality': True,
        'c8_nonselector_factors': actual,
        'factor_tree_sha256': hashlib.sha256(json.dumps(actual_tree).encode()).hexdigest(),
    })
assert sorted(x['sigma_id'] for x in branches) == [0,1]

truth_table=[]
for signs in itertools.product([-1,1], repeat=3):
    matching=[row['sigma_id'] for row in branches
              if row['uniquely_corresponding_main_sign_branch']==list(signs)]
    truth_table.append({'physical_signs':list(signs),'paired_sigma_ids':matching,
                        'selected_count':len(matching)})
assert sum(x['selected_count'] for x in truth_table)==2
inputs=[]
for label,run in runs.items():
    receipt=json.loads((run/'receipt.json').read_text())
    for path in [nodes[label],graphs[label],run/'state/model.json',run/'receipt.json']:
        inputs.append({'label':label,'revision':receipt['revision'],'path':str(path),
                       'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
                       'bytes':path.stat().st_size})
record={
    'status':'PASS_FACTORIZED_BARE_PAIR',
    'scope':'Actual main/C8 empty-forest uncut GL0 numerator factors. Exact text-AST Add/Mul-order comparison after two compact-vector materializations, per-branch E substitutions, selector pairing, and known 64*pi^6 normalization. No numerator distribution, library algebra, numerical evaluation, runtime map-catalog decoding, or workload run.',
    'inputs':inputs,
    'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'graph_dot_byte_identical':True,
    'selected_saved_model_records_equal':True,
    'selected_saved_model_records':models['main-current'],
    'normalization_main_to_c8':'64*pi^6',
    'numeric_coefficient_main':'-i/16384',
    'numeric_coefficient_c8_each_branch':'-i/256',
    'pi_power_main':-12,'pi_power_c8':-6,
    'main_num_utf8_bytes':len(nums['main-current'].encode()),
    'c8_num_utf8_bytes':len(nums['c8'].encode()),
    'byte_count_scope':'UTF-8 serialized num attribute lengths, not native Atom storage, heap allocation, or peak RSS.',
    'branches':branches,'truth_table':truth_table,
    'quoted_old_shape_difference':'The userquoted external factor 4 multiplying terms with -i/1024 is absorbed in the actual C8 coefficients -i/256; actual C8 remains a sum of two indexed mapped numerator products.',
    'analytic_lorentz_contraction':'Each of the matched physical branch factors contracts to 8*(E0*E1+dot_E(vecq0,vecq1)); this is the analytic Clifford-identity derivation from the exact matched factors, not an executed library result.',
    'remaining_limits':['C8 runtime edge2 direction cannot be independently read from this numerator; direction pairing is induced by actual main support and C8 E0/E1 factors.', 'No proper UV node, integrated addback, full final integrand, numerical evaluator, or C3 runtime output compared.', 'Representation equality does not assign a runtime or memory regression to C3 or any algebra stage.'],
}
output=BASE/'sunrise-main-c8-bare-pair.json'
output.write_text(json.dumps(record,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'status':record['status'],'output':str(output),
                  'sha256':hashlib.sha256(output.read_bytes()).hexdigest(),
                  'main_num_utf8_bytes':record['main_num_utf8_bytes'],
                  'c8_num_utf8_bytes':record['c8_num_utf8_bytes'],
                  'branch_ids':[x['sigma_id'] for x in branches]}))

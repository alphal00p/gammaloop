#!/usr/bin/env python3
"""Summarize recorded measurements without executing builds or physics workloads."""
import collections
import csv
import datetime
import hashlib
import io
import json
from pathlib import Path
import re
import tomllib

BASE = Path('/tmp/raised-energy-expression-perf-20260914')
CARDS = ['g_gl1_integrated', 'sunrise_integrated', 'sunrise_local_export',
         'orientation58_muv', 'orientation58_muv_sparse_atom_aware']


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def write(path, text):
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(text)
    temporary.replace(path)


def seconds(value):
    return value['secs'] + value['nanos'] / 1_000_000_000


def stage_data(receipt, problems):
    summaries, traces, grouped = [], [], collections.defaultdict(list)
    for item in receipt.get('generation_summaries', []):
        path = Path(item['path'])
        if not path.exists() or sha(path) != item['sha256']:
            problems.append('Missing or changed generation summary: ' + str(path))
            continue
        value = json.loads(path.read_text())
        reports = []
        for report in value.get('reports', []):
            stats = report.get('stats', {})
            reports.append(dict(identity={k: v for k, v in report.items() if k != 'stats'},
                                seconds={k: seconds(v) for k, v in stats.items()
                                         if isinstance(v, dict) and set(v) == {'secs', 'nanos'}},
                                evaluator_count=stats.get('evaluator_count')))
        summaries.append(dict(path=str(path), sha256=item['sha256'],
                              internal_peak_ram_bytes=value.get('peak_ram_bytes'), reports=reports))
    for filename in receipt.get('trace_logs', []):
        path = Path(filename)
        if not path.exists():
            problems.append('Missing indexed trace: ' + filename)
            continue
        count, last, parse_errors = 0, None, []
        with path.open() as stream:
            for line_number, line in enumerate(stream, 1):
                try:
                    event = json.loads(line)
                except json.JSONDecodeError:
                    parse_errors.append(line_number)
                    continue
                count += 1
                name = event.get('stage')
                if not name:
                    continue
                metrics = {k: v for k, v in event.items()
                           if type(v) in (int, float) and
                           (k.endswith('_ms') or k.endswith('_bytes') or 'byte_size' in k
                            or k.endswith('_count'))}
                last = dict(stage=name, line=line_number, timestamp=event.get('timestamp'))
                grouped[name].append(dict(path=filename, line=line_number, metrics=metrics))
        if parse_errors:
            problems.append('Malformed trace JSON lines: ' + filename)
        traces.append(dict(path=filename, sha256=sha(path), event_count=count,
                           last_stage=last, malformed_line_numbers=parse_errors))
    stages = []
    for name, events in sorted(grouped.items()):
        values = collections.defaultdict(list)
        for event in events:
            for key, value in event['metrics'].items():
                values[key].append(value)
        stages.append(dict(stage=name, event_count=len(events),
                           metrics={key: dict(count=len(v), minimum=min(v), maximum=max(v),
                                              observation_sum=sum(v)) for key, v in values.items()},
                           first_location={k: events[0][k] for k in ('path', 'line')},
                           last_location={k: events[-1][k] for k in ('path', 'line')}))
    return summaries, traces, stages


def main():
    inventory_path = BASE / 'attachments/run-card-inventory.json'
    inventory = json.loads(inventory_path.read_text())
    revisions = json.loads((BASE / 'revisions.json').read_text())
    revision_order = {r['label']: n for n, r in enumerate(revisions)}
    runs, builds, collection_issues = [], [], []
    for path in sorted((BASE / 'measurements').glob('*/*/receipt.json')):
        try:
            receipt = json.loads(path.read_text())
        except json.JSONDecodeError:
            collection_issues.append('Receipt was incomplete while reading: ' + str(path))
            continue
        if receipt['action'] != 'run':
            builds.append(dict(label=receipt['label'], receipt=str(path), status=receipt['status'],
                               binary_sha256=receipt.get('binary_sha256'),
                               note='Build status is not runtime performance or live-process evidence.'))
            continue
        problems = []
        pending = receipt['status'] == 'STARTED'
        card = receipt.get('card', {})
        card_name = card.get('card')
        effective = path.parent / 'run.toml'
        settings = tomllib.loads(effective.read_text()) if effective.exists() else {}
        if settings and not pending and sha(effective) != receipt.get('effective_card_sha256'):
            problems.append('Effective card hash differs from receipt')
        label = {'main-current': 'main', 'main-base': 'oldmain'}.get(receipt['label'], receipt['label'])
        rev_inventory = inventory['revisions'][label]
        if receipt['revision'] != rev_inventory['commit']:
            problems.append('Receipt revision differs from inventory pin')
        for boundary in ('tracked_before', 'tracked_after'):
            if receipt['status'] != 'STARTED' and not receipt.get(boundary, {}).get('passed'):
                problems.append('Source audit not successful: ' + boundary)
        generation = settings.get('cli_settings', {}).get('global', {}).get('generation', {})
        evaluator = generation.get('evaluator', {})
        uv = generation.get('uv', {})
        explicit_strategy = evaluator.get('tensor_network_contraction_order')
        strategy = explicit_strategy or rev_inventory['default_contraction_order']
        mode = ('EXPLICIT_CONTROL' if card.get('classification') == 'ONE_SETTING_CONTROL_NOT_EXACT_CARD'
                else 'EXPLICIT_NATIVE' if explicit_strategy else 'NATIVE_DEFAULT')
        sampling = dict(graphs='summed', orientations='summed', lmb_multichanneling=False,
                        lmb_channels='summed', coordinate_system='spherical', mapping='linear', b=1.0)
        sampling.update(settings.get('default_runtime_settings', {}).get('sampling', {}))
        stage = next((s for s in receipt.get('stages', [])
                      if s.get('argv', [])[-2:] == ['run', 'generate']), {})
        summaries, traces, observations = stage_data(receipt, problems)
        stats = [report for summary in summaries for report in summary['reports']]
        saved_times = {field: sum(row['seconds'][field] for row in stats if field in row['seconds'])
                       for field in sorted({key for row in stats for key in row['seconds']})}
        stage_map = {s['stage']: s for s in observations}
        complete = receipt['status'] == stage.get('status') == 'PASS' and not problems
        metrics = stage_map.get('evaluator_stack_new_done', {}).get('metrics', {})
        parse_metrics = stage_map.get('evaluator_stack_parse_atom_done', {}).get('metrics', {})
        t_metrics = stage_map.get('local_3d_t_output', {}).get('metrics', {})
        stdout = path.parent / 'runtime/stdout.log'
        failure_hint = None
        if receipt['status'] not in ('PASS', 'STARTED') and stdout.exists():
            clean = re.sub(r'\x1b\[[0-9;]*m', '', stdout.read_text(errors='replace'))
            errors = [line.strip() for line in clean.splitlines()
                      if line.lstrip().startswith(('0:', 'error:', 'RAM watchdog:'))]
            failure_hint = errors[-1][:600] if errors else None
        runs.append(dict(
            label=receipt['label'], commit=receipt['revision'], tree=receipt['tree'],
            attempt=path.parent.name, card=card_name, card_classification=card.get('classification'),
            strategy_mode=mode, strategy=strategy, generate_integrated=uv.get('generate_integrated', True),
            do_algebra=evaluator.get('do_algebra', False), compile=evaluator.get('compile', False),
            sampling=sampling, status=receipt['status'],
            evidence_state='PENDING_FINAL_RECEIPT' if pending else 'TERMINAL_RECEIPT',
            exit_code=stage.get('exit_code'),
            completed_full_card_seconds=stage.get('wall_seconds') if complete else None,
            observed_elapsed_seconds=stage.get('wall_seconds'),
            watchdog_completion_seconds=stage.get('watchdog_seconds'),
            sampled_process_tree_rss_bytes=stage.get('peak_tree_rss_bytes'),
            sampled_process_tree_rss_decimal_gb=(stage['peak_tree_rss_bytes'] / 1e9
                                               if 'peak_tree_rss_bytes' in stage else None),
            completed_timing_eligible=complete, failure_hint=failure_hint,
            source_hashes=receipt.get('source_hashes', {}), binary_sha256=receipt.get('binary_sha256'),
            effective_card_sha256=receipt.get('effective_card_sha256'),
            original_card_sha256=card.get('sha256'), imported_graph_sha256=receipt.get('imported_graph_sha256', {}),
            receipt=str(path), receipt_sha256=sha(path), build_receipt=receipt.get('build_receipt'),
            build_receipt_sha256=receipt.get('build_receipt_sha256'),
            saved_generation_graph_count=len(stats), saved_generation_times_graph_sum_seconds=saved_times,
            trace_spenso_event_sum_seconds=(metrics['spenso_ms']['observation_sum'] / 1000 if 'spenso_ms' in metrics else None),
            trace_symbolica_event_sum_seconds=(metrics['symbolica_ms']['observation_sum'] / 1000 if 'symbolica_ms' in metrics else None),
            trace_parse_atom_result_max_bytes=parse_metrics.get('result_bytes', {}).get('maximum'),
            trace_local_t_output_max_bytes=t_metrics.get('byte_size', {}).get('maximum'),
            summaries=summaries, trace_files=traces, stage_observations=observations,
            evidence_issues=problems))
    runs.sort(key=lambda r: (revision_order[r['label']], CARDS.index(r['card']) if r['card'] in CARDS else 99, r['attempt']))
    matrix = []
    for revision in revisions:
        label = {'main-current': 'main', 'main-base': 'oldmain'}.get(revision['label'], revision['label'])
        choices = {r['card']: r for r in inventory['revisions'][label]['cards']}
        for card in CARDS:
            matching = [r for r in runs if r['label'] == revision['label'] and r['card'] == card]
            choice = choices[card]
            status = ('EXACT_UNSUPPORTED' if choice['classification'] == 'EXACT_UNSUPPORTED'
                      else 'RECORDED_ATTEMPTS' if matching else 'NOT_RUN')
            matrix.append(dict(label=revision['label'], card=card, status=status,
                               reason=choice.get('reason'), attempts=[r['receipt'] for r in matching]))
    output = dict(generated_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  aggregator_sha256=sha(__file__), inventory_sha256=sha(inventory_path),
                  recorded_runtime_attempts=len(runs),
                  runtime_status_counts=dict(collections.Counter(r['status'] for r in runs)),
                  eligible_completed_timings=sum(r['completed_timing_eligible'] for r in runs),
                  collection_issues=collection_issues, builds=builds, matrix=matrix, runs=runs,
                  interpretation=[
                      'Full-card wall time includes startup, import, generation and explicit export/save commands.',
                      'Only PASS with successful recorded source audits and verified indexed artifacts is a completed timing.',
                      'Failure/cap elapsed time is an observation until termination, not a completed performance result.',
                      'External process-tree RSS is sampled in decimal bytes/GB; saved internal peak_ram_bytes is a different metric.',
                      'Saved generation times are sums over reported graphs. Trace stage observations can be nested or cumulative; never sum across stage names to invent a total.',
                      'Trace stage fields named compile=true are tags, not evaluator settings. Actual compile setting is read from effective TOML.',
                      'Native contraction default switches at C3; explicit sparse controls are separate from exact intermediate_cost cards.',
                      'Card2/card3 preserve distinct sampling settings; their difference is not an isolated integrated-UV toggle.',
                      'STARTED receipts are incomplete evidence and do not prove a process is still live.'])
    write(BASE / 'measurements.json', json.dumps(output, indent=2) + '\n')
    fields = ['label', 'commit', 'tree', 'attempt', 'card', 'card_classification', 'strategy_mode', 'strategy',
              'generate_integrated', 'do_algebra', 'compile', 'status', 'evidence_state', 'exit_code', 'completed_timing_eligible',
              'completed_full_card_seconds', 'observed_elapsed_seconds', 'watchdog_completion_seconds',
              'sampled_process_tree_rss_bytes', 'saved_generation_graph_count', 'trace_spenso_event_sum_seconds',
              'trace_symbolica_event_sum_seconds', 'trace_parse_atom_result_max_bytes', 'trace_local_t_output_max_bytes',
              'binary_sha256', 'effective_card_sha256', 'original_card_sha256', 'receipt', 'receipt_sha256',
              'source_hashes', 'sampling', 'saved_generation_times_graph_sum_seconds', 'failure_hint', 'evidence_issues']
    buffer = io.StringIO()
    writer = csv.DictWriter(buffer, fieldnames=fields)
    writer.writeheader()
    for row in runs:
        writer.writerow({k: json.dumps(row[k], sort_keys=True) if isinstance(row[k], (dict, list)) else row[k]
                         for k in fields})
    write(BASE / 'measurements.csv', buffer.getvalue())
    buffer = io.StringIO()
    stage_fields = ['label', 'card', 'attempt', 'run_status', 'stage', 'event_count', 'metric',
                    'unit', 'count', 'minimum', 'maximum', 'observation_sum', 'first_location', 'last_location']
    writer = csv.DictWriter(buffer, fieldnames=stage_fields)
    writer.writeheader()
    for run in runs:
        for stage in run['stage_observations']:
            for metric, values in stage['metrics'].items():
                writer.writerow(dict(label=run['label'], card=run['card'], attempt=run['attempt'],
                                     run_status=run['status'], stage=stage['stage'], event_count=stage['event_count'],
                                     metric=metric, unit='milliseconds' if metric.endswith('_ms') else 'bytes' if 'byte' in metric else 'count',
                                     **values, first_location=json.dumps(stage['first_location']), last_location=json.dumps(stage['last_location'])))
    write(BASE / 'measurement-stages.csv', buffer.getvalue())
    lines = ['# Current recorded measurement matrix', '',
             f"Generated {output['generated_utc']}. {len(runs)} runtime attempts; "
             f"{output['eligible_completed_timings']} eligible completed timings. Statuses: "
             + ', '.join(f'{k}={v}' for k, v in output['runtime_status_counts'].items()) + '.', '',
             'Each cell is full-card elapsed seconds / sampled process-tree GB (decimal). Failed or capped cells '
             'report elapsed observation only; they are not completed timings. Multiple attempts remain listed.', '',
             '| Revision | g GL1 integrated | Sunrise integrated | Sunrise local export | Orientation58 exact intermediate | Orientation58 sparse control |',
             '|---|---|---|---|---|---|']
    for revision in revisions:
        cells = []
        for card in CARDS:
            entry = next(e for e in matrix if e['label'] == revision['label'] and e['card'] == card)
            rows = [r for r in runs if r['receipt'] in entry['attempts']]
            cells.append('; '.join(f"{r['status']} {r['observed_elapsed_seconds']:.3f}s / {r['sampled_process_tree_rss_decimal_gb']:.3f}GB"
                                   if r['observed_elapsed_seconds'] is not None else r['status'] for r in rows)
                         or entry['status'])
        lines.append('| ' + revision['label'] + ' | ' + ' | '.join(cells) + ' |')
    pending_rows = [r for r in runs if r['status'] == 'STARTED']
    if pending_rows:
        lines += ['', 'Pending final receipts (not terminal failures or proof of process liveness): ' +
                  '; '.join(r['label'] + ' / ' + r['attempt'] for r in pending_rows) + '. '
                  'A pending receipt without card metadata cannot yet populate its matrix cell.']
    lines += ['', 'Native-default rows use sparse_atom_aware through C2 and intermediate_cost from C3. '
              'The original attachment explicitly requires intermediate_cost; its unsupported old-revision cells '
              'remain visible alongside separately labeled sparse controls. Both main pins retain their own models/dependencies.', '',
              'Reported generation/evaluator stages:', '',
              '| Revision / attempt | Saved graph-generation sum (s) | Spenso (s) | Symbolica (s) | Timing source |',
              '|---|---:|---:|---:|---|']
    for row in runs:
        saved = row['saved_generation_times_graph_sum_seconds']
        vals = [saved.get('total_time'), saved.get('evaluator_spenso_time', row['trace_spenso_event_sum_seconds']),
                saved.get('evaluator_symbolica_time', row['trace_symbolica_event_sum_seconds'])]
        source = 'saved graph statistics' if saved else 'completed evaluator-stack log events' if any(v is not None for v in vals) else 'no completed stage summary'
        lines.append('| ' + row['label'] + ' / ' + row['attempt'] + ' | '
                     + ' | '.join('—' if v is None else f'{v:.6f}' for v in vals) + ' | ' + source + ' |')
    lines += ['', 'Graph-generation statistics, evaluator substage observations and full-command wall time have distinct scopes. '
              'Nested/cumulative trace stages in measurement-stages.csv must not be added together as independent work. '
              'Saved internal peak_ram_bytes is retained only in JSON; it is not mixed with sampled process-tree RSS.', '',
              'Source/model/lock/card/binary fingerprints and receipt links are in measurements.json and measurements.csv. '
              'No historical timing is imported. This Python aggregation reads recorded artifacts; it runs no physics workloads, builds, or tests.', '']
    write(BASE / 'measurement-matrix.md', '\n'.join(lines))
    print(json.dumps(dict(runtime_attempts=len(runs), statuses=output['runtime_status_counts'],
                          evidence_issues=sum(len(r['evidence_issues']) for r in runs), outputs=[
                              str(BASE / p) for p in ['measurements.json', 'measurements.csv', 'measurement-stages.csv', 'measurement-matrix.md']])) )


if __name__ == '__main__':
    main()

# Prepared post-sweep comparisons

Preparation is complete; no controlled workload has been launched. The plan has
13 sequential jobs: seven repetitions of unchanged primary cards/strategy
controls, followed by six changes of exactly one setting. No card changes its
primary logging. Native repeats retain the original card bytes and receive
separate `repeat_...` names in the controls inventory.

| Family | Cases | Purpose |
|---|---|---|
| Native card repeats | GL1 on main-current/C1/C3; attachment on C3 with intermediate_cost | Measure run variability at the observed transition |
| Sparse strategy repeats | Attachment on main-current/C1/C3 | Compare the common strategy and repeat C3's memory-cap outcome |
| One-setting perturbations | C3 GL1: sparse ordering, integrated UV off, all UV off | Separate ordering, integrated and local UV effects |
| One-setting perturbations | C3 attachment: UV off, algebra on | Isolate UV assembly and algebra before tensor evaluation |
| One-setting perturbation | C8 GL1: integrated UV off | Determine whether the final-tree failure requires integrated UV |

All 13 requested cases are retained. The C3 sparse repetition is useful despite
its earlier cap: it establishes whether that resource outcome repeats. The C8
local-only case addresses a distinct failure. No additional failing integrated
C8 repeat or unrelated strategy sweep is added.

Run the script without arguments to validate cards, declared deltas, native
binary/receipt hashes and fixed-workspace availability. This validation does not
launch workloads. After the primary sweep finishes, root may execute:

```sh
/tmp/raised-stack/python /tmp/raised-energy-expression-perf-20260914/controls/run-post-sweep.py --execute
```

Execution first inspects the recorded primary PID and start ticks through
`/proc`, rejecting a still-live original process even if paused. It also requires
`FINISHED_SWEEP` from `remaining-sweep-02/state.json` and verifies the preserved,
inspected first-controller monitor failure. It then holds the primary measurement lock throughout the
batch, rechecks the primary state, and uses the reviewed measurement driver's
separate controls lock and existing global heavy-process watchdog. There is no
waiting for the primary and no automatic restart or retry.

The script imports the hash-pinned reviewed `measure.py` and changes only its
output/inventory root and per-job fixed source workspace. It calls only the
existing `run` action. Full source/tree checks, source hashes, native copied
binary bindings, state-folder-only TOML rewriting, explicit logging override
removal, the 30-GB sampled process-tree cap, and failure classifications remain
in that driver. Known expression-dump/profile environment hooks are cleared;
there are no new diagnostic hooks in these timings.

Fixed sources are under `diagnostic-workspaces/{main-current,c1,c3,c8}`. Main
and C8 workspaces were created and fully materialized for this preparation;
C1/C3 were reused. All four trees and complete tracked files were audited, and
all four native binary files were freshly rehashed. No moving PREFIX checkout,
ROOT working-change edit, build or application run occurred during preparation.

The original inventory remains frozen. Seven repeat descriptors were added to
the separate controls inventory; all six perturbation cards were reused. The
plan pins each selected descriptor and native build receipt. Additional unrelated
control entries may be added later, but altering a selected descriptor fails
validation. Each actual driver receipt retains its inventory hash.

Attempt names and output directories are fixed in `post-sweep-plan.json`.
Execution refuses existing attempt directories. The batch receipt is
`controls/post-sweep-01/state.json`; ordinary driver receipts remain under
`controls/measurements/`. Program failures and memory caps are retained and the
next distinct case runs. Infrastructure or source-integrity failures stop the
batch and leave remaining cases unexecuted. A cap's elapsed observation is never
a completed generation timing. Repetitions and perturbations must remain
separate in the report, and each case must be compared with its named base card.

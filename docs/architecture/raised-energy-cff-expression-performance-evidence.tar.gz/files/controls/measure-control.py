#!/usr/bin/env python3
"""Reuse the reviewed measurement driver with a separate control inventory/output root."""
import fcntl
import importlib.util
from pathlib import Path
import sys

BASE = Path('/tmp/raised-energy-expression-perf-20260914')
# Prevent a control from overlapping a source checkout in the primary sweep.
# The root still prepares the pinned source before invoking this entry point.
lock = (BASE / 'measurement.lock').open('a')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
spec = importlib.util.spec_from_file_location('measure', BASE / 'measure.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
module.BASE = Path(__file__).resolve().parent
sys.exit(module.main())

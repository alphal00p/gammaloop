#!/usr/bin/env python3
"""Use pinned diagnostic workspaces and immutable binaries; the global watchdog serializes heavy work."""
import hashlib
import importlib.util
from pathlib import Path
import sys

BASE = Path('/tmp/raised-energy-expression-perf-20260914')
assert sys.argv[1] == 'run', 'This entry point only runs preserved binaries'
assert sys.argv[2] in ('c1', 'c3'), 'Use the prepared fixed source workspaces'
spec = importlib.util.spec_from_file_location('measure', BASE / 'measure.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
module.BASE = Path(__file__).resolve().parent
module.PREFIX = BASE / 'diagnostic-workspaces' / sys.argv[2]
assert module.PREFIX.is_dir(), 'Prepare and audit the fixed workspace first'
assert hashlib.sha256((BASE / 'measure.py').read_bytes()).hexdigest() == '6f6ca7cbb51f5b606b93da4e00fe42465f3a194bc5efaf6e492df737cafad4d9'
sys.exit(module.main())

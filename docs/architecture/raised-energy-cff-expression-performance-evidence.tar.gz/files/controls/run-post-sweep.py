#!/usr/bin/env python3
"""Validate or run the prepared post-sweep repetitions and one-setting controls."""
import argparse
import datetime
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import tomllib

BASE = Path('/tmp/raised-energy-expression-perf-20260914')
PLAN = BASE / 'controls/post-sweep-plan.json'
CLEAR_DIAGNOSTICS = ('GAMMALOOP_DUMP_EVALUATOR_PRE_NETWORK_PARSE',
                     'GAMMALOOP_STOP_AFTER_EVALUATOR_PRE_NETWORK_PARSE',
                     'SPENSO_NETWORK_PROFILE', 'SPENSO_NETWORK_PROFILE_VERBOSE',
                     'SPENSO_NETWORK_PROFILE_ATOM_BYTES')


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def save(path, value):
    temporary = path.with_suffix('.tmp')
    temporary.write_text(json.dumps(value, indent=2) + '\n')
    temporary.replace(path)


def require_finished_primary(plan):
    prior = plan['prior_primary_failure']
    assert sha(prior['path']) == prior['sha256'], 'Inspected primary failure record changed'
    inspected = json.loads(Path(prior['path']).read_text())
    assert inspected['status'] == 'INSPECTED_MONITOR_FAILURE_NOT_RETRIED'
    for path, expected in inspected['files'].items():
        assert sha(path) == expected, 'Original stopped-primary evidence changed'
    state = json.loads(Path(plan['primary_state']).read_text())
    proc = Path('/proc') / str(state['pid']) / 'stat'
    try:
        stat = proc.read_text().rsplit(')', 1)[1].split()
    except FileNotFoundError:
        stat = None
    if stat and stat[19] == state['proc_start_ticks'] and stat[0] != 'Z':
        raise RuntimeError('Primary sweep process is still live; no controlled job started')
    if state['status'] != 'FINISHED_SWEEP':
        raise RuntimeError('Primary sweep has not recorded completion; inspect it before controlled runs')
    return dict(path=plan['primary_state'], sha256=sha(plan['primary_state']),
                status=state['status'], recorded_pid=state['pid'],
                same_process_still_live=False)


def validate(plan):
    assert sha(plan['driver']) == plan['driver_sha256'], 'Reviewed driver changed'
    assert sha(plan['original_inventory']) == plan['original_inventory_sha256'], 'Original inventory changed'
    original = json.loads(Path(plan['original_inventory']).read_text())
    controls = json.loads(Path(plan['control_inventory']).read_text())
    assert controls['source_inventory_sha256'] == plan['original_inventory_sha256']
    checks, builds = [], {}
    for job in plan['jobs']:
        label = job['inventory_label']
        revision = job['revision']
        assert controls['revisions'][label]['commit'] == revision['commit']
        card = next(c for c in controls['revisions'][label]['cards'] if c['card'] == job['card'])
        assert card == job['card_descriptor'], 'Selected control descriptor changed'
        base = next(c for c in original['revisions'][label]['cards'] if c.get('path') == card['base_card'])
        assert sha(card['base_card']) == card['base_card_sha256'] == base['sha256']
        assert sha(card['path']) == card['sha256']
        expected = tomllib.loads(Path(card['base_card']).read_text())
        actual = tomllib.loads(Path(card['path']).read_text())
        delta = card['delta']
        if delta:
            parent = expected
            keys = delta['path'].split('.')
            for key in keys[:-1]:
                parent = parent[key]
            if delta['old'] == 'implicit intermediate_cost':
                assert keys[-1] not in parent
                assert original['revisions'][label]['default_contraction_order'] == 'intermediate_cost'
            else:
                assert parent[keys[-1]] == delta['old']
            parent[keys[-1]] = delta['new']
        assert expected == actual, 'Card differs beyond its declared delta'
        assert 'logfile_directive' not in delta.get('path', ''), 'Post-sweep jobs must retain primary logging'
        assert not card.get('required_environment'), 'Diagnostic environment is not a timing control'
        if job['family'] != 'one_setting_perturbation':
            assert delta == {} and card['sha256'] == card['base_card_sha256']
        build = job['native_build']
        if build['receipt'] not in builds:
            assert sha(build['receipt']) == build['receipt_sha256'], 'Native build receipt changed'
            receipt = json.loads(Path(build['receipt']).read_text())
            assert receipt['status'] == 'PASS' and receipt['revision'] == revision['commit'] and receipt['tree'] == revision['tree']
            assert receipt['binary'] == build['binary']
            assert sha(build['binary']) == build['binary_sha256'] == receipt['binary_sha256']
            builds[build['receipt']] = True
        assert Path(job['source_workspace']).is_dir(), 'Fixed source workspace is missing'
        checks.append(dict(label=job['label'], card=job['card'], family=job['family'], status='PASS'))
    return checks


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute', action='store_true', help='Run only after the primary sweep is terminal')
    args = parser.parse_args()
    plan = json.loads(PLAN.read_text())
    primary = require_finished_primary(plan) if args.execute else None
    lock = None
    if args.execute:
        lock = (BASE / 'measurement.lock').open('a')
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        primary = require_finished_primary(plan)
    checks = validate(plan)
    if not args.execute:
        print(json.dumps(dict(status='VALIDATED_NOT_EXECUTED', jobs=len(checks), checks=checks)), flush=True)
        return 0
    for job in plan['jobs']:
        out = BASE / 'controls/measurements' / job['label'] / ('run-' + job['attempt'])
        assert not out.exists(), 'A planned attempt already exists; refusing automatic rerun'
    output = BASE / 'controls/post-sweep-01'
    output.mkdir(exist_ok=False)
    state = dict(status='RUNNING', script_sha256=sha(__file__), plan_sha256=sha(PLAN),
                 control_inventory_sha256=sha(plan['control_inventory']), primary_completion=primary,
                 pid=os.getpid(), jobs_planned=len(plan['jobs']), completed=[], current=None,
                 cleared_diagnostic_environment_names=list(CLEAR_DIAGNOSTICS))
    for name in CLEAR_DIAGNOSTICS:
        os.environ.pop(name, None)
    spec = importlib.util.spec_from_file_location('reviewed_measurement_driver', plan['driver'])
    measure = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(measure)
    measure.BASE = BASE / 'controls'
    try:
        for job in plan['jobs']:
            require_finished_primary(plan)
            measure.PREFIX = Path(job['source_workspace'])
            argv = [plan['driver'], 'run', job['label'], '--attempt', job['attempt'],
                    '--card', job['card'], '--build-receipt', job['native_build']['receipt']]
            state['current'] = dict(order=job['order'], family=job['family'], argv=argv,
                                    source_workspace=job['source_workspace'])
            save(output / 'state.json', state)
            print(json.dumps(dict(starting=state['current'])), flush=True)
            sys.argv = argv
            code = measure.main()
            path = BASE / 'controls/measurements' / job['label'] / ('run-' + job['attempt']) / 'receipt.json'
            receipt = json.loads(path.read_text())
            result = dict(order=job['order'], family=job['family'], label=job['label'], card=job['card'],
                          status=receipt['status'], driver_exit_code=code, receipt=str(path), receipt_sha256=sha(path))
            state['completed'].append(result)
            save(output / 'state.json', state)
            print(json.dumps(dict(finished=result)), flush=True)
            assert receipt['revision'] == job['revision']['commit'] and receipt['tree'] == job['revision']['tree']
            if receipt['status'] not in ('PASS', 'CHILD_FAILURE', 'MEMORY_CAP'):
                raise RuntimeError('Infrastructure/source failure: remaining jobs stay unexecuted; inspect before continuing')
            # A program failure or memory cap is retained as its own result; it is neither retried nor credited as completion.
        state.update(status='COMPLETED_WITH_RECORDED_OUTCOMES', current=None)
    except BaseException as error:
        state.update(status='STOPPED', error=repr(error))
        raise
    finally:
        state['updated_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        save(output / 'state.json', state)
    print(json.dumps(dict(status=state['status'], state=str(output / 'state.json'))), flush=True)
    return 0


if __name__ == '__main__':
    sys.exit(main())

# Fresh repetitions and one-setting controls

Each job is compared with its pinned unchanged primary card. Times are individual observations, not confidence intervals. A failed/capped case has no completed wall time.

| # | Revision / card | Family | Status | Wall s | Primary s | RSS GB | Primary GB |
|---|---|---|---|---:|---:|---:|---:|
| 1 | main-current / repeat_g_gl1_integrated | native_card_repeat | PASS | 75.744 | 73.639 | 3.552 | 3.180 |
| 2 | c1 / repeat_g_gl1_integrated | native_card_repeat | PASS | 40.988 | 39.082 | 2.124 | 1.860 |
| 3 | c3 / repeat_g_gl1_integrated | native_card_repeat | PASS | 168.300 | 166.063 | 17.282 | 17.700 |
| 4 | main-current / repeat_orientation58_muv_sparse_atom_aware | sparse_strategy_repeat | PASS | 115.130 | 109.066 | 8.615 | 8.443 |
| 5 | c1 / repeat_orientation58_muv_sparse_atom_aware | sparse_strategy_repeat | PASS | 37.328 | 37.497 | 3.381 | 3.264 |
| 6 | c3 / repeat_orientation58_muv | native_card_repeat | PASS | 60.709 | 59.884 | 8.226 | 7.015 |
| 7 | c3 / repeat_orientation58_muv_sparse_atom_aware | sparse_strategy_repeat | MEMORY_CAP | — | — | 30.140 | 30.618 |
| 8 | c3 / g_gl1_integrated_sparse_control | one_setting_perturbation | PASS | 201.664 | 166.063 | 17.920 | 17.700 |
| 9 | c3 / g_gl1_local_only | one_setting_perturbation | PASS | 138.212 | 166.063 | 17.630 | 17.700 |
| 10 | c3 / g_gl1_no_uv | one_setting_perturbation | PASS | 1.315 | 166.063 | 0.062 | 17.700 |
| 11 | c3 / orientation58_no_uv | one_setting_perturbation | PASS | 0.887 | 59.884 | 0.039 | 7.015 |
| 12 | c3 / orientation58_algebra | one_setting_perturbation | PASS | 113.020 | 59.884 | 14.001 | 7.015 |
| 13 | c8 / g_gl1_local_only | one_setting_perturbation | PASS | 144.602 | — | 18.929 | 0.042 |

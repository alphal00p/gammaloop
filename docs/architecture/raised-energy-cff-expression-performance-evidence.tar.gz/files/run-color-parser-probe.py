"""Run the prepared native C8 color parser once after the controlled batch."""
from pathlib import Path
import datetime
import fcntl
import hashlib
import importlib.util
import json
import re

BASE = Path('/tmp/raised-energy-expression-perf-20260914')
PROBE = BASE / 'diagnostics/color-parser'
lock = (BASE / 'measurement.lock').open('a')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
for relative, expected_status in [
    ('remaining-sweep-02/state.json', 'FINISHED_SWEEP'),
    ('controls/post-sweep-01/state.json', 'COMPLETED_WITH_RECORDED_OUTCOMES'),
]:
    state = json.loads((BASE / relative).read_text())
    assert state['status'] == expected_status, relative
    if 'pid' in state and 'proc_start_ticks' in state:
        proc = Path('/proc') / str(state['pid']) / 'stat'
        try:
            actual = proc.read_text().rsplit(') ', 1)[1].split()
        except FileNotFoundError:
            actual = None
        assert not actual or actual[19] != state['proc_start_ticks'] or actual[0] == 'Z', relative
source = BASE / 'measure.py'
assert hashlib.sha256(source.read_bytes()).hexdigest() == '6f6ca7cbb51f5b606b93da4e00fe42465f3a194bc5efaf6e492df737cafad4d9'
spec = importlib.util.spec_from_file_location('measure', source)
measure = importlib.util.module_from_spec(spec)
spec.loader.exec_module(measure)
measure.PREFIX = BASE / 'diagnostic-workspaces/c8'
revision = next(r for r in json.loads((BASE / 'revisions.json').read_text()) if r['label'] == 'c8')
assert revision['commit'] == '01982f688b6810d5152f0317713db412ae7ea794'
assert revision['tree'] == '25383f6f2a815a62c90a11d2e920099465d5cbdd'
validation_path = PROBE / 'preparation-validation.json'
assert measure.digest(validation_path) == '495c16a6f9b49c25858f1c69181aaf6a364fe6387e2f29a96ec879f180272088'
validation = json.loads(validation_path.read_text())
build_path = PROBE / 'build-01/receipt.json'
build = json.loads(build_path.read_text())
binary = PROBE / 'build-01/gl1-color-parser-reproducer'
assert build['status'] == 'PASS' and build['revision'] == revision
assert build['validation_sha256'] == measure.digest(validation_path) and build['source'] == validation
assert build['launcher_sha256'] == measure.digest(BASE / 'build-scratch-probes.py') == 'ae30f3f96ac3d694c12be6005ba9387427c040f3070d84972cb10d3dc81ce094'
assert build['tracked_before']['passed'] and build['tracked_after']['passed']
assert len(build['stages']) == 4 and all(stage['status'] == 'PASS' for stage in build['stages'])
assert build['binary'] == str(binary) and build['binary_sha256'] == measure.digest(binary)
pins = {validation_path: measure.digest(validation_path), build_path: measure.digest(build_path),
        binary: build['binary_sha256'], measure.WATCH: measure.WATCH_SHA,
        source: measure.digest(source), BASE / 'build-scratch-probes.py': build['launcher_sha256'],
        measure.PREFIX / 'Cargo.lock': validation['native_lock_sha256'],
        PROBE / 'native-c8.Cargo.lock': validation['native_lock_sha256']}
for name, key in [('src/main.rs', 'source_sha256'), ('Cargo.toml', 'manifest_sha256'), ('Cargo.lock', 'lock_sha256')]:
    pins[PROBE / name] = validation[key]
for path, expected in pins.items():
    assert measure.digest(path) == expected, str(path)
out = PROBE / 'run-01'
out.mkdir(exist_ok=False)
record = {'status': 'STARTED', 'revision': revision, 'build_receipt': str(build_path),
          'binary': str(binary), 'launcher_sha256': measure.digest(__file__),
          'pinned_files': {str(path): digest for path, digest in pins.items()},
          'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'expected_exposed_slots': [{'representation': 'coad', 'dimension': 8, 'abstract_index': index} for index in [0, 8, 10]],
          'expected_independent_color_control': '6i',
          'expected_closed_values': {'symmetric_only': '0', 'ordered_trace': '6i',
                                     'projector_expanded_sum': '6i', 'native_decomposed_sum': '6i'}}
measure.write(out / 'receipt.json', record)
try:
    record['tracked_before'] = measure.audit(revision)
    assert record['tracked_before']['passed'], 'Native C8 source differs'
    runtime = measure.guarded(out, 'runtime', [str(binary)],
                              dict(GL_ALL_LOG_FILTER='off', RAYON_NUM_THREADS='8',
                                   RUST_MIN_STACK='134217728', INSTA_UPDATE='no', NEXTEST_RETRIES='0'))
    record['runtime'] = runtime
    record['status'] = runtime['status']
    events = [json.loads(line) for line in (out / 'runtime/memory.jsonl').read_text().splitlines()]
    complete = next((event for event in reversed(events) if event['event'] == 'complete'), None)
    if runtime['status'] != 'MEMORY_CAP' and any(event['event'] == 'watchdog_error' for event in events):
        record['status'] = 'MONITOR_FAILURE'
    elif runtime['status'] != 'MEMORY_CAP' and complete and complete['returncode'] != runtime['exit_code']:
        record['status'] = 'MONITOR_FAILURE'
    text = (out / 'runtime/stdout.log').read_text()
    cases = {name: {'status': 'NOT_REACHED', 'expected_closed_value': value}
             for name, value in record['expected_closed_values'].items()}
    current = None
    for line in text.splitlines():
        match = re.fullmatch(r'CASE ([a-z_]+): (.*)', line)
        if match:
            current = match[1]
            assert current in cases, 'Unknown probe case'
            cases[current].update(status='STARTED', expression=match[2])
        elif current and line.startswith('EXPOSED '):
            cases[current]['complete_exposed_and_expected_slots'] = line
        elif current and line.startswith('RESULT '):
            cases[current]['complete_result_and_expected_value'] = line
            flags = re.search(r'slots_match=(true|false); value_matches=(true|false)$', line)
            assert flags, 'Unexpected result syntax'
            slots_match, value_matches = [value == 'true' for value in flags.groups()]
            cases[current].update(status='PASS' if slots_match and value_matches else 'CONTRACT_MISMATCH',
                                  slots_match=slots_match, value_matches=value_matches)
        elif current and line.startswith('PARSE_ERROR '):
            cases[current].update(status='PARSE_ERROR', parse_error=line.removeprefix('PARSE_ERROR '))
    record['cases'] = cases
    record['independent_color_control_passed'] = any(case['status'] != 'NOT_REACHED' for case in cases.values())
    record['public_contract_status'] = ('PASS' if all(case['status'] == 'PASS' for case in cases.values()) else
                                        'OBSERVED_CONTRACT_FAILURE' if all(case['status'] in ['PASS', 'PARSE_ERROR', 'CONTRACT_MISMATCH'] for case in cases.values()) else
                                        'INCOMPLETE_PROBE')
    if record['status'] == 'PASS' and record['public_contract_status'] != 'PASS':
        record['status'] = 'EVIDENCE_FAILURE'
    record['runtime_evidence'] = {name: measure.digest(out / 'runtime' / name)
                                  for name in ['command.json', 'result.json', 'stdout.log', 'memory.jsonl']}
except BaseException as error:
    record.update(prior_status=record['status'], status='LAUNCH_OR_EVIDENCE_FAILURE', error=repr(error))
finally:
    try:
        record['tracked_after'] = measure.audit(revision)
        assert record['tracked_after']['passed'], 'Native C8 source changed'
        for path, expected in pins.items():
            assert measure.digest(path) == expected, str(path)
    except BaseException as error:
        record.update(prior_status=record['status'], status='INPUT_INTEGRITY_FAILURE', integrity_error=repr(error))
    record['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    measure.write(out / 'receipt.json', record)
    print(json.dumps({'status': record['status'], 'receipt': str(out / 'receipt.json'),
                      'public_contract_status': record.get('public_contract_status')}), flush=True)
if record['status'] != 'PASS':
    raise SystemExit(1)

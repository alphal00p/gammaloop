# Resume only the unattempted primary tail

The first controller is terminal STOPPED. C6 GL1 ended with MONITOR_FAILURE:
the watchdog's process-list command exceeded its ten-second observation limit.
The recorded child and controller PIDs are absent. This failure remains an
incomplete generation result, and the first controller's receipt is preserved.
No manual kill or new observation timeout was applied.

`remaining-sweep-02-plan.json` contains exactly 13 previously unattempted jobs:
C6 attachment native and sparse runs; C7 check/build and five cards; main-base
check/build and four supported cards. Each build action invokes the existing
check then build stages. The unsupported exact main-base intermediate_cost card
remains explicit. C6's successful immutable native build is reused. C6 GL1 and
all other attempted runs are excluded; no automatic retry is introduced.

The new runner binds the inspected failure files, driver/watchdog fingerprints,
original inventory and revision pins. It verifies PREFIX's complete C6 tree and
files before the first new run. It then checks out only C7 and main-base in
PREFIX. All jobs retain the reviewed driver's source/binary/card/state checks,
original logging, four Cargo workers, eight Rayon threads and sampled 30-GB
process-tree cap. Jobs run sequentially. A new monitor or source failure stops
the controller. Program failures and memory caps remain separate recorded
outcomes and are never credited as completed generation timings.

The controller records its actual PID/start ticks and each current command in
`remaining-sweep-02/state.json`; it refuses existing attempt directories.
The source failure evidence is in `remaining-sweep-02-inspected-prerequisite.json`.
The original `remaining-sweep-01/state.json` remains unchanged.

The separate post-sweep plan now waits for the second controller's FINISHED_SWEEP
and absence of its original live process. Its gate additionally verifies the
first controller's inspected failure evidence and original receipt hashes.

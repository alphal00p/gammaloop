use std::collections::HashSet;

use idenso::{
    color::{ColorSimplifier, ColorSimplifySettings},
    color_f, color_idx, color_str_t, color_t,
    representations::{ColorAdjoint, ColorFundamental},
    tensor::{SymbolicNetExt, SymbolicNetParse},
};
use spenso::{
    network::parsing::{ParseSettings, SchoonschipExpansionMode, ShorthandParsing},
    shadowing::ProjectorExpander,
    structure::{
        abstract_index::AbstractIndex,
        representation::{LibraryRep, RepName},
        slot::Slot,
    },
    trace,
};
use symbolica::atom::{Atom, AtomCore};

fn main() {
    idenso::representations::initialize();
    // Alpha-rename hedge(0/8/10) to ordinary abstract labels, eliminating the
    // GammaLoop dependency while preserving the three distinct adjoint slots.
    let slots =
        [0, 8, 10].map(|index| ColorAdjoint {}.to_symbolic([Atom::num(8), Atom::num(index)]));
    let [a, b, c] = slots.clone();
    let expected_slots: HashSet<Slot<LibraryRep, AbstractIndex>> = slots
        .iter()
        .map(|slot| Slot::try_from(slot.as_view()).unwrap())
        .collect();
    let fundamental = ColorFundamental {}.to_symbolic([Atom::num(3)]);
    let antisymmetric = color_f!(a.clone(), b.clone(), c.clone());
    let symmetric = color_str_t!(fundamental.clone(), a.clone(), b.clone(), c.clone());
    let decomposed = symmetric.clone()
        + Atom::i() / Atom::num(2) * color_idx!(2, fundamental.clone()) * &antisymmetric;
    let ordered = trace!(fundamental, color_t!(a), color_t!(b), color_t!(c));
    let settings = ParseSettings {
        shorthand_parsing: ShorthandParsing::Expand {
            schoonschip: SchoonschipExpansionMode::full(),
            trace: false,
            chain: true,
        },
        ..Default::default()
    };
    let color_settings = ColorSimplifySettings::default().with_cof_dimension_invariants();
    // SU(3), Tr(Ta Tb) = delta_ab/2: Tr(Ta Tb Tc) f_abc =
    // i/2 * (1/2) * CA * dim(adj) = i/4 * 3 * 8 = 6i.
    let expected_value = Atom::num(6) * Atom::i();
    assert_eq!(
        (&decomposed * &antisymmetric).simplify_color_with(color_settings),
        expected_value,
        "the independent color-algebra control must evaluate to 6i"
    );
    let mut passed = true;
    for (name, expression, expected_closed) in [
        ("symmetric_only", symmetric, Atom::Zero),
        ("ordered_trace", ordered, expected_value.clone()),
        (
            "projector_expanded_sum",
            decomposed.expand_projectors(),
            expected_value.clone(),
        ),
        ("native_decomposed_sum", decomposed, expected_value),
    ] {
        println!("CASE {name}: {expression}");
        match expression.parse_to_symbolic_net::<AbstractIndex>(&settings) {
            Ok(network) => {
                let exposed: HashSet<_> = network.graph.dangling_indices().into_iter().collect();
                println!("EXPOSED {exposed:?}; expected {expected_slots:?}");
                let slots_match = exposed == expected_slots;
                let executed = network.simple_execute::<()>();
                let value = (executed * &antisymmetric).simplify_color_with(color_settings);
                let value_matches = value == expected_closed;
                println!(
                    "RESULT {value}; expected {expected_closed}; slots_match={slots_match}; value_matches={value_matches}"
                );
                passed &= slots_match && value_matches;
            }
            Err(error) => {
                println!("PARSE_ERROR {error}");
                passed = false;
            }
        }
    }
    assert!(
        passed,
        "public parsing lost exposed color slots or rejected a valid sum"
    );
}

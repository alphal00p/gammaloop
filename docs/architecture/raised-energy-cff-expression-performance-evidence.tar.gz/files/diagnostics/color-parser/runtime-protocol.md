# Prepared native C8 color-parser runtime

Status: launcher source prepared and Python AST syntax checked only. No build
or runtime was invoked for this preparation. The Rust source and its four
oracles remain unchanged.

After the controlled batch is terminal, root can build the existing probe:

```sh
/tmp/raised-stack/python /tmp/raised-energy-expression-perf-20260914/build-scratch-probes.py color-parser
```

Only after that build receipt reports PASS, run the prepared launcher once:

```sh
/tmp/raised-stack/python /tmp/raised-energy-expression-perf-20260914/run-color-parser-probe.py
```

The launcher requires the completed primary sweep and
`COMPLETED_WITH_RECORDED_OUTCOMES` for the 13-control batch, checks their recorded
process identities are no longer live, and holds the existing measurement lock.
It reuses `measure.guarded` and the existing ps10 watchdog: 30 GB process-tree
limit, Rayon 8, 128 MiB Rust worker stack, logging off, snapshot updates disabled
and no retries. The licensed wrapper is invoked by that existing guard only;
it is never inspected or included in an artifact inventory.

It binds the native C8 revision/tree, audited tracked source bytes, prepared
Rust source/manifest/scratch lock/native lock, validation receipt, build launcher,
four successful build stages, and copied immutable binary hash. These bindings
are checked before and after execution. The runtime uses a fresh
`diagnostics/color-parser/run-01`; an existing directory prevents another run.
Command, complete stdout, watchdog samples and guard result remain separate
files under `run-01/runtime`. The outer `run-01/receipt.json` adds semantic case
results without rewriting the execution evidence.

Every valid expression must expose exactly the three distinct adjoint slots
`coad(8,0)`, `coad(8,8)`, `coad(8,10)`, irrespective of HashSet print order.
Closing those slots with the antisymmetric SU(3) tensor must give:

| Input | Complete closed scalar oracle |
|---|---|
| Symmetric trace only | 0 |
| Ordered three-generator trace | 6i |
| Projector-expanded decomposed sum | 6i |
| Native decomposed sum | 6i |

The probe first checks the independent SU(3) color-algebra control against 6i.
Reaching any CASE line certifies that preceding assertion passed. The launcher
then retains the complete expression, complete exposed/expected slot line,
complete returned/expected scalar line and comparison flags, or the exact parse
error for each case. Cases interrupted before a result remain NOT_REACHED or
STARTED and produce INCOMPLETE_PROBE. No missing case is treated as a pass.

A nonzero exit from the probe remains CHILD_FAILURE even if it reproduces the
suspected parser issue. OBSERVED_CONTRACT_FAILURE records the case-level
explanation separately. Watchdog/infrastructure failures and memory caps remain
distinct. The oracles are fixed; failure does not authorize changing them or
retrying. This is a public parser/color-contract diagnostic, not a full GL1
integrand or Vakint-backend execution.

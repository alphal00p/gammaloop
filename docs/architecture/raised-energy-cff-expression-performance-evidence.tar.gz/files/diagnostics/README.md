# Prepared GL1 diagnostics (not executed)

## Isolated color parser reproducer

`color-parser/src/main.rs` uses public Idenso/Spenso APIs only. It contains one
main function and no production or repository-test modifications. Its complete
input is the color decomposition printed by the failing GL1 run, with the three
`gammalooprs::hedge(0/8/10)` indices alpha-renamed to ordinary abstract index
labels `0/8/10`. This removes the GammaLoop dependency while retaining the exact
color representations, generator/projector structure, coefficient, and index
incidence. It uses C6's exact parser settings: full Schoonschip expansion,
`trace: false`, and `chain: true`.

The expected exposed slots of the symmetric trace, ordinary trace and complete
sum are exactly `{coad(8,0), coad(8,8), coad(8,10)}`. The program compares full
slot sets, ignoring ordering. It prints all public parse results or errors, then
requires their mathematical contraction values. No assertion fixes a cache,
private storage layout, traversal order, expression spelling or exact error
message.

The independent scalar oracle is `Tr(Ta Tb Tc) f_abc = 6i`: with fundamental
normalization Tr(Ta Tb)=delta_ab/2 and SU(3), the antisymmetric part contracts to
`i/2 * (1/2) * CA * dim(adj) = i/4 * 3 * 8`. The fully symmetric trace contracted
with f is zero. A direct public color-algebra evaluation is checked first. Four
parser cases then isolate the suspected shallow representation boundary:

1. The symmetric trace alone: expected three exposed adjoint slots and closed
   contraction zero; current inference is predicted to lose the slots.
2. Ordinary cyclic trace: expected three slots and closed contraction 6i.
3. Explicit projector expansion of the small standalone color sum: expected
   three slots and contraction 6i.
4. Native symmetric-trace-plus-f sum: expected three slots and contraction 6i;
   current inference is predicted to reject its valid summands.

Only the standalone color projector is expanded in case 3. No graph numerator
is constructed or expanded. The final assertion reports whether the supported
public result contracts hold, not whether a particular implementation failed.
An exit 101 can be the intended bug reproduction; inspect the preceding control
results and classify it separately from compilation or setup failures.

The standalone Cargo manifest points to the fixed audited C8 source workspace
at `diagnostic-workspaces/c8`. Its tracked tree matches C8 across all 1,932
files. Resolver 2 and package profile overrides preserve native compilation
settings for the selected workspace crates. It does not use the moving PREFIX
source checkout. `color-parser/fixed-source-preparation.json` records the
manifest change; rerun offline locked metadata before compiling, since the
previous metadata file described ROOT-based paths. Symbolica/Graphica/Numerica are pinned to the native C8 revision
`4d0a833eb8e059d1f95bdae5abed2559830b235f`. The original C8 lock is copied as both
`Cargo.lock` and immutable `native-c8.Cargo.lock`; the new scratch package needs
its own lockfile root entry. After the shared-target benchmark sweep is idle:

```sh
/tmp/raised-stack/run cargo metadata --offline --format-version 1 --manifest-path /tmp/raised-energy-expression-perf-20260914/diagnostics/color-parser/Cargo.toml
```

Record the resulting lock and verify every retained dependency package's name,
version, source and checksum agrees with `native-c8.Cargo.lock` before compiling.
Do not update dependency revisions to resolve an error. Then, under the existing
ps10 watchdog with 30 GB cap and CARGO_BUILD_JOBS=4, check and build separately:

```sh
cargo check --locked --offline --manifest-path /tmp/raised-energy-expression-perf-20260914/diagnostics/color-parser/Cargo.toml --profile dev-optim
cargo build --locked --offline --manifest-path /tmp/raised-energy-expression-perf-20260914/diagnostics/color-parser/Cargo.toml --profile dev-optim
```

Use `CARGO_TARGET_DIR=/common/dev/gammaloop/higher-power-energies-review/target`
explicitly, preserving stdout, commands, source/lock fingerprints and monitor
receipts. Run the resulting `target/dev-optim/gl1-color-parser-reproducer` under
the licensed wrapper only after recording its binary identity. No compilation,
Cargo metadata execution or runtime has been performed during preparation.

## Separate C8 diagram-only export

`c8-gl1-diagram-only.toml` is a separately labeled input-certificate diagnostic.
It removes only the standalone `generate` command following the native
`--only-diagrams` generation. It retains all graph selectors, the projector,
model, settings, `save dot`, and `save state -o`, and points state to the fresh
absolute `diagnostics/c8-gl1-diagram-only-01/state`. Parsed TOML equality was
checked after those two declared changes. It does not count as the full native
GL1 workload passing.

The exact argv, cwd, output paths, source-card hash and immutable C8 build receipt
are in `c8-gl1-diagram-only-recipe.json`. The binary is the independent saved
C8 executable at `measurements/c8/build-native-01/gammaloop`, SHA256
`50a5c237a07192a9acaa3c4fe0f14c4c0e2304f44589d8fabf8da5af2cb03661`.
Check that hash and the build receipt before execution. Require the diagnostic
state/output directory to be absent, create its parent directory, and execute
the recorded argv with stdout/stderr redirected to the recorded stdout path.
The core command is:

```sh
/tmp/raised-energy-expression-perf-20260914/measurements/c8/build-native-01/gammaloop -n -s /tmp/raised-energy-expression-perf-20260914/diagnostics/c8-gl1-diagram-only-01/state /tmp/raised-energy-expression-perf-20260914/diagnostics/c8-gl1-diagram-only.toml run generate
```

The full recipe wraps that command with the existing licensed launcher, clears
all three inherited GL logging overrides afterward, sets Rayon=8 and 128 MiB
thread stacks, and applies the ps10 30 GB process-tree monitor. Run from the
`diagnostics` directory. Built-in JSON model content comes from the preserved
binary; no external DOT or source file input is needed, so this does not depend
on PREFIX remaining at C8. Do not run it concurrently with the matrix.

After successful exit, inspect the saved `GL1.dot` against main's saved DOT
(listed in the recipe). Compare the complete graph: three V_135 vertices and one
V_36; internal u edges 2,3,4 and internal g edges 5,6; external g edges 0,1;
incidence, orientation, LMB/routing expressions, overall factor and external
projector. A text diff is useful evidence but is not by itself the semantic
criterion. Also compare the restricted saved model entries used by this graph.
An equal count of graphs alone does not establish this certificate. Preserve
all generated artifacts and a distinct validation receipt; do not modify the
native failed result or its original card.

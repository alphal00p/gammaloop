# Prepared C8 sunrise orientation catalog diagnostic

Status: prepared and TOML-checked; no GammaLoop run, build or export executed.
The preserved native sunrise state has `store_atom=false`. C8 discards evaluator
atoms under that setting (`evaluators.rs:1576`), while standalone export requires
them (`amplitude/export.rs:70–78`). Exporting that state with `--read-only-state`
cannot produce the catalog JSON. No native state or settings were changed.

The prepared card changes `store_atom` to true and appends one
`save standalone ABS_OUTPUT_DIR --json` command, preserving all physical
settings and original commands. The state path is changed solely for a fresh
output directory. Parsed TOML equality after exactly those declared changes
was checked. Global logging is switched off by the launcher environment after
the licensed wrapper. This is an artifact diagnostic, not a native timing run.

The JSON recipe contains the complete exact argv, cwd, binary/build/card hashes,
output paths and validation predicates. After the primary sweep completes,
create its fresh run directory, capture stdout/stderr to its `stdout` path,
and execute its argv exactly once using the existing watchdog. Do not run
against the original saved state. The preserved binary embeds its native C8
model assets and needs no source checkout or rebuild.

The underlying CLI portion is:

```sh
/tmp/raised-energy-expression-perf-20260914/measurements/c8/build-native-01/gammaloop -n -s /tmp/raised-energy-expression-perf-20260914/diagnostics/c8-sunrise-orientation-catalog-01/state /tmp/raised-energy-expression-perf-20260914/diagnostics/c8-sunrise-orientation-catalog.toml run generate
```

On successful completion the public JSON export is:

`/tmp/raised-energy-expression-perf-20260914/diagnostics/c8-sunrise-orientation-catalog-01/standalone/processes/amplitudes/quark_sunrise/2L/standalone_evaluators.json`

The schema writes `graph_terms[*].orientations` from the runtime orientation
catalog and `original_integrand.production_orientation_ids` from the evaluator
stack. Both use the same runtime row order; `new_with_timings` checks their
lengths (`evaluators.rs:849–857`). Pair by row position, not by assuming that a
sigma ID is the row number. The export serializes Default/Reversed/Undirected
as 1/-1/0 (`amplitude/export.rs:251–264`). A minimal data-only inspection is:

```python
from pathlib import Path
import json
archive = json.loads(Path("/tmp/raised-energy-expression-perf-20260914/diagnostics/c8-sunrise-orientation-catalog-01/standalone/processes/amplitudes/quark_sunrise/2L/standalone_evaluators.json").read_text())
terms = [term for term in archive["graph_terms"] if term["graph_name"] == "GL0"]
assert len(terms) == 1
term = terms[0]
ids = term["original_integrand"]["production_orientation_ids"]
assert len(ids) == len(term["orientations"])
print(json.dumps([{"sigma_id": sigma, "physical_signs": signs}
                  for sigma, signs in zip(ids, term["orientations"])], indent=2))
```

For explicit edge-column labels, a separate public read-only display on the
fresh diagnostic state is available (with global log off):

```sh
/tmp/raised-energy-expression-perf-20260914/measurements/c8/build-native-01/gammaloop -n --read-only-state -s /tmp/raised-energy-expression-perf-20260914/diagnostics/c8-sunrise-orientation-catalog-01/state display integrand -p quark_sunrise -i 2L --category orientation
```

This display enumerates physical catalog rows and prints their edge IDs
(`integrand_info.rs:556–568`). It does not itself expose production selector
IDs, which is why the JSON export is needed. No additional compatibility helper
or Rust loader compilation is required; do not execute the generated standalone
Rust script merely to inspect JSON.

Before relating the fresh catalog to the native bare-pair report, compare
`GL0.dot` and all eight node DOT files exactly with the native C8 local run.
Rehash the 44 original state files against
`c8-sunrise-native-state-before-catalog.json`, including an equal complete path
inventory. Then check that the actual paired three-edge signs are sigma 0:
`[-1, 1, 1]`, sigma 1: `[1, -1, -1]`, as predicted by the earlier factor pairing.
These are expected assertions to run, not recorded results. A different actual
catalog must be reported and investigated; do not replace it with these expected
vectors or silently repeat generation.

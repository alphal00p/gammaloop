"""Bounded streaming inventory; no symbolic parsing or manipulation."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import re

BASE = Path('/tmp/raised-energy-expression-perf-20260914')
PROBE = BASE / 'diagnostics/common-factor-contraction'
OUT = BASE / 'diagnostics/common-factor-output-comparison'
preparation_path = PROBE / 'preparation.json'
preparation = json.loads(preparation_path.read_text())
proof_path = Path(preparation['proof'])
assert hashlib.file_digest(proof_path.open('rb'), 'sha256').hexdigest() == preparation['proof_sha256']
proof = json.loads(proof_path.read_text())
name = rb'[A-Za-z_][A-Za-z_0-9]*(?:::\{[^{}]*\}::[A-Za-z_][A-Za-z_0-9]*)?'
tokens = re.compile(name)
component = re.compile(rb'gammalooprs::\{spenso::rank1,spenso::tensor\}::Q\(-?\d+,spenso::\{\}::cind\([0-3]\)\)')
rows = []
for label, proof_key in [('original', 'enclosing_term'), ('factored', 'factored-equivalent-complete-enclosing-term')]:
    receipt_path = PROBE / ('run-' + label + '-01/receipt.json')
    receipt = json.loads(receipt_path.read_text())
    assert receipt['status'] == 'PASS' and receipt['tracked_before']['passed'] and receipt['tracked_after']['passed']
    assert receipt['input'] == preparation['inputs'][label]
    assert receipt['input'] == {k: proof[proof_key][k] for k in ['path', 'sha256']}
    with Path(receipt['input']['path']).open('rb') as stream:
        assert hashlib.file_digest(stream, 'sha256').hexdigest() == receipt['input']['sha256']
    stages = [json.loads(x) for x in (receipt_path.parent / 'runtime/stdout.log').read_text().splitlines()]
    assert any(x['stage'] == 'resolve_aliases' for x in stages)
    assert any(x.get('status') == 'PASS_CONTRACTION_ONLY' for x in stages)
    output = receipt['output']
    variables, functions, components, unicode_tokens, scalar_functions = Counter(), Counter(), Counter(), Counter(), Counter()
    digest, total, carry, max_buffer = hashlib.sha256(), 0, b'', 0
    with Path(output['path']).open('rb') as stream:
        while True:
            chunk = stream.read(1024 * 1024)
            if chunk:
                digest.update(chunk)
                total += len(chunk)
            data = carry + chunk
            max_buffer = max(max_buffer, len(data))
            assert len(data) <= 1024 * 1024 + 8192, 'Unexpected unbounded lexical token'
            boundary = data.rfind(b'*') + 1 if chunk else len(data)
            assert boundary or not chunk, 'No safe scalar-expression token boundary'
            prefix, carry = data[:boundary], data[boundary:]
            unicode_tokens.update(m.decode('utf-8') for m in re.findall(rb'[\x80-\xff]+', prefix))
            for match in tokens.finditer(prefix):
                following = prefix[match.end():match.end()+1]
                target = functions if following == b'(' else variables
                target[match[0].decode()] += 1
            components.update(m[0].decode() for m in component.finditer(prefix))
            scalar_functions.update(m[0].decode() for m in re.finditer(rb'(?:gammalooprs::\{\}::tree_denoms|three_dimensional_reps::\{\}::sigma)\([^()]{0,256}\)', prefix))
            if not chunk:
                break
    assert digest.hexdigest() == output['sha256'] and total == output['bytes']
    assert sum(components.values()) == functions['gammalooprs::{spenso::rank1,spenso::tensor}::Q']
    assert sum(scalar_functions.values()) == sum(functions[x] for x in ['gammalooprs::{}::tree_denoms', 'three_dimensional_reps::{}::sigma'])
    rows.append(dict(label=label, output=output, receipt=str(receipt_path), receipt_sha256=hashlib.sha256(receipt_path.read_bytes()).hexdigest(), functions=dict(sorted(functions.items())), variables=dict(sorted(variables.items())), concrete_momentum_components=dict(sorted(components.items())), maximum_buffer_bytes=max_buffer, unicode_tokens=dict(sorted(unicode_tokens.items())), scalar_function_applications=dict(sorted(scalar_functions.items()))))
result = dict(status='STREAMING_INVENTORY_COMPLETE', canonical_equal=False, canonical_inequality_reason='Complete qualified canonical strings have different verified byte lengths and SHA256 hashes.', exact_atom_equality='NOT_RUN', scalar_interpretation='Names and concrete Q/cind applications only; native semantic allowlist must be inspected before evaluation.', rows=rows)
(OUT / 'streaming-inventory.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))

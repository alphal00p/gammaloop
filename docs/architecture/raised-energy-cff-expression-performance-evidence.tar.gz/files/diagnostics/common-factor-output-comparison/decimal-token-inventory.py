"""Read measured factor inputs/outputs in bounded chunks; never parse or rewrite Atoms."""
from collections import Counter
from fractions import Fraction
import hashlib
import json
from pathlib import Path
import re

BASE = Path('/tmp/raised-energy-expression-perf-20260914')
MEASURED = BASE / 'diagnostics/common-factor-contraction'
OUT = BASE / 'diagnostics/common-factor-output-comparison'
preparation = json.loads((MEASURED / 'preparation.json').read_text())
sources = []
for label in ['original', 'factored']:
    sources.append(dict(label=label, boundary='replay_input', **preparation['inputs'][label]))
    receipt = json.loads((MEASURED / ('run-' + label + '-01/receipt.json')).read_text())
    assert receipt['status'] == 'PASS'
    sources.append(dict(label=label, boundary='resolved_contraction_output', **receipt['output']))
pattern = re.compile(rb'[+-]?[0-9]+[.][0-9]+(?:[eE][+-]?[0-9]+)?(?:`[0-9.]+)?')
rows = []
for source in sources:
    digest, carry, size = hashlib.sha256(), b'', 0
    tokens, contexts = Counter(), []
    with Path(source['path']).open('rb') as stream:
        while True:
            chunk = stream.read(1024 * 1024)
            digest.update(chunk)
            size += len(chunk)
            data = carry + chunk
            assert len(data) <= 1024 * 1024 + 8192
            boundary = data.rfind(b'*') + 1 if chunk else len(data)
            assert boundary or not chunk
            prefix, carry = data[:boundary], data[boundary:]
            for match in pattern.finditer(prefix):
                token = match[0].decode('ascii')
                assert len(token) <= 512
                tokens[token] += 1
                if len(contexts) < 5:
                    contexts.append(prefix[max(0,match.start()-30):match.end()+60].decode('utf-8','replace'))
            if not chunk:
                break
    assert digest.hexdigest() == source['sha256']
    rows.append(dict(**source, verified_bytes=size, decimal_token_count=sum(tokens.values()),
                     unique_tokens=dict(sorted(tokens.items())), bounded_contexts=contexts,
                     all_decimal_values_integer=all(Fraction(token.split('`')[0]).denominator == 1 for token in tokens)))
result = dict(status='STREAMING_INPUT_OUTPUT_DECIMAL_INVENTORY_COMPLETE', maximum_buffer_limit_bytes=1024*1024+8192,
              interpretation='Lexical decimal tokens denote Float coefficients in the native parser; counts compare measured boundaries only and do not assign the introducing production function.', rows=rows)
(OUT / 'decimal-token-inventory.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))

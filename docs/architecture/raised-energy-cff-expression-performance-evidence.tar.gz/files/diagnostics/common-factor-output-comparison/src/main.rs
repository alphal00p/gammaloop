use std::{collections::HashSet, env, fs, ops::Deref, path::Path, time::Instant};

use ahash::HashMap;
use color_eyre::{Result, eyre::eyre};
use gammalooprs::{
    initialisation::initialise,
    utils::{FUN_LIB, TENSORLIB},
};
use serde_json::{Value, json};
use symbolica::{
    atom::{Atom, AtomCore, AtomView, Symbol},
    domains::float::{Complex, Float},
    parser::ParseSettings,
    wrap_input,
};

fn main() -> Result<()> {
    let args = env::args().skip(1).collect::<Vec<_>>();
    if args.len() != 1 || Path::new(&args[0]).exists() {
        return Err(eyre!(
            "usage: cff-common-factor-output-comparison FRESH_RESULT.json"
        ));
    }
    let context: Value = serde_json::from_str(include_str!("../scalar-context.json"))?;
    let precision = 256;
    initialise()?;
    drop(TENSORLIB.read().unwrap());
    let _ = FUN_LIB.deref();
    let mut outputs = Vec::new();
    for input in context["inputs"].as_array().unwrap() {
        let started = Instant::now();
        let text = fs::read_to_string(input["path"].as_str().unwrap())?;
        let atom = Atom::parse_with_default_namespace(wrap_input!(&text), ParseSettings::default())
            .map_err(|error| eyre!("complete output parse failed: {error}"))?;
        println!(
            "{}",
            json!({"stage":"parse_complete_output", "path":input["path"],
            "utf8_bytes":text.len(), "atom_bytes":atom.as_view().get_byte_size(),
            "seconds":started.elapsed().as_secs_f64()})
        );
        outputs.push(atom);
    }
    let equal = outputs[0] == outputs[1];
    let mut report = json!({"exact_atom_equal":equal, "expansion_performed":false,
        "context":context, "status":if equal { "EXACT_ATOM_EQUAL" } else { "UNRESOLVED" }});
    fs::write(&args[0], serde_json::to_vec_pretty(&report)?)?;
    println!(
        "{}",
        json!({"stage":"direct_complete_atom_equality", "equal":equal})
    );
    if equal {
        return Ok(());
    }

    // Inspect complete function applications; concrete cind arguments belong to
    // their Q leaf and are never assigned separately. Preserve native pi/i.
    let mut leaves = HashSet::new();
    let mut negative_bases = HashSet::new();
    let mut invalid_exponents = Vec::new();
    for output in &outputs {
        output.visitor(&mut |view| match view {
            AtomView::Var(variable) if variable.get_symbol() == Symbol::PI => false,
            AtomView::Var(_) | AtomView::Fun(_) => {
                leaves.insert(view);
                false
            }
            AtomView::Num(_) => false,
            AtomView::Pow(power) => {
                match power.get_exp() {
                    AtomView::Num(number) if number.get_coeff_view().is_real() => {
                        if number.get_coeff_view().to_owned().is_negative() {
                            negative_bases.insert(power.get_base());
                        }
                    }
                    other => invalid_exponents.push(other.to_canonical_string()),
                }
                true
            }
            AtomView::Add(_) | AtomView::Mul(_) => true,
        });
    }
    let generic = context["generic_leaves"].as_array().unwrap();
    let fixed = context["fixed_leaves"].as_object().unwrap();
    let mut allowed = HashSet::new();
    let mut parameters = Vec::new();
    for name in generic
        .iter()
        .map(|v| v.as_str().unwrap())
        .chain(fixed.keys().map(String::as_str))
    {
        let atom = Atom::parse_with_default_namespace(wrap_input!(name), ParseSettings::default())
            .map_err(|error| eyre!("scalar context parse failed: {error}"))?;
        allowed.insert(atom.clone());
        parameters.push((name, atom));
    }
    let actual = leaves
        .iter()
        .map(|v| (*v).to_owned())
        .collect::<HashSet<_>>();
    let mut names = leaves
        .iter()
        .map(|v| v.to_canonical_string())
        .collect::<Vec<_>>();
    names.sort();
    report["scalar_leaves"] = json!(names);
    report["negative_power_bases"] = json!(negative_bases.len());
    report["status"] = json!("UNRESOLVED");
    if actual != allowed || !invalid_exponents.is_empty() {
        report["status"] = json!("UNKNOWN_SCALAR_CONTEXT");
        report["invalid_exponents"] = json!(invalid_exponents);
        fs::write(&args[0], serde_json::to_vec_pretty(&report)?)?;
        return Err(eyre!(
            "full scalar context differs from the inspected allowlist"
        ));
    }
    println!(
        "{}",
        json!({"stage":"scalar_context_validated", "leaves":names,
        "negative_power_bases":negative_bases.len()})
    );

    let zero = Float::with_val(precision, 0);
    let one = Float::with_val(precision, 1);
    let mut threshold = one.clone();
    for _ in 0..128 {
        threshold = threshold / 2;
    }
    let primes: [i64; 16] = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53];
    let divisors: [i64; 5] = [3, 5, 7, 11, 13];
    let mut samples = Vec::new();
    for sample in 0..3 {
        let mut map: HashMap<Atom, Complex<Float>> = HashMap::default();
        let mut assignments = Vec::new();
        for (index, (name, atom)) in parameters.iter().enumerate() {
            let (rn, rd, imn, imd) = if fixed.contains_key(*name) {
                (1, 1, 0, 1)
            } else {
                (
                    primes[(index + 3 * sample) % 16] + 2 * sample as i64,
                    divisors[(index + sample) % 5],
                    primes[(5 * index + sample) % 16] * if index % 2 == 0 { 1 } else { -1 },
                    17 + 2 * ((index + 2 * sample) % 7) as i64,
                )
            };
            map.insert(
                atom.clone(),
                Complex::new(
                    Float::with_val(precision, rn) / rd,
                    Float::with_val(precision, imn) / imd,
                ),
            );
            assignments
                .push(json!({"atom":name, "real_rational":[rn,rd], "imag_rational":[imn,imd]}));
        }
        // Predetermined points are never regenerated after a singularity or error.
        let mut row = json!({"sample":sample, "precision_bits":precision,
            "assignments":assignments, "status":"STARTED"});
        report["pending_sample"] = row.clone();
        fs::write(&args[0], serde_json::to_vec_pretty(&report)?)?;
        let evaluation = (|| -> Result<Value> {
            for base in &negative_bases {
                let value: Complex<Float> = base
                    .evaluate_with_prec(&map, precision)
                    .map_err(|error| eyre!("denominator evaluation failed: {error}"))?;
                if !value.re.is_finite()
                    || !value.im.is_finite()
                    || value.re == zero && value.im == zero
                {
                    return Err(eyre!("zero or non-finite negative-power base"));
                }
            }
            let values = outputs
                .iter()
                .map(|a| a.evaluate_with_prec(&map, precision))
                .collect::<std::result::Result<Vec<Complex<Float>>, _>>()
                .map_err(|error| eyre!("complete-output evaluation failed: {error}"))?;
            if values
                .iter()
                .any(|v| !v.re.is_finite() || !v.im.is_finite())
            {
                return Err(eyre!("non-finite complete output"));
            }
            let mut scale = one.clone();
            for value in &values {
                let norm = value.clone().to_polar_coordinates().0;
                if !norm.is_finite() {
                    return Err(eyre!("non-finite output magnitude"));
                }
                if norm > scale {
                    scale = norm;
                }
            }
            let residual = (&values[0] - &values[1]).to_polar_coordinates().0 / scale;
            if !residual.is_finite() {
                return Err(eyre!("non-finite relative residual"));
            }
            let zero_outputs = values
                .iter()
                .map(|v| v.re == zero && v.im == zero)
                .collect::<Vec<_>>();
            Ok(
                json!({"values":values.iter().map(|v| json!({"real":format!("{:.80e}",v.re),
                "imag":format!("{:.80e}",v.im)})).collect::<Vec<_>>(),
                "zero_outputs":zero_outputs, "relative_residual":format!("{residual:.80e}"),
                "threshold":"2^-128", "below_threshold":residual <= threshold,
                "status":if zero_outputs.iter().any(|z| *z) { "ZERO_OUTPUT_INCONCLUSIVE" }
                    else if residual <= threshold { "NUMERICAL_AGREEMENT" } else { "NUMERICAL_DISAGREEMENT" }}),
            )
        })();
        match evaluation {
            Ok(value) => row
                .as_object_mut()
                .unwrap()
                .extend(value.as_object().unwrap().clone()),
            Err(error) => {
                row["status"] = json!("INVALID_POINT");
                row["error"] = json!(error.to_string());
            }
        }
        println!(
            "{}",
            json!({"stage":"sample_complete", "sample":sample, "status":row["status"]})
        );
        samples.push(row);
        report["samples"] = json!(samples);
        report.as_object_mut().unwrap().remove("pending_sample");
        fs::write(&args[0], serde_json::to_vec_pretty(&report)?)?;
    }
    report["status"] = json!(
        if samples.iter().all(|s| s["status"] == "NUMERICAL_AGREEMENT") {
            "NUMERICAL_SUPPLEMENT_AGREES"
        } else if samples
            .iter()
            .any(|s| s["status"] == "NUMERICAL_DISAGREEMENT")
        {
            "NUMERICAL_DISAGREEMENT"
        } else {
            "UNRESOLVED"
        }
    );
    report["limitation"] = json!(
        "Generic finite-point evidence is supplementary, not an exact output identity or physical phase-space evaluation."
    );
    fs::write(&args[0], serde_json::to_vec_pretty(&report)?)?;
    println!(
        "{}",
        json!({"stage":"comparison_complete", "status":report["status"]})
    );
    Ok(())
}

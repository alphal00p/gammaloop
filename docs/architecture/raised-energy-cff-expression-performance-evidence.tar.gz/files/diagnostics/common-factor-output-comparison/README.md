# Complete contraction-output comparison

This separate native-C3 executable consumes both full `result.atom` files from the measured factor pair. Their streamed SHA256 hashes and complete byte lengths differ; this leaves value equality unresolved. The measured Rust source, settings, input witness, and result files are unchanged.

The executable first parses both qualified canonical outputs using the same initialization and parser as the measured harness and compares the complete Atoms with `==`. It never expands, subtracts symbolic expressions, strips namespaces, or selects a smaller term.

If direct equality is unresolved, a read-only visitor must find exactly the inspected scalar context. The 16 generic leaves are the 13 complete `Q(edge,cind(component))` applications plus `mUV`, `GC_1`, and `GC_11`. The other two complete functions have their native values: `tree_denoms(1)=1` and the selected orientation `sigma(58)=1`. The native imaginary unit and pi remain native numeric/builtin values. Unknown functions, unresolved aliases, open indices, and non-real/non-numeric exponents stop the check.

Three predetermined rational-complex assignments are constructed directly at 256-bit precision, with no f64 input. Every distinct negative-power base is evaluated with the same complete qualified-Atom map and must be finite and nonzero. Both full outputs and the relative residual `abs(a-b)/max(1,abs(a),abs(b))` must be finite. All assignments, both complex values, zero-output flags, residuals, and the exact threshold `2^-128` are recorded. Invalid points are retained and never regenerated. Numerical agreement supplements the exact input witness; it does not prove output equality or constitute physical phase-space evaluation.

The guarded launcher checks every source/context/input/output hash before and after, audits the fixed C3 workspace, and reuses the original memory monitor with the 30 GB sampled process-tree cap. It requires the primary and post-sweep batches to be terminal and the corrected C6 diagnostic receipt to be terminal. Root confirmation after C6 completion is additionally required before invoking either command.

Prepared commands:

```sh
/tmp/raised-stack/python /tmp/raised-energy-expression-perf-20260914/diagnostics/common-factor-output-comparison/run-checker.py build
/tmp/raised-stack/python /tmp/raised-energy-expression-perf-20260914/diagnostics/common-factor-output-comparison/run-checker.py run
```

The build action performs fmt/check/build/Clippy and copies an immutable executable. Each action has one fresh attempt directory and refuses existing attempts. Runtime receipt `PASS` certifies successful checker execution only: consult `run-01/comparison.json` for `EXACT_ATOM_EQUAL`, supplementary agreement, disagreement, or unresolved status. Source/metadata preparation has completed; build and runtime evidence are pending.

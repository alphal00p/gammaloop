"""Build or run the reviewed complete-output checker once, after C6 is idle."""
import argparse
import datetime
import fcntl
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil

BASE = Path('/tmp/raised-energy-expression-perf-20260914')
ROOT = Path('/common/dev/gammaloop/higher-power-energies-review')
PROBE = BASE / 'diagnostics/common-factor-output-comparison'
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('action', choices=['build', 'run'])
args = parser.parse_args()
lock = (BASE / 'measurement.lock').open('a')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
c6_path = BASE / 'diagnostics/c6-gl1-upstream-boundaries/run-02/receipt.json'
c6 = json.loads(c6_path.read_text())
assert c6['status'] not in ['STARTED', 'RUNNING'], 'C6 diagnostic still active'
for name, expected in [('remaining-sweep-02', 'FINISHED_SWEEP'),
                       ('controls/post-sweep-01', 'COMPLETED_WITH_RECORDED_OUTCOMES')]:
    assert json.loads((BASE / name / 'state.json').read_text())['status'] == expected
driver = BASE / 'measure.py'
assert hashlib.sha256(driver.read_bytes()).hexdigest() == '6f6ca7cbb51f5b606b93da4e00fe42465f3a194bc5efaf6e492df737cafad4d9'
spec = importlib.util.spec_from_file_location('measure', driver)
measure = importlib.util.module_from_spec(spec)
spec.loader.exec_module(measure)
measure.PREFIX = BASE / 'diagnostic-workspaces/c3'
revision = next(r for r in json.loads((BASE / 'revisions.json').read_text()) if r['label'] == 'c3')
review_path = PROBE / 'review.json'
review = json.loads(review_path.read_text())
assert review['status'] == 'PASS'
for path, expected in review['files'].items():
    assert measure.digest(path) == expected, path
validation_path = PROBE / 'preparation-validation.json'
validation = json.loads(validation_path.read_text())
assert validation['metadata_offline_locked_passed'] and validation['fmt_check_passed']
assert validation['retained_dependency_packages_identical']
assert measure.digest(Path('/tmp/raised-stack-latest-review-20260914/ram-watchdog-ps10.py')) == measure.WATCH_SHA
out = PROBE / (args.action + '-01')
out.mkdir(exist_ok=False)
record = dict(status='STARTED', action=args.action, revision=revision,
              launcher_sha256=measure.digest(__file__), review_sha256=measure.digest(review_path),
              validation_sha256=measure.digest(validation_path),
              c6_terminal_receipt=str(c6_path), c6_terminal_receipt_sha256=measure.digest(c6_path),
              started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), stages=[])
measure.write(out / 'receipt.json', record)
build = None
try:
    for path, expected in validation['pinned_files'].items():
        assert measure.digest(path) == expected, path
    record['tracked_before'] = measure.audit(revision)
    assert record['tracked_before']['passed'], 'Fixed C3 source changed'
    env = dict(CARGO_TARGET_DIR=str(ROOT / 'target'), CARGO_BUILD_JOBS='4', RAYON_NUM_THREADS='8',
               RUST_MIN_STACK='134217728', INSTA_UPDATE='no', NEXTEST_RETRIES='0')
    if args.action == 'build':
        manifest = str(PROBE / 'Cargo.toml')
        commands = [
            ('fmt', ['cargo', 'fmt', '--manifest-path', manifest, '--check']),
            ('check', ['cargo', 'check', '--offline', '--locked', '--manifest-path', manifest, '--profile', 'dev-optim', '-j', '4']),
            ('build', ['cargo', 'build', '--offline', '--locked', '--manifest-path', manifest, '--profile', 'dev-optim', '-j', '4']),
            ('clippy', ['cargo', 'clippy', '--offline', '--locked', '--manifest-path', manifest, '--profile', 'dev-optim', '-j', '4']),
        ]
    else:
        build_path = PROBE / 'build-01/receipt.json'
        build = json.loads(build_path.read_text())
        assert build['status'] == 'PASS' and build['revision'] == revision
        assert len(build['stages']) == 4 and all(s['status'] == 'PASS' for s in build['stages'])
        assert build['validation_sha256'] == record['validation_sha256']
        assert measure.digest(build['binary']) == build['binary_sha256']
        record.update(build_receipt=str(build_path), build_receipt_sha256=measure.digest(build_path), binary_sha256=build['binary_sha256'])
        commands = [('runtime', ['env', '-u', 'GL_DISPLAY_FILTER', '-u', 'GL_LOGFILE_FILTER',
            '-u', 'GAMMALOOP_DUMP_EVALUATOR_PRE_NETWORK_PARSE', '-u', 'GAMMALOOP_STOP_AFTER_EVALUATOR_PRE_NETWORK_PARSE',
            '-u', 'SPENSO_NETWORK_PROFILE', '-u', 'SPENSO_NETWORK_PROFILE_VERBOSE', '-u', 'SPENSO_NETWORK_PROFILE_ATOM_BYTES',
            'GL_ALL_LOG_FILTER=off', build['binary'], str(out / 'comparison.json')])]
    for stage, command in commands:
        result = measure.guarded(out, stage, command, env)
        record['stages'].append(result)
        measure.write(out / 'receipt.json', record)
        if result['status'] != 'PASS':
            record['status'] = result['status']
            break
    else:
        record['status'] = 'PASS'
        record['execution_status'] = 'PASS'
        if args.action == 'build':
            binary = out / 'cff-common-factor-output-comparison'
            shutil.copy2(ROOT / 'target/dev-optim' / binary.name, binary)
            record.update(binary=str(binary), binary_sha256=measure.digest(binary))
    record['execution_status'] = record['status']
    if args.action == 'run':
        comparison_path = out / 'comparison.json'
        if record['status'] == 'PASS':
            assert comparison_path.is_file(), 'Successful checker produced no comparison evidence'
        if comparison_path.exists():
            comparison = json.loads(comparison_path.read_text())
            assert comparison['status'] in ['EXACT_ATOM_EQUAL', 'NUMERICAL_SUPPLEMENT_AGREES',
                'NUMERICAL_DISAGREEMENT', 'UNRESOLVED', 'UNKNOWN_SCALAR_CONTEXT']
            assert comparison['expansion_performed'] is False
            assert comparison['context'] == json.loads((PROBE / 'scalar-context.json').read_text())
            assert isinstance(comparison['exact_atom_equal'], bool)
            if record['status'] == 'PASS':
                if comparison['status'] == 'EXACT_ATOM_EQUAL':
                    assert comparison['exact_atom_equal'] is True
                else:
                    assert comparison['exact_atom_equal'] is False
                    assert comparison['status'] != 'UNKNOWN_SCALAR_CONTEXT'
                    samples = comparison['samples']
                    assert len(samples) == 3 and [s['sample'] for s in samples] == [0, 1, 2]
                    assert 'pending_sample' not in comparison
                    statuses = [sample['status'] for sample in samples]
                    assert all(s in ['NUMERICAL_AGREEMENT', 'NUMERICAL_DISAGREEMENT',
                        'ZERO_OUTPUT_INCONCLUSIVE', 'INVALID_POINT'] for s in statuses)
                    if comparison['status'] == 'NUMERICAL_SUPPLEMENT_AGREES':
                        assert statuses == ['NUMERICAL_AGREEMENT'] * 3
                    elif comparison['status'] == 'NUMERICAL_DISAGREEMENT':
                        assert 'NUMERICAL_DISAGREEMENT' in statuses
                    else:
                        assert 'INVALID_POINT' in statuses or 'ZERO_OUTPUT_INCONCLUSIVE' in statuses
            record.update(comparison_status=comparison['status'], comparison_sha256=measure.digest(comparison_path))
except BaseException as error:
    record.update(prior_status=record['status'], status='LAUNCH_OR_EVIDENCE_FAILURE', error=repr(error))
finally:
    try:
        record['tracked_after'] = measure.audit(revision)
        assert record['tracked_after']['passed'], 'Fixed C3 source changed'
        for path, expected in validation['pinned_files'].items():
            assert measure.digest(path) == expected, path
        if args.action == 'run' and build is not None:
            assert measure.digest(build['binary']) == build['binary_sha256']
    except BaseException as error:
        record.update(prior_status=record['status'], status='SOURCE_INTEGRITY_FAILURE', integrity_error=repr(error))
    record['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    measure.write(out / 'receipt.json', record)
    print(json.dumps(dict(status=record['status'], receipt=str(out / 'receipt.json'), comparison_status=record.get('comparison_status'))), flush=True)
if record['status'] != 'PASS':
    raise SystemExit(1)

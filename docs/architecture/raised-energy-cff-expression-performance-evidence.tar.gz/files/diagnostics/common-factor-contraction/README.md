# Prepared same-input common-factor contraction diagnostic

Status: source formatted and offline metadata binding validated; no compilation
or GammaLoop execution performed. `preparation-validation.json` records the
current source, manifest and lock hashes and supersedes the initial preparation
hashes for the scratch source/manifest. Wait for root to schedule check/build
and runtime after the primary sweep.

The pair is the **complete enclosing scalar term** from the C3
namespace-qualified pre-network witness. Its projector, outside coefficient,
selector, model coupling symbols, scalar functions, powers and denominators
remain intact. The sole difference extracts the eight identical gamma factors
from the three-term nested sum. The existing proof.json binds both inputs and
proves this identity without numerator expansion. The naked common-gamma
product has open Lorentz slots and is not a suitable scalar replacement.

Reused implementations inspected before writing the small harness:

- `gammalooprs/examples/gl00_spenso_execute.rs` provides initialized public
  `parse_into_net`/`execute`/`result_scalar` replay of captured expressions.
- `gammalooprs/examples/bnl_evaluator_atom_mwe.rs` provides namespace-preserving
  text parsing and the `IntermediateCost` dispatch, but its default concrete
  path does not exactly reproduce production sum-boundary preparation and the
  completion pass. It is therefore not used unchanged for this comparison.
- Private `EvaluatorStack::preprocess_atom` (C3 `evaluators.rs:580`) owns the
  production sequence. Public `new_with_timings` continues into numeric evaluator
  construction and is too broad for this isolated boundary. The harness calls
  the same lower-level public operations directly, with no production changes.

The fixed sequence is: initialize native GammaLoop definitions, parse the
already normalized captured input, split only existing top-level scalar Add
terms, `parse_into_net`, scalar aliases at 4096 bytes,
`contract_ready_sum_boundaries`, `Sequential/MinIntermediateCost`, native
`SequentialRef/SmallestDegree` completion, `result_scalar`, resolve aliases,
and `Atom::add_many`. These settings match the captured C3 card and production
code. No algebra pass, factor collection, scalar substitution or numerator
expansion is added to the harness.

Context is retained at the measured boundary. `initialise` registers GS, UFO
and tensor symbols. The native TENSORLIB is `hep_lib_atom`; FUN_LIB contains
the same production conjugation operation. The captured input's tensor-bearing
functions are initialized `Q/Q3`, gamma, metric and delta; `Q3` has its native
component normalizer. The remaining couplings, OSE values, Q components,
`tree_denoms` and selector are formal scalar coefficients. Production
`preprocess_atom` itself accepts only Atom and settings and does not consult a
model or ParamBuilder. Numeric parameter/function-map construction happens
later in `GenericEvaluator::new_from_raw_params` (`evaluators.rs:1456` onward).
Therefore this experiment measures complete symbolic finite tensor contraction,
not a reconstructed physical numeric evaluator. Do not claim the latter or
silently assign values to the scalar context. Any missing registered definition
or non-scalar result is a failed diagnostic, not permission to improvise a
replacement context.

Cargo.toml depends on the immutable C3 diagnostic workspace and pins the exact
native Symbolica revision `4d0a833eb8e059d1f95bdae5abed2559830b235f`.
Its workspace resolver is explicitly 2. The `dev-optim` profile preserves
opt-level 2 for native workspace crates and 3 for registry/git dependencies
and workspace-hack; explicit package overrides avoid accidentally optimizing
standalone path dependencies at level 3. The overrides match all 12 selected native workspace packages, with the
workspace-hack retaining level 3 and the other 11 explicitly level 2. Native C3 Cargo.lock is copied both as a control and as the
initial working lock. Offline metadata added only the standalone package and
retained 505 native package version/source/checksum tuples unchanged, pruning
95 packages outside this closure. A second offline locked metadata check passed. Do not update production lockfiles or source. The initial native
lock hash and all input/source hashes are in preparation.json.

recipe.json records exact build and runtime argv. Use the established licensed
launcher without inspecting it, four Cargo jobs, the existing ps10 watchdog,
30 GB memory limit, Rayon 8 and 128 MiB Rust worker stack. Build once after the
primary sweep, copy/hash the binary immediately, and run original and factored
inputs in separate fresh processes/directories, sequentially and without
retries. No contraction heuristic changes are part of this pair.

Report Symbolica parse, network parse, alias/sum-boundary preparation, execution
including the native completion pass, alias resolution and full contraction
times separately. Save the entire resolved scalar output, alongside walltime
and process-tree RSS. Output serialization has its own timer. Initialization
and disk-output time are included in external process measurements, not in the
internal contraction timer.

A successful run requires scalar results and alias resolution for both inputs.
The factor witness establishes input equality. Compare complete returned values
where direct canonical equality succeeds; differing printed forms alone neither
prove a mismatch nor justify expansion. Preserve both outputs for a subsequent
factor-preserving comparison if direct equality does not settle it. Counts or
byte sizes are not correctness oracles. Single paired measurements remain a
bounded diagnostic, not a broad performance claim.

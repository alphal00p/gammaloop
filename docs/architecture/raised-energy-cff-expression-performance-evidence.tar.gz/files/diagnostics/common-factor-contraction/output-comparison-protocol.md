# Complete-output comparison for the common-factor pair

Prepared method only: no comparison has run and no measured harness files were
changed. Wait for both contraction receipts and their full resolved scalar
outputs. This check runs separately, outside both timing intervals.

1. Verify the two input hashes against the existing factor-witness proof, and
   bind each output hash to its successful contraction receipt. Require both
   native `result_scalar` calls and alias resolution to have completed. Preserve
   missing outputs, failures and resource caps as such; they are not equality
   results.
2. Compare the complete output bytes. The harness writes
   `Atom::to_canonical_string()` with qualified symbol names. Equal complete
   canonical strings establish equal returned Atoms without algebraic expansion.
   Record both output hashes, byte counts and `EXACT_CANONICAL_EQUAL`.
3. If bytes differ, parse both complete outputs in one separately initialized
   native C3 process, using the same namespace-preserving parser as the harness,
   and compare the full Atoms with `==`. Record `EXACT_ATOM_EQUAL` if successful.
   Do not strip names, compare only selected terms, or expand/subtract the graph
   numerator. Different canonical forms alone leave output equality unresolved.
4. Only if direct equality remains unresolved, inspect the actual scalar leaf
   inventory. The existing public `AtomCore::evaluate_with_prec` can supplement
   the result with generic finite-point evaluations. Use one shared
   `ahash::HashMap<Atom, Complex<Float>>` over the union of permitted formal
   scalar leaves; key complete qualified Atoms, including every function
   argument. Equal function applications then receive equal values, while
   different qualified symbols stay distinct. Preserve native numeric/builtin
   evaluation, including the imaginary unit. Do not treat tensor functions,
   unresolved aliases, open indices or unrecognized functions as arbitrary
   scalar parameters. Stop and report missing context instead.
5. For this optional supplement, use a small fixed list of generic complex
   assignments constructed at 256-bit precision from small rational real and
   imaginary parts, and record the entire map. Avoid special null, collinear or
   vanishing kinematics. Evaluate every negative-power base with the same map;
   any zero or non-finite denominator invalidates that point. Require finite
   complete outputs and report zero outputs explicitly so agreement cannot be
   presented as evidence without disclosing a vacuous sample. Report both
   values and the relative residual `abs(a-b)/max(1,abs(a),abs(b))`, with a stated
   threshold such as 2^-128. Do not silently regenerate failed sample points.

The exact factor-witness reassembly already proves equality of the two inputs.
Finite-point output agreement is supplementary numerical evidence, not a proof
of output equality or a reconstructed physical phase-space evaluation. A
numerical discrepancy would require checking the formal scalar context and
branch conventions before attributing it to contraction. Do not build a
sampling helper until actual outputs show that this extra check is useful.

Pinned local API evidence (Symbolica revision
`4d0a833eb8e059d1f95bdae5abed2559830b235f`):

- `src/atom/core.rs:940`: public `evaluate_with_prec` accepts the map and explicit
  binary precision. `examples/evaluate.rs:1-26` demonstrates the existing map
  and `Float::with_val` pattern; `src/lib.rs:120` exports `Complex` and `Float`.
- `src/evaluate/domain.rs:266` explicitly implements `EvaluationDomain` for
  `Complex<Float>`; native Numerica `float/complex.rs:742` supplies its `Real`
  implementation. These are the bounds required by `evaluate_with_prec`.
- `src/evaluate/tree.rs:3978`: unregistered scalar function applications are
  looked up by complete Atom bytes; registered functions retain their native
  evaluation hooks.
- `src/evaluate/tree.rs:4043-4084`: powers use native integer powers,
  square roots for half-integer exponents, and general `powf` otherwise.
- Exact rational-ring evaluation is therefore not required merely to support
  the fractional powers already present in these expressions.

No checker executable has been added. The measured `src/main.rs`, Cargo files,
input witness and recipe remain unchanged by preparation of this protocol.

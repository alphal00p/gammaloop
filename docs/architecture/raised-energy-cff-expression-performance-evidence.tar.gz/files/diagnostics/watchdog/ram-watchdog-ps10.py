#!/usr/bin/env python3
"""Use the pinned watchdog with only its two ps deadlines raised to ten seconds.

Scratch monitoring adaptation: no retries and no change to the memory cap,
process discovery, cleanup or sampling logic. Keep the original lock location.
"""
import hashlib
from pathlib import Path

SOURCE = Path('/common/dev/gammaloop/higher-power-energies-review/bin/ram_watchdog.py')
SOURCE_SHA256 = 'd0f5f51408f4c5ad386c046804fe0c5138872c2a961a3f08352b7b72a5075e1b'

if __name__ == '__main__':
    original = SOURCE.read_bytes()
    if hashlib.sha256(original).hexdigest() != SOURCE_SHA256:
        raise SystemExit('RAM watchdog adapter: source fingerprint changed; child not started')
    text = original.decode()
    if text.count('timeout=2') != 2:
        raise SystemExit('RAM watchdog adapter: expected exactly two ps deadlines; child not started')
    exec(compile(text.replace('timeout=2', 'timeout=10'), str(SOURCE), 'exec'),
         {'__name__': '__main__', '__file__': str(SOURCE)})

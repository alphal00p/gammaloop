#!/usr/bin/env python3
"""Run the remaining fixed revisions sequentially; never retry a measurement."""
import datetime
import json
import os
from pathlib import Path
import subprocess
import sys

BASE = Path('/tmp/raised-energy-expression-perf-20260914')
PREFIX = Path('/tmp/raised-stack/prefix')
PYTHON = '/tmp/raised-stack/python'
revisions = {row['label']: row for row in json.loads((BASE / 'revisions.json').read_text())}
labels = ['c1', 'c2', 'c3', 'c4', 'c5', 'c6', 'c7', 'main-base']
out = BASE / 'remaining-sweep-01'
out.mkdir(exist_ok=False)
state = dict(status='RUNNING', pid=os.getpid(), proc_start_ticks=Path('/proc/self/stat').read_text().rsplit(')', 1)[1].split()[19],
             planned_labels=labels, completed=[], current=None)
try:
    for label in labels:
        revision = revisions[label]
        state['current'] = dict(label=label, stage='checkout', revision=revision['commit'])
        (out / 'state.json').write_text(json.dumps(state, indent=2) + '\n')
        command = ['jj', 'new', '-r', revision['commit'], '-m', 'measure physical expression generation on pinned ' + label]
        result = subprocess.run(command, cwd=PREFIX, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        (out / (label + '-checkout.log')).write_text(result.stdout)
        if result.returncode:
            raise RuntimeError('Checkout failed for ' + label)
        jobs = [('build', None, 'native-01')]
        inventory = json.loads((BASE / 'attachments/run-card-inventory.json').read_text())
        inventory_label = 'oldmain' if label == 'main-base' else label
        cards = inventory['revisions'][inventory_label]['cards']
        if inventory['revisions'][inventory_label]['commit'] != revision['commit']:
            raise RuntimeError('Revision/card inventory mismatch')
        for card, attempt in [('sunrise_local_export', 'sunrise-local-01'), ('sunrise_integrated', 'sunrise-integrated-01'),
                              ('g_gl1_integrated', 'g-gl1-01'), ('orientation58_muv', 'orientation58-native-01'),
                              ('orientation58_muv_sparse_atom_aware', 'orientation58-sparse-01')]:
            entry = next(row for row in cards if row['card'] == card)
            if entry.get('path'):
                jobs.append(('run', card, attempt))
            else:
                state['completed'].append(dict(label=label, card=card, status='EXACT_UNSUPPORTED', reason=entry.get('reason')))
        for action, card, attempt in jobs:
            command = [PYTHON, str(BASE / 'measure.py'), action, label, '--attempt', attempt]
            if card:
                command += ['--card', card, '--build-receipt', str(BASE / 'measurements' / label / 'build-native-01/receipt.json')]
            state['current'] = dict(label=label, stage=action, card=card, attempt=attempt, argv=command)
            (out / 'state.json').write_text(json.dumps(state, indent=2) + '\n')
            print(json.dumps(dict(starting=state['current'])), flush=True)
            result = subprocess.run(command)
            receipt_path = BASE / 'measurements' / label / (action + '-' + attempt) / 'receipt.json'
            receipt = json.loads(receipt_path.read_text())
            row = dict(label=label, card=card, action=action, status=receipt['status'], exit_code=result.returncode,
                       receipt=str(receipt_path), revision=receipt['revision'])
            state['completed'].append(row)
            print(json.dumps(dict(finished=row)), flush=True)
            if receipt['revision'] != revision['commit'] or receipt['tree'] != revision['tree']:
                raise RuntimeError('Wrong source receipt')
            if action == 'build' and receipt['status'] != 'PASS':
                raise RuntimeError('Build did not complete successfully')
            if action == 'run' and receipt['status'] not in ('PASS', 'CHILD_FAILURE', 'MEMORY_CAP'):
                raise RuntimeError('Infrastructure or source-integrity failure; inspect before continuing')
            # A program error/cap is a measured terminal outcome, not a passing or completed generation.
            # Preserve it and continue different cards/revisions; there is no retry of the failed job.
    state.update(status='FINISHED_SWEEP', current=None)
except BaseException as error:
    state.update(status='STOPPED', error=repr(error))
    raise
finally:
    state['updated_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    (out / 'state.json').write_text(json.dumps(state, indent=2) + '\n')
    print(json.dumps(dict(status=state['status'], state=str(out / 'state.json'))), flush=True)

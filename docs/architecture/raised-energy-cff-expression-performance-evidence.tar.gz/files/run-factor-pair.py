"""Run the two proven-equivalent scalar contributions with one fixed executable."""
from pathlib import Path
import fcntl
import importlib.util
import json

BASE=Path('/tmp/raised-energy-expression-perf-20260914')
lock=(BASE/'measurement.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
for relative in ['remaining-sweep-02/state.json','controls/post-sweep-01/state.json']:
    state=json.loads((BASE/relative).read_text());assert state['status'] not in ['RUNNING','STARTED'],relative
assert json.loads((BASE/'remaining-sweep-02/state.json').read_text())['status']=='FINISHED_SWEEP'
spec=importlib.util.spec_from_file_location('measure',BASE/'measure.py');measure=importlib.util.module_from_spec(spec);spec.loader.exec_module(measure)
assert measure.digest(BASE/'measure.py')=='6f6ca7cbb51f5b606b93da4e00fe42465f3a194bc5efaf6e492df737cafad4d9'
probe=BASE/'diagnostics/common-factor-contraction';recipe=json.loads((probe/'recipe.json').read_text());build_path=probe/'build-01/receipt.json';build=json.loads(build_path.read_text());assert build['status']=='PASS'
preparation_path=probe/'preparation.json'
preparation_sha256='ac3ec31edbd09a30fbde5f0450c5e8796e937b5d4a91349752201f9bad763edb'
assert measure.digest(preparation_path)==preparation_sha256
preparation=json.loads(preparation_path.read_text())
assert measure.digest(preparation['proof'])==preparation['proof_sha256']
proof=json.loads(Path(preparation['proof']).read_text())
assert [run['label'] for run in recipe['runs']]==['original','factored']
for run,key in zip(recipe['runs'],['enclosing_term','factored-equivalent-complete-enclosing-term']):
    assert run['input']==preparation['inputs'][run['label']]
    assert run['input']=={field:proof[key][field] for field in ['path','sha256']}
    assert measure.digest(run['input']['path'])==run['input']['sha256']
assert measure.digest(build['binary'])==build['binary_sha256']
measure.PREFIX=BASE/'diagnostic-workspaces/c3';revision=next(r for r in json.loads((BASE/'revisions.json').read_text()) if r['label']=='c3');assert measure.audit(revision)['passed']
assert build['revision']==revision
assert preparation['revision']==proof['revision']==revision['commit']
for run in recipe['runs']:assert not Path(run['fresh_directory']).exists()
for run in recipe['runs']:
    assert measure.digest(run['input']['path'])==run['input']['sha256']
    out=Path(run['fresh_directory']);out.mkdir()
    record=dict(status='STARTED',label=run['label'],input=run['input'],build_receipt=str(build_path),build_receipt_sha256=measure.digest(build_path),binary_sha256=build['binary_sha256'],recipe_sha256=measure.digest(probe/'recipe.json'),preparation=str(preparation_path),preparation_sha256=preparation_sha256,proof=preparation['proof'],proof_sha256=preparation['proof_sha256'],tracked_before=measure.audit(revision))
    measure.write(out/'receipt.json',record)
    try:
        assert record['tracked_before']['passed']
        assert measure.digest(preparation_path)==preparation_sha256
        assert measure.digest(preparation['proof'])==preparation['proof_sha256']
        env=dict(CARGO_TARGET_DIR='/common/dev/gammaloop/higher-power-energies-review/target',CARGO_BUILD_JOBS='4',RAYON_NUM_THREADS='8',RUST_MIN_STACK='134217728',INSTA_UPDATE='no',NEXTEST_RETRIES='0',GL_ALL_LOG_FILTER='off')
        command=['env','-u','GAMMALOOP_DUMP_EVALUATOR_PRE_NETWORK_PARSE','-u','GAMMALOOP_STOP_AFTER_EVALUATOR_PRE_NETWORK_PARSE','-u','SPENSO_NETWORK_PROFILE','-u','SPENSO_NETWORK_PROFILE_VERBOSE','-u','SPENSO_NETWORK_PROFILE_ATOM_BYTES',build['binary'],run['input']['path'],run['result']]
        result=measure.guarded(out,'runtime',command,env)
        record.update(status=result['status'],runtime=result)
        if result['status']=='PASS':
            record['output']={'path':run['result'],'sha256':measure.digest(run['result']),'bytes':Path(run['result']).stat().st_size}
    except BaseException as error:
        record.update(status='LAUNCH_OR_EVIDENCE_FAILURE',error=repr(error))
    finally:
        try:
            record['tracked_after']=measure.audit(revision);assert record['tracked_after']['passed']
            assert measure.digest(run['input']['path'])==run['input']['sha256']
            assert measure.digest(preparation_path)==preparation_sha256
            assert measure.digest(preparation['proof'])==preparation['proof_sha256']
            assert measure.digest(build['binary'])==build['binary_sha256']
        except BaseException as error:
            record.update(prior_status=record['status'],status='SOURCE_INTEGRITY_FAILURE',error=repr(error))
        measure.write(out/'receipt.json',record)
        print(json.dumps({'case':run['label'],'status':record['status'],'receipt':str(out/'receipt.json')}),flush=True)
    if record['status'] not in ['PASS','MEMORY_CAP','CHILD_FAILURE']:raise SystemExit(1)

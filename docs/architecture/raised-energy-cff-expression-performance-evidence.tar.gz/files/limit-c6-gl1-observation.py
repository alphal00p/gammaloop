"""Bound one already-running native observation; retain its censored outcome."""
from pathlib import Path
import datetime
import json
import os
import signal
import time

RUN = Path('/tmp/raised-energy-expression-perf-20260914/measurements/c6/run-g-gl1-01')
PID = 4170611
path = Path('/proc') / str(PID) / 'stat'
stat = path.read_text().rsplit(') ', 1)[1].split()
start = stat[19]
assert os.getpgid(PID) == PID and os.getsid(PID) == PID
hz = os.sysconf('SC_CLK_TCK')
created = int(start) / hz
limit = 1200.0
record = dict(status='ARMED', pid=PID, proc_start_ticks=start, observation_limit_seconds=limit,
              established_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
              limit_was_predeclared_before_run=False,
              reason='Adaptive observation cap after the native C6 GL1 generation remained active for over17minutes; preserve lower bound and continue remaining prefixes.',
              classification='TIME_CENSORED_NOT_COMPLETED_TIMING')
out = RUN / 'observation-limit.json'
assert not out.exists()
def save():
    out.write_text(json.dumps(record, indent=2) + '\n')
save()
while path.exists():
    current = path.read_text().rsplit(') ', 1)[1].split()
    if current[19] != start or current[0] == 'Z':
        break
    elapsed = float(Path('/proc/uptime').read_text().split()[0]) - created
    if elapsed >= limit:
        assert os.getpgid(PID) == PID and os.getsid(PID) == PID
        # Signal only the verified workload group. Its supervising watchdog
        # remains alive and performs its existing descendant cleanup.
        os.killpg(PID, signal.SIGTERM)
        record.update(status='TIME_LIMIT', signalled_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                      observed_process_age_seconds=elapsed, signal='SIGTERM', process_group=PID)
        save()
        print(json.dumps(record), flush=True)
        break
    time.sleep(min(5, limit-elapsed))
else:
    pass
if record['status'] == 'ARMED':
    record.update(status='COMPLETED_BEFORE_LIMIT', finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    save()
    print(json.dumps(record), flush=True)

#!/usr/bin/env python3
"""Run only the previously unattempted tail after the inspected C6 monitor failure."""
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess

BASE = Path('/tmp/raised-energy-expression-perf-20260914')
PREFIX = Path('/tmp/raised-stack/prefix')
PYTHON = '/tmp/raised-stack/python'


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def save(path, value):
    temporary = path.with_suffix('.tmp')
    temporary.write_text(json.dumps(value, indent=2) + '\n')
    temporary.replace(path)


def main():
    plan_path = BASE / 'remaining-sweep-02-plan.json'
    plan = json.loads(plan_path.read_text())
    prerequisite = plan['prerequisite']
    assert sha(prerequisite['path']) == prerequisite['sha256']
    inspected = json.loads(Path(prerequisite['path']).read_text())
    assert inspected['status'] == 'INSPECTED_MONITOR_FAILURE_NOT_RETRIED'
    for path, expected in inspected['files'].items():
        assert sha(path) == expected, 'Inspected failure evidence changed'
    old_state = json.loads((BASE / 'remaining-sweep-01/state.json').read_text())
    assert old_state['status'] == 'STOPPED'
    for pid in (inspected['stopped_primary_pid'], inspected['runtime_child_pid']):
        assert not Path(f'/proc/{pid}').exists(), 'Original stopped pipeline PID is present; inspect before continuing'
    assert sha(BASE / 'measure.py') == plan['driver_sha256']
    assert sha('/tmp/raised-stack-latest-review-20260914/ram-watchdog-ps10.py') == plan['watchdog_adapter_sha256']
    assert sha(BASE / 'attachments/run-card-inventory.json') == plan['source_inventory_sha256']
    assert sha(BASE / 'revisions.json') == plan['revision_pins_sha256']
    assert sha(plan['c6_build_receipt']) == plan['c6_build_receipt_sha256']
    build = json.loads(Path(plan['c6_build_receipt']).read_text())
    assert build['status'] == 'PASS' and sha(build['binary']) == build['binary_sha256']
    revisions = {r['label']: r for r in json.loads((BASE / 'revisions.json').read_text())}
    assert build['revision'] == revisions['c6']['commit'] and build['tree'] == revisions['c6']['tree']
    for job in plan['jobs']:
        assert not (BASE / 'measurements' / job['label'] / (job['action'] + '-' + job['attempt'])).exists(), 'An attempted job would be repeated'
    spec = importlib.util.spec_from_file_location('measurement_source_audit', BASE / 'measure.py')
    measure = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(measure)
    source = measure.audit(revisions['c6'])
    assert source['passed'], 'PREFIX is no longer exactly pinned C6'
    out = BASE / 'remaining-sweep-02'
    out.mkdir(exist_ok=False)
    state = dict(status='RUNNING', pid=os.getpid(),
                 proc_start_ticks=Path('/proc/self/stat').read_text().rsplit(')', 1)[1].split()[19],
                 script_sha256=sha(__file__), plan_sha256=sha(plan_path), prerequisite=prerequisite,
                 initial_c6_source_audit=source, completed=[], current=None,
                 exact_unsupported=[plan['exact_unsupported']])
    save(out / 'state.json', state)
    current_label = 'c6'
    try:
        for job in plan['jobs']:
            label, action, attempt = job['label'], job['action'], job['attempt']
            revision = revisions[label]
            if label != current_label:
                state['current'] = dict(label=label, stage='checkout', revision=revision['commit'])
                save(out / 'state.json', state)
                command = ['jj', 'new', '-r', revision['commit'], '-m', 'measure unattempted physical expression generation on pinned ' + label]
                result = subprocess.run(command, cwd=PREFIX, stdin=subprocess.DEVNULL,
                                        stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
                (out / (label + '-checkout.log')).write_text(result.stdout)
                if result.returncode:
                    raise RuntimeError('Checkout failed for ' + label)
                current_label = label
            command = [PYTHON, str(BASE / 'measure.py'), action, label, '--attempt', attempt]
            if action == 'run':
                command += ['--card', job['card'], '--build-receipt',
                            str(BASE / 'measurements' / label / 'build-native-01/receipt.json')]
            state['current'] = dict(label=label, stage=action, card=job.get('card'), attempt=attempt, argv=command)
            save(out / 'state.json', state)
            print(json.dumps(dict(starting=state['current'])), flush=True)
            result = subprocess.run(command, stdin=subprocess.DEVNULL)
            path = BASE / 'measurements' / label / (action + '-' + attempt) / 'receipt.json'
            receipt = json.loads(path.read_text())
            row = dict(label=label, card=job.get('card'), action=action, status=receipt['status'],
                       exit_code=result.returncode, receipt=str(path), receipt_sha256=sha(path), revision=receipt['revision'])
            state['completed'].append(row)
            save(out / 'state.json', state)
            print(json.dumps(dict(finished=row)), flush=True)
            assert receipt['revision'] == revision['commit'] and receipt['tree'] == revision['tree']
            if action == 'build' and receipt['status'] != 'PASS':
                raise RuntimeError('Build failed; inspect before any dependent runs')
            if action == 'run' and receipt['status'] not in ('PASS', 'CHILD_FAILURE', 'MEMORY_CAP'):
                raise RuntimeError('Infrastructure/source failure: stop without retrying')
            # Failures and caps remain terminal observations, not completed-generation timings.
        state.update(status='FINISHED_SWEEP', current=None)
    except BaseException as error:
        state.update(status='STOPPED', error=repr(error))
        raise
    finally:
        state['updated_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        save(out / 'state.json', state)
        print(json.dumps(dict(status=state['status'], state=str(out / 'state.json'))), flush=True)


if __name__ == '__main__':
    main()

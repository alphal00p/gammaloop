# Prepared expression-performance evidence archive

The scratch packager and explicit allowlist are prepared. Only Python AST syntax
and a metadata-only candidate inventory have been checked. No archive, content
hashing pass or credential scan has run. The C6 diagnostic and separate
complete-output checker must reach terminal receipts before packaging. The
checker source/Cargo/context files and build/run receipt paths are now bound
under `diagnostics/common-factor-output-comparison`.

`package-expression-performance-evidence.py` follows the repository's existing
`docs/architecture/*-evidence.tar.gz` plus per-entry JSON convention. It writes
only under `/tmp/raised-energy-expression-perf-20260914/evidence-package`; root
can inspect the result before placing it in the repository.

After the checker gate has been configured and all guarded work is terminal:

```sh
/tmp/raised-stack/python /tmp/raised-energy-expression-perf-20260914/package-expression-performance-evidence.py --write
```

The current candidate contains 932 files and approximately 681.6 MB of source
text, including the complete original/factored scalar outputs (297.45/304.09 MB).
The remainder is about 80.0 MB. These are uncompressed inventory sizes; final
counts and compressed size are determined from the completed frozen selection.
Both complete outputs are retained for independent returned-value checks.

Selected evidence includes source/tree/dependency pins; original and adapted
cards; primary and controlled aggregates; build/runtime receipts, commands,
stdout and watchdog samples; generation summaries and bounded capture logs;
complete raw/factored witnesses; public probe sources and Cargo files; and
input/catalog certificates. Only specifically named graph/model/forest exports
and the standalone catalog JSON are selected from saved states. Compiled
binaries, whole states/workspaces, environment files, PDFs, prior archives,
symlinks, hardlinks and outside paths are excluded. The licensed wrapper is
never opened, hashed or archived. Its invocation path may appear in recorded
commands; a licensed execution setup remains external.

The explicit allowlist uses bounded-depth patterns and enumerated revision/card
labels, without recursive `**` traversal. The packager holds the existing
measurement lock, checks required terminal receipts and aggregate reference
hashes, scans every selected UTF-8 byte for listed credential formats without
printing matches, and rejects binary content. The supported credential-format
scan is stated as such, not as proof that every possible secret is detectable.

Archive members have sorted paths, normalized permissions and zero ownership
and timestamps; gzip has an empty filename and zero timestamp. An internal
manifest records per-file hashes and sizes. Every archived payload is rehashed
from the written archive before the external JSON manifest records its final
archive hash and size. No extraction or writes occur outside the scratch output
directory. Failure leaves an unfinalized partial archive, not a certified result.

The copied native executable itself is not included; its hash and invocations
remain in the receipts. The exact previously reviewed watchdog adapter source
is included under `diagnostics/watchdog`, with its original known hash and copy
provenance. No licensed wrapper file is read, hashed or copied. Exact native
source revisions and dependency locks plus the included probe source support
rebuilding the diagnostics. Final archive creation waits for the separate
output checker and C6 terminal results. Checker receipt PASS records completed
execution only; its separate comparison.json determines whether exact equality,
numerical agreement, disagreement or an unresolved result was observed.

C6 attempt `run-01` is preserved with its setup-failure sidecar: its logging
selectors were inert, and root requested termination. The recorded child exit
143 is not classified as a native physics failure. The corrected logging
experiment is `run-02`, with its own card/recipe/source and mandatory terminal
receipt. Both attempts remain in the archive; neither replaces the other.

The archive includes only approved `versions`, `cpu`, `affinity_cpu_count` and
`loadavg` fields in `measurement-platform.json`; the original curated metadata
file and all process-environment dumps stay excluded. Checker Python launch and
inventory sources are included explicitly. C6 trace snapshot01 retains the
complete captured prefix, every event Atom, timeline, selected structures and
sharing analysis. Its attempted stack sample is recorded as ptrace denied with
zero frames; GDB exit 0 does not certify a captured stack.

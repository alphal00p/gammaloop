# Current recorded measurement matrix

Generated 2026-09-14T21:46:22.830477+00:00. 46 runtime attempts; 37 eligible completed timings. Statuses: PASS=37, MEMORY_CAP=6, MONITOR_FAILURE=1, CHILD_FAILURE=2.

Each cell is full-card elapsed seconds / sampled process-tree GB (decimal). Failed or capped cells report elapsed observation only; they are not completed timings. Multiple attempts remain listed.

| Revision | g GL1 integrated | Sunrise integrated | Sunrise local export | Orientation58 exact intermediate | Orientation58 sparse control |
|---|---|---|---|---|---|
| main-current | PASS 73.639s / 3.180GB | PASS 5.501s / 0.053GB | PASS 2.538s / 0.047GB | EXACT_UNSUPPORTED | PASS 109.066s / 8.443GB |
| main-base | PASS 75.909s / 3.459GB | PASS 5.698s / 0.055GB | PASS 2.663s / 0.049GB | EXACT_UNSUPPORTED | PASS 114.278s / 8.383GB |
| c1 | PASS 39.082s / 1.860GB | PASS 4.687s / 0.050GB | PASS 2.151s / 0.046GB | EXACT_UNSUPPORTED | PASS 37.497s / 3.264GB |
| c2 | PASS 38.904s / 2.137GB | PASS 4.708s / 0.048GB | PASS 2.135s / 0.043GB | EXACT_UNSUPPORTED | PASS 36.660s / 3.102GB |
| c3 | PASS 166.063s / 17.700GB | PASS 5.941s / 0.052GB | PASS 3.050s / 0.054GB | PASS 59.884s / 7.015GB | MEMORY_CAP 49.706s / 30.618GB |
| c4 | PASS 164.877s / 17.767GB | PASS 5.683s / 0.054GB | PASS 2.640s / 0.045GB | PASS 59.493s / 8.354GB | MEMORY_CAP 46.912s / 30.146GB |
| c5 | PASS 161.936s / 17.696GB | PASS 5.550s / 0.058GB | PASS 2.583s / 0.048GB | PASS 60.117s / 6.885GB | MEMORY_CAP 48.355s / 30.242GB |
| c6 | MONITOR_FAILURE 875.207s / 0.330GB | PASS 4.307s / 0.053GB | PASS 2.602s / 0.048GB | PASS 59.523s / 7.033GB | MEMORY_CAP 48.703s / 30.484GB |
| c7 | CHILD_FAILURE 0.931s / 0.041GB | PASS 4.075s / 0.052GB | PASS 2.299s / 0.049GB | PASS 67.629s / 7.263GB | MEMORY_CAP 43.015s / 30.724GB |
| c8 | CHILD_FAILURE 0.859s / 0.042GB | PASS 4.216s / 0.054GB | PASS 2.620s / 0.049GB | PASS 62.144s / 7.734GB | MEMORY_CAP 39.235s / 30.680GB |

Native-default rows use sparse_atom_aware through C2 and intermediate_cost from C3. The original attachment explicitly requires intermediate_cost; its unsupported old-revision cells remain visible alongside separately labeled sparse controls. Both main pins retain their own models/dependencies.

Reported generation/evaluator stages:

| Revision / attempt | Saved graph-generation sum (s) | Spenso (s) | Symbolica (s) | Timing source |
|---|---:|---:|---:|---|
| main-current / run-g-gl1-01 | 72.489649 | 15.685367 | 31.528283 | saved graph statistics |
| main-current / run-sunrise-integrated-01 | 4.664993 | 0.636750 | 0.037949 | saved graph statistics |
| main-current / run-sunrise-local-01 | 0.924759 | 0.410906 | 0.032258 | saved graph statistics |
| main-current / run-orientation58-sparse-01 | — | 69.293530 | 33.113968 | completed evaluator-stack log events |
| main-base / run-g-gl1-01 | 74.726977 | 17.335239 | 32.214319 | saved graph statistics |
| main-base / run-sunrise-integrated-01 | 4.788352 | 0.639967 | 0.038612 | saved graph statistics |
| main-base / run-sunrise-local-01 | 0.941613 | 0.416140 | 0.032361 | saved graph statistics |
| main-base / run-orientation58-sparse-01 | — | 73.720679 | 33.440286 | completed evaluator-stack log events |
| c1 / run-g-gl1-01 | 37.921817 | 6.630284 | 15.934659 | saved graph statistics |
| c1 / run-sunrise-integrated-01 | 3.824351 | 0.406104 | 0.040588 | saved graph statistics |
| c1 / run-sunrise-local-01 | 0.622334 | 0.273034 | 0.035434 | saved graph statistics |
| c1 / run-orientation58-sparse-01 | — | 6.597956 | 27.355384 | completed evaluator-stack log events |
| c2 / run-g-gl1-01 | 37.968560 | 6.727517 | 15.953766 | saved graph statistics |
| c2 / run-sunrise-integrated-01 | 3.816910 | 0.407104 | 0.038956 | saved graph statistics |
| c2 / run-sunrise-local-01 | 0.587092 | 0.257181 | 0.033036 | saved graph statistics |
| c2 / run-orientation58-sparse-01 | — | 6.408016 | 27.109725 | completed evaluator-stack log events |
| c3 / run-g-gl1-01 | 163.227162 | 71.859200 | 64.271466 | saved graph statistics |
| c3 / run-sunrise-integrated-01 | 4.839989 | 0.890871 | 0.090467 | saved graph statistics |
| c3 / run-sunrise-local-01 | 1.253907 | 0.642464 | 0.080538 | saved graph statistics |
| c3 / run-orientation58-native-01 | — | 19.401046 | 34.552846 | completed evaluator-stack log events |
| c3 / run-orientation58-sparse-01 | — | — | — | no completed stage summary |
| c4 / run-g-gl1-01 | 162.088845 | 72.299406 | 65.342706 | saved graph statistics |
| c4 / run-sunrise-integrated-01 | 4.568296 | 0.759713 | 0.091939 | saved graph statistics |
| c4 / run-sunrise-local-01 | 1.107719 | 0.556258 | 0.081002 | saved graph statistics |
| c4 / run-orientation58-native-01 | — | 18.499498 | 35.594794 | completed evaluator-stack log events |
| c4 / run-orientation58-sparse-01 | — | — | — | no completed stage summary |
| c5 / run-g-gl1-01 | 159.376030 | 70.844593 | 65.204343 | saved graph statistics |
| c5 / run-sunrise-integrated-01 | 4.383984 | 0.738744 | 0.087511 | saved graph statistics |
| c5 / run-sunrise-local-01 | 1.119003 | 0.554472 | 0.085002 | saved graph statistics |
| c5 / run-orientation58-native-01 | — | 19.318331 | 35.658888 | completed evaluator-stack log events |
| c5 / run-orientation58-sparse-01 | — | — | — | no completed stage summary |
| c6 / run-g-gl1-01 | — | — | — | no completed stage summary |
| c6 / run-sunrise-integrated-01 | 3.214144 | 0.686247 | 0.084371 | saved graph statistics |
| c6 / run-sunrise-local-01 | 1.154366 | 0.578192 | 0.081789 | saved graph statistics |
| c6 / run-orientation58-native-01 | — | 18.723608 | 35.151745 | completed evaluator-stack log events |
| c6 / run-orientation58-sparse-01 | — | — | — | no completed stage summary |
| c7 / run-g-gl1-01 | — | — | — | no completed stage summary |
| c7 / run-sunrise-integrated-01 | 3.134922 | 0.688650 | 0.083389 | saved graph statistics |
| c7 / run-sunrise-local-01 | 1.029562 | 0.555226 | 0.084036 | saved graph statistics |
| c7 / run-orientation58-native-01 | — | 14.729522 | 49.465310 | completed evaluator-stack log events |
| c7 / run-orientation58-sparse-01 | — | — | — | no completed stage summary |
| c8 / run-g-gl1-01 | — | — | — | no completed stage summary |
| c8 / run-sunrise-integrated-01 | 3.077931 | 0.683923 | 0.085905 | saved graph statistics |
| c8 / run-sunrise-local-01 | 1.033963 | 0.549122 | 0.082712 | saved graph statistics |
| c8 / run-orientation58-native-01 | — | 14.580828 | 44.113671 | completed evaluator-stack log events |
| c8 / run-orientation58-sparse-01 | — | — | — | no completed stage summary |

Graph-generation statistics, evaluator substage observations and full-command wall time have distinct scopes. Nested/cumulative trace stages in measurement-stages.csv must not be added together as independent work. Saved internal peak_ram_bytes is retained only in JSON; it is not mixed with sampled process-tree RSS.

Source/model/lock/card/binary fingerprints and receipt links are in measurements.json and measurements.csv. No historical timing is imported. This Python aggregation reads recorded artifacts; it runs no physics workloads, builds, or tests.

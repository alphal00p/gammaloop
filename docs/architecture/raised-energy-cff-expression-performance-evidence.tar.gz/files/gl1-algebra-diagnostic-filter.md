# GL1 algebra boundary capture using existing logging

Source-only recipe for C3 `3ea313789a1a5290093579febd7d1c601b92594e`, with old-path comparison at C1 `665658b168981c5c508e6cd51d3b57bbb55a27fb` / C2 `a9397ee0f86b115fdfab50e81c48dde2137692e7`. No workload, diagnostic replay, or new instrumentation was executed for this note.

The existing hooks can expose three successive forms: the complete raw amplitude before evaluator algebra, its result after color **and** gamma simplification, and its result after metric simplification / dot conversion immediately before network parsing. There is no existing evaluator payload hook immediately before gamma simplification, after color simplification. Do not label the raw amplitude as that intermediate.

## Exact common logfile-only setting

The following keeps the existing summary/CFF timing filter and adds those three payloads. It works on C1/C2 and C3/C8 without enabling the evaluator network DOT dump:

```toml
logfile_directive = "off,[{#generation,#summary}]=debug,[{#generation,#cff,#profile}]=debug,gammalooprs::integrands::process::amplitude[{orientation_parametric_integrand}]=debug,gammalooprs::integrands::process::evaluators[{profile,stage=evaluator_stack_parse_atom_after_simplify_gamma}]=debug,gammalooprs::integrands::process::evaluators[{profile,stage=evaluator_stack_parse_atom_before_network_parse}]=debug"
```

Keep the existing display directive and all physics/evaluator settings unchanged. The no-algebra attachment needs only the last evaluator selector; it will not emit an after-gamma event.

`profile` is deliberately written as a **present field**, not a value predicate. Both selected evaluator payloads have a `profile` field; `evaluator_stack_parse_atom_network_dump` does not. The filter checks field presence at metadata level, so it prevents construction of that DOT event, including on C1/C2 where the old network dump has no `term_index`. The previous `!term_index` guard is sufficient for C3/C8 only. A `stage=...` condition alone is dynamic and can reject a payload after its formatting has already occurred. Source: `gammaloop-tracing-filter/src/lib.rs:258–274,486–522`; C3 evaluator payload callsites `evaluators.rs:597–604,627–632,690–698`; old C2 equivalents `evaluators.rs:505–511,528–533,568–575`.

The raw-amplitude selector also uses static field presence: the single event containing `orientation_parametric_integrand`. It is scoped to `gammalooprs::integrands::process::amplitude`, not `gammalooprs::processes::amplitude`.

## Payload meanings and limits

| Capture | Existing event/tags | Meaning |
|---|---|---|
| Raw amplitude | `orientation_parametric_integrand` field; `#generation,#graph,#orientation,#compile,#dump`; no `stage` field | `graph.derived_data.all_mighty_integrand`, before entering the original amplitude evaluator |
| After gamma | `stage=evaluator_stack_parse_atom_after_simplify_gamma`; `#generation,#profile,#compile,#term,#dump` | Raw evaluator input after color simplification with dimension invariants, followed by gamma simplification |
| Before network | `stage=evaluator_stack_parse_atom_before_network_parse`; same tags | After the previous step, then `simplify_metrics().to_dots()` when `do_algebra=true`; before independent top-level network parsing, aliasing and boundary closure |

The GL1 card uses `do_algebra=true`, leaves explicit-orientation-sum mode false, and disables threshold subtraction. On that route C3 passes the raw amplitude reference unchanged through `from_integrand_with_timings` and `new_with_timings` to preprocessing (`C3 amplitude/mod.rs:221–249; evaluators.rs:555–577,879–888`). Thus the raw amplitude is the evaluator's actual input before color/gamma algebra. If explicit-orientation-sum mode were enabled, selectors would be summed between that raw event and preprocessing; this equivalence would need revisiting. Old C1/C2 pass the same amplitude reference directly (`C2 amplitude/mod.rs:192–220`).

The raw amplitude event uses `LOGPRINTOPTS`: Symbolica syntax, no term truncation (`max_terms=None`), but **all namespaces and symbol attributes are hidden** (`utils/symbolica_ext.rs:37–59`). It also includes the parameter-builder table in its message. This is a complete factorization-shape diagnostic, but not a namespace-preserving replay artifact or a standalone proof of semantic identity. Do not resolve ambiguous unqualified symbols by guessing.

The two evaluator payloads use `log.after_gamma` and `log.atom`. In JSON their keys are `after_gamma` and `atom`. Their file formatter uses complete `to_plain_string()` preceded by `n-terms: N, byte size: B,expr:` (`gammaloop-tracing-filter/src/log_message.rs:36–43`). Decode JSON, split once at `expr:`, and preserve the complete remaining expression. Compare product/power/sum grouping without whole-expression expansion; retain coefficient, phase, selector and index data. Both packed Atom byte counts and text lengths are useful, but neither equals RSS.

For the one original evaluator input, this adds one raw expression and two plain expressions plus metadata/table, not a DOT per term. Other enabled evaluator inputs would each add their own after-gamma/pre-network pair. There is no reliable numerical file-size bound until the actual expressions are captured; the tensor result can be much larger than these source forms. The accepted `log.*` event formats both a compact display string and a plain-file string even if only the logfile emits it. These runs are diagnostics and must not replace the clean timing samples.

## Old-prefix environment hooks are post-algebra

C1/C2/main already have `GAMMALOOP_DUMP_EVALUATOR_PRE_NETWORK_PARSE=/absolute/path.atom` and optional `GAMMALOOP_STOP_AFTER_EVALUATOR_PRE_NETWORK_PARSE=1` (`C1 evaluators.rs:71–73,534–545`). With GL1's `do_algebra=true`, the dumped file is **after color, gamma, metrics and dot conversion**, the same meaning as `atom` above. It is not a raw-prealgebra or before-gamma hook. With the attachment's `do_algebra=false`, it instead captures the dimension-normalized raw evaluator input.

The hook writes complete plain syntax with no header, overwrites the requested file once per input Atom, and does not create parent directories. Use a unique path such as `/tmp/raised-energy-expression-perf-20260914/diagnostics/c2-gl1-pre-network.atom`. The optional stop is checked by presence and intentionally returns an error after writing but before network parsing; `0` still stops. Classify that as an expected diagnostic stop. These environment hooks were removed at C3. The common static-profile logfile selectors above are available across both generations.

There is no namespace-preserving raw-prealgebra file hook on C1/C2. Their old `network_dump` event does contain the original raw `a.to_canonical_string()`, but in the same event as `net.dot_pretty()` after parsing/aliasing. Logging filters select events, not individual payload fields; that event cannot provide the raw Atom while avoiding DOT construction. The raw amplitude event is the cheap existing alternative with the namespace limitation stated above.

## Timing interpretation

`EvaluatorBuildTimings.spenso_time` starts before preprocessing and covers color/gamma/metric algebra, parsing, aliasing, finite network preparation, contraction, scalar restoration and recombination (`C3 evaluators.rs:875–898`; C2 `:480–714`). Therefore the recorded GL1 71.859 s versus 6.728 s aggregate does not isolate tensor contraction. Existing `evaluator_stack_parse_atom_simplify_done` reports cumulative algebra time, while per-term `execute_elapsed` covers contraction plus the completion pass. There is no clean separate color/gamma timing field; payload-event timestamps from diagnostic runs include formatting overhead.

The similarly named `amplitude_to_vakint_after_simplify_gamma` event contains before/after gamma payloads for the amplitude-to-Vakint adapter (`C3 processes/amplitude.rs:1110–1123`). It is a different path and must not be substituted for a missing before-gamma hook in the evaluator pipeline. Keep Spenso environment profiling separate from this initial expression capture.

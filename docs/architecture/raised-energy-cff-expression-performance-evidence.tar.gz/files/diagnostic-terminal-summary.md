# Diagnostic terminal summary

As of 2026-09-14T22:38:23.361565+00:00. All scheduled executions are terminal; completion does not turn failures or numerical disagreement into passes.

| Diagnostic | Recorded status | Interpretation |
|---|---|---|
| factor_build | PASS | See its individual receipt and scope. |
| factor_original | PASS | See its individual receipt and scope. |
| factor_factored | PASS | See its individual receipt and scope. |
| color_build | PASS | See its individual receipt and scope. |
| color_runtime | CHILD_FAILURE | CHILD_FAILURE / OBSERVED_CONTRACT_FAILURE reproduces the unchanged public color-slot contract defect; it is not a passing test. |
| gl1_diagram | PASS_EXECUTION_ONLY | See its individual receipt and scope. |
| sunrise_catalog | PASS_EXECUTION_ONLY | See its individual receipt and scope. |
| c6_original_native | MONITOR_FAILURE | MONITOR_FAILURE is infrastructure-censored, with no completed native GL1 timing. |
| c6_diagnostic_setup_attempt | CHILD_FAILURE | CHILD_FAILURE/143 is the explicit stop after inert diagnostic logging selectors; not a native physics failure. |
| c6_corrected_diagnostic | TIME_LIMIT | TIME_LIMIT/124 is the declared 1200-second diagnostic limit. Complete 43-event prefix supports boundary observations, not completion of the physical generation. |
| output_checker_build | PASS | See its individual receipt and scope. |
| output_checker_runtime | PASS | See its individual receipt and scope. |

The output checker returned execution PASS and semantic NUMERICAL_DISAGREEMENT. Its precision-source audit supplies the qualification; exact output equality is not certified.

Report review and final archive integrity are recorded separately.

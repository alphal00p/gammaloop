"""Explicit, reproducible text-evidence archive; run only after final receipts."""
from pathlib import Path
import argparse
import codecs
import fcntl
import gzip
import hashlib
import io
import json
import os
import re
import stat
import tarfile

BASE = Path('/tmp/raised-energy-expression-perf-20260914')
ALLOWLIST = BASE / 'expression-performance-evidence-allowlist.json'
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--write', action='store_true', help='Create archive after all terminal checks')
args = parser.parse_args()
allow = json.loads(ALLOWLIST.read_text())
lock = (BASE / 'measurement.lock').open('a')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)


def safe(path):
    path = Path(path)
    relative = path.relative_to(BASE)
    if any(part in ['..', '.git', '.jj', '__pycache__'] for part in relative.parts):
        raise ValueError(f'Disallowed path: {relative}')
    cursor = BASE
    for part in relative.parts:
        cursor /= part
        if cursor.is_symlink():
            raise ValueError(f'Symlink rejected: {relative}')
    if not path.resolve().is_relative_to(BASE):
        raise ValueError(f'Outside path: {relative}')
    info = path.stat()
    if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
        raise ValueError(f'Non-regular file or hardlink: {relative}')
    if path.suffix not in ['.json', '.jsonl', '.md', '.toml', '.lock', '.py', '.rs', '.log', '.csv', '.atom', '.dot', '.txt']:
        raise ValueError(f'Unlisted content type: {relative}')
    if 'environment' in path.name.lower() or path.name in ['.env', 'run']:
        raise ValueError(f'Environment/wrapper excluded: {relative}')
    parts = relative.parts
    if parts[0] == 'measurements' and parts[1] not in allow['allowed_revision_labels']:
        raise ValueError(f'Unknown revision: {relative}')
    if parts[:2] == ('controls', 'measurements') and parts[2] not in allow['allowed_revision_labels']:
        raise ValueError(f'Unknown control revision: {relative}')
    if parts[:2] in [('attachments', 'cards'), ('attachments', 'controls')] and parts[2] not in allow['allowed_card_labels']:
        raise ValueError(f'Unknown card revision: {relative}')
    return relative.as_posix(), info


selected, unmatched = {}, []
for category, patterns in allow['categories'].items():
    for pattern in patterns:
        if '**' in pattern or pattern.startswith('/') or '..' in Path(pattern).parts:
            raise ValueError('Only bounded relative allowlist patterns are permitted')
        paths = sorted(BASE.glob(pattern))
        if not paths:
            unmatched.append(pattern)
        for path in paths:
            relative, info = safe(path)
            selected.setdefault(relative, {'bytes': info.st_size, 'categories': []})['categories'].append(category)
for name in allow['required_files']:
    if name not in selected:
        raise ValueError(f'Required artifact missing: {name}')
gaps = [{'status': 'PENDING_GATE_DEFINITION', 'description': text}
        for text in allow.get('pending_terminal_gate_definitions', [])]
for name, expected in allow['required_controller_statuses'].items():
    state = json.loads((BASE / name).read_text())
    if state['status'] != expected:
        gaps.append({'path': name, 'status': state['status'], 'expected': expected})
for name in allow['required_terminal_receipts']:
    if name not in selected:
        gaps.append({'path': name, 'status': 'MISSING'})
for name in sorted(selected):
    if Path(name).name in ['receipt.json', 'execution-receipt.json']:
        status = json.loads((BASE / name).read_text()).get('status')
        if status not in ['PASS', 'PASS_EXECUTION_ONLY', 'PASS_DIAGNOSTIC', 'CHILD_FAILURE',
                          'MEMORY_CAP', 'MONITOR_FAILURE', 'TIME_LIMIT', 'TIMEOUT_TOOL_FAILURE',
                          'SOURCE_INTEGRITY_FAILURE', 'INPUT_INTEGRITY_FAILURE', 'BUILD_OR_VALIDATION_FAILURE',
                          'LAUNCH_OR_EVIDENCE_FAILURE', 'EVIDENCE_FAILURE', 'LAUNCH_FAILURE',
                          'LAUNCH_OR_VALIDATION_FAILURE']:
            gaps.append({'path': name, 'status': status})
summary = {'files': len(selected), 'source_bytes': sum(row['bytes'] for row in selected.values()),
           'terminal_gaps': gaps, 'unmatched_optional_patterns': unmatched}
if not args.write:
    print(json.dumps({'status': 'INVENTORY_ONLY_NO_CONTENT_SCAN_OR_ARCHIVE', **summary}, indent=2))
    raise SystemExit(0)
if gaps:
    raise RuntimeError('Pending terminal artifacts; archive not created')

# Categories only are reported on a match; never print credential bytes.
secrets = {
    'symbolica_license': rb'(?i)[0-9a-f]{8}#[0-9a-f]{8}#[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}',
    'openai_key': rb'\bsk-(?:proj-|svcacct-)?[A-Za-z0-9_-]{24,}',
    'github_token': rb'\b(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,})',
    'aws_access_key': rb'\bAKIA[0-9A-Z]{16}\b',
    'private_key': rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----',
    'authorization_header': rb'(?i)authorization\s*[:=]\s*["\x27]?(?:bearer|basic)\s+[A-Za-z0-9_./+=-]{16,}',
}
patterns = {name: re.compile(pattern) for name, pattern in secrets.items()}
entries = []
for relative in sorted(selected):
    path = BASE / relative
    _, before = safe(path)
    digest, decoder, tail = hashlib.sha256(), codecs.getincrementaldecoder('utf-8')(), b''
    with path.open('rb') as stream:
        while chunk := stream.read(1024 * 1024):
            if b'\0' in chunk:
                raise ValueError(f'Binary content rejected: {relative}')
            decoder.decode(chunk)
            window = tail + chunk
            for category, pattern in patterns.items():
                if pattern.search(window):
                    raise ValueError(f'Credential category {category} detected in {relative}; value suppressed')
            digest.update(chunk)
            tail = window[-8192:]
        decoder.decode(b'', final=True)
    _, after = safe(path)
    if (before.st_size, before.st_mtime_ns, before.st_ino) != (after.st_size, after.st_mtime_ns, after.st_ino):
        raise RuntimeError(f'File changed during scan: {relative}')
    entries.append({'path': relative, 'archive_path': 'files/' + relative, 'bytes': before.st_size,
                    'mode': '0644', 'sha256': digest.hexdigest(), 'categories': sorted(set(selected[relative]['categories']))})
by_path = {entry['path']: entry for entry in entries}
primary = json.loads((BASE / 'measurements.json').read_text())
control = json.loads((BASE / 'controls/post-sweep-results.json').read_text())
assert control['primary_aggregate_sha256'] == by_path['measurements.json']['sha256'], 'Stale controls aggregate'
for row in primary['runs'] + control['rows']:
    references = [(row.get(name), row.get(name + '_sha256')) for name in ['receipt', 'build_receipt']]
    references += [(item['path'], item['sha256']) for item in row.get('summaries', []) + row.get('trace_files', [])]
    for path, expected in references:
        if path is None or expected is None:
            continue
        relative, _ = safe(Path(path))
        assert relative in by_path and by_path[relative]['sha256'] == expected, f'Stale or unselected aggregate evidence: {relative}'
manifest = {'schema_version': 1, 'allowlist_sha256': by_path[ALLOWLIST.name]['sha256'],
            'determinism': 'Sorted members; mode0644; uid/gid/mtime zero; empty user/group/gzip filename; gzip mtime zero. Same frozen inputs and compression toolchain produce identical archive bytes.',
            'files': entries, 'file_count': len(entries), 'source_bytes': sum(e['bytes'] for e in entries),
            'credential_scan': 'All selected bytes scanned for listed credential formats; no matches. This does not claim detection of every possible secret format.',
            'credential_categories': sorted(secrets), 'utf8_text_only': True,
            'excluded': allow['excluded'], 'unmatched_optional_patterns': unmatched,
            'terminal_gaps': [], 'aggregate_receipt_and_summary_hashes_checked': True,
            'comparison_receipt_semantics': allow['comparison_receipt_semantics'],
            'diagnostic_attempt_semantics': allow['diagnostic_attempt_semantics'],
            'platform_metadata_scope': allow['platform_metadata_scope'],
            'watchdog_source_scope': allow['watchdog_source_scope']}
manifest_bytes = (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode()
out = BASE / 'evidence-package'
out.mkdir(exist_ok=False)
archive = out / (allow['archive_stem'] + '.tar.gz')
temporary = out / (archive.name + '.partial')
with temporary.open('xb') as raw, gzip.GzipFile(filename='', fileobj=raw, mode='wb', mtime=0, compresslevel=6) as compressed, tarfile.open(fileobj=compressed, mode='w|', format=tarfile.USTAR_FORMAT) as tar:
    for name, data in [('MANIFEST.json', manifest_bytes)]:
        info = tarfile.TarInfo(name); info.size = len(data); info.mode = 0o644
        tar.addfile(info, io.BytesIO(data))
    for entry in entries:
        path = BASE / entry['path']
        safe(path)
        info = tarfile.TarInfo(entry['archive_path']); info.size = entry['bytes']; info.mode = 0o644
        with path.open('rb') as stream:
            tar.addfile(info, stream)
        with path.open('rb') as stream:
            assert hashlib.file_digest(stream, 'sha256').hexdigest() == entry['sha256'], f'Changed input: {entry["path"]}'
with tarfile.open(temporary, 'r:gz') as tar:
    assert tar.getnames() == ['MANIFEST.json'] + [entry['archive_path'] for entry in entries]
    for member in tar:
        assert member.isfile() and not member.issym() and not member.islnk()
        data = tar.extractfile(member)
        expected = hashlib.sha256(manifest_bytes).hexdigest() if member.name == 'MANIFEST.json' else by_path[member.name.removeprefix('files/')]['sha256']
        assert hashlib.file_digest(data, 'sha256').hexdigest() == expected, member.name
os.replace(temporary, archive)
with archive.open('rb') as stream:
    archive_sha = hashlib.file_digest(stream, 'sha256').hexdigest()
manifest.update(archive='docs/architecture/' + archive.name, archive_sha256=archive_sha,
                archive_bytes=archive.stat().st_size, archived_hashes_reverified=True)
index = out / (allow['archive_stem'] + '.json')
index.write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n')
print(json.dumps({'status': 'PACKAGED', 'archive': str(archive), 'manifest': str(index),
                  'files': len(entries), 'source_bytes': manifest['source_bytes'],
                  'archive_bytes': manifest['archive_bytes'], 'archive_sha256': archive_sha}))

# Completion audit

As of 2026-09-14T22:38:23.361565+00:00. All scheduled measurement and diagnostic executions are terminal. Final report and archive completion have separate certificates.

| Requirement | Status | Evidence/finding |
|---|---|---|
| 1 | COMPLETE | Recorded jj push succeeded and exact remote refs matched reviewed C8 and the pinned current main. |
| 2 | COMPLETE_WITH_RECORDED_FAILURES_AND_UNSUPPORTED_CELLS | 46 terminal native attempts across both main pins and C1-C8: 37 PASS, six MEMORY_CAP, two CHILD_FAILURE, one MONITOR_FAILURE. Four exact intermediate-cost combinations are unsupported; labeled sparse controls cover the same physical input. |
| 3 | COMPLETE_WITH_EXPLICIT_COMPATIBILITY_LIMIT | All 46 parsed card adaptations are verified; each revision keeps native locked dependencies and models. Pre-C3 intermediate_cost incompatibility is explicit, and sparse controls are distinct. |
| 4 | COMPLETE_AUDITED | All 46 indexed receipt hashes match and all recorded before/after source audits pass. Lock/model/manifest/card/binary hashes are present; all observation receipt paths are distinct. |
| 5 | COMPLETE_WITH_DOCUMENTED_TIMING_GRANULARITY_LIMIT | Build commands are separate from full-card runtimes; generation/evaluator stages and process-tree RSS are retained. Cap, child failure, watchdog failure and completed timing are distinguished. |
| 6 | BOUNDED_INVESTIGATION_COMPLETE_CAUSAL_PROOF_UNRESOLVED | Complete pipeline source tracing, adjacent-commit matrix, four upstream captures, UV/order/algebra controls and native public probes locate concrete boundaries. C3 onset is measured; C6/C7 color-input changes and the trace parser defect are separated. |
| 7 | COMPLETE_FOR_CERTIFIED_FACTOR_AND_SELECTOR_SCOPES | Graph-numerator products were preserved. The complete C3 gamma-factor extraction is exactly reversible; sunrise complete branch factors and all eight runtime sign rows match the bare-pair proof. GL1 full bare tensor/sign-support audit is preserved. |
| 8 | COMPLETE_WITH_LIMITED_REPETITIONS | Seven fresh repeats and six one-setting controls are terminal: 12 PASS, one MEMORY_CAP; no control evidence issues. Material C3 onset survives the repeated observations. |
| 9 | FINAL_REPORT_AND_ARCHIVE_CERTIFIED_SEPARATELY | All scheduled executions are terminal, with failures and censoring preserved. The completed report is bound by final-report-review.json; the external archive manifest certifies assembly and per-entry verification without a self-referential hash. |

All 46 primary receipt hashes match their aggregate entries, and all recorded source audits pass. The primary matrix has 37 passes, six memory caps, two program failures and one monitor failure. Four exact settings are unsupported. All 13 controls are terminal: 12 passes and one memory cap.

Both factor replays and the output checker completed. Checker execution PASS is separate from its NUMERICAL_DISAGREEMENT at all three points. Relative residuals near 1e-16 despite requested 256 bits require the recorded precision qualification; they do not prove a contraction defect. Exact input-factor identity remains proved.

C6 native GL1 remains censored by its monitor failure. The inert first logging attempt is a stopped setup failure. Corrected run-02 is TIME_LIMIT/124 after 1200.742 seconds; its 43 complete events are retained. GDB attachment was denied and no frames were captured. No diagnostic substitutes for a completed native generation.

No independent export-only timer exists. Matched C1/C3 proper-UV provenance, full GL1 scalar CFF-weight equality, full-integrand equality and a single implementation cause for the entire C3 slowdown remain unproved. These limits do not indicate a missing scheduled run.

final-report-review.json binds the finished report. The external raised-energy-cff-expression-performance-evidence.json manifest certifies the final archive and payload hashes; this audit deliberately does not embed the archive hash.

This audit performed bounded metadata/report checks only. It ran no workloads and no package-content scan.

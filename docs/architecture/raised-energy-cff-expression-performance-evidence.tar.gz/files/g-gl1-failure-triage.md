# GL1 integrated-generation failure: current evidence

The native GL1 card completes on current main and C1–C5. C7 and C8 fail
immediately with the same analytic UV tensor-notation error. C6 runs for more
than 14 minutes before the process monitor fails; it has no completed-generation
result and no observed copy of this parse error. C7 is therefore the earliest
observed immediate parse failure, while C6 remains inconclusive as a completed
workload.

C6 introduces the analytic spin parser. C7 changes the expression reaching it:
early color simplification produces an open symmetric color trace, and local
spin simplification moves later. The parser then encounters a pre-existing
Spenso slot-inference blind spot. This source-supported mechanism is distinct
from the C3 expression-growth boundary. The isolated public-API reproducer and
C8 diagram-only certificate remain prepared but unexecuted.

## Full pipeline comparison before local diagnosis

Both cards request the same massless QCD two-loop g-to-g GL1 graph with one
quark loop and a three-gluon vertex, the same external color/Lorentz projector,
local plus integrated UV, no thresholds, one generation core, and the same
non-compiled, unsummed evaluator settings. Main uses the old
`--number-of-fermion-loops` spelling; C8 uses `--number-of-anticommutating-loops`.
With only g/u species this spelling adaptation does not admit a ghost loop.

Both execute: import restricted built-in model; clear processes; generate and
select diagrams; generate integrand; save DOT; save state. Main completes all
steps. C8 completes diagram generation, then fails during integrand generation,
so neither explicit save runs. Both logs report the same diagram count sequence
16 -> 11 -> 11 -> 11 -> 6 -> 6 -> 6 -> 1, no grouping cancellations, and a final
symmetry-factor sum of -1.

The complete model files differ, but all **11 graph-used model entries** are
exactly equal after JSON parsing: g/u/u~ particles, g/u Feynman propagators,
V_135/V_36 vertices, FFV1/VVV1 Lorentz structures, and GC_10/GC_11 couplings.
The entire parameter list and default restriction are also equal. Thus a changed
Feynman rule for these entries cannot explain this error.

Main's saved GL1 DOT contains three V_135 vertices, one V_36 vertex, three
internal u lines, two internal g lines, two external g lines and the requested
projector. C8 has no saved DOT because it fails before saving. Equal generation
counts are not a complete graph/routing certificate: a separate diagram-only
export on C8 remains necessary before claiming exact generated graph identity.
This is the last missing shallow input comparison, not grounds to blame a
contour or integration backend.

The common conceptual UV route constructs local four-dimensional Taylor terms
and analytically integrates the relevant UV subgraph. On main and C1-C5,
`Integrated::run` passes that term into `simplify`, whose first operation is
Lorentz/bispinor collection. C6 inserts a new earlier boundary: a symbolic
network parse with full Schoonschip materialization, chain expansion enabled,
and trace expansion disabled. It then symbolically executes and expands the
analytic spin algebra. Scalar dot/metric spectators are protected with aliases.
This parser sees the entire analytic UV integrand, including its color factors.

The input-side call is at
`crates/gammalooprs/src/uv/approx/integrated.rs:337`; it precedes `self.integrate`
at line 343, conversion to Vakint at line 408, canonicalization at line 433,
tensor reduction at line 442 and evaluation at line 461. The same simplifier is
also used for projected numerators after tensor reduction, so the compact error
alone does not identify a forest owner or rule out previous successful backend
work on another term. Its immediate failing operation is unambiguously
GammaLoop/Spenso tensor parsing, not a Vakint algebra operation.

## Concrete boundary and mechanism

The C8 error at `integrated.rs:217` compares these two summands:

- `trace(cof(3), sym(t(a,in,out), t(b,in,out), t(c,in,out)))`: classified Scalar.
- `i/2 * f(a,b,c) * idx(2,cof(3))`: classified SelfDualTensor.

Here a, b, c are the distinct adjoint slots `coad(8,hedge(0/8/10))`. Both
summands mathematically expose all three adjoint indices. They are the ordinary
Idenso decomposition of `Tr(T^a T^b T^c)`, implemented at
`crates/idenso/src/color/simplify.rs:321`. A fundamental trace closes the
fundamental indices; it does not close those adjoint slots.

The exact static path predicting the observed mismatch is:

1. `integrated.rs:169` enters this spin pass on any `SPENSO_TAG.trace`, including
   color traces, and its parser settings at lines 208-213 leave traces opaque.
2. `crates/spenso/src/network/parsing/materialization.rs:527` recognizes disabled
   trace expansion. Its fixed-point path at lines 568-576 calls fast inferred
   leaf parsing.
3. `structure_inference.rs:361` scans a trace's factors through
   `shadowing::trace_factor_views` and `append_syntactic_slots`.
4. `crates/spenso/src/shadowing/trace.rs:73` unwraps only `cyclic(...)`, not the
   inert `sym(...)` payload produced for symmetric color traces.
5. `structure_inference.rs:280` treats a generic function's direct slot or
   `aind(...)` arguments as structural. The arguments of `sym` are generator
   functions, not direct slots, so its nested adjoint indices disappear from
   the inferred structure. The trace is consequently treated as scalar.
6. `f(a,b,c)` has direct adjoint-slot arguments and remains a tensor. The sum
   compatibility check in `parsing/mod.rs:959` or its equivalent non-precontract
   branch rejects the scalar/tensor sum, producing exactly the saved message.

The trace/projector helpers are byte-identical between current main and C8.
C1 changes only visibility of `syntactic_structure_from_atom`, not the trace or
function inference rules above. The three-generator color identity predates C1
as well. C1 does reorganize color simplification, but that alone is not evidence
that it introduced this parser defect. The missing symmetric-projector slot
semantics predate the stack. C6–C8 have byte-identical `integrated.rs`, but their
inputs differ: C7's `local_4d::grow` adds color simplification, and its Taylor
path stops closing the spin algebra before this boundary. The unchanged parser
therefore receives a new unresolved symmetric-trace sum. Full source evidence
is in `upstream-expression-analysis/c6-c7-analytic-color-input-boundary.md`.

The broad passing scalar/sunrise checks do not cover this color structure:
a two-generator quark trace reduces to an adjoint metric, while this GL1 quark
triangle yields the symmetric-trace-plus-f sum. Existing parser tests cover
ordinary cyclic traces with exposed indices; the inspected color invariant test
checks scalar Casimir/index/Gram products, not parsing a rank-three symmetric
trace combined with f.

## Smallest next diagnostics, without a fix

First export only the already selected C8 GL1 diagram into a new scratch state
and compare its graph, vertex assignments, routing and projector with main's
saved DOT. Do not alter the native failing card or relabel a shortened run as
its successful execution.

Then use the public Idenso/Spenso API on the isolated **color factor**, not on an
expanded graph numerator. Construct three distinct adjoint slots a,b,c and
`cof_3 = ColorFundamental {}.to_symbolic([Atom::num(3)])` using existing helpers:

```rust
let color = color_str_t!(cof_3.clone(), a.clone(), b.clone(), c.clone())
    + Atom::i() / Atom::num(2)
        * color_idx!(2, cof_3)
        * color_f!(a, b, c);
```

Parse this with exactly the C6 settings (`schoonschip: full()`, `trace: false`,
`chain: true`) using `SymbolicNetParse::parse_to_symbolic_net`. This should
reproduce the same scalar/tensor error without any graph generation, local UV
Taylor expansion, CFF recursion or Vakint call. Compare that with (a) an ordinary
cyclic three-generator trace, and (b) explicit projector expansion of this small
standalone color expression through the existing `ProjectorExpander` API.
The latter is a finite color diagnostic; it does not distribute a graph
numerator. Record complete expressions, parse errors and exposed slots, without
changing parser behavior or any failing test.

The native prefix observations now distinguish C5 PASS, C6 MONITOR_FAILURE,
and C7/C8 immediate CHILD_FAILURE. A separate C6 full-expression diagnostic has
an explicit 1200-second observation limit; it is not a replacement native timing
or an automatic retry. The public color-factor reproducer will isolate the
inference contract without the full Taylor/CFF pipeline. Until it runs, the
minimal-case mechanism remains source-supported rather than experimentally
confirmed.

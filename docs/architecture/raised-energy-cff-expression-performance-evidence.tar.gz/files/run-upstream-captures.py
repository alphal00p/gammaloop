#!/usr/bin/env python3
"""Inspect expression inputs between primary jobs, then resume the paused sweep."""
import datetime
import json
import os
from pathlib import Path
import signal
import subprocess
import time

BASE = Path('/tmp/raised-energy-expression-perf-20260914')
pause = json.loads((BASE / 'expression-diagnostic-pause.json').read_text())
out = BASE / 'upstream-captures-01'
out.mkdir(exist_ok=False)
state = {'status': 'WAITING_FOR_CURRENT_BUILD', 'pid': os.getpid(), 'completed': []}
try:
    build_path = BASE / 'measurements' / pause['current']['label'] / 'build-native-01/receipt.json'
    while True:
        build = json.loads(build_path.read_text())
        if build.get('completed_utc'):
            if build['status'] != 'PASS':
                raise RuntimeError('Current primary build failed; resume sweep for normal handling')
            break
        (out / 'state.json').write_text(json.dumps(state, indent=2) + '\n')
        time.sleep(2)
    state['status'] = 'CAPTURING_UPSTREAM_EXPRESSIONS'
    for label, card in [('c1', 'orientation58_expression_boundaries'), ('c3', 'orientation58_expression_boundaries'),
                        ('c1', 'g_gl1_expression_boundaries'), ('c3', 'g_gl1_expression_boundaries')]:
        attempt = card + '-01'
        command = ['/tmp/raised-stack/python', str(BASE / 'controls/measure-diagnostic.py'), 'run', label,
                   '--attempt', attempt, '--card', card, '--build-receipt',
                   str(BASE / 'measurements' / label / 'build-native-01/receipt.json')]
        state['current'] = {'label': label, 'card': card, 'argv': command}
        (out / 'state.json').write_text(json.dumps(state, indent=2) + '\n')
        print(json.dumps({'starting': state['current']}), flush=True)
        env = os.environ.copy()
        for key in ['GAMMALOOP_DUMP_EVALUATOR_PRE_NETWORK_PARSE', 'GAMMALOOP_STOP_AFTER_EVALUATOR_PRE_NETWORK_PARSE',
                    'SPENSO_NETWORK_PROFILE', 'SPENSO_NETWORK_PROFILE_VERBOSE', 'SPENSO_NETWORK_PROFILE_ATOM_BYTES']:
            env.pop(key, None)
        result = subprocess.run(command, env=env)
        path = BASE / 'controls/measurements' / label / ('run-' + attempt) / 'receipt.json'
        receipt = json.loads(path.read_text())
        row = {'label': label, 'card': card, 'status': receipt['status'], 'receipt': str(path), 'exit_code': result.returncode}
        state['completed'].append(row)
        print(json.dumps({'finished': row}), flush=True)
        if receipt['status'] not in ('PASS', 'CHILD_FAILURE', 'MEMORY_CAP'):
            raise RuntimeError('Diagnostic infrastructure/source-integrity failure')
    state.update(status='CAPTURES_COMPLETE', current=None)
except BaseException as error:
    state.update(status='CAPTURE_STOPPED', error=repr(error))
    raise
finally:
    stat = Path(f"/proc/{pause['pid']}/stat").read_text().rsplit(')', 1)[1].split()
    if stat[19] != pause['proc_start_ticks']:
        raise RuntimeError('Refusing to resume a different process')
    os.kill(pause['pid'], signal.SIGCONT)
    pause.update(status='RESUMED', resume_required=False, resumed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    (BASE / 'expression-diagnostic-pause.json').write_text(json.dumps(pause, indent=2) + '\n')
    state['primary_sweep_resumed'] = True
    state['updated_utc'] = pause['resumed_utc']
    (out / 'state.json').write_text(json.dumps(state, indent=2) + '\n')
    print(json.dumps({'status': state['status'], 'primary_sweep_resumed': True}), flush=True)

# GL1 input identity and sunrise runtime selector certificate

Both native C8 commands completed successfully, and the separate read-only
semantic checks passed. The execution receipts remain unchanged;
`input-certificates-semantic-checks.json` contains the semantic result,
complete comparisons, source references and artifact hashes.

The complete C8 GL1 diagram DOT is byte-identical to the completed main GL1
DOT, including all seven edges and their half-edge incidence, particle labels,
loop routing, graph factor −1 and the complete color/Lorentz projector.
Vertex V_36 is the physical three-gluon vertex; the other three vertices are
V_135 quark-gluon vertices. All 15 graph-used saved model records agree exactly:
g/u/u~ particles and propagators, V_135/V_36, FFV1/VVV1, GC_10/GC_11, and their
ZERO/aS/G parameter dependency records. The complete parameter cards also match.
This establishes the same physical GL1 graph and model inputs for the observed
pipeline comparison.

The **whole saved models are different**. Every difference is recorded:
C8 adds covariant-cut multiplet metadata, marks three Goldstone particles,
changes the three weak-vector propagators, and has different stored expressions
for FFS1–3, FFV2–5 and UUV1. None of those records belongs to the graph-used
closure above. This certificate does not assert whole-model equality or compare
the full GL1 integrands.

The fresh C8 sunrise standalone archive exposes the actual runtime catalog:

| Production selector ID | Edge 0 | Edge 1 | Edge 2 |
|---|---:|---:|---:|
| 0 | −1 | +1 | +1 |
| 1 | +1 | −1 | −1 |

These rows were paired by their actual row positions in `orientations` and
`production_orientation_ids`, not by assuming selector IDs equal row numbers.
The exported scalar parameter names explicitly identify columns σ(0), σ(1),
σ(2); native `EdgeVec` iteration also enumerates ascending edge indices.

Every one of the eight ±1 truth vectors matches the prior complete bare-factor
proof: (−,+,+) selects only branch 0, (+,−,−) selects only branch 1, and the
other six select neither. Thus the third-edge sign limitation of the earlier
bare-pair report is now closed by actual runtime metadata. Its branchwise
factor equality and known `(2π)^6` export-measure conversion remain the same.

The fresh diagnostic GL0 graph and all eight forest-node DOTs are byte-identical
to the original native C8 sunrise artifacts. All 44 original state files and
the complete path inventory are unchanged. Consequently changing `store_atom`
and appending the standalone export produced a catalog tied to those exact
native graph/forest artifacts.

Validation command: `/tmp/raised-stack/python /tmp/raised-energy-expression-perf-20260914/verify-input-certificates.py`.
Result: `PASS_SEMANTIC_INPUT_CERTIFICATES`. No physics workload, tensor
contraction, graph-numerator expansion or numerical evaluation ran during these
checks. The native input commands are artifact diagnostics, not timing repeats.
This adds no claim of proper-UV or full-integrand equality, nor of a measured
performance cause.

"""Summarize prepared controls and compare each with its unchanged primary card."""
from pathlib import Path
import csv
import datetime
import importlib.util
import io
import json

BASE=Path('/tmp/raised-energy-expression-perf-20260914')
spec=importlib.util.spec_from_file_location('aggregate',BASE/'aggregate-measurements.py');aggregate=importlib.util.module_from_spec(spec);spec.loader.exec_module(aggregate)
plan=json.loads((BASE/'controls/post-sweep-plan.json').read_text())
primary=json.loads((BASE/'measurements.json').read_text())
inventory=json.loads((BASE/'attachments/run-card-inventory.json').read_text())
rows=[]
for job in plan['jobs']:
    base=next(c for c in inventory['revisions'][job['inventory_label']]['cards'] if c.get('path')==job['card_descriptor']['base_card'])
    native=next(r for r in primary['runs'] if r['label']==job['label'] and r['card']==base['card'])
    path=BASE/'controls/measurements'/job['label']/('run-'+job['attempt'])/'receipt.json'
    row=dict(order=job['order'],label=job['label'],card=job['card'],family=job['family'],delta=job['card_descriptor']['delta'],base_card=base['card'],base_receipt=native['receipt'],base_status=native['status'],base_completed_timing_eligible=native['completed_timing_eligible'],base_wall_seconds=native['completed_full_card_seconds'],base_rss_bytes=native['sampled_process_tree_rss_bytes'],status='NOT_RUN',completed_timing_eligible=False,receipt=str(path))
    if path.exists():
        receipt=json.loads(path.read_text());row.update(status=receipt['status'],receipt_sha256=aggregate.sha(path))
        issues=[]
        if receipt['revision']!=job['revision']['commit'] or receipt['tree']!=job['revision']['tree']:issues.append('source pin differs')
        if receipt['status']!='STARTED':
            if receipt.get('card')!=job['card_descriptor']:issues.append('card descriptor differs from plan')
            if job['card_descriptor']['base_card_sha256']!=base['sha256']:issues.append('base card hash differs from inventory')
            for key,planned_key in [('binary','binary'),('binary_sha256','binary_sha256'),('build_receipt','receipt'),('build_receipt_sha256','receipt_sha256')]:
                if receipt.get(key)!=job['native_build'][planned_key]:issues.append(key+' differs from plan')
            for key in ['tracked_before','tracked_after']:
                if not receipt.get(key,{}).get('passed'):issues.append('source audit failed: '+key)
        summaries,traces,stages=aggregate.stage_data(receipt,issues)
        stage=next((s for s in receipt.get('stages',[]) if s.get('argv',[])[-2:]==['run','generate']),{})
        complete=receipt['status']==stage.get('status')=='PASS' and not issues
        row.update(completed_timing_eligible=complete,wall_seconds=stage.get('wall_seconds') if complete else None,observation_seconds=stage.get('wall_seconds'),rss_bytes=stage.get('peak_tree_rss_bytes'),evidence_issues=issues,summaries=summaries,trace_files=traces,stage_observations=stages,binary_sha256=receipt.get('binary_sha256'),source_hashes=receipt.get('source_hashes'),effective_card_sha256=receipt.get('effective_card_sha256'))
        if complete and native['completed_timing_eligible']:
            row['wall_ratio_to_primary']=row['wall_seconds']/native['completed_full_card_seconds']
            if row['rss_bytes'] is not None and native['sampled_process_tree_rss_bytes']:
                row['rss_ratio_to_primary']=row['rss_bytes']/native['sampled_process_tree_rss_bytes']
    rows.append(row)
out=dict(generated_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),aggregator_sha256=aggregate.sha(__file__),plan_sha256=aggregate.sha(BASE/'controls/post-sweep-plan.json'),primary_aggregate_sha256=aggregate.sha(BASE/'measurements.json'),rows=rows,scope='Repetitions and one-setting controls, separate from the four full-expression captures and native matrix; cap/failure observations are not completed timings.')
aggregate.write(BASE/'controls/post-sweep-results.json',json.dumps(out,indent=2)+'\n')
keys=['order','label','card','family','status','base_card','base_status','wall_seconds','base_wall_seconds','wall_ratio_to_primary','rss_bytes','base_rss_bytes','rss_ratio_to_primary','observation_seconds','receipt']
buffer=io.StringIO();writer=csv.DictWriter(buffer,fieldnames=keys);writer.writeheader();writer.writerows({k:r.get(k) for k in keys} for r in rows);aggregate.write(BASE/'controls/post-sweep-results.csv',buffer.getvalue())
lines=['# Fresh repetitions and one-setting controls','','Each job is compared with its pinned unchanged primary card. Times are individual observations, not confidence intervals. A failed/capped case has no completed wall time.','','| # | Revision / card | Family | Status | Wall s | Primary s | RSS GB | Primary GB |','|---|---|---|---|---:|---:|---:|---:|']
for r in rows:
    fmt=lambda v:'—' if v is None else f'{v:.3f}'
    lines.append(f"| {r['order']} | {r['label']} / {r['card']} | {r['family']} | {r['status']} | {fmt(r.get('wall_seconds'))} | {fmt(r['base_wall_seconds'])} | {fmt(r.get('rss_bytes')/1e9 if r.get('rss_bytes') is not None else None)} | {fmt(r['base_rss_bytes']/1e9 if r['base_rss_bytes'] is not None else None)} |")
aggregate.write(BASE/'controls/post-sweep-results.md','\n'.join(lines)+'\n')
print(json.dumps({'jobs':len(rows),'terminal':sum(r['status'] not in ['NOT_RUN','STARTED'] for r in rows),'issues':sum(len(r.get('evidence_issues',[])) for r in rows)}))

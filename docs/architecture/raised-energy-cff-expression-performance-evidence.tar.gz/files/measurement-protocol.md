# Immutable revision measurements

`measure.py` is scratch infrastructure. It does not fetch, check out revisions,
rewrite history, alter tracked source, or change the supplied physics settings.
Root prepares `/tmp/raised-stack/prefix` as an empty jj child of the desired
revision before each command. Its complete tracked bytes, executable modes,
symlink targets and jj tree must match the pinned revision in `revisions.json`.
The independent child commit ID may differ. Source integrity is checked before
and after execution; concurrent workspace mutation is prohibited.

Invoke with `/tmp/raised-stack/python`:

```sh
/tmp/raised-stack/python /tmp/raised-energy-expression-perf-20260914/measure.py build main-current --attempt native-01
/tmp/raised-stack/python /tmp/raised-energy-expression-perf-20260914/measure.py run main-current --attempt sunrise-local-01 --card sunrise_local_export --build-receipt /tmp/raised-energy-expression-perf-20260914/measurements/main-current/build-native-01/receipt.json
```

`build` checks and builds `gammaloop-api --bin gammaloop --locked --profile
dev-optim`, sequentially, against each revision's unchanged dependency lock.
It uses four Cargo workers and the shared ROOT target cache. Immediately after
success it copies the executable with `copy2` into the unique build directory,
hashes both copy and source, and records its identity. Each run requires that
successful build receipt, matching pinned commit/tree and unchanged binary hash.
A previous manual check does not substitute for this build receipt; a subsequent
driver check is permitted to reuse Cargo's cache. Build time is not a runtime
performance measurement.

`run` selects exactly one revision-specific card entry from
`attachments/run-card-inventory.json`, checking its stored hash. The ephemeral
card changes only `cli_settings.state.folder` to a new absolute path; parsed
TOML equality verifies every other field is unchanged. Attached graph paths are
already absolute in that inventory, and their hashes are checked against the
unchanged DOT member of the user-supplied ZIP before execution. Exact cards
marked unsupported are rejected. The separately named
`orientation58_muv_sparse_atom_aware` is an explicitly different setting control,
never an exact substitute for `orientation58_muv`.

The direct invocation is `BINARY -n -s STATE CARD run generate` with closed
stdin, matching the supplied reproducer and preventing interactive input. Existing card
generation cores remain one; global Rayon is fixed to eight threads and
`RUST_MIN_STACK=134217728` on every revision, matching the attached reproducer's
recommended environment. No save command is added. In particular, the attached
card has no explicit save: its generation summaries may exist only in logs.
The first three cards retain their explicit save commands. Logging filter overrides are removed both from the inherited environment and
after the licensed launcher, preserving the card's own logging configuration.
No snapshot updates or retries are enabled; an attempt never overwrites another.

Every check/build/run invokes the existing ps10 watchdog adapter, which pins the
repository watchdog implementation, with a 30 decimal GB process-tree RSS cap.
The driver's own lock prohibits parallel driver invocations; the watchdog's
existing global lock coordinates other guarded jobs. Run no unguarded benchmark
or build concurrently. On Linux the RSS peak is sampled, not an operating-system
high-water mark. Samples occur approximately every 0.25 seconds, with periodic
JSON records every five seconds. The adapter retains the earlier ten-second
`ps` observation deadline; monitoring failure is fail-closed.

Each stage records its literal argv, cwd, stdout/stderr, memory log and terminal
result. Only explicit non-secret environment overrides appear in argv. The
licensed launcher is invoked but never inspected, hashed, copied or archived.
`PASS`, `CHILD_FAILURE`, `MEMORY_CAP`, `MONITOR_FAILURE`, `DRIVER_FAILURE`, and
`SOURCE_INTEGRITY_FAILURE` remain distinct. Memory-cap and monitor failures do
not count as completed timings. There are no automatic retries or time-limit
claims. The orchestrator owns any explicit cancellation and must preserve its
partial evidence.

The receipt records Cargo.toml/Cargo.lock, native SM model/restriction hashes,
full source audits, executable identity, card provenance, imported graph hashes,
full command wall time, watchdog elapsed time, and sampled process-tree RSS.
Persisted `generation_summary.json` paths/hashes and JSONL trace paths are indexed
when present. Analyze generation timing stages separately from full card time:
the latter includes model import, graph generation, and explicit export/save
serialization. Rich expression traces are separate diagnostics, not silently
enabled during the native timing matrix. Do not expand graph numerators when
comparing representations.

Current main is not the stack's immediate parent. If C1 is the first observed
change, also run `main-base`. Main retains Symbolica lock `0441bd7a...`; all eight
commits retain `4d0a833e...`. Native model files also differ. Check graph topology,
used model contracts and requested modes before attributing a difference solely
to expression manipulation. Start with every required card/revision combination,
then repeat material onset pairs using fresh states to quantify variability.

Preparation verification is syntax/static review only. No workload execution is
claimed by this document.

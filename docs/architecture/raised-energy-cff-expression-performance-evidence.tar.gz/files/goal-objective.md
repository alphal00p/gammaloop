push, then investigate what seems to be a performance slowdown because of the expression manipulation. To see this I have a couple of run cards.&#x20;


````
commands = []
[cli_settings]
[cli_settings.state]
folder = "./ignore/my_runs/two_loop_g_se_gl01/state"
name = "two_loop_g_se_gl01"
[[command_blocks]]
name = "generate"
commands = [
```python
"import model sm-default.json",

"remove processes",
"""generate amp g > g [{2}] | g u
        --numerator-grouping group_identical_graphs_up_to_scalar_rescaling
        --max-n-bridges 0
        --number-of-factorized-loop-subtopologies 1 1
        --number-of-anticommutating-loops 1 1
        --only-diagrams
        --select-graphs GL1
        --global-prefactor-projector '(1/8)*spenso::g(spenso::coad(8,gammalooprs::hedge(0)),spenso::coad(8,gammalooprs::hedge(1)))*spenso::g(spenso::mink(4,gammalooprs::hedge(0)),spenso::mink(4,gammalooprs::hedge(1)))'
        -p double_triangle
        -i 2L
""",
"generate",
"save dot",
"save state -o",
```
]
[default_runtime_settings.sampling]
graphs = "monte_carlo"
orientations = "monte_carlo"
lmb_multichanneling = true
lmb_channels = "monte_carlo"
coordinate_system = "spherical"
mapping = "linear"
b = 1.0
[default_runtime_settings.subtraction]
disable_threshold_subtraction = true
[cli_settings.global.generation.uv]
subtract_uv = true
softct = false
generate_integrated = true
[cli_settings.global.n_cores]
feyngen = 1
generate = 1
[cli_settings.global.generation.tropical_subgraph_table]
disable_tropical_generation = true
[cli_settings.global.generation.evaluator]
iterative_orientation_optimization = false
store_atom = false
compile = false
summed = false
summed_function_map = false
do_algebra = true
do_fn_map_replacements = false
[cli_settings.global.generation.threshold_subtraction] enable_thresholds = false check_esurface_at_generation = false
````




```sql
(compare running this on main and then each commit). Also here is a simpler example you can start with
```


```ini
commands = []

[cli_settings]
[cli_settings.state]
folder = "./ignore/my_runs/qcd_sunrise/state"
name = "qcd_sunrise"

[[command_blocks]]
name = "generate"
commands = [

    "import model sm-default.json",

    "remove processes",
    """generate amp {} > {} [{2}] | g u
            --numerator-grouping group_identical_graphs_up_to_scalar_rescaling
            --max-n-bridges 0
            --number-of-factorized-loop-subtopologies 1 1
            --number-of-anticommutating-loops 1 1
            --only-diagrams
            -p quark_sunrise
            -i 2L
    """,
    "generate",
    "save dot",
    "save state -o",

]

[default_runtime_settings.sampling]
graphs = "monte_carlo"
orientations = "monte_carlo"
lmb_multichanneling = true
lmb_channels = "monte_carlo"
coordinate_system = "spherical"
mapping = "linear"
b = 1.0

[default_runtime_settings.subtraction]
disable_threshold_subtraction = true

# [cli_settings.global.generation.medium]
# mode = "vacuum"
# vacuum_subtraction = false

[cli_settings.global.generation.uv]
subtract_uv = true
softct = false
generate_integrated = true
# local_uv_cts_from_expanded_4d_integrands = true

# [cli_settings.global.generation]
# explicit_orientation_sum_only = true

[cli_settings.global.n_cores]
feyngen = 1
generate = 1

[cli_settings.global.generation.tropical_subgraph_table]
disable_tropical_generation = true

[cli_settings.global.generation.evaluator]
iterative_orientation_optimization = false
store_atom = false
compile = false
summed = false
summed_function_map = false
do_algebra = true
do_fn_map_replacements = false

[cli_settings.global.generation.threshold_subtraction]
enable_thresholds = false
check_esurface_at_generation = false
```





I think I found a clue as to why there is a performance regression in generation, both in memory usage and runtime.

I compared with current `main` by generating the vacuum QCD sunrise integrand with 3D local UV and `generate_integrated = false` using the following run card:
```ini
commands = []

[cli_settings]
[cli_settings.state]
folder = "./ignore/my_runs/qcd_sunrise/state"
name = "qcd_sunrise"

[[command_blocks]]
name = "generate"
commands = [

    "import model sm-default.json",

    "remove processes",
    """generate amp {} > {} [{2}] | g u
            --numerator-grouping group_identical_graphs_up_to_scalar_rescaling
            --max-n-bridges 0
            --number-of-factorized-loop-subtopologies 1 1
            --number-of-fermion-loops 1 1
            --only-diagrams
            -p quark_sunrise
            -i 2L
    """,
    "generate",
    "save uv-forest --computed -p quark_sunrise -i 2L -g GL0",
    "save dot",
    "save state -o",

]

[default_runtime_settings.subtraction]
disable_threshold_subtraction = true

[cli_settings.global.generation.uv]
subtract_uv = true
softct = false
generate_integrated = false
# local_uv_cts_from_expanded_4d_integrands = true

# [cli_settings.global.generation]
# explicit_orientation_sum_only = true

[cli_settings.global.n_cores]
feyngen = 1
generate = 1

[cli_settings.global.generation.tropical_subgraph_table]
disable_tropical_generation = true

[cli_settings.global.generation.evaluator]
iterative_orientation_optimization = false
store_atom = false
compile = false
summed = false
summed_function_map = false
do_algebra = true
do_fn_map_replacements = false

[cli_settings.global.generation.threshold_subtraction]
enable_thresholds = false
check_esurface_at_generation = false
```

Here, `run generate` saves the UV-forest node expressions to the state folder. Looking even at the bare expression already reveals that the integrand is no longer kept properly factorized on the new branch.

On `main`,  the bare expression reads
```bash
(-1𝑖/16384 \"GC_11\"^2 (op(θ)(op(σ)(0)) op(θ)(-op(σ)(1)) op(θ)(-op(σ)(2))+op(θ)(op(σ)(1)) op(θ)(op(σ)(2)) op(θ)(-op(σ)(0))) op(\"tree_denoms\")(1) γ^(α_(⁵),b_(⁰) b_(³)) γ^(q_0,b_(¹) b_(⁰)) γ^(α_(⁵),b_(²) b_(¹)) γ^(q_1,b_(³) b_(²)))/(pi^12 (E^(\"os\")_0+E^(\"os\")_1+E^(\"os\")_2) E^(\"os\")_0 E^(\"os\")_1 E^(\"os\")_2)
```

whereas on `codex/raised_energy_cff_wip_optimized_phase_fix` it is
```less
4 ((-1𝑖/1024 \"GC_11\"^2 (arrow(q)_0^(α_(ᵉ⁰.¹))+op(δ)([0],α_(ᵉ⁰.¹)) E^(\"os\")_0) (arrow(q)_1^(α_(ᵉ¹.¹))-op(δ)([0],α_(ᵉ¹.¹)) E^(\"os\")_1) op(\"tree_denoms\")(1) γ^(α_(⁵),b_(⁰) b_(³)) γ^(α_(⁵),b_(²) b_(¹)) γ^(α_(ᵉ⁰.¹),b_(¹) b_(⁰)) γ^(α_(ᵉ¹.¹),b_(³) b_(²)) op(\"sigma\")(1))/(pi^6 (E^(\"os\")_0+E^(\"os\")_1+E^(\"os\")_2) E^(\"os\")_0 E^(\"os\")_1 E^(\"os\")_2)+(-1𝑖/1024 \"GC_11\"^2 (arrow(q)_0^(α_(ᵉ⁰.¹))-op(δ)([0],α_(ᵉ⁰.¹)) E^(\"os\")_0) (arrow(q)_1^(α_(ᵉ¹.¹))+op(δ)([0],α_(ᵉ¹.¹)) E^(\"os\")_1) op(\"tree_denoms\")(1) γ^(α_(⁵),b_(⁰) b_(³)) γ^(α_(⁵),b_(²) b_(¹)) γ^(α_(ᵉ⁰.¹),b_(¹) b_(⁰)) γ^(α_(ᵉ¹.¹),b_(³) b_(²)) op(\"sigma\")(0))/(pi^6 (E^(\"os\")_0+E^(\"os\")_1+E^(\"os\")_2) E^(\"os\")_0 E^(\"os\")_1 E^(\"os\")_2))
```

Previously the two CFF orientations were kept together by keeping `op(θ)(op(σ)(0)) op(θ)(-op(σ)(1)) op(θ)(-op(σ)(2))+op(θ)(op(σ)(1)) op(θ)(op(σ)(2)) op(θ)(-op(σ)(0))` factorized from the rest of the expression whereas now the two orientations are expanded into separate terms. This could explain the doubled memory footprint in this particular example. This might not be all. I've attached another reproducing card as well. Go through all 4 (maybe its only 3) and all 8 commits and see when and hopefully why performance gets abysmal.
# Actual main–C8 sunrise bare-root comparison

The actual empty-forest, uncut GL0 exports agree **branch by branch** after the known export-measure conversion and compact-vector materialization. This comparison is now based on both completed outputs, not a predicted C8 shape.

Sources:

- Main revision `bc8bfbad717b80cb83ca1bf7ac2aec704917d424`, `measurements/main-current/run-sunrise-local-01/state/processes/amplitudes/quark_sunrise/2L/GL0_nodes/forest_000/node_000_key_term_000_all_none.dot`.
- C8 revision `01982f688b6810d5152f0317713db412ae7ea794`, corresponding path below `measurements/c8/run-sunrise-local-01/`.

`sunrise-main-c8-bare-pair.json` binds both DOTs, graph files, saved models and execution receipts by hash. `compare-sunrise-bare-pair.py` performs the bounded comparison. It decodes the DOT `num` strings, splits only balanced top-level sums/products, and compares complete factor trees allowing commutative Add/Mul order and redundant parentheses. It does not distribute any product or power, run Symbolica/Idenso, evaluate a numerical sample, or run a workload. All complete original `num` factors were inspected, including coefficients and index incidence.

## What is identical

The two **GL0.dot files are byte-identical**: two V_135 vertices; massless u lines 0 and 1, gluon line 2; Q0=K0, Q1=K1, Q2=K0−K1; graph overall factor −1/2; projector one. The exported node metadata agree (empty node key, `all_none`, overall factor one already included in `num`).

The actual saved models also have identical relevant V_135, FFV1, GC_11, g/u/u~ particle and propagator records, and G/aS/ZERO parameter records. Unrelated model fields need not agree and were not used to claim complete model equality.

Both C8 branches contain the same four inverse-denominator factors as main:

`E0^-1 * E1^-1 * E2^-1 * (E0+E1+E2)^-1`.

Both retain exactly `GC_11^2 * tree_denoms(1)` and the same closed four-gamma spinor incidence. The main compact Q0 and Q1 gamma arguments become fresh indexed gamma factors with `edge(0,1)` and `edge(1,1)`, respectively. The original repeated Lorentz index `hedge(5)` on the other two gammas is retained. The corresponding vector factors pair with those exact new indices; there are no extra tensor factors or missing contractions.

## Complete branch match

| C8 selector | Actual Q0 temporal factor | Actual Q1 temporal factor | Unique matching main selector |
|---|---|---|---|
| `three_dimensional_reps::sigma(0)` | −E0 | +E1 | `theta(-s0)*theta(s1)*theta(s2)` |
| `three_dimensional_reps::sigma(1)` | +E0 | −E1 | `theta(s0)*theta(-s1)*theta(-s2)` |

For each branch, replacing only the two compact main gamma-vector arguments with explicit indexed gamma/vector factors, applying those two temporal signs, and converting the measure gives an exact match of **all fourteen nonselector factors**. This includes the complete vector sums, all four gamma tensors, all inverse denominators, coupling, tree wrapper, imaginary rational coefficient and pi power.

The eight physical-sign rows remain: `(−,+,+)` selects C8 branch 0; `(+,-,-)` selects branch 1; the other six select zero. Therefore both contributions are selected once under this correspondence, and the sum of selected bodies equals the explicit two-body sum without expanding either body.

**Metadata limitation:** the C8 numerator contains no Q2 temporal factor. The third physical sign in the table comes from the unique matching main support; this DOT alone does not independently reveal the C8 runtime catalog's edge-2 direction. We have established an unambiguous *body pairing*, not decoded or validated the complete stored runtime orientation catalog.

## Constants and the user’s earlier shape

Main has the coefficient `−i/16384` and `pi^-12`. Each actual C8 branch has `−i/256` and `pi^-6`. Consequently multiplying the complete selected main export by **`64*pi^6 = (2*pi)^6`** yields the actual C8 coefficient exactly. There is no leftover sign or numerical factor. This is the duplicate export-measure removal; the two-loop phase ratio remains `i^2/(-i)^2=1`.

The userquoted older branch had an outer `4` multiplying terms with coefficient `−i/1024`. The actual reviewed C8 export absorbs that factor into `−i/256` on each term. It still contains **two separately mapped indexed-vector numerator products**, not one shared compact numerator times a selector sum. This is the same branchwise representation issue, with a simpler scalar coefficient layout.

The decoded plain `num` strings contain 536 UTF-8 bytes on main and 1,397 on C8. These are serialized text lengths only: they do not measure native Atom size, sharing, heap allocation or peak RSS, and do not certify a memory regression.

## Contraction opportunity and remaining scope

The exact matched four-gamma factors give the analytic identity

`N = tr(gamma_mu slash(Q0) gamma^mu slash(Q1)) = −8 Q0·Q1`.

Both paired branches have `s0*s1=−1`, so both contract to

`8*(E0*E1 + dot_E(vecQ0,vecQ1))`.

Thus this actual C8 pair has a common scalar body after full spin/Lorentz contraction. This follows analytically from the compared factors; the script did not execute the library contraction. The contracted C8 root is consequently

`−i*GC_11^2*tree_denoms(1)*(sigma(0)+sigma(1))*(E0*E1+dot_E(vecQ0,vecQ1)) / [32*pi^6*E0*E1*E2*(E0+E1+E2)]`.

Whether the production evaluator finds this form, when it does so, and its operation count require the next actual stage artifact. No proper UV node, integrated counterterm, full final integrand, numerical evaluator, or C3 runtime output is certified by this bare-pair comparison. C3 owns the source change to branchwise mapping; its contribution to measured cost remains a hypothesis pending the primary matrix and intermediate-stage evidence.

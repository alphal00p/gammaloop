# Actual-main sunrise bare-node comparison boundary

Scope: read the completed main run's actual DOT/receipt/model records and derive a bounded factor-preserving comparison. No library algebra, workload, build, instrumentation, or numerical physics evaluation was run. No future C3/C8 export has been compared here. `sunrise-main-bare-facts.json` records hashes, the exact plain `num` string, all eight selector rows, and the selected model records.

## Observed input

Run revision: `bc8bfbad717b80cb83ca1bf7ac2aec704917d424`; tree: `1c0e272f684cb070c0980293cdb2c8c88ed4676b`.

Bare node: `measurements/main-current/run-sunrise-local-01/state/processes/amplitudes/quark_sunrise/2L/GL0_nodes/forest_000/node_000_key_term_000_all_none.dot`, node key `∅`, residue `all_none`.

The **`num` attribute is plain Symbolica syntax** and matches the user's quoted bare expression. `full_num` is the Typst display. Parse `num` with the initialized GammaLoop symbol namespace, including `spenso`, `UFO`, Q, OSE, theta, sigma and pi; do not feed Typst notation to an algebra parser.

`GL0.dot` has two V_135 vertices and three lines:

- edge 0: u, vertex 1 → 0, Q0 = K0;
- edge 1: u, vertex 0 → 1, Q1 = K1;
- edge 2: g, vertex 0 → 1, spatial Q2 = K0 − K1.

The original graph's evaluated overall factor is `−1/2`. The exported node's `overall_factor=1` means that factor is already inside `num`; multiplying it in again would be wrong. Projector is one. Source JSON records for V_135, GC_11, FFV1 and the g/u propagators are identical in inspected main, C3 and C8. This eliminates those particular model records as a source of a later root-value discrepancy, while generated graph identity and normalization must still be checked on the actual future outputs.

Write the observed root as

`C_main * (S_plus + S_minus) * N(Q0,Q1)`,

where

`C_main = -i * GC_11^2 * tree_denoms(1) / [16384*pi^12*E0*E1*E2*(E0+E1+E2)]`,

`S_plus = theta(s0)*theta(-s1)*theta(-s2)`,

`S_minus = theta(-s0)*theta(s1)*theta(s2)`.

`N` is the exact four-gamma product in `num`, with its closed spinor chain and the repeated Lorentz slot `mink(4,hedge(5))`. Keep the scalar prefactor and the denominator factors intact.

## Selector truth table before any deeper comparison

Here theta(+1)=1 and theta(−1)=0. These eight rows were enumerated as Boolean selector arithmetic in the fact record, not as numerical evaluation of the physics integrand.

| (s0,s1,s2) | S_plus | S_minus | Selected factorized body |
|---|---:|---:|---|
| (−,−,−) | 0 | 0 | 0 |
| (−,−,+) | 0 | 0 | 0 |
| (−,+,−) | 0 | 0 | 0 |
| (−,+,+) | 0 | 1 | B_minus |
| (+,−,−) | 1 | 0 | B_plus |
| (+,−,+) | 0 | 0 | 0 |
| (+,+,−) | 0 | 0 | 0 |
| (+,+,+) | 0 | 0 | 0 |

For a future residue-ID expression, obtain the actual ID→map/direction catalog first. Do not infer which ID is `plus` from insertion order or assume there are only two IDs. If there are exactly two simple maps, the discrete truth table must select B_plus and B_minus once each; summing the selected results must equal the selector-free sum. Multiple generalized maps with the same physical directions require their own rows and cannot be merged using the physical signs alone.

## Compact gamma → indexed-vector boundary

Main's compact factor

`gamma(bis(4,b1), bis(4,b0), Q(0,mink(4)))`

means, with a fresh Lorentz index α,

`gamma(bis(4,b1), bis(4,b0), mink(4,α)) * Q(0,mink(4,α))`.

Likewise the Q1 gamma receives a **different** fresh index β. Retain the original common μ=`hedge(5)` on the other two gammas, the spinor incidence, and every outer product/sum. Fresh labels must not collide with μ or existing spinor/Lorentz labels. This is materialization of two compact tensor arguments, not algebraic expansion of a graph numerator.

The existing owner is Spenso's `network/parsing/materialization.rs:11–23,168–194`: a compact vector argument becomes a fresh slot plus its vector factor. Use the existing parser/materialization path or those two exact local rewrites in a bounded diagnostic; do not add a production helper. Merely replacing indexed `Q(e,mink(4,α))` will miss the original compact `Q(e,mink(4))` nested inside gamma.

After that representation alignment, apply only the compared branch's actual energy map. For the ordinary main sign interpretation this is

`Q(e,α) -> vecQ(e,α) + delta(0,α)*s_e*E_e`, e=0,1.

Keep each vector sum parenthesized. C3/C8's owning map is `cff/expression.rs:163–172`; the actual exported maps must establish that they reduce to these simple ±OSE values. Do not impose `E2=E0−E1` or another on-shell energy identity. The DOT routing specifies spatial momenta; the CFF residue construction does not put every propagator energy on shell simultaneously.

Compare B_plus and B_minus separately, with the same fresh-index labels and exact coefficients. The strongest shallow check is factorwise equality after these two local materializations, on-shell substitutions and allowed dummy renaming. A full numerator expansion or blanket `together()` is unnecessary and outside the diagnostic constraint.

## Do the two main bodies collapse after contraction?

**Yes, algebraically for this particular observed bare numerator after the indicated energy substitutions.** This statement is an analytic derivation from the actual four-gamma factor, not a claim that we executed the library contraction or inspected a future stack output.

The closed spinor chain is cyclically `tr(gamma_mu slash(Q0) gamma^mu slash(Q1))`. In four dimensions, `gamma_mu slash(Q0) gamma^mu = -2 slash(Q0)` and `tr(slash(Q0) slash(Q1)) = 4 Q0·Q1`, hence

`N = -8 Q0·Q1`.

These conventions agree with the repository's two/four-gamma trace identities (`crates/idenso/src/dirac/test/form_reference.rs:5–24`) and the Minkowski signature whose spatial components are negative (`crates/spenso/src/structure/representation.rs:324–325`). We can contract this isolated finite tensor coefficient while leaving C_main and selectors factored.

Both selected orientations have `s0*s1=-1`. With `v = dot_E(vecQ0,vecQ1)`,

`Q0·Q1 = s0*s1*E0*E1 - v = -E0*E1-v`,

so

`B_plus = B_minus = 8*(E0*E1+v)`.

The temporal-spatial cross terms vanish because the spatial vectors have zero temporal component and the Minkowski metric is diagonal. No distributive expansion of the original graph numerator is required. This leaves an available common scalar body **after contraction**, even though the two factorized vector products before contraction differ. It does not establish how soon the actual evaluator discovers or retains that equality, nor does it generalize to proper UV nodes or the double-triangle workload.

The resulting main exported root is

`-i*GC_11^2*tree_denoms(1)*(S_plus+S_minus)*(E0*E1+v) / [2048*pi^12*E0*E1*E2*(E0+E1+E2)]`.

This formula is a derived exact oracle for this boundary. A future executor must still check implementation output against it.

## Exact bare-root normalization for C3 versus C8

C3 retains the export post-division by `(2*pi)^(3L)` in `uv/export.rs:81–91` (the same issue exists on main). C5 removes it; C8's amplitude export postprocessor is the identity (`uv/export.rs:81–90`). C3's CFF conversion is `(-i)^L/(2*pi)^(3L)`; C5 changes its phase to `i^L/(2*pi)^(3L)`.

For this **empty-forest two-loop root**, `i^2/(-i)^2=1`. Therefore, once actual graph/body identity is established,

`C8 bare export = (2*pi)^6 * C3 bare export`.

The same expected conversion applies to the main bare export. Multiply the complete main/C3 atom by **`64*pi^6`**, without stripping an inferred sign or coupling. The uncontracted scalar coefficient becomes `-i*GC_11^2/(256*pi^6)` times unchanged denominator/tree factors. The contracted expected root becomes

`-i*GC_11^2*tree_denoms(1)*(id_plus+id_minus)*(E0*E1+v) / [32*pi^6*E0*E1*E2*(E0+E1+E2)]`.

For an explicit sum there are two equal bodies: replacing both IDs with one introduces a factor of two. Comparing one selected orientation against that explicit sum would be a separate normalization error.

This `64*pi^6` factor is **only** the empty two-loop root comparison. Proper forest nodes can include different remaining-loop counts, C6 integrated conventions, and owner-specific terms; do not apply it blindly to the entire UV forest.

## Next comparison and exclusions

The next needed evidence is the actual C3/C8 bare-node export plus its exact map catalog and matching `GL0.dot`. Check graph fields, preserve known prefactors, materialize the two compact vector slots, execute the full selector table, then compare complete selected bodies. This isolates the representation boundary before investigating gamma simplification, CFF recursion, reconstruction or optimizer internals. Existing evidence proves the main input and the analytic opportunity to share the contracted scalar; it does not prove the future output, its memory footprint, or a speedup from changing representation.

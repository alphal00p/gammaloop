# Run-card inventory for expression-growth measurements

There are four distinct workloads. The two attached ZIP paths have identical
SHA-256 `3a95438a5c1c121d16db43798ce042bb9c9ab2c6ac9e00f8422926375e351fbd`.
Only the currently attached ZIP supplied its three extracted files; no unrelated
attachment was inspected.

| Card | Physical workload | Integrated UV | Algebra | Sampling |
|---|---|---|---|---|
| `g_gl1_integrated` | two-loop g → g, GL1, one closed quark loop, projected external color/Lorentz indices | true | true | Monte Carlo graphs/orientations/LMB, multichanneling true |
| `sunrise_integrated` | two-loop vacuum QCD sunrise, one closed quark loop | true | true | same Monte Carlo settings |
| `sunrise_local_export` | same vacuum QCD sunrise, with computed GL0 UV-forest export | false | true | default summed graphs/orientations/LMB, multichanneling false |
| `orientation58_muv` | three-loop photon two-point graph: quark double triangle with central gluon dressed by a quark bubble; one explicit edge-sign pattern | false | false | default summed settings |

The attachment fixes MUV prescriptions, 3D local UV, the hedge-poset orchestrator,
sequential MinResultRank Spenso execution, intermediate_cost network ordering,
one Horner iteration, external energy 300, helicities [1,-1], and m_uv=mu_r=20.
Every one of these values is preserved in the exact cards.

`canonical/` contains valid TOML versions of all four supplied cards. The first
card only needed removal of accidentally nested Markdown fences and separation
of the threshold table and its two assignments onto separate TOML lines. The
remaining three canonical cards preserve the supplied text exactly.

`cards/REV/` contains cards for each pinned oldmain, main, and C1–C8 revision.
The generator option is spelled number-of-fermion-loops through C4 and
number-of-anticommutating-loops from C5. With allowed particles g/u there are no
ghosts, so these options select the same one-loop condition for these inputs.
The attached DOT reference is an absolute path to the unchanged extracted file.
The two explicitly false mode fields absent before C3 are omitted there; those
older implementations have only the requested selector/3D route.

The attachment's intermediate_cost ordering does not exist in either main or
C1–C2. Exact runs are marked **EXACT_UNSUPPORTED**, and no misleading exact card
is emitted for those four revisions. `controls/REV/` provides the separately
named `orientation58_muv_sparse_atom_aware.toml` at every revision. This changes
exactly one evaluator setting to a common available strategy. It preserves the
same physics and orientation but is a labeled control, not the exact requested
execution strategy. Comparing it with intermediate_cost at C3/C8 isolates that
one choice.

The first three cards omit contraction order, so their native default changes
from sparse_atom_aware to intermediate_cost at C3. This default switch must be
reported in the primary sweep. Cards 2 and 3 also differ in sampling settings,
not only the integrated-UV toggle; their supplied distinctions were retained.

State-folder strings remain as supplied. Invoke each CLI with a fresh absolute
`-s` state path, `-n`, the positional TOML path and `run generate`; the root
executor owns runtime path isolation and measurement. Do not use the attachment
README's historical timings as fresh evidence. Preserve native source models,
record generated graph identities, and keep source/lockfile provenance per run.

`run-card-inventory.json` binds all four inputs and all ten revision pins, lists
36 faithful cards plus 10 separately labeled controls, and records each precise
adaptation and SHA-256. It verifies parsed-value equality after only those
adaptations for all 46 emitted cards. This subtask performed no builds, CLI
runs, source edits, or jj mutations.

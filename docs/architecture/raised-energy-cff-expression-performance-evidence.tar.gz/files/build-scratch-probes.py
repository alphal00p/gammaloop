"""Build prepared isolated probes once with native locks and the reviewed monitor."""
from pathlib import Path
import argparse
import datetime
import fcntl
import hashlib
import importlib.util
import json
import shutil

BASE = Path('/tmp/raised-energy-expression-perf-20260914')
ROOT = Path('/common/dev/gammaloop/higher-power-energies-review')
p = argparse.ArgumentParser()
p.add_argument('probe', choices=['common-factor-contraction', 'color-parser'])
args = p.parse_args()
label, binary_name = {'common-factor-contraction': ('c3', 'cff-common-factor-contraction-probe'),
                      'color-parser': ('c8', 'gl1-color-parser-reproducer')}[args.probe]
# Refuse competing primary or controlled jobs; hold the outer lock across all
# stages. The native watchdog also owns its heavy-process lock per build stage.
lock = (BASE / 'measurement.lock').open('a')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
primary = BASE / 'remaining-sweep-02/state.json'
assert json.loads(primary.read_text())['status'] == 'FINISHED_SWEEP'
for statepath in [primary, BASE / 'controls/post-sweep-01/state.json']:
    if not statepath.exists():
        continue
    state = json.loads(statepath.read_text())
    assert state['status'] not in ['RUNNING', 'STARTED'], str(statepath)
    if 'pid' in state and 'proc_start_ticks' in state:
        proc = Path('/proc') / str(state['pid']) / 'stat'
        try:
            actual = proc.read_text().rsplit(') ', 1)[1].split()
        except FileNotFoundError:
            actual = None
        assert not actual or actual[19] != state['proc_start_ticks'] or actual[0] == 'Z', str(statepath)
source = BASE / 'measure.py'
assert hashlib.sha256(source.read_bytes()).hexdigest() == '6f6ca7cbb51f5b606b93da4e00fe42465f3a194bc5efaf6e492df737cafad4d9'
spec = importlib.util.spec_from_file_location('measure', source)
measure = importlib.util.module_from_spec(spec)
spec.loader.exec_module(measure)
measure.PREFIX = BASE / 'diagnostic-workspaces' / label
revision = next(r for r in json.loads((BASE / 'revisions.json').read_text()) if r['label'] == label)
probe = BASE / 'diagnostics' / args.probe
validation_path = probe / 'preparation-validation.json'
validation = json.loads(validation_path.read_text())
out = probe / 'build-01'
out.mkdir(exist_ok=False)
record = {'status': 'STARTED', 'probe': args.probe, 'revision': revision,
          'source': validation, 'validation_sha256': measure.digest(validation_path),
          'launcher_sha256': measure.digest(__file__), 'stages': [],
          'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
measure.write(out / 'receipt.json', record)
try:
    assert validation['metadata_offline_locked_passed'] and validation['fmt_check_passed']
    for name, key in [('src/main.rs', 'source_sha256'), ('Cargo.toml', 'manifest_sha256'), ('Cargo.lock', 'lock_sha256')]:
        assert measure.digest(probe / name) == validation[key], name
    assert measure.digest(Path('/tmp/raised-stack-latest-review-20260914/ram-watchdog-ps10.py')) == measure.WATCH_SHA
    record['tracked_before'] = measure.audit(revision)
    if not record['tracked_before']['passed']:
        record['status'] = 'SOURCE_INTEGRITY_FAILURE'
        raise RuntimeError('Pinned source audit failed')
    manifest = str(probe / 'Cargo.toml')
    env = dict(CARGO_TARGET_DIR=str(ROOT / 'target'), CARGO_BUILD_JOBS='4', RAYON_NUM_THREADS='8',
               RUST_MIN_STACK='134217728', INSTA_UPDATE='no', NEXTEST_RETRIES='0')
    for name, command in [
        ('fmt', ['cargo', 'fmt', '--manifest-path', manifest, '--check']),
        ('check', ['cargo', 'check', '--offline', '--locked', '--manifest-path', manifest, '--profile', 'dev-optim', '-j', '4']),
        ('build', ['cargo', 'build', '--offline', '--locked', '--manifest-path', manifest, '--profile', 'dev-optim', '-j', '4']),
        ('clippy', ['cargo', 'clippy', '--offline', '--locked', '--manifest-path', manifest, '--profile', 'dev-optim', '-j', '4']),
    ]:
        result = measure.guarded(out, name, command, env)
        record['stages'].append(result)
        measure.write(out / 'receipt.json', record)
        if result['status'] != 'PASS':
            record['status'] = result['status']
            break
    else:
        binary = out / binary_name
        shutil.copy2(ROOT / 'target/dev-optim' / binary.name, binary)
        record.update(status='PASS', binary=str(binary), binary_sha256=measure.digest(binary))
except BaseException as error:
    if record['status'] == 'STARTED':
        record['status'] = 'BUILD_OR_VALIDATION_FAILURE'
    record['error'] = repr(error)
finally:
    try:
        record['tracked_after'] = measure.audit(revision)
        assert record['tracked_after']['passed'], 'Pinned source changed'
        for name, key in [('src/main.rs', 'source_sha256'), ('Cargo.toml', 'manifest_sha256'), ('Cargo.lock', 'lock_sha256')]:
            assert measure.digest(probe / name) == validation[key], name
    except Exception as error:
        record.update(prior_status=record['status'], status='SOURCE_INTEGRITY_FAILURE', integrity_error=repr(error))
    record['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    measure.write(out / 'receipt.json', record)
    print(json.dumps({'status': record['status'], 'receipt': str(out / 'receipt.json')}), flush=True)
if record['status'] != 'PASS':
    raise SystemExit(1)

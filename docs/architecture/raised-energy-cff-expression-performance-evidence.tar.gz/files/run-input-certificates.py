"""Run two pre-reviewed CLI certificates once, after the primary sweep is idle."""
from pathlib import Path
import datetime
import fcntl
import hashlib
import importlib.util
import json
import os
import subprocess
import time

BASE = Path('/tmp/raised-energy-expression-perf-20260914')
PINNED_RECIPES = {
    'c8-gl1-diagram-only': '67ecf7030bdd12ac03a605140d7ee32cdf8edc9f28ea67d1a3605c2ec5466dc4',
    'c8-sunrise-orientation-catalog': '2c1266b4a66003a0e7296799af9affc00110aab34059281982d62319b63c0afa',
}
source = BASE / 'measure.py'
assert hashlib.sha256(source.read_bytes()).hexdigest() == '6f6ca7cbb51f5b606b93da4e00fe42465f3a194bc5efaf6e492df737cafad4d9'
spec = importlib.util.spec_from_file_location('measure', source)
measure = importlib.util.module_from_spec(spec)
spec.loader.exec_module(measure)
lock = (BASE / 'measurement.lock').open('a')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
primary = BASE / 'remaining-sweep-02/state.json'
assert json.loads(primary.read_text())['status'] == 'FINISHED_SWEEP'
for relative in ['remaining-sweep-01/state.json', 'remaining-sweep-02/state.json',
                 'controls/post-sweep-01/state.json']:
    state_path = BASE / relative
    if not state_path.exists():
        continue
    state = json.loads(state_path.read_text())
    assert state['status'] not in ['RUNNING', 'STARTED'], relative
    if 'pid' in state and 'proc_start_ticks' in state:
        proc = Path('/proc') / str(state['pid']) / 'stat'
        try:
            actual = proc.read_text().rsplit(') ', 1)[1].split()
        except FileNotFoundError:
            actual = None
        assert not actual or actual[19] != state['proc_start_ticks'] or actual[0] == 'Z', relative
revision = next(r for r in json.loads((BASE / 'revisions.json').read_text()) if r['label'] == 'c8')
watchdog = Path('/tmp/raised-stack-latest-review-20260914/ram-watchdog-ps10.py')
assert measure.digest(watchdog) == 'e94c98f65399e4cd0791ba050497ecaf4e745b4fdefc36fe036aae748f8152b9'
for stem, expected_recipe_sha in PINNED_RECIPES.items():
    recipe_path = BASE / 'diagnostics' / (stem + '-recipe.json')
    assert measure.digest(recipe_path) == expected_recipe_sha
    recipe = json.loads(recipe_path.read_text())
    # The first prepared recipe records its source hash without a source path.
    # Bind that existing field to the exact native C8 card explicitly.
    recipe.setdefault('source_card', str(BASE / 'attachments/cards/c8/g_gl1_integrated.toml'))
    directory = Path(recipe['stdout']).parent
    directory.mkdir(parents=True, exist_ok=False)
    record = {'classification': 'INPUT_CERTIFICATE_NOT_NATIVE_TIMING',
              'recipe': str(recipe_path), 'recipe_sha256': expected_recipe_sha,
              'launcher_sha256': measure.digest(__file__), 'verified_inputs': {},
              'argv': recipe['argv'], 'cwd': recipe['cwd'], 'revision': revision,
              'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'status': 'STARTED', 'certificate_postconditions_checked': False}
    result_path = directory / 'execution-receipt.json'
    measure.write(result_path, record)
    checked = {}
    phase = 'validate_inputs'
    try:
        for key in ['build_receipt', 'binary', 'card', 'source_card', 'original_state_fingerprint']:
            if key in recipe:
                digest = measure.digest(recipe[key])
                assert digest == recipe[key + '_sha256'], (key, digest)
                checked[key] = digest
        record['verified_inputs'] = checked.copy()
        build = json.loads(Path(recipe['build_receipt']).read_text())
        assert build['status'] == 'PASS' and build['revision'] == revision['commit'] and build['tree'] == revision['tree']
        assert build['binary'] == recipe['binary'] and build['binary_sha256'] == checked['binary']
        assert recipe['binary'] in recipe['argv'] and str(watchdog) in recipe['argv']
        assert str(Path(recipe['state'])) in recipe['argv'] and recipe['card'] in recipe['argv']
        env = os.environ.copy()
        for key in ['GL_ALL_LOG_FILTER', 'GL_DISPLAY_FILTER', 'GL_LOGFILE_FILTER',
                    'INSTA_FORCE_PASS', 'RUN_PYSECDEC_TESTS',
                    'GAMMALOOP_DUMP_EVALUATOR_PRE_NETWORK_PARSE',
                    'GAMMALOOP_STOP_AFTER_EVALUATOR_PRE_NETWORK_PARSE',
                    'SPENSO_NETWORK_PROFILE', 'SPENSO_NETWORK_PROFILE_VERBOSE',
                    'SPENSO_NETWORK_PROFILE_ATOM_BYTES']:
            env.pop(key, None)
        env.update(INSTA_UPDATE='no', NEXTEST_RETRIES='0')
        phase = 'execute'
        start = time.monotonic()
        with Path(recipe['stdout']).open('wb') as output:
            child = subprocess.run(recipe['argv'], cwd=recipe['cwd'], env=env,
                                   stdin=subprocess.DEVNULL, stdout=output, stderr=subprocess.STDOUT)
        record.update(exit_code=child.returncode, observation_seconds=time.monotonic()-start)
        phase = 'collect_evidence'
        memory = Path(recipe['memory'])
        events = [json.loads(line) for line in memory.read_text().splitlines()] if memory.exists() else []
        complete = next((e for e in reversed(events) if e['event'] == 'complete'), None)
        record.update(monitor_complete=complete,
                      peak_tree_rss_bytes=max((e.get('peak_tree_bytes', e.get('tree_bytes', 0)) for e in events), default=0))
        if any(e['event'] == 'memory_limit' for e in events):
            record['status'] = 'MEMORY_CAP'
        elif not complete or any(e['event'] == 'watchdog_error' for e in events):
            record['status'] = 'MONITOR_FAILURE'
        elif child.returncode == 0 and complete['returncode'] == 0:
            record['status'] = 'PASS_EXECUTION_ONLY'
        else:
            record['status'] = 'CHILD_FAILURE'
        record['execution_status'] = record['status']
    except BaseException as error:
        record.update(status='EVIDENCE_FAILURE' if phase == 'collect_evidence' else 'LAUNCH_OR_VALIDATION_FAILURE', failed_phase=phase, error=repr(error))
    finally:
        changed = []
        for key, expected in checked.items():
            try:
                if measure.digest(recipe[key]) != expected:
                    changed.append(key)
            except OSError:
                changed.append(key)
        if changed:
            record.update(prior_status=record['status'], status='INPUT_INTEGRITY_FAILURE', changed_inputs=changed)
        record['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        measure.write(result_path, record)
        print(json.dumps({'case': stem, 'status': record['status'], 'receipt': str(result_path)}), flush=True)
    if record['status'] in ['MONITOR_FAILURE', 'EVIDENCE_FAILURE', 'LAUNCH_OR_VALIDATION_FAILURE', 'INPUT_INTEGRITY_FAILURE']:
        raise SystemExit('Infrastructure/integrity failure; later certificates remain unexecuted')

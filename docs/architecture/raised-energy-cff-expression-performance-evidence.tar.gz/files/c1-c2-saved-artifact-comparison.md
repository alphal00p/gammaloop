# Exact saved-artifact comparison: main, C1 and C2

All requested equality predicates hold for the completed main-current, C1 and
C2 runs. This comparison reads saved artifacts only. It executes no algebra,
application workload or build and changes no source or saved state.

The **complete GL1 DOT files are byte-identical** across all three revisions.
This covers the full graph, orientations, routing/LMB assignments, three V_135
vertices, the V_36 three-gluon vertex, overall factor and external projector.
The **entire parsed saved models are equal**, not merely their sizes or source
models: all 11 graph-used particle/propagator/vertex/Lorentz/coupling entries,
all model parameters, and the saved parameter cards agree exactly. Thus the
observed main-to-C1 GL1 timing improvement accompanies an identical exported
physical graph and model input.

For the local-only sunrise, all three revisions have the same eight forest-node
identities. Every decoded `num` attribute is compared directly with main's
complete value and is exactly equal. All eight `full_num` attributes, all
recorded node/forest/residue/term metadata, and all eight **complete node DOT
files** are also equal. The GL0 graph and forest DOTs agree. Therefore the
factorized expression exports at every one of these eight nodes are unchanged
through C2; this conclusion does not rely on equal serialized sizes.

| Node | Forest key | Main = C1 = C2 num bytes | C8 num bytes | Main/C1/C2 complete value equal |
|---|---|---:|---:|---|
| 0 | `∅` | 536 | 1,397 | yes |
| 1 | `{y}` | 1,399 | 4,379 | yes |
| 2 | `{p}` | 1,399 | 4,379 | yes |
| 3 | `{F}` | 6,961 | 18,978 | yes |
| 4 | `{11}` | 23,573 | 53,899 | yes |
| 5 | `{y} · {11}` | 6,960 | 32,416 | yes |
| 6 | `{p} · {11}` | 6,960 | 32,416 | yes |
| 7 | `{F} · {11}` | 41,012 | 78,270 | yes |
| Total | eight nodes | 88,800 | 226,134 | yes |

C8 has the same graph/forest/node identity set but **none of its eight decoded
`num` values equals main's**. That is a textual representation difference; this
comparison performs no algebra and makes no claim that their mathematical
values differ. The sizes above count UTF-8 bytes of decoded serialized `num`
attributes, not Atom storage, live heap memory or peak RSS.

This evidence supports attributing an observed timing change to the code and
dependency changes rather than a changed GL1 graph/model or a different saved
sunrise expression. It does not isolate which C1 change causes the speedup,
certify equal intermediate allocation/traversal work, or supply an additional
benchmark repetition. The attached sparse-order workload has no corresponding
saved graph/model export in its native card and is outside this particular
saved-artifact certificate.

`c1-c2-saved-artifact-comparison.json` records exact equality predicates,
revision/receipt identities, input-file fingerprints, each decoded `num` hash,
metadata and sizes. The existing `attr` reader from
`compare-sunrise-bare-pair.py` was reused in isolation; its comparison script
body was not executed. All inspected input files were re-hashed afterward and
remained unchanged.

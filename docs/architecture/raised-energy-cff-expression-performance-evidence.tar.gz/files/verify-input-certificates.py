"""Read-only semantic checks of two completed native C8 input certificates."""
from pathlib import Path
import ast
import datetime
import hashlib
import itertools
import json
import re

BASE = Path('/tmp/raised-energy-expression-perf-20260914')
evidence = {}


def bind(path):
    path = Path(path)
    data = path.read_bytes()
    evidence[str(path)] = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
    return data


# Reuse only the existing DOT string reader; do not run its algebraic comparison.
reader = BASE / 'compare-sunrise-bare-pair.py'
module = ast.parse(bind(reader).decode())
attribute = next(node for node in module.body if isinstance(node, ast.FunctionDef) and node.name == 'attr')
exec(compile(ast.Module(body=[attribute], type_ignores=[]), str(reader), 'exec'))
recipes = {}
receipts = {}
for name in ['c8-gl1-diagram-only', 'c8-sunrise-orientation-catalog']:
    receipts[name] = json.loads(bind(BASE / 'diagnostics' / (name + '-01') / 'execution-receipt.json'))
    assert receipts[name]['status'] == 'PASS_EXECUTION_ONLY'
    assert receipts[name]['exit_code'] == receipts[name]['monitor_complete']['returncode'] == 0
    recipe = json.loads(bind(receipts[name]['recipe']))
    assert evidence[receipts[name]['recipe']]['sha256'] == receipts[name]['recipe_sha256']
    for key, expected in receipts[name]['verified_inputs'].items():
        path = recipe.get(key, str(BASE / 'attachments/cards/c8/g_gl1_integrated.toml'))
        assert hashlib.sha256(bind(path)).hexdigest() == expected, key
    recipes[name] = recipe

gl = recipes['c8-gl1-diagram-only']
main_dot, c8_dot = Path(gl['main_dot']), Path(gl['expected_dot'])
main_state = BASE / 'measurements/main-current/run-g-gl1-01/state'
c8_state = Path(gl['state'])
models = {name: json.loads(bind(state / 'model.json')) for name, state in [('main', main_state), ('c8', c8_state)]}
selected = {
    'particles': ['g', 'u', 'u~'],
    'propagators': ['g_propFeynman', 'u_propFeynman', 'u~_propFeynman'],
    'vertex_rules': ['V_135', 'V_36'],
    'lorentz_structures': ['FFV1', 'VVV1'],
    'couplings': ['GC_10', 'GC_11'],
    'parameters': ['ZERO', 'aS', 'G'],
}
used = []
for section, names in selected.items():
    for name in names:
        values = {label: next(item for item in model[section] if item['name'] == name) for label, model in models.items()}
        used.append({'section': section, 'name': name, 'equal': values['main'] == values['c8'], 'values': values})
model_differences = []
for key in sorted(set(models['main']) | set(models['c8'])):
    a, b = models['main'].get(key), models['c8'].get(key)
    if a == b:
        continue
    if isinstance(a, list) and isinstance(b, list) and all(isinstance(x, dict) and 'name' in x for x in a + b):
        aa, bb = ({x['name']: x for x in values} for values in [a, b])
        for name in sorted(set(aa) | set(bb)):
            if aa.get(name) != bb.get(name):
                model_differences.append({'section': key, 'name': name, 'main': aa.get(name), 'c8': bb.get(name)})
    else:
        model_differences.append({'section': key, 'main': a, 'c8': b})
gl1 = {
    'complete_dot_byte_equal': bind(main_dot) == bind(c8_dot),
    'complete_graph_text': c8_dot.read_text(),
    'projector': attr(c8_dot, 'projector'),
    'overall_factor': attr(c8_dot, 'overall_factor'),
    'overall_factor_evaluated': attr(c8_dot, 'overall_factor_evaluated'),
    'vertices': re.findall(r'(\d+) \[int_id="([^"]+)"\]', c8_dot.read_text()),
    'edges_including_routing_and_halfedge_incidence': [line.strip() for line in c8_dot.read_text().splitlines() if '->' in line],
    'complete_parsed_models_equal': models['main'] == models['c8'],
    'all_graph_used_model_records_equal': all(item['equal'] for item in used),
    'graph_used_model_records': used,
    'all_model_differences': model_differences,
    'complete_parameter_cards_byte_equal': bind(main_state / 'model_parameters.json') == bind(c8_state / 'model_parameters.json'),
    'scope': 'Full graph, routing, projector and exact graph-used model dependency records. Whole saved models differ as explicitly recorded; no equality claim for unrelated model sectors or generated integrands.',
}

sun = recipes['c8-sunrise-orientation-catalog']
fingerprint = json.loads(bind(sun['original_state_fingerprint']))
native_state, diagnostic_state = Path(fingerprint['state']), Path(sun['state'])
actual = {str(p.relative_to(native_state)): {'bytes': p.stat().st_size, 'sha256': hashlib.sha256(bind(p)).hexdigest()}
          for p in sorted(native_state.rglob('*')) if p.is_file()}
rel = Path('processes/amplitudes/quark_sunrise/2L')
native_nodes = sorted(str(p.relative_to(native_state / rel)) for p in (native_state / rel / 'GL0_nodes').rglob('*.dot'))
diagnostic_nodes = sorted(str(p.relative_to(diagnostic_state / rel)) for p in (diagnostic_state / rel / 'GL0_nodes').rglob('*.dot'))
dot_checks = [{'path': path, 'byte_equal': bind(native_state / rel / path) == bind(diagnostic_state / rel / path)}
              for path in ['GL0.dot'] + native_nodes]
archive = json.loads(bind(sun['expected_json']))
terms = [term for term in archive['graph_terms'] if term['graph_name'] == 'GL0']
assert len(terms) == 1
term = terms[0]
orientations, ids = term['orientations'], term['original_integrand']['production_orientation_ids']
assert len(ids) == len(orientations) and len(set(ids)) == len(ids)
assert all(len(row) == 3 and all(sign in [-1, 1] for sign in row) for row in orientations)
catalog = [{'sigma_id': sigma, 'physical_signs': signs} for sigma, signs in zip(ids, orientations)]
proof = json.loads(bind(BASE / 'sunrise-main-c8-bare-pair.json'))
assert proof['status'] == 'PASS_FACTORIZED_BARE_PAIR'
for item in proof['inputs']:
    assert hashlib.sha256(bind(item['path'])).hexdigest() == item['sha256']
expected = {branch['sigma_id']: branch['uniquely_corresponding_main_sign_branch'] for branch in proof['branches']}
truth = []
for signs in itertools.product([-1, 1], repeat=3):
    actual_ids = [item['sigma_id'] for item in catalog if item['physical_signs'] == list(signs)]
    prior = next(row for row in proof['truth_table'] if row['physical_signs'] == list(signs))
    truth.append({'physical_signs': list(signs), 'runtime_sigma_ids': actual_ids,
                  'proved_main_support_sigma_ids': prior['paired_sigma_ids'], 'equal': actual_ids == prior['paired_sigma_ids']})
params = [p for p in term['param_builder_params'] if re.fullmatch(r'gammalooprs::σ\(\d+\)', p)]
sunrise = {
    'native_state_path_inventory_equal': set(actual) == set(fingerprint['files']),
    'native_state_all_original_bytes_unchanged': actual == fingerprint['files'],
    'original_state_file_count': len(fingerprint['files']),
    'native_state_added_paths': sorted(set(actual) - set(fingerprint['files'])),
    'native_state_missing_paths': sorted(set(fingerprint['files']) - set(actual)),
    'native_state_changed_paths': sorted(k for k in set(actual) & set(fingerprint['files']) if actual[k] != fingerprint['files'][k]),
    'complete_forest_dot_path_inventory_equal': native_nodes == diagnostic_nodes,
    'forest_node_count': len(native_nodes),
    'graph_and_all_forest_dot_checks': dot_checks,
    'runtime_orientations': orientations,
    'production_orientation_ids': ids,
    'catalog': catalog,
    'orientation_parameter_column_labels': params,
    'orientation_columns_verified': params == ['gammalooprs::σ(0)', 'gammalooprs::σ(1)', 'gammalooprs::σ(2)'],
    'catalog_exactly_matches_previously_proved_body_pairing': {item['sigma_id']: item['physical_signs'] for item in catalog} == expected,
    'complete_truth_table': truth,
    'all_eight_truth_rows_match': all(row['equal'] for row in truth),
    'scope': 'Actual runtime selector IDs and all three physical edge signs, tied to byte-identical native C8 graph/eight forests and the existing complete bare-factor proof. No proper-UV or full-integrand equality certified.',
}
source_refs = [
    ('crates/gammalooprs/src/integrands/process/amplitude/export.rs', '251-264: runtime EdgeVec rows serialized as Default=1, Reversed=-1, Undirected=0'),
    ('crates/linnet/src/half_edge/involution.rs', '24-34: EdgeIndex/EdgeVec declaration'),
    ('crates/linnet/src/half_edge/typed_vec.rs', '141-145,194: EdgeVec iteration enumerates storage in ascending numerical edge index'),
]
for path, _ in source_refs:
    bind(BASE / 'diagnostic-workspaces/c8' / path)
checks = [gl1['complete_dot_byte_equal'], gl1['all_graph_used_model_records_equal'], gl1['complete_parameter_cards_byte_equal'],
          sunrise['native_state_all_original_bytes_unchanged'], sunrise['complete_forest_dot_path_inventory_equal'],
          sunrise['forest_node_count'] == 8, all(item['byte_equal'] for item in dot_checks),
          sunrise['orientation_columns_verified'], sunrise['catalog_exactly_matches_previously_proved_body_pairing'], sunrise['all_eight_truth_rows_match']]
bind(__file__)
record = {'status': 'PASS_SEMANTIC_INPUT_CERTIFICATES' if all(checks) else 'FAIL_SEMANTIC_INPUT_CERTIFICATES',
          'checked_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'classification': 'READ_ONLY_ARTIFACT_CHECK_NO_WORKLOAD_NO_NUMERATOR_EXPANSION',
          'gl1': gl1, 'sunrise': sunrise, 'orientation_source_evidence': source_refs, 'evidence': evidence,
          'execution_receipts_left_unchanged': True}
out = BASE / 'input-certificates-semantic-checks.json'
out.write_text(json.dumps(record, indent=2, ensure_ascii=False) + '\n')
print(json.dumps({'status': record['status'], 'receipt': str(out), 'sha256': hashlib.sha256(out.read_bytes()).hexdigest(),
                  'gl1_graph_used_model_records': len(used), 'whole_models_equal': gl1['complete_parsed_models_equal'],
                  'original_state_files_unchanged': sunrise['native_state_all_original_bytes_unchanged'], 'catalog': catalog}))

"""Verify the packaged index and every regular/hard-linked evidence payload."""
import hashlib,json,pathlib,re,sys,tarfile
archive=pathlib.Path(sys.argv[1]);prefix='powered-dot-review/';observed={};index=None
pattern=re.compile(rb'(?i)[0-9a-f]{8}#[0-9a-f]{8}#[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}')
with tarfile.open(archive,'r|gz')as tar:
 for member in tar:
  assert member.name.startswith(prefix) and '..'not in pathlib.PurePosixPath(member.name).parts
  name=member.name[len(prefix):];assert name not in observed
  if member.islnk():
   assert member.linkname.startswith(prefix)
   target=member.linkname[len(prefix):];assert target in observed
   observed[name]=dict(observed[target]);continue
  assert member.isfile(),('Unsupported archive member',member.name)
  stream=tar.extractfile(member);digest=hashlib.sha256();size=0;tail=b'';chunks=[]
  while chunk:=stream.read(1<<20):
   if size==0:assert not chunk.startswith(b'\x7fELF'),('Unexpected executable',member.name)
   assert not pattern.search(tail+chunk),('License-format content in artifact',member.name)
   tail=(tail+chunk)[-64:];digest.update(chunk);size+=len(chunk)
   if name=='package-index.json':chunks.append(chunk)
  assert size==member.size
  if name=='package-index.json':index=json.loads(b''.join(chunks))
  else:observed[name]={'bytes':size,'sha256':digest.hexdigest()}
assert index is not None
expected={r['path']:{'bytes':r['bytes'],'sha256':r['sha256']}for r in index['files']}
assert len(expected)==len(index['files']) and observed==expected
print(json.dumps({'archive':str(archive),'archive_bytes':archive.stat().st_size,'archive_sha256':hashlib.file_digest(archive.open('rb'),'sha256').hexdigest(),'files':len(expected),'unique_contents':len({r['sha256']for r in expected.values()}),'source_bytes':sum(r['bytes']for r in expected.values()),'symbolic_atom_outputs':sum(name.endswith('.atom')for name in expected),'saved_state_payloads':[name for name in expected if name.endswith('.bin')],'all_indexed_payload_hashes_match':True,'regular_files_and_internal_prior_hard_links_only':True,'no_ELF_payloads_or_license_format_found':True},indent=2))

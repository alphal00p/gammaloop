from pathlib import Path
import hashlib,json,re
from symbolica import Expression as E
root=Path('/tmp/powered-dot-review');source=root/'public-api/manifest.json';manifest=json.loads(source.read_text());records=[]
replacements={
 'vakint::{}::topo(vakint::{}::prop(1,vakint::{}::edge(1,1),vakint::{}::k(1),vakint::{}::muvsq,1))':'1',
 'vakint::{symmetric,linear}::dot(vakint::{}::k(1),vakint::{}::k(1))':'K',
 'vakint::{symmetric,linear}::dot(vakint::{}::p(1),vakint::{}::p(1))':'P',
 'vakint::{symmetric,linear}::dot(vakint::{}::p(2),vakint::{}::p(2))':'Q',
 'vakint::{symmetric,linear}::dot(vakint::{}::p(1),vakint::{}::p(2))':'R',
 'vakint::{}::eps':'e',
}
for row in manifest['runs']:
 assert row['exit_code']==0
 normalized={}
 for name in ['actual','expected']:
  expression=row['values'][name]
  for old,new in replacements.items():expression=expression.replace(old,new)
  assert re.fullmatch(r'[0-9KPQRe+*^()\-]+',expression),expression
  normalized[name]=expression
 actual=E.parse(normalized['actual']);expected=E.parse(normalized['expected']);oracle=E.parse('K*(P+2*R+Q)/(4-2*e)')
 assert (expected-oracle).together().cancel()==0
 residual=(actual-oracle).together().cancel()
 records.append({'mode':row['mode'],'variant':row['variant'],'normalized_expressions':normalized,'complete_residual':residual.to_canonical_string(),'complete_value_equal':bool(residual==0)})
 assert bool(residual==0)==(not(row['mode']=='monolithic'and row['variant']=='unfreshened'))
result={'source_manifest_sha256':hashlib.file_digest(source.open('rb'),'sha256').hexdigest(),'method':'Exact replacement of named scalar invariants and the common topology, followed by complete rational residual cancellation. No native observation rerun; no graph numerator expansion.','representation_note':'The original diagnostic complete_value_equal field compared collected-factor storage literally and was false even for equivalent signs of the denominator. Retain that field as a representation observation; this receipt checks mathematical values.','substitutions':replacements,'runs':records};(root/'public-api/complete-value-check.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(records,indent=2))

#-
*Off statistics;
S D, ep;
Auto V k,p,q;
Auto S n,x,m,t,cMi,log,z,ALARM;

CF rat,map,uvprop,g(s),tmps(s),dot;

Auto I s=4,mu=D;
CF counter,vec,vec1,gamma,NN;
CT opengammastring;

Polyratfun rat;
#include ./tensorreduce.frm

L F = (vec(k1,1001)*vec1(p1,1001)+vec(k1,1002)*vec1(p2,1002))*(vec(k1,1003)*vec1(p1,1003)+vec(k1,1004)*vec1(p2,1004));

#call TensorReduce()

id q1?.q2? = dot(q1,q2);
id g(xi?,xj?)*vec1(q1?,xi?)*vec1(q2?,xj?) = dot(q1,q2);
id vec1(q1?,xi?)*vec1(q2?,xi?) = dot(q1,q2);
.sort

Print +S;
#write<out.txt> \"%E\",F

.end

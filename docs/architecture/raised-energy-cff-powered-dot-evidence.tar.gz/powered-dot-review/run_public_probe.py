from pathlib import Path
import concurrent.futures,hashlib,json,os,shutil,subprocess,time
root=Path('/tmp/powered-dot-review');binary=root/'powered-dot-boundary'
shutil.copyfile('/common/dev/gammaloop/higher-power-energies-review/target/dev-optim/examples/powered_dot_boundary_probe',binary);binary.chmod(0o755)
records=[]
def run(case):
 mode,variant=case;out=root/'public-api'/f'{mode}-{variant}';out.mkdir(parents=True,exist_ok=True)
 command=['/tmp/raised-stack/run','env','-u','VAKINT_PROBE_SKIP_POWER_FRESHENING','INSTA_UPDATE=no','RAYON_NUM_THREADS=1']
 if variant=='unfreshened':command+=['VAKINT_PROBE_SKIP_POWER_FRESHENING=1']
 command+=['timeout','60',str(binary),mode,str(out)]
 started=time.monotonic();p=subprocess.run(command,capture_output=True,text=True);(out/'run.log').write_text(p.stdout+p.stderr)
 fields=dict(line.split('=',1)for line in p.stdout.splitlines()if line.startswith(('input=','expected=','actual=','complete_value_equal=')))
 return {'mode':mode,'variant':variant,'command':command,'exit_code':p.returncode,'elapsed_seconds':time.monotonic()-started,'values':fields,'retained_backend_directory':str(out)}
with concurrent.futures.ThreadPoolExecutor(max_workers=4)as pool:
 for record in pool.map(run,[(mode,variant)for mode in ['projected','monolithic']for variant in ['current','unfreshened']]):records.append(record);print(json.dumps(record),flush=True)
(root/'public-api/manifest.json').write_text(json.dumps({'binary_sha256':hashlib.file_digest(binary.open('rb'),'sha256').hexdigest(),'input_contract':'One-loop vacuum angular average of the complete factorized scalar square. No graph numerator expansion in the probe; equality uses complete collected factors.','oracle':'<k_mu k_nu> = g_mu_nu k^2/D with D=4-2eps.','runs':records},indent=2)+'\n')

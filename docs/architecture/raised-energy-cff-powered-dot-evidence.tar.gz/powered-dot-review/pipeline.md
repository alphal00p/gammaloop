# Powered-dot freshening boundary comparison

The common input is `(dot(k(1),p(1))+dot(k(1),p(2)))^2` on one-loop vacuum topology `I1L(muvsq,1)`.

Both public routes share topology canonicalization, Lorentz validation, the same Symbolica dependency, FORM resources and Laurent dimension. The projected route decomposes scalar monomials before backend conversion; the whole-numerator route hands the factorized sum to FORM tensor reduction. The intervention skips only the final copy-freshening traversal in `convert_from_dot_notation`. The first changed representation is therefore the indexed power sent to FORM, not the physical topology, angular-average formula, contour or integral evaluator.

The independent angular-average oracle is `k^2*(p^2+2*p.q+q^2)/D`, with `D=4-2*eps`, derived from `<k_mu*k_nu> = g_mu_nu*k^2/D`. Direct execution of the unchanged FORM resources gives that value for fresh copies. Reused indices give `k^2*(p^2+q^2)+2*k^2*p.q/D`: both diagonal terms lose their `1/D`. This direct boundary comparison is retained separately from the public API matrix.

No graph numerator is expanded in the Rust probe. The backend performs its own production tensor reduction. The native probe retains a literal collected-factor comparison, which is false even for equivalent denominator signs. The separate `check_public_values.py` compares the unchanged complete outputs by exact rational cancellation after mapping the four independent scalar invariants and common topology. It proves three zero residuals and one nonzero residual without rerunning a native observation. Timing this new probe is not an end-to-end performance benchmark. No PySecDec integration is launched.

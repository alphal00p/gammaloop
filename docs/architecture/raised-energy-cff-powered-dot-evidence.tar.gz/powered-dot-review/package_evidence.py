"""Package readable evidence and exact inputs, excluding binaries/license material."""
import hashlib,json,os,pathlib,re,tarfile,sys
root=pathlib.Path('/tmp/powered-dot-review');out=pathlib.Path(sys.argv[1]);
allowed={'.md','.json','.jsonl','.toml','.log','.txt','.py','.rs','.sh','.patch','.diff','.sym','.dot','.original','.atom','.instrumented','.repetitions','.dotpretty','.frm','.h'}
excluded_dirs={'benchmark-source','source','target','bin','__pycache__','.git','.jj','frozen-libs'}
license_pattern=re.compile(rb'(?i)[0-9a-f]{8}#[0-9a-f]{8}#[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}')
state_paths={
 'core-perf/GL04-explicit-process-state/symbolica_state.bin',
 'core-perf/GL04-explicit-process-state/processes/cross_sections/core_audit/def.bin',
 'core-perf/GL04-explicit-process-state/processes/cross_sections/core_audit/numerator/cs.bin',
 'core-perf/GL04-explicit-process-state/processes/cross_sections/core_audit/numerator/integrand/integrand.bin',
}
files=[]
for directory,dirs,names in os.walk(root):
 dirs[:]=[name for name in dirs if name not in excluded_dirs]
 for name in names:
  p=pathlib.Path(directory)/name
  if p.is_symlink()or (p.suffix not in allowed and str(p.relative_to(root))not in state_paths) or name.startswith('report-draft'):continue
  if p==out or name in {'package-index.json'}:continue
  files.append(p)
files.sort();index=[];seen={}
# The scanner reports only offending paths, never matching text.
for p in files:
 with p.open('rb')as stream:
  prefix=stream.read(4)
  assert prefix!=b'\x7fELF',('Unexpected executable',str(p))
 digest=hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
 with p.open('rb')as stream:
  tail=b''
  while chunk:=stream.read(1<<20):
   window=tail+chunk
   assert not license_pattern.search(window),('License-format content in artifact',str(p))
   tail=window[-64:]
 index.append({'path':str(p.relative_to(root)),'bytes':p.stat().st_size,'sha256':digest})
(root/'package-index.json').write_text(json.dumps({'scope':'Powered-dot public-API and FORM boundary evidence; no executables, compiled libraries, full source checkouts or license material. Original command paths remain as provenance. Duplicate content is represented by archive hard links.','files':index},indent=2)+'\n')
out.parent.mkdir(parents=True,exist_ok=True)
with tarfile.open(out,'w:gz',compresslevel=6)as tar:
 for p,record in zip(files,index):
  name='powered-dot-review/'+record['path'];info=tar.gettarinfo(str(p),arcname=name);info.uid=info.gid=0;info.uname=info.gname='';digest=record['sha256']
  if digest in seen:
   info.type=tarfile.LNKTYPE;info.linkname=seen[digest];info.size=0;tar.addfile(info)
  else:
   seen[digest]=name
   with p.open('rb')as stream:tar.addfile(info,stream)
 tar.add(root/'package-index.json',arcname='powered-dot-review/package-index.json')
print(json.dumps({'files':len(files),'unique_contents':len(seen),'source_bytes':sum(x['bytes']for x in index),'archive_bytes':out.stat().st_size,'archive_sha256':hashlib.file_digest(out.open('rb'),'sha256').hexdigest()}))

use symbolica::atom::AtomCore;
use vakint::{Vakint, VakintSettings, vakint_parse};

fn main() {
    let projected = std::env::args().nth(1).unwrap() == "projected";
    let settings = VakintSettings {
        project_onto_tensor_integrals: projected,
        use_dot_product_notation: true,
        clean_tmp_dir: false,
        temporary_directory: Some(std::env::args().nth(2).unwrap()),
        ..VakintSettings::default()
    };
    let vakint = Vakint::new().unwrap();
    let input = vakint_parse!("(dot(k(1),p(1))+dot(k(1),p(2)))^2*topo(I1L(muvsq,1))").unwrap();
    let expected = vakint_parse!("dot(k(1),k(1))*(dot(p(1),p(1))+2*dot(p(1),p(2))+dot(p(2),p(2)))/(4-2*eps)*topo(I1L(muvsq,1))").unwrap();
    let mut settings = settings;
    settings.epsilon_symbol = "eps".into();
    let input = vakint
        .to_canonical(&settings, input.as_view(), false)
        .unwrap();
    let expected = vakint
        .to_canonical(&settings, expected.as_view(), false)
        .unwrap();
    let actual = vakint.tensor_reduce(&settings, input.as_view()).unwrap();
    println!("input={}", input.to_canonical_string());
    println!("expected={}", expected.to_canonical_string());
    println!("actual={}", actual.to_canonical_string());
    println!(
        "complete_value_equal={}",
        actual.collect_factors() == expected.collect_factors()
    );
}

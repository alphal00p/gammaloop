from fractions import Fraction as F
from math import comb
from pathlib import Path
import json
out=Path('/tmp/raised-stack-latest-review-20260914')
source=json.loads((out/'sunset-independent-contours.json').read_text())
records=[]
for item in source['records']:
    p=item['degree']
    e0,e1,b=item['energies']
    a=e0+e1
    # R(z)=z^(p+1)/((z^2-a^2)*(z^2-b^2)^5).
    # Residue at b is the w^4 coefficient after stripping (z-b)^5.
    series=[F(comb(p+1,n)*b**(p+1-n)) for n in range(5)]
    for c,exponent in [(b-a,1),(b+a,1),(2*b,5)]:
        factor=[F((-1)**n * comb(exponent+n-1,n),c**(exponent+n)) for n in range(5)]
        series=[sum((series[j]*factor[n-j] for j in range(n+1)),F(0)) for n in range(5)]
    repeated=series[4]
    simple=F(a**(p+1),2*a*(a*a-b*b)**5)
    actual_simple=-simple/F(2*e1)
    actual_repeated=-repeated/F(2*e1)
    contour=-(actual_simple+actual_repeated)
    assert simple==F(item['simple_residue'])
    assert repeated==F(item['repeated_residue'])
    assert contour==F(item['complete_signed_contour'])
    records.append(dict(degree=p,raw_R_simple_residue=str(simple),raw_R_repeated_residue=str(repeated),actual_outer_simple_residue=str(actual_simple),actual_outer_repeated_residue=str(actual_repeated),complete_clockwise_contour=str(contour),expected_matches=True))
result=dict(status='PASS',arithmetic='Python fractions.Fraction, fourth-order truncated power-series multiplication; no Symbolica/CFF computation',definition='J_p=Below_k1 Below_k0 k0*k1^p/[(k0^2-E0^2)*((k1-k0)^2-E1^2)*(k1^2-E2^2)^5] with dq/(2pi i)',inner_identity='Below_k0[k0/(D0 D1)]=-k1/[2 E1 (k1^2-(E0+E1)^2)]',source_normalization='Native symbolic expression retains positive energy factors. For each component multiply (-1)^N times core frame for GlobalSourceProduct, or denominator-only frame for VariantLocal. This matches the established native signed-contour conversion in three-dimensional-reps eval.rs.',residue_label_note='Input artifact residue columns are for unprefactored R_p, not actual outer integrand -R_p/(2E1). Two minus signs give final sum(raw residues)/(2E1).',records=records)
(out/'sunset-independent-contours-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))

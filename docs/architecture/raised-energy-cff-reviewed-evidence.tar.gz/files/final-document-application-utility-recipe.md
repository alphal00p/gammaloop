# Proposed final C8 documentation application guard

`apply-final-documents.proposed.py` is prepared for independent static review. It has not been executed. Its `--apply` flag is an explicit operator action; do not invoke it during prefix validation or immediate audit work. It does not build, run tests, compile PDFs, generate an archive, edit the prefix, move a bookmark or push.

The guard reuses the already reviewed jj metadata/command/immutable-object helpers, prefix idle check and tracked-file audit. It loads those helper definitions from exact frozen bytes without running their `main` entry points. Both collector invocations explicitly include `--review-followup /tmp/raised-stack-latest-review-20260914/c1-clippy-readability-fix-review.json`; the earlier recipe omission is corrected.

## Freeze prerequisites

1. Finish all candidate validation and immediate audits. Generate the complete candidate ledger and main report using the corrected collector/filler commands from `final-document-application-plan.md`. The current incomplete drafts do not qualify. Candidate C8 must still equal the reconciled C8; this guard intentionally has no multi-candidate compatibility path.
2. Compile the exact final main Typst source to `main-report-final.pdf` and inspect every page. Retain the actual compile command/result and rendering/inspection evidence; prepare the receipt described below. Review the final report prose and the exact twelve destination artifacts.
3. Review the final archive allowlist and extras, then invoke the existing packager with both the reviewed allowlist SHA and the paired extras path/SHA. This happens outside the amendment script. The archive inventory must equal those descriptors, including current mapping, validation, fill receipt and the explicit C1 review. Reconcile descriptor sizes after the filler refreshes the MRE sidecar. The packager refuses an existing output directory; do not overwrite an earlier attempt blindly.
4. Keep the archived `final-document-artifact-map.proposed.json` unchanged. Create a **separate external** `final-document-artifact-map.frozen.json` only after the archive hash is known. Do not archive this frozen map, the final closure, or final verification outputs. Obtain an independent review receipt for the exact final application script.

The frozen descriptor uses this schema (the strings marked `ACTUAL...` are operator-supplied evidence, never pass values to invent):

```json
{
  "schema_version": 1,
  "status": "REVIEWED_FROZEN",
  "document_review_status": "PASS",
  "document_reviewer": "ACTUAL_REVIEWER",
  "application_script_sha256": "ACTUAL_SCRIPT_SHA256",
  "application_review_receipt": "final-document-application-static-review.json",
  "corrected_source_revision": "392c98c3d2f70896ef94267addfcf610e2df2c88",
  "tested_revision": "449a59f6f173d100c2da858c541faa1e0dccca6e",
  "reconciled_revision": "449a59f6f173d100c2da858c541faa1e0dccca6e",
  "pdf_review_receipt": "main-report-final-review.json",
  "archive_allowlist": "report-updater/drafts/archive-allowlist.json",
  "archive_extras": "ACTUAL_REVIEWED_EXTRAS_DESCRIPTOR.json",
  "inputs_sha256": {"TASK_RELATIVE_PATH": "ACTUAL_SHA256"},
  "entries": [
    {
      "source": "/tmp/raised-stack-latest-review-20260914/ACTUAL_SOURCE",
      "destination": "docs/architecture/ACTUAL_DESTINATION",
      "sha256": "ACTUAL_SOURCE_SHA256",
      "bytes": 123
    }
  ]
}
```

Copy **all twelve source/destination pairs in their existing order** from the proposed artifact map, adding each exact size and SHA256. The guard rejects path changes, wildcards, symlink ancestors, nonregular sources and unexpected destination modes. The example `123` is not a receipt.

`inputs_sha256` must bind: the script's `REQUIRED` set; the collector's `FIXED_INPUTS` and current validation `source_inputs_sha256`; all absolute-path fill inputs converted to TASK-relative keys; both archive descriptors; the main PDF review and its referenced evidence; and the application review receipt. Freeze all these files after final generation. This includes the append-only reconciliation proof/checkpoints and their exact already-reviewed correction receipt evidence through the collector. Do not include or read the licensed wrapper. Only files under TASK are read by the frozen-input loader.

The independent script review receipt has `status: "PASS"`, the exact `script_sha256`, a nonempty `reviewers` array, and `findings: []`. Its scope is static application review; it must not claim an execution. The previous recipe/map review is retained separately and does not certify this new script by itself.

The main PDF review receipt has:

```json
{
  "status": "PASS",
  "reviewer": "SAME_ACTUAL_DOCUMENT_REVIEWER",
  "source_typst_sha256": "ACTUAL_FROZEN_MAIN_TYPST_SHA256",
  "pdf_sha256": "ACTUAL_FROZEN_MAIN_PDF_SHA256",
  "pages": 1,
  "inspected": [1],
  "findings": [],
  "compile": {
    "argv": ["/ACTUAL/PATH/typst", "compile", "OTHER_ACTUAL_FLAGS_IF_ANY", "/tmp/raised-stack-latest-review-20260914/report-templates/filled/raised-energy-cff-stack-review.typ", "/tmp/raised-stack-latest-review-20260914/main-report-final.pdf"],
    "exit_code": 0
  },
  "evidence_sha256": {"ACTUAL_COMPILE_OR_INSPECTION_RECEIPT_PATH": "ACTUAL_SHA256"}
}
```

Use the actual page count, ordered `1..pages` inspection list, exact command array and successful recorded exit code. Omit the illustrative flag placeholder; preserve the real flags. Reference the actual compile/inspection receipts or logs in `evidence_sha256` and `inputs_sha256`. This is an evidence adapter, not permission to claim a render or visual review that did not happen. Existing motivation PDF evidence cannot substitute for the new main PDF.

## One explicit execution

After the independent script review, final descriptor review and idle confirmation, invoke exactly once:

```sh
/tmp/raised-stack/python /tmp/raised-stack-latest-review-20260914/apply-final-documents.proposed.py --apply --artifact-map /tmp/raised-stack-latest-review-20260914/final-document-artifact-map.frozen.json --reviewed-map-sha256 ACTUAL_REVIEWED_DESCRIPTOR_SHA256
```

The script takes `prefix-execution.lock`, checks both ROOT and prefix for active validation, requires ROOT to be the unchanged corrected source, verifies all eight stable jj changes and dispatch pins, and rejects unexpected nonignored files. It inventories all bookmarks and Git branch/tracking refs; none may follow the candidate C8 because bookmark movement is reserved for a separate step. Current refs meet that constraint.

It creates a new `final-document-application/` attempt directory, reruns the collector into fresh candidate verification output, and requires the complete gate/attempt/receipt data to match the frozen ledger. Before the first jj mutation, it records the operation checkpoint, original source trees, all refs, and backups of both pin files.

It edits the stable C8 change, atomically replaces only the twelve reviewed document artifacts using adjacent temporary files, then snapshots once all replacements are complete. That single command overrides `snapshot.max-new-file-size` to the largest frozen artifact size; the observed default is 1 MiB and the new evidence archive may exceed it. No repository configuration changes. It verifies the actual tested-to-final and reconciled-to-final Git deltas, exact artifact blobs and modes, unchanged C1–C7 and corrected source, unchanged originals and refs, and unchanged prefix files. Actual changed paths may be fewer than twelve if an artifact is already identical.

Only `corrected-stack.json: commits[7].commit/tree` and `validation-pins.json: c8` change. Pre-document source/tree proof fields retain their original meaning. The pin files are prepared together and replaced under the lock; a process crash between replacements is still possible, so the checkpoint/backups remain authoritative for a reviewed recovery.

The external `final-document-closure.json` contains exact actual document paths/hashes and the verbatim canonical C8 stage names. A second collector invocation uses `--closure` into fresh `final-document-application/final-verification/`. It must preserve the full accepted receipts, original executed revisions, commands, audit/binary/identity hashes and final counts. It records no new test execution. **Do not copy or regenerate those final verification reports back into C8.**

On failure, inspect the attempt's checkpoint/result and partial files; there is no automatic rollback or retry. The script refuses an existing attempt/closure. Before-mutation errors may leave only candidate verification output; after-mutation errors can leave an amended C8 and/or one updated pin file. Adjacent `.final-document.pending` files may remain after an interrupted replacement. Do not launch validation, resnapshot or retry until the operator reviews the partial state.

On success, ROOT remains on final C8 and the prefix remains on its previous pinned revision. The local bookmark and every remote/tracking ref remain unchanged. Root may separately review the final receipt and move `codex/raised-energy-cff-reviewed` to the reported final revision; pushing is outside this utility.

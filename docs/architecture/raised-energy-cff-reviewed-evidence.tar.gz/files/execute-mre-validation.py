#!/usr/bin/env python3
"""Run only the pinned C7 standalone controls and tiny import diagnostic.

Explicit invocation, after the prefix is idle:
  /tmp/raised-stack/run /tmp/raised-stack/python execute-mre-validation.py
No arguments or supplied physical inputs are admitted. Existing stage directories,
output dump, or final receipt stop execution; failures are never retried.
"""
from contextlib import ExitStack
from datetime import datetime, timezone
import fcntl
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import importlib.util

BASE = Path('/tmp/raised-stack-latest-review-20260914')
PREFIX = Path('/tmp/raised-stack/prefix')
REPOSITORY = Path('/common/dev/gammaloop/higher-power-energies-review')
PIN = 'a3af927afc633c6e6c2474d3f03fa02e0242eaa4'
PACKAGE = Path('tests/artifacts/aa_aa_uv_slowdown/symbolica_evaluator_mre')
TARGET = REPOSITORY / PACKAGE / 'target'
STAGES = ['check', 'build', 'clippy', 'control', 'abstract-control', 'import-write', 'import-read']
SOURCES = ['Cargo.toml', 'Cargo.lock', 'src/main.rs', 'examples/import_remap.rs']
ASSERTION = 'Argument identities changed during import'


def module(name, filename):
    spec = importlib.util.spec_from_file_location(name, BASE / filename)
    loaded = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(loaded)
    return loaded


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def validate_plan(plan):
    commands = plan['commands']
    require(list(commands) == STAGES, 'Unexpected MRE stages or ordering')
    for name in STAGES[:3]:
        expected = ['cargo', name, '--manifest-path', str(PACKAGE / 'Cargo.toml'),
                    '--target-dir', str(TARGET), '--locked', '--all-targets', '--profile', 'dev-optim']
        if name == 'clippy':
            expected += ['--', '-D', 'warnings']
        require(commands[name] == expected, f'Isolated locked {name} command differs from reviewed plan')
    binary = str(TARGET / 'dev-optim/symbolica-evaluator-mre')
    importer = str(TARGET / 'dev-optim/examples/import_remap')
    tiny = str(BASE / 'mre-tiny.symbolica')
    expected = {'control': [binary, '--control'],
                'abstract-control': [binary, '--abstract-parameters', '--control'],
                'import-write': [importer, 'write', tiny], 'import-read': [importer, 'read', tiny]}
    for name, argv in expected.items():
        require(commands[name] == argv, f'Unreviewed or physical MRE invocation: {name}')
    require(plan['expected_exits'] == {'import-read': 101}, 'Expected diagnostic exit differs')
    require(plan['expected_values'] == {'control': 39, 'abstract-control': 4}, 'Control oracles differ')
    return Path(tiny)


def validate_output(name, output, exit_code):
    clean = re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]', '', output)
    if name in {'control', 'abstract-control'}:
        require(exit_code == 0, f'{name} failed')
        events = []
        for line in clean.splitlines():
            try:
                value = json.loads(line)
            except json.JSONDecodeError:
                continue
            if isinstance(value, dict) and 'stage' in value:
                events.append(value)
        stages = [event['stage'] for event in events]
        required = ['symbolica_build_start', 'symbolica_build_done', 'control_passed']
        require(all(stages.count(stage) == 1 for stage in required), f'{name} lacks complete control events')
        require([stages.index(stage) for stage in required] == sorted(stages.index(stage) for stage in required),
                f'{name} control stages are out of order')
        require('panicked at' not in clean and 'assertion failed' not in clean, f'{name} contains a panic')
        return {'classification': 'positive_control', 'asserted_value': 4 if name == 'abstract-control' else 39,
                'value_evidence': 'Pinned numeric assert_eq! completed before the control_passed event; the numeric value is not printed.',
                'events': events}
    compact = [''.join(line.replace('import_mre::', '').split()) for line in clean.splitlines()]
    if name == 'import-write':
        require(exit_code == 0 and compact.count('exportedf(x,y)') == 1, 'Writer did not export the expected ordered function')
        return {'classification': 'diagnostic_input_creation', 'expression': 'f(x,y)'}
    if name == 'import-read':
        require(exit_code == 101, f'Reader did not reproduce the expected diagnostic (exit {exit_code})')
        require(compact.count('importedf(y,x);expectedf(x,y)') == 1, 'Reader did not show the expected argument-identity swap')
        require(re.search(r'panicked at [^\n]*examples/import_remap\.rs:\d+:\d+:', clean),
                'Reader panic is not at the reviewed assertion source')
        require(re.search(r"assertion [`']left == right[`'] failed: " + re.escape(ASSERTION), clean),
                'Reader failed for a different reason than the import identity assertion')
        return {'classification': 'reproduced_upstream_import_diagnostic', 'exit_code': 101,
                'imported': 'f(y,x)', 'expected': 'f(x,y)', 'assertion': ASSERTION,
                'large_evaluator_panic_reproduced': False}
    require(exit_code == 0, f'{name} failed with exit {exit_code}')
    return {'classification': 'build_gate'}


def main():
    require(len(sys.argv) == 1, 'This driver accepts no inputs or extra stages')
    plan_path = BASE / 'mre-validation-plan.json'
    plan = json.loads(plan_path.read_text())
    tiny = validate_plan(plan)
    prefix = module('mre_prefix_support', 'execute-prefix.py')
    stage_runner = module('mre_stage_support', 'run-stage.py')
    audit = module('mre_fingerprint_support', 'audit-nextest-stage.py')
    output = BASE / 'c7-results/mre-validation.json'
    require(not output.exists() and not tiny.exists(), 'MRE output already exists; refusing overwrite or retry')
    for name in STAGES:
        require(not (BASE / 'c7-results' / ('mre-' + name)).exists(), f'Existing MRE stage must be retained: {name}')
    require(json.loads((BASE / 'validation-pins.json').read_text())['c7'] == PIN, 'C7 pin changed; re-review this driver before invocation')
    summary = {'status': 'FAIL', 'revision': PIN, 'started_utc': datetime.now(timezone.utc).isoformat(),
               'plan_sha256': digest(plan_path), 'driver_sha256': digest(Path(__file__)), 'stages': [],
               'classification': 'Standalone correctness controls and an expected upstream import diagnostic; excluded from workspace suite totals.',
               'not_attempted': ['GL262 physical replay', 'large evaluator-construction panic reproduction'],
               'fmt_receipt': {'path': str(BASE / 'mre-fmt.json'), 'sha256': digest(BASE / 'mre-fmt.json'),
                               'scope': 'Existing formatting receipt retained; no formatting rerun by this driver.'}}
    with ExitStack() as stack:
        for path in [BASE / 'prefix-execution.lock', Path('/tmp/gammaloop-aa-aa-uv-build.lock')]:
            lock = stack.enter_context(path.open('a+'))
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        prefix.idle_prefix()
        head = subprocess.check_output(['jj', '--ignore-working-copy', 'log', '-r', '@', '--no-graph', '-T', 'commit_id'], cwd=PREFIX, text=True).strip()
        require(stage_runner.tracked_audit(head)['pass'], 'Prefix has unrecorded tracked changes; refusing jj edit')
        if head != PIN:
            subprocess.run(['jj', 'edit', PIN], cwd=PREFIX, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        require(stage_runner.tracked_audit(PIN)['pass'], 'Prefix does not match pinned C7')
        summary['sources'] = []
        for name in SOURCES:
            source = PREFIX / PACKAGE / name
            expected = subprocess.check_output(['git', '-C', str(REPOSITORY), 'show', PIN + ':' + str(PACKAGE / name)])
            require(source.read_bytes() == expected, f'MRE source differs from pin: {name}')
            summary['sources'].append({'path': str(source), 'sha256': hashlib.sha256(expected).hexdigest(), 'bytes': len(expected)})
        output.parent.mkdir(parents=True, exist_ok=True)
        try:
            for name in STAGES:
                prefix.idle_prefix()
                require(json.loads((BASE / 'validation-pins.json').read_text())['c7'] == PIN, 'C7 pin changed while running')
                argv = plan['commands'][name]
                before = audit.binary_digest(Path(argv[0])) if name not in STAGES[:3] else None
                print(f'RUN c7 mre-{name}', flush=True)
                process = subprocess.run([sys.executable, str(BASE / 'run-stage.py'), 'c7', 'mre-' + name, *argv],
                                         stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
                folder = BASE / 'c7-results' / ('mre-' + name)
                with (folder / 'driver.log').open('x') as stream:
                    stream.write(process.stdout)
                receipt = json.loads((folder / 'result.json').read_text())
                item = {'stage': name, 'argv': argv, 'exit_code': receipt['exit_code'],
                        'result': str(folder / 'result.json'), 'result_sha256': digest(folder / 'result.json'),
                        'output_sha256': digest(folder / 'output.log'), 'elapsed_seconds': receipt.get('elapsed_seconds')}
                summary['stages'].append(item)
                require(receipt['revision'] == PIN and receipt.get('integrity_pass') is True, f'{name} invalidated pinned source integrity')
                require(process.returncode == receipt['exit_code'], f'{name} runner exit differs from child receipt')
                if before:
                    after = audit.binary_digest(Path(argv[0]))
                    require(before == after, f'{name} binary changed during execution')
                    item['binary'] = after
                item.update(validate_output(name, (folder / 'output.log').read_text(errors='replace'), receipt['exit_code']))
                if name == 'import-write':
                    summary['tiny_input'] = {'path': str(tiny), 'sha256': digest(tiny), 'bytes': tiny.stat().st_size}
                    require(0 < tiny.stat().st_size < 1_000_000, 'Tiny diagnostic output has unexpected size')
                if name == 'import-read':
                    require(digest(tiny) == summary['tiny_input']['sha256'], 'Reader changed the exported diagnostic input')
                print(f'OK c7 mre-{name}: {item["classification"]}', flush=True)
            summary.update(status='PASS', positive_controls=2, upstream_diagnostics_reproduced=1,
                           workspace_tests_added_to_totals=0, large_evaluator_panic_reproduced=False)
        except Exception as exc:
            summary['error'] = str(exc)
            raise
        finally:
            summary['completed_utc'] = datetime.now(timezone.utc).isoformat()
            with output.open('x') as stream:
                stream.write(json.dumps(summary, indent=2) + '\n')
            print(f'{summary["status"]}: {output}', flush=True)


if __name__ == '__main__':
    try:
        main()
    except (RuntimeError, OSError, KeyError, ValueError, subprocess.CalledProcessError) as exc:
        print(f'STOP: {exc}', file=sys.stderr)
        sys.exit(1)

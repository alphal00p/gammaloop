# Latest CFF adapter review

Reviewed the entire `78395e3a..a1140c90` diff in all six assigned files, including every changed test and relevant callers. No demonstrated wrong-value production bug was found in this bounded static review. This does not certify numerical results or later builds.

The material findings were tests that fixed cache/pointer identities, exact build/eviction counts, selected private assignments, and native row-count goldens. These are repaired in the root working tree, pending root validation. The source files and exact immutable coverage/hashes are listed in `cff-review.json`.

## Functional ownership

The physical-owner/class namespace, exact class occurrence certificate, pinched affine-carrier reconstruction, opaque positive-block permission and signed diagonal certificates belong in commit3. Their contract is mathematical reconstruction. Physical originals remain fixed to original occurrences, completed class factors can choose certified equivalent occurrences, and soft/remote factors stay at their later integration boundary. Routing signs are restored separately from denominator evenness. The UV reviewer confirmed each production context is scoped to one Graph; the reviewed source preparation key therefore does not need a graph identity under current callers.

Generation/preparation/template-subtree retention, compressed allocation cycles, accounting and selector-free collection form enough distinct performance work for one additional UV generation commit. Keep the shared library changes with commit2 only where they are genuinely shared; the GammaLoop adapter consumes that API in commit3.

## Tests revised

- `generation_cache_obeys_byte_entry_and_access_order_limits`: Retains explicit cache API value/absence behavior, including insertion, replacement, oversize rejection and clear. Removes private accounting/count assertions.
- `canonical_sunset_allocator_matches_native_small_oracle`: All126 degree-5 placements plus bounded degree-5/7 proposals/challengers now compare complete signed exact contours with independent residues at energies(2,3,7). Removes native row goldens, proposal count/order and preferred capacity-layout assertions.
- `bounded_exact_cff_dispatch_preserves_owner_contour`: Existing signed contour regression retains fresh,cached,uncached,disabled,evicted paths; drops build counts, exact internal plans and row counts. Actual test selector is recorded below from source.
- `exact_numerator_templates_and_subtrees_are_retention_invariant`: Complete per-orientation mapped values remain compared with direct mapping; removes pointer identity, template-build, row hit/eviction and cache-size assertions.
- `owned_source_preparation_preserves_assignment_and_coefficient`: Preserves complete contour comparison across retention modes and distinct numerators; removes private plan/row vector equality and exact build/eviction counts.
- `pinched_affine_carrier_requires_occurrence_interpolation`: Retains independent complete3x3 interpolation certificate and signed analytic double contours; removes private source dimensions/membership and affine-block inventory assertions.
- `pinched_positive_block_preserves_joint_affine_assignment`: Preserves literal wrapper/value, source-certified mixed-owner authorization and unmodified soft-role values; replaces private AST-variant assertion with complete mapped value equality.
- `canonical_class_cyclic_lifts_preserve_factorization_and_exact_bounds`: Every admitted plan validates complete collapsed polynomial and independently analyzed mapped capacity; removes exact selected capacity distribution and plan count.
- `canonical_large_powers_keep_assignment_cycles_compressed`: Every plan over500000 powers and5,64,65,128,257occurrences validates mapped capacity and complete polynomial; removes exact packed/balanced distribution, proposal order, leaf-count limit.
- `canonical_challengers_preserve_pools_and_opaque_blocks`: All returned plans/challengers keep candidate membership, complete polynomial, correct declared mapped capacity; opaque denominator wrapper remains complete. Removes exact chosen occurrences and proposal counts/order.
- `canonical_pool_validation_preserves_physical_restrictions_and_domains`: Malformed overlapping pool errors remain; original physical factor is sampled at its supported fixed base instead of checking private family map. Every plan preserves inactive component value.
- `real_dirac_functions_keep_cyclic_energy_assignments_factorized`: Every returned plan preserves gamma/projector symbols and exact collapsed tensor expression plus advertised degree bounds; removes hard-coded count/layout.

Two new tests which corrupted private fields were removed: `assignment_certificate_rejects_understated_capacity` and `exact_assignment_certificate_rejects_invalid_occurrence_sign`. No supported constructor accepts the states they created. Production certificates remain, and public malformed-input/candidate/source-provenance errors remain tested; exact selectors are in JSON. No known-failing expected result or existing tolerance was changed.

The sunset test still enumerates all126 distributions of degree5 over five occurrences and tests allocator degree5/7 alternatives. It now evaluates complete signed contours at on-shell energies(2,3,7). Independent residues give degree5 `1213/16387080192` and degree7 `-365/47775744`; derivation and exact rational arithmetic are in `sunset-independent-contours.json`. The original test's62/346/136/124 row counts are benchmark evidence stated by a1140c90, not correctness targets, and were not rerun by this reviewer. Current architecture documentation calling62rows a test oracle needs corresponding wording.

## Rust patterns and KISS

- **EnergyReference enum and UvDenominatorClassId newtype**: Effective semantic separation of physical owners and completed algebraic classes; accidental equal integer IDs cannot alias.
- **Generic EnergyPowerCapMap<K> with checked arithmetic**: Avoids duplicate degree algebra while keeping physical-only public conversion explicit. Overflow becomes a typed error.
- **Immutable Arc-owned assignment, mapper and template**: Keeps actual sampled payload tied to its certified bounds across retention/eviction; full binding equality is retained behind a cached hash.
- **Identity token Arc<()> for memo rows**: Prevents address reuse without keeping evicted template ASTs alive; correct internal identity purpose, not user-facing contract.
- **Recursive enum compositor with compressed Repeat**: Preserves numerator products, sums and opaque multilinear functions without a Cartesian polynomial expansion; checked cycle advancement guards degree overflow.
- **Generation-local cache and Option<&mut Context>**: Cache absence/eviction affects work only. Separate hit/count/payload state is bounded; per-Graph lifetime makes omitted parent graph key safe.
- **Result-based certificates and exact rational coordinates**: Signed diagonal, denominator ownership and bound checks happen before native CFF dispatch; errors retain actionable owner/class context.
- **Sorted map/set iteration and explicit bounded proposal queue**: Makes decisions deterministic but internal order must not be frozen by numerical tests.

ExactSourceMappingContext duplicates most mapper fields because Replacement is not directly hashable; this has a real cache-identity role but accounting currently rebuilds/clones that context. Measure before introducing more caching layers.

The binding.binding field chain and candidate tuple make the immutable ownership path harder to read; consider field renaming or destructuring when touching these locations. No production rewrite made solely for style.

Keep bounded proposals and shared cache budgets explicit. The source statement62native rows is a measured implementation result, never proof of optimality or a mathematical correctness target.

Formatting passed for the four edited Rust files. Root owns compilation, Clippy and tests; this reviewer ran no build/test process and made no jj mutation.

# Independent watchdog timeout triage

The retained C8 `curated-list` attempt ended with **exit125: monitoring timeout**, during compilation and before a completed listing or test execution. All1925 tracked files matched before/after. The watchdog recorded29 memory samples (logged maximum7.257GB), then its numeric `ps` query exceeded2s. That sampled maximum does not bound memory at the unobserved timeout.

The exact sampler is healthy now: root recorded five successful probes under the original2s deadline (0.223–0.262s), and three independent probes completed around0.200s. This supports a transient recovered monitoring delay, without identifying its underlying host cause.

Recommend one deliberate fresh paired attempt using the **unchanged watchdog**, exact selection,30GB cap,4workers and no test/snapshot retries. Preserve the original failure and use new stage directories; if monitoring fails again, stop for further triage. No test from the failed listing has run. A longer scratch timeout would introduce a wider monitoring interval and lock/provenance changes without evidence that it is needed.

No application execution, source/runner/pin/history change, wrapper read, or process-command/environment dump occurred during this review.

# C7 import fix review

**PASS — static review only.** The single complete hunk in `c7-imports-fix.patch` adds the existing `GammaLoopLinearEnergyExpr` trait and `CffGlobalPrefactorSign` type inside `canonical_sunset_allocator_matches_native_small_oracle`. The trait supplies the unchanged linear-energy `to_atom_gs` call; the type resolves the unchanged signed-prefactor composition. Narrow local imports are sufficient and idiomatic.

Reversing those import edits restores the entire previous `generation.rs` byte for byte. Production code, test inputs, degree distributions, mathematical sign handling, exact degree-5 and degree-7 rational oracles, assertions and comments are unchanged. No assertion is weakened. No build or test was run by this reviewer.

Patch SHA-256: `2e5697ff3e10565540647179d3a4135276cd0dabcfef0dfc154e4e7a00eeb077`. The patch matches the complete immutable Git diff for all three transitions: C7 `a3af927afc633c6e6c2474d3f03fa02e0242eaa4` to `bbb8ff1db499a78b3b25c41f774c9a034acb5b4d`, C8 `b15d068f52a853f88a1dac2818e30af44fbcbc9c` to `1bc2316109c415e9b08020fb836c614847f5d926`, and corrected source `3a917074a0278f8b275f493b0728ca50dc288ea7` to `8b2b355a76f563cd68dc0a3424bacba10e1eb865`. Each has exactly one changed file and one reviewed hunk (+4/−1). C1–C6 and all stable change IDs are unchanged.

Final file SHA-256: `01194a435c5d69536347f43581391e43fa2d732cf962cb3a6b8f81d1f8c9ad74` at C8 `1bc2316109c415e9b08020fb836c614847f5d926`. The new corrected source and C8 have exactly equal tree `792c75a898c7b60f92ce5446256153c3c4ea7e88`. JSON records full before/after file blobs, hashes and patch proofs, including zero-context diff hashes for checkpoint verification.

Fresh workspace validation remains the root task's responsibility. This import review does not promote the older standalone MRE run to a new execution; its original revision remains authoritative.

# Supplemental evidence inventory v4

Proposed only: **101 files / 1508139 bytes**, adding11 completed cache-experiment and closeout-review artifacts. Descriptor SHA-256 `8de100b3b28d4eab3e3190b2a264d1d761b67de4f524022ceb26f81e2c81073a`. V3 and its90 selected payload fingerprints remain unchanged; `reviewed` remains `false`.

Every selected text payload passed the existing safe-read/content screen and byte/metadata recheck. No overlap with captured default555; no stage output or audit file was opened or duplicated. The two text inventories match completed execution receipt hashes and expected directory names; referenced cache/object files were not read.

The v4 listing exit101 remains retained beside the v5 listing/run exit0 context. Independent reviews and exact driver/patch hashes remain scoped to their recorded observations. The discovery-only summary still says its runtime was running; this immutable statement is not a current outcome and is superseded for runtime certification by the actual completed default stage/audit evidence. Context extras add no test executions. Rebuilding four narrowly mapped caches resolved these linker failures without establishing their origin.

Final report/fill/PDF placeholders remain pending. After all C8 suites and final report generation, regenerate the default allowlist, re-difference/refresh exact bytes and add final filled sources/current fill receipt plus real every-page PDF review text evidence. Only then review a final descriptor and package.

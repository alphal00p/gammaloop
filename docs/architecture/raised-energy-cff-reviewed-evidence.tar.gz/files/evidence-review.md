# Latest UV evidence review

Reviewed the complete three architecture JSON reports, all four MRE JSON files, the full speed-up diary, standalone dependency metadata, original-failure summary/panic, and all three shipped Symbolica input blobs. Exact file coverage and hashes are in `evidence-review.json`. This is a read-only audit of recorded evidence, not a new build or benchmark.

## Evidence that checks out

- Recorded source `911f1824f994611d723dff0f50416cb301718617` differs from fetched `a1140c90` only in six documentation files. Production/dependency code therefore matches the fetched implementation before review fixes. All four source-owner hashes match Git blobs; Cargo.lock matches its checksum.
- Parsed all 12,280 JSON values; independently recomputed 288 statistics without arithmetic discrepancy. Recomputed all 36 complete complex pointwise comparisons: worst relative differences are 4.329377502341177e-15 (GL00) and 4.475869895443919e-15 (GL01), below 1e-9.
- Accepted physical benchmark: 18 fresh generations, 108 runtime passes, 2,160 batches, 54,219,459 samples, 4,364.54838759 seconds of actual timing. Five undersized attempts remain recorded and excluded. All ten <=1.15 gates recompute. The 36 comparison rows include repeats/reference rows: two physical momentum points per graph, not 36 independent points.
- All 183 selected correctness names match PASS status lines, with no missing/unexpected names or failure/retry status: scalar 167, physical 2, UV composition 4, cut/threshold 7, API 2, analytic 1. Four immutable test executables and raw logs/receipts rehash correctly. Peak process-tree memory: 1,009,836,032 bytes.
- Rehashed 73 referenced files (~13 GB), then both immutable benchmark executables and 14 original GL262 evidence artifacts. Immutable executables and raw receipts match. Charged dispatch totals reconcile: 4.006%/4.158% of local UV time for GL00/GL01, correctly including child dispatch and raw-physical-degree work.
- Standalone MRE pins Symbolica, Numerica and Graphica to `4d0a833eb8e059d1f95bdae5abed2559830b235f`; dependency metadata and shipped parameter/function-map/tiny inputs match evidence. Three final tiny/scalar controls passed in recorded receipts.

## Limits and documentation follow-ups

Update the architecture's “62-row oracle” description of the revised sunset test to the complete signed contour oracle. Counts such as 62 rows/request and 196 selected rows remain historical benchmark observations, not frozen correctness requirements.

Four old manifest references target mutable original-workspace files: evaluators.rs, two target rlibs, and the MRE target binary. Their current bytes differ from recorded hashes. The source is independently verified against the recorded Git revision; immutable benchmark/test binaries and receipts still match. This is artifact retention drift, not evidence of a numerical failure. The earlier import-remap failure receipt names an older example source hash. A later manifest binds current example source, but the old failure is not a fresh run of it.

Physical acceptance covers eager, uncompiled H1/CPE5 GL00/GL01 at two points, integrated/threshold counterterms disabled. Scalar setup timings include those counterterms but are descriptive single-run measurements (166 observations, 49 labels), not repeated performance acceptance. Twelve scalar observations exceed 1.15; physical aggregate gates do not certify them.

The historical large GL262 failure is explicitly not reproduced by the standalone MRE. Its approximately 19.98 GB Atom reaches Symbolica `.build()` and panics; peak memory remains below the 500 GB guard. Tiny import-remapping failure is separate and does not establish the original cause. GL262 success/performance and manual PySecDec integrations remain uncertified. Current review edits and reconstructed prefixes need fresh validation by the parent task.

No source files edited during the evidence audit.

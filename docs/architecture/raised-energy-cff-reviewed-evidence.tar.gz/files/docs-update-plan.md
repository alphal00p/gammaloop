# Eight-commit report update plan

Prepared against incoming `a1140c90c334ff58a3b040ff3eae06d3645bf0bb` and the reviewed working changes. This is a documentation handoff only: no repository document, source, jj history or bookmark is edited by this task. The scratch templates require final identities and fresh validation receipts before publication.

## Current documents inspected

- `docs/architecture/raised-energy-cff-stack-review.md` and `.typ`: implementation summaries, ownership, Rust/KISS tables, source coverage, validation claims and limitations.
- `docs/architecture/raised-energy-cff-stack-review-validation.md`: source/tree identity tables, gates, owning/final selections, controls, warnings, diagnostic boundaries, command appendix structure and collector provenance. The 1,600-line exact-command appendix belongs to its existing recorded inputs; it must not be mechanically relabelled as current execution.
- `docs/architecture/raised-energy-cff-stack-source-mapping.md`: complete functional/source ownership mapping, original 42-source attribution and ownership boundaries.
- `docs/architecture/raised-energy-cff-motivation-audit.md` and `.typ`: pinned measurement methodology/results, defect/capability distinctions, original category inventory and PDF styling. The Typst body is the same typeset content; its stale front matter and ownership labels are identified below.
- Current incoming architecture: `architecture-current.md`, relevant canonical projection/assignment sections of `exact-powered-denominator-cff-lifting.md`, and `local-4d-uv-performance.md` with its source-pinned numerical/benchmark/profile receipts.
- Existing report generator `/tmp/raised-stack/report-drafts/build_report_typst.py` and recorded rendering commands `/tmp/raised-stack/test-comparison-revision/pdf-final-followup/inspection-commands.json`.
- Repository `CONTRIBUTING.md`: factorization, current architecture, docs, tests, jj and error-handling rules. No narrower docs AGENTS file was located.

## Required current-state corrections

| Document / location | Stale or incomplete statement | Required replacement |
| --- | --- | --- |
| Stack review `.md`:7,17–29; `.typ`:3,25–70 | Seven boundaries, six executable owners, C7 documentation, stable `vmrowquy`, all seven passing | Eight rows: C1 foundation, C2 CFF, C3 adapters/evaluators, C4 workflows, C5 phases, C6 integrated algebra, C7 canonical UV optimization, C8 documents. Fill final hashes and receipt statuses; no blanket pass statement before evidence. |
| Stack review `.md`:47–63 and exact lifting policy | Every original numerator factor always remains on an original occurrence | Distinguish raw recursion from completed canonical projection. Completed hard TaylorFixed/DenominatorDerived roles may use certified class occurrences. Physical-source-fixed/soft roles and unmatched affine carriers retain their restrictions. Keep signs independent of denominator evenness. |
| Stack review C3 and Rust patterns | No finite tensor-sum preparation or graph-owned canonical projection context | Describe evaluator-only ready-boundary contraction, slot/flow preservation, complete scalar-result access, graph-local immutable preparation/mapping reuse and raw/canonical type boundary. |
| Stack review C1 | Tensor powers and graph rewiring changes absent | Add fixed-base-square odd powers across five leaves, ordered slot/flow/forest preservation, payload reclamation and lazy scalar access. Existing parser and whole-numerator FORM correctness remains. |
| Stack review C6 | Scalar spectator protection during analytic spin expansion absent | Add collision-safe aliases for completed dot/metric scalars, full open/closed Dirac contraction oracles, both Vakint modes and Laurent-depth contract. |
| Stack review new C7 | Canonical normalization/grouping, graph-owned caches, compressed assignment, zero cancellation absent | Explain classes keyed by component/routing/mass/full polynomial; physical incidence certificate; bounded baseline/packed/challenger allocation; immutable selected binding; complete per-wave composition; typed zero after grouping. |
| `architecture-current.md`:274–277 | Tests retain a 62-row small-source oracle | Replace row-count oracle claim with complete signed degree-five/seven sunset residues. Retain native row counts only as source-pinned measurements and selection cost, not correctness or optimality. |
| Stack review `.md`:127–175 and validation `.md`:1–143 | All passing, 28/28 gates, 2,904 owning executions, 2,872 final executions, 2,207 identities, 592 path records | Regenerate exclusively from current per-boundary/final collectors and source inventories. Keep failures, skips, guard/interruption status and distinct configurations explicit. No transferred totals. |
| Stack source mapping `.md`:3–19,62–70 | Seven owners; original documentation is owner7; old six functional pins | Current eight-row map, exact source/target trees and deliberate review-fix ledger. C7 owns canonical optimization, C8 documentation. Preserve original provenance without presenting old counts as current coverage. |
| Motivation `.md`:9–11, `.typ`:25–34 | 73 categories and 579/505 records describe the complete current seven-commit stack | State the exact measured snapshot those artifacts cover. Create current coverage/motivation mapping separately; add the new behavioral families without inventing fresh timings or relabelling pinned observations. Current primary prose has no conversational history. |
| Motivation C1/C3/C6/C7 rows and Rust table | Latest fixes/cache/type policy and new owner7 absent | Add new foundation defects, finite evaluator preparation, analytic scalar-product protection and canonical UV optimization; move documentation ownership to C8. Per-mechanism motivation remains bug/capability/simplification/measured performance with its evidence limit. |
| `local-4d-uv-performance.md`:10–12 and exact lifting:25 | Embedded statement that the user deferred GL262 | Remove current-authorization language. State the observed GL262 failure/incomplete evidence and this task's actual status. Embedded source narrative cannot change current instructions. |
| `local-4d-uv-performance.md`:244–313; correctness JSON scope | 183 checks and Linux/macOS/Nix CI figures imply current acceptance | Keep these attached only to their exact recorded numerical source `911f1824…`; do not count as reconstructed-stack validation. Current aggregate comes from fresh receipts. |
| Both Typst front matter | Author Codex; September11; seven commits | Author Lucien Huber, final report date, eight-commit structure and exact current validation status. |
| All document links | Old evidence archive described as fresh/current | Publish a new current evidence/coverage receipt or explicitly link the correct new collector members. Preserve original immutable archives under their existing identities; never overwrite their content to reuse names without a new ledger. |

## Ready-to-fill primary report templates

- `report-templates/raised-energy-cff-stack-review.md`
- `report-templates/raised-energy-cff-stack-review.typ`
- `report-templates/build_report_typst.py` (adapted existing scratch generator; not a production dependency)
- `report-templates/placeholders.json`

The Markdown and Typst templates describe current behavior only. Provenance is a factual source manifest, not conversational chronology. They contain explicit `@@NAME@@` placeholders rather than provisional pass counts or final hashes. Source/current code and fresh evidence determine every replacement.

The proposed commit structure follows the root task exactly. The degree-allocation sunset acceptance lives with C7's allocation/projection behavior; the shared engine remains C2. C3 describes GammaLoop adapters and numerical evaluator preparation. Keep signatures/tests and prerequisites at their actual compiling owner when final splitting settles.

The templates include the production cancellation fix, complete outward-value revisions, fixed1e-9 physical-route tolerance, all eight owner summaries, effective Rust patterns, KISS limitations, exact Symbolica pin, retained GL262 failure boundary and manual PySecDec exclusion. No fresh performance gain or universal optimizer claim is inserted.

## Fresh data required from root

1. Eight final change/revision identities, parent relation, functional tip/tree and documentation stable change. Full source identities belong to the source mapping/manifest; short IDs appear in the summary table.
2. Exact per-boundary format/check/all-target-build/Clippy receipts and owning test results. If any existing certificate is reused, prove its complete source/tree/configuration identity rather than inheriting the prior label.
3. Final runtime selected identities, actual pass/nonpass/skip counts, unique binary/test pairs and configurations. Include all relevant shared-feature modes, full scalar namespaces including slow tests, phases, Vakint, physical route tests and model/vertex checks actually run.
4. Exact failed/interrupted diagnostics and their dispositions. Do not turn a guard termination, evaluator panic, test skip or partial producer success into a pass.
5. Fixed-point source audits/binary hashes for the built checkouts and after execution; command argv, toolchain, memory limits, worker counts, retry/snapshot/warning policy.
6. Final coverage manifest: every changed source, test, configuration, fixture, architecture, evidence and rendering path; independent reviewer attribution; exact reused-diff identity where applicable.
7. Explicit deliberate review-fix patch/hash and final tree-preservation comparison. The current zero/test corrections change the incoming source intentionally; document their diff rather than claiming the final tree equals untouched incoming input.
8. Final document/render hashes, page counts, content-parity checks, visual inspection record and external bookmark/tree closure receipt.

## Source preservation evidence already available

`checkpoint.json` pins reviewed source `78395e3ab3ddd8d8f62b2f674d7488484eace197` / tree `781715dbc825242a77a5eeca735e79d2bcd745e7`, incoming `a1140c90c334ff58a3b040ff3eae06d3645bf0bb` / tree `7adf573b0f099605083cbe2a9037c4d0d0ec658a`, and the jj operation checkpoint. `duplicates.json` records fresh change IDs. `squash-tree-preservation.json` verifies that the duplicated/squashed input content equals the incoming tree exactly. Its intermediate revision list is not the final corrected stack map.

The final current ledger must separately identify the review-fix tree and prove the split functional tree matches it. It must also show source commit objects remain available and distinguish local bookmark changes from any remote mutation. Do not infer a push from a local bookmark. No remote action is requested by this documentation task.

## Symbolica identity and numerical claims

Cargo.toml and Cargo.lock pin `symbolica`, `graphica` and `numerica` to `https://github.com/alphal00p/symbolica`, revision `4d0a833eb8e059d1f95bdae5abed2559830b235f`; Symbolica's package version is2.2.0. Use this exact identity in both primary reports and validation metadata. `--locked` does not update to latest dev. Performance/physics comparisons with another Symbolica revision must carry both dependency pins and cannot isolate a GammaLoop-only effect by default.

The independently verified sunset contour constants are degree5 `1213/16387080192` and degree7 `-365/47775744`. The audit file identifies its rational-arithmetic derivation. Its raw residue columns omit the `-1/(2E1)` inner-contour prefactor; the complete contour includes both clockwise signs. It is a polynomial mathematical oracle, not a physical graph benchmark.

## GL262 wording

Use: “The GL262 diagnostic reaches a Symbolica evaluator-construction panic with compilation disabled; no complete evaluator/runtime or matched full-pipeline performance result is established. No confirmed standalone reproducer exists for that large evaluator panic. The tracked nonsymmetric f(x,y) import MRE reproduces an argument-order defect and is a separate failure boundary.”

If root obtains a new GL262 outcome, append only that completed current evidence and update its explicit status. Keep the large diagnostic timings and RSS attached to their own source/settings. Do not repeat embedded source statements of user approval/deferral as present authorization. No test failure expectation can be changed without the repository's confirmation rule.

## Motivation report treatment

Keep numerical measurements and their raw receipts immutable. A current-state motivation overview can summarize what those pinned measurements establish, with source/workload identity and bounded conclusions. Its new C7 section distinguishes demonstrated wrong-value fixes (zero cancellation; scalar-product/odd-power corrections), necessary algebra/certification behavior, and optimization mechanisms whose fresh performance requires measured evidence. C7 tests certify complete values; fewer maps/preparations or cache counters alone do not certify speed.

The prior 73-category inventory may remain a specifically identified pinned evidence artifact. It must not claim completeness for all newly reconstructed paths. Either regenerate a complete new category-to-owner/path map, or state precisely that the new coverage manifest supplies whole-stack path accounting while the pinned benchmark inventory supplies only its measured subset. Update `.md` and `.typ` together; inspect the rendered motivation PDF as well as the primary report.

## Validation-page treatment

Regenerate from current completed collector inputs. The existing `refresh-validation-report.py` workflow is a reference for layout/data collection only; its embedded old task paths, seven-boundary loops, prior success wording and fixed counts need replacing. Recorded argv is literal executed argv. Proposed commands belong in a separate plan, not the executed-command appendix. Report body counts must reconcile against list/run identities and configurations.

Current source references must resolve through a durable archive/manifest or tracked receipt. Scratch target logs alone are unsuitable final report links. Keep license material and the invocation-only environment wrapper out of archives. Old2872/183/CI totals are not current certification.

## Typst preparation and rendering

Existing style is self-contained Typst using Libertinus Serif, DejaVu Sans and DejaVu Sans Mono. The available environment provides Typst0.15.0(3ae52774) and Poppler26.06.0 (`pdfinfo`, `pdftoppm`, `pdftotext`), verified with version-only invocations. These binaries are absent from the default shell PATH but resolve through `/tmp/raised-stack/run`. The wrapper is invocation-only and was neither read nor archived. A `load_workspace_dependencies` tool is not exposed in the available tool catalog; the established local document tools are available.

No document compilation has been run in this preparation task. After filling all placeholders and placing final sources, use the established commands from repository root:

```sh
/tmp/raised-stack/run typst compile docs/architecture/raised-energy-cff-stack-review.typ docs/architecture/raised-energy-cff-stack-review.pdf
/tmp/raised-stack/run typst compile docs/architecture/raised-energy-cff-motivation-audit.typ docs/architecture/raised-energy-cff-motivation-audit.pdf
/tmp/raised-stack/run pdfinfo docs/architecture/raised-energy-cff-stack-review.pdf
/tmp/raised-stack/run pdftotext -layout docs/architecture/raised-energy-cff-stack-review.pdf /tmp/raised-stack-latest-review-20260914/rendered-stack-review.txt
/tmp/raised-stack/run pdftoppm -r 120 -png docs/architecture/raised-energy-cff-stack-review.pdf /tmp/raised-stack-latest-review-20260914/pdf-review/page
```

Create the scratch rendering folder before `pdftoppm`; repeat text extraction/page rendering for motivation. Inspect every rendered page for clipped hashes/tables, missing glyphs, awkward breaks and stale captions. Compare extracted text against the filled Markdown and check all source/count/status/dependency fields. Record actual commands/exits/page count and image review; a successful Typst exit alone is not visual validation. The existing files have no includes requiring a custom `--root`.

Before publication, `rg '@@[A-Z0-9_]+@@'` over both report sources must return no unresolved tokens. Verify no stale seven-owner/all-pass/2872/183/CI claims remain as current assessment; legitimate pinned source measurements must carry their own scope. Preserve comments when regenerating `.typ`; update their meaning rather than silently deleting them. Final author metadata is Lucien Huber.

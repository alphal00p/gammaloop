# Final C8 document application and closure

Prepared from the current updater, filler, packager, pin schemas and repository guidance. This is an application recipe only; no repository, history, pin, plan or runner changes were performed.

Current immutable inputs:

- Corrected source: `392c98c3d2f70896ef94267addfcf610e2df2c88`.
- Reconciled C8: `449a59f6f173d100c2da858c541faa1e0dccca6e`.
- Both trees: `c87cc95044663a68413010aceb81f9475be342c1`.
- C7: `6d7a9220129c0fac37bdc0e04ebefccb1688c7be`.
- Stable C8 change: `oxsmszsroxrtxtzpowrowplwlqnowzyn`.

`TASK` below means `/tmp/raised-stack-latest-review-20260914`. Run Python helpers with `/tmp/raised-stack/python`; these reporting helpers need no licensed wrapper. Do not use the historical, hardcoded `report-updater/finalize-closure.py`.

## 1. Freeze the completed candidate evidence

Finish the active batch and every immediate nextest audit before changing pins. Run the existing updater with `--require-complete`; do not proceed on INCOMPLETE or unresolved provenance issues. Freeze the accepted ledger, exact command plan, pins, source proof chain, review receipts and their hashes. Derive the tested C8 revision from the accepted receipts; it must be the single candidate whose C8 gates will be reused, currently the reconciled C8 above. Preserve failed attempts and original executed revisions/binary hashes.

Before repository mutation, confirm the parent batch is idle, use the existing `idle_prefix()` guard and acquire `TASK/prefix-execution.lock` exclusively. Manual commands also need to be idle: the advisory lock alone cannot establish this. Record a jj operation checkpoint, the current root working-copy change, all eight commit records, bookmark/protected-ref values and exclusive backups of both pin files. Stop if unexpected root changes would be carried into C8.

## 2. Finish candidate-scoped reports and package once

Before updating pins, generate accepted drafts and fill the main report:

```sh
/tmp/raised-stack/python "$TASK/report-updater/update-current-reports.py" --review-followup "$TASK/c1-clippy-readability-fix-review.json" --require-complete
/tmp/raised-stack/python "$TASK/report-templates/fill-current-report.py" --require-complete
```

Use the existing documentation workflows for any other final reports. Keep candidate hashes explicitly scoped to the executed snapshot; use C8's stable change ID for its continuing identity. The filler verifies Markdown/Typst visible-body parity but does not compile or inspect PDFs. Compile every changed Typst document, inspect every rendered page and record source/PDF hashes and actual findings separately.

Review the generated exact `report-updater/drafts/archive-allowlist.json`, then invoke the existing packager with its reviewed SHA256. Add necessary new review/render receipts only through its structured, separately reviewed extras list:

```sh
/tmp/raised-stack/python "$TASK/package-evidence.py" --reviewed-allowlist-sha256 REVIEWED_SHA256
```

The packager refuses an existing output directory; preserve any prior package rather than overwrite it. It produces `evidence-package/raised-energy-cff-reviewed-evidence.tar.gz`, `manifest.json` and `package-receipt.json`. Keep its regular-file, symlink, size, content-screening and frozen-hash checks. Do not include binaries, states, environment dumps, the license wrapper or the future final closure/verification output. Freeze an explicit reviewed source-to-destination artifact list; do not use wildcard copies. Main MD/Typst/PDF, current mapping/validation/source-mapping reports, MRE sidecars, and the new archive/manifest belong under reviewed `docs/architecture/` names. Preserve unrelated and historical documents.

## 3. Amend C8 documents only

With the idle checks/lock still effective, edit only the stable C8 change:

```sh
jj edit oxsmszsroxrtxtzpowrowplwlqnowzyn
```

Copy the exact reviewed artifacts, snapshot, and obtain the resulting full C8 commit/tree IDs. Do not restore these documents into the corrected-source change or append a new reconciliation checkpoint. Review the entire final diff against both the tested candidate and reconciled C8. Each changed path must be under `docs/architecture/` and end in `.md`, `.typ`, `.pdf`, `.json` or `.tar.gz`; verify changed entries are regular blobs, with no deletions or mode-only surprises. The current closure verifier needs a final blob hash for every changed path, so it cannot certify a deleted document.

Verify C1–C7 IDs/trees remain exact, C8 retains its stable change ID, parent C7 and `Lucien Huber <im@lcnbr.ch>` author, and all eight commits remain nonempty, linear and conflict-free. Prove both complete deltas are limited to the reviewed document paths. The corrected-source commit and tree stay immutable; final C8's full tree is expected to differ.

## 4. Update the existing schemas and create the external certificate

Prepare and validate both complete JSON values before publishing them under the idle lock; use same-directory temporary files and `os.replace`, then re-read the pair before another reader runs. This is a guarded two-file update, not a filesystem transaction.

- `corrected-stack.json`: update only `commits[7].commit` and `.tree`; retain its `change_id`, C1–C7, `corrected_source_revision`, `corrected_tree` and `exact_preservation`. The latter fields continue to describe the immutable pre-document split proof.
- `validation-pins.json`: update only `c8`. Preserve `c1`–`c7`, `latest`, and historical `commit-1` through `commit-8`.
- Leave `reconciled-stack-proof.json` and `reconciliation-followups.json` unchanged.

Create `TASK/final-document-closure.json` exclusively, outside the repository, using these actual updater fields:

```json
{
  "status": "PASS",
  "tested_revision": "ACTUALLY_TESTED_C8",
  "final_revision": "NEW_FINAL_C8",
  "reconciled_revision": "449a59f6f173d100c2da858c541faa1e0dccca6e",
  "stable_change_id": "oxsmszsroxrtxtzpowrowplwlqnowzyn",
  "identical_production_build_test_config": true,
  "allowed_changed_paths": ["EXACT_SORTED_TESTED_TO_FINAL_PATHS"],
  "reconciled_allowed_changed_paths": ["EXACT_SORTED_RECONCILED_TO_FINAL_PATHS"],
  "document_review_status": "PASS",
  "document_reviewer": "ACTUAL_REVIEWER",
  "reviewed_document_sha256": {"EACH_PATH_IN_THE_UNION": "FINAL_GIT_BLOB_SHA256"},
  "reusable_stages": ["EXACT_ACCEPTED_CANONICAL_C8_GATE_NAMES"]
}
```

Derive each path list using `git diff --name-only -z FROM FINAL`; require exact sets without duplicates. Hash final Git blob bytes, including archive/PDF bytes, for the union of the two deltas. List reusable names from accepted C8 ledger gates, including paired listings and standalone gates. Keep canonical plan names, not `-vN` receipt-folder aliases. The certificate supports one tested revision, not arbitrary mixing of older C8 attempts; MRE evidence retains its separate source-equivalence scope. Record the real document/PDF review evidence and pre/post pin hashes in an external application receipt.

## 5. Verify externally and move the local bookmark

Run the updater with the explicit closure into a fresh external directory:

```sh
/tmp/raised-stack/python "$TASK/report-updater/update-current-reports.py" --review-followup "$TASK/c1-clippy-readability-fix-review.json" --closure "$TASK/final-document-closure.json" --out "$TASK/final-document-verification" --require-complete
```

Verify COMPLETE, both exact deltas, all final document fingerprints and unchanged accepted execution counts/identities. Reused receipts must retain their actual `executed_revision`; the closure adds no test executions. Do not copy this final verification output into C8 or regenerate/reapply the reports after it: those bytes would introduce a new final hash and invalidate the certificate. A necessary document correction requires an explicitly preserved replacement snapshot/certificate, not a hidden regeneration loop.

Finally set only the requested local bookmark:

```sh
jj bookmark set codex/raised-energy-cff-reviewed -r NEW_FINAL_C8
```

Verify the bookmark resolves to the certified final C8, protected refs match the checkpoint, and the corrected-source proof still resolves unchanged. Record bookmark verification externally. Do not push or modify thermal/threshold branches. Release the lock when the pin pair and closure verification are complete; no further application tests are implied by this document-only equivalence.

#!/usr/bin/env python3
"""Apply only a separately frozen and reviewed final C8 document map.

Preparation does not authorize execution. No build/test, prefix edit, bookmark
move, push, report regeneration into C8, or automatic rollback/retry occurs here.
The final collector output and closure stay external to avoid a self-hash loop.
"""
import argparse
import copy
from datetime import datetime, timezone
import fcntl
import hashlib
import io
import json
import os
from pathlib import Path
import stat
import types
import tarfile

TASK = Path('/tmp/raised-stack-latest-review-20260914')
ROOT = Path('/common/dev/gammaloop/higher-power-energies-review')
PREFIX = Path('/tmp/raised-stack/prefix')
PYTHON = '/tmp/raised-stack/python'
MAIN = '395610143576507503fd2c785db3ba62340f4277'
SOURCE_CHANGE = 'mzxyvvusvpusoswoovkmsxzvqpsqrnxx'
C8_CHANGE = 'oxsmszsroxrtxtzpowrowplwlqnowzyn'
VALIDATION = 'report-updater/drafts/raised-energy-cff-stack-current-validation.json'
MAPPING = 'report-updater/drafts/raised-energy-cff-stack-current-mapping.json'
FILL = 'report-templates/filled/report-fill-receipt.json'
FOLLOWUP = 'c1-clippy-readability-fix-review.json'
ATTEMPT = TASK / 'final-document-application'
CLOSURE = TASK / 'final-document-closure.json'
REQUIRED = {
    'apply-approved-numeric-sign.py', 'execute-prefix.py', 'run-stage.py',
    'report-updater/update-current-reports.py',
    'corrected-stack.json', 'validation-pins.json',
    'prefix-validation-plan.executable.json',
    'final-document-artifact-map.proposed.json', 'final-document-static-review.json',
    'final-document-application-plan.md', FOLLOWUP, FILL, VALIDATION, MAPPING,
    'report-templates/fill-current-report.py', 'report-templates/build_report_typst.py',
    'report-templates/current-report.md.in', 'package-evidence.py',
    'tool-versions.json', 'motivation-render/receipt.json', 'motivation-render/visual-inspection.json',
}


def frozen_read(path, digest=None):
    # Bootstrap guard before loading already-reviewed existing orchestration helpers.
    path = Path(path)
    if (not path.is_absolute() or not path.is_relative_to(TASK)
            or '..' in path.parts or path.is_symlink()
            or any(parent.is_symlink() for parent in path.parents)):
        raise RuntimeError('Frozen input must be a direct file under the task directory.')
    before = path.stat()
    if not stat.S_ISREG(before.st_mode):
        raise RuntimeError('Frozen input is not a regular file.')
    data = path.read_bytes()
    after = path.stat()
    if (before.st_ino, before.st_size, before.st_mtime_ns, before.st_mode) != (
            after.st_ino, after.st_size, after.st_mtime_ns, after.st_mode):
        raise RuntimeError('Frozen input changed during read.')
    if digest is not None and hashlib.sha256(data).hexdigest() != digest:
        raise RuntimeError('Frozen input hash differs from the reviewed map.')
    return data


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--apply', action='store_true', required=True,
                        help='Parent confirms the frozen map/reviews and all execution/audits are idle.')
    parser.add_argument('--artifact-map', type=Path, required=True)
    parser.add_argument('--reviewed-map-sha256', required=True)
    args = parser.parse_args()
    descriptor_bytes = frozen_read(args.artifact_map, args.reviewed_map_sha256)
    descriptor = json.loads(descriptor_bytes)
    if (descriptor.get('schema_version') != 1 or descriptor.get('status') != 'REVIEWED_FROZEN'
            or descriptor.get('document_review_status') != 'PASS'
            or not descriptor.get('document_reviewer')
            or descriptor.get('application_script_sha256') != hashlib.sha256(Path(__file__).read_bytes()).hexdigest()):
        raise RuntimeError('The final artifact map/application script has not been explicitly frozen and reviewed.')
    hashes = descriptor['inputs_sha256']
    if not REQUIRED <= hashes.keys():
        raise RuntimeError('Required input hashes are missing.')
    frozen = {name: frozen_read(TASK / name, digest) for name, digest in hashes.items()}
    # Reuse existing mutation tracing, jj metadata, original-ref and tracked-file guards.
    loaded = {}
    for role, relative in [('app', 'apply-approved-numeric-sign.py'), ('executor', 'execute-prefix.py'),
                           ('runner', 'run-stage.py'), ('updater', 'report-updater/update-current-reports.py')]:
        module = types.ModuleType('final_document_' + role)
        module.__file__ = str(TASK / relative)
        exec(compile(frozen[relative], module.__file__, 'exec'), module.__dict__)
        loaded[role] = module
    app, executor, updater = (loaded[role].__dict__ for role in ('app', 'executor', 'updater'))
    runner = loaded['runner']
    require, command, sha = app['require'], app['command'], app['sha']
    metadata, jj_value, tree = app['metadata'], app['jj_value'], app['tree']
    read_json = lambda name: json.loads(frozen[name])
    application_review = read_json(descriptor['application_review_receipt'])
    require(application_review['status'] == 'PASS' and application_review['findings'] == []
            and application_review['reviewers']
            and application_review['script_sha256'] == descriptor['application_script_sha256'],
            'Independent application review does not certify the exact proposed script.')
    require(set(updater['FIXED_INPUTS']) <= hashes.keys(), 'Missing fixed collector provenance inputs.')
    proposal = read_json('final-document-artifact-map.proposed.json')
    entries = descriptor['entries']
    require([(row['source'], row['destination']) for row in entries]
            == [(row['source'], row['destination']) for row in proposal['entries']],
            'Frozen artifact paths differ from the reviewed proposed map.')
    require(len(entries) == 12 and len({row['destination'] for row in entries}) == 12,
            'Expected twelve unique reviewed artifact destinations.')
    payload = {}
    for row in entries:
        destination = Path(row['destination'])
        require(destination.is_relative_to('docs/architecture') and '..' not in destination.parts
                and not destination.is_absolute()
                and str(destination).endswith(('.md', '.typ', '.pdf', '.json', '.tar.gz')),
                'Destination is outside the reviewed documentation allowlist.')
        data = frozen_read(row['source'], row['sha256'])
        require(len(data) == row['bytes'], 'Frozen artifact size mismatch.')
        payload[row['destination']] = data
    old = read_json('corrected-stack.json')
    pins = read_json('validation-pins.json')
    plan = read_json('prefix-validation-plan.executable.json')
    validation, mapping, fill = read_json(VALIDATION), read_json(MAPPING), read_json(FILL)
    source = descriptor['corrected_source_revision']
    tested = descriptor['tested_revision']
    reconciled = descriptor['reconciled_revision']
    require(len(old['commits']) == 8 and old['commits'][-1]['change_id'] == C8_CHANGE
            and old['corrected_source_revision'] == source and old['exact_preservation'] is True
            and old['commits'][-1]['commit'] == tested == reconciled,
            'This one-shot amendment requires the tested candidate to be the current reconciled C8.')
    require(validation['status'] == 'COMPLETE' and not validation['provenance_issues']
            and not mapping['issues'] and mapping['split_preservation_verified'] is True
            and validation['pins'] == mapping['commits']
            and [{key: row[key] for key in ('commit', 'change_id', 'tree')}
                 for row in validation['pins']] == old['commits'], 'Candidate evidence is incomplete or stale.')
    require(validation['tool_versions'] == read_json('tool-versions.json')
            and validation['motivation_rendering'] == read_json('motivation-render/visual-inspection.json'),
            'Candidate ledger differs from frozen tool or motivation-render evidence.')
    proof = mapping['immutable_pre_document_proof']
    require(proof['reconciled_revision'] == reconciled and proof['corrected_source_revision'] == source
            and mapping['observed_top'] == tested, 'Candidate evidence does not bind the current reconciliation proof.')
    planned = [(f'C{prefix["prefix"]}', stage, argv)
               for prefix in plan['prefixes'] for stage, argv in prefix['stages']]
    require([(g['owner'], g['stage'], g['planned_argv']) for g in validation['gates']] == planned
            and all(g['status'] == 'PASS' and g['receipt'] for g in validation['gates']),
            'Not every exact planned gate has an accepted passing receipt.')
    c8_stages = [stage for owner, stage, _ in planned if owner == 'C8']
    require(c8_stages and all(g['executed_revision'] == tested
                             for g in validation['gates'] if g['owner'] == 'C8'),
            'C8 evidence was executed at more than one candidate.')
    for name, digest in validation['source_inputs_sha256'].items():
        require(hashes.get(name) == digest, 'Collector input is not frozen at the candidate hash.')
    require(fill['status'] == 'PASS' and fill['application_validation_status'] == 'COMPLETE'
            and fill['unfilled_placeholders'] == [] and fill['root_input_fields'] == []
            and fill['ledger_generated_utc'] == validation['generated_utc']
            and fill['observed_functional_tip'] == old['commits'][6]['commit']
            and fill['stable_c8_change_id'] == C8_CHANGE, 'Filled sources are not complete candidate reports.')
    required_fill_inputs = {str(TASK / name) for name in (MAPPING, VALIDATION, 'corrected-stack.json',
                            'prefix-validation-plan.executable.json', 'report-templates/current-report.md.in',
                            'report-templates/build_report_typst.py',
                            'report-updater/drafts/raised-energy-cff-mre-validation.json')}
    require(required_fill_inputs == set(fill['input_sha256'])
            and set(fill['outputs']) == {'raised-energy-cff-stack-review.md', 'raised-energy-cff-stack-review.typ'}
            and fill['filled_placeholder_count'] == len(fill['fields']) > 0,
            'Filled source receipt omits a consumed input or either rendered output.')
    for name, digest in fill['input_sha256'].items():
        relative = str(Path(name).relative_to(TASK))
        require(hashes.get(relative) == digest, 'Fill input is not frozen at its consumed hash.')
    for filename, digest in fill['outputs'].items():
        require(sha(payload['docs/architecture/' + filename]) == digest, 'Filled source output hash mismatch.')
    for name in (VALIDATION, MAPPING):
        require(payload['docs/architecture/' + Path(name).name] == frozen[name], 'Copied ledger differs from frozen evidence.')
    pdf = read_json(descriptor['pdf_review_receipt'])
    require(pdf['status'] == 'PASS' and pdf['reviewer'] == descriptor['document_reviewer']
            and type(pdf['pages']) is int and pdf['pages'] > 0
            and pdf['inspected'] == list(range(1, pdf['pages'] + 1)) and pdf['findings'] == []
            and pdf['source_typst_sha256'] == sha(payload['docs/architecture/raised-energy-cff-stack-review.typ'])
            and pdf['pdf_sha256'] == sha(payload['docs/architecture/raised-energy-cff-stack-review.pdf']),
            'Final PDF does not have an exact successful every-page review.')
    compile_argv = pdf['compile']['argv']
    source_by_destination = {row['destination']: row['source'] for row in entries}
    require(pdf['compile']['exit_code'] == 0 and Path(compile_argv[0]).name == 'typst'
            and compile_argv[1] == 'compile'
            and compile_argv[-2:] == [source_by_destination['docs/architecture/raised-energy-cff-stack-review.typ'],
                                     source_by_destination['docs/architecture/raised-energy-cff-stack-review.pdf']]
            and pdf['evidence_sha256']
            and all(hashes.get(name) == digest for name, digest in pdf['evidence_sha256'].items()),
            'Final PDF compilation/evidence is not frozen to these source/output bytes.')
    manifest_data = payload['docs/architecture/raised-energy-cff-reviewed-evidence-manifest.json']
    manifest = json.loads(manifest_data)
    package = json.loads(payload['docs/architecture/raised-energy-cff-reviewed-evidence.json'])
    archive_data = payload['docs/architecture/raised-energy-cff-reviewed-evidence.tar.gz']
    require(package['status'] == 'PACKAGED' and package['archive_sha256'] == sha(archive_data)
            and package['archive_bytes'] == len(archive_data) and package['manifest_sha256'] == sha(manifest_data)
            and package['payload_files'] == manifest['payload_files'] == len(manifest['files'])
            and package['payload_bytes'] == manifest['payload_bytes'] == sum(row['bytes'] for row in manifest['files']),
            'Evidence package receipt, manifest, counts or artifact hashes differ.')
    allowlist = read_json(descriptor['archive_allowlist'])
    extras = read_json(descriptor['archive_extras'])
    require(allowlist['root'] == extras['root'] == str(TASK) and extras['reviewed'] is True
            and manifest['allowlist_sha256'] == hashes[descriptor['archive_allowlist']]
            and manifest['extras_sha256'] == hashes[descriptor['archive_extras']],
            'Package selection differs from the explicitly frozen reviewed descriptors.')
    selected = {}
    for selection in (allowlist, extras):
        for row in selection['entries']:
            require(row['path'] not in selected, 'Package descriptors overlap or contain duplicates.')
            selected[row['path']] = row
    require({row['path'] for row in manifest['files']} == set(selected)
            and str(args.artifact_map.relative_to(TASK)) not in selected
            and 'final-document-closure.json' not in selected,
            'Package inventory differs from reviewed descriptors or contains a self-reference.')
    members = {'MANIFEST.json': (len(manifest_data), sha(manifest_data))}
    for row in manifest['files']:
        require(row['archive_path'] == 'files/' + row['path'] and row['archive_path'] not in members,
                'Duplicate or malformed package member.')
        reviewed = selected[row['path']]
        require(row['bytes'] == reviewed['bytes']
                and ('sha256' not in reviewed or reviewed['sha256'] == row['sha256']),
                'Package member differs from its reviewed selection fingerprint.')
        members[row['archive_path']] = (row['bytes'], row['sha256'])
        # Bind every archived file to its current source; no stale receipt or pre-fill report silently survives.
        require(sha(frozen_read(TASK / row['path'])) == row['sha256'], 'Package contains stale candidate evidence.')
    require(all('files/' + name in members and members['files/' + name][1] == sha(frozen[name])
                for name in (VALIDATION, MAPPING, FILL, FOLLOWUP)), 'Package omits current candidate certification inputs.')
    with tarfile.open(fileobj=io.BytesIO(archive_data), mode='r:gz') as archive:
        actual = archive.getmembers()
        require(len(actual) == len(members) and {item.name for item in actual} == set(members), 'Archive member set mismatch.')
        for item in actual:
            require(item.isfile() and item.mode == 0o644 and item.size == members[item.name][0]
                    and sha(archive.extractfile(item).read()) == members[item.name][1], 'Archive content or mode mismatch.')
    for target in [ATTEMPT, CLOSURE]:
        require(not target.exists() and not target.is_symlink(), 'A prior application attempt or closure exists; no retry.')
    with (TASK / 'prefix-execution.lock').open('a+') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        executor['idle_prefix']()
        # The same existing active-Cargo/nextest guard also covers ROOT.
        idle_globals = executor['idle_prefix'].__globals__
        previous_prefix = idle_globals['PREFIX']
        try:
            idle_globals['PREFIX'] = ROOT
            executor['idle_prefix']()
        finally:
            idle_globals['PREFIX'] = previous_prefix
        rows = [metadata(row['change_id']) for row in old['commits']]
        c8_description = command(['git', 'show', '-s', '--format=%B', tested])
        require(rows == old['commits'] and all(pins[f'c{i}'] == row['commit'] for i, row in enumerate(rows, 1)),
                'Stable jj changes or dispatch pins differ from the frozen candidate.')
        source_before = metadata(SOURCE_CHANGE)
        require(source_before['commit'] == source == jj_value('@')
                and source_before['tree'] == old['corrected_tree'] == rows[-1]['tree'],
                'ROOT is not the unchanged corrected source with the reconciled C8 tree.')
        parent = MAIN
        for row in rows:
            require(command(['git', 'show', '-s', '--format=%P', row['commit']]).decode().strip() == parent,
                    'The reconstructed stack is not the expected linear chain.')
            parent = row['commit']
        root_before = app['tracked'](runner, ROOT, source)
        prefix_before = jj_value('@', cwd=PREFIX)
        prefix_audit = app['tracked'](runner, PREFIX, prefix_before)
        source_paths = set(command(['git', 'ls-tree', '-r', '--name-only', '-z', source]).split(b'\0'))
        untracked = set(command(['git', 'ls-files', '--others', '--exclude-standard', '-z']).split(b'\0'))
        require(not (untracked - source_paths), 'ROOT has unexpected nonignored untracked files.')
        bookmark_argv = ['jj', '--ignore-working-copy', 'bookmark', 'list', '--all-remotes',
                         '--template', 'name ++ "\\t" ++ remote ++ "\\t" ++ normal_target.commit_id() ++ "\\n"']
        git_ref_argv = ['git', 'for-each-ref', '--format=%(refname) %(objectname)', 'refs/heads', 'refs/remotes']
        bookmarks, git_refs = command(bookmark_argv), command(git_ref_argv)
        require(not any(line.endswith('\t' + tested) for line in bookmarks.decode().splitlines()),
                'A bookmark follows C8; review automatic movement before this separate-bookmark recipe.')
        protected = app['protected_refs']()
        require(protected, 'Protected reference inventory is unexpectedly empty.')
        provenance = read_json('report-updater/original-source-provenance.json')
        originals = {row['commit']: row['tree'] for row in provenance['original_commits']}
        require(len(originals) == 42, 'Original source inventory must contain 42 immutable commits.')
        originals.update({row['commit']: row['tree'] for row in rows})
        originals[source] = source_before['tree']
        checkpoint_base = read_json('checkpoint.json')['base']
        original_seven = command(['git', 'rev-list', '--reverse', MAIN + '..' + checkpoint_base]).decode().splitlines()
        require(len(original_seven) == 7, 'Original reviewed seven-commit chain differs.')
        originals.update({revision: tree(revision) for revision in original_seven + [pins['latest'], MAIN]})
        require(all(tree(revision) == digest for revision, digest in originals.items()), 'Original input tree mismatch.')
        for destination in payload:
            path = ROOT / destination
            require(not path.is_symlink() and not any(parent.is_symlink() for parent in path.parents)
                    and path.parent.is_dir() and (not path.exists() or path.is_file())
                    and not path.with_name('.' + path.name + '.final-document.pending').exists()
                    and not path.with_name('.' + path.name + '.final-document.pending').is_symlink(),
                    'Unsafe document destination or existing temporary replacement.')
        require(frozen_read(args.artifact_map, args.reviewed_map_sha256) == descriptor_bytes, 'Artifact map changed.')
        for name, digest in hashes.items():
            frozen_read(TASK / name, digest)
        ATTEMPT.mkdir(mode=0o700)
        result = {'status': 'FAIL', 'phase': 'candidate_preflight', 'commands': app['TRACE'],
                  'artifact_map_sha256': args.reviewed_map_sha256, 'tested_revision': tested,
                  'reconciled_revision': reconciled, 'bookmark_moved': False}
        try:
            # Collector scans immutable source receipts only; it performs no validation execution.
            collector = [PYTHON, str(TASK / 'report-updater/update-current-reports.py'),
                         '--base', str(TASK), '--repo', str(ROOT), '--require-complete',
                         '--review-followup', str(TASK / FOLLOWUP)]
            frozen_read(TASK / 'report-updater/update-current-reports.py', hashes['report-updater/update-current-reports.py'])
            command(collector + ['--out', str(ATTEMPT / 'candidate-verification')])
            fresh = json.loads((ATTEMPT / 'candidate-verification/raised-energy-cff-stack-current-validation.json').read_bytes())
            require(fresh['status'] == 'COMPLETE' and fresh['gates'] == validation['gates']
                    and fresh['final_runtime'] == validation['final_runtime']
                    and fresh['all_attempts'] == validation['all_attempts']
                    and fresh['source_inputs_sha256'] == validation['source_inputs_sha256'],
                    'Candidate evidence changed after its reports/package were frozen.')
            for name in ('corrected-stack.json', 'validation-pins.json'):
                with (ATTEMPT / (name + '.before')).open('xb') as stream:
                    stream.write(frozen[name])
                    stream.flush()
                    os.fsync(stream.fileno())
            checkpoint = {'status': 'CHECKPOINT_BEFORE_DOCUMENT_APPLICATION',
                          'operation': command(['jj', '--ignore-working-copy', 'op', 'log', '--limit', '1', '--no-graph', '-T', 'id']).decode().strip(),
                          'corrected_source': source_before, 'stack': old, 'pins': pins,
                          'root_tracked': root_before, 'prefix_revision': prefix_before, 'prefix_tracked': prefix_audit,
                          'bookmarks': bookmarks.decode().splitlines(), 'git_refs': git_refs.decode().splitlines(),
                          'protected_refs': protected, 'original_input_trees': originals,
                          'artifact_map_sha256': args.reviewed_map_sha256, 'inputs_sha256': hashes}
            app['exclusive_json'](ATTEMPT / 'checkpoint.json', checkpoint)
            result['phase'] = 'amend_C8_documents'
            require(jj_value('@') == source, 'ROOT moved during preflight.')
            app['tracked'](runner, ROOT, source)
            executor['idle_prefix']()
            for name, digest in hashes.items():
                frozen_read(TASK / name, digest)
            for row in entries:
                require(frozen_read(row['source'], row['sha256']) == payload[row['destination']],
                        'A frozen artifact changed during preflight.')
            command(['jj', 'edit', C8_CHANGE])
            require(jj_value('@') == tested, 'ROOT did not switch to the frozen C8 candidate.')
            app['tracked'](runner, ROOT, tested)
            for destination, data in payload.items():
                # Adjacent replacements keep os.replace on the same filesystem. Snapshot
                # only after every temporary replacement has been removed.
                target = ROOT / destination
                temporary = target.with_name('.' + target.name + '.final-document.pending')
                with temporary.open('xb') as stream:
                    stream.write(data)
                    stream.flush()
                    os.fsync(stream.fileno())
                temporary.chmod(0o644)
                os.replace(temporary, target)
            # The archive may exceed jj's default 1 MiB new-file limit. This override
            # applies only to this snapshot and is bounded by reviewed artifact sizes.
            command(['jj', '--config', 'snapshot.max-new-file-size=' + str(max(map(len, payload.values()))),
                     'status', '--no-pager'])
            final_rows = [metadata(row['change_id']) for row in rows]
            final = final_rows[-1]['commit']
            require(final_rows[:7] == rows[:7] and final != tested and jj_value('@') == final
                    and metadata(SOURCE_CHANGE) == source_before
                    and command(['git', 'show', '-s', '--format=%B', final]) == c8_description
                    and command(['git', 'show', '-s', '--format=%P', final]).decode().strip() == rows[6]['commit'],
                    'C1-C7, source identity or the final C8 parent changed.')
            final_entries = updater['tree_entries'](ROOT, final)
            deltas = {}
            for label, before in (('tested', tested), ('reconciled', reconciled)):
                changed = sorted(p for p in command(['git', 'diff', '--no-ext-diff', '--no-renames', '--name-only', '-z', before, final]).decode().split('\0') if p)
                require(changed and set(changed) <= payload.keys(), 'Actual amended paths exceed the reviewed document map.')
                before_entries = updater['tree_entries'](ROOT, before)
                for path in changed:
                    require(final_entries.get(path, {}).get('mode') == '100644'
                            and final_entries[path]['kind'] == 'blob'
                            and (path not in before_entries or before_entries[path]['mode'] == '100644')
                            and command(['git', 'show', final + ':' + path]) == payload[path],
                            'Changed artifact is deleted, has an unexpected mode or differs from reviewed bytes.')
                deltas[label] = changed
            for destination, data in payload.items():
                require(final_entries.get(destination, {}).get('mode') == '100644'
                        and command(['git', 'show', final + ':' + destination]) == data,
                        'Final C8 did not retain every frozen artifact exactly.')
            require(command(bookmark_argv) == bookmarks and command(git_ref_argv) == git_refs
                    and app['protected_refs']() == protected
                    and all(tree(revision) == digest for revision, digest in originals.items()),
                    'Original objects or branch/protected references changed.')
            require(jj_value('@', cwd=PREFIX) == prefix_before, 'Prefix workspace revision changed.')
            app['tracked'](runner, PREFIX, prefix_before)
            result['root_tracked_after'] = app['tracked'](runner, ROOT, final)
            for name, digest in hashes.items():
                frozen_read(TASK / name, digest)
            new_stack = copy.deepcopy(old)
            new_stack['commits'][7] = final_rows[7]
            new_pins = dict(pins, c8=final)
            require(new_stack['commits'][:7] == old['commits'][:7]
                    and {k: v for k, v in new_stack.items() if k != 'commits'} == {k: v for k, v in old.items() if k != 'commits'}
                    and {k: v for k, v in new_pins.items() if k != 'c8'} == {k: v for k, v in pins.items() if k != 'c8'},
                    'Pin amendment exceeds C8 commit/tree and dispatch fields.')
            result['phase'] = 'update_C8_pin_pair'
            values = {'corrected-stack.json': new_stack, 'validation-pins.json': new_pins}
            for name, value in values.items():
                app['exclusive_json'](ATTEMPT / (name + '.pending'), value)
            for name in values:
                os.replace(ATTEMPT / (name + '.pending'), TASK / name)
            require(all(json.loads((TASK / name).read_bytes()) == value for name, value in values.items()), 'Updated pin pair mismatch.')
            reviewed_paths = sorted(set(deltas['tested']) | set(deltas['reconciled']))
            closure = {'status': 'PASS', 'tested_revision': tested, 'final_revision': final,
                       'reconciled_revision': reconciled, 'stable_change_id': C8_CHANGE,
                       'identical_production_build_test_config': True,
                       'allowed_changed_paths': deltas['tested'],
                       'reconciled_allowed_changed_paths': deltas['reconciled'],
                       'document_review_status': 'PASS', 'document_reviewer': descriptor['document_reviewer'],
                       'reviewed_document_sha256': {path: sha(payload[path]) for path in reviewed_paths},
                       'reusable_stages': c8_stages, 'artifact_map_sha256': args.reviewed_map_sha256,
                       'pdf_review_sha256': hashes[descriptor['pdf_review_receipt']],
                       'scope': 'Exact reviewed documents only; original executed candidate receipts retain their hashes and count once.'}
            app['exclusive_json'](CLOSURE, closure)
            result['phase'] = 'verify_external_document_closure'
            frozen_read(TASK / 'report-updater/update-current-reports.py', hashes['report-updater/update-current-reports.py'])
            command(collector + ['--closure', str(CLOSURE), '--out', str(ATTEMPT / 'final-verification')])
            verified = json.loads((ATTEMPT / 'final-verification/raised-energy-cff-stack-current-validation.json').read_bytes())
            require(verified['status'] == 'COMPLETE' and not verified['provenance_issues']
                    and verified['final_runtime'] == validation['final_runtime']
                    and len(verified['gates']) == len(validation['gates']), 'Final closure changed validation totals or completeness.')
            for before, after in zip(validation['gates'], verified['gates']):
                # Deliberately retain full accepted receipt/audit/binary/identity fingerprints.
                require({k: v for k, v in before.items() if k not in ('revision', 'document_reuse_certificate')}
                        == {k: v for k, v in after.items() if k not in ('revision', 'document_reuse_certificate')},
                        'Final closure changed an executed receipt, command, outcome or selected identity.')
            for name, digest in hashes.items():
                if name not in values:
                    frozen_read(TASK / name, digest)
            require(command(bookmark_argv) == bookmarks and command(git_ref_argv) == git_refs
                    and [metadata(row['change_id']) for row in rows] == final_rows
                    and metadata(SOURCE_CHANGE) == source_before and jj_value('@') == final
                    and jj_value('@', cwd=PREFIX) == prefix_before, 'Final closure changed an immutable/workspace invariant.')
            for row in entries:
                frozen_read(row['source'], row['sha256'])
            app['tracked'](runner, ROOT, final)
            app['tracked'](runner, PREFIX, prefix_before)
            result.update(status='PASS', phase='complete', final_revision=final, final_tree=final_rows[7]['tree'],
                          deltas=deltas, closure_sha256=sha(CLOSURE.read_bytes()),
                          pin_sha256={name: sha((TASK / name).read_bytes()) for name in values},
                          final_runtime=verified['final_runtime'], originals_and_protected_refs_preserved=True,
                          followup='Root may separately move the local bookmark after reviewing this external receipt. Do not copy final-verification back into C8.')
        except Exception as error:
            result['error'] = str(error)
            raise
        finally:
            result['completed_utc'] = datetime.now(timezone.utc).isoformat()
            app['exclusive_json'](ATTEMPT / 'result.json', result)
            print(json.dumps({'status': result['status'], 'phase': result['phase'], 'receipt': str(ATTEMPT / 'result.json')}))


if __name__ == '__main__':
    main()

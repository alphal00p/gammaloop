# Standalone Symbolica MRE evidence review

**PASS** for the source-scoped diagnostic evidence at `a3af927afc633c6e6c2474d3f03fa02e0242eaa4`. Exact plan, driver, result/command/output hashes and per-stage tracked-tree guards agree. No diagnostic or build was rerun.

- Locked all-target check, build and Clippy completed successfully; Clippy denied warnings.
- Two interpreted positive controls reached their post-assertion success event: **39** for the tagged-function/alias control and **4** for the independent abstract-parameter control. Values are established by pinned assertions, not printed numeric output.
- Tiny import write exited **0**. Read exited the expected **101** at the exact argument-identity assertion, showing `f(y,x)` where `f(x,y)` was expected. This reproduces the separate import defect; it is not an application test pass.
- **No GL262 physical replay or large evaluator-panic reproduction occurred.** Nothing is added to workspace suite totals.

The two recorded executable identities are consistent across their paired runs; their mtimes fall inside the completed locked build interval. The driver verified before/after identity. This reviewer did not open executable or serialized payloads. The tiny-input size/hash remains recorded provenance only.

The MRE package is its own Cargo workspace with its own lock and dev-optim profile, pinned to Symbolica 2.2.0 at 4d0a833. Its complete immutable package tree is `b917afeca167a3b114c6f8bc0d22be24dc888292`; text source hashes, package entry identities, root Cargo/config/toolchain fingerprints and precise stage receipts appear in the JSON.

The retained formatting receipt has no revision/time/source guard and is not a fresh source-pinned formatting gate. A later C4 rebase has not yet been compared: retain these results at their executed revision, and verify the package/config fingerprint set before claiming unchanged applicability to a new target. Do not relabel the source or count another execution.

No source/test edits, jj mutations, builds, reruns, wrapper inspection or binary payload reads occurred.

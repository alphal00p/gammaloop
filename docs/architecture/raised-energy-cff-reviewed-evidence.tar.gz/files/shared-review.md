# Shared foundations review

Sources: `78395e3ab3ddd8d8f62b2f674d7488484eace197` to `a1140c90c334ff58a3b040ff3eae06d3645bf0bb`.

All changed hunks, including tests, were read in all 16 assigned files (3134 inserted, 337 deleted lines). No production correctness defect established by static inspection. No builds/tests run by this reviewer; the root reviewer owns fresh validation. CONTRIBUTING.md and AGENTS.md read; there are no narrower instructions for these three crates. No changed dependency manifest is in this scope; existing manifests were inspected to establish feature coverage.

## Findings before test revisions

1. **P2: Tests constrain storage and scheduling choices.** `crates/spenso/src/network/store.rs:700–722,825–832` assert exact retained storage order, rewritten indices, tensor counts and concrete terminal leaf variants. `crates/spenso/src/network/graph.rs:3690–3697` constrains vector capacity and scheduler shape. `crates/spenso/src/network/tests.rs:574–593` requires private bulk-sum dispatch at 4 terms, fallback below 4, and exactly one stored result; the sparse estimate test asserts implementation heuristic penalty fields. Several graph tests compare entire backing graphs, and `crates/linnet/src/tree/child_pointer.rs:781,786,818` compares private sibling-ring representations against converted reference stores. These violate the requested outward-behavior-only test boundary. Keep the concrete complete values, edge incidence, forest ancestry, public accessors, independent contraction sums, and failures/restoration where observable. Performance characteristics belong in measured evidence rather than allocator-capacity assertions.
2. **P2: Changed color regression remains an expression-format snapshot.** `crates/idenso/src/color/test/mod.rs:610` changes an ordered-expression string solely because coefficient grouping changed. The old and incoming expressions differ by multiplying a parenthesized coefficient by 16; mathematical equality is the relevant contract. Convert this assertion to an explicit symbolic expected value and exact small-expression cancellation, without expanding the original graph numerator.
3. **P3: Callback visit counts are redundant implementation assertions.** `crates/spenso/src/shadowing/tests.rs:153,174` asserts one visit even though complete callback payloads and final transformed expressions already verify the supported contract. Remove the counters and keep those complete value assertions.

## Planned test-only revisions (recorded before editing)

- Replace new/modified private storage-index/count/layout assertions in Spenso store tests with results reached through the current leaf references and existing public `result_tensor`/`result_scalar` accessors; keep alias-resolution values and repeated execution coverage.
- Exercise closed symbolic tensor sums through normal execution for the existing small/large operand fixtures, preserving independent summed expected expressions, aliases and zero cases while removing threshold/fallback count assertions. Keep the test's existing internal setup only where needed to reach lazy leaves.
- Remove capacity and exact scheduling assertions from the added ready-operation tests. Preserve visible operation incidence, hidden-edge behavior, graph validity, complete coordinate contraction oracles, and factorization boundaries. Do not constrain private copy counts or exact rewritten indices.
- Compare the new Linnet swap/deletion tests through existing public parent/child/data accessors and edge flow/orientation/pair accessors instead of whole private stores.
- Remove callback visit counts while keeping the callback's complete unaliased tensor and final expression contracts.
- Replace only the incoming changed color snapshot with the complete symbolic expected expression. No test is currently known to be failing; if root validation reports a failure before editing an expectation, repository confirmation is required.
- No new production helper, method or type; no production edits, builds, jj mutations or comment deletion. Existing explanatory comments will be retained and updated when their test assertion changes.

## Functional assessment and split ownership

**C1 foundations:** odd tensor powers (all five leaf paths), graph slot-order alignment, dangling edge flow, swap-owner bookkeeping, pointer-local forest swaps, compact operation incidence, tensor store reclamation, scalar-valued lazy leaf conversion, Symbolica scalar alias resolution, factor-preserving tensor/color/chain collection and guarded dot normalization. These extend behavior already owned by C1. Keep trait bounds/callers together (`ExecuteOp: NetworkStoreAccess`, associated-type equalities and graph-operation `hedges` migration).

**Distinct optional commit:** finite tensor sum-boundary contraction preparation (`NetworkGraph::contract_ready_sum_boundaries`/`ready_sum_boundaries`), its GammaLoop evaluator call, architecture description, complete coordinate tests and representative measurements. This is a substantive new execution rewrite. It consumes ready self-dual closing leaves and lowers the sum boundary rank while retaining intact native arms, scalar spectators and separate sums. It depends on C1's slot-order/delete and Linnet edge-flow fixes. It must stay exclusively at finite execution preparation; calling it in graph numerator construction would violate factorization guidance. Its guards deliberately leave dualizable, additive or partly open boundaries alone.

## Rust patterns and effectiveness

- Borrowed hash-map keys (`&[ConcreteIndex]` pairs) avoid copying immutable coordinate vectors. Value-based slice equality maintains the existing estimation meaning.
- Shared associated-type bounds and a single `NetworkLeaf::result_scalar` match remove duplicated conversion responsibility. `Cow` borrows literal scalars and owns assembled lazy scalar values. `Option` expresses absence of scalar interpretation at the leaf boundary; the public API turns it into `NoScalar`.
- `Vec::retain` moves non-Clone tensors and remaps all graph variants through one shared visitor. Reclaiming only after joined waves prevents invalidating overlay references; scalar alias definitions are deliberately retained.
- Compact sorted hedge vectors replace graph-sized masks per operation; sorting preserves the existing identification convention. Linnet accepts an iterator and membership predicate rather than adding another subgraph type.
- Pointer-local forest renaming changes only nodes which may reference the exchanged IDs. Reusing SmartEdgeVec's existing swap avoids a full involution scan. Independent accessor-based oracles should validate both.
- Exact fixed points make alias and generic-chain normalization explicit. Direct tagged-root guards avoid unrestricted wildcard work while maintaining the original five-stage dot-normalization order. The reference pattern tests check supported rewrite values, rather than a new statistical simplification contract.
- Temporary coefficient aliases protect factorized spectators; collision scanning prevents capture and AliasedAtom owns restoration. Direct Atom equality is intentional for factorization tests; expanding these spectators would erase what they protect.
- Sum-boundary preparation is more complex (roughly 270 production lines), but confines mutation and its invariants to the existing graph owner. The rank-decrease guard gives termination, candidate selection excludes nesting overlaps, and batched seam rewiring avoids repeatedly copying full arms. Its value needs representative time/memory measurements, not graph-copy assertions.

## Fresh validation required

Use the existing invocation-only licensed wrapper, retries 0 and INSTA_UPDATE=no. Never inspect or archive the wrapper.

- Spenso library tests with `--features shadowing`; also Spenso `--no-default-features` library tests (shadowing tests are otherwise absent).
- Idenso library tests (in particular color, chain and staged dot normalization).
- Linnet library tests (swap, flow, compact identification, forest deletion).
- Exact new selectors include `odd_tensor_powers_keep_the_base_square_fixed`, `odd_library_tensor_powers_keep_the_base_square_fixed`, `scalar_alias_resolution_preserves_nested_and_unregistered_handles`, `lazy_scalar_tensors_add_scalars_in_either_order`, `bulk_atom_sum_accepts_closed_tensor_leaves_and_preserves_aliases`, `ready_sum_boundary_closure_matches_coordinates_across_execution_strategies`, `staged_dot_normalization_matches_unrestricted_pattern_oracle`, `three_loop_pole_part_color`, `swaps_match_child_vec_for_all_small_forests`, `deletion_matches_child_vec_for_every_subset`, and all added tensor/color collection regressions.
- Root owns formatting, cargo check/build/Clippy and full integrated numerical regressions. Static review does not certify a fresh pass or performance improvement.

## Applied revisions and current validation state

All planned test-only revisions have been applied in the seven files listed below. Production code is unchanged. Direct `rustfmt` was unavailable in the shell; invocation through the existing environment succeeded. `git diff --check` passes. This reviewer has not built or executed Rust tests, and fresh validation remains with the root reviewer. No baseline failure had been reported at the time expectations were revised.

- `crates/idenso/src/color/test/mod.rs`
- `crates/linnet/src/half_edge/hedgevec.rs`
- `crates/linnet/src/tree/child_pointer.rs`
- `crates/spenso/src/network/graph.rs`
- `crates/spenso/src/network/store.rs`
- `crates/spenso/src/network/tests.rs`
- `crates/spenso/src/shadowing/tests.rs`

The bulk Atom regression now executes complete Network sums and compares with independently written scalar terms rather than calling the private dispatch helpers. The non-Clone retention fixture resolves whichever handles the graph now exposes to their actual stored payloads. Forest deletion compares data/children/root values independently of compacted node IDs. Callback output payloads and complete mathematical coordinate oracles are retained. The capacity test is now `ready_batch_reports_complete_visible_incidence`.

The three redundant graph-layout boundary tests were subsequently consolidated into existing complete-value execution tests. Their cases and all explanatory comments were moved, including independent, nested, coupled, partially open and dualizable boundaries. There are no Sum/arm/scalar copy-count or unchanged-node layout assertions for preparation. The deletion fixture now creates real tensor slots and checks the complete ordered surviving public slots after deleting a descriptor-selected slot. Allocation capacity, rewritten storage IDs, execution-wave counters and traversal order are unconstrained. The public sparse estimator quantities remain checked against independently enumerated coordinate joins; unrelated heuristic penalty fields were removed.

The changed Idenso snapshot is replaced by cancellation of the common `CA*eps^(-3)*gs^6*cas(2,coad(8))^2*dot(P(0,mink(4)),P(0,mink(4)))` factor, then an exact zero difference for the small remaining scalar polynomial. Independent rational arithmetic verified coefficients `[-18,-117/4,-3,29]` in the basis `[1,eps^2,eps^2*pi^2,eps]`; the original graph numerator is never expanded.

## Complete file coverage

| File | Added/deleted | Review coverage |
|---|---:|---|
| `crates/idenso/src/color/simplify.rs` | +72/-13 | All changed hunks and surrounding contracts |
| `crates/idenso/src/color/test/mod.rs` | +208/-1 | All changed hunks and surrounding contracts |
| `crates/idenso/src/shorthands/chain.rs` | +36/-2 | All changed hunks and surrounding contracts |
| `crates/idenso/src/shorthands/schoonschip/normalize_dots.rs` | +187/-6 | All changed hunks and surrounding contracts |
| `crates/linnet/src/half_edge.rs` | +13/-9 | All changed hunks and surrounding contracts |
| `crates/linnet/src/half_edge/hedgevec.rs` | +96/-27 | All changed hunks and surrounding contracts |
| `crates/linnet/src/half_edge/nodestore/test.rs` | +60/-2 | All changed hunks and surrounding contracts |
| `crates/linnet/src/tree/child_pointer.rs` | +113/-6 | All changed hunks and surrounding contracts |
| `crates/spenso/src/network/contract.rs` | +2/-2 | All changed hunks and surrounding contracts |
| `crates/spenso/src/network/graph.rs` | +871/-102 | All changed hunks and surrounding contracts |
| `crates/spenso/src/network/mod.rs` | +218/-147 | All changed hunks and surrounding contracts |
| `crates/spenso/src/network/parsing/tensor_from_expression.rs` | +2/-1 | All changed hunks and surrounding contracts |
| `crates/spenso/src/network/store.rs` | +267/-1 | All changed hunks and surrounding contracts |
| `crates/spenso/src/network/tests.rs` | +705/-0 | All changed hunks and surrounding contracts |
| `crates/spenso/src/shadowing/collect.rs` | +81/-18 | All changed hunks and surrounding contracts |
| `crates/spenso/src/shadowing/tests.rs` | +203/-0 | All changed hunks and surrounding contracts |

## Final scenario consolidation

The existing coordinate fixture now additionally checks the complete vectors `[4340,5642]`, `[22,32]`, and `[28,42]` for partial closure with dual spectators, a partly open factor, and a scalar spectator. Independent scalar sums verify dual closure (`92`), additive closure (`52`), and mixed residual dual boundaries in both operand orders (`8452`). The explicit-library fixture checks a shared vector closing a sum (`10`). The original coordinate cases, including both coupled-sum operand orders, remain intact. These execute prepared and unprepared networks, so they do not require the preparation algorithm to choose a particular layout or admission decision.

The added explicit-library closure block depends on the optional new boundary-preparation commit; keep that block with its implementation if splitting it away from C1. The existing odd-power part of that same test remains a C1 regression. No new production abstraction or named test helper was introduced. All seven changed files are formatted, and the final test-only diff passes `git diff --check`; compilation and Rust test outcomes remain unclaimed.

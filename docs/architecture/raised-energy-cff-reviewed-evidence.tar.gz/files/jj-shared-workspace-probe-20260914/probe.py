from pathlib import Path
import hashlib, json, subprocess
from datetime import datetime, timezone
BASE = Path(__file__).resolve().parent
TRACE = []
JJ = ['jj', '--no-pager', '--config', 'user.name="Workspace rewrite probe"', '--config', 'user.email="probe@example.invalid"']

def command(cwd, argv):
    cwd = Path(cwd).resolve()
    assert cwd.is_relative_to(BASE)
    result = subprocess.run(argv, cwd=cwd, capture_output=True, text=True)
    TRACE.append(dict(cwd=str(cwd), argv=argv, exit_code=result.returncode, stdout=result.stdout, stderr=result.stderr))
    if result.returncode:
        raise RuntimeError('Toy command failed: ' + repr(argv) + ': ' + result.stderr)
    return result.stdout.strip()

def jj(cwd, *args):
    return command(cwd, JJ + list(args))

def revision(cwd, rev='@', field='commit_id'):
    return jj(cwd, '--ignore-working-copy', 'log', '-r', rev, '--no-graph', '-T', field)

def git_tree(cwd, rev):
    return command(cwd, ['git', 'rev-parse', rev + '^{tree}'])

def scenario(name, park):
    folder = BASE / name
    folder.mkdir()
    root, prefix = folder / 'root', folder / 'prefix'
    jj(folder, 'git', 'init', '--colocate', str(root))
    (root / 'program.rs').write_text('fn value() -> u32 { 7 }\n')
    jj(root, 'describe', '-m', 'toy shared foundation')
    foundation = revision(root)
    jj(root, 'new', foundation, '-m', 'toy candidate documentation')
    (root / 'review.md').write_text('candidate review\n')
    jj(root, 'status')
    candidate, candidate_change = revision(root), revision(root, field='change_id')
    jj(root, 'new', foundation, '-m', 'toy immutable corrected source')
    (root / 'review.md').write_text('candidate review\n')
    jj(root, 'status')
    source = revision(root)
    source_tree, candidate_tree = git_tree(root, source), git_tree(root, candidate)
    assert source_tree == candidate_tree
    jj(root, 'workspace', 'add', '--name', 'prefix', '-r', source, str(prefix))
    jj(prefix, 'edit', candidate_change)
    assert revision(root) == source and revision(prefix) == candidate
    before_park = revision(prefix)
    pointer = (prefix / '.jj/repo').read_text().strip()
    assert Path(pointer).resolve() == (root / '.jj/repo').resolve()
    if park:
        jj(prefix, 'edit', source)
    prefix_before, root_before = revision(prefix), revision(root)
    assert root_before == source
    prefix_bytes_before = {name: (prefix/name).read_bytes() for name in ('program.rs', 'review.md')}
    jj(root, 'edit', candidate_change)
    (root/'review.md').write_text('review completed after validation\n')
    jj(root, 'status')
    final = revision(root)
    prefix_after = revision(prefix)
    prefix_bytes_after = {name: (prefix/name).read_bytes() for name in ('program.rs', 'review.md')}
    source_after = revision(root, source)
    assert final != candidate and source_after == source
    assert prefix_bytes_before == prefix_bytes_after
    if park:
        assert prefix_before == prefix_after == source
    else:
        assert prefix_before == candidate and prefix_after == final
    return dict(name=name, parked=park, source=source, candidate=candidate,
                candidate_change=candidate_change, final=final,
                independent_source_candidate_same_tree=source_tree,
                prefix_repository_pointer=pointer, root_before=root_before,
                prefix_before_parking=before_park, prefix_before_amendment=prefix_before,
                prefix_after_amendment=prefix_after,
                prefix_revision_guard_pass=prefix_before==prefix_after,
                prefix_files_unchanged=prefix_bytes_before==prefix_bytes_after,
                prefix_review_bytes=prefix_bytes_after['review.md'].decode(),
                final_review_bytes=(root/'review.md').read_text(),
                source_identity_preserved=source_after==source,
                root_final_revision=revision(root),
                source_tree=git_tree(root, source), candidate_tree=git_tree(root, candidate),
                final_tree=git_tree(root, final))

result = {'status': 'FAIL', 'started_utc': datetime.now(timezone.utc).isoformat(),
          'scope': 'Actual installed jj on two fresh isolated toy repositories/workspace pairs only. No application repository, prefix, pins, runner, plan or licensed wrapper accessed or changed.',
          'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
          'application_builds_tests': 0}
try:
    result['jj_version'] = command(BASE, ['jj', '--version'])
    result['unparked'] = scenario('unparked', False)
    result['parked'] = scenario('parked', True)
    result['status'] = 'REPRODUCED_AND_TOY_REMEDY_PASS'
finally:
    result['completed_utc'] = datetime.now(timezone.utc).isoformat()
    result['commands'] = TRACE
    with (BASE/'result.json').open('x') as stream:
        json.dump(result, stream, indent=2); stream.write('\n')
    print(json.dumps({key: value for key, value in result.items() if key != 'commands'}, indent=2))

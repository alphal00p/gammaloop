"""One explicit same-source rebuild after quarantining three mapped incremental caches; no automatic retry."""
from datetime import datetime, timezone
import fcntl
import hashlib
import importlib.util
import json
import os
import stat
from pathlib import Path
import subprocess
import sys

BASE = Path('/tmp/raised-stack-latest-review-20260914')
spec = importlib.util.spec_from_file_location('executor', BASE / 'execute-prefix.py')
executor = importlib.util.module_from_spec(spec)
spec.loader.exec_module(executor)
audit = executor.module('audit', 'audit-nextest-stage.py')
runner = executor.module('runner', 'run-stage.py')
plan_bytes = (BASE / 'prefix-validation-plan.executable.json').read_bytes()
plan = json.loads(plan_bytes)
entry = next(row for row in plan['prefixes'] if row['prefix'] == 8)
unit, = executor.units(entry, ['curated'])
revision = executor.load(BASE / 'validation-pins.json')['c8']
assert revision == '449a59f6f173d100c2da858c541faa1e0dccca6e'
prior_path = BASE / 'c8-results/curated-v3-list/result.json'
prior = executor.load(prior_path)
assert prior['revision'] == revision and prior['exit_code'] == 101 and prior['integrity_pass'] is True
assert executor.command_from_receipt(prior) == unit[0][1]
prior_log = (prior_path.parent / 'output.log').read_text()
assert 'undefined reference' in prior_log and 'Nextest run ID' not in prior_log
assert 'RAM watchdog: stopping because monitoring failed:' not in prior_log
assert not (BASE / 'c8-results/curated').exists()
assert executor.load(BASE/'c8-results/curated-list/result.json')['exit_code'] == 125
assert executor.load(BASE/'watchdog-ps10-controls.json')['status'] == 'PASS'
assert executor.load(BASE/'watchdog-ps10-runner-applied.json')['status'] == 'APPLIED'
assert hashlib.sha256((BASE/'run-stage.py').read_bytes()).hexdigest() == 'f34a88226b3b4598c02fdfd64d051ec0e228b41adf9c0bc692a597c0909b246f'
assert hashlib.sha256((BASE/'ram-watchdog-ps10.py').read_bytes()).hexdigest() == 'e94c98f65399e4cd0791ba050497ecaf4e745b4fdefc36fe036aae748f8152b9'
health = executor.load(BASE / 'c8-watchdog-health-probe.json')
assert health['status'] == 'PASS' and health['timeout_seconds'] == 2 and len(health['measurements']) == 5
assert audit.selection_argv(unit[0][1]) == audit.selection_argv(unit[1][1])
receipt = dict(status='RUNNING', reason='The identical curated list failed linking three test targets with internal Rust symbols. Their reported object files map to three reused incremental directories. Preserve and quarantine only these directories on the target filesystem, then rebuild the same source, Cargo command and profile. This tests incremental-cache dependence without asserting corruption or an interruption cause.', revision=revision, started_utc=datetime.now(timezone.utc).isoformat(), plan_sha256=hashlib.sha256(plan_bytes).hexdigest(), runner_sha256=hashlib.sha256((BASE/'run-stage.py').read_bytes()).hexdigest(), watchdog_sha256=hashlib.sha256(Path('/common/dev/gammaloop/higher-power-energies-review/bin/ram_watchdog.py').read_bytes()).hexdigest(), prior_failure_sha256=hashlib.sha256(prior_path.read_bytes()).hexdigest(), health_probe_sha256=hashlib.sha256((BASE/'c8-watchdog-health-probe.json').read_bytes()).hexdigest(), stages=[])
receipt['adapter_sha256'] = hashlib.sha256((BASE/'ram-watchdog-ps10.py').read_bytes()).hexdigest()
receipt['controls_sha256'] = hashlib.sha256((BASE/'watchdog-ps10-controls.json').read_bytes()).hexdigest()
summary = BASE / 'c8-incremental-rebuild-execution.json'
assert not summary.exists()
with (BASE / 'prefix-execution.lock').open('a+') as lock:
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    executor.idle_prefix()
    head = subprocess.check_output(['jj','--ignore-working-copy','log','-r','@','--no-graph','-T','commit_id'],cwd=executor.PREFIX,text=True).strip()
    assert head == revision and runner.tracked_audit(revision)['pass']
    # Preserve the three mapped caches by rename on their own filesystem.
    incremental = Path('/common/dev/gammaloop/higher-power-energies-review/target/dev-optim/incremental')
    quarantine = incremental.parent / 'curated-c8-incremental-quarantine-20260914'
    assert not quarantine.exists()
    names = ['network_dumb-3ieqzeu9i7o52', 'idenso-1fpl2n2nikwsb', 'spenso-3pknvrowl1fuo']
    inventory = []
    for name in names:
        origin = incremental / name
        assert origin.is_dir() and not origin.is_symlink()
        files = []
        for path in sorted(origin.rglob('*')):
            meta = path.lstat()
            assert stat.S_ISREG(meta.st_mode) or stat.S_ISDIR(meta.st_mode)
            if stat.S_ISREG(meta.st_mode):
                files.append(dict(path=str(path.relative_to(origin)), bytes=meta.st_size, device=meta.st_dev, inode=meta.st_ino, mtime_ns=meta.st_mtime_ns, links=meta.st_nlink))
        inventory.append(dict(name=name, origin=str(origin), destination=str(quarantine/name), files=files))
    inventory_path = BASE / 'c8-incremental-quarantine-inventory.json'
    assert not inventory_path.exists()
    inventory_path.write_text(json.dumps(dict(revision=revision, directories=inventory), indent=2)+'\n')
    quarantine.mkdir()
    assert quarantine.stat().st_dev == incremental.stat().st_dev
    for row in inventory:
        os.rename(row['origin'], row['destination'])
        assert not Path(row['origin']).exists()
    receipt['quarantine_inventory_sha256'] = hashlib.sha256(inventory_path.read_bytes()).hexdigest()
    receipt['quarantine_path'] = str(quarantine)
    # Confirm the exact existing monitoring command before starting this one attempt.
    measured = subprocess.run(health['argv'],capture_output=True,text=True,timeout=10,check=True)
    assert measured.stdout.strip()
    try:
        for canonical,argv in unit:
            name = 'curated-v4' + ('-list' if canonical.endswith('-list') else '')
            folder = BASE / 'c8-results' / name
            driver = BASE / 'c8-results' / (name+'.driver.log')
            assert not folder.exists() and not driver.exists()
            assert not (executor.PREFIX/'tests'/('TEST_OUTPUT_c8_'+name)).exists()
            assert (BASE/'prefix-validation-plan.executable.json').read_bytes() == plan_bytes
            assert executor.load(BASE/'validation-pins.json')['c8'] == revision
            assert hashlib.sha256((BASE/'run-stage.py').read_bytes()).hexdigest() == receipt['runner_sha256']
            assert hashlib.sha256(Path('/common/dev/gammaloop/higher-power-energies-review/bin/ram_watchdog.py').read_bytes()).hexdigest() == receipt['watchdog_sha256']
            print('RUN c8 '+name,flush=True)
            result = subprocess.run([sys.executable,str(BASE/'run-stage.py'),'c8',name,*argv],capture_output=True,text=True)
            with driver.open('x') as stream:stream.write(result.stdout+result.stderr)
            receipt['stages'].append(dict(stage=name,exit_code=result.returncode))
            if canonical.endswith('-list'):
                assert result.returncode == 0, 'Listing failed; retained receipt. No further automatic attempt.'
                selected = executor.selected_listing(folder,unit[1][1],plan['list_requirements']['8/curated'],audit)
                print('LIST c8 curated: '+str(len(selected))+' selected',flush=True)
            else:
                checked = subprocess.run([sys.executable,str(BASE/'audit-nextest-stage.py'),'c8',name],capture_output=True,text=True)
                assert result.returncode == checked.returncode == 0, 'Run or immediate audit failed; retained receipts.'
                saved = executor.validate_saved_audit(folder,revision,argv,selected)
                print('PASS c8 curated: '+str(saved['unique_outcomes'])+' unique tests',flush=True)
        receipt['status']='PASS'
    except Exception as error:
        receipt.update(status='FAIL',error=str(error))
        raise
    finally:
        receipt['completed_utc']=datetime.now(timezone.utc).isoformat()
        with summary.open('x') as stream:json.dump(receipt,stream,indent=2);stream.write('\n')

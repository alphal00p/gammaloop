"""One explicit rerun after correcting the fixture layout; preserves the failed attempt."""
from datetime import datetime, timezone
import fcntl
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys

BASE = Path('/tmp/raised-stack-latest-review-20260914')
spec = importlib.util.spec_from_file_location('executor', BASE / 'execute-prefix.py')
executor = importlib.util.module_from_spec(spec)
spec.loader.exec_module(executor)
audit = executor.module('audit', 'audit-nextest-stage.py')
runner = executor.module('runner', 'run-stage.py')
plan_bytes = (BASE / 'prefix-validation-plan.executable.json').read_bytes()
plan = json.loads(plan_bytes)
entry = next(row for row in plan['prefixes'] if row['prefix'] == 4)
unit, = executor.units(entry, ['commit4-workflows'])
revision = executor.load(BASE / 'validation-pins.json')['c4']
assert revision == '04637884f24fb28a247574f04e03308cf4c04afb'
prior = executor.load(BASE / 'c4-results/commit4-workflows/audit.json')
assert prior['status'] == 'FAIL' and prior['summary_counts'] == {'passed':602, 'failed':2, 'skipped':830}
assert prior['revision'] == revision
receipt = dict(status='RUNNING', reason='Correct externally misplaced validation state directory so the unchanged fixture helper reads pinned tests/resources. Test source, expected values, filters, retries and assertions unchanged.', revision=revision, started_utc=datetime.now(timezone.utc).isoformat(), plan_sha256=hashlib.sha256(plan_bytes).hexdigest(), runner_sha256=hashlib.sha256((BASE/'run-stage.py').read_bytes()).hexdigest(), prior_failure='c4-results/commit4-workflows/audit.json', stages=[])
summary = BASE / 'c4-fixture-correction-execution.json'
assert not summary.exists()
with (BASE / 'prefix-execution.lock').open('a+') as lock:
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    executor.idle_prefix()
    head = subprocess.check_output(['jj','--ignore-working-copy','log','-r','@','--no-graph','-T','commit_id'],cwd=executor.PREFIX,text=True).strip()
    assert runner.tracked_audit(head)['pass']
    if head != revision:
        subprocess.run(['jj','edit',revision],cwd=executor.PREFIX,check=True,capture_output=True)
    assert runner.tracked_audit(revision)['pass']
    try:
        for canonical,argv in unit:
            name = 'commit4-workflows-v2' + ('-list' if canonical.endswith('-list') else '')
            folder = BASE / 'c4-results' / name
            driver = BASE / 'c4-results' / (name+'.driver.log')
            assert not folder.exists() and not driver.exists()
            assert not (executor.PREFIX/'tests'/('TEST_OUTPUT_c4_'+name)).exists()
            print('RUN c4 '+name,flush=True)
            result = subprocess.run([sys.executable,str(BASE/'run-stage.py'),'c4',name,*argv],capture_output=True,text=True)
            with driver.open('x') as stream:stream.write(result.stdout+result.stderr)
            receipt['stages'].append(dict(stage=name,exit_code=result.returncode))
            if canonical.endswith('-list'):
                assert result.returncode == 0, 'Listing failed; retained receipt.'
                selected = executor.selected_listing(folder,unit[1][1],plan['list_requirements']['4/commit4-workflows'],audit)
                assert len(selected)==604
                print('LIST c4: 604 selected',flush=True)
            else:
                checked = subprocess.run([sys.executable,str(BASE/'audit-nextest-stage.py'),'c4',name],capture_output=True,text=True)
                assert result.returncode == checked.returncode == 0, 'Run or immediate audit failed; retained receipts.'
                saved = executor.validate_saved_audit(folder,revision,argv,selected)
                print('PASS c4: '+str(saved['unique_outcomes'])+' unique tests',flush=True)
        receipt['status']='PASS'
    except Exception as error:
        receipt.update(status='FAIL',error=str(error))
        raise
    finally:
        receipt['completed_utc']=datetime.now(timezone.utc).isoformat()
        with summary.open('x') as stream:json.dump(receipt,stream,indent=2)

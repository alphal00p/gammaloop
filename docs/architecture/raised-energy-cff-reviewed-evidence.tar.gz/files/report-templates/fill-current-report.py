#!/usr/bin/env python3
"""Fill the concise main report from the accepted scratch ledger; never run application commands."""
import argparse
from collections import Counter
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import subprocess
import sys
import tomllib

base = Path('/tmp/raised-stack-latest-review-20260914')
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--ledger-dir', type=Path, default=base/'report-updater/drafts')
parser.add_argument('--out', type=Path, default=base/'report-templates/filled')
parser.add_argument('--require-complete', action='store_true')
args = parser.parse_args()
out = args.out.resolve()
repo = Path('/common/dev/gammaloop/higher-power-energies-review')
if out == repo or repo in out.parents:
    parser.error('Output must remain outside the repository.')
out.mkdir(parents=True, exist_ok=True)
spec = importlib.util.spec_from_file_location('report_updater', base/'report-updater/update-current-reports.py')
updater = importlib.util.module_from_spec(spec); spec.loader.exec_module(updater)
paths = {
    'mapping': args.ledger_dir/'raised-energy-cff-stack-current-mapping.json',
    'validation': args.ledger_dir/'raised-energy-cff-stack-current-validation.json',
    'template': base/'report-templates/current-report.md.in',
    'renderer': base/'report-templates/build_report_typst.py',
    'pins': base/'corrected-stack.json',
    'plan': base/'prefix-validation-plan.executable.json',
}
if (base/'c7-results/mre-validation.json').exists():
    subprocess.run([sys.executable,str(base/'report-updater/summarize-mre.py'),'--out',str(args.ledger_dir)],check=True,capture_output=True,text=True)
    paths['mre'] = args.ledger_dir/'raised-energy-cff-mre-validation.json'
raw = {key: updater.stable_bytes(path) for key, path in paths.items()}
mapping, validation = (json.loads(raw[key]) for key in ['mapping','validation'])
current_pins = json.loads(raw['pins'])
for key in ['pins','plan']:
    if validation['source_inputs_sha256'].get(paths[key].name) != hashlib.sha256(raw[key]).hexdigest():
        raise ValueError('Accepted ledger is stale; refresh it before filling: '+str(paths[key]))
if [{key: row[key] for key in ['commit','change_id','tree']} for row in mapping['commits']] != current_pins['commits']:
    raise ValueError('Accepted ledgers do not match the current corrected-stack pins.')
if mapping['issues'] or validation['provenance_issues']:
    raise ValueError('Resolve ledger provenance issues before preparing the primary report.')
if mapping['commits'] != validation['pins'] or len(mapping['commits']) != 8:
    raise ValueError('Mapping and validation do not identify the same eight boundaries.')
if not all(row['author'] == 'Lucien Huber <im@lcnbr.ch>' for row in mapping['commits']):
    raise ValueError('Report author attribution differs from the pinned commits.')
lock = tomllib.loads(updater.git(repo, 'show', mapping['commits'][6]['commit']+':Cargo.lock').decode())
symbolica_source = 'git+https://github.com/alphal00p/symbolica?rev=4d0a833eb8e059d1f95bdae5abed2559830b235f#4d0a833eb8e059d1f95bdae5abed2559830b235f'
for name in ['symbolica','graphica','numerica']:
    packages = [p for p in lock['package'] if p['name'] == name]
    if len(packages) != 1 or packages[0]['source'] != symbolica_source or (name == 'symbolica' and packages[0]['version'] != '2.2.0'):
        raise ValueError('Template dependency identity differs from the immutable functional tip: '+name)

def table(header, rows):
    return '\n'.join('| '+' | '.join(updater.cell(value) for value in row)+' |' for row in [header, ['---']*len(header), *rows])

def test_evidence(suffixes):
    passing = []
    for gate in validation['gates']:
        receipt = gate.get('receipt')
        if gate['status'] != 'PASS' or not receipt or not receipt.get('audit'):
            continue
        names = [case['test_name'] for case in receipt['audit']['cases']]
        if all(any(name.endswith(suffix) for name in names) for suffix in suffixes):
            passing.append(gate['owner']+'/'+gate['stage'])
    return 'PASS: '+', '.join(passing) if passing else 'Pending accepted execution; static contract reviewed'

fields = {}
fields['REPORT_DATE'] = validation['generated_utc'][:10]
if 'mre' in raw:
    mre = json.loads(raw['mre'])
    if mre['status'] != 'PASS' or mre['observed_c7_revision'] != current_pins['commits'][6]['commit']:
        raise ValueError('Standalone MRE sidecar does not match current observed C7')
    fields['STANDALONE_MRE'] = f'Fresh standalone evidence at executed revision `{mre["executed_revision"]}` has locked all-target check/build/Clippy passes, **two positive controls (39 and 4)**, and **one reproduced import defect**: the writer exits 0 and the reader exits the expected 101 for `f(y,x)` versus `f(x,y)`. These are not workspace test counts or a GL262 replay. {mre["source_equivalence"]["claim"]}. The [standalone receipt](raised-energy-cff-mre-validation.md) records exact package/manifest/lock/config identity and original binary/result hashes; carrying that evidence adds no execution.'
    if mre.get('pinned_formatting'):
        formatting = mre['pinned_formatting']
        format_scope = 'its tracked package/build inputs match observed C7' if formatting['source_equivalent'] else 'its result applies only to that source because tracked package/build inputs differ'
        fields['STANDALONE_MRE'] += f' Separately recorded formatting passes at `{formatting["executed_revision"]}`; {format_scope}.'
else:
    fields['STANDALONE_MRE'] = 'No completed standalone MRE evidence has been added to this report snapshot.'
statuses = Counter(g['status'] for g in validation['gates'])
fields['VALIDATION_SUMMARY'] = validation['status']+' — '+', '.join(f'{count} {status}' for status,count in sorted(statuses.items()))+f' of {len(validation["gates"])} planned stages'
fields['FUNCTIONAL_TIP'] = mapping['commits'][6]['commit']
fields['COMMIT_TABLE'] = table(['Commit','Pinned identity','Responsibility'], [[row['owner'], '`'+(row['change_id'][:12] if row['owner']=='C8' else row['commit'][:12])+'`',row['purpose']] for row in mapping['commits']])
fields['FINDINGS_TABLE'] = table(['Finding','Current contract','Fresh execution evidence'], [
    ['Projection cancellation','Complete typed zero at every supported final cut order',test_evidence(['cancelling_projection_sectors_preserve_final_cut_orders_without_energy_maps'])],
    ['Private layout/cache assertions','Full values, supported errors, factorization and public bounds', 'Exact reviewed correction fingerprints in the source mapping; owning selections below'],
    ['Physical route tolerance','Fixed 1e-9 complex-relative acceptance for GL00/GL01',test_evidence(['aa_aa_2l_gl00_matches_across_local_uv_routes','aa_aa_2l_gl01_matches_across_local_uv_routes'])],
    ['Sunset allocation','Independent complete degree-five/seven signed contour values',test_evidence(['canonical_sunset_allocator_matches_native_small_oracle'])],
])
boundaries = []
for index in range(1,9):
    gates = [g for g in validation['gates'] if g['owner'] == f'C{index}']
    core = [g for g in gates if g['stage'] in ['fmt','check','build','clippy']]
    core_text = 'Four gates PASS' if all(g['status']=='PASS' for g in core) else '; '.join(g['stage']+' '+g['status'] for g in core)
    runtimes = [g for g in gates if g['planned_argv'][:3] == ['cargo','nextest','run']]
    accepted = [g for g in runtimes if g['status']=='PASS']
    count = sum(g['receipt']['audit']['selected_count'] for g in accepted)
    other_pending = sum(g['status'] != 'PASS' for g in gates if g not in core and g not in runtimes)
    detail = f'{len(accepted)}/{len(runtimes)} selections PASS; {count} accepted executions'
    if other_pending:
        detail += f'; {other_pending} listing/feature stages incomplete'
    for gate in runtimes:
        audit = gate.get('receipt') and gate['receipt'].get('audit')
        if gate['status'] != 'PASS' and audit and audit['summary_counts'].get('failed',0):
            detail += f'; {gate["stage"]}: {audit["summary_counts"].get("passed",0)} PASS / {audit["summary_counts"]["failed"]} FAIL observed'
    boundaries.append([f'C{index}',core_text,detail])
fields['BOUNDARY_TABLE'] = table(['Boundary','Format / check / build / Clippy','Owning behavioral selections'],boundaries)
labels = {'curated':'Curated GammaLoop (includes phase/Vakint subsets)','scalar-all':'Full scalar matrix, including slow cases','vertex-rules':'Vertex rules','ufo-model-parity':'UFO model parity (API library)','physical-local-uv-routes':'Physical local UV routes: GL00/GL01','spenso-shadowing-tests':'Spenso: shadowing','spenso-no-default-tests':'Spenso: no default features','three-dimensional-reps-default-tests':'Shared CFF: default features','three-dimensional-reps-all-tests':'Shared CFF: all features','three-dimensional-reps-no-default-tests':'Shared CFF: no default features'}
final_gates = [g for g in validation['gates'] if g['owner']=='C8' and g['planned_argv'][:3] == ['cargo','nextest','run']]
fields['FINAL_SELECTION_TABLE'] = table(['Final selection','Accepted passed / executed','Status'], [[labels.get(g['stage'],g['stage']), f'{g["receipt"]["audit"]["selected_count"]} / {g["receipt"]["audit"]["selected_count"]}' if g['status']=='PASS' else '—',g['status']] for g in final_gates])
runtime = validation['final_runtime']
if runtime['planned_selections'] != len(final_gates) or runtime['passing_selections'] != sum(g['status']=='PASS' for g in final_gates):
    raise ValueError('Final selection totals disagree with the accepted gate list.')
fields['FINAL_TOTALS'] = f'Accepted final runtime: **{runtime["executions"]} executions over {runtime["unique_binary_test_identities"]} distinct binary/test identities**, from {runtime["passing_selections"]}/{runtime["planned_selections"]} passing selections. Accepted configurations report {runtime["summary_counts_across_passing_configurations"].get("skipped",0)} excluded entries, which may overlap. Baseline and owning-prefix executions are excluded from these final totals.'
fields['TOOL_VERSIONS'] = '; '.join(validation['tool_versions'][name]['output'].splitlines()[0] for name in ['rustc','cargo','nextest'])
totals = mapping['incoming_totals']
fields['INCOMING_COVERAGE'] = f'{len(mapping["incoming_coverage"])} paths ({totals["text_paths"]} text, {totals["binary_paths"]} binary), {totals["hunks"]} text hunks, with explicit reviewer attribution'
fields['CORRECTION_COUNT'] = str(len(mapping['corrections']))
fields['INVENTORY'] = f'{mapping["full_stack_commit_path_records"]} commit/path records over {mapping["full_stack_distinct_paths"]} paths'
proof = mapping['immutable_pre_document_proof']
if not proof['verified']:
    raise ValueError('Immutable split-preservation proof is not verified.')
fields['IMMUTABLE_PROOF'] = f'Immutable corrected source `{proof["corrected_source_revision"]}` and reconciled C8 `{proof["reconciled_revision"]}` share tree `{proof["tree"]}` exactly.'
source = raw['template'].decode()
placeholders = set(re.findall(r'@@([A-Z0-9_]+)@@',source))
if placeholders != fields.keys():
    raise ValueError(f'Unmatched template fields: {placeholders ^ fields.keys()}')
for key,value in fields.items():
    source = source.replace('@@'+key+'@@',value)
if '@@' in source:
    raise ValueError('Unfilled placeholder remains.')
markdown_path = out/'raised-energy-cff-stack-review.md'
typst_path = out/'raised-energy-cff-stack-review.typ'
markdown_path.write_text(source)
render_command = [sys.executable,str(paths['renderer']),'--source',str(markdown_path),'--out',str(typst_path),'--date',fields['REPORT_DATE']]
subprocess.run(render_command,check=True,capture_output=True,text=True)
typst = updater.stable_bytes(typst_path).decode()
# Independently decode visible body literals; layout/whitespace is reviewed in the rendered PDF.
body = typst.split('// BEGIN GENERATED MARKDOWN BODY\n',1)[1]
pattern = r'#(?:text|strong)\((?:font: "DejaVu Sans Mono", size: 0\.86em, )?("(?:[^"\\]|\\.)*")\)'
visible_typst = ''.join(json.loads(match) for match in re.findall(pattern,body))
visible_markdown=[]
for line in source.splitlines()[4:]:
    if line.startswith('|'):
        cells=[part.strip() for part in line.strip('|').split('|')]
        if all(re.fullmatch(r'[-: ]+',part) for part in cells):
            continue
        line=' '.join(cells)
    line=re.sub(r'^## ', '', line)
    line=re.sub(r'\[([^\]]+)\]\([^)]+\)',r'\1',line).replace('`','').replace('**','')
    visible_markdown.append(line)
if re.sub(r'\s+','',visible_typst) != re.sub(r'\s+','',''.join(visible_markdown)):
    raise ValueError('Generated Markdown/Typst visible body parity failed.')
for key,path in paths.items():
    if updater.stable_bytes(path) != raw[key]:
        raise ValueError('Input changed during generation; refresh and rerun: '+str(path))
receipt = {'status':'PASS','application_validation_status':validation['status'],'scope':'Filled report source and non-whitespace visible body parity only; no PDF compilation or visual inspection','ledger_generated_utc':validation['generated_utc'],'observed_functional_tip':mapping['commits'][6]['commit'],'stable_c8_change_id':mapping['commits'][7]['change_id'],'input_sha256':{str(paths[key]):hashlib.sha256(value).hexdigest() for key,value in raw.items()},'outputs':{path.name:hashlib.sha256(updater.stable_bytes(path)).hexdigest() for path in [markdown_path,typst_path]},'fields':fields,'filled_placeholder_count':len(fields),'unfilled_placeholders':[],'renderer_command':render_command,'root_input_fields':[],'root_final_actions':['Review current report prose and accepted-ledger counts','Compile and inspect every PDF page','Finalize C8 and record the exact external documentation closure without republishing self-referential final verification output']}
updater.write_json(out/'report-fill-receipt.json',receipt)
print(json.dumps({'status':'PASS','application_validation':validation['status'],'filled_fields':len(fields),'word_count':len(source.split()),'body_parity':'PASS','output':str(out),'root_input_fields':[]},indent=2))
sys.exit(2 if args.require_complete and validation['status'] != 'COMPLETE' else 0)

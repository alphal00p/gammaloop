"""One explicit run after the reviewed process-query timeout adjustment; no automatic retry."""
from datetime import datetime, timezone
import fcntl
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys

BASE = Path('/tmp/raised-stack-latest-review-20260914')
spec = importlib.util.spec_from_file_location('executor', BASE / 'execute-prefix.py')
executor = importlib.util.module_from_spec(spec)
spec.loader.exec_module(executor)
audit = executor.module('audit', 'audit-nextest-stage.py')
runner = executor.module('runner', 'run-stage.py')
plan_bytes = (BASE / 'prefix-validation-plan.executable.json').read_bytes()
plan = json.loads(plan_bytes)
entry = next(row for row in plan['prefixes'] if row['prefix'] == 8)
unit, = executor.units(entry, ['curated'])
revision = executor.load(BASE / 'validation-pins.json')['c8']
assert revision == '449a59f6f173d100c2da858c541faa1e0dccca6e'
prior_path = BASE / 'c8-results/curated-v2-list/result.json'
prior = executor.load(prior_path)
assert prior['revision'] == revision and prior['exit_code'] == 125 and prior['integrity_pass'] is True
assert executor.command_from_receipt(prior) == unit[0][1]
prior_log = (prior_path.parent / 'output.log').read_text()
assert 'RAM watchdog: stopping because monitoring failed:' in prior_log
assert "timed out after 2 seconds" in prior_log and 'Nextest run ID' not in prior_log
assert not (BASE / 'c8-results/curated').exists()
assert executor.load(BASE/'c8-results/curated-list/result.json')['exit_code'] == 125
assert executor.load(BASE/'watchdog-ps10-controls.json')['status'] == 'PASS'
assert executor.load(BASE/'watchdog-ps10-runner-applied.json')['status'] == 'APPLIED'
assert hashlib.sha256((BASE/'run-stage.py').read_bytes()).hexdigest() == 'f34a88226b3b4598c02fdfd64d051ec0e228b41adf9c0bc692a597c0909b246f'
assert hashlib.sha256((BASE/'ram-watchdog-ps10.py').read_bytes()).hexdigest() == 'e94c98f65399e4cd0791ba050497ecaf4e745b4fdefc36fe036aae748f8152b9'
health = executor.load(BASE / 'c8-watchdog-health-probe.json')
assert health['status'] == 'PASS' and health['timeout_seconds'] == 2 and len(health['measurements']) == 5
assert audit.selection_argv(unit[0][1]) == audit.selection_argv(unit[1][1])
receipt = dict(status='RUNNING', reason='Two prior listings were interrupted by two-second process-query timeouts before tests. Run once after the reviewed validation-only ten-second query adjustment and passing normal/cap/cleanup controls; preserve the 30 GB threshold, four workers, source, selection, zero automatic retries and snapshot policy.', revision=revision, started_utc=datetime.now(timezone.utc).isoformat(), plan_sha256=hashlib.sha256(plan_bytes).hexdigest(), runner_sha256=hashlib.sha256((BASE/'run-stage.py').read_bytes()).hexdigest(), watchdog_sha256=hashlib.sha256(Path('/common/dev/gammaloop/higher-power-energies-review/bin/ram_watchdog.py').read_bytes()).hexdigest(), prior_failure_sha256=hashlib.sha256(prior_path.read_bytes()).hexdigest(), health_probe_sha256=hashlib.sha256((BASE/'c8-watchdog-health-probe.json').read_bytes()).hexdigest(), stages=[])
receipt['adapter_sha256'] = hashlib.sha256((BASE/'ram-watchdog-ps10.py').read_bytes()).hexdigest()
receipt['controls_sha256'] = hashlib.sha256((BASE/'watchdog-ps10-controls.json').read_bytes()).hexdigest()
summary = BASE / 'c8-watchdog-timeout-correction-execution.json'
assert not summary.exists()
with (BASE / 'prefix-execution.lock').open('a+') as lock:
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    executor.idle_prefix()
    head = subprocess.check_output(['jj','--ignore-working-copy','log','-r','@','--no-graph','-T','commit_id'],cwd=executor.PREFIX,text=True).strip()
    assert head == revision and runner.tracked_audit(revision)['pass']
    # Confirm the exact existing monitoring command before starting this one attempt.
    measured = subprocess.run(health['argv'],capture_output=True,text=True,timeout=10,check=True)
    assert measured.stdout.strip()
    try:
        for canonical,argv in unit:
            name = 'curated-v3' + ('-list' if canonical.endswith('-list') else '')
            folder = BASE / 'c8-results' / name
            driver = BASE / 'c8-results' / (name+'.driver.log')
            assert not folder.exists() and not driver.exists()
            assert not (executor.PREFIX/'tests'/('TEST_OUTPUT_c8_'+name)).exists()
            assert (BASE/'prefix-validation-plan.executable.json').read_bytes() == plan_bytes
            assert executor.load(BASE/'validation-pins.json')['c8'] == revision
            assert hashlib.sha256((BASE/'run-stage.py').read_bytes()).hexdigest() == receipt['runner_sha256']
            assert hashlib.sha256(Path('/common/dev/gammaloop/higher-power-energies-review/bin/ram_watchdog.py').read_bytes()).hexdigest() == receipt['watchdog_sha256']
            print('RUN c8 '+name,flush=True)
            result = subprocess.run([sys.executable,str(BASE/'run-stage.py'),'c8',name,*argv],capture_output=True,text=True)
            with driver.open('x') as stream:stream.write(result.stdout+result.stderr)
            receipt['stages'].append(dict(stage=name,exit_code=result.returncode))
            if canonical.endswith('-list'):
                assert result.returncode == 0, 'Listing failed; retained receipt. No further automatic attempt.'
                selected = executor.selected_listing(folder,unit[1][1],plan['list_requirements']['8/curated'],audit)
                print('LIST c8 curated: '+str(len(selected))+' selected',flush=True)
            else:
                checked = subprocess.run([sys.executable,str(BASE/'audit-nextest-stage.py'),'c8',name],capture_output=True,text=True)
                assert result.returncode == checked.returncode == 0, 'Run or immediate audit failed; retained receipts.'
                saved = executor.validate_saved_audit(folder,revision,argv,selected)
                print('PASS c8 curated: '+str(saved['unique_outcomes'])+' unique tests',flush=True)
        receipt['status']='PASS'
    except Exception as error:
        receipt.update(status='FAIL',error=str(error))
        raise
    finally:
        receipt['completed_utc']=datetime.now(timezone.utc).isoformat()
        with summary.open('x') as stream:json.dump(receipt,stream,indent=2);stream.write('\n')

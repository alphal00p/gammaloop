#!/usr/bin/env python3
"""Apply one approved test correction after the parent confirms its batch is over.

Explicit invocation only: /tmp/raised-stack/python apply-approved-numeric-sign.py --apply
No builds, test runs, report-proof updates, executor edits, or prefix checkout edits.
Failure preserves partial work and its checkpoint; never automatically roll back or retry.
"""
import argparse
import copy
from datetime import datetime, timezone
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess

BASE = Path('/tmp/raised-stack-latest-review-20260914')
REPO = Path('/common/dev/gammaloop/higher-power-energies-review')
PREFIX = Path('/tmp/raised-stack/prefix')
FILE = 'crates/gammalooprs/src/uv/approx/local_4d.rs'
MAIN = '395610143576507503fd2c785db3ba62340f4277'
SOURCE = '8b2b355a76f563cd68dc0a3424bacba10e1eb865'
SOURCE_CHANGE = 'mzxyvvusvpusoswoovkmsxzvqpsqrnxx'
PREIMAGE = 'fa0f67f9b3115f25953c2004f4f616c5105d058d3ca2f41f1321fe5040293d2a'
POSTIMAGE = 'a0fd88e22f3531268e9b6bdb3d5e97d4faa97c211d45780c87832ca4ab909c85'
FROZEN = {
    'corrected-stack.json': '3b086b938c63f32700655422ffa7f7962bcb89a4fc91a769e8f79079fc4b86b2',
    'validation-pins.json': 'c0f1bc17f54bbf6105cdde377b493c5e241251edd8e79b1fca73ae80091eef98',
    'c7-numeric-sign-approval.json': '8713a344281528de203536362ec1f8306b04fd04f454278164839032e36625d1',
    'c7-numeric-sign-proposal.json': '65cbc93e279a06f626ae4365ec25a91770543af89791b4139b493640d7b47a1d',
    'c7-numeric-sign-proposal.patch': '4e1b284a2e916091055a9e1ea6881dc8bdce2e12a711aa70b0a637427c650870',
    'execute-prefix.py': '6c657cc89fb90de384f527ce05216b9c2dbc606c663028be27a680d4f8689cff',
    'run-stage.py': '8d59b8ad39110211dcba2b336c9ced77c6a1733860173c3b16dde432cb635446',
}
BACKUPS = {
    'corrected-stack.json': 'corrected-stack-before-c7-numeric-sign.json',
    'validation-pins.json': 'validation-pins-before-c7-numeric-sign.json',
    'prefix-validation-plan.executable.json': 'prefix-validation-plan.executable-before-c7-numeric-sign.json',
    'execute-prefix.py': 'execute-prefix-before-c7-numeric-sign.py',
    'report-updater/reconciliation-followups.json': 'report-updater/reconciliation-followups-before-c7-numeric-sign.json',
}
CHECKPOINT = BASE / 'numeric-sign-application-checkpoint.json'
RESULT = BASE / 'numeric-sign-application-result.json'
TRACE = []


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def command(argv, cwd=REPO):
    result = subprocess.run(argv, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    TRACE.append(dict(argv=argv, cwd=str(cwd), exit_code=result.returncode,
                      stdout_sha256=sha(result.stdout), stderr_sha256=sha(result.stderr)))
    require(result.returncode == 0, 'Command failed; inspect the recorded argv and checkpoint.')
    return result.stdout


def jj_value(revision, template='commit_id', cwd=REPO):
    return command(['jj', '--ignore-working-copy', 'log', '--no-pager', '--no-graph',
                    '-r', revision, '-T', template], cwd).decode().strip()


def tree(revision):
    return command(['git', 'rev-parse', revision + '^{tree}']).decode().strip()


def metadata(change):
    fields = jj_value(change, 'commit_id ++ "\\t" ++ change_id ++ "\\t" ++ author.name() ++ "\\t" ++ author.email() ++ "\\t" ++ empty ++ "\\t" ++ conflict').split('\t')
    require(len(fields) == 6 and '\n' not in fields[0], 'Stable change must resolve uniquely.')
    revision, change_id, name, email, empty, conflict = fields
    require((name, email, empty, conflict) == ('Lucien Huber', 'im@lcnbr.ch', 'false', 'false'),
            'Author, nonempty or conflict invariant failed.')
    return dict(commit=revision, change_id=change_id, tree=tree(revision))


def protected_refs():
    rows = command(['jj', '--ignore-working-copy', 'bookmark', 'list', '--all-remotes',
                    '--template', 'name ++ "\\t" ++ remote ++ "\\t" ++ normal_target.commit_id() ++ "\\n"']).decode().splitlines()
    return sorted(row for row in rows if ('threshold' in row.split('\t')[0].lower()
                  or 'thermal' in row.split('\t')[0].lower()
                  or row.startswith('finite_T_and_mu')))


def exclusive_json(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())


def tracked(runner, cwd, revision):
    previous = runner.cwd
    try:
        runner.cwd = cwd
        audit = runner.tracked_audit(revision)
        require(audit['pass'], 'Tracked files differ from their pinned revision.')
        return audit
    finally:
        runner.cwd = previous


def delta(before, after):
    names = command(['git', 'diff', '--no-ext-diff', '--name-only', before, after]).decode().splitlines()
    require(names == [FILE], 'Correction changed an unexpected file set.')
    content = command(['git', 'show', after + ':' + FILE])
    require(sha(content) == POSTIMAGE, 'Corrected file differs from approved postimage.')
    diff = command(['git', 'diff', '--no-ext-diff', '--unified=0', before, after, '--', FILE])
    return dict(before=before, after=after, changed_paths=names,
                diff_sha256=sha(diff), file_sha256=sha(content))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--apply', action='store_true', required=True,
                        help='Parent confirms the active batch and immediate audits have ended.')
    parser.parse_args()
    # Check frozen utility bytes before importing existing guards. No licensed wrapper is read.
    frozen_bytes = {name: (BASE / name).read_bytes() for name in FROZEN}
    require(all(sha(frozen_bytes[name]) == digest for name, digest in FROZEN.items()),
            'Frozen inputs changed; revise the application recipe before proceeding.')
    spec = importlib.util.spec_from_file_location('numeric_sign_executor_guards', BASE / 'execute-prefix.py')
    executor = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(executor)
    runner = executor.module('numeric_sign_tracked_audit', 'run-stage.py')
    with (BASE / 'prefix-execution.lock').open('a+') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        executor.idle_prefix()
        require(not CHECKPOINT.exists() and not RESULT.exists(), 'An application attempt already exists; no retry.')
        require(all(not (BASE / path).exists() for path in BACKUPS.values()), 'Backup destination already exists.')
        require(all(not (BASE / (name + '.numeric-sign.pending')).exists()
                    for name in ('corrected-stack.json', 'validation-pins.json')), 'Pending pin files already exist.')
        old = json.loads(frozen_bytes['corrected-stack.json'])
        pins = json.loads(frozen_bytes['validation-pins.json'])
        approval = json.loads(frozen_bytes['c7-numeric-sign-approval.json'])
        proposal = json.loads(frozen_bytes['c7-numeric-sign-proposal.json'])
        require(approval['status'] == 'APPROVED_NOT_APPLIED'
                and approval['patch_sha256'] == FROZEN['c7-numeric-sign-proposal.patch']
                and approval['test'] == 'canonical_positive_denominator_recovers_one_class_from_expanded_coordinates',
                'Numeric-sign approval does not match this correction.')
        require(proposal['file'] == FILE and proposal['source_sha256'] == PREIMAGE
                and proposal['proposed_sha256'] == POSTIMAGE, 'Proposal fingerprint mismatch.')
        require(old['corrected_source_revision'] == SOURCE and len(old['commits']) == 8, 'Unexpected pin schema.')
        old_rows = [metadata(row['change_id']) for row in old['commits']]
        require(old_rows == old['commits'] and all(pins[f'c{i}'] == row['commit'] for i, row in enumerate(old_rows, 1)),
                'Stable changes and dispatch pins differ.')
        source_before = metadata(SOURCE_CHANGE)
        require(source_before['commit'] == SOURCE and jj_value('@') == SOURCE, 'Root is not the frozen corrected source.')
        require(old['corrected_tree'] == tree(SOURCE) == old_rows[-1]['tree'], 'Initial split tree equality failed.')
        root_audit = tracked(runner, REPO, SOURCE)
        prefix_head = jj_value('@', cwd=PREFIX)
        prefix_audit = tracked(runner, PREFIX, prefix_head)
        # Refuse nonignored files that a normal jj snapshot could unexpectedly add.
        source_paths = set(command(['git', 'ls-tree', '-r', '--name-only', '-z', SOURCE]).split(b'\0'))
        untracked = set(command(['git', 'ls-files', '--others', '--exclude-standard', '-z']).split(b'\0'))
        require(not (untracked - source_paths), 'Untracked nonignored files require parent review before snapshot.')
        for revision in [SOURCE, old_rows[6]['commit'], old_rows[7]['commit']]:
            require(sha(command(['git', 'show', revision + ':' + FILE])) == PREIMAGE, 'Source/C7/C8 preimages differ.')
        refs_before = protected_refs()
        require(refs_before, 'Protected bookmark inventory is unexpectedly empty.')
        checkpoint_input = json.loads((BASE / 'checkpoint.json').read_text())
        originals = command(['git', 'rev-list', '--reverse', MAIN + '..' + checkpoint_input['base']]).decode().splitlines()
        require(len(originals) == 7, 'Original seven-commit chain differs.')
        original_trees = {revision: tree(revision) for revision in originals + [pins['latest']]}
        backup_bytes = {name: (BASE / name).read_bytes() for name in BACKUPS}
        for name, data in frozen_bytes.items():
            require((BASE / name).read_bytes() == data, 'Frozen inputs changed during preflight.')
        for name, destination in BACKUPS.items():
            with (BASE / destination).open('xb') as stream:
                stream.write(backup_bytes[name])
        checkpoint = dict(status='CHECKPOINT_BEFORE_APPLICATION', recorded_utc=datetime.now(timezone.utc).isoformat(),
                          operation=command(['jj', '--ignore-working-copy', 'op', 'log', '--limit', '1', '--no-graph', '-T', 'id']).decode().strip(),
                          source=source_before, stack=old, validation_pins=pins, prefix_revision=prefix_head,
                          root_tracked=root_audit, prefix_tracked=prefix_audit, protected_refs=refs_before,
                          original_input_trees=original_trees, frozen_sha256=FROZEN,
                          backup_sha256={BACKUPS[name]: sha(data) for name, data in backup_bytes.items()})
        exclusive_json(CHECKPOINT, checkpoint)
        result = dict(status='FAIL', phase='before_application', commands=TRACE,
                      checkpoint_sha256=sha(CHECKPOINT.read_bytes()), approval_sha256=FROZEN['c7-numeric-sign-approval.json'],
                      application_validation='Not run', independent_applied_review='Required; no proof-chain entry appended')
        try:
            executor.idle_prefix()
            result['phase'] = 'apply_corrected_source'
            patch = str(BASE / 'c7-numeric-sign-proposal.patch')
            command(['git', 'apply', '--check', patch])
            command(['git', 'apply', patch])
            require(sha((REPO / FILE).read_bytes()) == POSTIMAGE, 'Working file postimage mismatch.')
            command(['jj', 'status', '--no-pager'])
            source_after = metadata(SOURCE_CHANGE)
            require(source_after['commit'] == jj_value('@'), 'Corrected source no longer owns root working copy.')
            source_delta = delta(SOURCE, source_after['commit'])
            result['phase'] = 'restore_into_C7'
            command(['jj', 'restore', '--from', SOURCE_CHANGE, '--into', old_rows[6]['change_id'], '--', FILE])
            rows = [metadata(row['change_id']) for row in old_rows]
            require(rows[:6] == old_rows[:6], 'C1-C6 changed.')
            require([row['change_id'] for row in rows] == [row['change_id'] for row in old_rows], 'Stable change IDs changed.')
            parent = MAIN
            for row in rows:
                require(command(['git', 'show', '-s', '--format=%P', row['commit']]).decode().strip() == parent,
                        'Reconstructed chain is not linear on pinned main.')
                parent = row['commit']
            c7_delta = delta(old_rows[6]['commit'], rows[6]['commit'])
            c8_delta = delta(old_rows[7]['commit'], rows[7]['commit'])
            require(source_delta['diff_sha256'] == c7_delta['diff_sha256'] == c8_delta['diff_sha256'], 'Source/C7/C8 deltas differ.')
            require(metadata(SOURCE_CHANGE) == source_after and source_after['tree'] == rows[7]['tree']
                    and jj_value('@') == source_after['commit'], 'Source/root/C8 exact tree equality failed.')
            root_after = tracked(runner, REPO, source_after['commit'])
            require(protected_refs() == refs_before, 'Protected thermal/threshold bookmarks changed.')
            require({revision: tree(revision) for revision in original_trees} == original_trees, 'Original immutable inputs changed.')
            for name, data in frozen_bytes.items():
                require((BASE / name).read_bytes() == data, 'Frozen input changed before pin publication.')
            new_stack = copy.deepcopy(old)
            new_stack.update(commits=rows, corrected_source_revision=source_after['commit'],
                             corrected_tree=source_after['tree'], exact_preservation=True)
            new_pins = dict(pins, c7=rows[6]['commit'], c8=rows[7]['commit'])
            require({k:v for k,v in new_pins.items() if k not in ('c7','c8')} == {k:v for k,v in pins.items() if k not in ('c7','c8')},
                    'Historical or unaffected dispatch pins changed.')
            require(all(new_pins[f'c{i}'] == row['commit'] for i,row in enumerate(rows,1)), 'New pin pair is inconsistent.')
            # Prepare both complete files before publishing either. The idle lock protects readers.
            result['phase'] = 'publish_pin_pair'
            values = {'corrected-stack.json':new_stack, 'validation-pins.json':new_pins}
            for name,value in values.items():
                exclusive_json(BASE / (name + '.numeric-sign.pending'), value)
            for name in values:
                os.replace(BASE / (name + '.numeric-sign.pending'), BASE / name)
            require(all(json.loads((BASE/name).read_text()) == value for name,value in values.items()), 'Published pin pair differs.')
            result.update(status='APPLIED_REVIEW_REQUIRED', phase='complete', source=source_after, stack=new_stack,
                          deltas=[source_delta,c7_delta,c8_delta], root_tracked_after=root_after,
                          output_pin_sha256={name:sha((BASE/name).read_bytes()) for name in values},
                          original_inputs_preserved=True, protected_refs_preserved=True,
                          prefix_workspace_updated=False,
                          next_steps=['Independent review of applied immutable delta', 'Append reviewed reconciliation checkpoint',
                                      'Parent handles stale prefix, executor alias patch and fresh validation'])
        except Exception as error:
            result['error'] = str(error)
            raise
        finally:
            result['completed_utc'] = datetime.now(timezone.utc).isoformat()
            exclusive_json(RESULT, result)
            print(json.dumps({'status':result['status'], 'phase':result['phase'], 'receipt':str(RESULT)}))


if __name__ == '__main__':
    main()

import datetime
import hashlib
import json
import os
import pathlib
import stat
import subprocess
import sys
import time

base = pathlib.Path('/tmp/raised-stack-latest-review-20260914')
cwd = pathlib.Path('/tmp/raised-stack/prefix')
repository = '/common/dev/gammaloop/higher-power-energies-review'


def tracked_audit(revision):
    tree_command = ['git', '-C', repository, 'ls-tree', '-rz', revision]
    audit = dict(revision=revision, tree_command=tree_command, expected_path_count=0,
                 checked_path_count=0, expected_tree_records_sha256=None,
                 actual_tree_records_sha256=None, mismatch_count=0, mismatches=[])
    audit['pass'] = False
    try:
        tree = subprocess.check_output(tree_command)
    except (OSError, subprocess.CalledProcessError) as error:
        audit['error'] = str(error)
        return audit
    rows = [row for row in tree.split(b'\0') if row]
    observed = hashlib.sha256()
    audit['expected_path_count'] = len(rows)
    audit['expected_tree_records_sha256'] = hashlib.sha256(tree).hexdigest()
    for row in rows:
        metadata, path = row.split(b'\t', 1)
        expected_mode, kind, expected_blob = metadata.split()
        entry = cwd / os.fsdecode(path)
        actual_mode = actual_blob = None
        try:
            mode = entry.lstat().st_mode
            if stat.S_ISLNK(mode):
                actual_mode = b'120000'
                data = os.readlink(os.fsencode(entry))
            elif stat.S_ISREG(mode):
                actual_mode = b'100755' if mode & stat.S_IXUSR else b'100644'
                data = entry.read_bytes()
            else:
                raise ValueError('tracked path is not a regular file or symlink')
            actual_blob = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest().encode()
            audit['checked_path_count'] += 1
            observed.update(actual_mode + b' blob ' + actual_blob + b'\t' + path + b'\0')
            if kind != b'blob' or expected_mode != actual_mode or expected_blob != actual_blob:
                raise ValueError('Git type, mode or blob identity mismatch')
        except (OSError, ValueError) as error:
            if actual_blob is None:
                observed.update(b'UNREADABLE\t' + path + b'\0')
            audit['mismatches'].append(dict(
                path=os.fsdecode(path), expected_mode=expected_mode.decode(),
                expected_kind=kind.decode(), expected_blob_sha1=expected_blob.decode(),
                actual_mode=actual_mode.decode() if actual_mode else None,
                actual_blob_sha1=actual_blob.decode() if actual_blob else None,
                error=str(error)))
    audit['actual_tree_records_sha256'] = observed.hexdigest()
    audit['mismatch_count'] = len(audit['mismatches'])
    audit['pass'] = (not audit['mismatches']
                     and audit['checked_path_count'] == len(rows)
                     and observed.hexdigest() == audit['expected_tree_records_sha256'])
    return audit


def main():
    branch, stage, *command = sys.argv[1:]
    pins = json.loads((base / 'validation-pins.json').read_text())
    assert branch in pins and command
    out = base / (branch + '-results') / stage
    out.mkdir(parents=True, exist_ok=False)
    head_command = ['jj', '--ignore-working-copy', 'log', '-r', '@', '--no-graph', '-T', 'commit_id']
    head = subprocess.check_output(head_command, cwd=cwd, text=True).strip()
    assert head == pins[branch], (head, pins[branch])
    tracked_before = tracked_audit(head)
    env = os.environ.copy()
    overrides = dict(CARGO_TARGET_DIR=repository + '/target', CARGO_BUILD_JOBS='4', NEXTEST_TEST_THREADS='4', NEXTEST_RETRIES='0', RAYON_NUM_THREADS='4', RUST_MIN_STACK='67108864', INSTA_UPDATE='no', TESTS_GAMMALOOP_STATE_PATH=str(base/(branch+'-results')/'states'), GAMMALOOP_TESTS_NO_CLEAN_STATE='1', GL_NO_HARD_WARNINGS='1')
    env.update(overrides)
    for key in ['INSTA_FORCE_PASS', 'RUN_PYSECDEC_TESTS', 'GL_ALL_LOG_FILTER', 'GL_DISPLAY_FILTER', 'GL_LOGFILE_FILTER']:
        env.pop(key, None)
    source = cwd / 'crates/spenso/src/network/mod.rs'
    source_sha = hashlib.sha256(source.read_bytes()).hexdigest() if tracked_before['pass'] else None
    argv = ['/tmp/raised-stack/run', '/tmp/raised-stack/python', repository + '/bin/ram_watchdog.py', '--log', str(out/'memory.jsonl'), '--limit-gb', '30', '--'] + command
    receipt = dict(branch=branch, stage=stage, revision=head, cwd=str(cwd), argv=argv, overrides=overrides, started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), source_sha256=source_sha, tracked_before=tracked_before)
    receipt['integrity_scope'] = 'Pinned tracked Git blobs, symlink target bytes and owner executable bit, plus HEAD and Spenso SHA256. Older receipts without tracked_before/tracked_after checked only HEAD and Spenso SHA256.'
    (out / 'command.json').write_text(json.dumps(receipt, indent=2) + '\n')
    if not tracked_before['pass']:
        receipt.update(exit_code=2, execution_skipped=True, integrity_pass=False, tracked_after=None, completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
        (out / 'result.json').write_text(json.dumps(receipt, indent=2) + '\n')
        print('Tracked files do not match pinned Git tree; child command was not started', file=sys.stderr)
        raise SystemExit(2)
    start = time.monotonic()
    print(f'START {branch} {stage}', flush=True)
    with (out / 'output.log').open('wb') as log:
        result = subprocess.run(argv, cwd=cwd, env=env, stdout=log, stderr=subprocess.STDOUT)
    receipt.update(exit_code=result.returncode, elapsed_seconds=time.monotonic()-start, completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    receipt['tracked_after'] = tracked_audit(head)
    try:
        receipt['head_after'] = subprocess.check_output(head_command, cwd=cwd, text=True).strip()
        receipt['source_sha256_after'] = hashlib.sha256(source.read_bytes()).hexdigest()
    except (OSError, subprocess.CalledProcessError) as error:
        receipt['integrity_error'] = str(error)
    receipt['integrity_pass'] = (tracked_before['pass'] and receipt['tracked_after']['pass']
                                 and receipt.get('head_after') == head
                                 and receipt.get('source_sha256_after') == source_sha
                                 and 'integrity_error' not in receipt)
    (out / 'result.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(f'END {branch} {stage}: exit={result.returncode}, elapsed={receipt["elapsed_seconds"]:.2f}s', flush=True)
    print((out / 'output.log').read_text(errors='replace')[-3500:], flush=True)
    sys.exit(result.returncode if receipt['integrity_pass'] else 2)


if __name__ == '__main__':
    main()

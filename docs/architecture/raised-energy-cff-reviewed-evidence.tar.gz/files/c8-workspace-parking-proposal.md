# Park the shared validation workspace before final C8 amendment

The issue is reproduced with installed **jj 0.44.0**. When both workspaces refer to C8 and ROOT amends it, PREFIX’s repository working-copy reference automatically moves to the new commit while its files still contain the prior tree. The current application utility then fails `Prefix workspace revision changed` after it has already amended C8.

A second isolated scenario demonstrates the minimal remedy: first place PREFIX on a preserved independent commit with exactly the candidate tree, then amend C8 from ROOT. PREFIX’s revision and files remain unchanged. Read-only actual Git queries confirm corrected source `392c98c3d2f70896ef94267addfcf610e2df2c88` and candidate `449a59f6f173d100c2da858c541faa1e0dccca6e` both have tree `c87cc95044663a68413010aceb81f9475be342c1`; neither is an ancestor of the other. Their workspace metadata points to the same jj repository.

**Proposed only, after all validation and immediate audits finish:** under the existing idle/lock/tracked-file guards, record a checkpoint and execute:

```sh
jj --repository /tmp/raised-stack/prefix edit 392c98c3d2f70896ef94267addfcf610e2df2c88
```

Verify ROOT and PREFIX both remain at that unchanged source tree, with C8, source objects, all pins/plan/runner and protected references unchanged. Save an external actual parking receipt. The existing final application utility needs no code change: it captures PREFIX’s starting revision dynamically, then preserves it. Release the parking lock once checks finish so the utility can acquire its own lock; keep all validation stopped.

No actual parking, application mutation or build/test was performed here. The first toy setup failure is preserved: it incorrectly resolved jj’s relative repository-pointer path against cwd. The corrected version changes only that scratch path base and retains both scenario assertions. Full toy commands and outcomes, exact script/receipt hashes and the proposed pre-step are in the adjacent JSON. Original recipes and reviews remain unchanged.

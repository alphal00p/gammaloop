#!/usr/bin/env python3
"""Audit completed nextest receipts, without invoking Cargo or tests.

Usage: python audit-nextest-stage.py KEY STAGE [--base SCRATCH_DIRECTORY]
Reads KEY-results/STAGE-list and KEY-results/STAGE. Writes STAGE/audit.json.
Hash only selected test binaries, immediately after the run and before rebuilding.
Filtered/ignored cases may be skipped; selected cases must each pass exactly once.
Repeated identical final-status rows are counted once. No licensed-wrapper reads.
"""
import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import sys

BASE = Path('/tmp/raised-stack-latest-review-20260914')
ANSI = re.compile(r'\x1b\[[0-?]*[ -/]*[@-~]')
ROW = re.compile(r'^\s*(.*?)\s+\[\s*([0-9.]+)s\]\s+\(\s*(\d+)/(\d+)\)\s+(\S+)\s+(\S+)\s*$')
SKIP = re.compile(r'^\s*SKIP\s+\[[^\]]*\]\s+(\S+)\s+(\S+)\s*$')
SUMMARY = re.compile(r'^\s*Summary\s+\[\s*([^\]]+)\]\s+(\d+) tests? run:\s*(.*?)\s*$')


def read_stable(path):
    before = path.stat()
    data = path.read_bytes()
    after = path.stat()
    if (before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns) != (after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns):
        raise ValueError(f'Artifact changed while reading: {path}')
    return data


def listing_from_log(text):
    """Find one complete nextest JSON object amid compilation/runner text."""
    text = ANSI.sub('', text)
    decoder, offset, found = json.JSONDecoder(), 0, []
    while (start := text.find('{', offset)) >= 0:
        try:
            value, end = decoder.raw_decode(text, start)
        except json.JSONDecodeError:
            offset = start + 1
            continue
        offset = end
        if isinstance(value, dict) and 'rust-suites' in value and 'test-count' in value:
            found.append(value)
    if len(found) != 1:
        raise ValueError(f'Expected one complete nextest listing JSON object, found {len(found)}')
    return found[0]


def cargo_argv(receipt, phase):
    argv = receipt['argv']
    for index in range(len(argv) - 2):
        if argv[index:index + 3] == ['cargo', 'nextest', phase]:
            return argv[index:]
    raise ValueError(f'No cargo nextest {phase} command in stage receipt')


def option(argv, name, default=None):
    for index, arg in enumerate(argv):
        if arg == name:
            return argv[index + 1]
        if arg.startswith(name + '='):
            return arg.split('=', 1)[1]
    return default


def selection_argv(argv):
    # Strip only listing/reporting/execution controls, retaining Cargo/filter options.
    values = {'--message-format', '--test-threads', '--retries', '--status-level',
              '--final-status-level', '--failure-output', '--success-output', '--run-ignored', '--no-tests'}
    switches = {'--no-fail-fast', '--fail-fast', '--no-capture'}
    result, index = [], 3
    while index < len(argv):
        name = argv[index].split('=', 1)[0]
        if name in values:
            index += 1 if '=' in argv[index] else 2
        elif name in switches:
            index += 1
        else:
            result.append(argv[index])
            index += 1
    return result


def binary_digest(path):
    before = path.stat()
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(4 * 1024 * 1024), b''):
            digest.update(chunk)
    after = path.stat()
    if (before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns) != (after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns):
        raise ValueError(f'Selected binary changed while hashing: {path}')
    return {'path': str(path), 'sha256': digest.hexdigest(), 'bytes': after.st_size,
            'mtime_ns': after.st_mtime_ns}


def audit(base, key, stage):
    errors, sources = [], []
    result = {'key': key, 'stage': stage, 'audited_utc': datetime.now(timezone.utc).isoformat(),
              'errors': errors, 'sources': sources}

    def check(condition, message):
        if not condition:
            errors.append(message)

    def read(path):
        data = read_stable(path)
        sources.append({'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
        return data.decode(errors='replace')

    try:
        folder = base / (key + '-results')
        listed_folder, run_folder = folder / (stage + '-list'), folder / stage
        listed = json.loads(read(listed_folder / 'result.json'))
        ran = json.loads(read(run_folder / 'result.json'))
        for phase, receipt in [('list', listed), ('run', ran)]:
            check(receipt.get('exit_code') == 0, f'{phase} exit was {receipt.get("exit_code")}')
            check(receipt.get('integrity_pass') is True, f'{phase} source integrity receipt did not pass')
            check(receipt.get('branch') == key, f'{phase} receipt key mismatch')
        check(listed['revision'] == ran['revision'], 'List/run revisions differ')
        check(listed['source_sha256'] == ran['source_sha256'], 'List/run source fingerprints differ')
        pins = json.loads(read(base / 'validation-pins.json'))
        check(ran['revision'] == pins[key], 'Run revision differs from the key pin')
        list_argv, run_argv = cargo_argv(listed, 'list'), cargo_argv(ran, 'run')
        check(selection_argv(list_argv) == selection_argv(run_argv), 'List/run Cargo or filter arguments differ')
        check(option(run_argv, '--retries', ran.get('overrides', {}).get('NEXTEST_RETRIES')) == '0', 'Retries were not disabled')
        check(ran.get('overrides', {}).get('INSTA_UPDATE') == 'no', 'Snapshot updates were not disabled')
        mode = option(run_argv, '--run-ignored', 'default')
        check(mode in {'default', 'all', 'ignored-only'}, f'Unknown ignored mode: {mode}')
        listing = listing_from_log(read(listed_folder / 'output.log'))
        expected, excluded, binaries = set(), set(), {}
        for suite in listing['rust-suites'].values():
            binary = suite['binary-id']
            for name, case in suite.get('testcases', {}).items():
                identity = (binary, name)
                check(identity not in expected | excluded, f'Duplicate listed identity: {identity}')
                matched = case['filter-match']['status'] == 'matches'
                admitted = (mode == 'all' or (mode == 'default' and not case['ignored'])
                            or (mode == 'ignored-only' and case['ignored']))
                if matched and admitted:
                    expected.add(identity)
                    binaries[binary] = Path(suite['binary-path'])
                else:
                    excluded.add(identity)
        check(len(expected | excluded) == listing['test-count'], 'Listing test-count does not match testcase identities')
        check(bool(expected), 'Unexpected zero selected tests')
        result.update(revision=ran['revision'], ignored_mode=mode, listed_count=listing['test-count'],
                      selected_count=len(expected), excluded_count=len(excluded),
                      selected_identities=[list(identity) for identity in sorted(expected)],
                      list_argv=list_argv, run_argv=run_argv)
        identity_bytes = ''.join(f'{binary}\t{name}\n' for binary, name in sorted(expected)).encode()
        result['selected_identity_sha256'] = hashlib.sha256(identity_bytes).hexdigest()
        lines = ANSI.sub('', read(run_folder / 'output.log')).splitlines()
        summaries = {line.strip() for line in lines if SUMMARY.match(line)}
        if len(summaries) != 1:
            raise ValueError(f'Expected one distinct completed summary, found {len(summaries)}')
        summary = summaries.pop()
        elapsed, total, summary_tail = SUMMARY.match(summary).groups()
        total = int(total)
        counts = {word: int(match[1]) if (match := re.search(r'(\d+) ' + word + r'\b', summary_tail)) else 0
                  for word in ['passed', 'failed', 'skipped']}
        cases, indices, skipped, duplicates = {}, {}, set(), 0
        for line in lines:
            if match := ROW.match(line):
                status, duration, index, denominator, binary, name = match.groups()
                identity, index = (binary, name), int(index)
                row = {'binary_id': binary, 'test_name': name, 'status': status.strip(),
                       'seconds': float(duration), 'progress_index': index}
                check(int(denominator) == total, f'Progress denominator differs: {identity}')
                check(identity not in cases or cases[identity] == row, f'Conflicting repeated status: {identity}')
                check(index not in indices or indices[index] == identity, f'Progress index reused: {index}')
                duplicates += identity in cases
                cases[identity], indices[index] = row, identity
            elif match := SKIP.match(line):
                skipped.add(tuple(match.groups()))
            elif re.match(r'^\s*error(?:\[[^\]]+\])?:', line):
                errors.append('Error diagnostic: ' + line.strip())
        statuses = dict(Counter(row['status'] for row in cases.values()))
        passed = {identity for identity, row in cases.items() if row['status'] == 'PASS'}
        check(set(cases) == expected, 'Executed identity set differs from selected identity set')
        check(passed == expected, 'Not every selected identity has a PASS outcome')
        check(total == len(expected) == len(cases), 'Summary executed count differs from selected/unique outcomes')
        check(counts['passed'] == len(passed) == total and counts['failed'] == 0, 'Summary pass/failure counts disagree or include failures')
        check(counts['skipped'] == len(excluded), 'Summary skipped count differs from intentionally excluded listing entries')
        check(not (skipped & expected), 'A selected test was skipped')
        check(skipped <= excluded, 'An unexpected skipped identity was reported')
        check(set(indices) == set(range(1, total + 1)), 'Completed progress indices are missing or unexpected')
        result.update(summary=summary, summary_elapsed=elapsed.strip(), summary_counts=counts,
                      status_counts=statuses, unique_outcomes=len(cases), repeated_result_lines_ignored=duplicates,
                      missing=[list(x) for x in sorted(expected - passed)],
                      unexpected=[list(x) for x in sorted(set(cases) - expected)],
                      cases=[cases[x] for x in sorted(cases)], binary_hashes=[])
        started_ns = int(datetime.fromisoformat(ran['started_utc']).timestamp() * 1_000_000_000)
        hashed = {}
        for binary, path in sorted(binaries.items()):
            # Paths come only from selected suites. Never scan the target directory.
            resolved = path.resolve(strict=True)
            check(resolved != Path('/tmp/raised-stack/run'), 'Selected binary resolves to forbidden wrapper')
            if resolved == Path('/tmp/raised-stack/run'):
                continue
            if resolved not in hashed:
                hashed[resolved] = binary_digest(resolved)
            item = {'binary_id': binary, **hashed[resolved]}
            check(item['mtime_ns'] <= started_ns, f'Selected binary was replaced after run start: {binary}')
            result['binary_hashes'].append(item)
        result['binary_hash_limit'] = 'Current selected binaries only; stable while hashing and modified no later than recorded run start. Rebuilding before this audit invalidates that provenance check.'
    except (OSError, ValueError, KeyError, TypeError, IndexError) as exc:
        errors.append(f'{type(exc).__name__}: {exc}')
    result['status'] = 'FAIL' if errors else 'PASS'
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('key')
    parser.add_argument('stage')
    parser.add_argument('--base', type=Path, default=BASE)
    args = parser.parse_args()
    if any(not re.fullmatch(r'[A-Za-z0-9_.-]+', value) or value in {'.', '..'} for value in [args.key, args.stage]):
        parser.error('key/stage must be simple names')
    result = audit(args.base, args.key, args.stage)
    output = args.base / (args.key + '-results') / args.stage / 'audit.json'
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({key: result[key] for key in ['status', 'key', 'stage', 'errors']} | {'output': str(output), 'selected': result.get('selected_count'), 'unique_outcomes': result.get('unique_outcomes')}))
    return 0 if result['status'] == 'PASS' else 1


if __name__ == '__main__':
    sys.exit(main())

# Latest UV review

Reviewed `a1140c90` against `78395e3a`: all18 assigned files, +2449/-252 lines. The source references below refer to immutable `a1140c90`; the small follow-up fix is separately recorded. No build or test result is claimed by this reviewer.

## Findings

### UV-1 — P2: Preserve typed zero when grouped sectors cancel

`crates/gammalooprs/src/uv/approx/projected_4d.rs:489`–`505`. **implemented; validation pending root task**.

Two same-binding nonzero sectors N and -N survive FourDSectors::with_atom individually. projection_sectors merges and removes their zero sum. Original project_local_4d checks only raw active emptiness, then requires maps or emits Projected4dCts([]). build_projected rejects empty sectors, so a valid zero is rejected.

Group before checking typed zero and before requiring orientation maps; use existing Projected4dSector zero representation.

### UV-2 — P2: Do not lock cache implementation statistics in behavioral tests

`crates/gammalooprs/src/uv/approx/projected_4d.rs:654`–`675`. **implemented; validation pending root task**.

Tests assert exact warm preparation/native-generation counters, exactly three retained entries, exact cold build increments, one-entry eviction occupancy and minimum eviction count. Later lines1232-1234 compare private projected_component_requests. Equivalent execution with another retention policy or grouping fails despite correct output.

Keep complete cached/uncached/disabled/evicted output equivalence and a declared memory-cap contract; report hit/build/request counts in benchmark evidence, not acceptance assertions.

### UV-3 — P2: Check complete canonical values instead of internal bucket order and IDs

`crates/gammalooprs/src/uv/approx/local_4d.rs:1931`–`1941`. **implemented; validation pending root task**.

New rational-shell tests require vector positions0/1/2 and bucket counts. Other new tests assert canonical class IDs/counts, terms layout and stable projection vector order (1956-2247). Those are private implementation choices, beyond the requested outward-value/factorization contract.

Reconstruct complete factorized rational values and compare exact difference or structural factorization where intended. Verify signed aliases, unequal masses, provenance/frozen domains through complete source/reconstruction or projected-value outcomes. Preserve independent physical incidence and error oracles.

### UV-4 — P2: Bound numerical uncertainty before accepting route equivalence

`tests/tests/uv.rs:2241`–`2247`. **implemented; validation pending root task**.

The only precondition on evaluated results is finite/nonzero complex value. Tolerance is1000 times reported relative uncertainty with no upper bound. If uncertainty reaches0.002, tolerance is2 and any pair of nonzero finite complex values passes because |a-b|/max(|a|,|b|)<=2. No assertion ensures uncertainty is finite/small.

The authorized correction uses a fixed1e-9 relative complex-norm tolerance. Reported accuracy is diagnostic only; finite/nonzero checks, shared evaluator helper and fallback settings are unchanged.

## Fix made during review

Moved projection grouping before the existing zero/orientation checks. The zero now follows the same existing typed-zero assembly path as a pruned Taylor result. Comments and structured grouping diagnostics are preserved. A new test in `local_4d.rs` sends both a pair of same-binding `+N/-N` sectors and an ordinary zero through projection and complete `build_projected`, then checks every allowed cut-order value is zero. It checks no private count, cache layout, iteration order or string formatting. No expectation was changed in a test known to be failing. The subsequent authorized outward-test changes are listed below.

The initial zero-only patch is `uv-zero-fix.patch`; the complete follow-up is `uv-review-fixes.patch`. `rustfmt` through `/tmp/raised-stack/run` and `git diff --check` passed; Cargo validation is pending the root task. The first direct rustfmt attempt was unavailable on the default PATH, then the established environment succeeded. The patch tool itself could not start because bubblewrap is unavailable; the same scoped edit was applied through approved shell execution. No automatic approval rejection occurred.

## Ownership in the reconstructed history

The bulk of this change is one coherent addition: **optimize factorized local UV projection**. It introduces canonical denominator-class algebra, preparation/context lifetime, exact source-mapping reuse, component-state grouping, early color reduction, delayed numerical Dirac work, bulk summation, and physical route acceptance tests. Keep the coupled signatures and consumers together in a new commit rather than moving only consumers backward into C3. Existing C3 is the conceptual owner of UV reconstruction, but the new implementation has sufficient distinct performance architecture to justify the user’s permitted extra commit.

The powered scalar-product protection in `integrated.rs` and its independent analytic spin contraction test belong with C6. The two mechanical phase-test `as_chunks` migrations belong with C5. There is no new physical phase convention or integrated mass/forest-owner convention in this assigned diff. Shared Spenso/Symbolica prerequisites and exact-source API dependencies are being reviewed by the other agents.

## Rust patterns and effectiveness

- **Separate raw and canonical types:** `FourDSector` remains authoritative for outer Taylor recursion, while `CanonicalUvSector` owns projection-only class algebra and its exact source certificate. This extra type prevents an important semantic mix-up and is justified despite the size of the change.

- **Graph-owned context and immutable `Arc` payloads:** production constructs the nonserialized context once per graph computation, then passes a mutable borrow through forest/cut consumers. Reuse shares prepared source data, while the numerator assignment remains request-specific. The observed callers never change parent graph topology within that lifetime. Cache accounting is explicit.

- **`BTreeMap::entry`, exact keys and sparse powers:** grouping uses exact component, signed routing, mass and polynomial identity, retaining physical incidence separately. Numerator sums remain factorized. Deterministic traversal is useful for reproducibility but should not be a correctness test contract.

- **Consuming iterator bulk addition:** `Integrands::zip_add` validates every cut-key shape, gathers per-key atoms, and calls `Atom::add_many` once. Callers migrate together and error ownership remains explicit. This is a concise implementation of the intended allocation reduction.

- **Bounded fixed-point rewriting:** sign normalization checks structural equality; component grouping repeats only when state count decreases. The loop guards are explicit and prevent unconstrained recursive normalization. Integer powers retain sign rules while fractional-power branches remain untouched.

- **Alias protection at analytic expansion:** `AliasedAtom` hides already completed scalar products before tensor shorthand materialization and restores them afterward. Names are collision-checked against existing symbols. The new Dirac-trace oracle tests full values with open and closed metric contractions, which is effective outward coverage.

- **Errors at semantic boundaries:** conflicting component ownership, malformed completed provenance, positive polynomials inconsistent with certified momentum, and cut-key mismatches return structured errors. Class lookup by internal ID relies on the constructor invariant. No compatibility shim or on-disk fallback was introduced.

## KISS and coverage limits

The separation between recursive raw sectors and canonical projection is warranted by exact reconstruction, not merely an extra interface. Existing numerator methods and tracing are reused. The longest projection method carries five-element tuples across grouping waves and many telemetry counters; this is readable only with careful invariant comments and should not acquire another parallel mode/helper. No extra helper was added for the review fix. Performance statistics belong in measured artifacts; the removed exact private counts in tests overconstrained otherwise equivalent simplification choices.

The three new physical route tests cover local-only subtraction (`generate_integrated=false`) with thresholds disabled and the Compare UV orchestrator. They are useful GL00/GL01/GL262 physics inputs, but do not independently certify integrated UV addbacks or the final answer against an external physics oracle. The GL262 set assertion checks physical subgraph membership and DOD, not implementation cache topology. All preexisting acceptance/oracle changes in assigned files were mechanical API/iterator migrations; no old expected value or tolerance was relaxed. The new trace-retention test checks factorization and trace presence but would benefit from a complete contraction value as a companion oracle.

## Complete file coverage

| File | + / − | Owner | Reviewed behavior |
|---|---:|---|---|

| `crates/gammalooprs/src/uv/approx/direct_3d/branches.rs` | 7 / 7 | new UV projection optimization | Migrates checked summation to bulk iterator addition; branch selector multiplication remains once per branch. |

| `crates/gammalooprs/src/uv/approx/direct_3d/kernel.rs` | 1 / 0 | new UV projection optimization | Simplifies color on existing numerator boundary before energy mapping. |

| `crates/gammalooprs/src/uv/approx/final_integrand.rs` | 45 / 13 | new UV projection optimization | Early cograph color simplification, structured dumps, bulk selector-free accumulation, typed-zero handling, context-only test migration. |

| `crates/gammalooprs/src/uv/approx/integrated.rs` | 92 / 5 | C6 | Protects completed scalar products while materializing analytic spin tensors; exact closed/open contraction oracles added. |

| `crates/gammalooprs/src/uv/approx/local_3d/residue_localizer.rs` | 45 / 4 | new UV projection optimization | Reports total bounded routing-selection cost including preparation and discarded proposals; selected source and numerator remain paired. |

| `crates/gammalooprs/src/uv/approx/local_3d/tests.rs` | 8 / 6 | new UV projection optimization | Context API migration and bulk-add migration preserve complete numerator/cut-key assertions. |

| `crates/gammalooprs/src/uv/approx/local_4d.rs` | 1379 / 93 | new UV projection optimization | Canonical classes preserve routing/mass/full polynomial/component and separate incidence witness; source certificates, rational-shell grouping, deferred Dirac algebra and complete new tests reviewed. |

| `crates/gammalooprs/src/uv/approx/mod.rs` | 39 / 11 | new UV projection optimization | Context migration together with callers; as_chunks mechanical typed-pair iteration keeps same remainder behavior. |

| `crates/gammalooprs/src/uv/approx/projected_4d.rs` | 498 / 83 | new UV projection optimization | Single-graph context lifetime; canonical preparation, per-wave state grouping, budgeted caches, instrumentation and all added tests reviewed. |

| `crates/gammalooprs/src/uv/forest.rs` | 17 / 5 | new UV projection optimization | One context shared over this graph’s forest/cut computation; no topology mutation introduced. |

| `crates/gammalooprs/src/uv/hedge_poset.rs` | 22 / 6 | new UV projection optimization | Same context lifetime for DAG route; root and disjoint replay signatures migrated coherently. |

| `crates/gammalooprs/src/uv/mod.rs` | 28 / 2 | new UV projection optimization | Validates all cut-key shapes before one Atom::add_many per key; errors retain missing-side distinction. |

| `crates/gammalooprs/src/uv/orchestrator.rs` | 7 / 1 | new UV projection optimization | Legacy renormalization entry uses fresh one-graph projection context. |

| `crates/gammalooprs/src/uv/tests.rs` | 66 / 0 | new UV projection optimization | Complete exact factorized values and mismatched cut shape checks; factorization equality is intentionally meaningful. |

| `tests/tests/test_runs/amplitude_phase_conventions.rs` | 3 / 1 | C5 | chunks_exact to as_chunks typed arrays; analytic sign oracle untouched. |

| `tests/tests/test_runs/scalar_3L_cross_section_inspects.rs` | 10 / 14 | new UV projection optimization | Setup/generation elapsed reporting now applies to every scalar case, no acceptance change. |

| `tests/tests/test_runs/scalar_phase_conventions.rs` | 1 / 1 | C5 | chunks_exact to as_chunks in momentum contraction; same point coordinates/sign calculation. |

| `tests/tests/uv.rs` | 181 / 0 | new UV projection optimization | Adds three physical local-only route comparisons with three momentum points; GL262 checks physical UV region/DOD set, not cache topology. |


## Targeted validation to run

Run formatting/check before compilation, then the relevant exact and outward tests below with the existing license, concurrent execution and resource cap. Do not modify any failing existing test without the repository-required explicit confirmation. Root validation should retain actual counts, exits and logs.

- `uv::approx::local_4d::tests::cancelling_projection_sectors_preserve_final_cut_orders_without_energy_maps`

- `uv::approx::final_integrand::tests::projected_zero_sectors_preserve_cut_orders_without_energy_maps`

- `uv::approx::integrated::tests::analytic_spin_expansion_preserves_powered_scalar_products`

- `uv::approx::integrated::tests::projected_dirac_algebra_precedes_single_and_double_pole_expansion`

- `uv::approx::integrated::tests::projected_dirac_numerator_matches_scalar_master_before_backend_truncation`

- `uv::approx::projected_4d::tests::nested_banana_quotient_powered_component_has_the_analytic_one_energy_sign`

- `uv::approx::projected_4d::tests::typed_taylor_wave_batches_genuine_owner_relabelled_terms`

- `uv::approx::projected_4d::tests::typed_taylor_next_component_reuses_one_topology_for_prior_residue_states`

- `uv::approx::local_4d::tests::early_color_simplification_preserves_open_and_nested_numerator_boundaries`

- `uv::tests::integrands_bulk_add_preserves_factorized_coefficients_and_cut_orders`

- `uv::tests::integrands_bulk_add_checks_every_complete_cut_shape`

- `slow::aa_aa_2l_gl00_matches_across_local_uv_routes`

- `slow::aa_aa_2l_gl01_matches_across_local_uv_routes`

- `slow::aa_aa_3l_gl262_matches_across_local_uv_routes`


Also run the canonical class/projection tests after replacing implementation-locked assertions; nested/disjoint UV and phase/Vakint regressions remain necessary because deferred Dirac work crosses those consumers. No PySecDec invocation is implied.

## Exact authorized test changes

Eight unit-test functions and three integration-test identities (through their shared helper) were revised; one outward cancellation regression was added. No shared evaluation/fallback settings changed. No failing existing test was known when the edits were authorized or performed. The tests still need to be run by the root task.

- `uv::approx::projected_4d::tests::canonical_source_and_template_preparation_share_retention_invariant_budget`: Preserve all five policy states and compare full factorized coefficient. Replace exact occupancy/build/hit/eviction assertions with configured retained-byte upper bound; disabled bound is zero.

- `uv::approx::projected_4d::tests::typed_taylor_next_component_reuses_one_topology_for_prior_residue_states`: Keep cached/sequential and combined/separate complete value oracles; remove canonical term-count and private request-count comparison.

- `uv::approx::local_4d::tests::rational_shell_groups_mixed_multisets_without_expanding_numerators`: Reconstruct entire rational values for mixed shells, squared shell, reordered-denominator cancellation, and retained factorized numerator; no vector size/order assertions.

- `uv::approx::local_4d::tests::canonical_uv_classes_certify_signed_aliases_and_preserve_raw_sectors`: Check complete neutral-frame signed rational value and unequal-mass rational sum, retaining source immutability. Remove class IDs, class/member count and term layout assertions.

- `uv::approx::local_4d::tests::canonical_uv_signed_multiloop_carriers_preserve_factorized_numerators`: Check complete neutral-frame rational value against independent signed hard-momentum numerator and original denominator polynomial. Keep opaque fifth power, normalization idempotence, huge/negative integer powers and fractional branch invariance.

- `uv::approx::local_4d::tests::canonical_uv_positive_blocks_and_absent_poles_keep_their_roles`: Check complete positive-block rational result and absent-pole affine value; remove class count, witness length and private provenance-role representation assertions.

- `uv::approx::local_4d::tests::canonical_positive_denominator_recovers_one_class_from_expanded_coordinates`: Check complete reconstructed rational value from independently expanded denominator polynomial. Retain rejection oracle for inconsistent momentum/polynomial. Remove private class ID/count/power-map shape.

- `uv::approx::local_4d::tests::projection_sector_grouping_preserves_frozen_domains_and_recursion`: Check complete coefficient weighted by frozen localizers and preserved recursive aggregate, instead of sector count or vector positions.

- `slow::aa_aa_2l_gl00_matches_across_local_uv_routes; slow::aa_aa_2l_gl01_matches_across_local_uv_routes; slow::aa_aa_3l_gl262_matches_across_local_uv_routes`: Shared new comparison uses fixed1e-9 complex-relative tolerance and diagnostic-only reported accuracy. Same three physical points, routes, generation settings, finite/nonzero assertions and GL262 physical-region oracle.

- `uv::approx::local_4d::tests::cancelling_projection_sectors_preserve_final_cut_orders_without_energy_maps`: New regression: complete project/build result for same-binding +N/-N sectors equals ordinary zero at every supported cut order without production energy maps.

The new mathematical comparisons preserve graph numerator factors; only the existing small denominator polynomial is expanded. Integer and fractional power invariance oracles remain unchanged. The retained cache byte-bound check concerns the configured resource contract; cache entry counts, preparation counters, hit counts and request counts are no longer acceptance criteria in these revised tests.

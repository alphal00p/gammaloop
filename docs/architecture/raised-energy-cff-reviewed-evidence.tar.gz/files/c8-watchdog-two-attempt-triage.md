# C8 curated listing monitor timeouts

Both attempts at C8 `449a59f6f173d100c2da858c541faa1e0dccca6e` exited **125 while compiling for `cargo nextest list`**. Neither completed a listing or executed the selected test bodies. Their Cargo arguments match; both retain four workers, disabled snapshots/retries and the 30,000,000,000-byte process-tree RSS guard.

| Attempt | Elapsed seconds | Logged samples | Maximum logged RSS bytes | Timeout event seconds |
| --- | --- | --- | --- | --- |
| curated-list | 155.618 | 29 | 7256641536 | 154.409 |
| curated-v2-list | 90.879 | 17 | 7280697344 | 90.122 |

Both logs end with the exact global `ps -axo pid=,ppid=,pgid=,rss=` query exceeding **2 seconds**. Neither contains a memory-limit or completion event. The maxima above are retained samples, not actual full-run peaks or a bound on memory during the monitoring gap. HEAD, Spenso and before/after tracked-file guards passed both attempts.

The watchdog catches the timeout, reports monitoring failure and enters `finally` cleanup. It attempts to stop the tracked process groups and descendants, freezes/rescans before killing, falls back to last-known identities when its sampler fails, and waits for the direct child. Exit125 is consistent with that cleanup returning, but neither log records cleanup identities or an independent post-exit process inventory. Complete descendant cleanup is therefore not separately established by these receipts.

The saved root health probe has five successful 2-second-deadline queries at 0.223–0.262 seconds (5123 processes), without its own timestamp. The independent first-attempt triage at 14:38:07 UTC records three successful queries at about 0.199–0.200 seconds (5199 processes, 10-second deadline), each within the original 2-second deadline. That triage predates attempt 2 at 14:40:33 UTC. These probes do not establish recovery after the second failure. The host scheduling/I/O/resource cause remains unknown.

This is a read-only triage, not a new test execution or acceptance. Exact input hashes, source references, guards and probe evidence are in the adjacent JSON. A separately reviewed timeout adapter would still need the original shared lock, cap, worker controls and fail-closed behavior; a longer timeout also increases the possible blind interval. No adapter was reviewed or run here.

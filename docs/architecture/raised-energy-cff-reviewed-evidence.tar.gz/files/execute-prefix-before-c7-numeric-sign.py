#!/usr/bin/env python3
"""Explicitly execute one pinned prefix's scratch validation plan.

Usage (only when the prefix is idle):
  /tmp/raised-stack/run /tmp/raised-stack/python execute-prefix.py 3 [STAGE ...]
With no names, execute all stages in plan order. Naming either half of a nextest
pair selects listing, test run, and immediate audit together. No retries or pin
updates. Reuse exact successful receipts only; never overwrite an existing stage.
A process guard and advisory lock protect the shared prefix. The root operator
must not launch other manual prefix commands while this executor owns it.
"""
import argparse
from datetime import datetime, timezone
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import subprocess
import sys

BASE = Path('/tmp/raised-stack-latest-review-20260914')
PREFIX = Path('/tmp/raised-stack/prefix')
ALIASES = {1: {'fmt': 'fmt-v4', 'check': 'check-v3', 'build': 'build-v2', 'clippy': 'clippy-v2'},
           3: {'fmt': 'fmt-v2', 'check': 'check-v2', 'build': 'build-v2', 'clippy': 'clippy-v2'},
           7: {'fmt': 'fmt-v2', 'check': 'check-v2'}}


def module(name, filename):
    spec = importlib.util.spec_from_file_location(name, BASE / filename)
    loaded = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(loaded)
    return loaded


def load(path):
    return json.loads(path.read_text())


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def idle_prefix():
    active = []
    for entry in Path('/proc').iterdir():
        if not entry.name.isdigit() or int(entry.name) == os.getpid():
            continue
        try:
            cwd = (entry / 'cwd').resolve(strict=True)
            if not cwd.is_relative_to(PREFIX):
                continue
            comm = (entry / 'comm').read_text().strip()
            args = (entry / 'cmdline').read_bytes().split(b'\0')
        except (FileNotFoundError, ProcessLookupError, PermissionError):
            continue
        if (comm in {'cargo', 'rustc', 'rustfmt', 'clippy-driver', 'cargo-clippy', 'cargo-nextest', 'nextest'}
                or any(b'ram_watchdog.py' in arg or b'run-stage.py' in arg for arg in args)
                or any(b'/target/' in arg and b'/deps/' in arg for arg in args[:1])):
            active.append((entry.name, comm))
    require(not active, f'Prefix has active validation processes: {active}')


def units(entry, requested):
    stages = entry['stages']
    names = {name for name, _ in stages}
    require(not (set(requested) - names), f'Unknown stages: {sorted(set(requested) - names)}')
    result, index = [], 0
    while index < len(stages):
        name, argv = stages[index]
        require(argv[:1] == ['cargo'], f'Unexpected command in plan: {name}')
        if argv[:2] == ['cargo', 'nextest']:
            require('--all-targets' not in argv, f'nextest must omit --all-targets: {name}')
            require(argv[2] == 'list' and name.endswith('-list'), f'Unpaired nextest command: {name}')
            require(index + 1 < len(stages), f'Missing paired run: {name}')
            run_name, run_argv = stages[index + 1]
            require(run_name == name[:-5] and run_argv[:3] == ['cargo', 'nextest', 'run'], f'Bad pair: {name}')
            require('--all-targets' not in run_argv, f'nextest must omit --all-targets: {run_name}')
            if not requested or name in requested or run_name in requested:
                result.append([(name, argv), (run_name, run_argv)])
            index += 2
        else:
            if not requested or name in requested:
                result.append([(name, argv)])
            index += 1
    require(result, 'No stages selected')
    return result


def command_from_receipt(receipt):
    argv = receipt['argv']
    require('--' in argv, 'Missing watchdog command boundary')
    return argv[argv.index('--') + 1:]


def reusable(folder, revision, argv):
    require((folder / 'result.json').is_file(), f'Existing incomplete stage cannot be retried: {folder}')
    result = load(folder / 'result.json')
    require(result.get('revision') == revision, f'Existing stage belongs to another revision: {folder}')
    require(command_from_receipt(result) == argv, f'Existing stage command differs: {folder}')
    require(result.get('exit_code') == 0 and result.get('integrity_pass') is True, f'Existing failed stage cannot be reused or retried: {folder}')
    require((folder / 'output.log').is_file(), f'Stage output is missing: {folder}')
    return result


def stage_name(number, name, revision, argv):
    root = BASE / f'c{number}-results'
    alias = ALIASES.get(number, {}).get(name)
    # Explicit aliases describe reviewed source corrections, not retry policy.
    if alias:
        canonical = root / name / 'result.json'
        if canonical.exists():
            prior = load(canonical)
            require(prior.get('revision') != revision or prior.get('exit_code') == 0,
                    f'Unresolved same-revision failure remains at {canonical.parent}')
        if (root / alias).exists():
            reusable(root / alias, revision, argv)
        return alias
    return name


def selected_listing(folder, run_argv, requirements, audit):
    listing = audit.listing_from_log((folder / 'output.log').read_text(errors='replace'))
    mode = audit.option(run_argv, '--run-ignored', 'default')
    require(mode in {'default', 'all', 'ignored-only'}, f'Unknown ignored mode: {mode}')
    selected = set()
    for suite in listing['rust-suites'].values():
        for name, case in suite.get('testcases', {}).items():
            if case['filter-match']['status'] != 'matches':
                continue
            if mode == 'default' and case['ignored'] or mode == 'ignored-only' and not case['ignored']:
                continue
            identity = suite['binary-id'], name
            require(identity not in selected, f'Duplicate selected identity: {identity}')
            require('pysecdec' not in identity[0].lower()
                    and name.rsplit('::', 1)[-1] != 'test_integrate_1l_decorated_indices_pysecdec',
                    f'Manual PySecDec integration is forbidden: {identity}')
            selected.add(identity)
    require(len(selected) >= max(1, requirements.get('minimum_selected', 1)), 'Unexpected empty or undersized selection')
    names = {name for _, name in selected}
    expected = requirements.get('expected_exact_names', [])
    if expected:
        require(names == set(expected) and len(selected) == len(expected), f'Exact physical test names differ: {sorted(names)}')
    for prefix in requirements.get('required_name_prefixes', []):
        require(any(name.startswith(prefix) for name in names), f'Required test family absent: {prefix}')
    return selected


def validate_saved_audit(folder, revision, run_argv, selected):
    require((folder / 'audit.json').is_file(), f'Completed run lacks its immediate audit; do not rebuild or retry: {folder}')
    saved = load(folder / 'audit.json')
    require(saved.get('status') == 'PASS' and saved.get('revision') == revision, f'Existing test audit failed or has another revision: {folder}')
    require(saved.get('run_argv') == run_argv, f'Existing audit command differs: {folder}')
    require({tuple(item) for item in saved['selected_identities']} == selected, f'Existing audit selection differs: {folder}')
    for source in saved['sources']:
        path = Path(source['path'])
        if path == BASE / 'validation-pins.json':
            continue  # Its selected key is checked against the frozen pin throughout this run.
        require(hashlib.sha256(path.read_bytes()).hexdigest() == source['sha256'], f'Existing audited artifact changed: {path}')
    require(saved.get('binary_hashes'), f'Existing test audit lacks selected-binary fingerprints: {folder}')
    return saved


def invoke_stage(number, name, argv, revision, completed):
    key = f'c{number}'
    actual = stage_name(number, name, revision, argv)
    folder = BASE / (key + '-results') / actual
    if folder.exists():
        receipt = reusable(folder, revision, argv)
        scope = 'tracked tree' if 'tracked_before' in receipt else 'HEAD + Spenso file only'
        print(f'REUSE {key} {actual} ({scope})', flush=True)
        completed.append({'stage': name, 'receipt_stage': actual, 'reused': True, 'integrity_scope': scope})
        return folder, True, 0
    idle_prefix()
    require(load(BASE / 'validation-pins.json')[key] == revision, 'Pinned revision changed during execution')
    driver_log = BASE / (key + '-results') / (actual + '.driver.log')
    require(not driver_log.exists(), f'Prior driver output must be preserved; refusing retry: {driver_log}')
    print(f'RUN {key} {name}', flush=True)
    result = subprocess.run([sys.executable, str(BASE / 'run-stage.py'), key, actual, *argv],
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    with driver_log.open('x') as stream:
        stream.write(result.stdout)
    completed.append({'stage': name, 'receipt_stage': actual, 'reused': False, 'exit_code': result.returncode,
                      'driver_log': str(driver_log)})
    return folder, False, result.returncode


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('prefix', type=int, choices=range(1, 9))
    parser.add_argument('stages', nargs='*')
    args = parser.parse_args()
    plan_path = BASE / 'prefix-validation-plan.executable.json'
    plan = load(plan_path)
    entry = next(row for row in plan['prefixes'] if row['prefix'] == args.prefix)
    selected_units = units(entry, args.stages)
    key = f'c{args.prefix}'
    revision = load(BASE / 'validation-pins.json')[key]
    require(re.fullmatch('[0-9a-f]{40}', revision), 'Pin must be a complete commit hash')
    audit = module('nextest_stage_audit', 'audit-nextest-stage.py')
    stage_runner = module('prefix_stage_runner', 'run-stage.py')
    completed = []
    summary = {'key': key, 'revision': revision, 'plan_sha256': hashlib.sha256(plan_path.read_bytes()).hexdigest(),
               'requested_stages': args.stages, 'started_utc': datetime.now(timezone.utc).isoformat(), 'stages': completed}
    with (BASE / 'prefix-execution.lock').open('a+') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        idle_prefix()
        head = subprocess.check_output(['jj', '--ignore-working-copy', 'log', '-r', '@', '--no-graph', '-T', 'commit_id'], cwd=PREFIX, text=True).strip()
        require(stage_runner.tracked_audit(head)['pass'], 'Prefix tracked contents differ from its current revision; refusing jj edit')
        if head != revision:
            subprocess.run(['jj', 'edit', revision], cwd=PREFIX, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        require(stage_runner.tracked_audit(revision)['pass'], 'Edited prefix does not match its pinned tree')
        try:
            for unit in selected_units:
                name, argv = unit[0]
                if len(unit) == 1:
                    folder, reused, code = invoke_stage(args.prefix, name, argv, revision, completed)
                    require(code == 0, f'Stage failed: {folder}; see output.log and driver log')
                    continue
                run_name, run_argv = unit[1]
                require(audit.selection_argv(argv) == audit.selection_argv(run_argv), f'List/run selection differs: {run_name}')
                listed_folder, _, code = invoke_stage(args.prefix, name, argv, revision, completed)
                require(code == 0, f'Listing failed: {listed_folder}')
                requirements = plan['list_requirements'][f'{args.prefix}/{run_name}']
                selected = selected_listing(listed_folder, run_argv, requirements, audit)
                print(f'LIST {key} {run_name}: {len(selected)} selected', flush=True)
                run_folder, reused, code = invoke_stage(args.prefix, run_name, run_argv, revision, completed)
                if not reused:
                    # Always retain the test audit, even if the test command failed.
                    checked = subprocess.run([sys.executable, str(BASE / 'audit-nextest-stage.py'), key, run_name],
                                             stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
                    require(checked.returncode == 0 and code == 0, f'Test run/audit failed: {run_folder}; inspect audit.json and output.log')
                saved = validate_saved_audit(run_folder, revision, run_argv, selected)
                print(f'PASS {key} {run_name}: {saved["unique_outcomes"]} unique tests', flush=True)
            summary['status'] = 'PASS'
        except Exception as exc:
            summary.update(status='FAIL', error=str(exc))
            raise
        finally:
            summary['completed_utc'] = datetime.now(timezone.utc).isoformat()
            output = BASE / (key + '-results') / ('executor-' + datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%f') + '.json')
            with output.open('x') as stream:
                stream.write(json.dumps(summary, indent=2) + '\n')
            print(f'{summary["status"]} {key}: {len(completed)} stages; {output}', flush=True)


if __name__ == '__main__':
    try:
        main()
    except (RuntimeError, OSError, KeyError, ValueError, subprocess.CalledProcessError) as exc:
        print(f'STOP: {exc}', file=sys.stderr)
        sys.exit(1)

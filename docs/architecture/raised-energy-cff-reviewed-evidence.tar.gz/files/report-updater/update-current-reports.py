#!/usr/bin/env python3
"""Generate scratch-only current source mapping and validation reports.

Only reads named receipts and immutable Git objects. Never invokes jj, Cargo,
Typst, a licensed environment wrapper, or any command from a receipt.
"""
import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import shlex
import subprocess
import sys

DEFAULT_BASE = Path('/tmp/raised-stack-latest-review-20260914')
DEFAULT_REPO = Path('/common/dev/gammaloop/higher-power-energies-review')
PURPOSES = [
    'Symbolic/tensor foundations and graph bookkeeping',
    'Exact shared generalized CFF generation',
    'GammaLoop adapters, local UV reconstruction and evaluator preparation',
    'Command, persistence, evaluation and benchmark workflows',
    'Physical phases and model sewing',
    'D-dimensional integrated UV algebra and analytic scalar-product protection',
    'Canonical UV algebra, bounded occurrence allocation and graph-owned reuse',
    'Current reports, source attribution and validation evidence',
]
FIXED_INPUTS = [
    'corrected-stack.json', 'incoming-diff-coverage.json', 'checkpoint.json',
    'duplicates.json', 'squash-tree-preservation.json', 'review-fixes.json',
    'independent-corrections-review.json', 'bulk-sum-public-builder-fix-review.json',
    'docs-edits-receipt.json', 'prefix-validation-plan.executable.json', 'c1-format-fix.patch',
    'report-updater/original-source-mapping.md', 'report-updater/original-source-provenance.json',
    'report-updater/reconciled-stack-proof.json', 'report-updater/reconciliation-followups.json',
]


def sha(data):
    return hashlib.sha256(data).hexdigest()


def stable_bytes(path):
    if path.is_symlink() or any(parent.is_symlink() for parent in path.parents):
        raise ValueError(f'Symlink path not read: {path}')
    before = path.stat()
    data = path.read_bytes()
    after = path.stat()
    if (before.st_size, before.st_mtime_ns, before.st_ino) != (after.st_size, after.st_mtime_ns, after.st_ino):
        raise ValueError(f'Changed during read: {path}')
    return data


def json_read(path):
    return json.loads(stable_bytes(path))


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')


def git(repo, *argv):
    return subprocess.check_output(['git', '-C', str(repo), *argv])


def tree_entries(repo, revision):
    records = {}
    for entry in git(repo, 'ls-tree', '-r', '-l', '-z', revision).split(b'\0'):
        if not entry:
            continue
        metadata, path = entry.split(b'\t', 1)
        mode, kind, object_id, size = metadata.decode().split()
        records[path.decode()] = {'mode': mode, 'kind': kind, 'git_blob': object_id, 'bytes': None if size == '-' else int(size)}
    return records


def cell(value):
    return str(value).replace('|', '\\|').replace('\n', ' ')


def cargo_args(receipt):
    argv = receipt.get('argv', [])
    try:
        return argv[argv.index('cargo'):]
    except ValueError:
        return []


def canonical_stage(stage):
    return re.sub(r'-v\d+(?=-list$|$)', '', stage)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--base', type=Path, default=DEFAULT_BASE)
    parser.add_argument('--repo', type=Path, default=DEFAULT_REPO)
    parser.add_argument('--out', type=Path)
    parser.add_argument('--require-complete', action='store_true')
    parser.add_argument('--closure', type=Path, help='Optional parent-reviewed final-document equivalence certificate')
    parser.add_argument('--review-followup', type=Path, action='append', default=[], help='Additional explicit file/revision/file_sha256/status review receipt')
    args = parser.parse_args()
    base, repo = args.base.resolve(), args.repo.resolve()
    out = (args.out or base / 'report-updater' / 'drafts').resolve()
    if out == repo or repo in out.parents:
        parser.error('Output must remain outside the repository; copy reviewed drafts manually.')
    out.mkdir(parents=True, exist_ok=True)
    source_hashes = {name: sha(stable_bytes(base / name)) for name in FIXED_INPUTS}
    inputs = {name: json_read(base / name) for name in FIXED_INPUTS if name.endswith('.json')}
    corrected = inputs['corrected-stack.json']
    coverage = inputs['incoming-diff-coverage.json']
    corrections = inputs['independent-corrections-review.json']
    plan = inputs['prefix-validation-plan.executable.json']
    prefixes = plan.get('prefixes', [])
    if sorted(row.get('prefix') for row in prefixes) != list(range(1, 9)):
        raise ValueError('Validation plan must contain each prefix 1..8 exactly once')
    for prefix in prefixes:
        stages = prefix.get('stages', [])
        named = dict(stages)
        if (len(named) != len(stages) or len({canonical_stage(name) for name in named}) != len(named)
                or not {'fmt', 'check', 'build', 'clippy'} <= named.keys()):
            raise ValueError(f'Incomplete or duplicate gate stages in C{prefix["prefix"]}')
        runs = [(name, argv) for name, argv in stages if argv[:3] == ['cargo', 'nextest', 'run']]
        if not runs or any(name+'-list' not in named or named[name+'-list'][:3] != ['cargo', 'nextest', 'list'] for name, _ in runs):
            raise ValueError(f'C{prefix["prefix"]} needs runtime selections with paired listings')
    old_provenance = inputs['report-updater/original-source-provenance.json']
    original_md = stable_bytes(base / 'report-updater/original-source-mapping.md').decode()
    revisions = corrected['commits']
    if len(revisions) != 8:
        raise ValueError('Expected eight pinned commits')
    issues = []
    commit_rows, trees, changes = [], {}, {}
    for index, record in enumerate(revisions, 1):
        fields = git(repo, 'show', '-s', '--format=%H%x00%P%x00%T%x00%an%x00%ae%x00%s', record['commit']).decode().strip().split('\0')
        commit, parents, tree, author, email, description = fields
        expected_parent = revisions[index - 2]['commit'] if index > 1 else old_provenance['original_main']['commit']
        if tree != record['tree'] or (expected_parent and parents != expected_parent):
            issues.append(f'C{index}: recorded tree/linear ancestry mismatch')
        if (author, email) != ('Lucien Huber', 'im@lcnbr.ch'):
            issues.append(f'C{index}: requested author differs')
        before = tree_entries(repo, parents)
        after = tree_entries(repo, commit)
        trees[commit] = after
        paths = sorted(path for path in before.keys() | after.keys() if before.get(path) != after.get(path))
        changes[f'C{index}'] = {path: {'before': before.get(path), 'after': after.get(path)} for path in paths}
        commit_rows.append({**record, 'owner': f'C{index}', 'parents': parents.split(), 'author': f'{author} <{email}>', 'description': description, 'purpose': PURPOSES[index-1], 'changed_paths': len(paths)})
    final_revision = revisions[-1]['commit']
    final_tree = revisions[-1]['tree']
    initial_proof = inputs['report-updater/reconciled-stack-proof.json']
    proof_chain = [initial_proof]
    checkpoint_review_paths = []
    for checkpoint in inputs['report-updater/reconciliation-followups.json']['checkpoints']:
        previous = proof_chain[-1]
        if (checkpoint['previous_corrected_source_revision'] != previous['corrected_source_revision']
                or checkpoint['previous_reconciled_revision'] != previous['reconciled_revision']
                or checkpoint['stable_c8_change_id'] != previous['stable_c8_change_id']):
            raise ValueError('Source followup does not extend the exact previous reconciliation checkpoint')
        before = tree_entries(repo, previous['corrected_source_revision'])
        after = tree_entries(repo, checkpoint['corrected_source_revision'])
        changed = sorted(path for path in before.keys() | after.keys() if before.get(path) != after.get(path))
        if sorted(row['path'] for row in checkpoint['changes']) != changed:
            raise ValueError('Source followup does not enumerate the exact corrected-source Git delta')
        reviews = []
        for receipt in checkpoint['review_receipts']:
            review_path = base / receipt['path']
            if (review_path.resolve() != review_path or base not in review_path.parents
                    or review_path.suffix != '.json'):
                raise ValueError('Unexpected checkpoint review path')
            review_bytes = stable_bytes(review_path)
            if sha(review_bytes) != receipt['sha256']:
                raise ValueError('Checkpoint review fingerprint changed')
            review = json.loads(review_bytes)
            if review.get('status') != 'PASS' or review.get('revision') not in {checkpoint['corrected_source_revision'], checkpoint['reconciled_revision']}:
                raise ValueError('Checkpoint review does not certify the new source snapshot')
            source_hashes[receipt['path']] = receipt['sha256']
            checkpoint_review_paths.append(review_path)
            reviews.append(review)
        for change in checkpoint['changes']:
            path = change['path']
            observed_diff = git(repo, 'diff', '--no-ext-diff', '--unified=0', previous['corrected_source_revision'], checkpoint['corrected_source_revision'], '--', path)
            blob = after.get(path, {}).get('git_blob')
            if (change['before'] != before.get(path) or change['after'] != after.get(path)
                    or change['diff_sha256'] != sha(observed_diff) or not blob
                    or change['file_sha256'] != sha(git(repo, 'cat-file', 'blob', blob))
                    or not any(review.get('file') == path and review.get('file_sha256') == change['file_sha256'] for review in reviews)):
                raise ValueError('Reviewed source followup differs from exact immutable file/diff fingerprints: '+path)
        proof_chain.append(checkpoint)
    for checkpoint in proof_chain:
        source_tree = git(repo, 'rev-parse', checkpoint['corrected_source_revision'] + '^{tree}').decode().strip()
        target_tree = git(repo, 'rev-parse', checkpoint['reconciled_revision'] + '^{tree}').decode().strip()
        if source_tree != target_tree or source_tree != checkpoint['tree']:
            raise ValueError('Immutable reconciliation checkpoint does not match its pinned equal trees')
    split_proof = proof_chain[-1]
    exact_tree = split_proof['tree']
    split_preserved = True
    if split_proof['stable_c8_change_id'] != revisions[-1]['change_id']:
        raise ValueError('Current C8 stable change differs from reconciliation proof')
    reconciled_delta = sorted(path for path in git(repo, 'diff', '--name-only', '-z', split_proof['reconciled_revision'], final_revision).decode().split('\0') if path)
    closure_path = (args.closure or base / 'final-document-closure.json').resolve()
    closure = None
    if closure_path.exists():
        closure_bytes = stable_bytes(closure_path)
        closure = json.loads(closure_bytes)
        expected_fields = (closure.get('status') == 'PASS'
                           and closure.get('final_revision') == final_revision
                           and closure.get('reconciled_revision') == split_proof['reconciled_revision']
                           and closure.get('stable_change_id') == revisions[-1]['change_id']
                           and closure.get('identical_production_build_test_config') is True)
        actual_changes = sorted(path for path in git(repo, 'diff', '--name-only', '-z', closure['tested_revision'], final_revision).decode().split('\0') if path)
        for allowed_key, actual_delta in [('allowed_changed_paths', actual_changes), ('reconciled_allowed_changed_paths', reconciled_delta)]:
            allowed = closure.get(allowed_key, [])
            document_paths = all(path.startswith('docs/architecture/')
                                 and path.endswith(('.md', '.typ', '.pdf', '.json', '.tar.gz')) for path in allowed)
            if not expected_fields or sorted(allowed) != actual_delta or len(allowed) != len(set(allowed)) or not document_paths:
                raise ValueError(f'Final-document certificate does not match exact reviewed Git delta: {allowed_key}')
        reviewed_paths = set(actual_changes) | set(reconciled_delta)
        if (closure.get('document_review_status') != 'PASS' or not closure.get('document_reviewer')
                or set(closure.get('reviewed_document_sha256', {})) != reviewed_paths):
            raise ValueError('Final-document certificate needs explicit review fingerprints for both exact deltas')
        closure = {**closure, 'path': str(closure_path), 'sha256': sha(closure_bytes), 'git_delta_verified': True, 'reconciled_git_delta_verified': True}
    elif reconciled_delta:
        issues.append('Final top differs from immutable pre-document C8 without an exact reviewed document-closure certificate')
    incoming_tree = tree_entries(repo, coverage['incoming'])
    base_tree = tree_entries(repo, coverage['base'])
    final_files = trees[final_revision]

    original_rows = []
    originals = {row['commit'][:8]: row for row in old_provenance['original_commits']}
    for line in original_md.splitlines():
        if not re.match(r'^\| \d+ \| `', line):
            continue
        columns = [value.strip() for value in line.strip('|').split('|')]
        if len(columns) != 6 or columns[2] not in {'remote', 'review'}:
            continue
        number, short, kind, description, old_owners, disposition = columns
        source = originals[short.strip('`')]
        observed_tree = git(repo, 'rev-parse', source['commit'] + '^{tree}').decode().strip()
        if observed_tree != source['tree']:
            issues.append(f'Original source tree differs: {source["commit"]}')
        old_numbers = [int(x) for x in re.findall(r'\d+', old_owners)]
        new_numbers = [8 if owner == 7 else owner for owner in old_numbers]
        original_rows.append({'number': int(number), 'source': source['commit'], 'tree': source['tree'], 'kind': kind, 'description': description, 'original_owners': old_numbers, 'current_owners': new_numbers, 'original_disposition': disposition, 'current_disposition': re.sub(r'(?<!\w)7(?!\w)', '8', disposition), 'original_git_object_preserved': True})
    if (len(original_rows) != 42 or Counter(row['kind'] for row in original_rows) != {'remote': 37, 'review': 5}
            or {row['source'] for row in original_rows} != {row['commit'] for row in old_provenance['original_commits']}
            or {row['number'] for row in original_rows} != set(range(1,43))):
        raise ValueError('Original attribution is not exactly 37 remote plus five review rows')

    incoming_rows = []
    actual_incoming_paths = {path for path in base_tree.keys() | incoming_tree.keys() if base_tree.get(path) != incoming_tree.get(path)}
    if len(coverage['files']) != 68 or {row['path'] for row in coverage['files']} != actual_incoming_paths:
        issues.append('Incoming ledger is not the exact 68-path Git diff')
    for record in coverage['files']:
        path = record['path']
        observed_diff = git(repo, 'diff', '--no-ext-diff', '--unified=0', coverage['base'], coverage['incoming'], '--', path)
        if sha(observed_diff) != record['incoming_diff_sha256']:
            issues.append(f'Incoming reviewed diff fingerprint differs: {path}')
        placement = []
        for owner in record['final_owners']:
            proof = changes[owner].get(path)
            if proof is None:
                issues.append(f'{path}: reviewed owner {owner} no longer touches this path')
            placement.append({'owner': owner, 'change_id': commit_rows[int(owner[1:])-1]['change_id'], 'revision': commit_rows[int(owner[1:])-1]['commit'], 'before_after': proof})
        if record['coverage_status'] != 'covered':
            issues.append(f'Incoming path not reviewed: {path}')
        incoming_rows.append({'path': path, 'kind': record['incoming_kind'], 'base_blob': base_tree.get(path), 'incoming_blob': incoming_tree.get(path), 'observed_final_blob': final_files.get(path), 'reviewed_semantic_owners': record['final_owners'], 'placement_proof': placement, 'reviewers': record['reviewers'], 'incoming_diff_sha256': record['incoming_diff_sha256'], 'hunks': record['hunks'], 'coverage_status': record['coverage_status'], 'semantic_decoding': record['semantic_decoding'], 'changed_by_review': incoming_tree.get(path) != final_files.get(path)})

    reviewed_fixes = {record['path']: record for record in corrections['coverage']}
    doc_fixes = {record['path']: record for record in inputs['docs-edits-receipt.json']['files']}
    last_fix_snapshot = corrections.get('followup', {}).get('snapshot_revision', corrections['corrected_source'])
    last_fix_tree = tree_entries(repo, last_fix_snapshot)
    format_patch = stable_bytes(base/'c1-format-fix.patch').decode()
    format_ids = re.search(r'^index ([0-9a-f]+)\.\.([0-9a-f]+)', format_patch, re.M)
    format_before = git(repo, 'rev-parse', format_ids[1]).decode().strip()
    format_after = git(repo, 'rev-parse', format_ids[2]).decode().strip()
    extra_reviews = {}
    extra_review_sources = []
    if closure and closure.get('reviewed_document_sha256'):
        if closure.get('document_review_status') != 'PASS' or not closure.get('document_reviewer'):
            raise ValueError('Final document fingerprints require an explicit passing review attribution')
        if set(closure['reviewed_document_sha256']) != set(closure['allowed_changed_paths']) | set(closure['reconciled_allowed_changed_paths']):
            raise ValueError('Final document review fingerprints do not cover the exact allowed delta')
        for path, digest in closure['reviewed_document_sha256'].items():
            blob = final_files.get(path, {}).get('git_blob')
            if not blob or sha(git(repo, 'cat-file', 'blob', blob)) != digest:
                raise ValueError(f'Final reviewed document fingerprint differs: {path}')
            doc_fixes[path] = {'owner':'C8', 'after_sha256':digest, 'receipt':str(closure_path), 'review':closure['document_reviewer']}

    for review_path in [*args.review_followup, *checkpoint_review_paths]:
        review_path = review_path.resolve()
        review_bytes = stable_bytes(review_path)
        review = json.loads(review_bytes)
        if review.get('status') != 'PASS' or not re.fullmatch('[0-9a-f]{64}', review.get('file_sha256', '')):
            raise ValueError(f'Additional review lacks a passing file fingerprint: {review_path}')
        extra_reviews[review['file']] = {**review, 'receipt': str(review_path), 'receipt_sha256': sha(review_bytes)}
        extra_review_sources.append(review_path)
    motivation_render_path = base/'motivation-render/visual-inspection.json'
    if motivation_render_path.exists():
        render = json_read(motivation_render_path)
        if (render['findings'] == [] and render['inspected'] == list(range(1,render['pages']+1))
                and render['source_typst_sha256'] == doc_fixes['docs/architecture/raised-energy-cff-motivation-audit.typ']['after_sha256']):
            doc_fixes['docs/architecture/raised-energy-cff-motivation-audit.pdf'] = {
                'owner':'C8', 'after_sha256':render['pdf_sha256'],
                'receipt':'motivation-render/visual-inspection.json', 'review':'Complete parent-owned PDF visual review; source Typst fingerprint matches.'}
    final_corrections = []
    for path in sorted(incoming_tree.keys() | final_files.keys()):
        if incoming_tree.get(path) == final_files.get(path):
            continue
        evidence = []
        if path in reviewed_fixes:
            evidence.append('independent-corrections-review.json:coverage')
        if path in doc_fixes:
            evidence.append(doc_fixes[path].get('receipt', 'docs-edits-receipt.json'))
        if path in corrections.get('followup', {}).get('files_rechecked', []):
            evidence.append('independent-corrections-review.json:followup')
        if path == inputs['bulk-sum-public-builder-fix-review.json']['file']:
            evidence.append('bulk-sum-public-builder-fix-review.json')
        if path == 'crates/linnet/src/tree/child_pointer.rs':
            evidence.append('c1-format-fix.patch; fresh fmt receipts')
        if path in extra_reviews:
            evidence.append(extra_reviews[path]['receipt'])
        if not evidence:
            issues.append(f'Correction lacks review receipt: {path}')
        exact_review_match = False
        final_blob = final_files.get(path, {}).get('git_blob')
        if path in extra_reviews:
            exact_review_match = bool(final_blob) and sha(git(repo, 'cat-file', 'blob', final_blob)) == extra_reviews[path]['file_sha256']
        elif path in doc_fixes:
            exact_review_match = bool(final_blob) and sha(git(repo, 'cat-file', 'blob', final_blob)) == doc_fixes[path]['after_sha256']
        elif path == inputs['bulk-sum-public-builder-fix-review.json']['file']:
            exact_review_match = bool(final_blob) and sha(git(repo, 'cat-file', 'blob', final_blob)) == inputs['bulk-sum-public-builder-fix-review.json']['file_sha256']
        elif path == 'crates/linnet/src/tree/child_pointer.rs':
            exact_review_match = last_fix_tree[path]['git_blob'] == format_before and final_blob == format_after
        elif path in reviewed_fixes:
            exact_review_match = final_files.get(path) == last_fix_tree.get(path)
        if not exact_review_match:
            issues.append(f'Current correction blob lacks exact reviewed fingerprint: {path}')
        owners = [owner for owner, rows in changes.items() if path in rows]
        final_corrections.append({'path': path, 'incoming': incoming_tree.get(path), 'corrected': final_files.get(path), 'prefixes_touching_path': owners, 'semantic_owner': doc_fixes.get(path, {}).get('owner') or reviewed_fixes.get(path, {}).get('ownership'), 'review_evidence': evidence, 'exact_review_fingerprint_match': exact_review_match})

    mapping = {'generated_utc': datetime.now(timezone.utc).isoformat(), 'scope': 'Current observed eight-commit source attribution; original source claims retain their evidence scope', 'commits': commit_rows, 'original_inputs': original_rows, 'incoming_source': coverage['incoming'], 'incoming_base': coverage['base'], 'incoming_coverage': incoming_rows, 'incoming_totals': coverage['totals'], 'corrections': final_corrections, 'corrected_source_revision': split_proof['corrected_source_revision'], 'corrected_tree': exact_tree, 'immutable_pre_document_proof': {**split_proof, 'verified': split_preserved}, 'reconciliation_checkpoints': proof_chain, 'reconciled_to_observed_document_delta': reconciled_delta, 'document_equivalence_certificate': closure, 'observed_top': final_revision, 'observed_top_tree': final_tree, 'split_preservation_verified': split_preserved, 'full_stack_commit_path_records': sum(len(rows) for rows in changes.values()), 'full_stack_distinct_paths': len(set().union(*(set(rows) for rows in changes.values()))), 'prefix_path_blobs': changes, 'issues': issues, 'limits': ['Before/after blobs prove path placement and content, not semantic attribution of each original hunk. Reviewed semantic owners come from the preserved attribution and incoming review ledger.', 'Whole-stack path inventory is separate from the 68-file incoming review coverage; no unperformed fresh full-stack rereview is inferred.', 'C8 revision/tree is an observed snapshot. Copying these drafts changes documentation; the final external closure receipt must identify and verify that later snapshot.']}
    write_json(out / 'raised-energy-cff-stack-current-mapping.json', mapping)

    text = ['# Source-to-commit mapping', '', 'Seven functional commits and one documentation commit retain the original 42 source attributions and integrate the fully reviewed incoming change. Counts below are generated from the pinned Git objects; execution outcomes are recorded separately in the [validation report](raised-energy-cff-stack-review-validation.md).', '', '| Commit | Stable jj change | Observed revision | Responsibility |', '| --- | --- | --- | --- |']
    for row in commit_rows:
        identity = '`' + row['commit'] + '`' if row['owner'] != 'C8' else 'Stable change; executed candidate is recorded in validation'
        text.append(f'| {row["owner"]} | `{row["change_id"]}` | {identity} | {row["purpose"]} |')
    text += ['', 'C8 is identified by its stable jj change. Executed candidate revisions remain in validation receipts. A final documentation revision may reuse those results only through an explicit certificate of identical production/build/test/config content and the exact allowed document delta. Final bookmark and rendered-document closure remain external.', '', f'The immutable pre-document source `{split_proof["corrected_source_revision"]}` and reconciled C8 `{split_proof["reconciled_revision"]}` share tree `{exact_tree}`: **{"verified" if split_preserved else "FAILED"}**. This is the exact split-preservation proof before final reports. Later documentation changes require a separate reviewed delta from this reconciled C8 and from the executed test candidate; the final full tree need not equal this pre-document tree. Untouched input duplication/squashing is recorded separately in `squash-tree-preservation.json`.', '', f'The observed eight boundaries contain **{mapping["full_stack_commit_path_records"]} commit/path records and {mapping["full_stack_distinct_paths"]} distinct paths**. Exact before/after Git blobs appear in `raised-energy-cff-stack-current-mapping.json`. These counts are an inventory, not a fresh review claim for unchanged earlier hunks.', '', '## Original source attribution', '', 'All 37 remote and five review Git objects retain their recorded trees. Their 42 source descriptions and attributions are preserved below, with the former documentation owner 7 mapped to owner 8. The empty remote marker contributes no payload; no empty review intermediary is included.', '', '| # | Source | Kind | Source description | Owners | Functional disposition |', '| --- | --- | --- | --- | --- | --- |']
    proof_rows = ['The preserved reconciliation chain retains each immutable source/tree pair and its explicitly reviewed source followup.', '', '| Checkpoint | Corrected source | Reconciled C8 | Equal tree |', '| --- | --- | --- | --- |']
    for index, checkpoint in enumerate(proof_chain, 1):
        proof_rows.append('| '+ ' | '.join([str(index), '`'+checkpoint['corrected_source_revision']+'`', '`'+checkpoint['reconciled_revision']+'`', '`'+checkpoint['tree']+'`'])+' |')
    insert_at = text.index('## Original source attribution')
    text[insert_at:insert_at] = proof_rows + ['']
    for row in original_rows:
        owners = ', '.join(map(str,row['current_owners'])) or 'none (empty)'
        text.append('| ' + ' | '.join(map(cell,[row['number'], '`'+row['source'][:8]+'`', row['kind'], row['description'], owners, row['current_disposition']])) + ' |')
    text += ['', '## Incoming review coverage', '', f'Incoming `{coverage["incoming"]}` is reviewed against `{coverage["base"]}`: **{len(incoming_rows)} paths**, including {coverage["totals"]["text_paths"]} text and {coverage["totals"]["binary_paths"]} binary artifacts. The retained ledger records {coverage["totals"]["hunks"]} text hunks, {coverage["totals"]["added_lines"]} added lines and {coverage["totals"]["deleted_lines"]} deleted lines. The three serialized Symbolica blobs have byte/hash and source-provenance review; their contents were not semantically decoded. Bounded reviewer attribution is explicit; filename overlap alone does not assign functionality.', '', '| Path | Reviewed owners | Reviewer(s) | Review correction |', '| --- | --- | --- | --- |']
    for row in incoming_rows:
        text.append('| '+ ' | '.join(map(cell,[f'`{row["path"]}`', ', '.join(row['reviewed_semantic_owners']), ', '.join(x['reviewer'] for x in row['reviewers']), 'yes' if row['changed_by_review'] else 'no']))+' |')
    text += ['', '## Deliberate review corrections', '', f'The current incoming-to-corrected delta contains **{len(final_corrections)} files**. Independent review covers the 15 production/test correction files, followed by complete public node-set checks, C1 formatting and public sum-fixture construction, plus current documentation sources and any separately verified rendered artifact. Initial formatting and compiler failures remain in the validation attempt ledger. Test oracles are preserved or strengthened; complete values replace incidental cache/class/order assertions.', '', '| Path | Semantic owner | Review receipt |', '| --- | --- | --- |']
    for row in final_corrections:
        text.append('| '+' | '.join(map(cell,[f'`{row["path"]}`', row['semantic_owner'], '; '.join(row['review_evidence'])]))+' |')
    text += ['', 'C1 owns shared tensor/graph prerequisites; C2 the shared CFF engine; C3 adapters/evaluators; C4 workflows; C5 phases; C6 integrated algebra; C7 canonical UV optimization; C8 reports. Required signatures, consumers and tests remain with the compiling owner. Source-pinned benchmark artifacts retain their own scope; manual PySecDec and unresolved GL262 evaluator diagnostics do not become current acceptance through attribution.', '']
    if issues:
        text += ['## Unresolved provenance checks', ''] + ['- '+issue for issue in issues] + ['']
    (out/'raised-energy-cff-stack-source-mapping.md').write_text('\n'.join(text))

    attempts = []
    tracked_expectations = {}
    for folder in sorted(base.glob('*-results')):
        if not folder.is_dir() or not re.fullmatch(r'(?:c[1-8]|latest|final|mre)-results', folder.name):
            continue
        for stage_dir in sorted(folder.iterdir()):
            if not stage_dir.is_dir() or stage_dir.name == 'states':
                continue
            result_path = stage_dir/'result.json'
            command_path = stage_dir/'command.json'
            if not result_path.exists() and not command_path.exists():
                continue
            receipt_path = result_path if result_path.exists() else command_path
            receipt_bytes = stable_bytes(receipt_path)
            record = json.loads(receipt_bytes)
            row = {'path': str(receipt_path.relative_to(base)), 'sha256': sha(receipt_bytes), 'branch': record['branch'], 'stage': record['stage'], 'canonical_stage': canonical_stage(record['stage']), 'revision': record['revision'], 'started_utc': record['started_utc'], 'completed_utc': record.get('completed_utc'), 'elapsed_seconds': record.get('elapsed_seconds'), 'argv': record['argv'], 'cargo_argv': cargo_args(record), 'overrides': record.get('overrides',{}), 'integrity_pass': record.get('integrity_pass'), 'exit_code': record.get('exit_code'), 'status': 'RUNNING' if not result_path.exists() else ('PASS' if record.get('exit_code') == 0 and record.get('integrity_pass') is True else 'FAIL'), 'audit': None}
            if result_path.exists() and (not record.get('completed_utc')
                    or not isinstance(record.get('elapsed_seconds'), (int, float))
                    or record.get('elapsed_seconds', -1) < 0 or record.get('execution_skipped', False)
                    or record.get('head_after') != row['revision']
                    or not re.fullmatch('[0-9a-f]{64}', record.get('source_sha256') or '')
                    or record.get('source_sha256') != record.get('source_sha256_after')):
                row['status'] = 'FAIL'
            row['tracked_before'] = record.get('tracked_before')
            row['tracked_after'] = record.get('tracked_after')
            row['execution_skipped'] = record.get('execution_skipped', False)
            row['integrity_scope'] = record.get('integrity_scope', 'HEAD and crates/spenso/src/network/mod.rs SHA-256 only')
            if result_path.exists() and ('tracked_before' in record or 'tracked_after' in record):
                if row['revision'] not in tracked_expectations:
                    raw_tree = git(repo, 'ls-tree', '-rz', row['revision'])
                    tracked_expectations[row['revision']] = (sha(raw_tree), len(raw_tree.split(b'\0')) - 1)
                expected_digest, expected_count = tracked_expectations[row['revision']]
                for phase in ['tracked_before', 'tracked_after']:
                    tracked = record.get(phase) or {}
                    if (tracked.get('pass') is not True or tracked.get('revision') != row['revision']
                            or tracked.get('expected_path_count') != tracked.get('checked_path_count')
                            or tracked.get('expected_tree_records_sha256') != tracked.get('actual_tree_records_sha256')
                            or tracked.get('expected_tree_records_sha256') != expected_digest
                            or tracked.get('expected_path_count') != expected_count
                            or tracked.get('mismatch_count') != 0):
                        row['status'] = 'FAIL'
            audit_path = stage_dir/'audit.json'
            if audit_path.exists():
                audit_bytes = stable_bytes(audit_path)
                audit = json.loads(audit_bytes)
                audit_errors = list(audit.get('errors', []))
                if audit.get('revision') != row['revision']:
                    audit_errors.append('Audit/result revision differs')
                matching_result = [item for item in audit.get('sources',[]) if item.get('path') == str(result_path)]
                if len(matching_result) != 1 or matching_result[0]['sha256'] != row['sha256']:
                    audit_errors.append('Audit/result fingerprint differs or is absent')
                list_folder = stage_dir.parent / (stage_dir.name + '-list')
                required_sources = {str(result_path), str(stage_dir/'output.log'),
                                    str(list_folder/'result.json'), str(list_folder/'output.log')}
                source_paths = [item['path'] for item in audit.get('sources', [])]
                if not required_sources <= set(source_paths) or len(source_paths) != len(set(source_paths)):
                    audit_errors.append('Incomplete or duplicate list/run evidence sources')
                if (list_folder/'result.json').exists():
                    listed = json_read(list_folder/'result.json')
                    if (listed.get('exit_code') != 0 or listed.get('integrity_pass') is not True
                            or listed.get('revision') != row['revision']
                            or listed.get('source_sha256') != record.get('source_sha256')
                            or audit.get('list_argv') != cargo_args(listed)):
                        audit_errors.append('Listing/result identity or command differs')
                else:
                    audit_errors.append('Paired listing receipt is missing')
                for source in audit.get('sources', []):
                    source_path = Path(source['path'])
                    if source_path == base / 'validation-pins.json':
                        # This mutable dispatch file is not a source snapshot.
                        # The exact result revision is checked against corrected-stack below.
                        continue
                    if (not source_path.is_absolute() or base not in source_path.parents
                            or source_path.is_symlink() or any(parent.is_symlink() for parent in source_path.parents)
                            or source_path.resolve() != source_path or source_path.name not in {'result.json', 'output.log'}):
                        audit_errors.append('Unexpected audit source path; not read')
                        continue
                    if not source_path.exists() or sha(stable_bytes(source_path)) != source['sha256']:
                        audit_errors.append('Audit source fingerprint differs: ' + str(source_path.relative_to(base)))
                if audit.get('run_argv') != row['cargo_argv']:
                    audit_errors.append('Audit command differs from result command')
                selected = {tuple(value) for value in audit.get('selected_identities',[])}
                outcomes = {(value['binary_id'], value['test_name']) for value in audit.get('cases',[])}
                if not selected or selected != outcomes:
                    audit_errors.append('Selected and executed identities differ or are empty')
                cases = audit.get('cases', [])
                summary = audit.get('summary_counts', {})
                if (audit.get('selected_count') != len(selected) or len(cases) != len(selected)
                        or summary.get('passed') != len(selected) or summary.get('failed') != 0
                        or any(case.get('status') != 'PASS' for case in cases)):
                    audit_errors.append('Audit counts or PASS outcomes disagree')
                if summary.get('skipped') != audit.get('excluded_count'):
                    audit_errors.append('Audit excluded count disagrees')
                hashed_binaries = {item['binary_id'] for item in audit.get('binary_hashes', [])
                                   if re.fullmatch('[0-9a-f]{64}', item.get('sha256', ''))}
                if hashed_binaries != {identity[0] for identity in selected}:
                    audit_errors.append('Selected binary hash coverage is incomplete')
                row['audit'] = {'list_argv': audit.get('list_argv'), 'path': str(audit_path.relative_to(base)), 'sha256': sha(audit_bytes), 'status': audit.get('status'), 'errors': audit_errors, 'selected_count': audit.get('selected_count'), 'excluded_count': audit.get('excluded_count'), 'summary_counts': audit.get('summary_counts', {}), 'status_counts': audit.get('status_counts',{}), 'cases': audit.get('cases',[]), 'selected_identity_sha256': audit.get('selected_identity_sha256'), 'binary_hashes': audit.get('binary_hashes',[]), 'normalization_correction': audit.get('normalization_correction')}
            attempts.append(row)
    chosen_paths, gates = set(), []
    for prefix in plan['prefixes']:
        owner = f'C{prefix["prefix"]}'
        pinned = revisions[prefix['prefix']-1]['commit']
        for stage, command in prefix['stages']:
            reusable_revision = (closure['tested_revision'] if closure and owner == 'C8'
                                 and stage in closure.get('reusable_stages', []) else None)
            matching = [row for row in attempts if row['branch'] == owner.lower() and row['canonical_stage'] == canonical_stage(stage)
                        and row['revision'] in {pinned, reusable_revision} and row['cargo_argv'] == command]
            chosen = max(matching,key=lambda row:row['started_utc']) if matching else None
            state = chosen['status'] if chosen else 'PENDING'
            if chosen:
                chosen_paths.add(chosen['path'])
                if command[:3] == ['cargo','nextest','run'] and state == 'PASS':
                    audit = chosen['audit']
                    requirement = plan.get('list_requirements', {}).get(f'{prefix["prefix"]}/{stage}', {})
                    required_names = set(requirement.get('expected_exact_names', []))
                    observed_names = {case['test_name'] for case in audit['cases']} if audit else set()
                    required_prefixes = requirement.get('required_name_prefixes', [])
                    if (not audit or audit['status'] != 'PASS' or audit['errors']
                            or audit['selected_count'] < requirement.get('minimum_selected', 1)
                            or not required_names <= observed_names
                            or not all(any(name.startswith(prefix) for name in observed_names) for prefix in required_prefixes)
                            or audit['list_argv'] != dict(prefix['stages'])[stage+'-list']):
                        state = 'UNVERIFIED'
            gates.append({'owner':owner,'stage':stage,'revision':pinned,'planned_argv':command,'status':state,'executed_revision':chosen['revision'] if chosen else None,'document_reuse_certificate':closure['sha256'] if chosen and chosen['revision'] != pinned and closure else None,'receipt':chosen})
    nonfinal = [row for row in attempts if row['path'] not in chosen_paths]
    final_tests = [row for row in gates if row['owner'] == 'C8' and row['planned_argv'][:3] == ['cargo','nextest','run']]
    accepted_tests = [row for row in final_tests if row['status'] == 'PASS']
    totals = Counter()
    identities = set()
    for gate in accepted_tests:
        audit = gate['receipt']['audit']
        totals.update(audit['summary_counts'])
        identities.update((case['binary_id'],case['test_name']) for case in audit['cases'])
    complete = not issues and all(row['status'] == 'PASS' for row in gates)
    validation = {'generated_utc':datetime.now(timezone.utc).isoformat(),'status':'COMPLETE' if complete else 'INCOMPLETE','pins':commit_rows,'gates':gates,'all_attempts':attempts,'nonfinal_attempt_paths':[row['path'] for row in nonfinal],'final_runtime':{'passing_selections':len(accepted_tests),'planned_selections':len(final_tests),'executions':sum(gate['receipt']['audit']['selected_count'] for gate in accepted_tests),'unique_binary_test_identities':len(identities),'summary_counts_across_passing_configurations':dict(totals),'scope':'Only audited, exact-command C8 selections at the final target or an explicitly certified equivalent tested candidate. Executed revisions/hashes remain unchanged and each reused receipt is counted once; baseline and earlier prefix counts excluded. Skipped counts are per configuration and may overlap.'},'provenance_issues':issues,'document_equivalence_certificate':closure,'source_inputs_sha256':source_hashes,'integrity_scope':'New receipts record complete pinned tracked-file Git blobs, symlink target bytes and executable modes in tracked_before/after, plus HEAD and the Spenso source fingerprint. Earlier receipts without those fields check only HEAD and crates/spenso/src/network/mod.rs; they retain that narrower scope. The report does not upgrade old guards or claim to inspect untracked files. Selected binary hashes are separate evidence.'}
    tools_path = base / 'tool-versions.json'
    tool_versions = json_read(tools_path) if tools_path.exists() else {}
    render_path = base / 'motivation-render/visual-inspection.json'
    rendering = json_read(render_path) if render_path.exists() else None
    validation['tool_versions'] = tool_versions
    validation['motivation_rendering'] = rendering
    write_json(out/'raised-energy-cff-stack-current-validation.json',validation)
    text=['# Reconstructed-stack validation', '', f'Current generated status: **{validation["status"]}**. Completed commands must match the exact planned argument vector and source revision. Reuse from a tested C8 candidate requires an explicit verified document-equivalence certificate; executed revisions and counts are never relabelled. The latest matching attempt determines its status; an earlier passing attempt cannot hide a later failure. Unfinished, unaudited and stale-source receipts remain explicit.', '', '| Commit | Format | Check | All-target build | Clippy | Other planned stages |', '| --- | --- | --- | --- | --- | --- |']
    for owner in [f'C{i}' for i in range(1,9)]:
        owned=[row for row in gates if row['owner']==owner]
        statuses={row['stage']:row['status'] for row in owned}
        other=Counter(row['status'] for row in owned if row['stage'] not in {'fmt','check','build','clippy'})
        text.append('| '+' | '.join([owner]+[statuses.get(stage,'PENDING') for stage in ['fmt','check','build','clippy']]+[', '.join(f'{count} {status.lower()}' for status,count in sorted(other.items()))])+' |')
    text += ['', f'The final runtime currently has {len(accepted_tests)}/{len(final_tests)} audited passing selections: {validation["final_runtime"]["executions"]} executions and {len(identities)} distinct binary/test identities. These are partial collector values until every final selection completes. They exclude the immutable incoming baseline and owning-prefix runs; no imported or earlier-prefix suite total is added.', '', '## Final runtime selections', '', '| Selection | Status | Selected / passed | Excluded | Receipt |', '| --- | --- | --- | --- | --- |']
    for row in final_tests:
        receipt=row['receipt']; audit=receipt and receipt['audit']
        counts=f'{audit["selected_count"]} / {audit["summary_counts"].get("passed",0)}' if audit else 'not audited'
        text.append('| '+' | '.join(map(cell,[row['stage'],row['status'],counts,audit['excluded_count'] if audit else '—',receipt['path'] if receipt else 'not run']))+' |')
    text += ['', '## Current boundary receipts', '', '| Boundary / stage | Status | Executed revision / final document target | Seconds | Receipt |', '| --- | --- | --- | --- | --- |']
    for row in gates:
        receipt=row['receipt']
        seconds=f'{receipt["elapsed_seconds"]:.3f}' if receipt and receipt['elapsed_seconds'] is not None else '—'
        text.append('| '+' | '.join(map(cell,[row['owner']+'/'+row['stage'],row['status'],('`'+row['executed_revision'][:12]+'` → docs `'+row['revision'][:12]+'`' if row['document_reuse_certificate'] else '`'+row['revision'][:12]+'`'),seconds,receipt['path'] if receipt else 'not run']))+' |')
    text += ['', '## Other completed or interrupted attempts', '', 'These receipts remain evidence of actual work. Their source or command differs from the final gate, or they belong to the immutable incoming baseline. They contribute no current-boundary passing count. A failed listing runs no test selection; compiler failures are not failing behavioral assertions.', '', '| Attempt | Revision | Exit / status | Seconds | Scope or disposition |', '| --- | --- | --- | --- | --- |']
    known={('c3','clippy'):'Existing SoftMomentumAssignment alias moved into C3 and nested test conditional collapsed; Clippy diagnostics, no changed expected values or runtime assertion failure.',('c1','fmt'):'Initial Linnet formatting mismatch; corrected at the owning C1 boundary.',('c1','check'):'E0624 in new sum fixtures: use existing public graph builder; production helper stays private and expected values stay unchanged.',('latest','affected-tests-list'):'All-target nextest listing required unavailable gungraun-runner; corrected list/run target selection, retaining all targets for build/check/Clippy.'}
    for row in nonfinal:
        reason=known.get((row['branch'],row['stage']),'Immutable incoming baseline' if row['branch']=='latest' else 'Different revision/arguments or superseded attempt; retained separately')
        if row['stage'].startswith('mre-'):
            reason = ('Standalone import diagnostic; expected assertion exit 101, separately source-scoped in raised-energy-cff-mre-validation.md' if row['stage']=='mre-import-read' else 'Standalone MRE build/control evidence; excluded from workspace totals, see raised-energy-cff-mre-validation.md')
        text.append('| '+' | '.join(map(cell,[row['branch']+'/'+row['stage'],'`'+row['revision'][:12]+'`',str(row['exit_code'])+' / '+row['status'],f'{row["elapsed_seconds"]:.3f}' if row['elapsed_seconds'] is not None else '—',reason]))+' |')
    text += ['', '## Execution controls and limits', '', 'The recorded commands use the licensed environment by invocation only. The report generator never reads it or executes commands from receipts. Recorded settings include a 30 GB process-tree guard, four Cargo/nextest/Rayon workers, disabled retries and snapshot updates, and `GL_NO_HARD_WARNINGS=1`; individual argument vectors and overrides remain authoritative. Clippy uses its separately recorded warning policy. Timing runs with different controls retain their own scope.', '', validation['integrity_scope'], '', 'Nextest counts require an audit matching the result fingerprint, revision, selected identities and actual outcomes. Selected binary hashes belong to their original audit time; later builds do not refresh that evidence. Changes to selection normalization are retained in the audit correction receipt. Listing and test commands are distinct executed operations.', '', 'Manual PySecDec integrations remain outside automatic selections. GL262 has a source-pinned Symbolica evaluator-construction panic and incomplete paired performance evidence. The planned physical-route selection names GL00 and GL01; it does not certify GL262. A standalone nonsymmetric function import MRE is a separate defect. No incomplete diagnostic, skipped test or guard termination is counted as passing.', '', 'Source-pinned physical performance and older benchmark/CI totals are separate evidence. The C8 source identity is an observed snapshot; copying reports and rendering PDFs requires a final documentation/closure receipt. This generator does not certify PDF compilation or visual inspection.', '', '## Executed command appendix', '', 'Each block below is an actual receipt argument vector, rendered with shell quoting for review; it is not executed by this generator. Receipt JSON retains exact argument and environment arrays.', '']
    if tool_versions:
        text += ['Tool versions: ' + '; '.join(f'{key}: {value["output"].splitlines()[0]}' for key,value in tool_versions.items()) + '.', '']
    if rendering:
        text += [f'Motivation PDF: {rendering["pages"]} pages, inspection covers pages {rendering["inspected"]}; findings {rendering["findings"]}. PDF SHA-256 `{rendering["pdf_sha256"]}`, Typst SHA-256 `{rendering["source_typst_sha256"]}`. Evidence: `motivation-render/receipt.json` and `motivation-render/visual-inspection.json`. This is the parent reviewer’s recorded inspection, not a rerender by this updater.', '']
    for row in attempts:
        text += [f'### {row["branch"]}/{row["stage"]}', '', f'Revision `{row["revision"]}`; {row["status"]}; receipt `{row["path"]}`; SHA-256 `{row["sha256"]}`.', '', '```sh', shlex.join(row['argv']), '```', '']
    (out/'raised-energy-cff-stack-review-validation.md').write_text('\n'.join(text))

    # Emit an allowlist only; do not package files or follow receipt binary paths.
    candidates = []
    named = FIXED_INPUTS + ['c7-imports-fix.patch','c7-imports-fix-review.md','corrected-stack-before-c7-imports.json','c7-results/mre-validation.json','execute-mre-validation.py','mre-evidence-review.md','mre-evidence-review.json','report-updater/summarize-mre.py','report-updater/drafts/raised-energy-cff-mre-validation.md','report-updater/drafts/raised-energy-cff-mre-validation.json','c3-clippy-fix.patch','top-clippy-fix.patch','corrected-stack-before-c3-clippy.json','report-updater/reconciliation-followup-plan.md','validation-pins.json','review-fixes-final.patch','review-and-doc-fixes.patch','node-population-followup.patch','c1-format-fix.patch','c7-docs-review-fixes.patch','c8-docs-review-fixes.patch','uv-review.md','uv-review.json','cff-review.md','cff-review.json','shared-review.md','shared-review.json','evidence-review.md','evidence-review.json','sunset-independent-contours.json','sunset-independent-contours-audit.json','audit-sunset-contours.py','audit-nextest-stage.py','audit-nextest-stage-selfcheck.json','audit-nextest-stage-no-tests-fix.json','docs-update-plan.md','report-updater/update-current-reports.py','report-updater/original-source-mapping.md','report-updater/original-source-provenance.json','tool-versions.json','motivation-render/receipt.json','motivation-render/visual-inspection.json','motivation-render/0.log','motivation-render/1.log','motivation-render/2.log','motivation-render/3.log','run-stage.py','run-stage-integrity-selfcheck.json','mre-validation-plan.json','report-updater/selfcheck.json','report-updater/selfcheck-updater.py','report-updater/README.md','report-updater/independent-review.md','report-updater/independent-review.json']
    for name in named:
        path=base/name
        if path.is_file():candidates.append(path)
    candidates.extend(extra_review_sources)
    if closure:
        candidates.append(closure_path)
    for row in attempts:
        folder=base/row['path'];folder=folder.parent
        for name in ['command.json','result.json','audit.json','audit-before-no-tests-normalization.json','output.log','memory.jsonl']:
            path=folder/name
            if path.is_file():candidates.append(path)
    candidates.extend(out/name for name in ['raised-energy-cff-stack-source-mapping.md','raised-energy-cff-stack-review-validation.md','raised-energy-cff-stack-current-mapping.json','raised-energy-cff-stack-current-validation.json'])
    allowlist=[]
    for path in sorted(set(candidates)):
        if path.is_symlink() or any(parent.is_symlink() for parent in path.parents) or base not in path.resolve().parents or path.stat().st_size>16*1024*1024 or path.suffix not in {'.json','.jsonl','.md','.py','.patch','.log'}:
            continue
        allowlist.append({'path':str(path.relative_to(base)),'bytes':path.stat().st_size,'review_before_packaging':True})
    write_json(out/'archive-allowlist.json',{'status':'Proposed exact-path allowlist; no archive created and content screening still required','root':str(base),'entries':allowlist,'exclude':['/tmp/raised-stack/run and any licensed environment wrapper','process environment dumps, credentials, license/token files','target executables, shared libraries, saved evaluator/state folders and core dumps','large standalone GL262 binary/state artifacts','commit-description.txt with imported instructions and unrelated history','unbounded glob inclusion or following symlinks'],'limit_bytes_per_file':16*1024*1024,'packaging_requirement':'Review logs and structured records for credentials before packaging; archive only explicitly approved entries. Do not follow binary paths or wrapper references embedded in receipts. Retain a final per-file SHA-256 archive manifest.'})
    for review in extra_reviews.values():
        if sha(stable_bytes(Path(review['receipt']))) != review['receipt_sha256']:
            raise ValueError('Additional review receipt changed during generation')
    if closure and sha(stable_bytes(closure_path)) != closure['sha256']:
        raise ValueError('Document-equivalence certificate changed during generation')
    for name, digest in source_hashes.items():
        if sha(stable_bytes(base/name)) != digest:
            raise ValueError(f'Input changed during report generation: {name}; rerun to obtain a consistent snapshot')
    print(json.dumps({'status':validation['status'],'source_issues':issues,'original_inputs':len(original_rows),'incoming_paths':len(incoming_rows),'correction_paths':len(final_corrections),'observed_top':final_revision,'gates':dict(Counter(row['status'] for row in gates)),'attempts':len(attempts),'output':str(out)},indent=2))
    return 0 if complete or not args.require_complete else 2


if __name__ == '__main__':
    sys.exit(main())

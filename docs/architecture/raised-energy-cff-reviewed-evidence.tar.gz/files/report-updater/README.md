# Current stack report updater

This scratch utility reads immutable Git objects and named validation/review receipts. It writes drafts outside the repository. It does not run jj, builds, application tests, Typst, receipt commands, or the licensed environment wrapper.

Run from any directory:

```sh
/tmp/raised-stack/python /tmp/raised-stack-latest-review-20260914/report-updater/update-current-reports.py \
  --review-followup /tmp/raised-stack-latest-review-20260914/c1-clippy-readability-fix-review.json
```

Add `--require-complete` for the final gate: exit 0 requires every planned boundary stage to pass and no unresolved provenance issue; exit 2 means incomplete. An invalid certificate or malformed input is an error. `--base`, `--repo`, `--out`, and `--closure` are optional overrides. Output inside the repository is refused. Repeat `--review-followup` for additional explicitly passing review receipts with exact `file`, `revision`, and `file_sha256` fields. New document followups belong in the closure certificate described below.

The default `drafts/` directory contains current source mapping and validation Markdown, two detailed JSON ledgers, and `archive-allowlist.json`. Root reviews and copies the relevant drafts into C8; generation alone does not publish them.

## Evidence accounting

The mapping retains all 42 original attributions, verifies the exact 68-path incoming diff and hunk fingerprints, and records current prefix before/after Git blobs. Semantic ownership comes from the review ledger, not filename overlap. Every incoming-to-current correction must match its reviewed immutable blob or a separately supplied exact SHA-256 review receipt. Current source, tested candidate, and final documentation revision are distinct identities.

The collector compares each stage with the exact planned Cargo argument vector and pinned prefix revision. Stage version suffixes identify repeated attempts; the latest matching attempt wins even if it failed. A nextest run requires its paired listing, all four list/run result/output fingerprints, consistent complete selected identities and PASS outcomes, required names/prefixes, and selected binary hash coverage. Missing audits remain UNVERIFIED. Build/check failures, failed listings, older source runs, baseline evidence, unplanned diagnostics, and superseded attempts remain separate from accepted current gates. No old test total is imported.

Full tracked-file guards are checked against immutable Git tree entries when present. Earlier receipts retain their narrower HEAD/single-file guard scope. The generator never upgrades an older receipt's integrity scope. Binary hashes are those recorded by the original nextest audit, not hashes recomputed after another build. A failed or unfinished diagnostic is not a passing test.

Final runtime counts include only audited C8 selections. Configuration executions and distinct binary/test identities are reported separately; overlapping configurations are not represented as distinct tests. GL262 evaluator-construction diagnostics and manual PySecDec integrations remain explicit coverage limits. PDF compilation and complete visual inspection require separate render receipts.

## Immutable split proof and final documentation closure

`reconciled-stack-proof.json` permanently identifies corrected source `d0242b4714a5a6aec54bdb38fcf46b82f26e325a`, reconciled C8 `a1cf5b3f0ee68b065225e6a18a264a333a0006ab`, and their equal tree `c74a276735c3142a6db8cafe1bbd08127a6a7681`. Do not update this proof when publishing reports or applying later review fixes. `reconciliation-followups.json` appends each separately reviewed source/tree pair, preserving the prior corrected-source and reconciled revisions. Every source transition must match exact before/after blobs, diff/file fingerprints and passing immutable review receipts. The latest verified checkpoint becomes the base for final documentation closure; earlier checkpoints remain in the mapping. Boundary-only redistribution is recorded in the associated review receipt. Later documentation changes require their own proof; the final full tree need not equal any earlier pre-document tree.

The default optional certificate is `../final-document-closure.json`. Root produces it after reviewing the exact final documentation delta and final commit. Example schema (replace placeholders and enumerate exact paths/stages):

```json
{
  "status": "PASS",
  "tested_revision": "FULL_EXECUTED_C8_COMMIT",
  "reconciled_revision": "LATEST_VERIFIED_RECONCILED_C8_COMMIT",
  "final_revision": "FULL_FINAL_C8_COMMIT",
  "stable_change_id": "oxsmszsroxrtxtzpowrowplwlqnowzyn",
  "identical_production_build_test_config": true,
  "allowed_changed_paths": ["docs/architecture/EXACT_TESTED_TO_FINAL_PATH"],
  "reconciled_allowed_changed_paths": ["docs/architecture/EXACT_RECONCILED_TO_FINAL_PATH"],
  "document_review_status": "PASS",
  "document_reviewer": "/root",
  "reviewed_document_sha256": {
    "docs/architecture/EXACT_TESTED_TO_FINAL_PATH": "FINAL_FILE_SHA256",
    "docs/architecture/EXACT_RECONCILED_TO_FINAL_PATH": "FINAL_FILE_SHA256"
  },
  "reusable_stages": ["EXACT_PLANNED_C8_STAGE"]
}
```

The reconciled revision must be the latest verified entry in the retained checkpoint chain. Source/test corrections belong in that reviewed source chain and cannot enter the document-only path allowlist. The two path arrays must independently equal `git diff --name-only` for tested→final and reconciled→final. Their union must equal the reviewed fingerprint keys. Current allowed file types are `.md`, `.typ`, `.pdf`, `.json`, and `.tar.gz` under `docs/architecture/`; no production/build/test/config path is allowed. Each reviewed digest must match the actual final Git blob. Deleted paths fail the digest check; represent an intentional deletion with a separately reviewed updater change rather than silently broadening the certificate. Empty deltas use empty arrays and an empty fingerprint object, with explicit passing review attribution.

Only stages named in `reusable_stages` may carry tested-candidate receipts to final C8. Preserve the executed revision, original receipt/audit hashes, and exact command; reuse does not count as another execution. Include both listing and run stages when reusing a nextest selection. C1–C7 receipts always match their exact current prefix revision.

To avoid a hash loop, generate and copy committed reports from a pinned candidate, identifying C8 by its stable change ID and labeling embedded candidate hashes as observed/executed snapshots. Compile and inspect the final reports, finalize C8, then write the closure certificate externally. Update `corrected-stack.json` to the actual final commits and run this updater again to a separate scratch output for final verification. Do not copy that final, self-referential JSON/closure output back into the already finalized C8. The immutable pre-document proof and externally verified final documentation delta serve different purposes.

## Archive allowlist

The updater proposes exact relative paths beneath the task scratch directory. It creates no archive and reads no file merely because a receipt names it. The proposal includes named source/review receipts, review patches, generator/self-check scripts, result/audit records, bounded logs and memory measurements, selected render receipts, and generated drafts. Each candidate must be a regular non-symlink path with no symlink ancestor, a permitted text/JSON extension, and at most 16 MiB.

Before packaging, review each proposed entry for credentials or sensitive environment output, then archive only the approved exact paths and record a final SHA-256 manifest. Never archive or read the licensed environment wrapper, credential/license files, environment dumps, target executables or shared libraries, evaluator/state folders, core dumps, large GL262 binary artifacts, imported prompt-like commit descriptions, or unbounded glob results. Audit references to selected binary paths are provenance strings only; the binaries are not archive candidates. Reject changed files and regenerate the allowlist rather than silently packaging a different snapshot.

`selfcheck-updater.py` exercises synthetic report-selection fixtures only. Its counts are utility checks, not GammaLoop/Rust test executions. The independent review and its script SHA-256 identify the reviewed utility version.

## Standalone MRE sidecar

`report-templates/fill-current-report.py` calls the metadata-only `summarize-mre.py` when the completed MRE receipt exists. The resulting `raised-energy-cff-mre-validation.md/json` stay separate from workspace totals. The summarizer checks the exact seven stages and all original result/output/source guards, two numeric control assertions, expected import assertion, paired recorded binary identities, and only four allowlisted text source blobs. It compares the complete package tree, manifests, lockfiles, Cargo config tree and tracked toolchain markers to current C7 before any unchanged-source claim. It never relabels the executed revision, rereads runtime binaries, or decodes serialized inputs. The retained unpinned formatting receipt is not counted as a new pinned build gate. A later `mre-fmt-current` receipt is verified and reported separately at its own executed revision with its own complete tracked-source and package/build-input identity proof.

# Reviewed source followups after the first reconciliation

Keep `reconciled-stack-proof.json` unchanged: d0242b47 and a1cf5b3f share c74a276. The new C3 Clippy correction changes source, so it cannot be represented as a documentation-only delta from that checkpoint.

Add `reconciliation-followups.json` with an ordered `checkpoints` array. Each appended record names its prior corrected-source and reconciled revisions, new corrected-source and reconciled C8 revisions, the exact equal new tree, and the stable C8 change ID. Include an exact prior-source→new-source path delta with before/after Git blobs, per-path diff SHA-256, current file SHA-256, semantic owner and the immutable review receipt. No input revision or earlier proof is overwritten.

For every record, the updater verifies both Git trees equal the stated tree and that the complete adjacent source diff equals the listed reviewed paths/fingerprints. Its current-correction check still requires an explicit passing review receipt for the new final file blob. Boundary-only redistribution has separate review evidence: moving the existing SoftMomentumAssignment alias from C7 into C3 changes prefix diffs even if its final bytes remain equal. Preserve the old/new C3 and C7 before/after hunk receipts for that ownership correction.

The generated mapping exposes `reconciliation_checkpoints` for the complete chain and keeps `immutable_pre_document_proof` as the latest verified pair for the main report filler. It separately retains the original checkpoint. This is an additive evidence change, not a replacement of the original proof.

The final external document certificate must name the latest verified `reconciled_revision`; its reconciled→final and tested-candidate→final deltas remain exact reviewed documentation-only path sets. The old checkpoint is connected through explicit reviewed source changes, never through an expanded document allowlist. C3–C8 test receipts must match the resulting new pins; C1/C2 may retain their unchanged pinned receipts. The existing main report filler reads proof and identities from the mapping and needs no hardcoded hash changes.

Required root inputs before implementing this extension: final corrected-source revision, reconstructed C8 revision/tree, updated eight-commit pins, exact source review receipt(s), and the alias-ownership redistribution receipt. Until those arrive, the existing generator/draft pins remain an explicitly labeled prior snapshot and are not a current-final acceptance claim.

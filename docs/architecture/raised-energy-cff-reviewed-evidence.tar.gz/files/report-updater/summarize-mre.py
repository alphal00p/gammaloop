#!/usr/bin/env python3
"""Verify and summarize recorded standalone MRE evidence; never execute or hash its binaries."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import re

base=Path('/tmp/raised-stack-latest-review-20260914')
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--out',type=Path,default=base/'report-updater/drafts')
args=parser.parse_args()
spec=importlib.util.spec_from_file_location('updater',base/'report-updater/update-current-reports.py')
u=importlib.util.module_from_spec(spec);spec.loader.exec_module(u)
repo=u.DEFAULT_REPO
out=args.out.resolve()
if out==repo or repo in out.parents: raise ValueError('Output must remain in scratch')
out.mkdir(parents=True,exist_ok=True)
inputs={}
for name in ['c7-results/mre-validation.json','mre-validation-plan.json','execute-mre-validation.py','corrected-stack.json']:
    inputs[name]=u.stable_bytes(base/name)
summary=json.loads(inputs['c7-results/mre-validation.json'])
plan=json.loads(inputs['mre-validation-plan.json'])
pins=json.loads(inputs['corrected-stack.json'])
executed=summary['revision']; observed=pins['commits'][6]['commit']
stage_order=['check','build','clippy','control','abstract-control','import-write','import-read']
if (summary['status']!='PASS' or not summary.get('completed_utc')
        or summary['plan_sha256']!=u.sha(inputs['mre-validation-plan.json'])
        or summary['driver_sha256']!=u.sha(inputs['execute-mre-validation.py'])
        or [row['stage'] for row in summary['stages']]!=stage_order or list(plan['commands'])!=stage_order
        or plan['expected_values']!={'control':39,'abstract-control':4}
        or plan['expected_exits']!={'import-read':101}
        or summary['positive_controls']!=2 or summary['upstream_diagnostics_reproduced']!=1
        or summary['workspace_tests_added_to_totals']!=0 or summary['large_evaluator_panic_reproduced'] is not False):
    raise ValueError('Standalone summary is incomplete or disagrees with its exact plan/driver')
package='tests/artifacts/aa_aa_uv_slowdown/symbolica_evaluator_mre'
entries=u.tree_entries(repo,executed)
tracked=u.git(repo,'ls-tree','-rz',executed)
tracked_digest=u.sha(tracked);tracked_count=len(tracked.split(b'\0'))-1
stages=[]
previous_completed=None
runtime_binaries={}
for stage in summary['stages']:
    name=stage['stage'];folder=base/'c7-results'/('mre-'+name)
    result_path=folder/'result.json';output_path=folder/'output.log'
    result_bytes=u.stable_bytes(result_path);output=u.stable_bytes(output_path)
    inputs[str(result_path.relative_to(base))]=result_bytes;inputs[str(output_path.relative_to(base))]=output
    result=json.loads(result_bytes);expected_exit=plan.get('expected_exits',{}).get(name,0)
    if (stage['result']!=str(result_path) or stage['result_sha256']!=u.sha(result_bytes)
            or stage['output_sha256']!=u.sha(output) or stage['argv']!=plan['commands'][name]
            or result['argv'][-len(stage['argv']):]!=stage['argv']
            or result['revision']!=executed or result['head_after']!=executed
            or result['exit_code']!=expected_exit or stage['exit_code']!=expected_exit
            or result.get('integrity_pass') is not True or result.get('execution_skipped',False)
            or not result.get('completed_utc') or result['source_sha256']!=result['source_sha256_after']
            or result['elapsed_seconds']!=stage['elapsed_seconds']):
        raise ValueError('MRE result/command/output identity differs: '+name)
    for key in ['tracked_before','tracked_after']:
        guard=result.get(key,{})
        if (guard.get('pass') is not True or guard.get('revision')!=executed
                or guard.get('expected_path_count')!=tracked_count or guard.get('checked_path_count')!=tracked_count
                or guard.get('expected_tree_records_sha256')!=tracked_digest
                or guard.get('actual_tree_records_sha256')!=tracked_digest or guard.get('mismatch_count')!=0):
            raise ValueError('MRE full tracked-source guard differs: '+name)
    if previous_completed and result['started_utc'] < previous_completed:
        raise ValueError('Standalone stages are not the recorded sequential execution')
    previous_completed=result['completed_utc']
    if name in ['check','build','clippy']:
        expected=['cargo',name,'--manifest-path',package+'/Cargo.toml','--target-dir',str(repo/package/'target'),'--locked','--all-targets','--profile','dev-optim']
        if name=='clippy':expected+=['--','-D','warnings']
        if stage['argv']!=expected:raise ValueError('Standalone build gate differs from locked all-target contract')
    else:
        binary=stage.get('binary',{})
        expected_binary=repo/package/'target/dev-optim'/('examples/import_remap' if name.startswith('import-') else 'symbolica-evaluator-mre')
        tail={'control':['--control'],'abstract-control':['--abstract-parameters','--control'],'import-write':['write',str(base/'mre-tiny.symbolica')],'import-read':['read',str(base/'mre-tiny.symbolica')]}[name]
        if (stage['argv']!=[str(expected_binary),*tail] or binary.get('path')!=str(expected_binary)
                or not re.fullmatch('[0-9a-f]{64}',binary.get('sha256',''))
                or not isinstance(binary.get('bytes'),int) or binary['bytes']<=0
                or not isinstance(binary.get('mtime_ns'),int)):
            raise ValueError('Standalone runtime binary provenance/command is incomplete')
        group='import' if name.startswith('import-') else 'control'
        if group in runtime_binaries and runtime_binaries[group]!=binary:
            raise ValueError('Paired standalone runs used different recorded binaries')
        runtime_binaries[group]=binary
    if name=='import-write' and output.decode().strip()!='exported f(x,y)':
        raise ValueError('Tiny writer did not export the complete expected nonsymmetric value')
    if name in plan['expected_values']:
        events=[json.loads(line) for line in output.decode().splitlines() if line.startswith('{')]
        if stage['asserted_value']!=plan['expected_values'][name] or not any(event.get('stage')=='control_passed' for event in events):
            raise ValueError('MRE positive control did not reach its post-assertion success event')
    if name=='import-read':
        required=['imported f(y,x); expected f(x,y)','Argument identities changed during import','left: import_mre::f(import_mre::y,import_mre::x)','right: import_mre::f(import_mre::x,import_mre::y)']
        if not all(text in output.decode() for text in required): raise ValueError('Expected import diagnostic was not reproduced exactly')
    stages.append({**stage,'result_sha256_verified':True,'output_sha256_verified':True,'full_tracked_source_guard_verified':True})
reported_sources={}
allowed_sources={package+'/'+path for path in ['Cargo.toml','Cargo.lock','src/main.rs','examples/import_remap.rs']}
source_records={}
for source in summary['sources']:
    marker='/'+package+'/'
    if marker not in source['path']: raise ValueError('Unexpected standalone source path')
    path=package+'/'+source['path'].split(marker,1)[1]
    if path not in allowed_sources or path in source_records:
        raise ValueError('Unexpected or duplicate source path rejected before reading a Git blob')
    source_records[path]=source
if set(source_records)!=allowed_sources:
    raise ValueError('MRE source fingerprint set is incomplete')
for path,source in source_records.items():
    blob=entries[path]['git_blob']
    if source['sha256']!=u.sha(u.git(repo,'cat-file','blob',blob)) or source['bytes']!=entries[path]['bytes']:
        raise ValueError('Recorded MRE source fingerprint differs from immutable Git: '+path)
    reported_sources[path]={'git_blob':blob,'sha256':source['sha256'],'bytes':source['bytes']}
build_paths=['Cargo.toml','Cargo.lock','.cargo/config.toml','rust-toolchain','rust-toolchain.toml',package+'/Cargo.toml',package+'/Cargo.lock']
observed_entries=u.tree_entries(repo,observed)
package_before=u.git(repo,'rev-parse',executed+':'+package).decode().strip()
package_after=u.git(repo,'rev-parse',observed+':'+package).decode().strip()
config_before=u.git(repo,'rev-parse',executed+':.cargo').decode().strip()
config_after=u.git(repo,'rev-parse',observed+':.cargo').decode().strip()
identity={'executed_revision':executed,'observed_c7_revision':observed,'package_path':package,'executed_package_tree':package_before,'observed_package_tree':package_after,'executed_cargo_config_tree':config_before,'observed_cargo_config_tree':config_after,'files':{path:{'executed':entries.get(path),'observed':observed_entries.get(path)} for path in build_paths},'scope':'Exact tracked package, manifests, lockfiles, Cargo configuration and toolchain-file identity only; original runtime/binary/environment receipts remain at the executed revision.'}
identity['identical']=package_before==package_after and config_before==config_after and all(row['executed']==row['observed'] for row in identity['files'].values())
identity['claim']='Same executed source' if executed==observed else ('Source-equivalent standalone package; no additional execution' if identity['identical'] else 'Original-source evidence only; current package/build inputs differ')
formatting=None
format_path=base/'c7-results/mre-fmt-current/result.json'
if format_path.exists():
    format_bytes=u.stable_bytes(format_path);format_output=u.stable_bytes(format_path.parent/'output.log')
    inputs[str(format_path.relative_to(base))]=format_bytes
    inputs[str((format_path.parent/'output.log').relative_to(base))]=format_output
    record=json.loads(format_bytes);format_revision=record['revision']
    expected_command=['cargo','fmt','--manifest-path',package+'/Cargo.toml','--all','--','--check']
    if (record['argv'][-len(expected_command):]!=expected_command or record['stage']!='mre-fmt-current'
            or record['exit_code']!=0 or record.get('integrity_pass') is not True
            or record['head_after']!=format_revision or not record.get('completed_utc')
            or record.get('execution_skipped',False) or record['source_sha256']!=record['source_sha256_after']):
        raise ValueError('Pinned standalone formatting receipt failed its command/source gate')
    format_tree=u.git(repo,'ls-tree','-rz',format_revision)
    format_digest=u.sha(format_tree);format_count=len(format_tree.split(b'\0'))-1
    for key in ['tracked_before','tracked_after']:
        guard=record.get(key,{})
        if (guard.get('pass') is not True or guard.get('revision')!=format_revision
                or guard.get('expected_path_count')!=format_count or guard.get('checked_path_count')!=format_count
                or guard.get('expected_tree_records_sha256')!=format_digest
                or guard.get('actual_tree_records_sha256')!=format_digest or guard.get('mismatch_count')!=0):
            raise ValueError('Pinned standalone formatting source guard differs')
    format_entries=u.tree_entries(repo,format_revision)
    format_package_tree=u.git(repo,'rev-parse',format_revision+':'+package).decode().strip()
    format_config_tree=u.git(repo,'rev-parse',format_revision+':.cargo').decode().strip()
    format_files={path:{'executed':format_entries.get(path),'observed':observed_entries.get(path)} for path in build_paths}
    formatting={'status':'PASS','executed_revision':format_revision,'observed_c7_revision':observed,'result':str(format_path),'result_sha256':u.sha(format_bytes),'output_sha256':u.sha(format_output),'elapsed_seconds':record['elapsed_seconds'],'argv':expected_command,'full_tracked_source_guard_verified':True,'executed_package_tree':format_package_tree,'observed_package_tree':package_after,'executed_cargo_config_tree':format_config_tree,'observed_cargo_config_tree':config_after,'files':format_files,'source_equivalent':format_package_tree==package_after and format_config_tree==config_after and all(row['executed']==row['observed'] for row in format_files.values()),'adds_runtime_execution':False}
report={'status':'PASS','scope':'Two standalone positive controls and one reproduced import defect; excluded from all workspace gate/runtime totals.','executed_revision':executed,'observed_c7_revision':observed,'source_equivalence':identity,'positive_controls':2,'control_assertions':plan['expected_values'],'reproduced_import_defects':1,'workspace_tests_added_to_totals':0,'large_evaluator_panic_reproduced':False,'stages':stages,'immutable_source_files':reported_sources,'recorded_binary_provenance':[row['binary'] for row in stages if 'binary' in row],'binary_hashes_recomputed':False,'tiny_input_provenance':summary['tiny_input'],'tiny_input_read_or_decoded':False,'pinned_formatting':formatting,'formatting_scope':'The original unpinned formatting receipt has no revision, time or source guard and is not a fresh pinned MRE gate. The separate pinned formatting record, when present, carries its own revision and source guards.','input_sha256':{name:u.sha(data) for name,data in inputs.items()}}
text=['# Standalone Symbolica MRE evidence','',f'Executed revision: `{executed}`. The standalone package passes locked all-target check/build/Clippy and two controls whose assertions require **39** and **4**. The tiny writer exits 0; the reader exits the expected **101**, reproducing `f(y,x)` where `f(x,y)` is required. This is **two positive controls and one reproduced defect**, contributing **zero workspace tests**.','',f'Observed C7: `{observed}`. Source relationship: **{identity["claim"]}**. Package tree `{package_before}` and the exact manifest/lock/Cargo-config/toolchain-file comparison are recorded in the JSON sidecar. The executed revision and original receipt/binary hashes are retained.','', '| Stage | Classification | Exit | Seconds |','| --- | --- | --- | --- |']
for row in stages:text.append('| '+ ' | '.join([row['stage'],row['classification'],str(row['exit_code']),f'{row["elapsed_seconds"]:.3f}'])+' |')
if formatting:
    text+=['',f'Separately executed standalone formatting: **PASS** at `{formatting["executed_revision"]}` in {formatting["elapsed_seconds"]:.3f}s, with complete tracked-source guards. Package/build-input identity with observed C7: **{formatting["source_equivalent"]}**. This is a formatting operation, not a control or additional runtime execution.','']
text+=['','No GL262 physical replay or large evaluator-construction panic reproduction was attempted. The import argument-order defect does not establish the cause of the GL262 panic. Controls build small synthetic inputs; they do not decode or validate the three serialized Symbolica blobs.','',report['formatting_scope'],'','Exact result/output fingerprints and complete tracked-source guards are verified against the original immutable revision. Binary and tiny-input hashes are retained from the execution driver; this summarizer does not read/hash the binaries or read/decode the serialized input. The original toolchain/environment and execution date remain authoritative.','']
for name,data in inputs.items():
    if u.stable_bytes(base/name)!=data:raise ValueError('MRE evidence changed during report generation: '+name)
u.write_json(out/'raised-energy-cff-mre-validation.json',report)
(out/'raised-energy-cff-mre-validation.md').write_text('\n'.join(text))
print(json.dumps({'status':'PASS','executed_revision':executed,'observed_c7_revision':observed,'source_equivalent':identity['identical'],'positive_controls':2,'reproduced_defects':1,'workspace_tests':0,'output':str(out)},indent=2))

#!/usr/bin/env python3
"""Synthetic receipt checks for report selection; no application tests run."""
from pathlib import Path
import hashlib
import importlib.util
import json
import shutil
import subprocess
import tempfile

base=Path('/tmp/raised-stack-latest-review-20260914')
script=base/'report-updater/update-current-reports.py'
spec=importlib.util.spec_from_file_location('report_updater',script)
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
fixture=Path(tempfile.mkdtemp(prefix='report-updater-selfcheck-',dir='/tmp'))
for name in module.FIXED_INPUTS:
    target=fixture/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(base/name,target)
for checkpoint in json.loads((base/'report-updater/reconciliation-followups.json').read_text())['checkpoints']:
    for review in checkpoint['review_receipts']:
        target=fixture/review['path'];target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(base/review['path'],target)
plan=json.loads((fixture/'prefix-validation-plan.executable.json').read_text())
revision=json.loads((fixture/'corrected-stack.json').read_text())['commits'][0]['commit']
commands=dict(plan['prefixes'][0]['stages'])
checks=[]

def write(path,value):
    path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(value,indent=2)+'\n')

def receipt(stage,command,exit_code=0,rev=revision,time='2026-09-14T00:00:00+00:00'):
    return {'branch':'c1','stage':stage,'revision':rev,'argv':command,'started_utc':time,'completed_utc':time,'elapsed_seconds':1.0,'exit_code':exit_code,'integrity_pass':True,'head_after':rev,'source_sha256':'0'*64,'source_sha256_after':'0'*64}

def run(expect,stage):
    completed=subprocess.run(['/tmp/raised-stack/python',str(script),'--base',str(fixture)],capture_output=True,text=True)
    assert completed.returncode==0,completed.stderr
    data=json.loads((fixture/'report-updater/drafts/raised-energy-cff-stack-current-validation.json').read_text())
    row=next(row for row in data['gates'] if row['owner']=='C1' and row['stage']==stage)
    assert row['status']==expect,(row['status'],expect,row)
    return data

folder=fixture/'c1-results'
fmt=folder/'fmt/result.json'
write(fmt,receipt('fmt',commands['fmt']));run('PASS','fmt');checks.append('exact current revision and command accepted')
write(folder/'fmt-v2/result.json',receipt('fmt-v2',commands['fmt'],1,time='2026-09-14T00:00:01+00:00'));run('FAIL','fmt');checks.append('later matching failure overrides earlier pass')
shutil.rmtree(folder/'fmt-v2')
write(fmt,receipt('fmt',commands['fmt'],rev='0'*40));run('PENDING','fmt');checks.append('stale-source pass excluded')
write(fmt,receipt('fmt',commands['fmt']+['--unexpected']));run('PENDING','fmt');checks.append('changed-command pass excluded')
shutil.rmtree(folder/'fmt')
stage=next(name for name, argv in plan['prefixes'][0]['stages'] if argv[:3] == ['cargo','nextest','run']);result=folder/stage/'result.json';write(result,receipt(stage,commands[stage]));run('UNVERIFIED',stage);checks.append('unaudited nextest pass excluded')
listing=folder/(stage+'-list')/'result.json';write(listing,receipt(stage+'-list',commands[stage+'-list']))
(result.parent/'output.log').write_text('synthetic run log; no tests executed\n')
(listing.parent/'output.log').write_text('synthetic listing log; no tests executed\n')
case={'binary_id':'synthetic-binary','test_name':'synthetic_complete_value','status':'PASS','seconds':1.0,'progress_index':1}
def audit():
    return {'status':'PASS','revision':revision,'errors':[],'sources':[{'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()} for path in [result,result.parent/'output.log',listing,listing.parent/'output.log']],'run_argv':commands[stage],'list_argv':commands[stage+'-list'],'selected_count':1,'excluded_count':0,'selected_identities':[['synthetic-binary','synthetic_complete_value']],'summary_counts':{'passed':1,'failed':0,'skipped':0},'status_counts':{'PASS':1},'cases':[case.copy()],'binary_hashes':[{'binary_id':'synthetic-binary','sha256':'0'*64}]}
audit_path=result.parent/'audit.json';write(audit_path,audit());run('PASS',stage);checks.append('consistent synthetic audited selection accepted')
requirement=plan['list_requirements'][f'1/{stage}']
requirement['required_name_prefixes']=['missing_prefix::'];write(fixture/'prefix-validation-plan.executable.json',plan)
run('UNVERIFIED',stage);checks.append('missing required test prefix excluded')
requirement['required_name_prefixes']=['synthetic_'];write(fixture/'prefix-validation-plan.executable.json',plan)
run('PASS',stage);checks.append('required test prefix found in selected outcomes')
requirement.pop('required_name_prefixes');write(fixture/'prefix-validation-plan.executable.json',plan)
a=audit();a['sources'][0]['sha256']='f'*64;write(audit_path,a);run('UNVERIFIED',stage);checks.append('changed result fingerprint excluded')
a=audit();a['summary_counts']['passed']=2;write(audit_path,a);run('UNVERIFIED',stage);checks.append('inflated pass count excluded')
a=audit();a['cases'][0]['status']='FAIL';write(audit_path,a);run('UNVERIFIED',stage);checks.append('nonpassing selected outcome excluded')
a=audit();a['binary_hashes']=[];write(audit_path,a);run('UNVERIFIED',stage);checks.append('missing selected binary provenance excluded')
a=audit();a['sources'].append({'path':'/tmp/raised-stack/run','sha256':'0'*64});write(audit_path,a);run('UNVERIFIED',stage);checks.append('wrapper reference rejected without reading or hashing it')
a=audit();a['sources']=a['sources'][:1];write(audit_path,a);run('UNVERIFIED',stage);checks.append('missing list/run output evidence excluded')
complete_receipt=receipt(stage,commands[stage]);complete_receipt.pop('completed_utc');write(result,complete_receipt);run('FAIL',stage);checks.append('missing completion marker excluded')
write(result,receipt(stage,commands[stage]));write(audit_path,audit())
saved_prefixes=plan['prefixes'];plan['prefixes']=[];write(fixture/'prefix-validation-plan.executable.json',plan)
invalid=subprocess.run(['/tmp/raised-stack/python',str(script),'--base',str(fixture)],capture_output=True,text=True)
assert invalid.returncode!=0,'empty plan must not pass'
checks.append('empty plan rejected rather than vacuously complete')
plan['prefixes']=saved_prefixes;write(fixture/'prefix-validation-plan.executable.json',plan)
plan['prefixes'][0]['stages'].append(['fmt-v2', commands['fmt']]);write(fixture/'prefix-validation-plan.executable.json',plan)
invalid=subprocess.run(['/tmp/raised-stack/python',str(script),'--base',str(fixture)],capture_output=True,text=True)
assert invalid.returncode!=0,'duplicate canonical stages must not count one receipt twice'
checks.append('duplicate canonical stages rejected to prevent double counting')
plan['prefixes'][0]['stages'].pop();write(fixture/'prefix-validation-plan.executable.json',plan)
chain_path=fixture/'report-updater/reconciliation-followups.json';chain=json.loads(chain_path.read_text())
original_parent=chain['checkpoints'][0]['previous_corrected_source_revision']
chain['checkpoints'][0]['previous_corrected_source_revision']='0'*40;write(chain_path,chain)
invalid=subprocess.run(['/tmp/raised-stack/python',str(script),'--base',str(fixture)],capture_output=True,text=True)
assert invalid.returncode!=0,'incorrect reconciliation parent must be rejected'
checks.append('incorrect reconciliation-chain parent rejected')
chain['checkpoints'][0]['previous_corrected_source_revision']=original_parent
original_diff=chain['checkpoints'][0]['changes'][0]['diff_sha256']
chain['checkpoints'][0]['changes'][0]['diff_sha256']='0'*64;write(chain_path,chain)
invalid=subprocess.run(['/tmp/raised-stack/python',str(script),'--base',str(fixture)],capture_output=True,text=True)
assert invalid.returncode!=0,'unreviewed source diff must be rejected'
checks.append('incorrect reviewed source-followup diff fingerprint rejected')
chain['checkpoints'][0]['changes'][0]['diff_sha256']=original_diff;write(chain_path,chain)
bad_tracked=receipt(stage,commands[stage])
bad_tracked['tracked_before']=bad_tracked['tracked_after']={'pass':True,'revision':revision,'expected_path_count':0,'checked_path_count':0,'expected_tree_records_sha256':'0'*64,'actual_tree_records_sha256':'0'*64,'mismatch_count':0}
write(result,bad_tracked);run('FAIL',stage);checks.append('false complete tracked-tree guard excluded')
write(result,receipt(stage,commands[stage]));write(audit_path,audit())
stack=json.loads((fixture/'corrected-stack.json').read_text())
final_revision=stack['commits'][-1]['commit'];tested_revision=stack['corrected_source_revision']
final_commands=dict(plan['prefixes'][-1]['stages'])
c8_result=fixture/'c8-results/fmt/result.json'
c8_receipt=receipt('fmt',final_commands['fmt'],rev=tested_revision);c8_receipt['branch']='c8';write(c8_result,c8_receipt)
certificate={'status':'PASS','tested_revision':tested_revision,'final_revision':final_revision,'stable_change_id':stack['commits'][-1]['change_id'],'identical_production_build_test_config':True,'allowed_changed_paths':[],'reconciled_revision':stack['commits'][-1]['commit'],'reconciled_allowed_changed_paths':[],'document_review_status':'PASS','document_reviewer':'synthetic fixture only','reviewed_document_sha256':{},'reusable_stages':['fmt']}
closure_path=fixture/'final-document-closure.json';write(closure_path,certificate)
reused=run('PASS',stage)
c8=next(row for row in reused['gates'] if row['owner']=='C8' and row['stage']=='fmt')
assert c8['status']=='PASS' and c8['executed_revision']==tested_revision and c8['revision']==final_revision and c8['document_reuse_certificate']
checks.append('certified equal-tree C8 reuse preserves executed and final revisions')
certificate['allowed_changed_paths']=['Cargo.toml'];write(closure_path,certificate)
invalid=subprocess.run(['/tmp/raised-stack/python',str(script),'--base',str(fixture)],capture_output=True,text=True)
assert invalid.returncode!=0,'non-document or incorrect closure delta must be rejected'
checks.append('non-document or incorrect closure delta rejected')
closure_path.unlink()
strict=subprocess.run(['/tmp/raised-stack/python',str(script),'--base',str(fixture),'--require-complete'],capture_output=True,text=True)
assert strict.returncode==2,strict.stderr
checks.append('strict mode rejects incomplete plans')
report={'status':'PASS','checks':checks,'scope':'Synthetic report-selection receipts only; not Rust/application test executions','fixture':str(fixture),'script_sha256':hashlib.sha256(script.read_bytes()).hexdigest(),'licensed_wrapper_read_or_hashed':False}
write(base/'report-updater/selfcheck.json',report)
print(json.dumps(report,indent=2))

"""Park the idle validation workspace on the independent, identical-tree source snapshot.
No commit, source, dispatch pin, bookmark or report changes. Explicit one-time operator step.
"""
from pathlib import Path
import fcntl
import importlib.util
import json

BASE = Path('/tmp/raised-stack-latest-review-20260914')
spec = importlib.util.spec_from_file_location('parking_executor', BASE/'execute-prefix.py')
executor = importlib.util.module_from_spec(spec)
spec.loader.exec_module(executor)
app = executor.module('parking_existing_guards', 'apply-approved-numeric-sign.py')
runner = executor.module('parking_source_guard', 'run-stage.py')
ledger_path = BASE/'report-updater/drafts/raised-energy-cff-stack-current-validation.json'
ledger = executor.load(ledger_path)
assert ledger['status'] == 'COMPLETE' and not ledger['provenance_issues']
assert len(ledger['gates']) == 93 and all(row['status'] == 'PASS' for row in ledger['gates'])
old = executor.load(BASE/'corrected-stack.json')
pins = executor.load(BASE/'validation-pins.json')
tested = pins['c8']
source = old['corrected_source_revision']
assert tested == '449a59f6f173d100c2da858c541faa1e0dccca6e'
assert source == '392c98c3d2f70896ef94267addfcf610e2df2c88'
assert all(row['executed_revision'] == tested for row in ledger['gates'] if row['owner'] == 'C8')
result_path = BASE/'prefix-document-parking-result.json'
checkpoint_path = BASE/'prefix-document-parking-checkpoint.json'
assert not result_path.exists() and not checkpoint_path.exists()
with (BASE/'prefix-execution.lock').open('a+') as lock:
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    executor.idle_prefix()
    previous_prefix = executor.PREFIX
    try:
        executor.PREFIX = app.REPO
        executor.idle_prefix()
    finally:
        executor.PREFIX = previous_prefix
    assert app.jj_value('@') == source and app.jj_value('@', cwd=executor.PREFIX) == tested
    assert app.tree(source) == app.tree(tested) == old['corrected_tree']
    assert tested not in app.command(['git','rev-list',source]).decode().splitlines()
    rows = [app.metadata(row['change_id']) for row in old['commits']]
    assert rows == old['commits']
    source_record = app.metadata(app.SOURCE_CHANGE)
    assert source_record['commit'] == source
    root_audit = app.tracked(runner,app.REPO,source)
    prefix_audit = app.tracked(runner,executor.PREFIX,tested)
    ref_argv = ['git','for-each-ref','--format=%(refname) %(objectname)','refs/heads','refs/remotes']
    bookmark_argv = ['jj','--ignore-working-copy','bookmark','list','--all-remotes','--template','name ++ "\\t" ++ remote ++ "\\t" ++ normal_target.commit_id() ++ "\\n"']
    refs, bookmarks = app.command(ref_argv), app.command(bookmark_argv)
    frozen = {name:(BASE/name).read_bytes() for name in ['corrected-stack.json','validation-pins.json','prefix-validation-plan.executable.json','run-stage.py','execute-prefix.py']}
    checkpoint = dict(status='BEFORE_PARKING',operation=app.command(['jj','--ignore-working-copy','op','log','--limit','1','--no-graph','-T','id']).decode().strip(),tested_revision=tested,source_record=source_record,stack=rows,root_tracked=root_audit,prefix_tracked=prefix_audit,refs=refs.decode().splitlines(),bookmarks=bookmarks.decode().splitlines(),input_sha256={n:app.sha(d) for n,d in frozen.items()},complete_ledger_sha256=app.sha(ledger_path.read_bytes()))
    app.exclusive_json(checkpoint_path,checkpoint)
    result = dict(status='FAIL',commands=app.TRACE,tested_revision=tested,parked_revision=source,application_tests_added=0)
    try:
        app.command(['jj','edit',app.SOURCE_CHANGE],cwd=executor.PREFIX)
        assert app.jj_value('@',cwd=executor.PREFIX) == app.jj_value('@') == source
        assert [app.metadata(row['change_id']) for row in rows] == rows
        assert app.metadata(app.SOURCE_CHANGE) == source_record
        assert app.command(ref_argv) == refs and app.command(bookmark_argv) == bookmarks
        assert all((BASE/name).read_bytes() == data for name,data in frozen.items())
        assert app.sha(ledger_path.read_bytes()) == checkpoint['complete_ledger_sha256']
        result['root_tracked_after'] = app.tracked(runner,app.REPO,source)
        result['prefix_tracked_after'] = app.tracked(runner,executor.PREFIX,source)
        result['status'] = 'PASS'
        result['scope'] = 'Only validation workspace checkout moved to an existing independent commit with identical tracked tree. All eight stack commits, source snapshot, pins, refs and executed evidence remain unchanged.'
    except Exception as error:
        result['error'] = str(error)
        raise
    finally:
        app.exclusive_json(result_path,result)
        print(json.dumps(dict(status=result['status'],receipt=str(result_path))))

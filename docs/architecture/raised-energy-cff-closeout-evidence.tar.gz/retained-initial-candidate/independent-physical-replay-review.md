# Independent completed GL04 replay review

The completed serialization/retention replay passes independent evidence review at `a474c96016a6236d0e91cb67dd284fe91a6c38b7` (tree `1f4a64901b2d7df8bf84629ff47fa098b83e8918`). No open findings. This reviewer executed no CLI, build or test and changed no tracked files.

Frozen binary SHA256 `c48ae9aa1335adabb0899fb998ad6a97daddf2f15033a779d4711caca023f931` matches the successful C7 build receipt, replay before/after hashes and a fresh independent hash. Build log/command and source-audit hashes match. Source audits report all 1,904 tracked entries matching in the applicable workspaces. C7 refreshed 32 documentation/evidence files and preserved 1,872 regular files from certified C6; its short cached build is not a performance result.

Both concurrent processes exited 0. Their logs show four inspections: plain and JSON output with additional weights disabled and enabled. Independent complete JSON comparisons confirm one group of three events, identical retained kinematics, cut metadata, event weights, stability values and every other non-additional-weight field. Nine emitted additional-weight pairs include three structured `ThresholdCounterterm` keys; complete values are retained in the JSON review receipt.

Baseline normalization removes only five named evaluation timings and one stability timing, and converts three original empty weight objects to empty pair lists. Additional weights are omitted only across the retention toggle and checked separately. Event/group ordering is ignored while multiplicity and membership are preserved; numbers use exact parsed-value equality. All 14 state-file hashes match the original, replay before/after and a fresh read. The frozen binary remains identical.

The guard exited 0 under an 8 GB tree-RSS limit and 90-second outer timeout. Each CLI had a 40-second timeout, two Rayon threads and shared CPU affinity 8–11. No retries or snapshot updates. Startup filter-override and imported-symbol registration warnings remain recorded. Guard duration and sampled RSS are execution evidence only.

This is one saved-state serialization/retention regression. It supplies no independent physics, expected physical key set, fresh-generation acceptance or new performance claim. Full-suite and final documentation/history closure remain separate.

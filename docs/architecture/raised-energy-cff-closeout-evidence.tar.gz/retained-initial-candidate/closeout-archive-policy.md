# Closeout evidence archive preparation

Run `archive-closeout-evidence.py` only after all seven boundary receipts and all ten final runtime selections are complete. This preparation does not certify active validation and does not execute Cargo, tests, jj mutations or archive publication.

Example invocation, directly with the existing Python executable:

```sh
/tmp/raised-stack/python /tmp/raised-stack/closeout/archive-closeout-evidence.py \
  --runtime-revision FULL_FROZEN_RUNTIME_COMMIT \
  --runtime-tree FULL_FROZEN_RUNTIME_TREE \
  --boundary-evidence /tmp/raised-stack/closeout/validation-prep/boundary-evidence-complete.json \
  --runtime-evidence /tmp/raised-stack/closeout/validation-prep/runtime-evidence-complete.json \
  --physical-manifest /tmp/raised-stack/closeout/physical-inspect/final-c7/manifest.json \
  --ledger-output /tmp/raised-stack/closeout/frozen-ledger-data.json
```

The default outputs are `docs/architecture/raised-energy-cff-closeout-evidence.tar.gz` and its adjacent `.json` receipt. For a preview, create an empty directory below `/tmp/raised-stack/closeout` and pass it as `--output-directory`. Neither output may already exist. The runtime commit must precede both new evidence paths, preventing archive/final-report recursion. The optional ledger is a fresh scratch JSON containing exact test summaries, commands and aggregate counts, with no final PDF/report hashes.

Included: allowlisted root history/tree proofs and descriptions; functional/independent source review receipts; complete validation commands, stdout/stderr, lists, guards, source audits and collectors; final orchestration source/progress/completion and frozen CLI build hash receipt; validation renderer and explicit diagnostic-attempt receipt; JSON-fix compiler/test diagnostics; compact-test initial failures, retained draft, final checks and explicit correction approval; powered-dot owning-boundary proposal; completed physical GL04 replay scripts/inputs/results and read-only-state/binary hash manifests (excluding state and binary payloads); per-boundary Cargo/nextest/tooling files read from immutable Git blobs. Existing shared `extra-prefix-checks` is included because commands invoke it.

Excluded: `/tmp/raised-stack/run` (never read or hashed), environment/license secrets, symlinks, ELF/other binaries, states, all `bin/` directories, caches/build products, prior archives, old report/PDF snapshots and final document/head closure. The separate final closure receipt should record final document IDs/hashes after this archive is included. Earlier evidence archives are not opened or overwritten by packaging.

Every selected regular file is read with metadata stability checks, UTF-8/NUL and binary checks, and credential screening. A possible credential aborts packaging with only the source name reported; matched values are never printed. This is an explicit source allowlist plus screening, not permission to archive arbitrary environment dumps. Active or changing evidence aborts packaging. No environment dump is read, printed or archived; only the existing explicit public command contexts are retained.

The tar contains source bytes, a generated ledger and `MANIFEST.json`. Member names are sorted; timestamps, owners and gzip timestamp are normalized, and executable bits are preserved. The manifest inventories every payload’s SHA256, size, mode and provenance. It does not hash itself. The adjacent receipt hashes the finished archive and manifest and repeats the member inventory. Every archive member is read back and checked before atomic publication. Identical frozen source bytes, provenance paths and executable bits produce identical archives; source modification times are checked for stability but are not stored in the manifest. Full completed failures remain failures; the package never promotes them to passes.

The source-selection whitelist is in the script (`ROOT_FILES`, `SUBDIRECTORIES`, suffix and extensionless-name sets). Unknown future root artifacts are excluded until explicitly reviewed and added. Final document/PDF review receipts stay external to prevent circular self-certification.

The physical manifest must carry the frozen runtime revision and a final passed/failed outcome; incomplete replay cannot be packaged as completed evidence. Initial compiler errors and first-draft test failures stay under diagnostic directories and are explicitly separate from reconstructed boundary failures. The archive precedes final report refresh/gates/PDF inspection and bookmark closure. Those later receipts stay external.

The final driver source and its optional captured driver log are allowlisted. Its frozen CLI receipt contains only binary paths, hashes and provenance; the archive never opens those referenced binaries. Before-runtime and after-runtime worktree audits are retained under `validation-prep/`. The runtime driver and complete collectors must finish before packaging; final report refresh, rendering, final gates and bookmark closure follow packaging and remain in an external closure receipt.

Current report/ledger renderer sources and their independent static reviews are included as preparation evidence. The accepted history/source closure verifier source is included; its eventual final-head closure output stays external. `runtime-candidate.json`, the queued orchestration source, and the exact `pre-runtime-ref-observation.json` are retained. That observation records transient Codex ref changes and the separately observed new remote ref. Original named branch protections remain strict; the archive does not claim that all shared-repository refs are unchanged or identify the actor behind other activity.

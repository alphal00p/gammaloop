# Independent closeout script review

Static independent review of the complete physical replay harness, retained input records and read-only history/source closure verifier, with relevant public CLI source context.

This is a source audit only: no Cargo build/test, CLI inspection or closure verifier was executed by this reviewer. There are no open findings.

The one finding was corrected in the harness: JSON-string sorting could reject parsed-equal numbers such as `-0.0`/`0.0` and `1`/`1.0`. The reviewed version uses native complete-record equality and exact event/group multiplicities. Group membership is preserved; traversal order and number spelling are not contracts.

The physical GL04 replay is a serialization and retention regression. It reloads the retained state and evaluates the same point with retention disabled/enabled, using plain inspection before JSON inspection. The original successful JSON is a regression baseline. It is not an independent physics oracle. Enabled additional weights are structurally validated and retained, but this harness does not independently derive their values or expected key set.

Its exclusions are explicit: the five named evaluation timing fields, per-stability-result timing, original empty-map encoding `{}`→`[]`, and the additional-weight field only across the false/true retention toggle. All other payload values participate in structural comparisons. Public display numbers provide output consistency, not separate physics evidence.

Read-only CLI semantics, external output paths and before/after state file hashes agree. Two concurrent CLI processes have two Rayon threads each, shared CPU affinity 8–11, 40-second timeouts and five-second kill grace under the common 8 GB/90-second watchdog. There are no retries or snapshot updates. Root must link the recorded frozen executable hash to the immutable C7 source/build receipt; the declared revision alone cannot prove that link.

The closure verifier has no substantive static-review findings. It checks the exact seven-commit linear histories, first-six pins and identity, report-only C7 deltas, unchanged runtime/final non-report blobs/types/modes, preservation of source objects and original jj changes, and the intended bookmark/reference boundary. Its operations read history and write a scratch receipt. Workspace cleanliness, binary provenance, PDF rendering and executed validation require their own receipts. The current ref scope preserves all original heads/remotes/tags and other original non-transient refs except the requested reviewed bookmark move. It records transient `refs/codex/turn-diffs/` activity and new jj keep refs, and admits only the exact CI remote addition pinned by the pre-runtime observation. No actor is inferred and no ref is mutated by the verifier.

The standard container comparisons and immutable Git inventories are direct and appropriate for this bounded audit. No production hooks or test helpers were added.

| Complete reviewed artifact | SHA256 |
| --- | --- |
| `physical-inspect/replay.py` | `3307548ab6a62c9cb0cbe5b2ed4e0f6a218cd05af35f679313c966d782da99a2` |
| `physical-inspect/run.sh` | `c1dd515cea11792dc1065aa056a57fba9cd755e5fa34c834b1555b66e57ed811` |
| `physical-inspect/ram_watchdog.py` | `aa26497fe4711bcb6c0179f7ca01ba6f43aadaa967b430e81502f6da17cd8992` |
| `physical-inspect/README.md` | `7e9a3499781f516fbf3ee316b1f1072c1fca82daea52cdc51cfd80b5b82a760f` |
| `physical-inspect/inputs/original-reproducer.py` | `1eb5cf9db743cfe4133930fb6278e311dc91387fe20a1c14bec2b98915e25f0c` |
| `physical-inspect/inputs/original-manifest.json` | `03156b5aa58838c60608b50e8560e31d4d13e0f39defe1ad542e1caeb0f91152` |
| `physical-inspect/inputs/original-weights-false.json` | `19c6ecb2d74fbe10b5128f2dcdb6a5fadb6ec15fdc6fd0a7539e86b295c9f666` |
| `verify-history-source-closure.py` | `d3c17c011dca768b03cce1fd97c966b284641ff37e2110d71af7b03af8f59d8f` |

The adjacent JSON receipt identifies the limited public CLI source context separately from complete script reads. Final PDF/bookmark/artifact closure receipts are external to the tracked archive.

The prepared main-report renderer is accepted at SHA256 `3c6d69b3a30ae5ccfe5ea1c3f248185e582cee2bdcf95859e22d5343b0a383e1`. It matches the producing schemas, derives actual counts and requires matching C7/runtime outcomes and frozen CLI provenance. It distinguishes emitted-weight serialization from independent physics, binary/test identities from configurations, and path inventory from required external final document/render/head closure. It was not executed.

The prepared machine-ledger updater is accepted at SHA256 `3ccc418c97104adbfe6f34eccad568d3e00621073f56d99b45691e2147baa1f6`; see `independent-machine-ledger-review.json`. The prior script-review receipt remains preserved inside the current JSON receipt, with its own hash and version scope.

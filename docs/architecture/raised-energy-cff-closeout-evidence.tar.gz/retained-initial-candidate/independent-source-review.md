# Independent closeout source review

Reviewer: `/root/inspect_json_review`. Receipt time: 2026-09-11T13:16:51.013854+00:00.

**Result: no findings in the scoped changes.** This receipt records source inspection and static patch/context checks only. The reviewer ran no Cargo builds, tests, benchmarks, or backend executions and edited no repository source. Runtime validation belongs to the separate root receipts.

## JSON serialization and tests

No findings in serialization attribute, two outward tests, or architecture documentation.

GenericAdditionalWeightInfo.weights is the shared serialization boundary. Reuse existing vectorize dependency and local Serde adapter pattern; no new helper, string identifier grammar, production wrapper, or compatibility branch.

FloatLike already requires Serialize but not Deserialize. The original derive inferred T: Deserialize from the field. serde(with) suppresses that inference; bound(deserialize = "T: Deserialize<'de>") restores the same Deserialize impl requirement without strengthening the type definition.

Direct event Serde JSON uses a sequence of [key,value] pairs, including [] for no weights; structured enum identifiers remain values. Python events, approach JSON, and existing event snapshots explicitly construct their own string-key representations and are unaffected.

BatchResult.event_data uses Serde through EventOutput::EventList. Source inspection of bincode 2.0.1 shows identical map/sequence length encoding and no pair-tuple length prefix, so expected binary layout remains the same; not executed by reviewer. No compatibility shim is warranted.

JSON and bincode round trips compare all four exact key/value pairs and empty input. Physical gg_hhh inspection exercises retention both off/on, requires a structured amplitude counterterm when on, and compares numerical values, retained weights, grouping and selected cut identifiers with public evaluation.

Coverage qualification: Existing helper does not compare kinematics, PDGs, lmb_channel_edge_ids or every cut metadata field.

At C4 `76639bb7184868baf9b6ef4e16d64a96f8abab91`, the existing helpers in `tests/tests/test_runs/utils.rs` are:

- `setup_gg_hhh_threshold_amplitude_cli` at line 209.
- `evaluate_xspace_process_with_events` at line 489.
- `complex_ff64` at line 521.
- `assert_evaluation_outputs_match` at line 533.

The structured amplitude-counterterm key also already exists at C4. No later-commit helper or API dependency was found.

## Spenso outward tests

Three private materializer tests removed; three public parse/execute/result tests added. Production behavior and comments unchanged.

For w in {-2, a, a+b}, compare execution of f(w*p) with w*sum(mu=0..3, eta_mu*f(cind(mu))*p(cind(mu))), eta=(+1,-1,-1,-1). Expected value never invokes materializer or contraction engine.

Check complete scalar Atom values via exact expanded zero residual. No private slots, dummy names, node/map/cache counts, traversal order, or formatting checks.

Two compact vectors, or one compact vector times an explicit tensor, remain complete opaque scalar function arguments. Updated new-test expectations match the explicitly approved public contract.

Reuse existing macros, parser, execution/result APIs and mink4 helper; bounded fold and weight table; no new helper or compatibility layer.

## Powered-dot commit-boundary proposal

No findings in complete three proposed patches and complete C1/C6 test snippets.

C1 TestVakint already provides to_canonical(input,short_form) and tensor_reduce(input), forwarding to public Vakint with saved settings; epsilon_symbol and use_dot_product_notation exist. Projection setting is absent at C1 and present at C6.

C1 adds whole-numerator FORM regression and explanation at existing freshening code; C6 extends the same regression to false/true projection modes when that setting is introduced.

Vacuum Lorentz isotropy <k_mu*k_nu>=g_mu_nu*k^2/D implies <(k.p+k.q)^2>=k^2*(p^2+2*p.q+q^2)/D, D=4-2*eps. Both diagonal terms require 1/D. Complete expected numerator is independent of backend implementation; only the common topology envelope is canonicalized.

Exact rational together/cancel zero residual checks complete value and keeps input graph numerator factorized; no dummy-index or formatting assertion.

This is supported vacuum tensor reduction, not a full physical integration acceptance. Static API availability is not a compilation or execution result.

All proposal manifest file hashes match. C1 regression patch context matches pinned C1 source and reconstructs the supplied full C1 test file. The explanatory comment patch context matches pinned C1 production source. The C6 migration patch matches its supplied input and reconstructs the current complete test file exactly. These are text checks, not compiler checks.

## Reviewed source hashes

| File | SHA256 |
|---|---|
| `crates/gammalooprs/src/observables/events.rs` | `290100d7d212cbdd52985b5719b3dd750cd4917205f7d8c64267ac5b40093649` |
| `tests/tests/test_differential.rs` | `a8163e3c0cfa8453ebd7a872eb8d54c0e41de824c445d92b4fc93a640f0028b9` |
| `tests/tests/test_runs/inspect.rs` | `9932bc8264a3c6549939b663af5b3c78131d6b95ec342085069424deebd2dcad` |
| `docs/architecture/architecture-current.md` | `b4bdbecef0e363fd13c24f11c517451cb3b4ea75287f85556d8bf3692d5c8105` |
| `crates/spenso/src/network/parsing/materialization.rs` | `7baa2598b395baf8d29b88498da0803da4519eb60638a2e8e919b9202f5dd833` |
| `crates/spenso/src/network/parsing/test.rs` | `a821356cd021f1e5c31c71e1648f903ca34cc0e2ab990d9ba14c68d73d924117` |

The JSON companion additionally records full hashes of pinned C1/C4/C6 context files, all proposal artifacts, static patch checks, exact review scope, and exclusions.

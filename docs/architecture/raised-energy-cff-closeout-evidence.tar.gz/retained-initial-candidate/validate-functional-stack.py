from pathlib import Path
import json,subprocess,time
base=Path('/tmp/raised-stack/closeout')
prep=base/'validation-prep'
revisions=json.loads((base/'reconstructed-candidate.json').read_text())[:6]
first=prep/'boundary-1'
while not (first/'gates-completed').exists():
    for name in ['fmt','check','build','clippy']:
        p=first/(name+'.exit')
        if p.exists() and p.read_text().strip()!='0':
            raise SystemExit('C1 gate failed: '+name)
    time.sleep(3)
jobs={1:['commit1-foundations'],2:['shared-default','shared-all','shared-no-default'],3:['commit3-cff-uv','shared-all','shared-no-default'],4:['commit4-workflows','commit4-scalar-smoke','signed-acceptances','shared-all','shared-no-default'],5:['commit5-phases','signed-acceptances','vertex-rules','shared-all','shared-no-default'],6:['commit6-vakint-uv','shared-all','shared-no-default']}
records=[]
for row in revisions:
    number=row['number'];revision=row['commit']
    if number>1:
        subprocess.run(['jj','-R','/tmp/raised-stack/prefix','edit',revision],check=True)
        subprocess.run(['bash',str(prep/'validate-boundary'),str(number),revision],check=True)
    for job in jobs[number]:
        print(f'Boundary {number}: {job}',flush=True)
        subprocess.run(['bash',str(prep/'final-runtime-job'),revision,job,str(prep/f'boundary-{number}')],check=True)
    records.append(row)
    (base/'functional-stack-progress.json').write_text(json.dumps({'completed_boundaries':records},indent=2)+'\n')
    print(f'Boundary {number} gates and owning tests complete',flush=True)
print('All six functional boundaries complete',flush=True)

#[test_log::test]
fn tensor_reduction_of_powered_scalar_sum_matches_angular_average() {
    use symbolica::atom::AtomCore;

    let vakint = get_vakint(VakintSettings {
        use_dot_product_notation: true,
        epsilon_symbol: "eps".into(),
        ..VakintSettings::default()
    });
    let input = vakint_parse!("(dot(k(1),p(1))+dot(k(1),p(2)))^2*topo(I1L(muvsq,1))").unwrap();
    // Vacuum isotropy gives <k_mu k_nu> = g_mu_nu k^2/D.
    // In particular, both diagonal terms need the same 1/D as the cross term.
    let expected = vakint_parse!(
        "dot(k(1),k(1))*(dot(p(1),p(1))+2*dot(p(1),p(2))+dot(p(2),p(2)))/(4-2*eps)*topo(I1L(muvsq,1))"
    )
    .unwrap();
    let input = vakint.to_canonical(input.as_view(), false).unwrap();
    let expected = vakint.to_canonical(expected.as_view(), false).unwrap();
    let actual = vakint.tensor_reduce(input.as_view()).unwrap();
    assert!((actual - expected).together().cancel().is_zero());
}

from pathlib import Path
from collections import Counter
import datetime
import hashlib
import json
import os
import subprocess

repo = Path('/common/dev/gammaloop/higher-power-energies-review')
root = Path('/tmp/raised-stack/closeout')
folder = root / 'reconstructed-functional-review-data'
data = json.loads((folder / 'inventory.json').read_text())
replay = json.loads((folder / 'original-patch-reapplication.json').read_text())
independent = json.loads((root / 'independent-source-review.json').read_text())
compact_path = Path('/tmp/stack-closeout-compact/review.json')
compact = json.loads(compact_path.read_text())
reviews = {
    (1, 'crates/spenso/src/network/parsing/materialization.rs'): 'Read all 73 removed test lines and neighboring module context. Removes only three private materializer tests; no production/comment change. Corresponding complete public behavior is covered in parsing/test.rs.',
    (1, 'crates/spenso/src/network/parsing/test.rs'): 'Read the import and all 53 added lines, existing mink4 helper and public parser/execution/result calls. Direct four-component Minkowski summation independently checks -2, a and a+b weights. Ambiguous vector products retain their supported opaque scalar meaning. Existing From conversion accepts complete results without selecting Val/Zero/One storage; exact expanded residuals compare values without private slots, dummy names or printed formatting.',
    (1, 'crates/vakint/src/lib.rs'): 'Read both new explanatory lines and complete existing copy-freshening pass. Comment accurately explains FORM dummy-index capture; no production logic changes.',
    (1, 'crates/vakint/tests/tensor_reduction_tests.rs'): 'Read all 22 added regression lines and C1 TestVakint wrappers/settings. The then-only whole-numerator route compares a factorized scalar square with independent vacuum isotropy using exact rational cancellation. Projection setting is absent at C1; all invoked APIs already exist.',
    (4, 'crates/gammalooprs/src/observables/events.rs'): 'Read the complete Serde annotation and generic field/conversion context. Existing vectorize adapter represents structured keys as pair-list values. Explicit Deserialize bound restores the previous derive requirement; FloatLike already supplies Serialize. No new helper, dependency, wrapper or compatibility branch.',
    (4, 'docs/architecture/architecture-current.md'): 'Read all eight added lines and surrounding retention policy. Correctly documents pair-list event JSON, structured amplitude-counterterm keys and empty-list form. This is the direct event Serde payload; separately constructed Python and approach outputs are outside the annotation.',
    (4, 'tests/tests/test_differential.rs'): 'Read all 38 added lines and existing imports. JSON and bincode round trips compare complete maps for empty input and all four key variants with exactly representable signed complex values. No serialization-order, cache/storage or string-format assertions. Current roundtrip behavior is tested; an old-format migration guarantee is not inferred.',
    (4, 'tests/tests/test_runs/inspect.rs'): 'Read all 52 added lines, fixture/evaluation helpers and complete comparison helper. Real gg_hhh inspection exercises retention off/on, public JSON deserialization, numerical parity, grouping, semantic cut identities and complete additional weights. Structured counterterm presence is required when enabled; total stays unchanged. Existing helper does not compare every kinematic/metadata field. Dynamic completeness checks permit implementation changes; events use semantic cut-key matching rather than a fixed traversal oracle.',
    (6, 'crates/vakint/tests/tensor_reduction_tests.rs'): 'Read the complete regression and 22-to-28-line owning migration. Original C6 edits replay unchanged on the amended C5 parent. Only the mode loop, corresponding setting and failure label are added; the input, isotropy oracle and exact cancellation remain the same. This expands behavior coverage with the C6 API, without a compatibility layer.',
}
blob_cache = {}
for commit in data['commits']:
    for row in commit['paths']:
        item = row['new_commit']
        if item and item['type'] == 'blob':
            blob = item['blob']
            if blob not in blob_cache:
                content = subprocess.check_output(['git', '-C', str(repo), 'cat-file', 'blob', blob], env={**os.environ, 'GIT_OPTIONAL_LOCKS': '0'})
                blob_cache[blob] = {'sha256': hashlib.sha256(content).hexdigest(), 'bytes': len(content)}
            row['new_file_content'] = blob_cache[blob]
        for prefix in ['original', 'new']:
            row[prefix + '_status'] = ('unchanged' if not row[prefix + '_owner_changed'] else
                                      'added' if row[prefix + '_parent'] is None else
                                      'deleted' if row[prefix + '_commit'] is None else 'modified')
        key = (commit['number'], row['path'])
        if row['coverage'] == 'same_owned_edit_lines_in_inherited_amended_context':
            proof = next(p for p in replay if p['number'] == commit['number'] and p['path'] == row['path'])
            assert proof['exact_full_file_equality']
            row['coverage'] = 'original_patch_reapplication_exact'
            row['review'] = 'Reuse original owning review: zero-fuzz original patch reapplication on the amended parent produces the complete new file byte-for-byte. No new semantic reread of unchanged hunks is claimed.'
            row['patch_reapplication_proof'] = proof
        elif row['coverage'] == 'changed_owned_hunks_require_fresh_review':
            assert key in reviews
            row['coverage'] = 'prior_review_plus_fresh_owned_hunk_review'
            row['review'] = reviews[key]
            row['fresh_review_findings'] = []
            delta = folder / f"C{commit['number']}--{row['path'].replace('/', '__')}.cumulative.patch"
            row['inspected_complete_additional_delta'] = {'path': str(delta), 'sha256': hashlib.sha256(delta.read_bytes()).hexdigest(), 'bytes': delta.stat().st_size}
            if commit['number'] == 6:
                row['prior_C6_patch_reapplication_proof'] = next(p for p in replay if p['number'] == 6 and p['path'] == row['path'])
        else:
            row['review'] = 'Reuse prior full-diff owning review by exact before/after mode/type/blob equality. Enumeration and hashing are not a fresh semantic reread.'
    commit['coverage_counts'] = dict(Counter(row['coverage'] for row in commit['paths']))
    commit['findings'] = []

independent_matches = []
for source in independent['source_files']:
    content = subprocess.check_output(['git', '-C', str(repo), 'show', f"{data['new_six'][-1]['commit']}:{source['path']}"])
    digest = hashlib.sha256(content).hexdigest()
    match = digest == source['sha256']
    record = {'path': source['path'], 'earlier_review_sha256': source['sha256'], 'reconstructed_C6_sha256': digest, 'earlier_receipt_matches': match}
    if not match:
        assert source['path'] == 'crates/spenso/src/network/parsing/test.rs'
        assert compact['final_source_sha256'][source['path']] == digest
        record.update(final_compact_review_matches=True, reason='The root replaced Val-only matches and panic branches with existing public From conversion in all three tests. Expected values stayed unchanged. Final compact review and this fresh reconstructed-hunk review cover the simplified result handling; the earlier receipt remains unchanged.')
    independent_matches.append(record)
assert sum(r['earlier_receipt_matches'] for r in independent_matches) == 5
for path, expected in compact['final_source_sha256'].items():
    content = subprocess.check_output(['git', '-C', str(repo), 'show', f"{data['new_six'][-1]['commit']}:{path}"])
    assert hashlib.sha256(content).hexdigest() == expected

snapshot = json.loads((root / 'reconstructed-candidate.json').read_text())[:6]
assert snapshot == data['new_six'], 'First-six candidate pins changed during review'
revset = ' | '.join(row['change'] for row in snapshot)
observed = subprocess.check_output(['jj', '--ignore-working-copy', 'log', '--no-graph', '-r', revset, '-T', r'change_id ++ " " ++ commit_id ++ "\n"'], cwd=repo, text=True)
expected = {row['change']: row['commit'] for row in snapshot}
for line in observed.splitlines():
    change, commit = line.split()
    assert expected.pop(change) == commit
assert not expected

prior_sources = []
for revision, path in [('d08776d3bfdb7ed498b4dd6e5eb08dc97112388a', 'docs/architecture/raised-energy-cff-motivation-inventory.json'), ('d55a0f3e9d25e5c64bdb9ef9fb57749ecf680390', 'docs/architecture/raised-energy-cff-stack-review.md')]:
    content = subprocess.check_output(['git', '-C', str(repo), 'show', f'{revision}:{path}'])
    prior_sources.append({'revision': revision, 'path': path, 'sha256': hashlib.sha256(content).hexdigest(), 'bytes': len(content)})

data.update({
    'reviewer': '/root/closeout_validation_plan',
    'recorded_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'status': 'functional_source_review_complete; runtime_validation_and_final_C7_review_separate',
    'scope': 'All owning diff paths in reconstructed C1-C6 are classified using exact original transition matching, zero-fuzz patch replay for inherited context, or complete fresh additional-hunk inspection. C7 is under active finalization and is not certified.',
    'prior_review_sources': prior_sources,
    'prior_ledger_match': 'All 556 original C1-C6 owner/path records match their entries in the prior 579-record seven-commit inventory. No original path is missing or extra. Its other 23 C7 records are outside this functional receipt.',
    'findings': [],
    'rust_and_kiss_review': 'Existing parser/execution/result APIs, TestVakint and physical fixture helpers, direct bounded component folding and exact Atom arithmetic suffice. The sole production edit uses the existing field-level Serde vectorize adapter and preserves the required generic Deserialize bound. No new helper abstraction, dependency or compatibility shim.',
    'test_contract_review': 'Assertions check complete values, supported opaque syntax, complete Serde key/value preservation and actual CLI output. Independent Minkowski components and vacuum isotropy supply mathematical oracles. No new test selects private storage, dummy names, cache counts, fixed traversal or printed expression formatting.',
    'boundary_review': 'C1 has only the whole-numerator Vakint route; C6 adds both-mode coverage with its new setting. C4 helpers and structured amplitude counterterm variant already exist at its boundary. Static API placement is not a compilation result.',
    'independent_source_review': {
        'path': str(root / 'independent-source-review.json'),
        'sha256': hashlib.sha256((root / 'independent-source-review.json').read_bytes()).hexdigest(),
        'source_match_records': independent_matches,
        'final_compact_review': {'path': str(compact_path), 'sha256': hashlib.sha256(compact_path.read_bytes()).hexdigest(), 'both_final_source_hashes_match': True},
        'scope': 'Earlier receipt matches five files. Final compact receipt and fresh reconstructed review cover the simplified public result conversion in the sixth; original evidence is not silently repinned.',
    },
    'first_six_stability': {'candidate_first_six_json_sha256': hashlib.sha256(json.dumps(snapshot, sort_keys=True, separators=(',', ':')).encode()).hexdigest(), 'jj_read_only_observation': observed, 'all_parents_match': True, 'all_author_and_committer_identities_match': True},
    'C7': {'status': 'pending_final_document_review', 'reason': 'Reports are actively being finalized. Final C7 path inventory, document contents, rendered PDFs and reference closure need their final-tree review.'},
    'execution_scope': {'cargo_builds': 0, 'tests_executed': 0, 'backend_runs': 0, 'repository_or_jj_mutations': 0, 'scratch_only_patch_applications': 4, 'license_wrapper_reads': 0},
    'limitations': ['Fresh compiler/runtime gates belong to separate root receipts; previous counts do not certify these revisions.', 'Review reuse retains prior mathematical and performance limits; it supplies no fresh benchmark evidence.', 'The inspection comparison does not assert every kinematic or metadata field.', 'Vacuum angular-average correctness is not full physical integration acceptance.'],
})
data['counts'].update({'exact_transition_reuse': 546, 'original_patch_reapplication_exact': 3, 'fresh_owned_hunk_review_records': 9, 'fresh_unique_paths': 8, 'original_seven_prior_records': 579, 'prior_C7_records_not_claimed': 23, 'all_new_functional_records_classified': 558})
assert sum(sum(c['coverage_counts'].values()) for c in data['commits']) == 558
for path in [root / 'reconstructed-functional-review.json', root / 'reconstructed-functional-review.md']:
    assert not path.exists()
(root / 'reconstructed-functional-review.json').write_text(json.dumps(data, indent=2) + '\n')
lines = ['# Reconstructed functional-commit review', '',
         'No new findings in C1–C6. Every owning diff path is accounted for; reuse of prior review is distinguished from fresh hunk inspection. Compiler/runtime validation is separate, and final C7 review remains pending.', '',
         '| Commit | Current revision | Paths | Exact transitions reused | Original patch replay | Fresh additional hunks |',
         '|---|---|---:|---:|---:|---:|']
for c in data['commits']:
    counts = c['coverage_counts']
    lines.append(f"| {c['number']} — {c['title']} | `{c['commit']}` | {c['new_changed_path_count']} | {counts.get('exact_transition_reuse', 0)} | {counts.get('original_patch_reapplication_exact', 0)} | {counts.get('prior_review_plus_fresh_owned_hunk_review', 0)} |")
lines += ['',
    'The six commits contain **558 commit/path records across 485 distinct paths**. All 556 original records match their entries in the prior 579-record seven-commit inventory. C4 adds two owning records for files it previously left unchanged. Production, tests, configuration, fixtures, schemas, tooling and architecture documentation are all included. The JSON enumerates every original/current parent/commit mode, type, blob ID and current-file SHA256.', '',
    '**546 transitions** have identical before/after blobs and modes. **Three records** inherit amendments while retaining their original edits: C5 architecture/inspection and C6 Vakint implementation. Zero-fuzz reapplication of each original patch in scratch reproduces the complete new file byte-for-byte. C6’s original tensor-test migration also replays exactly before the new mode loop. This reuses exact content; it does not claim that 579 unchanged paths were semantically reread.', '',
    'Fresh review covers all additional hunks in **nine records across eight files**, plus relevant public helpers and type context:', '',
    '- **C1:** Replace three private materializer tests with complete public parsing/execution checks and an independent Minkowski component oracle. Preserve supported opaque arguments. Add the public whole-numerator FORM angular-average regression and explanatory comment; production freshening logic stays unchanged.',
    '- **C4:** Apply the existing Serde pair-list adapter to additional weights and preserve the generic Deserialize requirement. Test complete JSON/bincode values and real physical inspection with retention off/on. Document the actual event JSON representation.',
    '- **C6:** Extend the same angular-average oracle to both input modes when the setting is introduced, without a compatibility API.', '',
    'The new code reuses existing owners, public conversions and helpers. Bounded folds and exact small-expression residuals make the oracles direct. No new test fixes private slots, dummy identities, cache counts, traversal or expression printing. The serialization change adds one field annotation and no new dependency.', '',
    'All first-six parents form the intended linear chain from `395610143576507503fd2c785db3ba62340f4277`; every author and committer is `Lucien Huber <im@lcnbr.ch>`. An end-of-review read-only jj observation matches all pinned change/commit identities.', '',
    'The earlier independent receipt matches five of its six source hashes. The Spenso parsing test was subsequently simplified to use its existing public result-to-Atom conversion; the final compact reviewer’s receipt matches that exact source. This review independently reads the final hunks. Earlier evidence is retained without silently changing its hash.', '',
    'Limits: the inspection helper omits some kinematic/metadata fields, and the Vakint oracle is vacuum tensor algebra rather than physical integration acceptance. Prior mathematical/performance limits remain. This reviewer ran no Cargo, tests or backends and made no repository/history changes; four patch applications occurred only in scratch.', '',
    'Final C7 contents, path inventory, compiled PDFs and reference closure remain for documentation closeout.', '',
    'Evidence: [complete inventory](reconstructed-functional-review.json), [exact patch replay](reconstructed-functional-review-data/original-patch-reapplication.json), [independent source review](independent-source-review.json), [final compact review](/tmp/stack-closeout-compact/review.json).', '']
(root / 'reconstructed-functional-review.md').write_text('\n'.join(lines))
print(json.dumps({'json': str(root / 'reconstructed-functional-review.json'), 'markdown': str(root / 'reconstructed-functional-review.md'), 'counts': data['counts'], 'findings': 0}))

# Independent final-runtime reconciliation

PASS: all ten selections were reconciled directly from their raw Nextest lists, complete numbered outcomes, summaries, guards, commands, contexts and source audits at `a474c96016a6236d0e91cb67dd284fe91a6c38b7` / tree `1f4a64901b2d7df8bf84629ff47fa098b83e8918`. The collector's parsing functions were not imported.

The original plan remains open pending the complete independent GL00 common-chart reconstruction certificate. This receipt certifies the executed selections and makes no claim that every original-plan requirement is complete.

| Selection | Executed | Passed | Failed | Skipped |
|---|---:|---:|---:|---:|
| curated | 2065 | 2065 | 0 | 297 |
| commit5-phases | 212 | 212 | 0 | 1205 |
| signed-acceptances | 4 | 4 | 0 | 0 |
| commit6-vakint-uv | 241 | 241 | 0 | 619 |
| scalar-all | 166 | 166 | 0 | 107 |
| shared-default | 37 | 37 | 0 | 0 |
| shared-all | 108 | 108 | 0 | 0 |
| shared-no-default | 37 | 37 | 0 | 0 |
| ufo-model-parity | 1 | 1 | 0 | 378 |
| vertex-rules | 1 | 1 | 0 | 725 |

There are 2872 actual executions and 2207 distinct binary/test identities across overlapping selections and feature configurations. Repeated identical live/final outcome rows are counted once. Every selected identity has a complete matching outcome; all collector counts, statuses, configurations and pairwise overlaps match the independent reconstruction.

All ten post-job audits and both full-workspace runtime audits match the immutable tracked inventory. The frozen CLI SHA remains `c48ae9aa1335adabb0899fb998ad6a97daddf2f15033a779d4711caca023f931` after all runtime jobs. Physical GL04 replay has its own independent review; no extra physics or performance result is inferred here.

This reviewer ran no Cargo, tests, CLI replay or jj command and edited no tracked source. Manual physical PySecDec integrations remain outside coverage. Four Nextest workers is a scheduler budget, and the 30 GB guard is a sampled RSS bound. Final reports, PDFs, separate final-document gates and bookmark closure require later external receipts.

/tmp/raised-stack/run bash /tmp/raised-stack/closeout/validation-prep/remaining-validation list vertex-rules /tmp/raised-stack/closeout/validation-prep/boundary-5/tests 

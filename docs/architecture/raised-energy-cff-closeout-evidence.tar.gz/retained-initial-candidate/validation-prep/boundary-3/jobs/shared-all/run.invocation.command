/tmp/raised-stack/run bash /tmp/raised-stack/closeout/validation-prep/remaining-validation run shared-all /tmp/raised-stack/closeout/validation-prep/boundary-3/tests 

# Fresh closeout validation preparation

No Cargo build, test, or history mutation was launched while preparing this folder. `run` is invocation-only and was not read, hashed, or archived. These scripts reuse the recorded validation runners and conservative resource settings. Historical times below are scheduling estimates only; no historical count certifies this closeout.

## Boundary workflow

Root must select `/tmp/raised-stack/prefix` at each exact immutable new commit. Run one Cargo pipeline at a time against the shared target. Each pipeline itself runs four compilation/test workers under a 30 GB process-tree RSS guard; nextest resource groups remain active. Start the driver **directly**, because it invokes the licensed environment once per Cargo step:

```
bash /tmp/raised-stack/closeout/validation-prep/validate-boundary 1 FULL_NEW_COMMIT_ID
```

Repeat for boundaries 2–7 after root selects each commit. Driver runs fmt before check, workspace all-target check/build/Clippy with `--locked`, shared CFF all-feature/no-default all-target checks from C2 onward, optional Python API check at 4, optional Vakint community module check at 6. It records the full revision/tree, checks tracked prefix bytes before/after gates, and refreshes every tracked regular-file mtime at C1 because prior cache provenance is unknown. C2–C7 require the previous boundary's certificate and refresh only added or blob/mode-changed regular files; identical source timestamps are preserved. Per-file old/new Git blob IDs and timestamps, unchanged-source records, inventory hashes, and prior certificate hashes are retained. A missing previous source certificate is an error. Documentation-only changes preserve executable-source mtimes after byte identity is established. Logs have no overwrite path. A failure stops dependent gates without retry.

Then run each owning job from the following table using:

```
bash /tmp/raised-stack/closeout/validation-prep/final-runtime-job FULL_NEW_COMMIT_ID JOB /tmp/raised-stack/closeout/validation-prep/boundary-1
```

Use the appropriate stage in the output path. The runner records an actual nextest JSON list, execution log, exact command, revision/tree, head checks, and guard completion. Do not move prefix while a job is active. Jobs automatically use four test workers, zero retries, no snapshot updates, no stale-state cleanup overrides, and explicit manual PySecDec exclusions. The recorded warning policy is the repository-supported `--allow-warnings` equivalent to avoid a new rustflags fingerprint; check/Clippy still report warnings.

| Boundary | Required jobs |
|---|---|
| 1 | `commit1-foundations` (shared CFF does not exist until C2) |
| 2 | `shared-default`, `shared-all`, `shared-no-default` |
| 3 | `commit3-cff-uv`, `shared-all`, `shared-no-default` |
| 4 | `commit4-workflows`, `commit4-scalar-smoke`, `signed-acceptances`, `shared-all`, `shared-no-default` |
| 5 | `commit5-phases`, `signed-acceptances`, `vertex-rules`, `shared-all`, `shared-no-default` |
| 6 | `commit6-vakint-uv`, `shared-all`, `shared-no-default` |
| 7 | The ten final-runtime jobs below |

C1 selects all ordinary Spenso, Spenso HEP, Idenso, Vakint, Linnet and Linnest tests; this includes new outward compact-tensor regressions without coupling to their names. C3 selects core CFF and UV modules plus ordinary renormalization and UV integration binaries. Existing owning/final selectors are otherwise unchanged. C4 includes the exact new test_differential::additional_event_weights_roundtrip_preserves_all_keys_and_values identity; the existing test_runs inspection selector includes inspect::inspect_json_preserves_retained_events_and_additional_weights.

## Final runtime at boundary 7

Run the following job names separately through `final-runtime-job` against the same frozen revision and `boundary-7` directory:

```
curated
commit5-phases
signed-acceptances
commit6-vakint-uv
scalar-all
shared-default
shared-all
shared-no-default
ufo-model-parity
vertex-rules
```

`scalar-all` is the actual standard and slow namespace selection, release profile, `--run-ignored all --ignore-default-filter --test-threads 4 --retries 0 --no-fail-fast`. It does not invoke the scalar wrapper with its forced single worker. The curated package set matches `just test_gammaloop base`. The exact approved vertex test alone bypasses the profile's failing-class exclusions. Shared feature runs are standalone package invocations, so workspace feature unification cannot quietly re-enable the disabled default feature. Manual physical PySecDec stays excluded; the Rust backend adapter tests remain included.

`ufo-model-parity` is last among ordinary optional-feature consumers to limit feature-change rebuilds; it invokes the existing pinned Python environment, without reading the private wrapper. The optional installed-Python subprocess suite is not claimed by these commands.

## Evidence collection

When all seven boundaries have complete receipts:

```
/tmp/raised-stack/python /tmp/raised-stack/closeout/validation-prep/collect-boundary-evidence.py --through 7 --output /tmp/raised-stack/closeout/validation-prep/boundary-evidence-complete.json
/tmp/raised-stack/python /tmp/raised-stack/closeout/validation-prep/collect-final-runtime-evidence.py --revision FULL_NEW_COMMIT_ID --tree FULL_NEW_TREE_ID --log-root /tmp/raised-stack/closeout/validation-prep/boundary-7 --output /tmp/raised-stack/closeout/validation-prep/runtime-evidence-complete.json
```

The boundary collector requires the exact table's jobs, successful pre/post tracked-byte audits, the mtime receipt linked to the previous certified revision, and final head equality; missing receipts or tests remain incomplete. The runtime collector compares selected JSON identities with actual completed statuses, deduplicates repeated nextest status lines, preserves feature/configuration identities, and requires the explicit ten selections. It does not add overlapping counts as distinct tests.

Use `audit-tracked-worktrees.py --revision REV --label LABEL --output FRESH_PATH` only when root and prefix both intentionally match that revision; use before and after final runtime. `audit-prefix.py` is the same previously reviewed auditor restricted to the selected prefix and is called by boundary gates. Neither mutates source or history.

## Runtime and caching observations

Previous changed-boundary all-target builds took 3m51s at C3, 19m39s at C4, 18m45s at C5, 21m12s at C6; cached documentation-only gates took <1s each after fmt (~5s). These are prior-run observations, not estimates with confidence bounds. Current revalidation may rebuild more or less, especially C1 changes propagating through consumers. Historical runtime-only durations were curated 466s, phase 31s, signed acceptances 122s, Vakint/UV 74s, scalar release 942s, shared default/all/no-default 5/22/5s, UFO and vertex <1s each. Allow roughly half an hour for final test execution plus builds; the seven-boundary rebuild chain can take hours.

Do not double-wrap `run`: PATH duplication changes PyO3's tracked build input and caused a reproduced dependency rebuild. Preserve the same `CARGO_TARGET_DIR`, flags and single-wrapper context. Standalone shared features and optional UFO/community features legitimately change resolution. Dev-optim versus release necessarily changes artifacts. Do not run two Cargo jobs/checkouts against one target at once. Cargo source-mtime reuse across isolated checkouts previously produced stale artifacts; verify real source changes caused compilation (the prepared driver refreshes all initial sources and only changed source blobs at subsequent boundaries), and never infer source identity solely from the requested revision in a log. Frozen tracked bytes and exact build log receipts are separate evidence.

## Safe jj history consolidation (root-owned, not executed here)

1. Record full commit and tree IDs, operation checkpoint, and all branch/bookmark/remote refs before rewriting.
2. `jj duplicate 'BASE::CLOSEOUT_TIP ~ BASE'` (substitute the actual pinned identifiers and pass one quoted revset) duplicates the complete local seven-commit chain plus audit/freshening/fix followups. Without destination options it retains the original base and uses duplicated ancestors. Inspect its emitted old-to-new mapping.
3. Select the duplicated tip. Use `jj squash --from DUPLICATED_FOLLOWUP --into DUPLICATED_OWNER --use-destination-message FILESETS...`. C1 owns Spenso and the powered-dot converter comment/regression; C4 owns event JSON behavior/regressions; C7 owns reports/evidence. Use precise files or interactive hunks where a file spans owners. Each squash rewrites descendants, so use stable duplicated change IDs after the first mutation.
4. Full final followup payload can be squashed into C7 once functional files have been moved. Empty sources disappear unless `--keep-emptied` is requested; do not keep them in the final seven. If the working commit is abandoned jj creates an empty working commit, so explicitly select the duplicated C7 afterward.
5. Compare exact tip trees before and after every fold and before/after consolidation. Recompute per-commit source ownership and source-to-new mapping, then set only the requested reviewed local bookmark to final C7. No push, thermal, threshold, or remote-ref changes.
6. Preserve existing descriptions and full user request blocks; append this authorized closeout request deliberately with `jj describe --stdin`/a prepared file, not shell-interpolated multiline text.

The original seven and existing two followups remain reachable through their original change IDs/recorded operation and any deliberately retained local refs. Do not alter unrelated refs to satisfy old closure verifiers: old verify-final-closure.py is pinned to obsolete owner IDs/test blobs and is unsuitable without a separately reviewed new manifest. Current prepared collectors only certify commands/results; they do not assert final history closure.

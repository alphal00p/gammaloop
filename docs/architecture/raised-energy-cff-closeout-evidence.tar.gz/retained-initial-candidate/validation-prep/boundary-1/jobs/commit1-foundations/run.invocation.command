/tmp/raised-stack/run bash /tmp/raised-stack/closeout/validation-prep/remaining-validation run commit1-foundations /tmp/raised-stack/closeout/validation-prep/boundary-1/tests 

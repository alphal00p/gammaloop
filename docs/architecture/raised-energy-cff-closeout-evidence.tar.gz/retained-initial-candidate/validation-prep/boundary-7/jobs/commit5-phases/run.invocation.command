/tmp/raised-stack/run bash /tmp/raised-stack/closeout/validation-prep/remaining-validation run commit5-phases /tmp/raised-stack/closeout/validation-prep/boundary-7/tests 

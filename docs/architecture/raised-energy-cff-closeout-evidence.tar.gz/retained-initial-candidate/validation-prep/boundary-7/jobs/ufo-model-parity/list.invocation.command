/tmp/raised-stack/run bash /tmp/raised-stack/closeout/validation-prep/remaining-validation list ufo-model-parity /tmp/raised-stack/closeout/validation-prep/boundary-7/tests 

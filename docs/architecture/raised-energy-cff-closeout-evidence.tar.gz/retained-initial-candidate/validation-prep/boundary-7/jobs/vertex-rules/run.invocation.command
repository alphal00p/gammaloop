/tmp/raised-stack/run bash /tmp/raised-stack/closeout/validation-prep/remaining-validation run vertex-rules /tmp/raised-stack/closeout/validation-prep/boundary-7/tests 

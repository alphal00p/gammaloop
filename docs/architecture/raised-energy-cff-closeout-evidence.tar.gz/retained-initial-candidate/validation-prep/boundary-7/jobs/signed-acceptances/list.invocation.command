/tmp/raised-stack/run bash /tmp/raised-stack/closeout/validation-prep/remaining-validation list signed-acceptances /tmp/raised-stack/closeout/validation-prep/boundary-7/tests 

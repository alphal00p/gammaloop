/tmp/raised-stack/run bash /tmp/raised-stack/closeout/validation-prep/remaining-validation list curated /tmp/raised-stack/closeout/validation-prep/boundary-7/tests 

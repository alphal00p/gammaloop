/tmp/raised-stack/run bash /tmp/raised-stack/closeout/validation-prep/remaining-validation run curated /tmp/raised-stack/closeout/validation-prep/boundary-7/tests 

/tmp/raised-stack/run bash /tmp/raised-stack/closeout/validation-prep/remaining-validation list commit4-scalar-smoke /tmp/raised-stack/closeout/validation-prep/boundary-4/tests 

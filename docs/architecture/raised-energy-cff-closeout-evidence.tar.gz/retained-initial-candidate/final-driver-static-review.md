# Prepared final-driver static review

No open findings in the prepared orchestration. This is a source review only; no Cargo, tests, CLI replay or jj commands were run by this reviewer. The JSON receipt pins every reviewed helper.

The driver selects the immutable C7 prefix, runs all required gates, audits both workspaces, copies and hashes the CLI produced by the successful all-target build, executes the GL04 replay, then runs the ten final selections and both collectors. Source selection occurs once. Read-only pin checks avoid working-copy snapshotting. Every Cargo child enters the existing licensed environment once.

The CLI copy follows Clippy and shared CFF cargo-check feature gates, which do not replace the CLI executable. It precedes all runtime Nextest feature jobs. A successful build/log hash, source audit hash and matching original/copy hashes are retained as provenance.

Four Nextest workers and a 30 GB process-tree RSS guard bound ordinary scheduling and memory; acceptance tests can start internal worker threads. Ordinary runtime jobs have no practical global time cap. Physical replay alone has the explicit 40-second CLI and 90-second outer limits. No retries or snapshot updates are enabled. Manual physical PySecDec integrations remain outside coverage, and existing warnings remain visible under the recorded warning-policy exception.

The separate frozen-stack inventory tool is syntax checked and unexecuted. It requires both new archive files in the actual immutable C7 tree, records all seven owning diffs, and compares C1-C6 mode/type/blob transitions with the existing review receipt. It does not claim semantic C7 review or insert hypothetical paths. Final rendered-document and archive review require a separate external receipt.

    #[test]
    fn gl00_gl04_planned_lifts_match_post_t_numerators_in_common_loop_coordinates() -> Result<()> {
        test_initialise()?;
        // The frozen GL04 Taylor numerator below belongs to the two-line
        // self-energy on owners 5 and 6. Retain that physical incidence while
        // reconstructing its raised denominators through the production API.
        let gl04: Graph = dot!(digraph gl04_t2_source_certificate {
            edge [num=1 mass=1]
            node [num=1]
            incoming [style=invis]
            outgoing [style=invis]
            incoming -> v1 [id=0]
            v0 -> v3 [id=1 lmb_id=0]
            v0 -> v5 [id=2]
            v1 -> v2 [id=3 lmb_id=1]
            v1 -> v3 [id=4]
            v2 -> v4 [id=5 lmb_id=2]
            v2 -> v4 [id=6]
            v3 -> v5 [id=7]
            v4 -> v5 [id=8]
            v0 -> outgoing [id=9]
        })?;
        // This GL00 graph and owner-local Q5^0 probe are used by the scalar LU
        // regression. Its first bubble has Q4=q, Q3=p and Q5=-q-p; the complete
        // T<=1 numerator below retains the odd fixed-owner factor and soft p.
        let gl00: Graph = dot!(digraph gl00_t1_source_certificate {
            edge [num=1 mass=0]
            node [num=1]
            incoming [style=invis]
            outgoing [style=invis]
            incoming -> v0 [id=0 mass=1]
            v0 -> v1 [id=1 lmb_id=0]
            v0 -> v5 [id=2]
            v1 -> v3 [id=3]
            v2 -> v3 [id=4 lmb_id=1]
            v2 -> v3 [id=5 num="Q(5,spenso::cind(0))"]
            v2 -> v4 [id=6]
            v4 -> v5 [id=7 lmb_id=2]
            v4 -> v5 [id=8 mass=1]
            v1 -> outgoing [id=9 mass=1]
        })?;
        for (case, graph, owner_a, owner_b, taylor_order, powers) in [
            ("gl04_t2", gl04, EdgeIndex(5), EdgeIndex(6), 2, [2, 3]),
            ("gl00_t1", gl00, EdgeIndex(4), EdgeIndex(5), 1, [1, 2]),
        ] {
            let q_a = FunctionBuilder::new(GS.emr_mom).add_arg(usize::from(owner_a)).finish();
            let minus_q_a = -q_a.clone();
            let tagged = |owner: EdgeIndex, derived: bool, hard: &Atom, index: Atom| {
                FunctionBuilder::new(GS.emr_mom)
                    .add_arg(GS.uv_momentum_provenance_tag(
                        Atom::num(usize::from(owner) as i64).as_view(),
                        derived,
                        hard.as_view(),
                    ))
                    .add_arg(index)
                    .finish()
            };
            let tagged_momentum = |owner: EdgeIndex, hard: &Atom| {
                FunctionBuilder::new(GS.emr_mom)
                    .add_arg(GS.uv_momentum_provenance_tag(
                        Atom::num(usize::from(owner) as i64).as_view(),
                        true,
                        hard.as_view(),
                    ))
                    .finish()
            };
            let q_a_fixed_0 = tagged(owner_a, false, &q_a, GS.cind(0));
            let q_b_fixed_0 = tagged(owner_b, false, &minus_q_a, GS.cind(0));
            let q_a_derived = (0..4)
                .map(|index| tagged(owner_a, true, &q_a, GS.cind(index)))
                .collect::<Vec<_>>();
            let q_b_derived = (0..4)
                .map(|index| tagged(owner_b, true, &minus_q_a, GS.cind(index)))
                .collect::<Vec<_>>();
            let uv_mass_squared = Atom::var(GS.m_uv_expansion).pow(2);
            // Taylor payloads retain the vacuum mass in their full expression
            // and the expansion mass in denominator metadata. The final
            // integrand identifies these symbols; certify both fields first.
            let vacuum_mass_squared = Atom::var(GS.m_uv_vacuum).pow(2);
            let minkowski_square = |components: &[Atom]| {
                components[0].clone().pow(2)
                    - components[1..]
                        .iter()
                        .fold(Atom::Zero, |sum, component| sum + component.clone().pow(2))
            };
            let d_a = GS.den(
                usize::from(owner_a),
                tagged_momentum(owner_a, &q_a),
                uv_mass_squared.clone(),
                minkowski_square(&q_a_derived) - &vacuum_mass_squared,
            );
            let d_b = GS.den(
                usize::from(owner_b),
                tagged_momentum(owner_b, &minus_q_a),
                uv_mass_squared.clone(),
                minkowski_square(&q_b_derived) - &vacuum_mass_squared,
            );
            let p = (0..4)
                .map(|index| {
                    Atom::var(symbolica::symbol!(format!(
                        "{case}_certificate::p_{index}"
                    )))
                })
                .collect::<Vec<_>>();
            let p_squared = minkowski_square(&p);
            let p_dot_minus_q = &p[0] * &q_b_derived[0]
                - p[1..]
                    .iter()
                    .zip(&q_b_derived[1..])
                    .fold(Atom::Zero, |sum, (left, right)| sum + left * right);
            let coupling_squared = Atom::var(symbolica::symbol!("UFO::SCALAR_COUPLING")).pow(2);
            let planned_numerator = if taylor_order == 2 {
                -q_a_fixed_0.pow(2)
                    * (-&d_a * d_b.clone().pow(2) + (&uv_mass_squared + &p_squared) * &d_a * &d_b
                        - Atom::num(4) * p_dot_minus_q.clone().pow(2) * &d_a
                        + &uv_mass_squared * d_b.clone().pow(2)
                        + Atom::num(2) * &p_dot_minus_q * &d_a * &d_b)
            } else {
                // Retain the complete recorded GL00 child coefficient, including
                // its two scalar vertices. Only the denominator derivative may
                // use the new owner-5 occurrence; its original numerator stays fixed.
                &coupling_squared * (&d_b * (&q_b_fixed_0 - &p[0])
                    + Atom::num(2) * &p_dot_minus_q * &q_b_fixed_0)
            };

            let denominators = [(owner_a, &q_a, powers[0]), (owner_b, &minus_q_a, powers[1])]
                .into_iter()
                .flat_map(|(source_edge, momentum, count)| {
                    std::iter::repeat_n(
                        FourDDenominator {
                            source_edge,
                            momentum: momentum.clone(),
                            mass_squared: uv_mass_squared.clone(),
                            full_expr: Atom::one(),
                        },
                        count,
                    )
                })
                .collect::<Vec<_>>();
            let uv_filter = graph
                .get_edge_subgraph(owner_a)
                .union(&graph.get_edge_subgraph(owner_b));
            let uv_subgraph = InternalSubGraph::cleaned_filter_optimist(uv_filter, graph.as_ref());
            let sub_lmb = graph.try_compatible_sub_lmb(
                &uv_subgraph,
                graph.dummy_stripped_external_flows_of(&uv_subgraph),
                &graph.loop_momentum_basis,
            )?;
            let source = GraphThreeDSource::from_exact_denominators_in_uv_sub_lmb(
                &graph,
                &denominators,
                [owner_a, owner_b],
                [],
                &sub_lmb,
                ExactUvSubLmbFrame::TaylorVacuum,
            )?;
            let parsed = source.to_three_d_parsed_graph()?;
            assert!(validate_parsed_graph(&parsed).ok);
            let mut mapper = source
                .exact_source_energy_mapper()
                .expect("the reconstructed source has an exact map");
            let candidates = mapper.equivalent_energy_candidates([owner_a, owner_b])?;
            let plan = EnergyPowerAnalyzer::for_physical_emr_edges([owner_a, owner_b])
                .plan_atom_assignment(&planned_numerator, &candidates)?;

            // First retain distinct symbols for the occurrence samples. They are
            // not independent proof variables: the structural invariant before
            // the common-LMB diagonal is that original factors stay on the base
            // occurrence while denominator-derived factors use only new copies.
            let mut fixed_assignments = BTreeMap::<EdgeIndex, Vec<usize>>::new();
            let mut derived_assignments = BTreeMap::<EdgeIndex, BTreeSet<usize>>::new();
            let _ = plan.map_factors(|factor, assignments| {
                let mut factor_provenance = BTreeSet::new();
                let _ = factor.replace_map(|view, _, _| {
                    let AtomView::Fun(momentum) = view else {
                        return;
                    };
                    if momentum.get_symbol() != GS.emr_mom || momentum.get_nargs() < 1 {
                        return;
                    }
                    if let Some((owner, role, _)) = GS.uv_momentum_provenance_data(momentum.get(0)) {
                        factor_provenance.insert((owner, role));
                    }
                });
                for (&owner, &occurrence) in assignments {
                    let roles = factor_provenance
                        .iter()
                        .filter_map(|(provenance_owner, role)| {
                            (*provenance_owner == owner).then_some(*role)
                        })
                        .collect::<BTreeSet<_>>();
                    assert_eq!(
                        roles.len(),
                        1,
                        "each energy-bearing planned factor must have one provenance role per owner"
                    );
                    let role = *roles.first().expect("one provenance role was certified");
                    match role {
                        UvMomentumProvenanceRole::DenominatorDerived => {
                            derived_assignments
                                .entry(owner)
                                .or_default()
                                .insert(occurrence);
                        }
                        UvMomentumProvenanceRole::TaylorFixed
                        | UvMomentumProvenanceRole::PhysicalSourceFixed => {
                            fixed_assignments.entry(owner).or_default().push(occurrence);
                        }
                        UvMomentumProvenanceRole::DenominatorDerivedSoft => {
                            panic!("a soft coefficient must not own a child-contour occurrence");
                        }
                    }
                }
                Ok::<_, std::convert::Infallible>(factor.clone())
            });
            for (owner, assignments) in &fixed_assignments {
                let base = mapper.source_edge_occurrences[owner]
                    .iter()
                    .find(|occurrence| occurrence.is_base)
                    .expect("a retained base occurrence");
                assert!(
                    assignments
                        .iter()
                        .all(|assignment| *assignment == base.energy_edge_id)
                );
            }
            for (owner, assignments) in &derived_assignments {
                assert!(assignments.iter().all(|assignment| {
                    mapper.source_edge_occurrences[owner]
                        .iter()
                        .any(|occurrence| {
                            !occurrence.is_base && occurrence.energy_edge_id == *assignment
                        })
                }));
            }

            let mut edge_energy_map = vec![
                LinearEnergyExpr::zero();
                source
                    .exact_energy_edge_index_map
                    .as_ref()
                    .unwrap()
                    .orientation_edge_count
            ];
            let mut occurrence_energies = BTreeMap::new();
            for (index, occurrence) in source.exact_occurrences.iter().enumerate() {
                let energy = Atom::var(symbolica::symbol!(format!(
                    "{case}_certificate::P_{}_0",
                    occurrence.energy_edge_id
                )));
                let witness_edge = EdgeIndex(edge_energy_map.len() + index);
                mapper.exact_ose_replacements.push(Replacement::new(
                    crate::utils::ose_atom_from_index(witness_edge).to_pattern(),
                    energy.to_pattern(),
                ));
                edge_energy_map[occurrence.energy_edge_id] = LinearEnergyExpr::ose(witness_edge, 1);
                occurrence_energies.insert(occurrence.local_edge_id, energy);
            }
            let q_0 = Atom::var(symbolica::symbol!(format!("{case}_certificate::q_0")));
            let mut loop_energy_map = vec![LinearEnergyExpr::zero(); parsed.loop_names.len()];
            assert_eq!(
                loop_energy_map.len(),
                1,
                "the reconstructed self-energy has one active loop"
            );
            let loop_witness = EdgeIndex(edge_energy_map.len() + source.exact_occurrences.len());
            mapper.exact_ose_replacements.push(Replacement::new(
                crate::utils::ose_atom_from_index(loop_witness).to_pattern(),
                q_0.to_pattern(),
            ));
            loop_energy_map[0] = LinearEnergyExpr::ose(loop_witness, 1);
            let mapped = mapper.map_planned_numerator(&loop_energy_map, &edge_energy_map, &plan)?;
            let mapped = GS.erase_uv_momentum_provenance(
                &mapped
                    .replace(GS.den(W_.a_, W_.b_, W_.c_, W_.d_))
                    .with(W_.d_),
            );
            let q_spatial = (1..4)
                .map(|index| GS.emr_mom(owner_a, GS.cind(index)))
                .collect::<Vec<_>>();
            let spatial_square = q_spatial
                .iter()
                .fold(Atom::Zero, |sum, component| sum + component.clone().pow(2));

            // All serial occurrences denote the same formal loop momentum in the
            // reconstructed graph LMB. The occurrence-specific samples used by
            // generalized CFF are deliberately not independent proof variables.
            let common_chart = occurrence_energies
                .iter()
                .map(|(local, energy)| {
                    let signature = &parsed.internal_edges[*local].signature;
                    assert_eq!(signature.loop_signature.len(), 1);
                    assert!(
                        signature
                            .external_signature
                            .iter()
                            .all(|coefficient| *coefficient == 0)
                    );
                    Replacement::new(
                        energy.to_pattern(),
                        (Atom::num(signature.loop_signature[0]) * &q_0).to_pattern(),
                    )
                })
                .collect::<Vec<_>>();
            let mapped = mapped.replace_multiple(&common_chart);
            let d = q_0.clone().pow(2) - &spatial_square - &vacuum_mass_squared;
            let p_dot_minus_q = -&p[0] * &q_0
                + p[1..]
                    .iter()
                    .zip(&q_spatial)
                    .fold(Atom::Zero, |sum, (left, right)| sum + left * right);
            let post_t = if taylor_order == 2 {
                -q_0.pow(2)
                    * (-d.clone().pow(3) + (&uv_mass_squared + p_squared) * d.clone().pow(2)
                        - Atom::num(4) * p_dot_minus_q.clone().pow(2) * &d
                        + &uv_mass_squared * d.clone().pow(2)
                        + Atom::num(2) * &p_dot_minus_q * d.pow(2))
            } else {
                // Independently differentiate (-q0-lambda*p0)/(D4(lambda)*D5(lambda)):
                // D4=D+O(lambda^2), D5=D+2*lambda*p.q+O(lambda^2).
                // T0+T1 has numerator (-q0-p0)*D+2*q0*(p.q) over D^3.
                let p_dot_q = &p[0] * &q_0 - p[1..].iter().zip(&q_spatial)
                    .fold(Atom::Zero, |sum, (left, right)| sum + left * right);
                &coupling_squared * ((-&q_0 - &p[0]) * &d + Atom::num(2) * &q_0 * p_dot_q)
            };
            // Compare in the common chart, normalizing numeric signs without
            // distributing the retained post-Taylor numerator or its factors.
            // Only the squared contraction is even: preserve its separate linear
            // occurrences so this identity cannot conceal a momentum-sign error.
            let squared_opposite_dot = (-&p_dot_minus_q).expand_num().pow(2);
            let retained_dot_square = p_dot_minus_q.expand_num().pow(2);
            let difference = (mapped
                .expand_num()
                .replace(squared_opposite_dot)
                .with(retained_dot_square)
                .collect_factors()
                - post_t.expand_num().collect_factors())
            .collect_factors();
            assert!(
                difference.is_zero(),
                "the actual {case} occurrence plan must commute with substitution into one common formal loop momentum: {difference}"
            );

            // Certify the denominator independently so its evenness cannot hide a
            // sign error in the numerator check above. The owner-built source has
            // two serial copies of D(+q) and three of D(-q) for GL04; GL00 has
            // one and two respectively. Each complete denominator product uses
            // the same common-LMB carrier, with its physical owners kept separate.
            let minus_q_denominator = (-&q_0).pow(2)
                - q_spatial
                    .iter()
                    .fold(Atom::Zero, |sum, component| sum + (-component).pow(2))
                - &uv_mass_squared;
            let expansion_denominator = q_0.clone().pow(2) - &spatial_square - &uv_mass_squared;
            let post_t_denominator = expansion_denominator.pow(powers[0] as i64)
                * minus_q_denominator.pow(powers[1] as i64);
            let mut reconstructed_denominator = Atom::one();
            let mut reconstructed_multiplicities = BTreeMap::new();
            for occurrence in &source.exact_occurrences {
                let edge = &parsed.internal_edges[occurrence.local_edge_id];
                let denominator = &denominators[occurrence.original_occurrence];
                assert!(
                    source.uv_edges.contains(&denominator.source_edge),
                    "every denominator stays in the self-energy component"
                );
                *reconstructed_multiplicities
                    .entry(denominator.source_edge)
                    .or_insert(0) += 1;
                assert_eq!(
                    edge.mass_key.as_deref(),
                    Some(uv_mass_squared.to_canonical_string().as_str())
                );
                assert!(
                    edge.signature
                        .external_signature
                        .iter()
                        .all(|coefficient| *coefficient == 0)
                );
                let [coefficient] = edge.signature.loop_signature.as_slice() else {
                    panic!("each reconstructed denominator must belong to the one-loop component")
                };
                assert_eq!(
                    coefficient.abs(),
                    1,
                    "each serial propagator carries one common loop momentum"
                );
                let routed = Atom::num(*coefficient);
                reconstructed_denominator *= (&routed * &q_0).pow(2)
                    - q_spatial.iter().fold(Atom::Zero, |sum, component| {
                        sum + (&routed * component).pow(2)
                    })
                    - &denominator.mass_squared;
            }
            assert_eq!(
                reconstructed_multiplicities,
                BTreeMap::from([(owner_a, powers[0]), (owner_b, powers[1])])
            );
            let denominator_difference = (post_t_denominator - reconstructed_denominator)
                .expand()
                .together();
            assert!(
                denominator_difference.is_zero(),
                "the {case} owner-built denominator must equal the complete reconstructed source in the common loop chart: {denominator_difference}"
            );
        }
        Ok(())
    }


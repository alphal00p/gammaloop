#!/usr/bin/env python3
"""Compare actual tracked files/modes in both workspaces to an explicit Git revision.

Reads immutable Git objects and filesystem bytes only. Ignores all untracked
files, never restores anything, never invokes jj, and writes one fresh scratch
JSON receipt. Use before and after final runtime with different output paths.
"""

import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import stat
import subprocess

SCRATCH = Path('/tmp/raised-stack/closeout/validation-prep')
REPOSITORY = Path('/common/dev/gammaloop/higher-power-energies-review')
WORKSPACES = [Path('/tmp/raised-stack/prefix')]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--revision', required=True, help='Full immutable 40-character commit ID')
    parser.add_argument('--label', required=True, help='Observation label, e.g. pre-runtime or post-runtime')
    parser.add_argument('--output', required=True, type=Path, help='Fresh JSON path inside task scratch directory')
    args = parser.parse_args()
    assert len(args.revision) == 40 and all(c in '0123456789abcdef' for c in args.revision), 'Use a full lowercase commit ID'
    output = args.output.resolve()
    assert output.is_relative_to(SCRATCH) and not output.exists(), 'Receipt must be a new scratch file'
    assert output.parent.is_dir(), 'Create the intended scratch receipt directory separately'
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    commands = []
    env = {**os.environ, 'GIT_OPTIONAL_LOCKS': '0'}

    def git(*argv):
        command = ['git', '-C', str(REPOSITORY), *argv]
        commands.append(command)
        return subprocess.check_output(command, env=env)

    assert git('rev-parse', args.revision + '^{commit}').decode().strip() == args.revision
    tree = git('rev-parse', args.revision + '^{tree}').decode().strip()
    object_format = git('rev-parse', '--show-object-format').decode().strip()
    assert object_format == 'sha1', 'This prepared audit expects the observed SHA-1 repository'
    raw_inventory = git('ls-tree', '-rz', '--full-tree', args.revision)
    entries = []
    for record in raw_inventory.split(b'\0'):
        if not record:
            continue
        metadata, raw_path = record.split(b'\t', 1)
        mode, object_type, expected_blob = metadata.decode().split()
        relative = PurePosixPath(os.fsdecode(raw_path))
        assert relative.parts and not relative.is_absolute() and '..' not in relative.parts
        entries.append((mode, object_type, expected_blob, relative, raw_path))
    assert entries, 'Refuse an empty inventory'

    def signature(info):
        return (info.st_dev, info.st_ino, info.st_mode, info.st_size,
                info.st_mtime_ns, info.st_ctime_ns)

    workspaces = []
    for workspace in WORKSPACES:
        assert workspace.is_dir() and not workspace.is_symlink(), f'Workspace must be an ordinary directory: {workspace}'
        mismatches = []
        bytes_checked = 0
        blobs_hashed = 0
        entries_matching = 0
        observed_inventory = hashlib.sha256()
        for mode, object_type, expected_blob, relative, raw_path in entries:
            row = {'path': str(relative), 'expected_mode': mode, 'expected_blob': expected_blob}
            issues = []
            try:
                if object_type != 'blob' or mode not in ('100644', '100755', '120000'):
                    raise ValueError(f'Unsupported tracked mode/type: {mode} {object_type}')
                parent = workspace
                for component in relative.parts[:-1]:
                    parent /= component
                    parent_info = parent.lstat()
                    if not stat.S_ISDIR(parent_info.st_mode):
                        raise ValueError(f'Tracked parent is not an ordinary directory: {parent.relative_to(workspace)}')
                path = workspace.joinpath(*relative.parts)
                before = path.lstat()
                if stat.S_ISREG(before.st_mode):
                    actual_mode = '100755' if before.st_mode & stat.S_IXUSR else '100644'
                    descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
                    with os.fdopen(descriptor, 'rb') as source:
                        opened = os.fstat(source.fileno())
                        if signature(opened) != signature(before):
                            raise ValueError('File changed between lstat and open')
                        digest = hashlib.sha1(b'blob ' + str(before.st_size).encode() + b'\0')
                        size = 0
                        while block := source.read(1024 * 1024):
                            digest.update(block)
                            size += len(block)
                        after_open = os.fstat(source.fileno())
                    if signature(after_open) != signature(before) or size != before.st_size:
                        issues.append('File metadata or size changed while being read')
                elif stat.S_ISLNK(before.st_mode):
                    actual_mode = '120000'
                    link_bytes = os.readlink(os.fsencode(path))
                    size = len(link_bytes)
                    digest = hashlib.sha1(b'blob ' + str(size).encode() + b'\0' + link_bytes)
                else:
                    raise ValueError('Tracked path is neither a regular file nor a symlink')
                after = path.lstat()
                if signature(after) != signature(before):
                    issues.append('Tracked entry changed during observation')
                actual_blob = digest.hexdigest()
                bytes_checked += size
                blobs_hashed += 1
                row.update({'actual_mode': actual_mode, 'actual_blob': actual_blob, 'bytes_read': size})
                observed_inventory.update(actual_mode.encode() + b' blob ' + actual_blob.encode() + b'\t' + raw_path + b'\0')
                if actual_mode != mode:
                    issues.append('Git executable/symlink mode differs')
                if actual_blob != expected_blob:
                    issues.append('Git blob hash differs')
            except (OSError, ValueError) as error:
                issues.append(f'{type(error).__name__}: {error}')
            if issues:
                row['issues'] = issues
                mismatches.append(row)
            else:
                entries_matching += 1
        observed_sha = observed_inventory.hexdigest()
        expected_sha = hashlib.sha256(raw_inventory).hexdigest()
        inventory_matches = observed_sha == expected_sha
        # Every successful entry is included in Git tree order; an omitted read
        # or a differing blob/mode must also fail the inventory digest equality.
        all_match = (not mismatches and entries_matching == len(entries) and inventory_matches)
        workspaces.append({
            'directory': str(workspace), 'tracked_entries': len(entries),
            'blobs_hashed': blobs_hashed, 'entries_matching': entries_matching,
            'bytes_checked': bytes_checked, 'mismatches': mismatches,
            'observed_inventory_sha256': observed_sha,
            'inventory_digest_matches': inventory_matches, 'all_match': all_match,
        })
    all_match = all(row['all_match'] for row in workspaces)
    receipt = {
        'status': 'PASS' if all_match else 'FAIL', 'label': args.label,
        'started_at_utc': started,
        'completed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'revision': args.revision, 'tree': tree, 'object_format': object_format,
        'expected_inventory_sha256': hashlib.sha256(raw_inventory).hexdigest(),
        'expected_tracked_entries': len(entries), 'workspaces': workspaces,
        'all_match': all_match, 'commands': commands,
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'scope': 'All tracked leaf bytes and Git executable/symlink modes against the explicit revision, independently of HEAD or jj @. Untracked files are ignored. No restoration, source edit, jj command, history mutation or cleanup.',
        'limits': ['This is a bounded filesystem observation, not an atomic snapshot. Run with both workspaces frozen.',
                   'The Git executable bit (owner execute) is checked; other permission bits, ownership, ACLs and timestamps are not Git tree contracts.',
                   'Direct byte hashes are used; no Git clean filter or line-ending conversion is applied.',
                   'Matching pre/post observations do not prove files were never temporarily changed during intervening execution.'],
    }
    with output.open('x') as destination:
        destination.write(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({'status': receipt['status'], 'revision': args.revision,
                      'tracked_entries_per_workspace': len(entries),
                      'mismatches': [len(row['mismatches']) for row in workspaces],
                      'receipt': str(output)}))
    return 0 if all_match else 1


if __name__ == '__main__':
    raise SystemExit(main())

#!/usr/bin/env python3
"""Independently reconcile completed final runtime from raw lists/logs/guards.

No Cargo, tests, CLI or jj execution. Git inventory reads and a streaming hash
of the already frozen CLI supply read-only provenance. Never read the licensed
wrapper. Output is a fresh external review receipt plus a short Markdown note.
The existing collectors are compared as data; their parsing code is not used.
"""
from collections import Counter
from datetime import datetime, timezone
import hashlib
import itertools
import json
import os
from pathlib import Path
import re
import shlex
import subprocess

ROOT = Path('/tmp/raised-stack/closeout')
PREP = ROOT / 'validation-prep'
LOGS = PREP / 'boundary-7'
REPO = Path('/common/dev/gammaloop/higher-power-energies-review')
REVISION = 'a474c96016a6236d0e91cb67dd284fe91a6c38b7'
TREE = '1f4a64901b2d7df8bf84629ff47fa098b83e8918'
JOBS = ['curated', 'commit5-phases', 'signed-acceptances', 'commit6-vakint-uv',
        'scalar-all', 'shared-default', 'shared-all', 'shared-no-default',
        'ufo-model-parity', 'vertex-rules']
RUN_FLAGS = ['--test-threads', '4', '--retries', '0', '--no-fail-fast', '--status-level', 'pass',
             '--final-status-level', 'all', '--failure-output', 'immediate-final', '--success-output', 'never']
ANSI = re.compile(r'\x1b\[[0-?]*[ -/]*[@-~]')
ROW = re.compile(r'^\s*(\S+)\s+\[\s*([0-9.]+)s\]\s+\(\s*(\d+)/(\d+)\)\s+(\S+)\s+(\S+)\s*$')
OBSERVED = {}
COMMANDS = []


def read(path):
    path = Path(path)
    assert path != Path('/tmp/raised-stack/run') and not path.is_symlink()
    assert path.is_relative_to(ROOT) or path == Path('/tmp/raised-stack/extra-prefix-checks')
    before = path.stat()
    data = path.read_bytes()
    after = path.stat()
    assert (before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns) == (after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns)
    assert path not in OBSERVED or OBSERVED[path] == data, 'Receipt changed during reconciliation'
    OBSERVED[path] = data
    return data


def load(path):
    return json.loads(read(path))


def digest(path):
    return hashlib.sha256(read(path)).hexdigest()


def check_audit(path, count, inventory_hash):
    audit = load(path)
    assert audit['status'] == 'PASS' and audit['all_match']
    assert audit['revision'] == REVISION and audit['tree'] == TREE
    assert audit['expected_tracked_entries'] == count and audit['expected_inventory_sha256'] == inventory_hash
    assert len(audit['workspaces']) in [1, 2]
    for row in audit['workspaces']:
        assert row['all_match'] and row['inventory_digest_matches'] and not row['mismatches']
        assert row['tracked_entries'] == row['blobs_hashed'] == row['entries_matching'] == count
        assert row['observed_inventory_sha256'] == inventory_hash
    return {'path': str(path), 'sha256': digest(path), 'workspaces': len(audit['workspaces']), 'tracked_entries': count}


def main():
    outputs = [ROOT / ('final-runtime-independent-review.' + suffix) for suffix in ['json', 'md']]
    assert not any(path.exists() for path in outputs), 'Never replace an independent review receipt'
    collector = load(PREP / 'runtime-evidence-complete.json')
    assert collector['declared_revision'] == REVISION and collector['declared_tree'] == TREE
    assert collector['aggregate']['all_required_selections_complete']
    assert [row['selection'] for row in collector['jobs']] == JOBS
    assert all(row['status'] == 'completed' for row in collector['jobs'])
    completion = load(ROOT / 'final-stack-driver-completion.json')
    assert completion['revision'] == REVISION and completion['tree'] == TREE and completion['completed_jobs'] == JOBS
    frozen = load(ROOT / 'runtime-candidate.json')
    assert frozen['revision'] == REVISION and frozen['tree'] == TREE
    pin_command = ['git', '-C', str(REPO), 'show', '-s', '--format=%H%x00%T', REVISION]
    COMMANDS.append(pin_command)
    assert subprocess.check_output(pin_command, env={**os.environ, 'GIT_OPTIONAL_LOCKS': '0'}).decode().strip().split('\0') == [REVISION, TREE]
    argv = ['git', '-C', str(REPO), 'ls-tree', '-rz', '--full-tree', REVISION]
    COMMANDS.append(argv)
    inventory = subprocess.check_output(argv, env={**os.environ, 'GIT_OPTIONAL_LOCKS': '0'})
    inventory_hash = hashlib.sha256(inventory).hexdigest()
    count = len([row for row in inventory.split(b'\0') if row])
    assert count > 0
    all_audits = [check_audit(PREP / (phase + '-final-runtime-tracked-audit.json'), count, inventory_hash) for phase in ['pre', 'post']]
    assert all(row['workspaces'] == 2 for row in all_audits)
    records = []
    identity_maps = {}
    for saved in collector['jobs']:
        name = saved['selection']
        folder = LOGS / 'jobs' / name
        assert read(folder / 'revision').decode().strip() == REVISION
        assert read(folder / 'tree').decode().strip() == TREE
        assert read(folder / 'actual-head-after').decode().strip() == REVISION
        assert int(read(folder / 'integrity.exit')) == 0
        read(folder / 'started'); read(folder / 'completed')
        phase_data = {}
        for phase in ['list', 'run']:
            prefix = LOGS / 'tests' / (name + '.' + phase)
            command = shlex.split(read(Path(str(prefix) + '.command')).decode())
            assert command[:3] == ['cargo', 'nextest', phase] and '--locked' in command
            events = [json.loads(line) for line in read(Path(str(prefix) + '.watchdog.jsonl')).splitlines() if line]
            starts = [event for event in events if event.get('event') == 'start']
            finishes = [event for event in events if event.get('event') == 'complete']
            assert len(starts) == len(finishes) == 1 and events[-1] == finishes[0]
            assert starts[0]['command'] == command
            assert starts[0]['memory_metric'] == 'rss' and starts[0]['tree_limit_bytes'] == 30_000_000_000
            exit_code = int(read(Path(str(prefix) + '.exit')))
            assert exit_code == finishes[0]['returncode'] == int(read(folder / (phase + '.exit')))
            outer = shlex.split(read(folder / (phase + '.invocation.command')).decode())
            assert outer == ['/tmp/raised-stack/run', 'bash', str(PREP / 'remaining-validation'), phase, name, str(LOGS / 'tests')]
            context = read(Path(str(prefix) + '.context')).decode().splitlines()
            assert context[-3:] == [REVISION, TREE, REVISION]
            fields = dict(line.split('=', 1) for line in context if '=' in line)
            assert all(fields.get(k) == v for k, v in {'workers': '4', 'retries': '0', 'snapshot_updates': 'no', 'memory_limit_decimal_gb': '30', 'checkout': '/tmp/raised-stack/prefix', 'target': str(REPO / 'target')}.items())
            assert command == saved['listing_and_execution'][phase]['argv']
            assert exit_code == saved['listing_and_execution'][phase]['exit_code']
            phase_data[phase] = {'argv': command, 'exit': exit_code, 'context': context, 'fields': fields,
                                 'elapsed_seconds': finishes[0]['elapsed_s'], 'peak_rss_bytes': finishes[0]['peak_tree_bytes']}
        listed, ran = phase_data['list'], phase_data['run']
        assert listed['exit'] == 0
        assert int(read(folder / 'driver.exit')) == ran['exit']
        assert listed['argv'][-2:] == ['--message-format', 'json']
        expected_run = listed['argv'][:-2]
        expected_run[2] = 'run'
        assert ran['argv'] == expected_run + RUN_FLAGS
        assert listed['context'][1:] == ran['context'][1:]
        runner_lines = read(folder / 'runner-fingerprints.txt').decode().splitlines()
        assert len(runner_lines) == 3 and len({line.split(maxsplit=1)[1] for line in runner_lines}) == 3
        for line in runner_lines:
            expected_hash, path = line.split(maxsplit=1)
            assert Path(path) in [PREP / 'remaining-validation', PREP / 'final-runtime-job', Path('/tmp/raised-stack/extra-prefix-checks')]
            assert digest(Path(path)) == expected_hash
        listing = load(LOGS / 'tests' / (name + '.list.json'))
        mode = listed['argv'][listed['argv'].index('--run-ignored') + 1] if '--run-ignored' in listed['argv'] else 'default'
        assert mode in ['default', 'all', 'ignored-only']
        expected = set()
        listed_cases = sum(len(suite.get('testcases', {})) for suite in listing['rust-suites'].values())
        assert listed_cases == listing['test-count']
        for suite in listing['rust-suites'].values():
            for test, case in suite.get('testcases', {}).items():
                if case['filter-match']['status'] == 'matches' and not (case['ignored'] and mode == 'default') and not (not case['ignored'] and mode == 'ignored-only'):
                    identity = (suite['binary-id'], test)
                    assert identity not in expected
                    expected.add(identity)
        text = '\n'.join(read(LOGS / 'tests' / (name + '.run' + suffix)).decode() for suffix in ['.log', '.stderr.log'])
        lines = ANSI.sub('', text).splitlines()
        summaries = {line.strip() for line in lines if re.search(r'\bSummary\s+\[', line)}
        assert len(summaries) == 1
        summary = summaries.pop()
        match = re.search(r'\[\s*([0-9.]+)s\]\s+(\d+) tests? run:', summary)
        assert match
        total, elapsed = int(match[2]), float(match[1])
        counts = {key: int(found[1]) if (found := re.search(r'(\d+) ' + key, summary)) else 0 for key in ['passed', 'failed', 'skipped']}
        outcomes = {}
        indices = {}
        repeated = 0
        for line in lines:
            match = ROW.match(line)
            if match:
                status, duration, index, denominator, binary, test = match.groups()
                assert int(denominator) == total
                key = binary, test
                value = {'status': status, 'seconds': float(duration), 'progress_index': int(index)}
                assert key not in outcomes or outcomes[key] == value
                assert int(index) not in indices or indices[int(index)] == key
                repeated += key in outcomes
                outcomes[key] = value; indices[int(index)] = key
        assert set(outcomes) == expected and total == len(expected) > 0
        assert counts['skipped'] == listed_cases - total, 'Raw skipped count does not match the unexecuted listed cases'
        assert set(indices) == set(range(1, total + 1))
        statuses = Counter(value['status'] for value in outcomes.values())
        assert statuses.get('PASS', 0) == counts['passed'] and total - counts['passed'] == counts['failed']
        assert ran['exit'] == (100 if counts['failed'] else 0)
        saved_tests = saved['listing_and_execution']['run']['tests']
        saved_outcomes = {(row['binary_id'], row['test_name']): {key: row[key] for key in ['status', 'seconds', 'progress_index']} for row in saved_tests['cases']}
        assert outcomes == saved_outcomes
        assert {key: saved_tests[key] for key in counts} == counts
        assert saved_tests['selected'] == total and saved_tests['elapsed_seconds'] == elapsed and saved_tests['repeated_result_lines_ignored'] == repeated
        identity_text = ''.join(f'{binary}\t{test}\n' for binary, test in sorted(outcomes))
        assert hashlib.sha256(identity_text.encode()).hexdigest() == saved['selected_identity_sha256']
        config = {'cargo_selection_argv': ran['argv'][3:ran['argv'].index('-E')], 'rustflags': ran['fields'].get('rustflags', ''), 'target': ran['fields']['target'], 'pythonpath': ran['fields'].get('PYTHONPATH')}
        config_hash = hashlib.sha256(json.dumps(config, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
        assert config == saved['configuration'] and config_hash == saved['configuration_sha256']
        assert not any('pysecdec' in binary or test == 'test_integrate_1l_decorated_indices_pysecdec' for binary, test in outcomes)
        failing = {test for _, test in outcomes if re.search(r'(^|::)failing::', test)}
        assert failing == ({'graph::parse::tests::failing::vertex_rules'} if name == 'vertex-rules' else set())
        slow = {test for _, test in outcomes if re.search(r'(^|::)slow::', test)}
        scalar_counts = None
        if name == 'scalar-all':
            prefixes = {'standard': 'scalar_3l_cross_section_inspects::default_scalar_3l_cross_section_inspects::', 'slow': 'scalar_3l_cross_section_inspects::slow::'}
            scalar_counts = {label: sum(test.startswith(prefix) for _, test in outcomes) for label, prefix in prefixes.items()}
            assert sum(scalar_counts.values()) == total and all(scalar_counts.values())
            assert '--release' in ran['argv'] and '--ignore-default-filter' in ran['argv'] and mode == 'all'
            assert ran['argv'][ran['argv'].index('--test') + 1] == 'test_runs'
        else:
            assert not slow
        if name.startswith('shared-'):
            assert (name == 'shared-all') == ('--all-features' in ran['argv'])
            assert (name == 'shared-no-default') == ('--no-default-features' in ran['argv'])
        if name == 'curated':
            required = {'scalar_weighted_compact_vector_contracts_to_minkowski_inner_product',
                'parsing_preserves_two_compact_vectors_in_an_opaque_argument',
                'parsing_preserves_compact_and_explicit_tensors_in_an_opaque_argument',
                'additional_event_weights_roundtrip_preserves_all_keys_and_values',
                'inspect_json_preserves_retained_events_and_additional_weights',
                'tensor_reduction_of_powered_scalar_sum_matches_angular_average',
                'arb_parameter_baseline_uses_decimal_promotion',
                'nested_vacuum_denominators_preserve_incidence_and_factorized_numerators', 'finite_part_quark_lo'}
            assert required <= {test.rsplit('::', 1)[-1] for _, test in outcomes}
        audit = check_audit(folder / 'post-job-tracked-audit.json', count, inventory_hash)
        assert audit['workspaces'] == 1
        identity_maps[name] = {key: value['status'] for key, value in outcomes.items()}
        records.append({'selection': name, 'selected': total, **counts, 'elapsed_test_seconds': elapsed,
            'guarded_list_seconds': listed['elapsed_seconds'], 'guarded_run_seconds': ran['elapsed_seconds'],
            'peak_run_rss_bytes': ran['peak_rss_bytes'], 'actual_statuses': dict(statuses),
            'repeated_identical_status_lines': repeated, 'identity_sha256': saved['selected_identity_sha256'],
            'configuration_sha256': config_hash, 'scalar_namespace_counts': scalar_counts,
            'raw_list_and_run_identities_equal': True, 'collector_all_outcomes_equal': True,
            'post_job_audit': audit})
    union = set().union(*(rows.keys() for rows in identity_maps.values()))
    failed = {key for rows in identity_maps.values() for key, status in rows.items() if status != 'PASS'}
    status_counts = Counter(status for rows in identity_maps.values() for status in rows.values())
    intersections = [{'left': left, 'right': right, 'count': len(identity_maps[left].keys() & identity_maps[right].keys())} for left, right in itertools.combinations(JOBS, 2)]
    disagreements = [{'left': left, 'right': right, 'binary_id': key[0], 'test_name': key[1], 'left_status': identity_maps[left][key], 'right_status': identity_maps[right][key]} for left, right in itertools.combinations(JOBS, 2) for key in sorted(identity_maps[left].keys() & identity_maps[right].keys()) if identity_maps[left][key] != identity_maps[right][key]]
    aggregate = {'distinct_identities': len(union), 'identities_with_only_passes': len(union - failed),
        'identities_with_any_nonpass': len(failed), 'actual_executions': sum(status_counts.values()),
        'execution_status_counts': dict(sorted(status_counts.items())), 'all_selected_tests_pass': not failed,
        'pairwise_intersections': intersections, 'overlapping_status_disagreements': disagreements}
    assert all(collector['aggregate'][key] == value for key, value in aggregate.items())
    build = load(ROOT / 'frozen-cli-build-receipt.json')
    physical = load(ROOT / 'physical-inspect/final-c7/manifest.json')
    assert build['revision'] == physical['revision'] == REVISION and build['tree'] == TREE
    assert build['build_exit'] == 0 and build['source_and_copy_equal']
    assert build['build_log_sha256'] == digest(LOGS / 'build.log')
    assert build['pre_runtime_source_audit_sha256'] == digest(PREP / 'pre-final-runtime-tracked-audit.json')
    assert build['build_command'] == read(LOGS / 'build.command').decode()
    binary = Path(build['frozen_binary'])
    assert binary == ROOT / 'bin/gammaloop-final' and not binary.is_symlink()
    before = binary.stat()
    with binary.open('rb') as stream:
        binary_hash = hashlib.file_digest(stream, 'sha256').hexdigest()
    after = binary.stat()
    assert (before.st_ino, before.st_size, before.st_mtime_ns) == (after.st_ino, after.st_size, after.st_mtime_ns)
    assert binary_hash == build['binary_sha256']
    assert physical['status'] == 'passed'
    physical_review = load(ROOT / 'independent-physical-replay-review.json')
    assert physical_review['status'] == 'PASS' and not physical_review['open_findings']
    assert physical_review['runtime_revision'] == REVISION and physical_review['runtime_tree'] == TREE and physical_review['binary_sha256'] == binary_hash
    boundary = load(PREP / 'boundary-evidence-complete.json')
    assert [row['boundary'] for row in boundary['boundaries']] == list(range(1, 8))
    assert all(row['status'] == 'completed' and row['all_recorded_required_jobs_pass'] for row in boundary['boundaries'])
    for path, data in OBSERVED.items():
        assert path.read_bytes() == data, 'Frozen evidence changed during reconciliation'
    result = {'schema_version': 1, 'recorded_at_utc': datetime.now(timezone.utc).isoformat(),
        'reviewer': 'closeout_validation_plan', 'status': 'PASS' if not failed else 'FAIL',
        'revision': REVISION, 'tree': TREE, 'selections': records, 'aggregate': aggregate,
        'global_source_audits': all_audits,
        'frozen_cli_sha256_after_all_runtime_jobs': binary_hash,
        'physical_review_receipt_sha256': digest(ROOT / 'independent-physical-replay-review.json'),
        'collector_sha256': digest(PREP / 'runtime-evidence-complete.json'),
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'raw_sources': [{'path': str(path), 'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)} for path, data in sorted(OBSERVED.items())],
        'read_only_commands': COMMANDS, 'open_findings': [],
        'plan_requirements_complete': False,
        'known_plan_gap': 'The original requested complete independent GL00 common-chart reconstruction certificate is still being prepared; this review certifies only the actual frozen selections and does not close that requirement.',
        'execution_scope': {'cargo_runs': 0, 'tests_or_cli_replays': 0, 'jj_commands': 0, 'tracked_edits': 0, 'licensed_wrapper_read_or_hash': False},
        'limits': ['The review independently parses completed raw records; it does not rerun tests or infer failure causes.',
                   'Distinct binary/test identities combine overlapping selections; actual executions retain repeated configurations. Skipped/discovered cases are not executions.',
                   'Four Nextest workers is not an OS-thread cap. The guard samples process-tree RSS; ordinary suites have no practical global time limit.',
                   'Manual physical PySecDec integrations remain excluded. Existing warning-policy exception remains visible in raw commands/contexts.',
                   'C7 report rendering, final-document gates and final bookmark/history closure are outside this frozen runtime review.']}
    with outputs[0].open('x') as stream:
        json.dump(result, stream, indent=2); stream.write('\n')
    rows = '\n'.join(f"| {r['selection']} | {r['selected']} | {r['passed']} | {r['failed']} | {r['skipped']} |" for r in records)
    note = f"""# Independent final-runtime reconciliation\n\n{result['status']}: all ten selections were reconciled directly from their raw Nextest lists, complete numbered outcomes, summaries, guards, commands, contexts and source audits at `{REVISION}` / tree `{TREE}`. The collector's parsing functions were not imported.\n\nThe original plan remains open pending the complete independent GL00 common-chart reconstruction certificate. This receipt certifies the executed selections and makes no claim that every original-plan requirement is complete.\n\n| Selection | Executed | Passed | Failed | Skipped |\n|---|---:|---:|---:|---:|\n{rows}\n\nThere are {aggregate['actual_executions']} actual executions and {aggregate['distinct_identities']} distinct binary/test identities across overlapping selections and feature configurations. Repeated identical live/final outcome rows are counted once. Every selected identity has a complete matching outcome; all collector counts, statuses, configurations and pairwise overlaps match the independent reconstruction.\n\nAll ten post-job audits and both full-workspace runtime audits match the immutable tracked inventory. The frozen CLI SHA remains `{binary_hash}` after all runtime jobs. Physical GL04 replay has its own independent review; no extra physics or performance result is inferred here.\n\nThis reviewer ran no Cargo, tests, CLI replay or jj command and edited no tracked source. Manual physical PySecDec integrations remain outside coverage. Four Nextest workers is a scheduler budget, and the 30 GB guard is a sampled RSS bound. Final reports, PDFs, separate final-document gates and bookmark closure require later external receipts.\n"""
    with outputs[1].open('x') as stream:
        stream.write(note)
    print(json.dumps({'status': result['status'], 'revision': REVISION, 'aggregate': aggregate, 'review': str(outputs[0])}, indent=2))


if __name__ == '__main__':
    main()

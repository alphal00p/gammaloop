from pathlib import Path
from datetime import datetime, timezone
import argparse, hashlib, json, subprocess

root = Path('/tmp/raised-stack/closeout')
prep = root / 'validation-prep'
repo = Path('/common/dev/gammaloop/higher-power-energies-review')
parser = argparse.ArgumentParser()
parser.add_argument('revision')
args = parser.parse_args()
rev = args.revision
assert len(rev) == 40 and all(c in '0123456789abcdef' for c in rev)
assert not (prep / 'boundary-7').exists()
assert json.loads((root / 'functional-stack-progress.json').read_text())['completed_boundaries'][-1]['number'] == 6
commands = []
def run(argv):
    commands.append(argv)
    subprocess.run(argv, cwd=repo, check=True)
def git(arg):
    return subprocess.check_output(['git', 'rev-parse', arg], cwd=repo, text=True).strip()
def digest(path):
    with path.open('rb') as source:
        return hashlib.file_digest(source, 'sha256').hexdigest()
tree = git(rev + '^{tree}')
assert subprocess.check_output(['jj', '--ignore-working-copy', 'log', '--no-graph', '-r', '@', '-T', 'commit_id'], cwd=repo, text=True).strip() == rev
run(['jj', '-R', '/tmp/raised-stack/prefix', 'edit', rev])
run(['bash', str(prep / 'validate-boundary'), '7', rev])
run(['/tmp/raised-stack/python', str(prep / 'audit-tracked-worktrees.py'), '--revision', rev, '--label', 'pre-final-runtime', '--output', str(prep / 'pre-final-runtime-tracked-audit.json')])
binary = repo / 'target/dev-optim/gammaloop'
frozen = root / 'bin/gammaloop-final'
frozen.parent.mkdir(exist_ok=True)
assert not frozen.exists()
source_hash = digest(binary)
run(['cp', '--reflink=auto', '--preserve=mode,timestamps', str(binary), str(frozen)])
assert source_hash == digest(binary) == digest(frozen)
receipt = {'revision': rev, 'tree': tree, 'captured_utc': datetime.now(timezone.utc).isoformat(), 'source_binary': str(binary), 'frozen_binary': str(frozen), 'binary_sha256': source_hash, 'source_and_copy_equal': True, 'build_command': (prep / 'boundary-7/build.command').read_text(), 'build_log_sha256': digest(prep / 'boundary-7/build.log'), 'build_exit': int((prep / 'boundary-7/build.exit').read_text()), 'pre_runtime_source_audit_sha256': digest(prep / 'pre-final-runtime-tracked-audit.json'), 'commands': list(commands)}
assert receipt['build_exit'] == 0
(root / 'frozen-cli-build-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
run(['bash', str(root / 'physical-inspect/run.sh'), str(frozen), rev, str(root / 'physical-inspect/final-c7')])
jobs = ['curated', 'commit5-phases', 'signed-acceptances', 'commit6-vakint-uv', 'scalar-all', 'shared-default', 'shared-all', 'shared-no-default', 'ufo-model-parity', 'vertex-rules']
completed = []
for job in jobs:
    print('Final runtime: ' + job, flush=True)
    run(['bash', str(prep / 'final-runtime-job'), rev, job, str(prep / 'boundary-7')])
    completed.append(job)
    (root / 'final-stack-progress.json').write_text(json.dumps({'revision': rev, 'tree': tree, 'completed_jobs': completed}, indent=2) + '\n')
run(['/tmp/raised-stack/python', str(prep / 'audit-tracked-worktrees.py'), '--revision', rev, '--label', 'post-final-runtime', '--output', str(prep / 'post-final-runtime-tracked-audit.json')])
run(['/tmp/raised-stack/python', str(prep / 'collect-boundary-evidence.py'), '--through', '7', '--output', str(prep / 'boundary-evidence-complete.json')])
run(['/tmp/raised-stack/python', str(prep / 'collect-final-runtime-evidence.py'), '--revision', rev, '--tree', tree, '--log-root', str(prep / 'boundary-7'), '--output', str(prep / 'runtime-evidence-complete.json')])
(root / 'final-stack-driver-completion.json').write_text(json.dumps({'revision': rev, 'tree': tree, 'completed_jobs': completed, 'commands': commands, 'completed_utc': datetime.now(timezone.utc).isoformat()}, indent=2) + '\n')
print('Final runtime and collectors complete', flush=True)

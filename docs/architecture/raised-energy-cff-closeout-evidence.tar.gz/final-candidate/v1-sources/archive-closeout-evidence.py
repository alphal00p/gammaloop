#!/usr/bin/env python3
"""Archive frozen closeout evidence after complete runtime, without touching history.

The licensed environment wrapper is invocation-only: never read or hash it.
Raw payloads are allowlisted, stable-read, secret-scanned and inventoried.
Reports/PDFs, final closure, saved states, binaries, caches and prior archives
are excluded. The archive records a pre-archive runtime revision/tree, never
its own final documentation commit. Existing output files are never replaced.
"""
import argparse
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import tarfile
import tempfile

ROOT = Path('/tmp/raised-stack/closeout')
COMPACT = Path('/tmp/stack-closeout-compact')
REPO = Path('/common/dev/gammaloop/higher-power-energies-review')
PRIVATE_WRAPPER = Path('/tmp/raised-stack/run')
ARCHIVE_NAME = 'raised-energy-cff-closeout-evidence.tar.gz'
RECEIPT_NAME = 'raised-energy-cff-closeout-evidence.json'
ALLOWED_SUFFIXES = {'.json', '.jsonl', '.log', '.md', '.txt', '.py', '.sh', '.rs', '.patch', '.command', '.context', '.exit', '.started', '.revision', '.completed', '.toml', '.yaml', '.yml'}
ALLOWED_BARE_NAMES = {'validate', 'validate-with-bound', 'validate-boundary', 'remaining-validation', 'final-runtime-job', 'probe-command-construction', 'revision', 'tree', 'started', 'completed', 'gates-completed', 'actual-head-after', 'shared-cff-not-applicable'}
ROOT_FILES = {
    'before-duplicate.json', 'before-fold.json', 'reconstructed-candidate.json',
    'source-revisions.txt', 'checkpoint.txt', 'duplicate.log', 'fold-steps.json',
    'fold-tree-proof.json', 'boundary-adjustment-tree-proof.json',
    'post-fold-preservation.json', 'post-job-audit-amendment.json',
    'functional-stack-progress.json', 'functional-stack-driver.log',
    'validate-functional-stack.py', 'final-tensor-reduction-tests.rs',
    'validate-final-stack.py', 'final-stack-driver.log',
    'frozen-cli-build-receipt.json', 'final-stack-progress.json',
    'final-stack-driver-completion.json', 'refresh-validation-report.py',
    'archive-preparation-handoff.json', 'archive-preparation-amendment.json',
    'independent-source-review.json', 'independent-source-review.md',
    'reconstructed-functional-review.json', 'reconstructed-functional-review.md',
    'archive-closeout-evidence.py', 'closeout-archive-policy.md',
    'archive-preparation-checks.json', 'archive-preparation-checks-final.json',
    'archive-preparation-checks-current.json', 'validation-diagnostic-attempts.json',
    'final-runtime-independent-review.json', 'final-runtime-independent-review.md',
    'final-runtime-review.json', 'final-runtime-review.md',
    'runtime-independent-review.json', 'runtime-independent-review.md',
    'independent-script-review.json', 'independent-script-review.md',
    'final-driver-static-review.json', 'final-driver-static-review.md',
    'inventory-frozen-stack.py',
    'runtime-candidate.json', 'await-and-validate-final.py',
    'pre-runtime-ref-observation.json', 'refresh-main-report.py',
    'refresh-machine-ledgers.py', 'verify-history-source-closure.py',
    'independent-machine-ledger-review.json', 'independent-machine-ledger-review.md',
    'archive-preparation-finalized.json',
    'independent-physical-replay-review.json', 'independent-physical-replay-review.md',
}
SUBDIRECTORIES = ['validation-prep', 'json-fix', 'powered-dot-boundary-proposal', 'reconstructed-functional-review-data', 'physical-inspect']
BLOCKED_PARTS = {'__pycache__', '.git', '.jj', 'target', 'bin', 'cache', 'caches', 'source', 'state', 'gammaloop_state'}
LICENSE_PATTERN = re.compile(rb'(?i)\b[0-9a-f]{8}#[0-9a-f]{8}#[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\b')
TOKEN_PATTERN = re.compile(rb'\b(?:sk-(?:proj-|svcacct-)?|gh[pousr]_|github_pat_)[A-Za-z0-9_-]{20,}\b')
BEARER_PATTERN = re.compile(rb'(?i)\bBearer\s+[A-Za-z0-9_./+-]{20,}={0,2}')
SECRET_ASSIGNMENT = re.compile(rb'''(?im)^\s*(?:export\s+)?["']?(?:SYMBOLICA_LICENSE(?:_KEY)?|OPENAI_API_KEY|GH_TOKEN|GITHUB_TOKEN|AWS_SECRET_ACCESS_KEY|ANTHROPIC_API_KEY)["']?\s*[:=]\s*["']?([^\s"',}]+)''')
SAFE_REFERENCES = (b'$', b'os.environ', b'std::env', b'env::var', b'<redacted>', b'redacted', b'None', b'null')


def encoded(value):
    return (json.dumps(value, sort_keys=True, indent=2, ensure_ascii=False, allow_nan=False) + '\n').encode()


def safe_read(path):
    path = Path(path)
    assert path.absolute() != PRIVATE_WRAPPER, 'Private wrapper is never read'
    assert not path.is_symlink(), 'Symlink payloads are excluded'
    resolved = path.resolve(strict=True)
    assert resolved != PRIVATE_WRAPPER, 'Private wrapper is never read'
    assert resolved.is_relative_to(ROOT) or resolved.is_relative_to(COMPACT) or resolved == Path('/tmp/raised-stack/extra-prefix-checks'), 'Source outside evidence allowlist'
    before = path.stat()
    assert stat.S_ISREG(before.st_mode), 'Payload must be a regular file'
    with path.open('rb') as stream:
        opened = os.fstat(stream.fileno())
        assert (opened.st_dev, opened.st_ino, opened.st_size, opened.st_mtime_ns) == (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns)
        data = stream.read()
    after = path.stat()
    assert (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns) == (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns), 'Active evidence changed while read; freeze it first'
    assert len(data) == before.st_size
    return data, before


def scan(data, name):
    # Never print a matched token, payload, or nearby text.
    if LICENSE_PATTERN.search(data) or TOKEN_PATTERN.search(data) or BEARER_PATTERN.search(data):
        raise ValueError(f'Credential-shaped payload rejected: {name}')
    for match in SECRET_ASSIGNMENT.finditer(data):
        if not match.group(1).startswith(SAFE_REFERENCES):
            raise ValueError(f'Secret environment assignment rejected: {name}')
    assert not data.startswith((b'\x7fELF', b'MZ', b'\xfe\xed\xfa', b'\xcf\xfa\xed\xfe', b'\xca\xfe\xba\xbe')), 'Executable payload rejected'
    assert b'\0' not in data, 'NUL/binary payload rejected'
    data.decode('utf-8')


def selected_paths():
    selected = set()
    excluded = []
    for path in ROOT.iterdir():
        if path.is_file() and (path.name in ROOT_FILES or path.name.endswith(('.fold.log', '.description.txt'))):
            selected.add(path)
        elif path.is_file():
            excluded.append(path.name)
    for label in SUBDIRECTORIES:
        start = ROOT / label
        if not start.exists():
            continue
        for directory, subdirs, files in os.walk(start, followlinks=False):
            subdirs[:] = sorted(d for d in subdirs if d not in BLOCKED_PARTS and not d.endswith('-state') and not d.startswith(('final-document', 'final-report', 'pdf', 'render')) and not (Path(directory) / d).is_symlink())
            for name in sorted(files):
                path = Path(directory) / name
                relative = path.relative_to(ROOT)
                if path.is_symlink() or name == 'run' or path.suffix not in ALLOWED_SUFFIXES and name not in ALLOWED_BARE_NAMES:
                    excluded.append(str(relative))
                else:
                    selected.add(path)
    for path in COMPACT.iterdir():
        if path.is_file() and not path.is_symlink() and path.suffix in ALLOWED_SUFFIXES:
            selected.add(path)
    selected.add(Path('/tmp/raised-stack/extra-prefix-checks'))
    return selected, sorted(excluded)


def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args], env={**os.environ, 'GIT_OPTIONAL_LOCKS': '0'}, stderr=subprocess.PIPE)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--runtime-revision', required=True)
    parser.add_argument('--runtime-tree', required=True)
    parser.add_argument('--boundary-evidence', required=True, type=Path)
    parser.add_argument('--runtime-evidence', required=True, type=Path)
    parser.add_argument('--physical-manifest', required=True, type=Path, help='Completed GL04 replay manifest, identified with the frozen runtime revision')
    parser.add_argument('--output-directory', type=Path, default=REPO / 'docs/architecture')
    parser.add_argument('--ledger-output', type=Path, help='Optional fresh scratch JSON summary; no report/PDF or final-commit hashes')
    args = parser.parse_args()
    assert re.fullmatch(r'[0-9a-f]{40}', args.runtime_revision) and re.fullmatch(r'[0-9a-f]{40}', args.runtime_tree)
    assert git('rev-parse', args.runtime_revision + '^{commit}').decode().strip() == args.runtime_revision
    assert git('rev-parse', args.runtime_revision + '^{tree}').decode().strip() == args.runtime_tree
    output = args.output_directory.resolve(strict=True)
    assert output == REPO / 'docs/architecture' or output.is_relative_to(ROOT), 'Output must be the requested docs directory or closeout scratch'
    archive_path, receipt_path = output / ARCHIVE_NAME, output / RECEIPT_NAME
    assert not archive_path.exists() and not receipt_path.exists(), 'Existing evidence outputs are never overwritten'
    for name in [ARCHIVE_NAME, RECEIPT_NAME]:
        assert not git('ls-tree', args.runtime_revision, '--', 'docs/architecture/' + name).strip(), 'Frozen runtime must precede this evidence archive; avoid self-reference'
    boundary_path, runtime_path = args.boundary_evidence.resolve(strict=True), args.runtime_evidence.resolve(strict=True)
    assert boundary_path.is_relative_to(ROOT / 'validation-prep') and runtime_path.is_relative_to(ROOT / 'validation-prep')
    boundary = json.loads(safe_read(boundary_path)[0])
    runtime = json.loads(safe_read(runtime_path)[0])
    boundaries = boundary['boundaries']
    assert [b['boundary'] for b in boundaries] == list(range(1, 8)), 'Require all seven boundary receipts'
    assert all(b['status'] == 'completed' for b in boundaries), 'A boundary is still incomplete'
    assert boundaries[-1]['declared_revision'] == args.runtime_revision
    assert runtime['declared_revision'] == args.runtime_revision and runtime['declared_tree'] == args.runtime_tree
    assert runtime['aggregate']['all_required_selections_complete'], 'Final runtime is not complete'
    assert len(runtime['jobs']) == 10 and all(job['status'] == 'completed' for job in runtime['jobs'])
    assert runtime['aggregate']['actual_executions'] > 0
    expected_jobs = {'curated', 'commit5-phases', 'signed-acceptances', 'commit6-vakint-uv', 'scalar-all', 'shared-default', 'shared-all', 'shared-no-default', 'ufo-model-parity', 'vertex-rules'}
    assert {job['selection'] for job in runtime['jobs']} == expected_jobs
    # The completed collectors already check list/run identity, guard closure and
    # controls. Archive their exact raw source records, not regenerated commands.
    chain = git('rev-list', '--reverse', '395610143576507503fd2c785db3ba62340f4277..' + args.runtime_revision).decode().splitlines()
    assert len(chain) == 7 and chain == [b['declared_revision'] for b in boundaries], 'Boundary receipts do not match the frozen seven-commit chain'
    approval = json.loads(safe_read(COMPACT / 'test-correction-approval.json')[0])
    assert approval['answer'] == 'Yes, check the preserved value', 'Retain the explicit approved test correction'
    physical_path = args.physical_manifest.resolve(strict=True)
    assert physical_path.is_relative_to(ROOT / 'physical-inspect')
    physical = json.loads(safe_read(physical_path)[0])
    assert physical['revision'] == args.runtime_revision
    assert physical['status'] in {'passed', 'failed'}, 'Physical replay has not reached a final outcome'
    candidates, excluded = selected_paths()
    candidates.update([boundary_path, runtime_path, physical_path])
    # A failure is retained as a failure; complete evidence never changes it to pass.
    ledger = {
        'runtime_revision': args.runtime_revision, 'runtime_tree': args.runtime_tree,
        'boundary_revisions': chain,
        'physical_replay': {'manifest': str(physical_path), 'sha256': hashlib.sha256(safe_read(physical_path)[0]).hexdigest(), 'status': physical['status'], 'runs': len(physical.get('runs', [])), 'state_unchanged': physical.get('state_unchanged'), 'binary_unchanged': physical.get('binary_unchanged')},
        'all_boundaries_pass': all(b['all_recorded_required_jobs_pass'] for b in boundaries),
        'runtime_aggregate': runtime['aggregate'],
        'runtime_selections': [{'selection': job['selection'], 'status': job['status'], 'tests': {k: v for k, v in job['listing_and_execution']['run']['tests'].items() if k != 'cases'}, 'argv': job['listing_and_execution']['run']['argv']} for job in runtime['jobs']],
        'boundary_collector': {'path': str(boundary_path), 'sha256': hashlib.sha256(safe_read(boundary_path)[0]).hexdigest()},
        'runtime_collector': {'path': str(runtime_path), 'sha256': hashlib.sha256(safe_read(runtime_path)[0]).hexdigest()},
        'counting_policy': 'Executions include overlapping selections and feature configurations. Distinct identities are the collector union; neither is inferred from discovery counts.',
        'scope': 'Frozen runtime and boundary evidence; no final report/PDF hash or final documentation commit is asserted. Ref observations preserve exact recorded changes; preservation claims concern the original named branches, not an unchanged count of all shared-repository refs.',
    }
    members = {}
    sources = {}
    for path in sorted(candidates):
        contents, metadata = safe_read(path)
        if path.is_relative_to(ROOT):
            name = 'closeout/' + path.relative_to(ROOT).as_posix()
        elif path.is_relative_to(COMPACT):
            name = 'compact-tests/' + path.relative_to(COMPACT).as_posix()
        else:
            name = 'shared-tools/extra-prefix-checks'
        scan(contents, name)
        assert name not in members
        mode = 0o755 if metadata.st_mode & stat.S_IXUSR else 0o644
        members[name] = (contents, mode)
        sources[name] = {'source': str(path)}
    # Capture build/test controls from immutable source for each actual boundary.
    for number, revision in enumerate(chain, 1):
        for path in ['Cargo.toml', 'Cargo.lock', '.cargo/config.toml', '.config/nextest.toml', 'bin/ram_watchdog.py', 'justfile']:
            entry = git('ls-tree', revision, '--', path).decode().strip()
            if not entry:
                continue
            metadata, recorded_path = entry.split('\t', 1)
            mode, kind, blob = metadata.split()
            assert kind == 'blob' and recorded_path == path and mode in {'100644', '100755'}
            contents = git('cat-file', 'blob', blob)
            name = f'boundary-source/C{number}/{path}'
            scan(contents, name)
            members[name] = (contents, 0o755 if mode == '100755' else 0o644)
            sources[name] = {'revision': revision, 'path': path, 'git_blob': blob}
    members['LEDGER.json'] = (encoded(ledger), 0o644)
    inventory = [{'name': name, 'sha256': hashlib.sha256(contents).hexdigest(), 'bytes': len(contents), 'mode': oct(mode), **sources.get(name, {})} for name, (contents, mode) in sorted(members.items())]
    manifest = {
        'format_version': 1, 'runtime_revision': args.runtime_revision, 'runtime_tree': args.runtime_tree,
        'boundary_revisions': chain, 'members': inventory,
        'excluded_non_payload_policy': 'Unknown root files and non-allowlisted descendant formats are omitted. The source preflight receipts report their observation; unrelated unselected files do not affect archive determinism.',
        'inclusion_policy': 'Allowlisted closeout raw commands/results/guards, collectors/audits, history/tree proofs, functional and independent source reviews, JSON-fix diagnostics, compact-test diagnostics and explicit correction approval, powered-dot boundary proposal; final orchestration and frozen CLI build hash receipts; renderer and explicit diagnostic-attempt receipt; physical GL04 replay scripts/inputs/results and state/binary hash manifests without their binary/state payloads; and immutable per-boundary build/test controls.',
        'exclusion_policy': 'Licensed wrapper and environment secrets; symlinks; executables, binary payloads, saved states, caches/build products; prior evidence archives; report/PDF snapshots and final document/head closure. Existing archives are never modified.',
        'determinism': 'Sorted member names; source bytes unchanged; executable bit preserved; other permissions normalized; tar uid/gid/uname/gname and all archive timestamps normalized; gzip mtime zero. Frozen input bytes and manifest provenance determine the archive.',
        'credential_scan': 'All included UTF-8 payloads scanned for the Symbolica license format, known token prefixes, Bearer tokens and sensitive environment assignments. Matches reject packaging without exposing matched text. No licensed-wrapper read/hash occurs.',
        'diagnostic_classification': 'Initial JSON-fix compiler errors and initial compact-test draft failures remain setup/fix diagnostics, not reconstructed boundary failures. Only named frozen boundary/runtime receipts certify those revisions.',
        'self_reference_policy': 'MANIFEST.json does not hash itself. External adjacent receipt hashes the finished archive and manifest. Final document/PDF hashes and final bookmark/commit closure belong in a later external receipt.',
    }
    manifest_data = encoded(manifest)
    scan(manifest_data, 'MANIFEST.json')
    members['MANIFEST.json'] = (manifest_data, 0o644)
    # Ensure no collected regular file changed after initial stable reads.
    for name, source in sources.items():
        if 'source' not in source:
            continue
        contents, _ = safe_read(Path(source['source']))
        assert contents == members[name][0], 'Evidence changed during collection; freeze before packaging'
    ledger_path = args.ledger_output.resolve() if args.ledger_output else None
    if ledger_path:
        assert ledger_path.is_relative_to(ROOT) and ledger_path.suffix == '.json' and not ledger_path.exists()
        assert ledger_path.parent.is_dir() and ledger_path not in {archive_path, receipt_path}
    temp_archive = None
    temp_receipt = None
    try:
        with tempfile.NamedTemporaryFile(prefix='.closeout-archive-', dir=output, delete=False) as destination:
            temp_archive = Path(destination.name)
            with gzip.GzipFile(fileobj=destination, mode='wb', filename='', mtime=0, compresslevel=9) as compressed:
                with tarfile.open(fileobj=compressed, mode='w|', format=tarfile.PAX_FORMAT) as archive:
                    for name, (contents, mode) in sorted(members.items()):
                        info = tarfile.TarInfo(name)
                        info.size, info.mode, info.mtime = len(contents), mode, 0
                        info.uid = info.gid = 0
                        info.uname = info.gname = ''
                        archive.addfile(info, io.BytesIO(contents))
        # Verify every payload in the newly written archive against its source bytes.
        with tarfile.open(temp_archive, 'r:gz') as archive:
            names = []
            for item in archive:
                assert item.isfile() and not item.issym() and not item.islnk()
                assert item.name in members and item.name not in names
                actual = archive.extractfile(item).read()
                assert actual == members[item.name][0]
                assert item.mode == members[item.name][1] and item.mtime == item.uid == item.gid == 0
                names.append(item.name)
            assert names == sorted(members)
        digest = hashlib.sha256(temp_archive.read_bytes()).hexdigest()
        receipt = {
            'archive': ARCHIVE_NAME, 'archive_sha256': digest, 'archive_bytes': temp_archive.stat().st_size,
            'manifest_sha256': hashlib.sha256(manifest_data).hexdigest(),
            'payload_files': len(inventory), 'total_archive_members': len(members),
            'raw_payload_bytes': sum(row['bytes'] for row in inventory),
            'runtime_revision': args.runtime_revision, 'runtime_tree': args.runtime_tree,
            'all_boundaries_pass': ledger['all_boundaries_pass'], 'runtime_aggregate': runtime['aggregate'],
            'physical_replay': ledger['physical_replay'],
            'members': inventory,
            'verification': 'Every regular member, contents, mode and normalized timestamp verified after writing; all included payloads credential-scanned; no symlinks, binaries, states, prior archives or licensed wrapper included.',
            'scope': 'Frozen pre-archive runtime and functional boundary evidence. Final report/PDF hashes and final history/bookmark closure are deliberately external.',
        }
        receipt_data = encoded(receipt)
        scan(receipt_data, RECEIPT_NAME)
        with tempfile.NamedTemporaryFile(prefix='.closeout-receipt-', dir=output, delete=False) as destination:
            temp_receipt = Path(destination.name)
            destination.write(receipt_data)
        # Hard-link publication is atomic and refuses existing destination names.
        os.link(temp_archive, archive_path)
        os.link(temp_receipt, receipt_path)
        if ledger_path:
            with ledger_path.open('xb') as destination:
                destination.write(encoded(ledger))
        print(json.dumps({'archive': str(archive_path), 'receipt': str(receipt_path), 'archive_sha256': digest, 'payload_files': len(inventory), 'bytes': archive_path.stat().st_size()}))
    finally:
        if temp_archive is not None:
            temp_archive.unlink(missing_ok=True)
        if temp_receipt is not None:
            temp_receipt.unlink(missing_ok=True)


if __name__ == '__main__':
    main()

#!/usr/bin/env bash
# Invoke directly: this runner enters the existing licensed environment once.
set -euo pipefail
replay_binary="${1:?usage: run.sh FROZEN_CLI FULL_C7_REVISION NEW_OUTPUT_DIRECTORY}"
replay_revision="${2:?provide the full final C7 commit ID}"
replay_output="${3:?provide a new absolute output directory}"
replay_base=/tmp/raised-stack/closeout/physical-inspect
[[ "$replay_output" == "$replay_base"/* && "$replay_output" != *'..'* && "$replay_output" != *' '* ]] || exit 2
[[ "$replay_revision" =~ ^[0-9a-f]{40}$ ]] || exit 2
mkdir "$replay_output"
replay_command=(/tmp/raised-stack/run env INSTA_UPDATE=no RAYON_NUM_THREADS=2
  /tmp/raised-stack/python "$replay_base/ram_watchdog.py" --limit-gb 8
  --log "$replay_output/watchdog.jsonl" -- timeout --signal=TERM --kill-after=5 90
  taskset -c 8-11 /tmp/raised-stack/python "$replay_base/replay.py"
  --binary "$replay_binary" --revision "$replay_revision" --output "$replay_output")
printf '%q ' "${replay_command[@]}" > "$replay_output/invocation.command"
printf '\n' >> "$replay_output/invocation.command"
exec "${replay_command[@]}" > "$replay_output/driver.log" 2>&1

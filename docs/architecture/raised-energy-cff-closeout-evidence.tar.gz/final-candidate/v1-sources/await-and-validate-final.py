from pathlib import Path
import json, subprocess, time
root = Path('/tmp/raised-stack/closeout')
record = json.loads((root / 'runtime-candidate.json').read_text())
print('Waiting for successful completion of functional boundary 6', flush=True)
while True:
    progress = json.loads((root / 'functional-stack-progress.json').read_text())
    if progress['completed_boundaries'][-1]['number'] == 6:
        break
    for suffix in ['*.exit', 'jobs/*/driver.exit', 'jobs/*/integrity.exit']:
        for receipt in (root / 'validation-prep/boundary-6').glob(suffix):
            if receipt.read_text().strip() != '0':
                raise SystemExit('Functional boundary 6 failed: ' + str(receipt))
    time.sleep(3)
print('Functional boundary 6 complete; starting frozen final runtime ' + record['revision'], flush=True)
subprocess.run(['/tmp/raised-stack/python', str(root / 'validate-final-stack.py'), record['revision']], check=True)

"""Read-only closure proof for explicit runtime/final C7 objects and saved pins."""

import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess


ROOT = Path("/tmp/raised-stack/closeout")
REPOSITORY = Path("/common/dev/gammaloop/higher-power-energies-review")
BASE = "395610143576507503fd2c785db3ba62340f4277"
PROVENANCE = "docs/architecture/raised-energy-cff-stack-provenance.json"
BOOKMARK = "codex/raised-energy-cff-reviewed"
IDENTITY = ["Lucien Huber", "im@lcnbr.ch"] * 2
BEFORE_SHA256 = "4ed74f12ca1678b578932b5e08b8c0fad262cf6de5b58d5b12495ff3a27b2a64"
FIRST_SIX_SHA256 = "9d5be1fcdc0dc8f71f1e8ed181fcfe508f419650082d57a6f8a7d140e93a92df"
REF_OBSERVATION_SHA256 = "e1f0ec346a1e41d0c08793809d15302a4c7e71a07d00a41ce4d74f5c2ecc6571"
TRANSIENT_PREFIX = "refs/codex/turn-diffs/"
PROTECTED_PREFIXES = ("refs/heads/", "refs/remotes/", "refs/tags/")
OBSERVED_REMOTE = {"refs/remotes/origin/codex/ci-clan-upload-validation": "c31db49424e9feb2db53145f20479d51255bf2bd"}

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--runtime-c7", required=True)
parser.add_argument("--final-c7", required=True)
parser.add_argument("--output", type=Path, required=True)
args = parser.parse_args()
assert all(re.fullmatch(r"[0-9a-f]{40}", oid) for oid in [args.runtime_c7, args.final_c7])
output = args.output.resolve()
assert output.is_relative_to(ROOT) and output.parent.is_dir() and not output.exists()
with output.open("x") as stream:
    json.dump({"status": "RUNNING"}, stream)

receipt = {
    "status": "RUNNING",
    "started_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "repository": str(REPOSITORY),
    "base": BASE,
    "runtime_c7": args.runtime_c7,
    "final_c7": args.final_c7,
    "bookmark": BOOKMARK,
    "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    "commands": [],
}
env = {**os.environ, "GIT_OPTIONAL_LOCKS": "0"}


# Same read-only command pattern as validation-prep/audit-prefix.py and the
# existing test-comparison-revision/verify-final-closure.py verifier.
def read(*argv):
    result = subprocess.run(argv, cwd=REPOSITORY, env=env, capture_output=True, timeout=30)
    receipt["commands"].append({
        "argv": list(argv), "returncode": result.returncode,
        "stdout_bytes": len(result.stdout),
        "stdout_sha256": hashlib.sha256(result.stdout).hexdigest(),
        "stderr": result.stderr.decode(errors="replace"),
    })
    result.check_returncode()
    return result.stdout


def git(*argv):
    return read("git", *argv).decode().strip()


try:
    before_bytes = (ROOT / "before-duplicate.json").read_bytes()
    candidate_bytes = (ROOT / "reconstructed-candidate.json").read_bytes()
    observation_bytes = (ROOT / "pre-runtime-ref-observation.json").read_bytes()
    assert hashlib.sha256(observation_bytes).hexdigest() == REF_OBSERVATION_SHA256, "pinned unrelated-ref observation changed"
    ref_observation = json.loads(observation_bytes)
    before = json.loads(before_bytes)
    candidate = json.loads(candidate_bytes)
    first_six = candidate[:6]
    six_bytes = json.dumps(first_six, sort_keys=True, separators=(",", ":")).encode()
    assert hashlib.sha256(before_bytes).hexdigest() == BEFORE_SHA256, "original checkpoint changed"
    assert hashlib.sha256(six_bytes).hexdigest() == FIRST_SIX_SHA256, "pinned first six changed"
    assert before["base"] == BASE and len(before["inputs"]) == 10
    receipt["input_hashes"] = {
        "before-duplicate.json": hashlib.sha256(before_bytes).hexdigest(),
        "reconstructed-candidate.json": hashlib.sha256(candidate_bytes).hexdigest(),
        "canonical_first_six": hashlib.sha256(six_bytes).hexdigest(),
        "pre-runtime-ref-observation.json": REF_OBSERVATION_SHA256,
    }
    refs_start = dict(
        line.split(" ", 1)
        for line in git("for-each-ref", "--format=%(refname) %(objectname)").splitlines()
    )
    assert git("rev-parse", "--show-object-format") == "sha1"
    assert git("rev-parse", BASE + "^{commit}") == BASE
    first_six_ids = [row["commit"] for row in first_six]
    histories = {}
    for label, tip in [("runtime", args.runtime_c7), ("final", args.final_c7)]:
        assert git("rev-parse", tip + "^{commit}") == tip
        rows = [line.split() for line in git("rev-list", "--parents", "--reverse", BASE + ".." + tip).splitlines()]
        expected = first_six_ids + [tip]
        assert len(rows) == 7 and [row[0] for row in rows] == expected, f"{label}: not the pinned seven commits"
        assert all(row[1:] == [parent] for row, parent in zip(rows, [BASE] + expected[:-1])), f"{label}: not linear"
        parent_tree = git("rev-parse", BASE + "^{tree}")
        commits = []
        for number, commit in enumerate(expected, 1):
            tree = git("rev-parse", commit + "^{tree}")
            identity = git("show", "-s", "--format=%an%x00%ae%x00%cn%x00%ce", commit).split("\0")
            assert identity == IDENTITY, f"{label} C{number}: author/committer mismatch"
            assert tree != parent_tree, f"{label} C{number}: empty commit"
            if number <= 6:
                assert tree == first_six[number - 1]["tree"]
                assert rows[number - 1][1:] == first_six[number - 1]["parents"]
            commits.append({"number": number, "commit": commit, "tree": tree, "parents": rows[number - 1][1:], "author_committer": identity})
            parent_tree = tree
        histories[label] = commits
    receipt["histories"] = histories

    inventories = {}
    for label, commit in [("c6", first_six_ids[-1]), ("runtime", args.runtime_c7), ("final", args.final_c7)]:
        inventory = {}
        for record in read("git", "ls-tree", "-rz", "--full-tree", commit).split(b"\0"):
            if record:
                metadata, path = record.split(b"\t", 1)
                inventory[os.fsdecode(path)] = metadata.decode().split()
        inventories[label] = inventory
    paths = set().union(*(inventory.keys() for inventory in inventories.values()))
    report_paths = {
        path for path in paths
        if path in {"PHASE_CONVENTIONS_FIX.md", "docs/architecture/exact-powered-denominator-cff-lifting.md", "docs/architecture/kysvnqlq-rebase-review.md"}
        or (
            Path(path).parent.as_posix() == "docs/architecture"
            and Path(path).name.startswith("raised-energy-cff-")
            and path.endswith((".md", ".typ", ".pdf", ".json", ".tar.gz"))
        )
    }
    deltas = {}
    for label in ["runtime", "final"]:
        changed = {path for path in paths if inventories["c6"].get(path) != inventories[label].get(path)}
        assert changed and changed <= report_paths, f"{label} C7 changes non-report paths: {sorted(changed - report_paths)}"
        deltas[label + "_c7"] = sorted(changed)
    nonreports = {
        label: {path: value for path, value in inventories[label].items() if path not in report_paths}
        for label in ["runtime", "final"]
    }
    assert nonreports["runtime"] == nonreports["final"], "runtime/final non-report blobs, types or modes differ"
    final_delta = {path for path in paths if inventories["runtime"].get(path) != inventories["final"].get(path)}
    assert final_delta <= report_paths
    receipt["report_deltas"] = deltas
    receipt["runtime_to_final_report_changes"] = [
        {"path": path, "before_mode_type_oid": inventories["runtime"].get(path), "after_mode_type_oid": inventories["final"].get(path)}
        for path in sorted(final_delta)
    ]
    receipt["non_report_identity"] = {
        "equal": True, "tracked_leaf_count": len(nonreports["final"]),
        "canonical_inventory_sha256": hashlib.sha256(json.dumps(nonreports["final"], sort_keys=True, separators=(",", ":")).encode()).hexdigest(),
    }

    source_revision = before["inputs"][0]["commit"]
    source_provenance = json.loads(read("git", "show", source_revision + ":" + PROVENANCE))
    original = source_provenance["original_commits"]
    assert len(original) == len({row["commit"] for row in original}) == 42
    assert sum(row["kind"] == "remote" for row in original) == 37
    assert sum(row["kind"] == "review" for row in original) == 5
    for tip in [args.runtime_c7, args.final_c7]:
        assert json.loads(read("git", "show", tip + ":" + PROVENANCE))["original_commits"] == original
    preserved = []
    for row in [*before["inputs"], *original]:
        commit, tree, parents = git("show", "-s", "--format=%H%x00%T%x00%P", row["commit"]).split("\0")
        assert commit == row["commit"] and tree == row["tree"], f"original object differs: {row['commit']}"
        if "parents" in row:
            assert parents.split() == row["parents"]
        preserved.append({"commit": commit, "tree": tree})
    changes = read(
        "jj", "--ignore-working-copy", "--no-pager", "log", "--no-graph", "-r",
        "all() & (" + " | ".join(row["change"] for row in before["inputs"]) + ")",
        "-T", 'commit_id ++ " " ++ change_id ++ "\\n"',
    ).decode().splitlines()
    observed = sorted(tuple(line.split()) for line in changes)
    expected = sorted((row["commit"], row["change"]) for row in before["inputs"])
    assert observed == expected, "one of the ten original jj changes was rewritten, abandoned or diverged"
    receipt["preserved_originals"] = {
        "original_change_count": 10, "original_source_commit_count": 42,
        "original_changes": [dict(commit=commit, change=change) for commit, change in observed],
        "objects": preserved,
        "provenance_source_commit": source_revision,
        "provenance_source_blob": git("rev-parse", source_revision + ":" + PROVENANCE),
    }

    original_refs = {ref: oid for oid, ref in (line.split(" ", 1) for line in before["git_refs"].splitlines())}
    bookmark_ref = "refs/heads/" + BOOKMARK
    assert bookmark_ref in original_refs
    assert ref_observation["existing_refs_compared"] == len(original_refs)
    assert all(row["ref"].startswith(TRANSIENT_PREFIX) and original_refs[row["ref"]] == row["before"]
               for row in ref_observation["changed_existing_refs"])
    assert {ref: oid for ref, oid in ref_observation["added_other_refs"].items()
            if not ref.startswith(TRANSIENT_PREFIX)} == OBSERVED_REMOTE
    protected_originals = {ref: oid for ref, oid in original_refs.items() if ref.startswith(PROTECTED_PREFIXES)}
    jj_bookmark = read(
        "jj", "--ignore-working-copy", "--no-pager", "log", "--no-graph", "-r", BOOKMARK,
        "-T", 'commit_id ++ "\\n"',
    ).decode().splitlines()
    assert jj_bookmark == [args.final_c7], "jj reviewed bookmark is not uniquely the final C7"
    refs_end = dict(line.split(" ", 1) for line in git("for-each-ref", "--format=%(refname) %(objectname)").splitlines())
    ref_checks = {}
    for label, snapshot in [("start", refs_start), ("end", refs_end)]:
        changed_existing = {
            ref: {"before": oid, "after": snapshot.get(ref)}
            for ref, oid in original_refs.items() if snapshot.get(ref) != oid
        }
        protected_changes = {ref: change for ref, change in changed_existing.items() if ref in protected_originals}
        assert protected_changes == {bookmark_ref: {"before": original_refs[bookmark_ref], "after": args.final_c7}}, (
            "an original head, remote or tag changed unexpectedly", label, protected_changes)
        assert all(ref == bookmark_ref or ref.startswith(TRANSIENT_PREFIX) for ref in changed_existing), (
            "an original non-transient ref changed unexpectedly", label, changed_existing)
        added = {ref: oid for ref, oid in snapshot.items() if ref not in original_refs}
        added_keep = {ref: oid for ref, oid in added.items() if ref.startswith("refs/jj/keep/")}
        added_transient = {ref: oid for ref, oid in added.items() if ref.startswith(TRANSIENT_PREFIX)}
        added_other = {ref: oid for ref, oid in added.items() if ref not in added_keep and ref not in added_transient}
        assert added_other == OBSERVED_REMOTE, ("unobserved new branch/remote/tag or other ref", label, added_other)
        ref_checks[label] = {
            "snapshot_ref_count": len(snapshot),
            "canonical_snapshot_sha256": hashlib.sha256(json.dumps(snapshot, sort_keys=True, separators=(",", ":")).encode()).hexdigest(),
            "changed_existing": changed_existing,
            "original_protected_namespace_changes": protected_changes,
            "transient_existing_changes": {ref: change for ref, change in changed_existing.items() if ref.startswith(TRANSIENT_PREFIX)},
            "added_jj_keep_refs": added_keep, "added_transient_refs": added_transient,
            "added_observed_unrelated_remote": added_other,
        }
    # Application capture/checkpoint refs are transient shared-repository state.
    # Preserve and record their movement without attributing an actor. Existing
    # heads/remotes/tags and other non-transient refs remain strict invariants.
    during_changes = {
        ref: {"before": oid, "after": refs_end.get(ref)}
        for ref, oid in refs_start.items() if refs_end.get(ref) != oid
    }
    during_additions = {ref: oid for ref, oid in refs_end.items() if ref not in refs_start}
    assert all(ref.startswith(TRANSIENT_PREFIX) for ref in during_changes), (
        "a non-transient ref changed while verification ran", during_changes)
    assert all(ref.startswith((TRANSIENT_PREFIX, "refs/jj/keep/")) for ref in during_additions), (
        "an unexpected ref was added while verification ran", during_additions)
    receipt["refs"] = {
        "checkpoint_ref_count": len(original_refs),
        "protected_original_namespace_ref_count": len(protected_originals),
        "protected_namespaces": list(PROTECTED_PREFIXES),
        "original_heads_remotes_tags_unchanged_except_reviewed_bookmark": True,
        "other_original_non_transient_refs_unchanged": True,
        "pinned_pre_runtime_observation": ref_observation,
        "snapshots": ref_checks,
        "during_verifier_transient_changes": during_changes,
        "during_verifier_permitted_additions": during_additions,
        "non_transient_existing_refs_unchanged_during_verifier": True,
        "jj_bookmark": jj_bookmark[0],
        "scope": "All original heads, remotes and tags are preserved except the requested reviewed bookmark move. Transient refs/codex/turn-diffs activity and added jj keep refs are recorded separately. The sole permitted new non-transient non-keep ref is the exact remote addition pinned by the pre-runtime observation. No actor is inferred, and no ref is restored, deleted or mutated by this verifier.",
    }
    receipt["status"] = "PASS"
except Exception as error:
    receipt["status"] = "FAIL"
    receipt["error"] = f"{type(error).__name__}: {error}"
    raise
finally:
    receipt["completed_at_utc"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    output.write_text(json.dumps(receipt, indent=2) + "\n")

print(json.dumps({"status": receipt["status"], "receipt": str(output), "sha256": hashlib.sha256(output.read_bytes()).hexdigest()}))

#!/usr/bin/env python3
"""Inventory an actual seven-commit tree after the new evidence files exist.

Read-only Git and jj --ignore-working-copy queries; no source mutation/builds.
Write one new external JSON receipt. This proves path accounting and exact
C1-C6 review reuse. It never marks a C7 path semantically reviewed.
"""
import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

ROOT = Path('/tmp/raised-stack/closeout')
REPO = Path('/common/dev/gammaloop/higher-power-energies-review')
BASE = '395610143576507503fd2c785db3ba62340f4277'
REVIEW = ROOT / 'reconstructed-functional-review.json'
REQUIRED_C7_PATHS = {
    'docs/architecture/raised-energy-cff-closeout-evidence.tar.gz',
    'docs/architecture/raised-energy-cff-closeout-evidence.json',
}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--revision', required=True, help='Actual full immutable C7 revision containing both new archive files')
    parser.add_argument('--output', type=Path, required=True, help='Fresh external JSON under task scratch')
    args = parser.parse_args()
    assert re.fullmatch('[0-9a-f]{40}', args.revision), 'Use a full immutable lowercase revision'
    output = args.output.resolve()
    assert output.is_relative_to(ROOT) and output.suffix == '.json' and not output.exists()
    assert output.parent.is_dir()
    commands = []
    env = {**os.environ, 'GIT_OPTIONAL_LOCKS': '0'}

    def run(argv):
        commands.append(argv)
        return subprocess.check_output(argv, cwd=REPO, env=env)

    def git(*argv):
        return run(['git', '-C', str(REPO), *argv])

    def inventory(revision):
        raw = git('ls-tree', '-rz', '--full-tree', revision)
        rows = {}
        for record in raw.split(b'\0'):
            if record:
                meta, path = record.split(b'\t', 1)
                mode, kind, blob = meta.decode().split()
                name = os.fsdecode(path)
                assert name not in rows
                rows[name] = {'mode': mode, 'type': kind, 'blob': blob}
        return rows, hashlib.sha256(raw).hexdigest()

    assert git('rev-parse', args.revision + '^{commit}').decode().strip() == args.revision
    review_bytes = REVIEW.read_bytes()
    review = json.loads(review_bytes)
    assert review['base'] == BASE
    chain = git('rev-list', '--reverse', BASE + '..' + args.revision).decode().splitlines()
    assert len(chain) == 7, 'Require exactly seven actual commits above the reviewed base'
    assert chain[:6] == [c['commit'] for c in review['commits']], 'First six reviewed source revisions changed'
    before, before_inventory_sha = inventory(BASE)
    all_paths = set()
    commits = []
    total_coverage = Counter()
    parent = BASE
    for number, commit in enumerate(chain, 1):
        metadata = git('show', '-s', '--format=%H%x00%T%x00%P%x00%an%x00%ae%x00%cn%x00%ce%x00%s', commit).decode().rstrip('\n').split('\0')
        actual, tree, parents, author_name, author_email, committer_name, committer_email, title = metadata
        assert actual == commit and parents.split() == [parent], 'Stack must remain linear'
        assert (author_name, author_email) == ('Lucien Huber', 'im@lcnbr.ch')
        assert (committer_name, committer_email) == ('Lucien Huber', 'im@lcnbr.ch')
        after, after_inventory_sha = inventory(commit)
        changed = sorted(path for path in before.keys() | after.keys() if before.get(path) != after.get(path))
        # Cross-check the complete tree comparison with Git's ordinary no-rename diff.
        raw_diff = git('diff-tree', '--no-commit-id', '--no-renames', '--name-only', '-r', '-z', parent, commit)
        assert set(changed) == {os.fsdecode(p) for p in raw_diff.split(b'\0') if p}
        paths = []
        prior = review['commits'][number - 1] if number <= 6 else None
        prior_paths = {r['path']: r for r in prior['paths'] if r['new_owner_changed']} if prior else {}
        if prior:
            assert prior['parent'] == parent and prior['tree'] == tree
            assert set(prior_paths) == set(changed), 'Reviewed owning diff omitted or added paths'
        counts = Counter()
        for path in changed:
            old, new = before.get(path), after.get(path)
            row = {'path': path, 'before': old, 'after': new,
                   'status': 'added' if old is None else 'deleted' if new is None else 'modified'}
            if prior:
                reviewed = prior_paths[path]
                assert reviewed['new_parent'] == old and reviewed['new_commit'] == new, 'Reviewed before/after mode/type/blob transition differs'
                row['coverage'] = reviewed['coverage']
                row['coverage_receipt'] = 'reconstructed-functional-review.json'
                counts[row['coverage']] += 1
                total_coverage[row['coverage']] += 1
            else:
                row['coverage'] = 'complete_inventory_only_semantic_review_separate'
            paths.append(row)
            all_paths.add(path)
        record = {
            'number': number, 'commit': commit, 'tree': tree, 'parent': parent,
            'title': title, 'author': {'name': author_name, 'email': author_email},
            'committer': {'name': committer_name, 'email': committer_email},
            'before_tree_inventory_sha256': before_inventory_sha,
            'after_tree_inventory_sha256': after_inventory_sha,
            'changed_path_count': len(paths), 'paths': paths,
            'complete_inventory': True,
        }
        if prior:
            record['reused_review_coverage_counts'] = dict(counts)
        commits.append(record)
        parent, before, before_inventory_sha = commit, after, after_inventory_sha
    c7 = commits[-1]
    assert REQUIRED_C7_PATHS <= set(before), 'Both new archive outputs must exist in the supplied immutable C7 tree'
    assert REQUIRED_C7_PATHS <= {r['path'] for r in c7['paths']}, 'New archive outputs must belong to C7'
    for path in REQUIRED_C7_PATHS:
        assert before[path]['type'] == 'blob' and before[path]['mode'] == '100644'
    change = run(['jj', '--ignore-working-copy', 'log', '-r', args.revision, '--no-graph', '-T', 'change_id']).decode().strip()
    assert re.fullmatch('[k-z]+', change), 'Unexpected jj change ID'
    c7['change'] = change
    c7['semantic_review'] = {'status': 'separate_receipt_required', 'scope': 'All C7 text, rendered PDFs and archive/receipt integrity require final review after report refresh. Complete inventory does not assert this semantic review occurred.'}
    assert sum(c['changed_path_count'] for c in commits[:6]) == review['counts']['new_commit_path_records']
    receipt = {
        'schema_version': 1, 'created_at_utc': datetime.now(timezone.utc).isoformat(),
        'revision': args.revision, 'tree': c7['tree'], 'base': BASE,
        'counts': {'commit_path_records': sum(c['changed_path_count'] for c in commits),
                   'distinct_paths': len(all_paths),
                   'first_six_commit_path_records': sum(c['changed_path_count'] for c in commits[:6]),
                   'c7_commit_path_records': c7['changed_path_count'],
                   'first_six_reused_review_coverage': dict(total_coverage)},
        'commits': commits, 'c7': c7,
        'complete_inventory': True, 'first_six_exact_review_coverage_match': True,
        'review_receipt': {'path': str(REVIEW), 'sha256': hashlib.sha256(review_bytes).hexdigest()},
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'commands': commands,
        'scope': 'Actual immutable tree/path/mode/type/blob accounting. No inferred future archive paths or hypothetical totals. C1-C6 before/after transitions exactly match the recorded review; enumeration is not a fresh semantic reread. C7 semantic coverage remains a separate final receipt.',
        'path_count_policy': 'One record per changed path per owning commit, with renames represented as deleted and added paths. Distinct paths is the union across seven actual diffs.',
        'execution': {'cargo_or_test_runs': 0, 'source_mutations': 0, 'jj_mutations': 0,
                      'read_only_jj_queries': 1, 'archive_payloads_opened': 0},
    }
    assert REVIEW.read_bytes() == review_bytes, 'Prior review receipt changed during accounting'
    with output.open('x') as stream:
        stream.write(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({'revision': args.revision, 'counts': receipt['counts'],
                      'first_six_exact_review_coverage_match': True,
                      'c7_semantic_review': 'separate_receipt_required', 'receipt': str(output)}, indent=2))


if __name__ == '__main__':
    main()

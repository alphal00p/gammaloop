# GL00 v2 report and closure adaptation plan

Prepared only. The retained runtime is `a474c96016a6236d0e91cb67dd284fe91a6c38b7`; no v2 revisions, counts or test outcomes exist in this plan. Existing scripts and receipts remain byte-for-byte untouched.

Use separate v2 copies of the accepted renderers, inventory and history verifier. Feed them an explicit candidate plus independently reviewed amendment manifest. Pin C1/C2 to the unchanged commits, keep all ten original change identities and42 source pins, and derive C3–C7 from actual immutable objects after reconstruction.

The new functional review ledger must classify complete actual before/after transitions. The currently affected source path belongs to C3 only, but final counts must come from the new inventory. Rebased descendants inherit the test amendment without acquiring fictitious new owning edits. The full GL00 numerator, independent denominator, physical owner and distinct-mass contracts need fresh semantic review; the shared GL04 fixture also changes.

Keep the current558/485 and546/3/9 figures out of v2 renderer assumptions. Check every reported aggregate against the new enumerated ledger. C1/C2 use their existing exact-revision passing receipts; C3–C7 need new gates and owning selections. The combined GL00/GL04 fixture is one nextest identity with two cases. Final ten-suite totals, frozen CLI/replay identities and counts remain v2-only and must not absorb the retained runtime totals.

For tracked provenance, preserve `original_commits`, `original_source_pins` and recorded snapshots. Update only current history/closeout mappings and add explicit amendment lineage. Retain the existing strict protected-ref rules and documented unrelated-ref observation. Final C7 self identities and rendered-artifact hashes stay in external closure receipts, avoiding report/archive cycles.

The JSON lists exact script adaptation points, prerequisite receipts, preserved-input hashes and failure risks. No Cargo, history operation, backend, production test or report mutation was performed.

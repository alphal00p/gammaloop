from pathlib import Path
import argparse, hashlib, json
BASE = Path('/tmp/raised-stack/closeout/gl00-certificate-v2')
TARGET = Path('/common/dev/gammaloop/higher-power-energies-review/docs/architecture/raised-energy-cff-stack-source-mapping.md')
a = argparse.ArgumentParser()
a.add_argument('--inventory', required=True, type=Path)
a.add_argument('--receipt', required=True, type=Path)
args = a.parse_args()
assert args.receipt.resolve().is_relative_to(BASE) and not args.receipt.exists()
snapshots = {BASE / name: (BASE / name).read_bytes() for name in ['validation-inputs.json', 'reconstructed-candidate.json', 'runtime-candidate.json', 'validation-prep/boundary-evidence-complete.json', 'validation-prep/runtime-evidence-complete.json']}
snapshots[BASE.parent / 'reconstructed-candidate.json'] = (BASE.parent / 'reconstructed-candidate.json').read_bytes()
inputs = json.loads(snapshots[BASE / 'validation-inputs.json'])
assert hashlib.sha256(snapshots[BASE / 'validation-inputs.json']).hexdigest() == 'b9740c1a68baaeef17cfe860b927ea7766d65cfa93bf9044adab6dd79c5a76a1'
assert inputs['status'] == 'PASS'
assert hashlib.sha256(snapshots[BASE / 'reconstructed-candidate.json']).hexdigest() == inputs['candidate_sha256']
inventory_bytes = args.inventory.read_bytes()
inventory = json.loads(inventory_bytes)
assert inventory['complete_inventory'] and inventory['first_six_exact_review_coverage_match']
assert inventory['v2_validation_inputs_sha256'] == hashlib.sha256(snapshots[BASE / 'validation-inputs.json']).hexdigest()
assert len(inventory['commits']) == 7
assert inventory['c7']['change'] == 'vmrowquyxoorvtnrtzqnoszyontoryro'
assert inventory['c7']['parent'] == inputs['first_six'][-1]['commit']
assert [row['commit'] for row in inventory['commits'][:6]] == [row['commit'] for row in inputs['first_six']]
completed = json.loads(snapshots[BASE / 'validation-prep/boundary-evidence-complete.json'])
assert [row['boundary'] for row in completed['boundaries']] == list(range(1, 8))
assert all(row['status'] == 'completed' and row['all_recorded_required_jobs_pass'] for row in completed['boundaries'])
assert [row['declared_revision'] for row in completed['boundaries'][:6]] == [row['commit'] for row in inputs['first_six']]
runtime = json.loads(snapshots[BASE / 'validation-prep/runtime-evidence-complete.json'])
pin = json.loads(snapshots[BASE / 'runtime-candidate.json'])
assert runtime['declared_revision'] == pin['revision'] and runtime['declared_tree'] == pin['tree']
assert runtime['declared_tree'] == completed['boundaries'][-1]['source_integrity']['tree']
assert runtime['aggregate']['all_required_selections_complete'] and runtime['aggregate']['all_selected_tests_pass']
assert runtime['declared_revision'] == completed['boundaries'][-1]['declared_revision']
before = TARGET.read_bytes()
s = before.decode()
source_table = s.split('| # | Source |', 1)[1].split('\n## Ownership boundaries', 1)[0]
assert len([line for line in source_table.splitlines() if line.startswith('| ') and line.split('|')[1].strip().isdigit()]) == 42
old_paragraphs = s.split('\n\n')[1:3]
new_paragraphs = [
'The **42 input commits (37 remote and five review commits)** map to seven functional owners. The input ownership table records their source attribution. Current revisions include the motivation audit, powered-dot regressions, public parser tests, inspection JSON fix and complete GL00/GL04 child reconstruction certificates. The [stack review](raised-energy-cff-stack-review.md#validation) and [validation record](raised-energy-cff-stack-review-validation.md) record passing checks at all seven boundaries and the completed final runtime selections.',
f"The [provenance bundle](raised-energy-cff-stack-provenance.json) records source revisions, trees and jj checkpoints. The [coverage manifest](raised-energy-cff-stack-coverage.json) accounts for {inventory['counts']['commit_path_records']} commit/path entries and {inventory['counts']['distinct_paths']} distinct paths in the complete seven-commit inventory. Final documentation review and rendered artifacts are recorded in the external closure receipt. Benchmark-source measurements retain their own scope."
]
for old, new in zip(old_paragraphs, new_paragraphs):
    assert s.count(old) == 1
    s = s.replace(old, new, 1)
old = json.loads(snapshots[BASE.parent / 'reconstructed-candidate.json'])[:6]
for previous, current in zip(old, inputs['first_six']):
    if previous['commit'] != current['commit']:
        assert s.count(previous['commit']) == 1
        s = s.replace(previous['commit'], current['commit'], 1)
s = s.replace('Integrates raised-energy CFF and local UV reconstruction |', 'Integrates raised-energy CFF and local UV reconstruction, including complete GL00/GL04 child certificates |', 1)
s = s.replace('Commit 7 is identified by jj change `vmrowquy` while the documentation is finalized;', 'Commit 7 is identified by stable jj change `vmrowquy`;', 1)
s = s.replace('Commit 3 owns core consumers, source assignment, exact reconstruction and denominator-incidence handling.', 'Commit 3 owns core consumers, source assignment, exact reconstruction and denominator-incidence handling. Its GL00 T0+T1 and GL04 T0+T1+T2 child certificates check complete signed numerators and separate denominator contracts; full-route numerical tests provide complementary coverage.', 1)
assert s.split('| # | Source |', 1)[1].split('\n## Ownership boundaries', 1)[0] == source_table
assert 'Pending' not in s and 'pending' not in s
assert TARGET.read_bytes() == before and args.inventory.read_bytes() == inventory_bytes
assert all(path.read_bytes() == data for path, data in snapshots.items())
TARGET.write_text(s)
receipt = {'inputs': [{'path': str(path), 'sha256': hashlib.sha256(data).hexdigest()} for path, data in snapshots.items()], 'input_inventory': str(args.inventory), 'inventory_sha256': hashlib.sha256(inventory_bytes).hexdigest(), 'before_sha256': hashlib.sha256(before).hexdigest(), 'after_sha256': hashlib.sha256(TARGET.read_bytes()).hexdigest(), 'original_42_source_rows_unchanged': True, 'source_table_sha256': hashlib.sha256(source_table.encode()).hexdigest(), 'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
with args.receipt.open('x') as stream:
    json.dump(receipt, stream, indent=2); stream.write('\n')
print(json.dumps(receipt))

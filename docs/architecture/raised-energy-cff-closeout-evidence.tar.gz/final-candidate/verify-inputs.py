#!/usr/bin/env python3
"""Read-only v2 input/scope proof; writes one fresh scratch validation manifest."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

ROOT = Path('/tmp/raised-stack/closeout/gl00-certificate-v2')
ORIGINAL = ROOT.parent
REPO = Path('/common/dev/gammaloop/higher-power-energies-review')
BASE = '395610143576507503fd2c785db3ba62340f4277'
OLD_RUNTIME = 'a474c96016a6236d0e91cb67dd284fe91a6c38b7'
SOURCE = 'crates/gammalooprs/src/graph/three_d_source.rs'
DOCUMENT = 'docs/architecture/exact-powered-denominator-cff-lifting.md'
CERTIFICATE = 'graph::three_d_source::tests::gl00_gl04_planned_lifts_match_post_t_numerators_in_common_loop_coordinates'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--candidate-sha256', required=True)
    parser.add_argument('--amendment-sha256', required=True)
    args = parser.parse_args()
    assert all(re.fullmatch('[0-9a-f]{64}', value) for value in [args.candidate_sha256, args.amendment_sha256])
    output = ROOT / 'validation-inputs.json'
    assert not output.exists()
    observed = {}
    commands = []

    def read(path):
        data = path.read_bytes()
        assert path not in observed or observed[path] == data
        observed[path] = data
        return data

    def load(path):
        return json.loads(read(path))

    def git(*argv):
        command = ['git', '-C', str(REPO), *argv]
        commands.append(command)
        return subprocess.check_output(command, env={**os.environ, 'GIT_OPTIONAL_LOCKS': '0'})

    candidate_bytes = read(ROOT / 'reconstructed-candidate.json')
    amendment_bytes = read(ROOT / 'amendment.json')
    assert hashlib.sha256(candidate_bytes).hexdigest() == args.candidate_sha256
    assert hashlib.sha256(amendment_bytes).hexdigest() == args.amendment_sha256
    candidate, amendment = json.loads(candidate_bytes), json.loads(amendment_bytes)
    baseline = load(ORIGINAL / 'reconstructed-candidate.json')
    assert len(candidate) == 7 and [row['number'] for row in candidate] == list(range(1, 8))
    for number in [0, 1]:
        assert all(candidate[number][key] == baseline[number][key] for key in ['number', 'commit', 'tree', 'parents'])
    assert amendment['status'] == 'accepted_for_reconstruction'
    assert amendment['certificate_test'] == CERTIFICATE and amendment['owning_commit'] == 3
    assert set(amendment['accepted_c3_file_sha256']) == {SOURCE, DOCUMENT}
    assert all(re.fullmatch('[0-9a-f]{64}', value) for value in amendment['accepted_c3_file_sha256'].values())
    for key in ['formatted_patch', 'oracle_review', 'formatting_receipt', 'architecture_review', 'proposal_freeze']:
        path = Path(amendment[key]['path']).resolve()
        assert path.is_relative_to(ORIGINAL / 'gl00-certificate-proposal')
        assert hashlib.sha256(read(path)).hexdigest() == amendment[key]['sha256']
    propagation_path = Path(amendment['doc_propagation']['path']).resolve()
    assert propagation_path == ROOT / 'doc-propagation-prep/manifest.json'
    propagation_bytes = read(propagation_path)
    assert hashlib.sha256(propagation_bytes).hexdigest() == amendment['doc_propagation']['sha256']
    propagation = json.loads(propagation_bytes)
    assert propagation['status'] == 'PASS' and propagation['proposed_c3_document_sha256'] == amendment['accepted_c3_file_sha256'][DOCUMENT]
    assert [row['boundary'] for row in propagation['records']] == [3, 4, 5, 6]
    expected_docs = {}
    for record in propagation['records']:
        number = record['boundary']
        assert record['exit_code'] == 0 and record['baseline_commit'] == baseline[number - 1]['commit'] and record['source_c3_commit'] == baseline[2]['commit']
        patch = git('diff', '--no-ext-diff', '--no-renames', '--binary', baseline[2]['commit'], baseline[number - 1]['commit'], '--', DOCUMENT)
        assert hashlib.sha256(patch).hexdigest() == record['original_doc_patch_sha256']
        expected_path = Path(record['expected_document']).resolve()
        assert expected_path.is_relative_to(ROOT / 'doc-propagation-prep')
        expected_bytes = read(expected_path)
        assert hashlib.sha256(expected_bytes).hexdigest() == record['expected_sha256']
        expected_docs[number] = record['expected_sha256']
    assert expected_docs[3] == amendment['accepted_c3_file_sha256'][DOCUMENT]
    before = read(ORIGINAL / 'before-duplicate.json')
    assert hashlib.sha256(before).hexdigest() == '4ed74f12ca1678b578932b5e08b8c0fad262cf6de5b58d5b12495ff3a27b2a64'
    assert len(json.loads(before)['inputs']) == 10
    runtime = load(ORIGINAL / 'validation-prep/runtime-evidence-complete.json')
    assert runtime['declared_revision'] == OLD_RUNTIME and runtime['aggregate']['all_required_selections_complete'] and runtime['aggregate']['all_selected_tests_pass']
    complete = load(ORIGINAL / 'final-stack-driver-completion.json')
    assert complete['revision'] == OLD_RUNTIME and len(complete['completed_jobs']) == 10
    independent = load(ORIGINAL / 'final-runtime-independent-review.json')
    assert independent['revision'] == OLD_RUNTIME and independent['status'] == 'PASS'
    preserved = []
    copy_manifest = load(ROOT / 'source-copy-manifest.json')
    for row in copy_manifest['files']:
        assert hashlib.sha256(read(Path(row['source']))).hexdigest() == row['sha256']
        assert hashlib.sha256(read(Path(row['snapshot']))).hexdigest() == row['sha256']
        preserved.append({'source': row['source'], 'sha256': row['sha256']})
    deltas = []
    parent = BASE
    for number, row in enumerate(candidate[:6], 1):
        metadata = git('show', '-s', '--format=%H%x00%T%x00%P%x00%an%x00%ae%x00%cn%x00%ce', row['commit']).decode().strip().split('\0')
        assert metadata[:3] == [row['commit'], row['tree'], parent]
        assert metadata[3:] == ['Lucien Huber', 'im@lcnbr.ch'] * 2
        assert row['parents'] == [parent]
        if number >= 3:
            old = baseline[number - 1]['commit']
            changed = sorted(p.decode() for p in git('diff', '--no-renames', '--name-only', '-z', old, row['commit']).split(b'\0') if p)
            assert changed == sorted([SOURCE, DOCUMENT]), 'Amendment changes unexpected functional paths'
            old_source = git('show', old + ':' + SOURCE)
            new_source = git('show', row['commit'] + ':' + SOURCE)
            marker = b'\n#[cfg(test)]\nmod tests {'
            assert old_source.count(marker) == new_source.count(marker) == 1
            assert old_source.split(marker)[0] == new_source.split(marker)[0], 'Code before the existing test module changed'
            assert new_source.count(('fn ' + CERTIFICATE.rsplit('::', 1)[1] + '(').encode()) == 1
            entries = []
            for path in changed:
                old_entry = git('ls-tree', old, '--', path).decode().strip()
                new_entry = git('ls-tree', row['commit'], '--', path).decode().strip()
                assert old_entry.startswith('100644 blob ') and new_entry.startswith('100644 blob ')
                data = git('show', row['commit'] + ':' + path)
                sha = hashlib.sha256(data).hexdigest()
                expected_sha = amendment['accepted_c3_file_sha256'][SOURCE] if path == SOURCE else expected_docs[number]
                assert sha == expected_sha, 'Accepted test source or exact propagated document differs'
                entries.append({'path': path, 'before': old_entry, 'after': new_entry, 'new_sha256': sha})
            deltas.append({'boundary': number, 'before_commit': old, 'after_commit': row['commit'], 'production_prefix_unchanged': True, 'paths': entries})
        parent = row['commit']
    for path, data in observed.items():
        assert path.read_bytes() == data, 'Pinned input changed during verification'
    result = {'schema_version': 1, 'status': 'PASS', 'created_at_utc': datetime.now(timezone.utc).isoformat(),
        'candidate_sha256': args.candidate_sha256, 'amendment_sha256': args.amendment_sha256,
        'first_six': candidate[:6], 'retained_runtime': OLD_RUNTIME, 'certificate_test': CERTIFICATE,
        'amendment_scope': deltas, 'exact_descendant_document_propagation': amendment['doc_propagation'], 'preserved_v1_sources': preserved,
        'prerequisites': [{'path': str(p), 'sha256': hashlib.sha256(data).hexdigest()} for p, data in observed.items()],
        'commands': commands,
        'limits': ['The production prefix is byte-identical; the existing test module and two-case oracle still require independent semantic review and fresh execution.',
                   'C1/C2 reuse their unchanged revision receipts. C3-C7 require new gates and tests; retained a474 results do not certify new revisions.'],
        'scope': 'Read-only source/identity and retained-runtime prerequisites. This checker executes no Cargo, tests, CLI or jj command.'}
    with output.open('x') as stream:
        json.dump(result, stream, indent=2); stream.write('\n')
    print(json.dumps({'output': str(output), 'status': 'PASS', 'fresh_boundaries': [3, 4, 5, 6, 7], 'reused_unchanged_boundaries': [1, 2]}))


if __name__ == '__main__':
    main()

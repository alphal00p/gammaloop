#!/usr/bin/env python3
"""Run fresh v2 C3-C6 gates and owning suites after pinned input verification."""
from pathlib import Path
import argparse
import hashlib
import json
import re
import subprocess

ROOT = Path('/tmp/raised-stack/closeout/gl00-certificate-v2')
PREP = ROOT / 'validation-prep'
PYTHON = '/tmp/raised-stack/python'
JOBS = {
    3: ['commit3-cff-uv', 'shared-default', 'shared-all', 'shared-no-default'],
    4: ['commit4-workflows', 'commit4-scalar-smoke', 'signed-acceptances', 'source-certificates', 'shared-default', 'shared-all', 'shared-no-default'],
    5: ['commit5-phases', 'signed-acceptances', 'vertex-rules', 'source-certificates', 'shared-default', 'shared-all', 'shared-no-default'],
    6: ['commit6-vakint-uv', 'source-certificates', 'shared-default', 'shared-all', 'shared-no-default'],
}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--candidate-sha256', required=True)
    parser.add_argument('--amendment-sha256', required=True)
    parser.add_argument('--verified-inputs-sha256', help='Reuse the exact successful read-only input receipt after a pre-gate setup failure')
    args = parser.parse_args()
    assert not any((PREP / f'boundary-{number}').exists() for number in range(3, 8))
    input_path = ROOT / 'validation-inputs.json'
    if args.verified_inputs_sha256:
        assert re.fullmatch('[0-9a-f]{64}', args.verified_inputs_sha256)
        assert hashlib.sha256(input_path.read_bytes()).hexdigest() == args.verified_inputs_sha256
        inputs = json.loads(input_path.read_bytes())
        for prerequisite in inputs['prerequisites']:
            assert hashlib.sha256(Path(prerequisite['path']).read_bytes()).hexdigest() == prerequisite['sha256'], 'Previously verified input changed'
    else:
        assert not input_path.exists(), 'Use the explicit verified-input receipt hash after a setup failure; existing evidence is preserved'
        subprocess.run([PYTHON, str(ROOT / 'verify-inputs.py'), '--candidate-sha256', args.candidate_sha256, '--amendment-sha256', args.amendment_sha256], check=True)
        inputs = json.loads(input_path.read_bytes())
    assert inputs['status'] == 'PASS'
    assert inputs['candidate_sha256'] == args.candidate_sha256 and inputs['amendment_sha256'] == args.amendment_sha256
    assert hashlib.sha256((ROOT / 'reconstructed-candidate.json').read_bytes()).hexdigest() == args.candidate_sha256
    assert hashlib.sha256((ROOT / 'amendment.json').read_bytes()).hexdigest() == args.amendment_sha256
    assert subprocess.check_output(['jj', '--ignore-working-copy', '-R', '/tmp/raised-stack/prefix', 'log', '-r', '@', '--no-graph', '-T', 'commit_id'], text=True).strip() == inputs['retained_runtime']
    subprocess.run([PYTHON, str(PREP / 'audit-prefix.py'), '--revision', inputs['retained_runtime'], '--label', 'before-v2-first-prefix-move', '--output', str(PREP / 'pre-v2-prefix-source-audit.json')], check=True)
    records = list(inputs['first_six'][:2])
    for row in inputs['first_six'][2:]:
        number, revision = row['number'], row['commit']
        assert hashlib.sha256((ROOT / 'reconstructed-candidate.json').read_bytes()).hexdigest() == inputs['candidate_sha256']
        subprocess.run(['jj', '-R', '/tmp/raised-stack/prefix', 'edit', revision], check=True)
        subprocess.run(['bash', str(PREP / 'validate-boundary'), str(number), revision], check=True)
        for job in JOBS[number]:
            print(f'V2 boundary {number}: {job}', flush=True)
            subprocess.run(['bash', str(PREP / 'final-runtime-job'), revision, job, str(PREP / f'boundary-{number}')], check=True)
        records.append(row)
        (ROOT / 'functional-stack-progress.json').write_text(json.dumps({'completed_boundaries': records, 'unchanged_revision_receipts_reused': [1, 2], 'fresh_completed_boundaries': [r['number'] for r in records if r['number'] >= 3]}, indent=2) + '\n')
        print(f'V2 boundary {number} gates and owning tests complete', flush=True)
    subprocess.run([PYTHON, str(PREP / 'collect-boundary-evidence.py'), '--through', '6', '--output', str(PREP / 'boundary-evidence-through6.json')], check=True)
    print('V2 C3-C6 validation complete; C1/C2 retained by identical revisions', flush=True)


if __name__ == '__main__':
    main()

#!/usr/bin/env python3
"""Refresh only the main Markdown/Typst reports from complete fresh receipts.

Preparation only until root explicitly runs this script. No subprocess, build,
collector, PDF rendering, history query or mutation is performed. C7 inventory
proves accounting; its final semantic/render review belongs to external closure.
"""
import argparse
from collections import Counter
from datetime import date, datetime, timezone
import hashlib
import json
from pathlib import Path
import re

ROOT = Path('/common/dev/gammaloop/higher-power-energies-review')
BASE = Path('/tmp/raised-stack/closeout')
V2 = BASE / 'gl00-certificate-v2'
DOCS = ROOT / 'docs/architecture'
MD = DOCS / 'raised-energy-cff-stack-review.md'
TYP = DOCS / 'raised-energy-cff-stack-review.typ'
RENDERER = Path('/tmp/raised-stack/current-report/build_report_typst.py')
PRIOR_SIX = [
    '97eb06cbd3b09cd62c242f27da668accf68173c8',
    '2ba79605128090281bf4ebffdfa0f1c52fb4ba7f',
    '60b36ebce8b204090674cd3fbb63c8425ce6ed25',
    'fe8aaa4a2173117f47ca9202801bb263bccc95e6',
    '095016907e0e3fe47485a60cecda8fa693868a95',
    '86dd57af7efa6acec4bf870c25f97df92d082acc',
]
CHANGE = 'vmrowquyxoorvtnrtzqnoszyontoryro'
NAMES = {
    'curated': 'Curated GammaLoop', 'commit5-phases': 'Phase regressions',
    'signed-acceptances': 'Signed acceptances', 'commit6-vakint-uv': 'Vakint / UV',
    'scalar-all': 'Full scalar matrix, including slow cases',
    'shared-default': 'Shared CFF: default', 'shared-all': 'Shared CFF: all features',
    'shared-no-default': 'Shared CFF: no default features',
    'ufo-model-parity': 'UFO model parity', 'vertex-rules': 'Vertex rules',
}
READS = {}


def read(path):
    path = path.resolve()
    assert path.is_relative_to(BASE) or path in {MD, TYP, RENDERER}, path
    assert path != Path('/tmp/raised-stack/run'), 'License wrapper is invocation-only'
    data = path.read_bytes()
    assert path not in READS or READS[path] == data, ('Input changed', path)
    READS[path] = data
    return data


def load(path):
    return json.loads(read(path))


def passed(record, revision, tests=False):
    assert record['status'] == 'completed' and record['exit_code'] == 0
    assert record['declared_revision'] == revision
    assert record['watchdog']['limit_bytes'] == 30_000_000_000
    if tests:
        result = record['tests']
        assert result['selected'] > 0 and result['passed'] == result['selected']
        assert result['failed'] == 0 and result['passed'] == len(result['cases'])
        assert all(row['status'] == 'PASS' for row in result['cases'])
        context = record['context']
        assert all(context[key] == value for key, value in {
            'workers': '4', 'retries': '0', 'snapshot_updates': 'no',
            'memory_limit_decimal_gb': '30',
        }.items())
        return result


def replace_once(source, old, new):
    assert source.count(old) == 1, ('Expected one current-report anchor', old)
    return source.replace(old, new, 1)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--boundary', type=Path, required=True)
    parser.add_argument('--runtime', type=Path, required=True)
    parser.add_argument('--inventory', type=Path, required=True)
    parser.add_argument('--replay', type=Path, required=True, help='Passed GL04 replay manifest.json')
    parser.add_argument('--build', type=Path, default=V2 / 'frozen-cli-build-receipt.json')
    parser.add_argument('--functional-review', type=Path, default=V2 / 'reconstructed-functional-review.json')
    parser.add_argument('--date', type=date.fromisoformat, default=datetime.now(timezone.utc).date())
    parser.add_argument('--receipt', type=Path, required=True, help='New external JSON receipt under closeout')
    args = parser.parse_args()
    receipt_path = args.receipt.resolve()
    assert receipt_path.is_relative_to(BASE) and receipt_path.suffix == '.json' and not receipt_path.exists()
    assert receipt_path.parent.is_dir()
    boundary_doc, runtime, inventory, replay, build, review = [load(path) for path in (
        args.boundary, args.runtime, args.inventory, args.replay, args.build, args.functional_review)]
    validation_inputs = load(V2 / 'validation-inputs.json')
    assert hashlib.sha256(read(V2 / 'validation-inputs.json')).hexdigest() == 'b9740c1a68baaeef17cfe860b927ea7766d65cfa93bf9044adab6dd79c5a76a1'
    assert validation_inputs['status'] == 'PASS'
    SIX = [row['commit'] for row in validation_inputs['first_six']]
    assert SIX[:2] == PRIOR_SIX[:2] and len(SIX) == 6
    assert review['new_six'] == validation_inputs['first_six']
    assert review['v2_validation_inputs']['sha256'] == hashlib.sha256(read(V2 / 'validation-inputs.json')).hexdigest()
    assert review['v2_amendment']['sha256'] == validation_inputs['amendment_sha256']
    assert boundary_doc['schema_version'] == runtime['schema_version'] == inventory['schema_version'] == 1
    boundaries = {row['boundary']: row for row in boundary_doc['boundaries']}
    assert len(boundary_doc['boundaries']) == 7 and set(boundaries) == set(range(1, 8))
    assert [boundaries[n]['declared_revision'] for n in range(1, 7)] == SIX
    assert [row['commit'] for row in review['commits']] == SIX
    gates, features, early_tests = [], [], []
    for number, row in boundaries.items():
        revision = row['declared_revision']
        assert row['reused_unchanged_revision_certificate'] == (number in {1, 2}), 'Only unchanged C1/C2 receipts may be reused'
        assert row['status'] == 'completed' and row['all_recorded_required_jobs_pass']
        assert row['source_integrity']['status'] == 'completed'
        assert row['source_integrity']['revision'] == revision
        assert set(row['gates_and_targeted']) == {'fmt', 'check', 'build', 'clippy'}
        expected_features = (set() if number == 1 else {'shared-all', 'shared-no-default'})
        expected_features |= {'python-api'} if number == 4 else set()
        expected_features |= {'vakint-community'} if number == 6 else set()
        assert set(row['feature_checks']) == expected_features
        for records, destination in [(row['gates_and_targeted'], gates), (row['feature_checks'], features)]:
            for record in records.values():
                passed(record, revision)
                destination.append(record)
        assert row['shared_or_additional_matrix']
        for pair in row['shared_or_additional_matrix'].values():
            assert pair['list_run_identity_match']
            passed(pair['list'], revision)
            tests = passed(pair['run'], revision, tests=True)
            if number < 7:
                early_tests.append((number, tests))
    revision, tree = runtime['declared_revision'], runtime['declared_tree']
    assert revision == boundaries[7]['declared_revision']
    assert tree == boundaries[7]['source_integrity']['tree']
    jobs = {job['selection']: job for job in runtime['jobs']}
    assert len(runtime['jobs']) == len(NAMES) and set(jobs) == set(NAMES)
    aggregate = runtime['aggregate']
    assert aggregate['all_required_selections_complete'] and aggregate['all_selected_tests_pass']
    assert not aggregate['missing_or_incomplete_jobs'] and not aggregate['failed_identities']
    assert not aggregate['identities_with_any_nonpass'] and not aggregate['overlapping_status_disagreements']
    results = {}
    identities = set()
    for name, job in jobs.items():
        assert job['status'] == 'completed' and job['counted_in_executed_union'] and job['list_run_identity_match']
        tests = passed(job['listing_and_execution']['run'], revision, tests=True)
        passed(job['listing_and_execution']['list'], revision)
        results[name] = tests
        identities.update((case['binary_id'], case['test_name']) for case in tests['cases'])
        # C7 boundary and final-runtime collectors describe the same executions.
        c7_tests = boundaries[7]['shared_or_additional_matrix'][name]['run']['tests']
        assert c7_tests == tests, ('C7/final runtime receipts differ', name)
    assert sum(row['selected'] for row in results.values()) == aggregate['actual_executions']
    assert len(identities) == aggregate['distinct_identities']
    assert aggregate['execution_status_counts'] == {'PASS': aggregate['actual_executions']}
    scalar = jobs['scalar-all']['scalar_namespace_counts']
    assert scalar['standard'] + scalar['slow'] == scalar['total'] == results['scalar-all']['selected']
    assert scalar['slow'] > 0

    assert inventory['complete_inventory'] and inventory['first_six_exact_review_coverage_match']
    assert inventory['review_receipt']['sha256'] == hashlib.sha256(read(args.functional_review)).hexdigest()
    assert [row['commit'] for row in inventory['commits'][:6]] == SIX
    assert inventory['c7']['parent'] == SIX[-1] and inventory['c7']['change'] == CHANGE
    assert inventory['c7']['complete_inventory']
    assert inventory['revision'] == inventory['c7']['commit'] and inventory['tree'] == inventory['c7']['tree']
    assert len(inventory['commits']) == 7 and inventory['commits'][-1] == inventory['c7']
    assert inventory['c7']['semantic_review']['status'] == 'separate_receipt_required'
    functional_paths = [row['path'] for commit in review['commits'] for row in commit['paths'] if row['new_owner_changed']]
    coverage = Counter(row['coverage'] for commit in review['commits'] for row in commit['paths'] if row['new_owner_changed'])
    functional_records, functional_distinct = len(functional_paths), len(set(functional_paths))
    assert functional_records == review['counts']['new_commit_path_records']
    assert functional_distinct == review['counts']['new_distinct_paths']
    assert dict(coverage) == review['counts']['coverage_categories']
    methods = Counter(row['v2_review_method'] for commit in review['commits'] for row in commit['paths'] if row['new_owner_changed'])
    assert dict(methods) == review['counts']['v2_review_methods']
    assert sum(methods.values()) == functional_records
    assert methods['accepted_GL00_fresh_C3_hunk_review'] == len(review['v2_fresh_owning_hunks'])
    assert methods['exact_v1_owning_patch_replay_on_amended_parent'] == len(review['v2_inherited_owning_patch_replays'])
    c7_paths = [row['path'] for row in inventory['c7']['paths']]
    assert len(c7_paths) == len(set(c7_paths)) and c7_paths
    # Reuse the history-closure verifier's report-only scope.
    assert all(path in {
        'PHASE_CONVENTIONS_FIX.md', 'docs/architecture/exact-powered-denominator-cff-lifting.md',
        'docs/architecture/kysvnqlq-rebase-review.md',
    } or (Path(path).parent == Path('docs/architecture')
          and Path(path).name.startswith('raised-energy-cff-')
          and path.endswith(('.md', '.typ', '.pdf', '.json', '.tar.gz'))) for path in c7_paths)
    records, distinct = len(functional_paths) + len(c7_paths), len(set(functional_paths) | set(c7_paths))
    assert inventory['counts']['commit_path_records'] == records
    assert inventory['counts']['distinct_paths'] == distinct
    assert inventory['counts']['first_six_commit_path_records'] == functional_records
    assert inventory['counts']['c7_commit_path_records'] == len(c7_paths)

    assert build['build_exit'] == 0 and build['source_and_copy_equal']
    assert build['revision'] == replay['revision'] == revision and build['tree'] == tree
    assert build['binary_sha256'] == replay['binary_sha256_before'] == replay['binary_sha256_after']
    assert build['frozen_binary'] == replay['binary']
    assert replay['status'] == 'passed' and replay['same_state_as_original_reproducer']
    assert replay['state_unchanged'] and replay['binary_unchanged']
    assert replay['state_sha256_before'] == replay['state_sha256_after']
    assert len(replay['runs']) == 2 and {row['weights'] for row in replay['runs']} == {False, True}
    assert all(row['exit_code'] == 0 and row['json_exists'] and row['plain_and_json_display_matches_original'] for row in replay['runs'])
    assert all(replay['comparison_results'][key] is True for key in [
        'disabled_matches_retained_success', 'toggle_preserves_all_non_additional_weight_content',
        'enabled_additional_weights_complete_and_well_formed', 'structured_threshold_counterterm_exercised'])
    assert replay['resources']['retries'] == 0 and replay['resources']['snapshot_updates'] == 'disabled'

    source = read(MD).decode()
    for old, new in zip(PRIOR_SIX, SIX):
        source = source.replace(old, new).replace(old[:8], new[:8])
    read(TYP)
    day = f'{args.date.day} {args.date.strftime("%B %Y")}'
    source = re.sub(r'(Functionality, Rust idioms, KISS, and behavioral test contracts · )[^\n]+', lambda m: m[1] + day, source, count=1)
    source = replace_once(source,
        '**Fresh per-commit checks, full runtime validation and final diff-coverage totals are pending.** Earlier execution totals do not certify these reconstructed source revisions.',
        '**All seven reconstructed boundaries have passing certificates, and all ten final runtime selections pass at the amended source.** Complete path accounting and the execution evidence below refer to these reconstructed source revisions; final document and history review is recorded separately in the external closure receipt.')
    source = replace_once(source, 'Fresh checks that every commit builds with its ancestors are pending.',
        'Formatting, locked workspace checks, all-target builds, Clippy and owning behavioral selections pass at every commit with its ancestors. C1 and C2 retain their exact unchanged-revision certificates; C3–C7 have fresh checks after the GL00 certificate amendment.')
    source = replace_once(source, 'Documentation uses stable jj change `vmrowquy` while its contents are finalized;',
        'Documentation uses stable jj change `vmrowquy`;')
    source = replace_once(source, 'Fresh default, all-feature and no-default feature runs are pending.',
        'Fresh default, all-feature and no-default-feature test selections pass; all-feature and no-default-feature all-target checks also pass from commit 2 onward.')
    source = replace_once(source,
        'A physical inspection regression compares numerical values, retained weights and grouping with retention disabled and enabled; it does not claim every event metadata field.',
        'A physical inspection regression compares numerical values, retained weights and grouping with retention disabled and enabled; it does not claim every event metadata field. The separate fresh GL04 replay checks complete retained event kinematics, cut metadata, weights and grouping under this toggle, exercises structured threshold-counterterm keys in JSON, and verifies the saved state stays unchanged. This replay supplies serialization and retention evidence; the independent signed contours and physical oracles described elsewhere supply physics evidence.')
    source = replace_once(source,
        'Inspection JSON and the three compact-parser test changes are implemented; their fresh validation belongs to the pending final stack results.',
        'Inspection JSON, the three compact-parser execution regressions and the powered-dot angular-average regression are included in their fresh owning selections. The GL04 replay certifies serialization and retention at its recorded point; it provides no performance measurement or independent physics oracle.')

    source = replace_once(source,
        'GL00 and GL04 certificates independently check factorized common-chart numerators, denominator multiplicities, masses, physical owners, and UV/cograph domains.',
        'GL00 and GL04 child certificates independently check complete factorized common-chart numerators and denominator momenta, multiplicities, masses, physical owners and UV domains. The GL00 edge-5 temporal case uses an independent signed T0+T1 oracle; the GL04 case covers T0+T1+T2. Both retain the vacuum mass in full numerator expressions and the expansion mass in denominator metadata until the documented final mass identification. These checks start from the completed post-Taylor child source and do not certify every forest or the Taylor-producing stage. Separate GL04 source evidence also includes the cograph domain.')
    source = replace_once(source,
        'Borrows and global locks remain short.',
        'Parser borrows are scoped, and parallel lookups release the global map lock before bucket comparisons.')
    source = replace_once(source,
        'Their owner, sign, denominator, and dimensional distinctions are mathematically necessary.',
        'Their owner, sign, denominator, and dimensional distinctions are mathematically necessary. The motivation audit does not demonstrate a benefit from compaction on its reached single-component product or from extra losing assignment proposals on its completed GL04 inputs. These remain bounded simplification candidates.')
    source = replace_once(source,
        'UFO/JSON model parity covers 22 Lorentz structures, 108 couplings, 153 vertices, 72 parameter declarations, 43 particle contracts, three quartets, and three vector propagators. Five deterministic substitutions provide sampled expression checks.',
        'The retained UFO/JSON model-asset audit covers 22 Lorentz structures, 108 couplings, 153 vertices, 72 parameter declarations, 43 particle contracts, three quartets and three vector propagators, with five deterministic substitutions for sampled expression checks. All 25 audited asset entries retain their modes and blobs. The fresh `fresh_sm_ufo_preserves_virtual_gauge_and_covariant_cut_states` regression checks covariant multiplets and twelve named W/Z, Goldstone and ghost propagator/state contracts.')

    lines = ['## Validation', '',
        f'**All seven reconstructed boundaries and all ten final runtime selections pass.** The executable implementation is pinned by commits 1–6, ending at `{SIX[-1]}`. Final runtime ran at `{revision}` (tree `{tree}`). Documentation remains in stable jj change `vmrowquy`; the external closure receipt records its final content/render review and exact source-to-bookmark checks.', '',
        'The [validation reference](raised-energy-cff-stack-review-validation.md) records exact fresh commands, selected identities, counts, configurations, diagnostics and warnings. The [closeout evidence archive](raised-energy-cff-closeout-evidence.tar.gz) and [archive receipt](raised-energy-cff-closeout-evidence.json) retain the underlying records. The retained initial-candidate runtime and motivation-audit measurements are not counted as amended-source runtime executions. C1/C2 reuse exactly matching revision certificates; C3–C7 are revalidated after the GL00 amendment.', '',
        '| Boundary checks | Passed / recorded | Guard time |', '| --- | --- | --- |',
        f'| Formatting, locked workspace check, all-target build and Clippy | {len(gates)} / {len(gates)} | {sum(r["watchdog"]["elapsed_seconds"] for r in gates):.3f} s |',
        f'| Required shared-CFF and optional API feature checks | {len(features)} / {len(features)} | {sum(r["watchdog"]["elapsed_seconds"] for r in features):.3f} s |', '',
        'Guard times include complete commands and build work. The following times are nextest test-execution times and are not end-to-end benchmark timings.', '',
        '| Owning boundary | Passed / selected executions | Test time |', '| --- | --- | --- |']
    for number in range(1, 7):
        rows = [tests for owner, tests in early_tests if owner == number]
        total = sum(row['selected'] for row in rows)
        lines.append(f'| Commit {number} | {total} / {total} | {sum(row["elapsed_seconds"] for row in rows):.3f} s |')
    early_count = sum(row['selected'] for _, row in early_tests)
    early_skips = sum(row['skipped'] for _, row in early_tests)
    lines += ['', f'C1–C6 owning selections account for {early_count} passing executions, zero failing executions and {early_skips} reported skipped entries. C1/C2 figures describe their retained unchanged-revision certificates, while C3–C6 figures describe fresh amended-boundary executions. Repeated boundaries and feature configurations remain separate executions. C7’s behavioral records are the same ten final runtime selections below and are counted once.', '',
        '| Final runtime selection | Passed / selected | Test time |', '| --- | --- | --- |']
    for name, label in NAMES.items():
        row = results[name]
        lines.append(f'| {label} | {row["passed"]} / {row["selected"]} | {row["elapsed_seconds"]:.3f} s |')
    skips = sum(row['skipped'] for row in results.values())
    lines += ['',
        f'Final runtime: **{aggregate["actual_executions"]} passing executions across {aggregate["distinct_identities"]} distinct binary/test identities**, zero failing executions, {skips} reported skipped entries, and {len(aggregate["configurations"])} recorded Cargo/environment configurations. Distinct identities are binary/test pairs across all runs; configurations and repeated executions are reported separately. Skipped entries are outside the selected run and are not passing executions. Overlapping selections and feature configurations are counted separately as executions.', '',
        f'The full scalar matrix includes {scalar["standard"]} standard and {scalar["slow"]} slow cases ({scalar["total"]} total), selected directly in release mode with ignored tests enabled. Licensed tests run with four workers, zero retries, disabled snapshot updates and a 30 GB process-tree RSS limit; Cargo uses four build jobs. The scalar command does not use the wrapper’s forced single-test setting. Clippy and the explicitly warning-tolerant curated/scalar commands pass with compiler/dependency warnings retained in the validation reference; passing exits do not mean warning-free compilation.', '',
        f'The fresh GL04 replay completes four inspection calls: plain and JSON output with additional weights disabled and enabled. Its frozen CLI SHA-256 `{build["binary_sha256"]}` exactly matches the binary copied from the successful C7 build. Disabled output matches the retained successful evaluation; the toggle preserves complete non-additional-weight content, including every event’s kinematics, cut metadata and complex weight, with group membership and multiplicity retained. Every emitted additional-weight entry is a well-formed key/value pair, and the output contains a structured `ThresholdCounterterm`; the replay does not independently determine the expected physical key set. Only documented timing metadata and the empty-object-to-pair-list weight encoding are normalized. The saved state and binary hashes are unchanged. This is serialization/retention evidence, independent of the signed-contour and analytic physics oracles; it is not a performance measurement.', '',
        f'Coverage accounts for **{records} commit/path records and {distinct} distinct paths** at inventory revision `{inventory["revision"]}`. C1–C6 coverage consists of {functional_records} records over {functional_distinct} paths. Relative to the retained initial review, {methods["exact_v1_before_after_transition_reuse"]} exact before/after transitions reuse their existing review, {methods["exact_v1_owning_patch_replay_on_amended_parent"]} owning architecture patches replay exactly on the amended parent, and {methods["accepted_GL00_fresh_C3_hunk_review"]} C3 source/document records have fresh GL00 review. Earlier fresh-hunk and original-patch review methods remain linked in that retained lineage. C7 contains {len(c7_paths)} documentation/evidence paths. Final C7 content and render review is recorded separately in the external closure receipt; inventory alone is not semantic review. These totals come from complete immutable-tree inventories, including the new evidence files. The motivation audit does not certify new paths, and coverage does not mean every unchanged repository line was reread.', '']
    start = source.index('## Validation\n')
    end = source.index('## Scope and remaining limitations\n', start)
    source = source[:start] + '\n'.join(lines) + '\n' + source[end:]
    assert not re.search(r'\bpending\b', source, flags=re.IGNORECASE)
    assert all(f'`{revision[:8]}`' in source for revision in SIX)
    assert '`vmrowquy`' in source and 'codex/raised-energy-cff-reviewed' in source
    typst = render(source, args.date)
    read(RENDERER)  # Record the renderer whose inline/table mechanism was reused.
    for path, data in READS.items():
        assert path.read_bytes() == data, ('Input changed before writing', path)
    receipt = {
        'schema_version': 1, 'created_at_utc': datetime.now(timezone.utc).isoformat(),
        'runtime_revision': revision, 'runtime_tree': tree, 'inventory_revision': inventory['revision'],
        'functional_commits': SIX, 'documentation_change': CHANGE,
        'coverage': {'commit_path_records': records, 'distinct_paths': distinct, 'c7_paths': len(c7_paths),
                     'semantic_c7_review': 'requires_separate_external_closure'},
        'final_runtime': aggregate, 'c1_to_c6_passing_executions': early_count,
        'frozen_cli_replay_sha256': build['binary_sha256'],
        'inputs': [{'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()} for path, data in READS.items()],
        'outputs': [{'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()} for path, data in [(MD, source.encode()), (TYP, typst.encode())]],
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'scope': 'Only the two named main reports are rewritten. No PDF compilation/inspection, Git/jj action, collector, test or benchmark is executed; final document/history closure remains external.',
    }
    MD.write_text(source)
    TYP.write_text(typst)
    with receipt_path.open('x') as stream:
        stream.write(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({'reports_written': [str(MD), str(TYP)], 'receipt': str(receipt_path), 'coverage': receipt['coverage']}))


# The generated Typst file is self-contained; this draft helper is not a runtime dependency.
def inline(value):
    parts = re.split(r'(`[^`]+`|\*\*[^*]+\*\*|\[[^\]]+\]\([^)]+\))', value)
    out = []
    for part in parts:
        if not part:
            continue
        if part.startswith('`'):
            out.append('#text(font: "DejaVu Sans Mono", size: 0.86em, ' + json.dumps(part[1:-1], ensure_ascii=False) + ')')
        elif part.startswith('**'):
            out.append('#strong(' + json.dumps(part[2:-2], ensure_ascii=False) + ')')
        elif part.startswith('['):
            label, target = re.fullmatch(r'\[([^\]]+)\]\(([^)]+)\)', part).groups()
            out.append('#link(' + json.dumps(target, ensure_ascii=False) + ')[#text(' + json.dumps(label, ensure_ascii=False) + ')]')
        else:
            out.append('#text(' + json.dumps(part, ensure_ascii=False) + ')')
    return ''.join(out)


def render(source, report_date):
    # Reuse the existing self-contained inline/table renderer and update its date.
    header = '''// Self-contained typesetting of raised-energy-cff-stack-review.md.
// Current implementation, validation results, and coverage limits.
#set document(date: datetime(year: 2026, month: 9, day: 10), title: "Raised-energy CFF stack review", author: "Codex",
  description: "Seven-commit reconstruction: correctness, Rust idioms, KISS and outward test contracts; current implementation and completed validation.")
#set page(paper: "a4", margin: (x: 18mm, top: 19mm, bottom: 18mm),
  header: align(right)[#text(font: "DejaVu Sans", size: 8pt, fill: rgb("667085"))[GammaLoop / Reconstructed stack review]],
  footer: context [#line(length: 100%, stroke: 0.4pt + rgb("d0d5dd"))
    #v(2mm)
    #text(font: "DejaVu Sans", size: 8pt, fill: rgb("667085"))[Current implementation review #h(1fr) #counter(page).display("1 / 1", both: true)]])
#set text(font: "Libertinus Serif", size: 10.5pt, fill: rgb("202939"))
#set par(leading: 0.58em, spacing: 0.78em, justify: false)
#set heading(numbering: none)
#show heading.where(level: 1): set text(font: "DejaVu Sans", size: 16pt, fill: rgb("163e59"))
#show heading.where(level: 2): set text(font: "DejaVu Sans", size: 11pt, weight: "bold")
#show link: set text(fill: rgb("146c94"))
#set table(stroke: 0.4pt + rgb("d0d5dd"), inset: 6pt,
  fill: (x, y) => if y == 0 { rgb("e8eff5") } else if calc.odd(y) { rgb("f7f9fb") } else { none })

#text(font: "DejaVu Sans", size: 9pt, weight: "bold", fill: rgb("146c94"))[ENGINEERING REVIEW]
#v(4mm)
#text(font: "DejaVu Sans", size: 26pt, weight: "bold", fill: rgb("163e59"))[Raised-energy CFF stack]
#v(2mm)
#text(font: "DejaVu Sans", size: 12pt)[Functionality · Test contracts · Rust idioms · KISS]
#v(3mm)
#text(size: 9pt, fill: rgb("667085"))[10 September 2026 · Seven functional commits]
#v(4mm)
'''
    header = header.replace("year: 2026, month: 9, day: 10", f"year: {report_date.year}, month: {report_date.month}, day: {report_date.day}")
    header = header.replace("10 September 2026", f"{report_date.day} {report_date.strftime("%B %Y")}")
    lines = source.splitlines()
    blocks = [header]
    i = 4
    while i < len(lines):
        line = lines[i]
        if not line.strip():
            i += 1
            continue
        if line.startswith('## '):
            blocks.append('= ' + inline(line[3:]) + '\n')
            i += 1
            continue
        if line.startswith('| '):
            rows=[]
            while i < len(lines) and lines[i].startswith('| '):
                cells=[x.strip() for x in lines[i].strip('|').split('|')]
                if not all(re.fullmatch(r'[-: ]+', x) for x in cells):
                    rows.append(cells)
                i += 1
            count=len(rows[0])
            widths = '(0.08fr, 0.22fr, 0.70fr)' if rows[0][0] == '#' else {2:'(0.32fr, 0.68fr)',3:'(0.56fr, 0.24fr, 0.20fr)',4:'(0.10fr, 0.38fr, 0.18fr, 0.34fr)'}[count]
            cells=[]
            for row in rows[1:]:
                cells.extend('['+inline(c)+']' for c in row)
            table_header='table.header('+', '.join('['+inline(c)+']' for c in rows[0])+'),'
            blocks.append('#block[\n#set text(size: 8.6pt)\n#table(columns: '+widths+',\n'+table_header+'\n'+',\n'.join(cells)+',\n)\n]\n')
            continue
        para=[]
        while i < len(lines) and lines[i].strip() and not lines[i].startswith('## ') and not lines[i].startswith('| '):
            para.append(lines[i]);i+=1
        text=' '.join(para)
        rendered=inline(text)
        if text.startswith('**DRAFT'):
            rendered='#block(fill: rgb("fff4df"), stroke: 0.6pt + rgb("b7791f"), inset: 9pt)[\n'+rendered+'\n]'
        blocks.append(rendered+'\n')
    return "\n".join(blocks)


if __name__ == "__main__":
    main()

# Independent v2 validation script review

Result: **PASS — static review only. No remaining finding in the pinned prepared scripts.**

Complete core input verifier and functional/final validation drivers; validation job/gate scripts; boundary/runtime collectors; source and mtime audits; physical replay scripts and their v1 deltas; preparation usage, amendment template and archive policy; separately prepared independent runtime reconciler. This receipt certifies review of pinned scripts, not execution or final stack completion.

The exact scope and SHA256 inventory are in `independent-validation-script-review.json`.

Reviewed safeguards:

- Candidate and amendment hashes, proposal reviews, freeze receipt and accepted file bytes are linked; original history remains preserved and prepared validation fails on unrecognized source changes.
- Linear ancestry, exact revisions/trees, Lucien Huber author and committer identity, owning C3 test-module-only source amendment and preserved later document changes are checked before fresh jobs.
- Boundary gates include formatting, locked workspace all-target check/build, Clippy and both shared-CFF feature checks, followed by owning behavioral selections; failures preserve raw exits and stop progression.
- List/run identities, context, arguments, watchdog completion, source inventory and mtime audit links are checked. Complete result values and test identities are counted without treating repeated configurations as new distinct tests.
- The combined GL00/GL04 certificate must actually occur in the required C3 and final curated selections. One test entry exercises two physical child fixtures; no increase in test-ID count is inferred from fixture count.
- Independent runtime reconciliation parses raw selections and outcomes independently of the collector parser and compares the resulting counts, identity sets and configuration overlaps; it requires the accepted source SHA and actual combined certificate.
- Physical replay retains its native complete event-group multiset comparison and exact multiplicities, with only declared timing/empty-weight normalization; additional_weights is excluded only across retention-toggle comparisons. This checks serialization and retention, not an independent physics oracle.
- Source and frozen binary identities are audited before and after work; the physical review must independently match the new runtime revision, tree and copied binary.
- Preserved initial evidence, fresh v2 evidence and diagnostic attempts occupy explicitly distinct archive scopes; final report/PDF/history closure requires separate external receipts.

Resolved during review:

- Reuse and descendant evidence could be insufficiently tied to exact source identities. Boundary collector pins the unchanged C1/C2 full revisions and trees; C3-C6 must match verified candidate inputs and C7 must match the explicit runtime candidate.
- Accepted amendment propagation needed full descendant-byte checks. Input verifier now requires the exact accepted Rust source SHA at every C3-C6 boundary and each complete expected document SHA, reconstructed from the accepted C3 document plus immutable old C3-to-descendant diffs. The expected C3 document itself must equal the accepted document SHA.
- Frozen CLI copy wording needed to match command ordering. The copy occurs after C7 build, Clippy and shared-feature compile checks and before runtime feature-test builds; the receipt ties the copied binary to the successful workspace build and source audits.

Read-only hash checks matched all 29 original/snapshot pairs, all 23 prepared-file hashes and lengths, and all declared prepared-copy/diff hashes. The author’s receipt records 21 successful JSON/AST/bash syntax checks; this reviewer did not rerun them. The separately prepared independent runtime reconciler was fully reviewed at SHA256 `5a7a9fe24bc6d06fbb3d4945bf599e08ade07026c53290e8e1510c407f8ecc61`.

The candidate and accepted amendment now exist and their supplied hashes match. Actual verification against Git and execution remain the responsibility of the prepared driver; this reviewer has not run it. The retained initial a474 runtime prerequisite has successful completion flags, but its totals do not certify amended source.

Limits:

- No prepared verifier, driver, collector, runtime reconciler, Cargo command, CLI test or jj command was executed by this reviewer; no tracked files changed.
- Four nextest workers and a 30 GB sampled RSS guard are retained. Worker count is not a process-thread cap; the sampled guard is not a hard operating-system memory limit. General test jobs have no new global timeout; physical calls retain their explicit timeout wrapping.
- Snapshot updates and retries remain disabled. Curated/scalar jobs explicitly record VALIDATION_ALLOW_WARNINGS=1; warning acceptance is an intentional exception, not a warning-free claim.
- The scalar matrix directly selects both namespaces with ignored slow tests enabled and no forced single-test setting. Manual PySecDec integrations remain outside the automatic suite.
- The exact certificate starts from the complete post-Taylor child source; it complements numerical GL00 routes and does not independently rerun Taylor construction or establish all physical sectors.
- Fresh boundary/runtime execution, actual source-input verification, final archive packaging, report rendering, PDF inspection and final bookmark/history closure remain separate tasks.

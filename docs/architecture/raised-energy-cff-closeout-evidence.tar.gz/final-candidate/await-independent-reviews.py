#!/usr/bin/env python3
"""Wait for finalized v2 evidence and run only accepted read-only reviewers."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import time

ROOT = Path('/tmp/raised-stack/closeout/gl00-certificate-v2')
REV = '9e260684581ab2893eff4032c5ca8ea1fc2c18cb'
TREE = '9cebc793fe813699b9d689f1ab245715902ac04e'
SCRIPTS = {
    'physical-inspect/review-completed-replay.py': '6ae9f97a44f6874dd52269baf7222bf0ee4d80267af1c414550f3c9584480a5e',
    'validation-prep/reconcile-final-runtime.py': '5a7a9fe24bc6d06fbb3d4945bf599e08ade07026c53290e8e1510c407f8ecc61',
}
OUTPUT = ROOT / 'independent-review-driver.json'
assert not OUTPUT.exists()
RECEIPT = {'status': 'WAITING_PHYSICAL', 'revision': REV, 'tree': TREE, 'started_utc': datetime.now(timezone.utc).isoformat(), 'script_pins': SCRIPTS, 'commands': [], 'scope': 'Waits for complete raw evidence and executes only accepted read-only independent reviewers. No Cargo, CLI replay, jj operation, wrapper access or tracked edit.'}


def observe(path):
    try:
        return json.loads(path.read_bytes())
    except (FileNotFoundError, json.JSONDecodeError):
        return None


def save():
    RECEIPT['updated_utc'] = datetime.now(timezone.utc).isoformat()
    OUTPUT.write_text(json.dumps(RECEIPT, indent=2) + '\n')


def pinned():
    for name, expected in SCRIPTS.items():
        assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == expected
    state = observe(ROOT / 'final-watcher.json')
    assert not state or state.get('status') != 'FAIL', 'Final validation watcher failed; inspect its preserved evidence'


def physical_ready():
    base = ROOT / 'physical-inspect/final-c7'
    manifest = observe(base / 'manifest.json')
    if not manifest or manifest.get('status') != 'passed':
        assert not manifest or manifest.get('status') != 'failed', 'Physical replay failed; raw evidence preserved'
        return False
    try:
        events = [json.loads(line) for line in (base / 'watchdog.jsonl').read_bytes().splitlines() if line]
        final_log = json.loads((base / 'driver.log').read_text().splitlines()[-1])
    except (FileNotFoundError, json.JSONDecodeError, IndexError):
        return False
    if not events or events[-1].get('event') != 'complete':
        return False
    assert events[-1]['returncode'] == 0 and final_log['status'] == 'passed'
    assert manifest['revision'] == REV and final_log['inspect_calls'] == 4
    return True


def run(name, result_name):
    pinned()
    command = ['/tmp/raised-stack/python', str(ROOT / name), '--revision', REV, '--tree', TREE]
    RECEIPT['commands'].append(command); save()
    subprocess.run(command, check=True)
    path = ROOT / result_name
    value = json.loads(path.read_bytes())
    assert value['status'] == 'PASS'
    RECEIPT[result_name] = {'path': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}


try:
    pinned()
    with OUTPUT.open('x') as stream:
        json.dump(RECEIPT, stream, indent=2); stream.write('\n')
    print('Waiting for finalized v2 physical replay evidence', flush=True)
    while not physical_ready():
        pinned(); time.sleep(3)
    RECEIPT['status'] = 'REVIEWING_PHYSICAL'; save()
    run('physical-inspect/review-completed-replay.py', 'independent-physical-replay-review.json')
    RECEIPT['status'] = 'WAITING_FINAL_RUNTIME'; save()
    print('Physical review passed; waiting for final runtime collector and completion', flush=True)
    while True:
        pinned()
        evidence = observe(ROOT / 'validation-prep/runtime-evidence-complete.json')
        completion = observe(ROOT / 'final-stack-driver-completion.json')
        if evidence and completion:
            assert evidence['declared_revision'] == completion['revision'] == REV
            assert evidence['declared_tree'] == completion['tree'] == TREE
            assert evidence['aggregate']['all_required_selections_complete']
            break
        time.sleep(3)
    RECEIPT['status'] = 'REVIEWING_FINAL_RUNTIME'; save()
    run('validation-prep/reconcile-final-runtime.py', 'final-runtime-independent-review.json')
    RECEIPT['status'] = 'PASS'; save()
    print('Both independent v2 reviews passed; root source freeze may release', flush=True)
except Exception as error:
    RECEIPT['status'] = 'FAIL'; RECEIPT['error'] = f'{type(error).__name__}: {error}'; save()
    raise

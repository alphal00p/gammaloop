#!/usr/bin/env python3
"""Render current validation Markdown from reviewed, fresh collector snapshots.

This script runs no subprocess, build, test, history operation, or collector.
Use --boundary with a collect-boundary-evidence.py snapshot and optionally
--runtime with collect-final-runtime-evidence.py output. Only the requested
Markdown output and an optional scratch rendering receipt are written.
"""
from pathlib import Path
import argparse
import hashlib
import json
import re

ROOT = Path('/common/dev/gammaloop/higher-power-energies-review')
BASE = Path('/tmp/raised-stack/closeout')
V2 = BASE / 'gl00-certificate-v2'
TARGET = ROOT / 'docs/architecture/raised-energy-cff-stack-review-validation.md'
ARCHIVE = 'raised-energy-cff-closeout-evidence.tar.gz'
ARCHIVE_RECEIPT = 'raised-energy-cff-closeout-evidence.json'
SECRET = re.compile(r'\b[0-9a-fA-F]{8}#[0-9a-fA-F]{8}#[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}\b')
NAMES = {
    1: 'Symbolic and tensor foundations', 2: 'Exact generalized CFF',
    3: 'Raised-energy CFF and local UV', 4: 'Command and evaluation workflows',
    5: 'Physical phases and model sewing', 6: 'D-dimensional integrated UV',
    7: 'Final stack and documentation',
}
RUNTIME_NAMES = ['curated', 'commit5-phases', 'signed-acceptances', 'commit6-vakint-uv',
                 'scalar-all', 'shared-default', 'shared-all', 'shared-no-default',
                 'ufo-model-parity', 'vertex-rules']
READS = {}


def read(path):
    path = path.resolve()
    assert path.is_relative_to(BASE), path
    data = path.read_bytes()
    assert path not in READS or READS[path] == data, ('Input changed', path)
    READS[path] = data
    return data


def fingerprint(path):
    data = read(path)
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def load(path):
    return json.loads(read(path))


def code(text):
    return '`' + str(text).replace('`', '') + '`'


def cell(text):
    return str(text).replace('|', '\\|').replace('\n', ' ')


def status(record):
    if record.get('status') != 'completed':
        return 'Pending'
    return 'Pass' if record.get('exit_code') == 0 else f'Failed (exit {record.get("exit_code")})'


def test_cells(record):
    tests = record.get('tests')
    if record.get('status') != 'completed' or tests is None:
        return ['Pending', 'Pending', 'Pending', 'Pending']
    return [f'{tests["passed"]}/{tests["selected"]}', str(tests['failed']),
            str(tests['skipped']), f'{tests["elapsed_seconds"]:.3f} s']


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--boundary', type=Path, required=True)
    parser.add_argument('--runtime', type=Path)
    parser.add_argument('--diagnostics', type=Path, default=BASE / 'validation-diagnostic-attempts.json')
    parser.add_argument('--candidate', type=Path, default=V2 / 'reconstructed-candidate.json')
    parser.add_argument('--amendment', type=Path, default=V2 / 'amendment.json')
    parser.add_argument('--verified-inputs', type=Path, default=V2 / 'validation-inputs.json')
    parser.add_argument('--runtime-candidate', type=Path, default=V2 / 'runtime-candidate.json')
    parser.add_argument('--output', type=Path, default=TARGET)
    parser.add_argument('--receipt', type=Path)
    args = parser.parse_args()
    output = args.output.resolve()
    assert output == TARGET or (output.is_relative_to(BASE) and output.suffix == '.md'), output
    if args.receipt:
        target = args.receipt.resolve()
        assert target.is_relative_to(V2) and target.suffix == '.json' and not target.exists(), 'Receipt must be a fresh v2 scratch path'
    boundaries_doc = load(args.boundary)
    assert boundaries_doc['schema_version'] == 1
    candidates = {row['number']: row for row in load(args.candidate)}
    assert set(candidates) == set(range(1, 8))
    amendment = load(args.amendment)
    verified = load(args.verified_inputs)
    assert verified['status'] == 'PASS'
    assert verified['candidate_sha256'] == fingerprint(args.candidate)['sha256']
    assert verified['amendment_sha256'] == fingerprint(args.amendment)['sha256']
    assert verified['first_six'] == [candidates[n] for n in range(1, 7)]
    assert amendment['status'] == 'accepted_for_reconstruction' and amendment['owning_commit'] == 3
    assert amendment['certificate_test'] == verified['certificate_test']
    assert boundaries_doc['collector']['sha256'] == fingerprint(V2 / 'validation-prep/collect-boundary-evidence.py')['sha256']
    boundaries = {row['boundary']: row for row in boundaries_doc['boundaries']}
    assert len(boundaries) == len(boundaries_doc['boundaries']) and set(boundaries) <= set(range(1, 8))
    for number, row in boundaries.items():
        assert row['reused_unchanged_revision_certificate'] == (number <= 2)
        if number < 7 and row.get('declared_revision'):
            assert row['declared_revision'] == candidates[number]['commit'], ('Wrong functional revision', number)
            if row.get('source_integrity', {}).get('tree'):
                assert row['source_integrity']['tree'] == candidates[number]['tree']
    diagnostics = load(args.diagnostics)
    assert diagnostics['schema_version'] == 1
    runtime_driver = V2 / 'validation-prep/final-runtime-job'
    selection_driver = V2 / 'validation-prep/remaining-validation'
    assert 'VALIDATION_ALLOW_WARNINGS=1' in read(runtime_driver).decode()
    assert '${VALIDATION_ALLOW_WARNINGS:-0}' in read(selection_driver).decode()
    runtime = load(args.runtime) if args.runtime else None
    runtime_pin = load(args.runtime_candidate) if runtime else None
    if runtime:
        assert runtime['schema_version'] == 1
        assert runtime['declared_revision'] == runtime_pin['revision']
        assert runtime['declared_tree'] == runtime_pin['tree']
        assert runtime['collector']['sha256'] == fingerprint(V2 / 'validation-prep/collect-final-runtime-evidence.py')['sha256']
        if any(job.get('counted_in_executed_union') for job in runtime['jobs']):
            assert boundaries.get(7, {}).get('declared_revision'), 'Completed runtime results require their matching C7 boundary pin'
        if boundaries.get(7, {}).get('declared_revision'):
            assert runtime['declared_revision'] == boundaries[7]['declared_revision']
        if boundaries.get(7, {}).get('source_integrity', {}).get('tree'):
            assert runtime['declared_tree'] == boundaries[7]['source_integrity']['tree']
    completed = [n for n in range(1, 8) if boundaries.get(n, {}).get('all_recorded_required_jobs_pass')]
    required_closed = len(completed) == 7
    runtime_complete = bool(runtime and runtime['aggregate']['all_required_selections_complete'])
    runtime_pass = bool(runtime and runtime['aggregate']['all_selected_tests_pass'])
    archive_ready = all((TARGET.parent / name).is_file() for name in [ARCHIVE, ARCHIVE_RECEIPT])
    archive_state = 'The archive and receipt are present; presence alone does not establish their integrity or final document closure.' if archive_ready else 'Those durable artifacts are being assembled.'
    lines = ['# Reviewed CFF stack: current validation', '']
    if required_closed and runtime_pass:
        lines += ['All seven boundaries and all required final runtime selections have complete passing collector receipts. C1/C2 reuse exact unchanged revision certificates; C3–C7 and final runtime are freshly executed after the accepted GL00/GL04 certificate amendment. Document rendering and final history closure are separate evidence, described below.', '']
    else:
        lines += ['**Validation is in progress.** Only completed receipts for the exact source are reported below: unchanged C1/C2 certificates are reused, while amended C3–C7 require fresh executions. Missing or running jobs are pending; earlier runtime totals and benchmark-source results do not certify this stack.', '']
    lines += [f'Boundary snapshot: {code(boundaries_doc["recorded_at_utc"])}. Completed passing boundaries: {", ".join(map(str, completed)) or "none"}.', '',
              'Boundary executions, repeated feature configurations and the final runtime selections remain separate counts. A skipped identity reported by nextest is outside that selected run; it is not a passing execution.', '',
              f'Raw commands, lists, logs, guard records and source audits belong in the [fresh closeout evidence archive]({ARCHIVE}) and its [JSON receipt]({ARCHIVE_RECEIPT}). {archive_state} Paths below are relative to the closeout capture directory and must be resolved through their manifest. No ignored target-directory log is used as a report link.', '',
              '## Execution identities', '', '| Boundary | Source revision | Tree | Status |', '| --- | --- | --- | --- |']
    for n in range(1, 8):
        b = boundaries.get(n, {})
        revision = b.get('declared_revision') or (candidates[n]['commit'] if n < 7 else 'vmrowquy; execution pin pending')
        tree = b.get('source_integrity', {}).get('tree') or (candidates[n]['tree'] if n < 7 else 'Pending')
        state = ('Passed — unchanged revision certificate reused' if b.get('reused_unchanged_revision_certificate') else 'Passed — fresh execution') if b.get('all_recorded_required_jobs_pass') else 'Pending'
        if b.get('status') == 'completed' and not b.get('all_recorded_required_jobs_pass'):
            state = 'Completed with nonzero job exit'
        lines.append(f'| {n} — {NAMES[n]} | {code(revision)} | {code(tree)} | {state} |')
    if runtime:
        lines += ['', f'Final runtime execution pin: {code(runtime["declared_revision"])}; tree {code(runtime["declared_tree"])}. Snapshot: {code(runtime["recorded_at_utc"])}.']
    lines += ['', 'Completed boundary receipts require pre/post tracked-source audits, matching revision/tree records, unchanged contents during source-mtime refresh, and final head equality. C1 refreshes all tracked regular-file mtimes because prior cache provenance is unknown; subsequent boundaries refresh changed blobs/modes against the preceding audited checkout. The first amended C3 checkout records its explicit pre-v2 source reference; it does not infer that reference from the retained runtime identifier. This guards against stale build reuse across checkouts. It does not infer identity from a requested revision alone.', '',
              '## Per-commit gates and feature checks', '',
              'Each completed boundary has formatting before locked workspace checking, a locked all-target `dev-optim` build, and Clippy. Guard time includes the complete command; it is distinct from nextest execution time. Peak memory is process-tree RSS in decimal GB.', '',
              '| Boundary | Step | Result | Guard time | Peak RSS | Limit | Command |', '| --- | --- | --- | --- | --- | --- | --- |']
    commands = []
    invocations = []
    for n in range(1, 8):
        b = boundaries.get(n, {})
        records = [('fmt', b.get('gates_and_targeted', {}).get('fmt', {})),
                   ('check', b.get('gates_and_targeted', {}).get('check', {})),
                   ('build', b.get('gates_and_targeted', {}).get('build', {})),
                   ('clippy', b.get('gates_and_targeted', {}).get('clippy', {}))]
        records += [(name, record) for name, record in b.get('feature_checks', {}).items()]
        for name, record in records:
            guard = record.get('watchdog', {})
            metrics = [f'{guard["elapsed_seconds"]:.3f} s', f'{guard["peak_process_tree_rss_bytes"]/1e9:.3f} GB', f'{guard["limit_bytes"]/1e9:g} GB'] if guard else ['Pending']*3
            anchor = f'command-c{n}-{name}'
            link = f'[recorded](#{anchor})' if record.get('command_file_text') else 'Pending'
            lines.append('| ' + ' | '.join(map(cell, [str(n), name, status(record), *metrics, link])) + ' |')
            if record.get('command_file_text'):
                commands.append((anchor, f'C{n} {name}', record))
                invocations.append(record)
    lines += ['', 'Shared CFF is absent at C1. From C2 onward, all-feature and no-default-feature all-target checks are required. The Python API check belongs to C4 and the Vakint community-module check to C6; their absence from an uncollected boundary remains pending.', '',
              '## Per-commit behavioral selections', '', '| Boundary | Selection | Passed/executed | Nonpass | Skipped | Test time | List/run match | Command |', '| --- | --- | --- | --- | --- | --- | --- | --- |']
    for n in range(1, 8):
        b = boundaries.get(n, {})
        matrix = b.get('shared_or_additional_matrix', {})
        if not matrix:
            lines.append(f'| {n} | Required owning selections | Pending | Pending | Pending | Pending | Pending | Pending |')
        for name, pair in matrix.items():
            record = pair['run']; anchor = f'command-c{n}-{name}-run'
            match = 'Verified' if pair.get('list_run_identity_match') else 'Pending'
            link = f'[recorded](#{anchor})' if record.get('command_file_text') else 'Pending'
            lines.append('| ' + ' | '.join(map(cell, [str(n), name, *test_cells(record), match, link])) + ' |')
            for phase in ['list', 'run']:
                rec = pair[phase]
                if rec.get('command_file_text'):
                    commands.append((f'command-c{n}-{name}-{phase}', f'C{n} {name} {phase}', rec))
                    invocations.append(rec)
    lines += ['', 'The accepted C3 amendment extends the existing exact source certificate to two fixtures, GL00 and GL04. It compares the complete signed numerator and powered-denominator assignment in a common loop chart, beginning from the complete post-Taylor child source. The retained coupling, physical owner multiplicities and distinct raw vacuum/expansion masses are part of that contract. One test identity exercises the two fixtures; fixture count is not a second test execution. The C3 owning selection and final curated selection must contain '+code(verified['certificate_test'])+'. Numerical GL00 routes remain complementary end-to-end coverage.', '', 'The collector reconciles every executed binary/test identity against its recorded nextest JSON selection. Repeated final-status lines are deduplicated only when identity, outcome, duration and progress index agree. Separate boundaries and feature runs are not added as unique test coverage.', '',
              '## Final runtime selections', '', '| Selection | Passed/executed | Nonpass | Skipped | Test time | Status | Command |', '| --- | --- | --- | --- | --- | --- | --- |']
    jobs = {job['selection']: job for job in runtime['jobs']} if runtime else {}
    for name in RUNTIME_NAMES:
        job = jobs.get(name, {}); record = job.get('listing_and_execution', {}).get('run', {})
        anchor = f'command-final-{name}-run'
        link = f'[recorded](#{anchor})' if record.get('command_file_text') else 'Pending'
        job_status = job.get('status', 'incomplete')
        counted_record = record if job.get('counted_in_executed_union') else {}
        lines.append('| ' + ' | '.join(map(cell, [name, *test_cells(counted_record), job_status, link])) + ' |')
        for phase, rec in job.get('listing_and_execution', {}).items():
            if rec.get('command_file_text'):
                commands.append((f'command-final-{name}-{phase}', f'Final {name} {phase}', rec)); invocations.append(rec)
    if runtime:
        a=runtime['aggregate']
        lines += ['', f'{"Complete" if runtime_complete else "Partial"} final-runtime aggregation: **{a["actual_executions"]} executions across {a["distinct_identities"]} distinct binary/test identities**. Status counts: {code(json.dumps(a["execution_status_counts"], sort_keys=True))}. Identities with any nonpass: {a["identities_with_any_nonpass"]}. Distinct execution configurations: {len(a["configurations"])}.', '',
                  'Missing or incomplete required selections: '+(', '.join(code(n) for n in a['missing_or_incomplete_jobs']) or 'none')+'.']
        if a['failed_identities']:
            lines += ['', 'Recorded nonpassing identities:']+[f'- {code(r["binary_id"])} / {code(r["test_name"])}.' for r in a['failed_identities']]
        scalar=jobs.get('scalar-all',{}).get('scalar_namespace_counts')
        if scalar: lines += ['', f'The complete scalar selection executes {scalar["standard"]} standard and {scalar["slow"]} slow cases ({scalar["total"]} total). Its recorded command selects the two scalar namespaces directly in release mode, with ignored tests enabled and four workers; it does not use the wrapper\'s forced single-worker setting.']
    else:
        lines += ['', '**Final runtime aggregate pending.** No final execution total, distinct-identity total, scalar-case count or pass claim is inferred from the boundary runs.']
    lines += ['', '## Execution controls and warnings', '',
              'Completed test contexts record four nextest workers, zero retries, disabled snapshot updates (`INSTA_UPDATE=no`) and a 30 GB process-tree RSS limit. The boundary driver uses four Cargo build jobs. Exact argv, guards and per-job context hashes remain in the evidence. Tests use `--no-fail-fast`; this reports remaining selected outcomes without retrying a failure. Optional feature changes and the release scalar selection use their own recorded Cargo configurations.', '',
              'Passing Clippy or Cargo exits do not mean warning-free compilation. The recorded runtime driver explicitly exports `VALIDATION_ALLOW_WARNINGS=1`: the curated and scalar selections therefore omit their optional `-Dwarnings` injection. This is an explicit warning-policy exception. The recorded workspace Clippy command also has no `-D warnings` argument. Compiler and dependency warnings remain visible in the raw logs. The following unique warning lines are taken only from hash-matching completed invocation logs:', '']
    warnings = set()
    for invocation in invocations:
        for source in invocation.get('source_files', []):
            path=Path(source['path'])
            if not path.name.endswith('.log'): continue
            data=read(path)
            assert hashlib.sha256(data).hexdigest()==source['sha256'] and len(data)==source['bytes'], path
            for line in re.sub(r'\x1b\[[0-9;]*m','',data.decode()).splitlines():
                if line.lstrip().startswith('warning:'):
                    warnings.add(line.strip())
    lines += [f'- {code(warning)}' for warning in sorted(warnings)] if warnings else ['No warning lines were found in the completed invocation logs included in this snapshot. This makes no claim about pending jobs.']
    attempts=boundaries_doc.get('interrupted_attempts',[])+boundaries_doc.get('failed_build_attempts',[])
    lines += ['', '## Interrupted or failed prerequisite attempts', '']
    if attempts:
        for attempt in attempts:
            lines.append(f'- Boundary {attempt["boundary"]}: {code(attempt["status"])} at {code(attempt["declared_revision"])}. Excluded from current boundary pass totals. '+attempt.get('cause_inference','No cause inferred.'))
    else:
        lines.append('No prerequisite attempts are included in this collector snapshot. This is an evidence-scope statement, not a claim that none occurred. Include the collector\'s interruption/failed-build options when those receipts exist.')
    driver_diagnostic = V2 / 'diagnostics/initial-functional-driver/diagnostic-and-fix.json'
    if driver_diagnostic.exists():
        diagnostic = load(driver_diagnostic)
        lines += ['', 'A separate pre-gate driver startup attempt is retained in '+code(str(driver_diagnostic.relative_to(BASE)))+'. It concerns the prefix-workspace start precondition and is excluded from production test outcomes. Its raw log and disposition remain in the archive.']
    lines += ['', '## Separate drafting diagnostics and approval', '', diagnostics['scope'], '']
    for attempt in diagnostics['attempts']:
        lines += [f'**{attempt["id"]}.** '+attempt['description']+' '+attempt['disposition'], '']
        if attempt['id'] == 'json-serde-deserialize-bound':
            lines += [f'Initial check: exit {attempt["initial"]["exit_code"]}; corrected check: exit {attempt["corrected_check"]["exit_code"]}. The initial failure occurred before runtime testing.', '', '```sh', ' '.join(attempt['initial']['command']), '```', '']
        if attempt['id'] == 'new-opaque-scalar-test-expectations':
            initial=attempt['initial']
            lines += [f'The draft run executed {initial["tests_selected"]} tests: {initial["passed"]} passed and {initial["failed"]} failed. The approval receipt records the answer “{attempt["approval"]["answer"]}”. These were incorrect expectations in two new draft tests; they were not production regressions or failures of the reconstructed stack.', '']
        lines += ['Captured diagnostic sources: '+', '.join(code(f['path']) for f in attempt['source_files'])+'. Their hashes are pinned in '+code('validation-diagnostic-attempts.json')+'; the final archive manifest maps each captured path to its actual member without reusing obsolete namespace labels.', '']
    lines += ['', '## Scope and limits', '',
              '- Manual physical PySecDec integrations remain excluded; passing Rust adapters does not certify those integrations.',
              '- Ordinary selections exclude legacy failing-class tests and `aa_aa::important::aa_aa_local_inspect_backend_consistency`. The exact reviewed vertex-rule case is an explicit separate selection.',
              '- Three scalar triangle, double-triangle and TBT reference points remain outside automatic coverage; their decimal targets lack an independently recorded derivation.',
              '- Optional installed-Python subprocess tests are not certified by these runtime selectors. Model parity and the Python API compile check have distinct scopes.',
              '- Sampled numerator grouping and Monte Carlo acceptances are bounded numerical evidence. Local electroweak/Ward checks do not establish complete electroweak LU acceptance; complex-mass cutting rules and arbitrary non-Hermitian interactions remain unsupported.',
              '- General serialized-graph validation and a changed singular-surface contract for the diagnostic f64 evaluator are outside this review.',
              '- This generated page certifies only completed records in its collector inputs. Final PDF compilation/visual inspection, source-to-bookmark closure and final artifact integrity belong to separate external final-closure receipts referencing the archive and final report hashes; those receipts are not embedded in the tracked archive.', '',
              '## Recorded command appendix', '',
              'These are the exact command-file contents captured for completed invocations; they are not proposed commands or reconstructed argv. Source file paths identify entries in the fresh closeout capture, whose archive manifest retains their hashes.', '']
    for anchor, title, record in commands:
        raw_paths=[str(Path(s['path']).relative_to(BASE)) for s in record.get('source_files',[]) if s['path'].endswith('.command')]
        lines += [f'<a id="{anchor}"></a>', '<details>', f'<summary>{title}</summary>', '',
                  'Raw command record: '+', '.join(code(p) for p in raw_paths)+'.', '',
                  '```sh', record['command_file_text'].rstrip('\n'), '```', '', '</details>', '']
    lines += ['## Collector inputs and durable evidence', '',
              f'The [fresh archive]({ARCHIVE}) and [receipt]({ARCHIVE_RECEIPT}) are the durable evidence targets. The receipt records payload paths and hashes. C1/C2 use the retained certificates only because their full revision and tree are unchanged. Initial a474 C3–C7 and runtime evidence remains preserved separately and does not certify the amended source.', '',
              '| Input | SHA256 |', '| --- | --- |']
    inputs=[args.boundary,args.candidate,args.amendment,args.verified_inputs,args.diagnostics,runtime_driver,selection_driver]+([args.runtime,args.runtime_candidate] if args.runtime else [])
    if driver_diagnostic.exists(): inputs.append(driver_diagnostic)
    for path in inputs:
        f=fingerprint(path)
        lines.append(f'| {code(Path(f["path"]).relative_to(BASE))} | {code(f["sha256"])} |')
    lines += ['', 'Regenerate this page with the bundled `refresh-validation-report.py` using a current boundary snapshot and, when available, the final runtime snapshot. Collection and rendering execute no tests.', '']
    text='\n'.join(lines)
    assert not SECRET.search(text), 'Credential-shaped content excluded'
    assert '../../target/' not in text
    for path,data in READS.items(): assert path.read_bytes()==data, ('Input changed during rendering',path)
    output.parent.mkdir(parents=True,exist_ok=True); output.write_text(text)
    receipt={'output':str(output),'bytes':len(text.encode()),'sha256':hashlib.sha256(text.encode()).hexdigest(),
             'completed_passing_boundaries':completed,'all_boundaries_pass':required_closed,
             'final_runtime_selections_complete':runtime_complete,'final_runtime_all_pass':runtime_pass,
             'collector_inputs':[fingerprint(p) for p in inputs],
             'renderer':fingerprint(Path(__file__)), 'executed_builds_or_tests':0,
             'input_policy':'Explicit v2 collector snapshots; C1/C2 exact unchanged revision certificates reused; C3-C7 and final runtime require fresh evidence. No earlier runtime totals or missing jobs inferred.'}
    if args.receipt:
        with target.open('x') as stream:
            stream.write(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(receipt,indent=2))


if __name__=='__main__':
    main()

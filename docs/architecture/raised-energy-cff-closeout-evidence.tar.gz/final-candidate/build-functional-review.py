#!/usr/bin/env python3
"""Record exact v1 review reuse, the accepted GL00 delta and inherited edits.

Read-only Git object queries and patch replay in new scratch folders only.
No Cargo, repository edits, jj commands, refs or license-wrapper reads.
"""
import copy
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess

ROOT = Path('/tmp/raised-stack/closeout/gl00-certificate-v2')
PRIOR = ROOT.parent
REPO = Path('/common/dev/gammaloop/higher-power-energies-review')
SOURCE = 'crates/gammalooprs/src/graph/three_d_source.rs'
DOCUMENT = 'docs/architecture/exact-powered-denominator-cff-lifting.md'
INPUTS_SHA = 'b9740c1a68baaeef17cfe860b927ea7766d65cfa93bf9044adab6dd79c5a76a1'
AMENDMENT_SHA = '1609514078a49453593d452dc381b6eac0a2c50a0400c24020f48dcbd3a7c897'
READS = {}
COMMANDS = []
ENV = {**os.environ, 'GIT_OPTIONAL_LOCKS': '0'}


def read(path):
    path = path.resolve()
    assert path.is_relative_to(PRIOR)
    data = path.read_bytes()
    assert path not in READS or READS[path] == data
    READS[path] = data
    return data


def git(*args):
    argv = ['git', '-C', str(REPO), *args]
    data = subprocess.check_output(argv, env=ENV)
    COMMANDS.append({'argv': argv, 'stdout_sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)})
    return data


def inventory(revision):
    entries = {}
    for line in git('ls-tree', '-rz', '--full-tree', revision).split(b'\0'):
        if line:
            meta, path = line.split(b'\t', 1)
            mode, kind, blob = meta.decode().split()
            entries[os.fsdecode(path)] = {'mode': mode, 'type': kind, 'blob': blob}
    return entries


def main():
    output = ROOT / 'reconstructed-functional-review.json'
    markdown = ROOT / 'reconstructed-functional-review.md'
    work = ROOT / 'functional-review-data'
    assert not output.exists() and not markdown.exists() and not work.exists()
    work.mkdir()
    raw_inputs = read(ROOT / 'validation-inputs.json')
    raw_amendment = read(ROOT / 'amendment.json')
    assert hashlib.sha256(raw_inputs).hexdigest() == INPUTS_SHA
    assert hashlib.sha256(raw_amendment).hexdigest() == AMENDMENT_SHA
    inputs, amendment = json.loads(raw_inputs), json.loads(raw_amendment)
    assert inputs['status'] == 'PASS' and inputs['amendment_sha256'] == AMENDMENT_SHA
    assert amendment['status'] == 'accepted_for_reconstruction'
    candidate = json.loads(read(ROOT / 'reconstructed-candidate.json'))[:6]
    assert candidate == inputs['first_six']
    prior_bytes = read(PRIOR / 'reconstructed-functional-review.json')
    prior = json.loads(prior_bytes)
    adaptation = json.loads(read(ROOT / 'report-prep/adaptation-plan.json'))
    prior_pin = next(row['sha256'] for row in adaptation['inputs'] if row['path'] == str(PRIOR / 'reconstructed-functional-review.json'))
    assert hashlib.sha256(prior_bytes).hexdigest() == prior_pin
    assert candidate[:2] == prior['new_six'][:2]
    for key in ['formatted_patch', 'oracle_review', 'formatting_receipt', 'architecture_review', 'proposal_freeze', 'doc_propagation']:
        assert hashlib.sha256(read(Path(amendment[key]['path']))).hexdigest() == amendment[key]['sha256']
    assert json.loads(read(Path(amendment['oracle_review']['path'])))['findings'] == []
    assert json.loads(read(Path(amendment['architecture_review']['path'])))['findings'] == []
    propagation = json.loads(read(Path(amendment['doc_propagation']['path'])))
    expected_docs = {row['boundary']: row['expected_sha256'] for row in propagation['records']}
    result = copy.deepcopy(prior)
    base = prior['base']
    trees = {base: inventory(base)}
    for row in prior['new_six'] + candidate:
        if row['commit'] not in trees:
            trees[row['commit']] = inventory(row['commit'])
    replays, changes = [], []
    for number, (old, new, prior_commit) in enumerate(zip(prior['new_six'], candidate, prior['commits']), 1):
        meta = git('show', '-s', '--format=%H%x00%T%x00%P%x00%an%x00%ae%x00%cn%x00%ce', new['commit']).decode().strip().split('\0')
        parent = base if number == 1 else candidate[number - 2]['commit']
        assert meta[:3] == [new['commit'], new['tree'], parent]
        assert meta[3:] == ['Lucien Huber', 'im@lcnbr.ch'] * 2
        assert new['parents'] == [parent]
        old_parent = old['parents'][0]
        before, after = trees[parent], trees[new['commit']]
        old_before, old_after = trees[old_parent], trees[old['commit']]
        changed = {p for p in before.keys() | after.keys() if before.get(p) != after.get(p)}
        old_changed = {p for p in old_before.keys() | old_after.keys() if old_before.get(p) != old_after.get(p)}
        assert changed == old_changed == {r['path'] for r in prior_commit['paths'] if r['new_owner_changed']}
        actual_diff = {os.fsdecode(p) for p in git('diff-tree', '--no-commit-id', '--no-renames', '--name-only', '-r', '-z', parent, new['commit']).split(b'\0') if p}
        assert actual_diff == changed
        amendment_paths = {p for p in old_after.keys() | after.keys() if old_after.get(p) != after.get(p)}
        assert amendment_paths == (set() if number < 3 else {SOURCE, DOCUMENT})
        if number >= 3:
            source = git('show', new['commit'] + ':' + SOURCE)
            old_source = git('show', old['commit'] + ':' + SOURCE)
            marker = b'\n#[cfg(test)]\nmod tests {'
            assert source.count(marker) == old_source.count(marker) == 1
            assert source.split(marker)[0] == old_source.split(marker)[0]
            assert hashlib.sha256(source).hexdigest() == amendment['accepted_c3_file_sha256'][SOURCE]
            assert hashlib.sha256(git('show', new['commit'] + ':' + DOCUMENT)).hexdigest() == expected_docs[number]
        commit = result['commits'][number - 1]
        commit.update(commit=new['commit'], tree=new['tree'], parent=parent, prior_v1_commit=old['commit'], prior_v1_parent=old_parent)
        for row in commit['paths']:
            path = row['path']
            old_row = next(r for r in prior_commit['paths'] if r['path'] == path)
            assert old_row['new_parent'] == old_before.get(path) and old_row['new_commit'] == old_after.get(path)
            row['prior_v1_transition'] = {'parent': old_parent, 'commit': old['commit'], 'before': old_row['new_parent'], 'after': old_row['new_commit'], 'coverage': old_row['coverage'], 'receipt_sha256': prior_pin}
            row['new_parent'], row['new_commit'] = before.get(path), after.get(path)
            if after.get(path) and after[path]['type'] == 'blob':
                data = git('cat-file', 'blob', after[path]['blob'])
                row['new_file_content'] = {'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}
            exact = (old_row['new_parent'], old_row['new_commit']) == (row['new_parent'], row['new_commit'])
            if exact:
                row['v2_review_method'] = 'exact_v1_before_after_transition_reuse'
            elif number == 3 and path in {SOURCE, DOCUMENT}:
                row['coverage'] = 'prior_review_plus_fresh_owned_hunk_review'
                row['v2_review_method'] = 'accepted_GL00_fresh_C3_hunk_review'
                row['review'] = ('Retain the prior full owning review and add the independently reviewed complete GL00/GL04 child-source fixture delta. Signed Taylor numerator, physical owners, denominator product, separate mass fields and factorization are certified without a new helper or production edit.' if path == SOURCE else 'Retain the prior architecture review and add the author-independently reviewed complete GL00 post-Taylor child certificate, with explicit child-sector scope and separate raw mass fields/final identification.')
                row['fresh_review_findings'] = []
                row['accepted_amendment'] = {'path': str(ROOT / 'amendment.json'), 'sha256': AMENDMENT_SHA}
                row['independent_review'] = amendment['oracle_review' if path == SOURCE else 'architecture_review']
                changes.append({'number': number, 'path': path, 'before': old_row['new_commit'], 'after': row['new_commit'], 'new_sha256': row['new_file_content']['sha256']})
            else:
                assert number in [4, 5] and path == DOCUMENT
                folder = work / f'C{number}-architecture-replay'
                target = folder / path
                target.parent.mkdir(parents=True)
                target.write_bytes(git('show', parent + ':' + path))
                patch = git('diff', '--no-ext-diff', '--no-renames', '--binary', old_parent, old['commit'], '--', path)
                patch_file = folder / 'original-owning.patch'
                patch_file.write_bytes(patch)
                argv = ['patch', '--fuzz=0', '--batch', '--forward', '-p1']
                applied = subprocess.run(argv, cwd=folder, input=patch, capture_output=True)
                (folder / 'apply.log').write_bytes(applied.stdout + applied.stderr)
                assert applied.returncode == 0 and target.read_bytes() == git('show', new['commit'] + ':' + path)
                proof = {'number': number, 'path': path, 'argv': argv, 'cwd': str(folder), 'exit_code': applied.returncode, 'patch_sha256': hashlib.sha256(patch).hexdigest(), 'output_sha256': hashlib.sha256(target.read_bytes()).hexdigest(), 'exact_full_file_equality': True}
                replays.append(proof)
                row['coverage'] = 'prior_v1_transition_reapplied_exact'
                row['v2_review_method'] = 'exact_v1_owning_patch_replay_on_amended_parent'
                row['review'] = 'The original v1 owning architecture patch, applied with zero fuzz to the amended parent, reproduces the complete v2 file byte-for-byte. This reuses the prior semantic review; it is not a fresh reread of unchanged content.'
                row['v2_patch_reapplication_proof'] = proof
        commit['coverage_counts'] = dict(Counter(r['coverage'] for r in commit['paths'] if r['new_owner_changed']))
        commit['v2_review_method_counts'] = dict(Counter(r['v2_review_method'] for r in commit['paths'] if r['new_owner_changed']))
    assert {(r['number'], r['path']) for r in changes} == {(3, SOURCE), (3, DOCUMENT)}
    assert {r['number'] for r in replays} == {4, 5}
    rows = [r for c in result['commits'] for r in c['paths'] if r['new_owner_changed']]
    categories = Counter(r['coverage'] for r in rows)
    methods = Counter(r['v2_review_method'] for r in rows)
    result.update(new_six=candidate, prior_v1_six=prior['new_six'], reviewer='/root/compact_public_tests', recorded_at_utc=datetime.now(timezone.utc).isoformat(),
        status='functional_source_review_complete; runtime_validation_and_final_C7_review_separate',
        scope='Every actual v2 C1-C6 owning path is accounted for. Preserve v1 review lineage by exact transitions or exact owning-patch replay; independently reviewed GL00 source/document hunks belong to C3. Runtime and final C7 review remain separate.',
        prior_v1_review={'path': str(PRIOR / 'reconstructed-functional-review.json'), 'sha256': prior_pin},
        v2_amendment={'path': str(ROOT / 'amendment.json'), 'sha256': AMENDMENT_SHA},
        v2_validation_inputs={'path': str(ROOT / 'validation-inputs.json'), 'sha256': INPUTS_SHA},
        v2_fresh_owning_hunks=changes, v2_inherited_owning_patch_replays=replays,
        findings=[], commands=COMMANDS,
        first_six_stability={'candidate_first_six_json_sha256': hashlib.sha256(json.dumps(candidate, sort_keys=True, separators=(',', ':')).encode()).hexdigest(), 'all_parents_match': True, 'all_author_and_committer_identities_match': True, 'C1_C2_exactly_unchanged': True},
        execution_scope={'cargo_builds': 0, 'tests_executed': 0, 'backend_runs': 0, 'repository_or_jj_mutations': 0, 'scratch_only_patch_applications': len(replays), 'license_wrapper_reads': 0})
    result['counts'].update(new_commit_path_records=len(rows), new_distinct_paths=len({r['path'] for r in rows}), all_new_functional_records_classified=len(rows),
        exact_transition_reuse=categories['exact_transition_reuse'], original_patch_reapplication_exact=categories['original_patch_reapplication_exact'],
        fresh_owned_hunk_review_records=categories['prior_review_plus_fresh_owned_hunk_review'], prior_v1_transition_reapplied_exact=categories['prior_v1_transition_reapplied_exact'],
        fresh_unique_paths=len({r['path'] for r in rows if r['coverage'] == 'prior_review_plus_fresh_owned_hunk_review'}),
        coverage_categories=dict(categories), v2_review_methods=dict(methods))
    result['rust_and_kiss_review'] += ' The v2 two-case certificate extends existing test machinery and preserves distinct raw mass fields. No new helper, API or dependency is introduced.'
    result['test_contract_review'] += ' GL00 adds an independent signed T0+T1 child numerator and complete owner/mass/domain denominator proof, with factorization-preserving exact comparison; GL04 retains full T0+T1+T2 coverage.'
    result['input_fingerprints'] = [{'path': str(p), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()} for p, data in READS.items()]
    result['script_sha256'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    for path, data in READS.items():
        assert path.read_bytes() == data
    with output.open('x') as stream:
        json.dump(result, stream, indent=2); stream.write('\n')
    lines = ['# V2 reconstructed functional review', '', 'All owning diff paths are accounted for. Exact prior review reuse and fresh GL00 hunk review remain distinct; runtime and final C7 approval are separate.', '', '| Commit | Revision | Paths | Exact v1 transitions | V1 patch replay | Fresh GL00 hunks |', '|---|---|---:|---:|---:|---:|']
    for c in result['commits']:
        m = c['v2_review_method_counts']
        lines.append(f"| {c['number']} | `{c['commit']}` | {c['new_changed_path_count']} | {m.get('exact_v1_before_after_transition_reuse', 0)} | {m.get('exact_v1_owning_patch_replay_on_amended_parent', 0)} | {m.get('accepted_GL00_fresh_C3_hunk_review', 0)} |")
    lines += ['', f"The six commits contain {len(rows)} owning commit/path records across {len({r['path'] for r in rows})} paths. {methods['exact_v1_before_after_transition_reuse']} exact v1 transitions retain their existing semantic review. Two architecture owning patches replay exactly on the amended parent, and the two C3 source/document hunks have independent review.", '',
        'GL00 now checks the complete signed post-Taylor child numerator, physical owner roles, denominator multiplicities, masses and UV domain. The fixture retains both mass fields before the documented final identification. GL04 remains covered by the same fixture loop. The certificate does not independently exercise the Taylor-producing stage or every physical forest.', '',
        'The JSON retains all prior source mappings and review evidence, enumerates every actual before/after mode/type/blob, and records exact scratch patch replay. No Cargo, backend or repository/history mutation occurred. C1/C2 are unchanged; fresh affected-boundary and final runtime evidence belongs to separate receipts.', '']
    with markdown.open('x') as stream:
        stream.write('\n'.join(lines))
    print(json.dumps({'output': str(output), 'counts': result['counts'], 'findings': []}))


if __name__ == '__main__':
    main()

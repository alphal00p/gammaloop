from pathlib import Path
from datetime import datetime, timezone
import argparse, hashlib, json, tarfile

base = Path('/tmp/raised-stack/closeout/gl00-certificate-v2')
folder = Path('/common/dev/gammaloop/higher-power-energies-review/docs/architecture')
parser = argparse.ArgumentParser()
parser.add_argument('--inventory', type=Path, required=True)
parser.add_argument('--ledger', type=Path, required=True)
parser.add_argument('--receipt', type=Path, required=True)
args = parser.parse_args()
assert not args.receipt.exists() and args.receipt.resolve().is_relative_to(base)
inventory = json.loads(inventory_bytes := args.inventory.read_bytes())
ledger = json.loads(ledger_bytes := args.ledger.read_bytes())
review_path = base / 'reconstructed-functional-review.json'
review = json.loads(review_bytes := review_path.read_bytes())
archive_path = folder / 'raised-energy-cff-closeout-evidence.json'
archive = json.loads(archive_bytes := archive_path.read_bytes())
assert archive['archive'] == 'raised-energy-cff-closeout-evidence.tar.gz'
validation_path = base / 'validation-inputs.json'
validation_bytes = validation_path.read_bytes()
assert hashlib.sha256(validation_bytes).hexdigest() == 'b9740c1a68baaeef17cfe860b927ea7766d65cfa93bf9044adab6dd79c5a76a1'
verified = json.loads(validation_bytes)
assert verified['status'] == 'PASS' and review['new_six'] == verified['first_six']
assert review['v2_amendment']['sha256'] == verified['amendment_sha256']
assert ledger['amendment']['amendment_sha256'] == verified['amendment_sha256']
assert ledger['amendment']['candidate_sha256'] == verified['candidate_sha256']
assert ledger['boundary_revisions'][:6] == [c['commit'] for c in verified['first_six']]
assert inventory['v2_validation_inputs_sha256'] == hashlib.sha256(validation_bytes).hexdigest()
assert archive['runtime_revision'] == ledger['runtime_revision'] and archive['runtime_tree'] == ledger['runtime_tree']
assert archive['runtime_aggregate'] == ledger['runtime_aggregate']
assert archive['physical_replay'] == ledger['physical_replay']
with (folder / archive['archive']).open('rb') as source:
    assert hashlib.file_digest(source, 'sha256').hexdigest() == archive['archive_sha256']
with tarfile.open(folder / archive['archive'], 'r:gz') as package:
    assert json.load(package.extractfile('LEDGER.json')) == ledger
    archived_review = package.extractfile('final-candidate/reconstructed-functional-review.json').read()
assert hashlib.sha256(archived_review).hexdigest() == inventory['review_receipt']['sha256']
assert archived_review == review_bytes
assert inventory['complete_inventory'] and inventory['first_six_exact_review_coverage_match']
assert ledger['all_boundaries_pass'] and ledger['runtime_aggregate']['all_required_selections_complete'] and ledger['runtime_aggregate']['all_selected_tests_pass']
assert ledger['physical_replay']['status'] == 'passed' and ledger['physical_replay']['state_unchanged'] and ledger['physical_replay']['binary_unchanged']
assert inventory['c7']['change'] == 'vmrowquyxoorvtnrtzqnoszyontoryro'
assert [c['commit'] for c in inventory['commits'][:6]] == ledger['boundary_revisions'][:6]
assert len(ledger['boundary_revisions']) == 7 and ledger['boundary_revisions'][-1] == ledger['runtime_revision']
now = datetime.now(timezone.utc).isoformat()
inputs = []
for source, contents in [(args.inventory, inventory_bytes), (args.ledger, ledger_bytes), (review_path, review_bytes), (archive_path, archive_bytes), (validation_path, validation_bytes)]:
    assert source.read_bytes() == contents, 'Input changed during evidence validation'
    inputs.append({'path': str(source), 'sha256': hashlib.sha256(contents).hexdigest()})
outputs = []
prepared = []
for name in ['coverage', 'validation', 'provenance']:
    path = folder / f'raised-energy-cff-stack-{name}.json'
    original_bytes = path.read_bytes()
    data = json.loads(original_bytes)
    protected = {key: data[key] for key in data if key in {'original_commits', 'original_source_pins', 'original_source_count', 'original_source_kind_counts', 'source_inputs'} or (key.startswith('recorded_') and key != 'recorded_field_scope')}

    data['status'] = {'state': 'frozen_validation_complete', 'assembled_at_utc': now,
        'final_document_closure': {'location': 'external', 'required': True, 'not_certified_by_this_artifact': True},
        'scope': 'Unchanged C1/C2 revision certificates, fresh amended C3-C7 boundary and runtime validation, preserved source history, and complete changed-path accounting. Final report content/render review and final head identity require a separate external closure receipt; recorded snapshots retain their own execution scope.'}
    data['recorded_field_scope'] = {key: 'Preserved pinned snapshot evidence; current reconstructed validation and source accounting belong to closeout.' for key in ['input_snapshot', 'evidence_file', 'linked_evidence', 'completed_selection_evidence', 'external_execution_artifacts', 'authorized_test_comparison_revision', 'authorized_remaining_test_revision', 'recorded_coverage_snapshot', 'recorded_ledger', 'recorded_snapshot_status', 'recorded_functional_history', 'recorded_documentation_commit_identity', 'applied_metadata_evidence', 'original_source_and_protected_bookmark_preservation', 'checkpoint_and_amendment_evidence'] if key in data}
    closeout = data['closeout']
    closeout.update(functional_revisions=review['new_six'],
        amendment=ledger['amendment'], boundary_reuse=ledger['boundary_reuse'],
        retained_initial_runtime=ledger['retained_initial_runtime'],
        functional_review_v2_methods=review['counts']['v2_review_methods'],
        validation_status='complete', evidence_file=archive_path.name,
        runtime_revision=ledger['runtime_revision'], runtime_tree=ledger['runtime_tree'],
        runtime_aggregate=ledger['runtime_aggregate'], runtime_selections=ledger['runtime_selections'],
        all_seven_boundaries_pass=True, physical_replay=ledger['physical_replay'],
        coverage_counts=inventory['counts'], coverage_snapshot_revision=inventory['revision'],
        coverage_snapshot_tree=inventory['tree'], first_six_exact_review_coverage_match=True,
        functional_review_counts=review['counts'], evidence_input_fingerprints=inputs,
        final_document_identity_policy='Final C7 hashes, report/PDF hashes, reviewed bookmark/ref checks and final source-to-runtime equivalence are recorded externally, avoiding recursive self-hashes.')
    closeout.pop('evidence_location', None)
    if name == 'coverage':
        data['snapshot_scope'] = 'recorded_coverage_snapshot and its linked_evidence retain their pinned source and review scope. Current first-six review and complete seven-diff path accounting are summarized in closeout; final C7 contents require certification in a separate external closure receipt.'
        closeout['commit_path_counts'] = [{'number': c['number'], 'change': c.get('change'), 'commit': c['commit'], 'changed_paths': c['changed_path_count']} for c in inventory['commits']]
        closeout['c7_paths'] = [p['path'] for p in inventory['c7']['paths']]
    elif name == 'provenance':
        data['observed_functional_history'] = [
            {'number': c['number'], 'change_id': review['new_six'][c['number'] - 1]['change'],
             'commit': c['commit'], 'parent': c['parent'], 'tree': c['tree'], 'title': c['title'],
             'observed_author': c['author'], 'observed_committer': c['committer']}
            for c in inventory['commits'][:6]]
        data['documentation_commit_identity']['validation_candidate_commit'] = ledger['runtime_revision']
        data['documentation_commit_identity']['validation_candidate_tree'] = ledger['runtime_tree']
    else:
        closeout['boundary_collector'] = ledger['boundary_collector']
        closeout['runtime_collector'] = ledger['runtime_collector']
    assert all(data[key] == value for key, value in protected.items()), 'Original source pins or retained snapshots changed'
    contents = (json.dumps(data, indent=2, ensure_ascii=False) + '\n').encode()
    prepared.append((path, original_bytes, contents))
    outputs.append({'path': str(path), 'sha256': hashlib.sha256(contents).hexdigest()})
for path, original_bytes, contents in prepared:
    assert path.read_bytes() == original_bytes, 'Tracked ledger changed during preparation'
for path, original_bytes, contents in prepared:
    path.write_bytes(contents)
with args.receipt.open('x') as stream:
    stream.write(json.dumps({'inputs': inputs, 'outputs': outputs, 'created_utc': now, 'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}, indent=2) + '\n')
print(json.dumps({'outputs': outputs, 'receipt': str(args.receipt)}))

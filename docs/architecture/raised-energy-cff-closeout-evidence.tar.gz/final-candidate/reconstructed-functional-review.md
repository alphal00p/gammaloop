# V2 reconstructed functional review

All owning diff paths are accounted for. Exact prior review reuse and fresh GL00 hunk review remain distinct; runtime and final C7 approval are separate.

| Commit | Revision | Paths | Exact v1 transitions | V1 patch replay | Fresh GL00 hunks |
|---|---|---:|---:|---:|---:|
| 1 | `97eb06cbd3b09cd62c242f27da668accf68173c8` | 36 | 36 | 0 | 0 |
| 2 | `2ba79605128090281bf4ebffdfa0f1c52fb4ba7f` | 22 | 22 | 0 | 0 |
| 3 | `1f0d4fd6141b1e572fe780824dc2579142f2343f` | 111 | 109 | 0 | 2 |
| 4 | `48104fa453f8a8a35077ec8a5e1d9ad94e7a9c16` | 283 | 282 | 1 | 0 |
| 5 | `32a57c5dd5beedcdf7e42c17091baf7a6e9a6fec` | 74 | 73 | 1 | 0 |
| 6 | `ee798ce279f280000537e4d8c05ecc83fc6ec2cf` | 32 | 32 | 0 | 0 |

The six commits contain 558 owning commit/path records across 485 paths. 554 exact v1 transitions retain their existing semantic review. Two architecture owning patches replay exactly on the amended parent, and the two C3 source/document hunks have independent review.

GL00 now checks the complete signed post-Taylor child numerator, physical owner roles, denominator multiplicities, masses and UV domain. The fixture retains both mass fields before the documented final identification. GL04 remains covered by the same fixture loop. The certificate does not independently exercise the Taylor-producing stage or every physical forest.

The JSON retains all prior source mappings and review evidence, enumerates every actual before/after mode/type/blob, and records exact scratch patch replay. No Cargo, backend or repository/history mutation occurred. C1/C2 are unchanged; fresh affected-boundary and final runtime evidence belongs to separate receipts.

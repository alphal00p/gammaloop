#!/usr/bin/env python3
"""Collect completed final-runtime-job evidence without running any validation.

Invoke with --revision FULL_COMMIT --tree FULL_TREE --log-root ABSOLUTE_ROOT.
Only scratch runtime-evidence*.json is written; raw evidence remains untouched.
Gates/features remain in collect-boundary-evidence.py, not these runtime counts.
"""
from pathlib import Path
from datetime import datetime, timezone
from collections import Counter
import argparse
import hashlib
import itertools
import json
import re
import runpy
import shlex

BASE = Path('/tmp/raised-stack/closeout/gl00-certificate-v2/validation-prep')
LIBRARY = BASE / 'collect-boundary-evidence.py'
# Reuse the reviewed stable-read, guard, summary, identity and ignored-mode logic.
LIB = runpy.run_path(str(LIBRARY), run_name='boundary_evidence_library')
read, fingerprint, invocation = (LIB[name] for name in ['read', 'fingerprint', 'invocation'])
JOBS = ['curated', 'commit5-phases', 'signed-acceptances', 'commit6-vakint-uv',
        'scalar-all', 'shared-default', 'shared-all', 'shared-no-default', 'ufo-model-parity', 'vertex-rules']
RUN_FLAGS = ['--test-threads', '4', '--retries', '0', '--no-fail-fast',
             '--status-level', 'pass', '--final-status-level', 'all',
             '--failure-output', 'immediate-final', '--success-output', 'never']
SECRET = re.compile(r'\b[0-9a-fA-F]{8}#[0-9a-fA-F]{8}#[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}\b')


def context(prefix, revision, tree):
    path = Path(str(prefix) + '.context')
    lines = read(path).decode().splitlines()
    assert lines[-3:] == [revision, tree, revision], path
    fields = dict(line.split('=', 1) for line in lines if '=' in line)
    expected = {'workers': '4', 'retries': '0', 'snapshot_updates': 'no',
                'memory_limit_decimal_gb': '30', 'checkout': '/tmp/raised-stack/prefix',
                'target': '/common/dev/gammaloop/higher-power-energies-review/target'}
    assert all(fields.get(key) == value for key, value in expected.items()), path
    return {'recorded_text': '\n'.join(lines) + '\n', 'fields': fields,
            'revision': revision, 'tree': tree, 'actual_head': revision}


def outer_job(root, name, revision, tree):
    directory = root / 'jobs' / name
    required = ['revision', 'tree', 'started', 'completed', 'driver.exit',
                'integrity.exit', 'actual-head-after', 'runner-fingerprints.txt']
    if not all((directory / field).is_file() for field in required):
        return {'status': 'incomplete', 'missing': [field for field in required if not (directory / field).is_file()]}
    assert read(directory / 'revision').decode().strip() == revision
    assert read(directory / 'tree').decode().strip() == tree
    assert read(directory / 'actual-head-after').decode().strip() == revision
    assert int(read(directory / 'integrity.exit')) == 0
    driver_exit = int(read(directory / 'driver.exit'))
    sources = [directory / field for field in required]
    phases = {}
    for phase in ['list', 'run']:
        exit_path = directory / (phase + '.exit')
        command_path = directory / (phase + '.invocation.command')
        if exit_path.is_file():
            command = read(command_path).decode()
            expected = ['/tmp/raised-stack/run', 'bash', '/tmp/raised-stack/closeout/gl00-certificate-v2/validation-prep/remaining-validation',
                        phase, name, str(root / 'tests')]
            assert shlex.split(command) == expected, command_path
            phases[phase] = {'argv': expected, 'exit_code': int(read(exit_path))}
            sources.extend([exit_path, command_path])
    assert 'list' in phases
    assert driver_exit == phases.get('run', phases['list'])['exit_code']
    assert ('run' in phases) == (phases['list']['exit_code'] == 0)
    runner_hashes = []
    expected_runners = {'/tmp/raised-stack/closeout/gl00-certificate-v2/validation-prep/remaining-validation', '/tmp/raised-stack/closeout/gl00-certificate-v2/extra-prefix-checks',
                        str(BASE / 'final-runtime-job')}
    for line in read(directory / 'runner-fingerprints.txt').decode().splitlines():
        digest, path = line.split(maxsplit=1)
        assert re.fullmatch(r'[0-9a-f]{64}', digest) and path in expected_runners
        runner_hashes.append({'path': path, 'sha256': digest})
    assert {row['path'] for row in runner_hashes} == expected_runners and len(runner_hashes) == 3
    return {'status': 'completed', 'driver_exit_code': driver_exit, 'phases': phases,
            'runner_hashes_at_invocation': runner_hashes,
            'started_utc': read(directory / 'started').decode().strip(),
            'completed_utc': read(directory / 'completed').decode().strip(),
            'source_files': [fingerprint(path) for path in sources]}


def collect_job(root, name, revision, tree):
    prefixes = {phase: root / 'tests' / (name + '.' + phase) for phase in ['list', 'run']}
    phases = {phase: invocation(prefixes[phase], revision, 'list' if phase == 'list' else 'tests')
              for phase in ['list', 'run']}
    outer = outer_job(root, name, revision, tree)
    record = {'selection': name, 'status': 'incomplete', 'listing_and_execution': phases,
              'outer_job': outer, 'counted_in_executed_union': False}
    for phase, result in phases.items():
        if result['status'] == 'completed':
            assert result['argv'][:3] == ['cargo', 'nextest', phase]
            assert '--locked' in result['argv']
            result['full_context'] = context(prefixes[phase], revision, tree)
            if outer['status'] == 'completed':
                assert outer['phases'][phase]['exit_code'] == result['exit_code']
    if outer['status'] != 'completed':
        return record
    listed, run = phases['list'], phases['run']
    assert listed['status'] == 'completed', 'Closed outer job lacks a completed listing guard'
    if listed['exit_code'] != 0:
        assert run['status'] == 'incomplete'
        record['status'] = 'closed_failed_before_tests'
        return record
    assert run['status'] == 'completed', 'Closed outer job lacks a completed execution guard'
    assert listed['argv'][-2:] == ['--message-format', 'json']
    expected_run = listed['argv'][:-2]
    expected_run[2] = 'run'
    assert run['argv'] == expected_run + RUN_FLAGS, 'Listing/execution Cargo or filter arguments differ'
    left_context, right_context = (phases[phase]['full_context']['recorded_text'].splitlines()[1:]
                                   for phase in ['list', 'run'])
    assert left_context == right_context, 'List/run recorded environment or pins differ'
    if run.get('tests') is None:
        assert run['exit_code'] != 0
        record['status'] = 'closed_without_complete_test_summary'
        return record
    tests = run['tests']
    expected = {tuple(key) for key in listed.pop('selected_identities')}
    actual = {(row['binary_id'], row['test_name']) for row in tests['cases']}
    assert actual == expected and tests['selected'] > 0, 'Listed/executed identities differ or selection is empty'
    assert run['exit_code'] == (100 if tests['failed'] else 0), 'Outcome summary and nextest exit differ'
    listed['selected_count'] = len(expected)
    argv = run['argv']
    fields = run['full_context']['fields']
    configuration = {'cargo_selection_argv': argv[3:argv.index('-E')],
                     'rustflags': fields.get('rustflags', ''),
                     'target': fields['target'], 'pythonpath': fields.get('PYTHONPATH')}
    encoded = json.dumps(configuration, sort_keys=True, separators=(',', ':')).encode()
    identities = ''.join(f'{binary}\t{test}\n' for binary, test in sorted(actual))
    slow = {(binary, test) for binary, test in actual if re.search(r'(^|::)slow::', test)}
    assert not any('pysecdec' in binary or test == 'test_integrate_1l_decorated_indices_pysecdec' for binary, test in actual)
    failing_names = {test for _, test in actual if re.search(r'(^|::)failing::', test)}
    if name == 'vertex-rules':
        assert len(actual) == 1 and failing_names == {'graph::parse::tests::failing::vertex_rules'}
        assert '--ignore-default-filter' in argv and argv[argv.index('--run-ignored') + 1] == 'all'
    else:
        assert not failing_names, 'Unexpected failing-class test outside its explicitly approved job'
    if name == 'curated':
        required = {'gl00_gl04_planned_lifts_match_post_t_numerators_in_common_loop_coordinates',
                    'arb_parameter_baseline_uses_decimal_promotion',
                    'nested_vacuum_denominators_preserve_incidence_and_factorized_numerators',
                    'finite_part_quark_lo'}
        assert required <= {test.rsplit('::', 1)[-1] for _, test in actual}, 'Curated selection omitted an approved correction'
        record['newly_approved_curated_tests'] = sorted(required)
    if name == 'scalar-all':
        standard = {(binary, test) for binary, test in actual
                    if test.startswith('scalar_3l_cross_section_inspects::default_scalar_3l_cross_section_inspects::')}
        scalar_slow = {(binary, test) for binary, test in actual
                       if test.startswith('scalar_3l_cross_section_inspects::slow::')}
        assert standard | scalar_slow == actual and not standard & scalar_slow
        assert '--release' in argv and '--ignore-default-filter' in argv
        assert argv[argv.index('--run-ignored') + 1] == 'all'
        assert argv[argv.index('--test') + 1] == 'test_runs'
        record['scalar_namespace_counts'] = {'standard': len(standard), 'slow': len(scalar_slow),
                                             'total': len(actual), 'scope': 'Only the two selected scalar namespaces; other tests remain outside this matrix.'}
    else:
        assert not slow, 'Unexpected slow namespace in ordinary selection'
    record.update(status='completed', counted_in_executed_union=True,
                  list_run_identity_match=True, selected_identity_sha256=hashlib.sha256(identities.encode()).hexdigest(),
                  configuration=configuration, configuration_sha256=hashlib.sha256(encoded).hexdigest(),
                  failed_identities=[{'binary_id': row['binary_id'], 'test_name': row['test_name'], 'status': row['status']}
                                     for row in tests['cases'] if row['status'] != 'PASS'],
                  slow_namespace_cases=len(slow),
                  failure_cause_scope='Only identities and outcomes are recorded; matching names/statuses do not establish matching causes.')
    return record


def aggregate(records):
    completed = {record['selection']: record for record in records if record['counted_in_executed_union']}
    maps = {name: {(row['binary_id'], row['test_name']): row['status']
                   for row in record['listing_and_execution']['run']['tests']['cases']}
            for name, record in completed.items()}
    union = set().union(*(set(rows) for rows in maps.values()))
    failed = {identity for rows in maps.values() for identity, status in rows.items() if status != 'PASS'}
    statuses = Counter(status for rows in maps.values() for status in rows.values())
    disagreements = [{'left': left, 'right': right, 'binary_id': key[0], 'test_name': key[1],
                      'left_status': maps[left][key], 'right_status': maps[right][key]}
                     for left, right in itertools.combinations(maps, 2)
                     for key in sorted(maps[left].keys() & maps[right].keys()) if maps[left][key] != maps[right][key]]
    configurations = {}
    for name, record in completed.items():
        configurations.setdefault(record['configuration_sha256'],
                                  {'configuration': record['configuration'], 'jobs': []})['jobs'].append(name)
    result = {'scope': 'Completed selections only; partial until every required job closes. Identity unions do not collapse distinct Cargo configurations.',
              'completed_jobs': list(completed), 'missing_or_incomplete_jobs': [name for name in JOBS if name not in completed],
              'all_required_selections_complete': len(completed) == len(JOBS),
              'all_selected_tests_pass': len(completed) == len(JOBS) and not failed,
              'distinct_identities': len(union), 'identities_with_only_passes': len(union - failed),
              'identities_with_any_nonpass': len(failed), 'actual_executions': sum(statuses.values()),
              'execution_status_counts': dict(sorted(statuses.items())),
              'failed_identities': [{'binary_id': key[0], 'test_name': key[1]} for key in sorted(failed)],
              'pairwise_intersections': [{'left': left, 'right': right, 'count': len(maps[left].keys() & maps[right].keys())}
                                        for left, right in itertools.combinations(maps, 2)],
              'overlapping_status_disagreements': disagreements,
              'configurations': [{'sha256': digest, **row} for digest, row in sorted(configurations.items())]}
    if 'curated' in maps:
        result['curated_inclusion'] = [{'job': name, 'overlap': len(rows.keys() & maps['curated'].keys()),
                                       'outside_curated': len(rows.keys() - maps['curated'].keys()),
                                       'is_subset_by_identity_only': rows.keys() <= maps['curated'].keys()}
                                      for name, rows in maps.items() if name != 'curated']
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--revision', required=True)
    parser.add_argument('--tree', required=True)
    parser.add_argument('--log-root', type=Path, default=BASE / 'boundary-7')
    parser.add_argument('--output', type=Path, default=BASE / 'runtime-evidence.json')
    args = parser.parse_args()
    assert re.fullmatch(r'[0-9a-f]{40}', args.revision) and re.fullmatch(r'[0-9a-f]{40}', args.tree)
    root, output = args.log_root.resolve(), args.output.resolve()
    assert root.is_relative_to(BASE) and root != BASE
    assert output.parent == BASE and output.name.startswith('runtime-evidence') and output.suffix == '.json'
    assert output not in [LIBRARY.resolve(), Path(__file__).resolve()]
    root_revision = root / 'revision'
    if root_revision.is_file():
        assert read(root_revision).decode().strip() == args.revision
    records = [collect_job(root, name, args.revision, args.tree) for name in JOBS]
    snapshot = {'schema_version': 1, 'recorded_at_utc': datetime.now(timezone.utc).isoformat(),
                'scope': 'Scratch-only final runtime evidence. Missing/running jobs, gates, features, history and rendered documents are not certified.',
                'declared_revision': args.revision, 'declared_tree': args.tree,
                'revision_scope': 'Exact saved job revision/tree/actual-head and list/run context pins are checked; no live Git or workspace observation is performed.',
                'log_root': str(root), 'root_revision_receipt': fingerprint(root_revision) if root_revision.is_file() else None,
                'jobs': records, 'aggregate': aggregate(records),
                'pending_test_proposals': [],
                'manual_pysecdec_scope': 'Explicitly excluded from every completed identity set; no manual integration execution is claimed.',
                'raw_artifact_policy': 'Raw logs/list payloads stay at fingerprinted paths; only compact outcomes, commands, contexts and guard summaries are embedded.',
                'collector': fingerprint(Path(__file__)), 'reused_boundary_collector': fingerprint(LIBRARY)}
    for path, data in LIB['OBSERVED'].items():
        assert path.read_bytes() == data, ('Input changed during collection', path)
    encoded = (json.dumps(snapshot, indent=2, ensure_ascii=False, allow_nan=False) + '\n').encode()
    assert not SECRET.search(encoded.decode()), 'Credential-shaped content is excluded'
    temporary = output.with_suffix('.json.tmp')
    temporary.write_bytes(encoded)
    temporary.replace(output)
    print(json.dumps({'output': str(output), 'sha256': hashlib.sha256(encoded).hexdigest(),
                      'bytes': len(encoded), 'aggregate': snapshot['aggregate']}, indent=2))


if __name__ == '__main__':
    main()

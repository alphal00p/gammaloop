cargo check -p three-dimensional-reps --all-targets --no-default-features --locked 

cargo build --workspace --all-targets --locked --profile dev-optim 

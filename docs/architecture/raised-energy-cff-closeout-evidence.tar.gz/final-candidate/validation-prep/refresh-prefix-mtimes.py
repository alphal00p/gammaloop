#!/usr/bin/env python3
"""Refresh changed tracked prefix mtimes before Cargo; preserve bytes and modes.

At C1 the cache provenance is unknown, so refresh every tracked regular file.
At later boundaries, require the previous gate certificate and refresh only
added or blob/mode-changed files. The driver checks all tracked bytes before
and after gates. No source contents, Git/jj metadata, target or license changes.
"""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import stat
import subprocess
import time

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--revision', required=True)
parser.add_argument('--output', type=Path, required=True)
parser.add_argument('--reference-boundary', type=Path)
args = parser.parse_args()
base = Path('/tmp/raised-stack/closeout/gl00-certificate-v2/validation-prep')
prefix = Path('/tmp/raised-stack/prefix')
repository = Path('/common/dev/gammaloop/higher-power-energies-review')
assert len(args.revision) == 40 and all(c in '0123456789abcdef' for c in args.revision)
output = args.output.resolve()
assert output.is_relative_to(base) and not output.exists() and output.parent.is_dir()
assert prefix.is_dir() and not prefix.is_symlink()
reference_revision = None
reference_certificates = []
if args.reference_boundary:
    reference = args.reference_boundary.resolve()
    assert (reference.is_relative_to(base) or reference == Path("/tmp/raised-stack/closeout/validation-prep/boundary-7")) and reference != output.parent
    required = ['revision', 'tree', 'gates-completed', 'actual-head-after', 'post-gates-tracked-audit.json']
    assert all((reference / name).is_file() for name in required), 'Reference boundary certificate unavailable'
    reference_revision = (reference / 'revision').read_text().strip()
    assert len(reference_revision) == 40 and all(c in '0123456789abcdef' for c in reference_revision)
    assert (reference / 'actual-head-after').read_text().strip() == reference_revision
    previous_audit = json.loads((reference / 'post-gates-tracked-audit.json').read_text())
    assert previous_audit['status'] == 'PASS' and previous_audit['all_match']
    assert previous_audit['revision'] == reference_revision and previous_audit['tree'] == (reference / 'tree').read_text().strip()
    for name in required:
        data = (reference / name).read_bytes()
        reference_certificates.append({'path': str(reference / name), 'sha256': hashlib.sha256(data).hexdigest()})
commands = []
inventories = {}
inventory_hashes = {}
for revision in [reference_revision, args.revision]:
    if revision is None:
        continue
    command = ['git', '-C', str(repository), 'ls-tree', '-rz', '--full-tree', revision]
    commands.append(command)
    raw = subprocess.check_output(command, env={**os.environ, 'GIT_OPTIONAL_LOCKS': '0'})
    inventory_hashes[revision] = hashlib.sha256(raw).hexdigest()
    entries = {}
    for record in raw.split(b'\0'):
        if not record:
            continue
        metadata, path = record.split(b'\t', 1)
        mode, kind, blob = metadata.decode().split()
        relative = PurePosixPath(os.fsdecode(path))
        assert relative.parts and not relative.is_absolute() and '..' not in relative.parts
        assert not {'.git', '.jj'} & set(relative.parts)
        assert kind == 'blob' and mode in ['100644', '100755', '120000']
        entries[str(relative)] = {'mode': mode, 'blob': blob}
    assert entries, 'Missing or empty revision inventory'
    inventories[revision] = entries
current = inventories[args.revision]
previous = inventories.get(reference_revision, {})
unchanged = []
refresh = []
for path, item in current.items():
    target = prefix / path
    assert target.parent.resolve().is_relative_to(prefix)
    info = target.lstat()
    if item['mode'] == '120000':
        assert stat.S_ISLNK(info.st_mode)
        continue
    assert stat.S_ISREG(info.st_mode)
    if previous.get(path) == item:
        unchanged.append({'path': path, **item, 'preserved_mtime_ns': info.st_mtime_ns})
    else:
        refresh.append((path, item, target, info))
now = time.time_ns()
assert all(info.st_mtime_ns < now for _, _, _, info in refresh), 'Future/equal source mtime; investigate instead of silently claiming invalidation'
rows = []
for path, item, target, info in refresh:
    os.utime(target, ns=(info.st_atime_ns, now), follow_symlinks=False)
    after = target.lstat()
    assert after.st_size == info.st_size and after.st_mode == info.st_mode and after.st_mtime_ns == now
    rows.append({'path': path, **item, 'previous': previous.get(path), 'old_mtime_ns': info.st_mtime_ns, 'new_mtime_ns': after.st_mtime_ns, 'bytes': info.st_size})
for row in unchanged:
    assert (prefix / row['path']).lstat().st_mtime_ns == row['preserved_mtime_ns']
receipt = {
    'revision': args.revision,
    'reference_revision': reference_revision,
    'recorded_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'purpose': 'Force initial source invalidation, then only changed tracked blobs/modes against the previous certified prefix; preserve identical source mtimes.',
    'commands': commands,
    'reference_certificates': reference_certificates,
    'inventory_sha256': inventory_hashes,
    'tracked_regular_files_refreshed': len(rows),
    'unchanged_regular_files_preserved': len(unchanged),
    'source_contents_changed': False,
    'files': rows,
    'unchanged_files': unchanged,
    'removed_reference_files': [{'path': path, **item} for path, item in previous.items() if path not in current],
}
with output.open('x') as f:
    json.dump(receipt, f, indent=2)
    f.write('\n')
print(json.dumps({'receipt': str(output), 'tracked_regular_files_refreshed': len(rows), 'unchanged_regular_files_preserved': len(unchanged)}))

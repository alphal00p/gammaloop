cargo check --workspace --all-targets --features vakint/symbolica_community_module --locked 

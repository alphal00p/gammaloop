#!/usr/bin/env python3
"""Read completed boundary receipts only; write a bounded scratch JSON snapshot.

Usage: python collect-boundary-evidence.py --through 6
Use --through 7 after boundary-7 exists; --output must remain in this directory.
Use --include-interrupted to retain preserved interruptions and failed builds.
Use --include-failed-build to include only the latter historical attempts.
No subprocess, Cargo, repository/history writes, or licensed-wrapper reads.
"""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import json
import re
import shlex

BASE = Path('/tmp/raised-stack/closeout/gl00-certificate-v2/validation-prep')
ORIGINAL_BASE = Path('/tmp/raised-stack/closeout/validation-prep')
FOLDERS = {number: (ORIGINAL_BASE if number <= 2 else BASE) / f'boundary-{number}' for number in range(1, 8)}
CERTIFICATE = 'graph::three_d_source::tests::gl00_gl04_planned_lifts_match_post_t_numerators_in_common_loop_coordinates'
REUSED_PINS = {1: ('97eb06cbd3b09cd62c242f27da668accf68173c8', '5c270b8f8e491416413667f00e257a7e4429b62d'), 2: ('2ba79605128090281bf4ebffdfa0f1c52fb4ba7f', 'e28fd22e70c1737f02f8951ad8c3872afb623fa1')}
LINKAGE_INPUTS = {BASE.parent / 'validation-inputs.json', BASE.parent / 'runtime-candidate.json'}
ANSI = re.compile(r'\x1b\[[0-9;]*m')
RESULT = re.compile(r'^\s*(PASS|FAIL|TIMEOUT|ABORT|LEAK|EXECFAIL)\s+\[\s*([\d.]+)s\]\s+\(\s*(\d+)/(\d+)\)\s+(\S+)\s+(\S+)\s*$')
OBSERVED = {}
EXPECTED_MATRIX = {
    1: ['commit1-foundations'],
    2: ['shared-default', 'shared-all', 'shared-no-default'],
    3: ['commit3-cff-uv', 'shared-default', 'shared-all', 'shared-no-default'],
    4: ['commit4-workflows', 'commit4-scalar-smoke', 'signed-acceptances', 'source-certificates', 'shared-default', 'shared-all', 'shared-no-default'],
    5: ['commit5-phases', 'signed-acceptances', 'vertex-rules', 'source-certificates', 'shared-default', 'shared-all', 'shared-no-default'],
    6: ['commit6-vakint-uv', 'source-certificates', 'shared-default', 'shared-all', 'shared-no-default'],
    7: ['curated', 'commit5-phases', 'signed-acceptances', 'commit6-vakint-uv', 'scalar-all', 'shared-default', 'shared-all', 'shared-no-default', 'ufo-model-parity', 'vertex-rules'],
}


def read(path):
    path = path.resolve()
    assert path.is_relative_to(BASE) or any(path.is_relative_to(FOLDERS[number]) for number in [1, 2]) or path == ORIGINAL_BASE / "boundary-7/revision" or path in LINKAGE_INPUTS, path
    before = path.stat()
    data = path.read_bytes()
    after = path.stat()
    assert (before.st_size, before.st_mtime_ns, before.st_ino) == (after.st_size, after.st_mtime_ns, after.st_ino), path
    assert path not in OBSERVED or OBSERVED[path] == data, path
    OBSERVED[path] = data
    return data


def fingerprint(path):
    data = read(path)
    return {'path': str(path), 'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}


def seconds(value):
    return sum(float(n) * {'ms': .001, 's': 1, 'm': 60, 'h': 3600}[unit]
               for n, unit in re.findall(r'([\d.]+)\s*(ms|s|m|h)', value))


def result_summary(log):
    clean = ANSI.sub('', log)
    summaries = [line.strip() for line in clean.splitlines() if re.search(r'\bSummary\s+\[', line)]
    if not summaries:
        return None
    assert len(set(summaries)) == 1, 'Multiple different nextest summaries'
    summary = summaries[0]
    match = re.search(r'\[\s*([\d.]+)s\]\s+(\d+) tests? run:', summary)
    assert match, summary
    counts = {name: int(m[1]) if (m := re.search(r'(\d+) ' + name, summary)) else 0
              for name in ['passed', 'failed', 'skipped']}
    selected = int(match[2])
    cases, indices, repetitions = {}, {}, 0
    for line in clean.splitlines():
        match_case = RESULT.match(line)
        if not match_case:
            continue
        status, duration, index, total, binary, test = match_case.groups()
        row = {'binary_id': binary, 'test_name': test, 'status': status,
               'seconds': float(duration), 'progress_index': int(index)}
        key = (binary, test)
        assert int(total) == selected
        assert key not in cases or cases[key] == row, ('Conflicting repeated outcome', key)
        assert int(index) not in indices or indices[int(index)] == key
        repetitions += key in cases
        cases[key] = row
        indices[int(index)] = key
    assert len(cases) == selected and set(indices) == set(range(1, selected + 1)), 'Incomplete result identities'
    assert sum(row['status'] == 'PASS' for row in cases.values()) == counts['passed']
    assert selected - counts['passed'] == counts['failed'], 'Unclassified outcomes; inspect raw evidence'
    return {'summary': summary, 'selected': selected, **counts,
            'elapsed_seconds': float(match[1]),
            'repeated_result_lines_ignored': repetitions,
            'cases': [cases[key] for key in sorted(cases)]}


def invocation(prefix, revision, kind):
    def path(suffix):
        return Path(str(prefix) + suffix)
    exit_path, guard_path = path('.exit'), path('.watchdog.jsonl')
    if not exit_path.is_file() or not guard_path.is_file():
        return {'status': 'incomplete', 'reason': 'Missing exit or complete-watchdog receipt', 'prefix': str(prefix)}
    # The runner writes .exit only after the watchdog closes its output files.
    guard_data = read(guard_path)
    guards = [json.loads(line) for line in guard_data.splitlines() if line]
    starts = [item for item in guards if item.get('event') == 'start']
    ends = [item for item in guards if item.get('event') == 'complete']
    if not ends:
        return {'status': 'incomplete', 'reason': 'Watchdog completion absent', 'prefix': str(prefix)}
    assert len(starts) == len(ends) == 1 and guards[-1] == ends[0], guard_path
    command = read(path('.command')).decode()
    argv = shlex.split(command)
    assert argv == starts[0]['command'], path('.command')
    exit_code = int(read(exit_path))
    assert exit_code == ends[0]['returncode'], exit_path
    assert starts[0]['tree_limit_bytes'] == 30_000_000_000 and starts[0]['memory_metric'] == 'rss'
    sources = [path('.command'), exit_path, guard_path]
    logs = []
    for suffix in ['.log', '.stderr.log']:
        if path(suffix).is_file():
            logs.append(read(path(suffix)).decode())
            sources.append(path(suffix))
    assert logs, prefix
    log = '\n'.join(logs)
    record = {'status': 'completed', 'declared_revision': revision, 'command_file_text': command,
              'argv': argv, 'exit_code': exit_code, 'watchdog': {'elapsed_seconds': ends[0]['elapsed_s'],
              'peak_process_tree_rss_bytes': ends[0]['peak_tree_bytes'], 'limit_bytes': starts[0]['tree_limit_bytes']}}
    if path('.revision').is_file():
        assert read(path('.revision')).decode().strip() == revision
        sources.append(path('.revision'))
    if path('.started').is_file():
        record['started_utc'] = read(path('.started')).decode().strip()
        sources.append(path('.started'))
    if path('.context').is_file():
        context = read(path('.context')).decode().splitlines()
        assert context[-3] == context[-1] == revision and re.fullmatch(r'[0-9a-f]{40}', context[-2])
        fields = dict(line.split('=', 1) for line in context if '=' in line)
        for field, value in [('workers', '4'), ('retries', '0'), ('snapshot_updates', 'no'), ('memory_limit_decimal_gb', '30')]:
            assert fields[field] == value
        record['context'] = {'declared_revision': context[-3], 'tree': context[-2], 'actual_head': context[-1],
                             **{key: fields[key] for key in ['workers', 'retries', 'snapshot_updates', 'memory_limit_decimal_gb']}}
        sources.append(path('.context'))
    elapsed = re.findall(r'Finished `[^`]+` profile .*? in ([^\n]+)', ANSI.sub('', log))
    if elapsed:
        record['cargo_elapsed'] = {'reported': elapsed[-1], 'seconds': seconds(elapsed[-1])}
    if kind == 'tests':
        assert argv[:3] == ['cargo', 'nextest', 'run']
        assert argv[argv.index('--test-threads') + 1] == '4' and argv[argv.index('--retries') + 1] == '0'
        assert '--no-fail-fast' in argv and '--locked' in argv
        record['tests'] = result_summary(log)
        if exit_code == 0:
            assert record['tests'] is not None and record['tests']['failed'] == 0
    elif kind == 'list' and exit_code == 0:
        listing = json.loads(read(path('.json')))
        sources.append(path('.json'))
        selected = []
        for suite in listing['rust-suites'].values():
            for name, case in suite.get('testcases', {}).items():
                if case['filter-match']['status'] != 'matches':
                    continue
                ignored_mode = argv[argv.index('--run-ignored') + 1] if '--run-ignored' in argv else 'default'
                if (case['ignored'] and ignored_mode == 'default') or (not case['ignored'] and ignored_mode == 'ignored-only'):
                    continue
                selected.append((suite['binary-id'], name))
        assert len(set(selected)) == len(selected)
        record['selected_identities'] = sorted(selected)
    record['source_files'] = [fingerprint(p) for p in sources]
    return record


def boundary(number):
    folder = FOLDERS[number]
    if not (folder / 'revision').is_file():
        return {'boundary': number, 'status': 'incomplete', 'reason': 'Boundary revision not recorded'}
    revision = read(folder / 'revision').decode().strip()
    assert re.fullmatch(r'[0-9a-f]{40}', revision)
    if number <= 2:
        expected_revision, expected_tree = REUSED_PINS[number]
    elif number <= 6:
        linkage = json.loads(read(BASE.parent / 'validation-inputs.json'))['first_six'][number - 1]
        expected_revision, expected_tree = linkage['commit'], linkage['tree']
    else:
        linkage = json.loads(read(BASE.parent / 'runtime-candidate.json'))
        expected_revision, expected_tree = linkage['revision'], linkage['tree']
    assert revision == expected_revision, 'Boundary receipt does not match its pinned candidate'
    jobs = {name: invocation(folder / name, revision, 'tests' if name == 'targeted' else 'gate')
            for name in ['fmt', 'check', 'build', 'clippy']}
    features = ([] if number == 1 else ['shared-all', 'shared-no-default']) + (['python-api'] if number == 4 else []) + (['vakint-community'] if number == 6 else [])
    feature_results = {name: invocation(folder / 'features' / name, revision, 'feature') for name in features}
    matrix_names = set(EXPECTED_MATRIX[number])
    matrix_names.update(p.name.removesuffix('.list.command') for p in (folder / 'tests').glob('*.list.command'))
    matrix = {}
    for name in sorted(matrix_names):
        listed = invocation(folder / 'tests' / (name + '.list'), revision, 'list')
        run = invocation(folder / 'tests' / (name + '.run'), revision, 'tests')
        result = {'list': listed, 'run': run}
        if listed.get('exit_code') == 0 and run.get('tests') is not None:
            expected = {tuple(key) for key in listed['selected_identities']}
            actual = {(row['binary_id'], row['test_name']) for row in run['tests']['cases']}
            assert actual == expected, ('List/run selection differs', number, name)
            if (number == 3 and name == 'commit3-cff-uv') or name == 'source-certificates' or (number == 7 and name == 'curated'):
                assert ('gammalooprs', CERTIFICATE) in actual, 'Complete GL00/GL04 certificate identity absent'
            assert listed['argv'][listed['argv'].index('-E') + 1] == run['argv'][run['argv'].index('-E') + 1]
            assert listed['context'] == run['context']
            result['list_run_identity_match'] = True
            # Full identities/durations are retained once in run.tests.cases.
            listed['selected_count'] = len(listed.pop('selected_identities'))
        matrix[name] = result
    all_jobs = list(jobs.values()) + list(feature_results.values()) + [record[phase] for record in matrix.values() for phase in ['list', 'run']]
    source_names = ['pre-gates-tracked-audit.json', 'post-gates-tracked-audit.json', 'source-mtime-refresh.json', 'actual-head-after', 'gates-completed', 'tree']
    source_checks = {'status': 'incomplete', 'missing': [name for name in source_names if not (folder / name).is_file()]}
    if not source_checks['missing']:
        tree = read(folder / 'tree').decode().strip()
        assert re.fullmatch(r'[0-9a-f]{40}', tree) and tree == expected_tree
        for name in source_names[:2]:
            audit = json.loads(read(folder / name))
            assert audit['status'] == 'PASS' and audit['all_match']
            assert audit['revision'] == revision and audit['tree'] == tree
            assert len(audit['workspaces']) == 1
        refresh = json.loads(read(folder / 'source-mtime-refresh.json'))
        assert refresh['revision'] == revision and refresh['source_contents_changed'] is False
        assert refresh['tracked_regular_files_refreshed'] == len(refresh['files']) >= 0
        if number == 3:
            assert refresh['reference_revision'] == 'a474c96016a6236d0e91cb67dd284fe91a6c38b7'
        reference = ORIGINAL_BASE / 'boundary-7' if number == 3 else FOLDERS.get(number - 1)
        assert refresh['reference_revision'] is None if number == 1 else refresh['reference_revision'] == read(reference / 'revision').decode().strip()
        assert all(row['old_mtime_ns'] < row['new_mtime_ns'] for row in refresh['files'])
        assert read(folder / 'actual-head-after').decode().strip() == revision
        source_checks = {'status': 'completed', 'revision': revision, 'tree': tree,
                         'source_files': [fingerprint(folder / name) for name in source_names]}
    complete = source_checks['status'] == 'completed' and all(job['status'] == 'completed' for job in all_jobs)
    return {'boundary': number, 'receipt_directory': str(folder), 'reused_unchanged_revision_certificate': number <= 2, 'declared_revision': revision, 'revision_receipt': fingerprint(folder / 'revision'),
            'status': 'completed' if complete else 'incomplete', 'all_recorded_required_jobs_pass': complete and all(job['exit_code'] == 0 for job in all_jobs),
            'gates_and_targeted': jobs, 'feature_checks': feature_results, 'shared_or_additional_matrix': matrix, 'source_integrity': source_checks}


def interrupted_attempts(through):
    attempts = []
    for receipt in sorted(BASE.glob('boundary-*-interrupted*/interruption.json')):
        match = re.fullmatch(r'boundary-([3-7])-interrupted(?:[-_].+)?', receipt.parent.name)
        if not match or int(match[1]) > through:
            continue
        content = json.loads(read(receipt))
        revision = read(receipt.parent / 'revision').decode().strip()
        assert re.fullmatch(r'[0-9a-f]{40}', revision)
        sources = [receipt, receipt.parent / 'revision']
        for stem in ['fmt', 'check', 'build', 'clippy', 'targeted']:
            sources.extend(path for suffix in ['.command', '.exit', '.log', '.started', '.watchdog.jsonl']
                           if (path := receipt.parent / (stem + suffix)).is_file())
        if content.get('build_exit_recorded') is False:
            assert not (receipt.parent / 'build.exit').exists()
        if content.get('guard_has_completion_record') is False:
            guard = [json.loads(line) for line in read(receipt.parent / 'build.watchdog.jsonl').splitlines() if line]
            assert not any(row.get('event') == 'complete' for row in guard)
        attempts.append({'boundary': int(match[1]), 'declared_revision': revision,
                         'status': 'interrupted_incomplete_attempt',
                         'included_in_current_boundary_results': False,
                         'test_failure_inferred': False,
                         'cause_inference': 'None: preserve the recorded cause and last sample; do not infer OOM or a test failure.',
                         'interruption_receipt': {'source': fingerprint(receipt), 'content': content},
                         'source_files': [fingerprint(path) for path in sources]})
    return attempts


def failed_build_attempts(through):
    attempts = []
    for receipt in sorted(BASE.glob('boundary-*-link-failed/failure.json')):
        match = re.fullmatch(r'boundary-([3-7])-link-failed', receipt.parent.name)
        if not match or int(match[1]) > through:
            continue
        number = int(match[1])
        content = json.loads(read(receipt))
        revision = read(receipt.parent / 'revision').decode().strip()
        assert re.fullmatch(r'[0-9a-f]{40}', revision) and content['revision'] == revision
        gates = {name: invocation(receipt.parent / name, revision, 'gate') for name in ['fmt', 'check', 'build']}
        assert all(gate['status'] == 'completed' for gate in gates.values())
        assert gates['fmt']['exit_code'] == gates['check']['exit_code'] == 0
        assert gates['build']['exit_code'] == content['exit'] == 101
        assert gates['build']['watchdog']['elapsed_seconds'] == content['duration_seconds']
        assert gates['build']['watchdog']['peak_process_tree_rss_bytes'] == content['peak_tree_bytes']
        assert fingerprint(receipt.parent / 'build.log')['sha256'] == content['log_sha256']
        assert not list(receipt.parent.glob('targeted.*'))
        assert not (receipt.parent / 'tests').exists()
        attempts.append({'boundary': number, 'declared_revision': revision,
                         'status': 'completed_failed_build_attempt',
                         'included_in_current_boundary_results': False,
                         'tests_executed': False, 'test_failure_inferred': False,
                         'cause_inference': 'None: the receipt records an unestablished cause; cache quarantine is a recorded intervention, not proof of causation or recovery.',
                         'failure_receipt': {'source': fingerprint(receipt), 'content': content},
                         'revision_receipt': fingerprint(receipt.parent / 'revision'),
                         'gates': gates,
                         'related_evidence': [fingerprint(BASE / f'boundary-{number}-linker-diagnosis' / name)
                                              for name in ['diagnosis.json', 'archive-cache-match.json']]
                                             + [fingerprint(BASE / 'cache-quarantine.json')]})
    return attempts


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--through', type=int, choices=[1, 2, 3, 4, 5, 6, 7], default=7)
    parser.add_argument('--include-interrupted', action='store_true', help='Include preserved interruption and failed-build receipts separately from current results')
    parser.add_argument('--include-failed-build', action='store_true', help='Include preserved failed-build receipts only')
    parser.add_argument('--output', type=Path, default=BASE / 'boundary-evidence.json')
    args = parser.parse_args()
    output = args.output.resolve()
    assert output.parent == BASE and output.name.startswith('boundary-evidence') and output.suffix == '.json'
    snapshot = {'schema_version': 1, 'recorded_at_utc': datetime.now(timezone.utc).isoformat(),
                'scope': 'C1/C2 reuse certificates for unchanged commit IDs; C3–C7 require fresh completed gate and feature receipts; behavioral jobs are recorded under each owning boundary. Missing or interrupted jobs are not passes. Boundary and feature counts remain separate; missing/running outputs are not certified.',
                'boundaries': [boundary(n) for n in range(1, args.through + 1)],
                'interrupted_attempt_collection_requested': args.include_interrupted,
                'interrupted_attempts': interrupted_attempts(args.through) if args.include_interrupted else [],
                'failed_build_attempt_collection_requested': args.include_interrupted or args.include_failed_build,
                'failed_build_attempts': failed_build_attempts(args.through) if args.include_interrupted or args.include_failed_build else [],
                'collector': fingerprint(Path(__file__)),
                'runner_control_sources': [fingerprint(BASE / name) for name in ['validate-boundary', 'final-runtime-job', 'remaining-validation']],
                'provenance_limit': 'Gate/targeted revisions come from the directory revision receipt; feature checks also carry per-job revision receipts. Matrix jobs additionally verify recorded revision/tree/actual-head context. No Git query, test replay, or source/history mutation occurs.',
                'counting_limit': 'Repeated nextest final-status rows are deduplicated by full binary/test identity with identical outcome/duration/index required. Cross-boundary and cross-feature counts are not added as unique coverage.',
                'raw_artifact_policy': 'Raw logs and list payloads stay in scratch; this snapshot keeps exact hashes, commands, summaries, compact identities and guard outcomes only.'}
    for path, data in OBSERVED.items():
        assert path.read_bytes() == data, ('Input changed during collection', path)
    encoded = (json.dumps(snapshot, indent=2, ensure_ascii=False, allow_nan=False) + '\n').encode()
    temp = output.with_suffix('.json.tmp')
    temp.write_bytes(encoded)
    temp.replace(output)
    print(json.dumps({'output': str(output), 'sha256': hashlib.sha256(encoded).hexdigest(), 'bytes': len(encoded),
                      'boundaries': [{'number': row['boundary'], 'status': row['status']} for row in snapshot['boundaries']]}))


if __name__ == '__main__':
    main()

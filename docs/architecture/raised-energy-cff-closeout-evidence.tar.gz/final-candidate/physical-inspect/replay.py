"""Replay the retained GL04 inspection through an explicitly supplied frozen CLI."""

import argparse
import copy
import hashlib
import json
import math
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import time


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--binary", type=Path, required=True)
parser.add_argument("--revision", required=True)
parser.add_argument("--output", type=Path, required=True)
args = parser.parse_args()
assert re.fullmatch(r"[0-9a-f]{40}", args.revision), "supply the full final commit ID"
binary = args.binary.resolve(strict=True)
assert binary.is_file() and os.access(binary, os.X_OK), "CLI must be executable"
base = Path(__file__).resolve().parent
output = args.output.resolve(strict=True)
assert output.is_dir()
manifest_path = output / "manifest.json"
with manifest_path.open("x") as stream:
    json.dump({"status": "preparing", "revision": args.revision}, stream)

source = json.loads((base / "inputs/original-manifest.json").read_text())
state = Path(source["state"]).resolve(strict=True)
assert (state / "state_manifest.toml").is_file()
state_before = {
    str(path.relative_to(state)): hashlib.file_digest(path.open("rb"), "sha256").hexdigest()
    for path in sorted(state.rglob("*"))
    if path.is_file()
}
binary_before = hashlib.file_digest(binary.open("rb"), "sha256").hexdigest()
manifest = {
    "status": "prepared",
    "revision": args.revision,
    "binary": str(binary),
    "binary_sha256_before": binary_before,
    "state": str(state),
    "state_sha256_before": state_before,
    "same_state_as_original_reproducer": state_before == source["state_sha256_before"],
    "input_and_runner_sha256": {
        str(path.relative_to(base)): hashlib.file_digest(path.open("rb"), "sha256").hexdigest()
        for path in [
            *sorted((base / "inputs").iterdir()),
            base / "replay.py",
            base / "run.sh",
            base / "ram_watchdog.py",
        ]
        if path.is_file()
    },
    "resources": {
        "outer_memory_limit_gb": 8,
        "outer_timeout_seconds": 90,
        "cli_timeout_seconds": 40,
        "cli_kill_grace_seconds": 5,
        "concurrent_cli_processes": 2,
        "rayon_threads_per_cli": 2,
        "cpu_affinity": sorted(os.sched_getaffinity(0)),
        "retries": 0,
        "snapshot_updates": "disabled",
    },
    "runs": [],
}
manifest_path.write_text(json.dumps(manifest, indent=2) + "\n")
assert manifest["same_state_as_original_reproducer"], "retained state changed before replay"

env = os.environ.copy()
env.pop("GL_ALL_LOG_FILTER", None)
env.update(
    GL_LOGFILE_FILTER="off",
    GL_DISPLAY_FILTER="info",
    INSTA_UPDATE="no",
    RAYON_NUM_THREADS="2",
)
processes = []
try:
    for weights in [False, True]:
        label = "weights-" + str(weights).lower()
        run_dir = output / label
        run_dir.mkdir()
        json_path = run_dir / "sample.json"
        point = "inspect -p core_audit -i numerator -x 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9"
        statements = [
            "set process -p core_audit -i numerator kv general.generate_events=true "
            f"general.store_additional_weights_in_event={str(weights).lower()}",
            point,
            point + " --json-output " + str(json_path),
        ]
        command = [
            "timeout", "--signal=TERM", "--kill-after=5", "40", str(binary),
            "--read-only-state", "-n", "-s", str(state), "run", "-c", "; ".join(statements),
        ]
        row = {
            "weights": weights,
            "events": True,
            "command": command,
            "cwd": str(run_dir),
            "statements": statements,
            "log": str(run_dir / "run.log"),
            "json_path": str(json_path),
            "environment_overrides": {
                name: env[name]
                for name in ["GL_LOGFILE_FILTER", "GL_DISPLAY_FILTER", "INSTA_UPDATE", "RAYON_NUM_THREADS"]
            },
            "environment_unset": ["GL_ALL_LOG_FILTER"],
        }
        manifest["runs"].append(row)
        manifest_path.write_text(json.dumps(manifest, indent=2) + "\n")
        stream = Path(row["log"]).open("xb")
        started = time.monotonic()
        process = subprocess.Popen(
            command, env=env, cwd=run_dir, stdout=stream,
            stderr=subprocess.STDOUT, start_new_session=True,
        )
        processes.append((process, stream, row, started))
    for process, stream, row, started in processes:
        row["exit_code"] = process.wait(timeout=50)
        row["elapsed_seconds"] = time.monotonic() - started
        stream.close()
        row["json_exists"] = Path(row["json_path"]).is_file()
finally:
    for process, stream, row, started in processes:
        if process.poll() is None:
            os.killpg(process.pid, signal.SIGTERM)
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait()
        stream.close()
        row.setdefault("exit_code", process.returncode)
        row.setdefault("elapsed_seconds", time.monotonic() - started)
        row["json_exists"] = Path(row["json_path"]).is_file()
    manifest["state_sha256_after"] = {
        str(path.relative_to(state)): hashlib.file_digest(path.open("rb"), "sha256").hexdigest()
        for path in sorted(state.rglob("*"))
        if path.is_file()
    }
    manifest["binary_sha256_after"] = hashlib.file_digest(binary.open("rb"), "sha256").hexdigest()
    manifest["state_unchanged"] = manifest["state_sha256_after"] == state_before
    manifest["binary_unchanged"] = manifest["binary_sha256_after"] == binary_before
    manifest["status"] = "executed_pending_comparison"
    manifest_path.write_text(json.dumps(manifest, indent=2) + "\n")

try:
    assert manifest["state_unchanged"], "read-only replay changed the saved state"
    assert manifest["binary_unchanged"], "frozen binary changed during replay"
    assert all(row["exit_code"] == 0 and row["json_exists"] for row in manifest["runs"])
    payloads = {"original": json.loads((base / "inputs/original-weights-false.json").read_text())}
    for row in manifest["runs"]:
        payloads["weights-" + str(row["weights"]).lower()] = json.loads(Path(row["json_path"]).read_text())
    views = copy.deepcopy(payloads)
    exclusions = {}
    for label, document in views.items():
        metadata = document["evaluation"]["evaluation_metadata"]
        timing = {}
        for field in [
            "total_timing", "integrand_evaluation_time", "evaluator_evaluation_time",
            "parameterization_time", "event_processing_time",
        ]:
            duration = metadata.pop(field)
            assert set(duration) == {"secs", "nanos"}
            timing["evaluation.evaluation_metadata." + field] = duration
        for index, result in enumerate(metadata["stability_results"]):
            duration = result.pop("total_time")
            assert set(duration) == {"secs", "nanos"}
            timing[f"evaluation.evaluation_metadata.stability_results[{index}].total_time"] = duration
        exclusions[label] = timing
    manifest["excluded_timing_fields"] = exclusions

    normalizations = []
    enabled_weights = []
    for label, document in views.items():
        for group_index, group in enumerate(document["evaluation"]["event_groups"]):
            for event_index, event in enumerate(group):
                location = f"evaluation.event_groups[{group_index}][{event_index}].additional_weights.weights"
                assert set(event["additional_weights"]) == {"weights"}
                weights = event["additional_weights"]["weights"]
                if label == "original":
                    assert weights == {}, "only the original empty-object encoding is normalized"
                    event["additional_weights"]["weights"] = []
                    normalizations.append({"path": location, "from": {}, "to": []})
                elif label == "weights-false":
                    assert weights == [], "disabled additional weights must be an empty pair list"
                else:
                    assert isinstance(weights, list) and weights, "enabled event has no additional weights"
                    keys = set()
                    for pair in weights:
                        assert isinstance(pair, list) and len(pair) == 2
                        key, value = pair
                        if isinstance(key, str):
                            assert key in {"FullMultiplicativeFactor", "Original"}
                        else:
                            assert isinstance(key, dict) and len(key) == 1
                            variant, indices = next(iter(key.items()))
                            fields = {
                                "ThresholdCounterterm": {"subset_index"},
                                "AmplitudeThresholdCounterterm": {"esurface_id", "overlap_group"},
                            }
                            assert variant in fields and isinstance(indices, dict)
                            assert set(indices) == fields[variant]
                            assert all(type(index) is int and index >= 0 for index in indices.values())
                        identity = json.dumps(key, sort_keys=True)
                        assert identity not in keys, "duplicate additional-weight key"
                        keys.add(identity)
                        assert isinstance(value, dict) and set(value) == {"re", "im"}
                        assert all(type(number) in (int, float) and math.isfinite(number) for number in value.values())
                    enabled_weights.append({"path": location, "cut_info": event["cut_info"], "complete_pairs": weights})
    assert any(
        isinstance(key, dict) and "ThresholdCounterterm" in key
        for event in enabled_weights
        for key, value in event["complete_pairs"]
    ), "the structured key that caused the original JSON failure was not exercised"
    manifest["empty_weight_encoding_normalizations"] = normalizations
    manifest["enabled_additional_weights"] = enabled_weights

    comparisons = {
        "original": views["original"],
        "weights-false": views["weights-false"],
        "weights-false-common": copy.deepcopy(views["weights-false"]),
        "weights-true-common": copy.deepcopy(views["weights-true"]),
    }
    event_groups = {}
    for label, document in comparisons.items():
        groups = document["evaluation"].pop("event_groups")
        if label.endswith("-common"):
            for group in groups:
                for event in group:
                    del event["additional_weights"]
        event_groups[label] = groups
    for left, right in [("original", "weights-false"), ("weights-false-common", "weights-true-common")]:
        assert comparisons[left] == comparisons[right], f"evaluation differs: {left} versus {right}"
        unmatched = event_groups[right].copy()
        # Compare complete groups and events as multisets: traversal order is
        # not a physics contract, while group membership and every value are.
        # Native value equality also treats -0.0/0.0 and 1/1.0 equivalently.
        for group in event_groups[left]:
            for index, candidate in enumerate(unmatched):
                if len(group) == len(candidate) and all(
                    group.count(event) == candidate.count(event) for event in group
                ):
                    unmatched.pop(index)
                    break
            else:
                raise AssertionError(f"event group differs: {left} versus {right}")
        assert not unmatched, f"extra event groups: {right}"
    manifest["comparison_results"] = {
        "disabled_matches_retained_success": True,
        "toggle_preserves_all_non_additional_weight_content": True,
        "enabled_additional_weights_complete_and_well_formed": True,
        "structured_threshold_counterterm_exercised": True,
        "event_order_contract": "complete-record multisets within complete event groups; group membership retained",
        "numeric_comparison": "exact parsed f64 JSON values; no tolerance, rounding or numeric rewrite",
    }

    evaluation = payloads["original"]["evaluation"]
    expected_plain = {
        "integrand result": [evaluation["integrand_result"]["re"], evaluation["integrand_result"]["im"]],
        "parameterization jacobian": [evaluation["parameterization_jacobian"]],
        "integrator weight": [evaluation["integrator_weight"]],
        "event groups": [len(evaluation["event_groups"])],
        "generated events": [evaluation["evaluation_metadata"]["generated_event_count"]],
        "accepted events": [evaluation["evaluation_metadata"]["accepted_event_count"]],
    }
    for row in manifest["runs"]:
        plain = {field: [] for field in expected_plain}
        for line in Path(row["log"]).read_text().splitlines():
            fields = [part.strip() for part in re.sub(r"\x1b\[[0-9;]*m", "", line).split("│")]
            if len(fields) >= 3 and fields[1] in plain:
                numbers = [float(value.rstrip("i")) for value in fields[2].split()]
                plain[fields[1]].append(numbers)
        for field, expected in expected_plain.items():
            assert plain[field] == [expected, expected], f"plain and JSON inspect disagree on {field}: {plain[field]}"
        row["plain_and_json_displayed_values"] = plain
        row["plain_and_json_display_matches_original"] = True
    manifest["status"] = "passed"
except Exception as error:
    manifest["status"] = "failed"
    manifest["comparison_error"] = f"{type(error).__name__}: {error}"
    raise
finally:
    manifest_path.write_text(json.dumps(manifest, indent=2) + "\n")

print(json.dumps({"status": manifest["status"], "runs": len(manifest["runs"]), "inspect_calls": 4, "state_unchanged": manifest["state_unchanged"]}))

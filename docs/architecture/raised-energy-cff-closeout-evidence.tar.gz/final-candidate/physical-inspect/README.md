# Prepared GL04 inspection replay

Status: prepared; no new CLI has been executed. Run only after root supplies the
frozen final C7 CLI and its complete commit ID.

```bash
bash /tmp/raised-stack/closeout/gl00-certificate-v2/physical-inspect/run.sh \
  /absolute/path/to/frozen/gammaloop \
  FULL_40_CHARACTER_C7_COMMIT_ID \
  /tmp/raised-stack/closeout/gl00-certificate-v2/physical-inspect/final-c7
```

Invoke the runner directly. It enters `/tmp/raised-stack/run` exactly once;
the license wrapper is invocation-only and is not copied, read, or hashed.
The output directory must be new, preventing accidental overwrite or retries.
No Cargo commands, source edits, history changes, imports, graph generation,
or state migrations are performed.

The input is the exact retained explicit-process GL04 state at
`/tmp/cff-change-audit/core-perf/GL04-explicit-process-state` and the same point
`0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9`. Both runs enable event retention. Two
concurrent CLI processes toggle additional weights off/on; each executes plain
inspection followed by JSON inspection. Every CLI uses `--read-only-state`,
with file logging disabled and output files outside the saved state.

The common process tree has an 8 GB memory cap and a 90 second outer timeout.
Each CLI has a 40 second timeout followed by a 5 second kill grace. Both share
CPU affinity 8–11; each gets two Rayon threads. There are no retries or snapshot
updates. Timing receipts describe execution only and support no performance claim.

`inputs/` preserves the original reproducer, its manifest, and its successful
additional-weights-disabled JSON. Preparation confirmed that all 14 retained
state files still match that original manifest. Execution records the exact
commands, full logs and JSON values, binary hash before/after, complete state
file hashes before/after, and input/runner hashes. The original and frozen new
binaries are identified separately; the wrapper is excluded from fingerprints.

The validator requires:

- Both processes exit successfully and produce their JSON files. All four
  inspection calls print the same integrand result, Jacobian, integrator weight,
  event-group count, generated-event count and accepted-event count as the
  original successful JSON.
- The new disabled JSON matches that original payload completely, excluding
  exactly five named evaluation timing fields and each stability result's
  `total_time`. Stability values/status, event counts and other metadata remain
  part of the comparison. The sole value-encoding normalization changes each
  original empty additional-weight object `{}` into its new pair-list `[]`.
- Toggling additional weights preserves every other field, including all event
  kinematics, cut metadata and complex event weights. Additional-weight maps are
  omitted only from this toggle comparison, because that setting changes their
  content; their complete enabled payload is checked separately and retained.
- Enabled maps are nonempty lists of complete unique key/value pairs. Enum keys
  retain their structured variants and nonnegative integer indices. Values have
  both finite complex components. At least one actual structured
  `ThresholdCounterterm` key must occur, exercising the original failure.
- Complete events are compared as multisets within complete event groups, then
  groups as multisets. This preserves group membership and every event value
  without requiring traversal order. No numbers, signs, field names or nonempty
  additional-weight entries are rewritten; numerical equality uses exact parsed
  JSON f64 values with no tolerance or rounding.
- The binary and all saved state files remain byte-identical during execution.

The final `manifest.json` records each permitted timing exclusion, each original
empty-map encoding conversion, and every enabled key/value pair with its cut
metadata. `status: passed` is written only after all comparisons succeed. A CLI,
memory, or timeout failure is retained as a failure; it cannot certify replay or
state preservation without the corresponding completed receipts.

Preparation checks only parse the Python syntax, check shell syntax and verify
the retained state fingerprints. They are not new physics or CLI validation.

import json,pathlib,subprocess,os,hashlib
base=pathlib.Path('/tmp/cff-change-audit/physical/inspect-weights');base.mkdir(exist_ok=True)
state=pathlib.Path('/tmp/cff-change-audit/core-perf/GL04-explicit-process-state');binary=pathlib.Path('/tmp/cff-change-audit/root/bin/gammaloop-audit')
assert (state/'state_manifest.toml').exists()
snapshots={}
for p in state.rglob('*'):
 if p.is_file():
  with p.open('rb')as f:snapshots[str(p.relative_to(state))]=hashlib.file_digest(f,'sha256').hexdigest()
rows=[]
for weights in [False,True]:
 label='weights-'+str(weights).lower();output=base/(label+'.json');log=base/(label+'.log')
 statements=[f'set process -p core_audit -i numerator kv general.generate_events=true general.store_additional_weights_in_event={str(weights).lower()}', 'inspect -p core_audit -i numerator -x 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9', 'inspect -p core_audit -i numerator -x 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 --json-output '+str(output)]
 cmd=['/tmp/raised-stack/run','timeout','30',str(binary),'--read-only-state','-n','-s',str(state),'run','-c','; '.join(statements)]
 env=os.environ.copy();env.pop('GL_ALL_LOG_FILTER',None);env.update({'GL_LOGFILE_FILTER':'off','GL_DISPLAY_FILTER':'info','INSTA_UPDATE':'no'})
 with log.open('wb')as stream:r=subprocess.run(cmd,env=env,stdout=stream,stderr=subprocess.STDOUT,timeout=40)
 rows.append({'weights':weights,'events':True,'command':cmd,'exit_code':r.returncode,'log':str(log),'json_path':str(output),'json_exists':output.exists()})
 print(label,r.returncode,output.exists(),flush=True)
checks={}
for p in state.rglob('*'):
 if p.is_file():
  with p.open('rb')as f:checks[str(p.relative_to(state))]=hashlib.file_digest(f,'sha256').hexdigest()
with binary.open('rb')as f:binary_sha=hashlib.file_digest(f,'sha256').hexdigest()
report={'state':str(state),'state_unchanged':checks==snapshots,'state_sha256_before':snapshots,'state_sha256_after':checks,'binary':str(binary),'binary_sha256':binary_sha,'runs':rows,'scope':'Read-only reload of already generated explicit-process GL04 state; no graph import or regeneration, same numerical point and event flag. Compare additional-weight toggle and plain inspect before JSON inspect.'}
(base/'manifest.json').write_text(json.dumps(report,indent=2)+'\n')
assert report['state_unchanged']

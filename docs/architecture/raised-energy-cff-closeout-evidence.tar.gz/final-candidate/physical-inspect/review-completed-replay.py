#!/usr/bin/env python3
"""Independently review completed v2 physical replay; no CLI/test/build/jj execution.

This is a newly prepared reviewer. The initial review was performed by bounded
read/hash invocations and manual inspection; it had no standalone script.
The harness is never imported. Native structural multisets preserve every value,
duplicate event multiplicity and group membership without fixing traversal order.
"""
import argparse
from collections import Counter
import copy
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import re
import shlex
import subprocess

ROOT = Path('/tmp/raised-stack/closeout/gl00-certificate-v2')
HERE = ROOT / 'physical-inspect'
DATA = HERE / 'final-c7'
PREP = ROOT / 'validation-prep'
REPO = Path('/common/dev/gammaloop/higher-power-energies-review')
ANSI = re.compile(r'\x1b\[[0-?]*[ -/]*[@-~]')
OBSERVED = {}
COMMANDS = []


def read(path):
    assert path.is_relative_to(ROOT) and not path.is_symlink()
    assert path != Path('/tmp/raised-stack/run')
    before = path.stat()
    value = path.read_bytes()
    after = path.stat()
    assert (before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns) == (after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns)
    assert path not in OBSERVED or OBSERVED[path] == value
    OBSERVED[path] = value
    return value


def load(path):
    return json.loads(read(path))


def sha(path):
    return hashlib.sha256(read(path)).hexdigest()


def file_sha(path):
    assert path.is_file() and not path.is_symlink()
    before = path.stat()
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    after = path.stat()
    assert (before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns) == (after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns)
    return digest


def structural(value):
    if isinstance(value, dict):
        return ('object', frozenset((key, structural(item)) for key, item in value.items()))
    if isinstance(value, list):
        return ('array', tuple(structural(item) for item in value))
    if type(value) in (int, float):
        assert math.isfinite(value)
        return ('number', value)
    return (type(value).__name__, value)


def document_view(value, omit_weights):
    value = copy.deepcopy(value)
    groups = value['evaluation'].pop('event_groups')
    encoded_groups = []
    for group in groups:
        if omit_weights:
            for event in group:
                del event['additional_weights']
        events = Counter(structural(event) for event in group)
        encoded_groups.append(frozenset(events.items()))
    return structural(value), Counter(encoded_groups)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--revision', required=True)
    parser.add_argument('--tree', required=True)
    args = parser.parse_args()
    revision, tree = args.revision, args.tree
    assert all(re.fullmatch('[0-9a-f]{40}', x) for x in [revision, tree])
    outputs = [ROOT / ('independent-physical-replay-review.' + suffix) for suffix in ['json', 'md']]
    assert not any(path.exists() for path in outputs), 'Never replace completed review evidence'
    runtime = load(ROOT / 'runtime-candidate.json')
    inputs = load(ROOT / 'validation-inputs.json')
    assert runtime['revision'] == revision and runtime['tree'] == tree and inputs['status'] == 'PASS'
    assert sha(ROOT / 'reconstructed-candidate.json') == inputs['candidate_sha256']
    assert sha(ROOT / 'amendment.json') == inputs['amendment_sha256']
    manifest = load(DATA / 'manifest.json')
    original = load(HERE / 'inputs/original-manifest.json')
    build = load(ROOT / 'frozen-cli-build-receipt.json')
    assert manifest['status'] == 'passed' and manifest['revision'] == build['revision'] == revision and build['tree'] == tree
    assert build['build_exit'] == 0 and build['source_and_copy_equal']
    command = ['git', '-C', str(REPO), 'ls-tree', '-rz', '--full-tree', revision]
    COMMANDS.append(command)
    inventory = subprocess.check_output(command, env={**os.environ, 'GIT_OPTIONAL_LOCKS': '0'})
    inventory_sha = hashlib.sha256(inventory).hexdigest()
    entries = len([entry for entry in inventory.split(b'\0') if entry])
    command = ['git', '-C', str(REPO), 'rev-parse', revision + '^{tree}']
    COMMANDS.append(command)
    assert subprocess.check_output(command, env={**os.environ, 'GIT_OPTIONAL_LOCKS': '0'}).decode().strip() == tree
    audits = []
    for relative, workspaces in [('boundary-7/pre-gates-tracked-audit.json', 1), ('boundary-7/post-gates-tracked-audit.json', 1), ('pre-final-runtime-tracked-audit.json', 2)]:
        path = PREP / relative
        audit = load(path)
        assert audit['status'] == 'PASS' and audit['all_match'] and audit['revision'] == revision and audit['tree'] == tree
        assert audit['expected_tracked_entries'] == entries and audit['expected_inventory_sha256'] == inventory_sha
        assert len(audit['workspaces']) == workspaces
        for workspace in audit['workspaces']:
            assert workspace['all_match'] and not workspace['mismatches'] and workspace['inventory_digest_matches']
            assert workspace['entries_matching'] == workspace['blobs_hashed'] == workspace['tracked_entries'] == entries
            assert workspace['observed_inventory_sha256'] == inventory_sha
        audits.append({'path': str(path), 'sha256': sha(path), 'entries_matching_per_workspace': entries, 'workspaces': workspaces})
    boundary = PREP / 'boundary-7'
    assert read(boundary / 'revision').decode().strip() == read(boundary / 'actual-head-after').decode().strip() == revision
    assert read(boundary / 'tree').decode().strip() == tree
    assert int(read(boundary / 'build.exit')) == 0
    assert build['build_command'] == read(boundary / 'build.command').decode()
    argv = shlex.split(build['build_command'])
    assert argv == ['cargo', 'build', '--workspace', '--all-targets', '--locked', '--profile', 'dev-optim']
    assert build['build_log_sha256'] == sha(boundary / 'build.log')
    assert build['pre_runtime_source_audit_sha256'] == sha(PREP / 'pre-final-runtime-tracked-audit.json')
    build_guard = [json.loads(line) for line in read(boundary / 'build.watchdog.jsonl').splitlines() if line]
    starts = [row for row in build_guard if row['event'] == 'start']
    finishes = [row for row in build_guard if row['event'] == 'complete']
    assert len(starts) == len(finishes) == 1 and starts[0]['command'] == argv and finishes[0]['returncode'] == 0
    assert starts[0]['tree_limit_bytes'] == 30_000_000_000 and starts[0]['memory_metric'] == 'rss'
    binary = ROOT / 'bin/gammaloop-final'
    assert build['frozen_binary'] == manifest['binary'] == str(binary)
    binary_sha = file_sha(binary)
    assert binary_sha == build['binary_sha256'] == manifest['binary_sha256_before'] == manifest['binary_sha256_after']
    assert manifest['binary_unchanged'] and manifest['state_unchanged'] and manifest['same_state_as_original_reproducer']
    state = Path(manifest['state'])
    assert state == Path(original['state']) and not state.is_symlink()
    expected_state = original['state_sha256_before']
    assert len(expected_state) == 14 and manifest['state_sha256_before'] == manifest['state_sha256_after'] == expected_state
    assert {str(path.relative_to(state)) for path in state.rglob('*') if path.is_file()} == set(expected_state)
    current_state = {}
    for name in expected_state:
        relative = Path(name)
        assert not relative.is_absolute() and '..' not in relative.parts
        current_state[name] = file_sha(state / relative)
    assert current_state == expected_state
    for name, expected in manifest['input_and_runner_sha256'].items():
        relative = Path(name)
        assert not relative.is_absolute() and '..' not in relative.parts
        assert sha(HERE / relative) == expected
    assert set(manifest['input_and_runner_sha256']) == {'inputs/original-manifest.json', 'inputs/original-weights-false.json', 'inputs/original-reproducer.py', 'replay.py', 'run.sh', 'ram_watchdog.py'}
    resources = manifest['resources']
    assert all(resources[key] == value for key, value in {'outer_memory_limit_gb': 8, 'outer_timeout_seconds': 90, 'cli_timeout_seconds': 40, 'cli_kill_grace_seconds': 5, 'concurrent_cli_processes': 2, 'rayon_threads_per_cli': 2, 'cpu_affinity': [8, 9, 10, 11], 'retries': 0, 'snapshot_updates': 'disabled'}.items())
    outer = shlex.split(read(DATA / 'invocation.command').decode())
    expected_outer = ['/tmp/raised-stack/run', 'env', 'INSTA_UPDATE=no', 'RAYON_NUM_THREADS=2', '/tmp/raised-stack/python', str(HERE / 'ram_watchdog.py'), '--limit-gb', '8', '--log', str(DATA / 'watchdog.jsonl'), '--', 'timeout', '--signal=TERM', '--kill-after=5', '90', 'taskset', '-c', '8-11', '/tmp/raised-stack/python', str(HERE / 'replay.py'), '--binary', str(binary), '--revision', revision, '--output', str(DATA)]
    assert outer == expected_outer
    guard = [json.loads(line) for line in read(DATA / 'watchdog.jsonl').splitlines() if line]
    starts = [row for row in guard if row['event'] == 'start']; finishes = [row for row in guard if row['event'] == 'complete']
    assert len(starts) == len(finishes) == 1 and guard[-1] == finishes[0]
    assert starts[0]['command'] == outer[outer.index('--') + 1:] and starts[0]['tree_limit_bytes'] == 8_000_000_000 and starts[0]['memory_metric'] == 'rss' and finishes[0]['returncode'] == 0
    read(DATA / 'driver.log')
    assert len(manifest['runs']) == 2 and {row['weights'] for row in manifest['runs']} == {False, True}
    payloads = {'original': load(HERE / 'inputs/original-weights-false.json')}
    logs = {}
    for row in manifest['runs']:
        label = 'weights-' + str(row['weights']).lower(); folder = DATA / label
        assert row['exit_code'] == 0 and row['events'] is True and row['json_exists']
        assert row['cwd'] == str(folder) and row['log'] == str(folder / 'run.log') and row['json_path'] == str(folder / 'sample.json')
        point = 'inspect -p core_audit -i numerator -x 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9'
        statements = ['set process -p core_audit -i numerator kv general.generate_events=true general.store_additional_weights_in_event=' + str(row['weights']).lower(), point, point + ' --json-output ' + str(folder / 'sample.json')]
        assert row['statements'] == statements
        assert row['command'] == ['timeout', '--signal=TERM', '--kill-after=5', '40', str(binary), '--read-only-state', '-n', '-s', str(state), 'run', '-c', '; '.join(statements)]
        assert row['environment_overrides'] == {'GL_LOGFILE_FILTER': 'off', 'GL_DISPLAY_FILTER': 'info', 'INSTA_UPDATE': 'no', 'RAYON_NUM_THREADS': '2'} and row['environment_unset'] == ['GL_ALL_LOG_FILTER']
        payloads[label] = load(folder / 'sample.json')
        text = ANSI.sub('', read(folder / 'run.log').decode())
        assert text.count('Running command inspect ') == 2 and text.count('Wrote inspect JSON output to ') == 1
        assert sum(line == 'Evaluation result' for line in text.splitlines()) == 2
        logs[label] = {'text': text, 'inspect_commands': 2, 'json_write_confirmations': 1, 'evaluation_summaries': 2}
    views = copy.deepcopy(payloads); masks = {}; conversions = []; weights_payload = []
    for label, document in views.items():
        metadata = document['evaluation']['evaluation_metadata']; masks[label] = {}
        for name in ['total_timing', 'integrand_evaluation_time', 'evaluator_evaluation_time', 'parameterization_time', 'event_processing_time']:
            masks[label]['evaluation.evaluation_metadata.' + name] = metadata.pop(name)
        for index, stability in enumerate(metadata['stability_results']):
            masks[label][f'evaluation.evaluation_metadata.stability_results[{index}].total_time'] = stability.pop('total_time')
        assert all(set(value) == {'secs', 'nanos'} and all(type(number) is int and number >= 0 for number in value.values()) for value in masks[label].values())
        for gi, group in enumerate(document['evaluation']['event_groups']):
            for ei, event in enumerate(group):
                location = f'evaluation.event_groups[{gi}][{ei}].additional_weights.weights'
                assert set(event['additional_weights']) == {'weights'}
                weights = event['additional_weights']['weights']
                if label == 'original':
                    assert weights == {}; event['additional_weights']['weights'] = []
                    conversions.append({'path': location, 'from': {}, 'to': []})
                elif label == 'weights-false':
                    assert weights == []
                else:
                    assert isinstance(weights, list) and weights
                    keys = []
                    for pair in weights:
                        assert isinstance(pair, list) and len(pair) == 2
                        key, value = pair
                        if isinstance(key, str):
                            assert key in {'Original', 'FullMultiplicativeFactor'}
                        else:
                            assert isinstance(key, dict) and len(key) == 1
                            variant, fields = next(iter(key.items()))
                            contracts = {'ThresholdCounterterm': {'subset_index'}, 'AmplitudeThresholdCounterterm': {'esurface_id', 'overlap_group'}}
                            assert variant in contracts and set(fields) == contracts[variant]
                            assert all(type(number) is int and number >= 0 for number in fields.values())
                        keys.append(structural(key))
                        assert isinstance(value, dict) and set(value) == {'re', 'im'} and all(type(number) in (float, int) and math.isfinite(number) for number in value.values())
                    assert len(set(keys)) == len(keys)
                    weights_payload.append({'path': location, 'cut_info': event['cut_info'], 'complete_pairs': weights})
    assert document_view(views['original'], False) == document_view(views['weights-false'], False)
    assert document_view(views['weights-false'], True) == document_view(views['weights-true'], True)
    threshold_count = sum(isinstance(key, dict) and 'ThresholdCounterterm' in key for event in weights_payload for key, value in event['complete_pairs'])
    assert threshold_count > 0
    assert masks == manifest['excluded_timing_fields'] and conversions == manifest['empty_weight_encoding_normalizations'] and weights_payload == manifest['enabled_additional_weights']
    evaluation = payloads['original']['evaluation']
    expected = {'integrand result': list(evaluation['integrand_result'][key] for key in ['re', 'im']), 'parameterization jacobian': [evaluation['parameterization_jacobian']], 'integrator weight': [evaluation['integrator_weight']], 'event groups': [len(evaluation['event_groups'])], 'generated events': [evaluation['evaluation_metadata']['generated_event_count']], 'accepted events': [evaluation['evaluation_metadata']['accepted_event_count']]}
    for row in manifest['runs']:
        label = 'weights-' + str(row['weights']).lower(); found = {key: [] for key in expected}
        for line in logs[label].pop('text').splitlines():
            fields = [field.strip() for field in line.split('│')]
            if len(fields) >= 3 and fields[1] in found:
                found[fields[1]].append([float(number.rstrip('i')) for number in fields[2].split()])
        assert all(found[key] == [value, value] for key, value in expected.items())
        assert row['plain_and_json_display_matches_original'] and found == row['plain_and_json_displayed_values']
        logs[label]['displayed_values'] = found
    assert all(manifest['comparison_results'][key] is True for key in ['disabled_matches_retained_success', 'toggle_preserves_all_non_additional_weight_content', 'enabled_additional_weights_complete_and_well_formed', 'structured_threshold_counterterm_exercised'])
    for path, data in OBSERVED.items():
        assert path.read_bytes() == data, 'Evidence changed during independent observation'
    receipt = {'schema_version': 1, 'reviewer': 'independent subagent closeout_validation_plan', 'recorded_at_utc': datetime.now(timezone.utc).isoformat(), 'status': 'PASS', 'runtime_revision': revision, 'runtime_tree': tree, 'binary_sha256': binary_sha,
        'scope': 'Independent read/hash and structural multiset review of completed v2 replay. No CLI, test, Cargo, collector or jj execution. The new checker imports no harness code.',
        'source_audits': audits, 'source_and_frozen_binary_link': 'Exact build command, successful guarded exit, build-log and source-audit hashes, immutable Git inventory, and current frozen binary SHA agree.',
        'observed_calls': {'processes': 2, 'inspect_calls': 4, 'exit_codes': [row['exit_code'] for row in manifest['runs']], 'logs': logs},
        'payload_comparisons': {'original_disabled_vs_new_disabled': 'PASS after only declared timing and original empty-map encoding masks', 'new_disabled_vs_enabled': 'PASS for every non-additional-weight field', 'event_group_count': len(evaluation['event_groups']), 'events_per_group': [len(group) for group in evaluation['event_groups']], 'method': 'Counter of recursively immutable complete event records inside a Counter of complete groups; native parsed numeric equality, no tolerance, traversal-order constraint or harness import.', 'excluded_timing_fields': masks, 'empty_encoding_conversions': conversions, 'toggle_only_omission': 'event.additional_weights', 'numeric_result': evaluation['integrand_result'], 'parameterization_jacobian': evaluation['parameterization_jacobian'], 'additional_weight_pairs': sum(len(row['complete_pairs']) for row in weights_payload), 'structured_threshold_counterterms': threshold_count, 'complete_emitted_weight_payload': weights_payload},
        'preservation': {'state_files': len(current_state), 'all_original_pre_post_and_fresh_hashes_equal': True, 'binary_build_pre_post_and_fresh_hashes_equal': True, 'state_sha256': current_state},
        'resources': {'observed_guard_exit': 0, 'recorded_tree_limit_bytes': starts[0]['tree_limit_bytes'], 'guard_elapsed_seconds': finishes[0]['elapsed_s'], 'sampled_peak_tree_bytes': finishes[0]['peak_tree_bytes'], **resources},
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), 'read_only_commands': COMMANDS, 'open_findings': [],
        'limitations': ['One retained generated GL04 state and point; no independently derived physical value or expected physical weight-key set.', 'No fresh-generation, integration, performance or full-suite completion claim.', 'Before/after/fresh hashes are bounded observations, not proof of no temporary changes. RSS is sampled.', 'This standalone reviewer was newly prepared for v2; no prior script execution is implied.'],
        'inputs': [{'path': str(path), 'archive_member': 'final-candidate/' + str(path.relative_to(ROOT)), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()} for path, data in sorted(OBSERVED.items())]}
    with outputs[0].open('x') as stream:
        json.dump(receipt, stream, indent=2); stream.write('\n')
    note = f"Independent physical replay review: PASS at `{revision}` / tree `{tree}`. Two exit-zero processes performed four inspections. Complete non-additional-weight JSON agrees under the declared timing and empty-encoding masks; group membership and duplicate multiplicity are preserved. {receipt['payload_comparisons']['additional_weight_pairs']} emitted pairs include {threshold_count} structured threshold keys. The frozen binary and all {len(current_state)} saved-state hashes match their build/original/pre/post receipts. This is one-point serialization/retention evidence, with no independent physics, generation or performance claim. No CLI, Cargo, tests or jj command was executed by this reviewer.\n"
    with outputs[1].open('x') as stream:
        stream.write(note)
    print(json.dumps({'status': 'PASS', 'revision': revision, 'review': str(outputs[0]), 'sha256': hashlib.sha256(outputs[0].read_bytes()).hexdigest()}))


if __name__ == '__main__':
    main()

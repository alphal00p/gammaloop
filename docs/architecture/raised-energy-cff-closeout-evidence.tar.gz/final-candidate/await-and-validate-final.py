#!/usr/bin/env python3
"""Wait for exact functional completion, then start the pinned final v2 driver.

Prepared only. Invoke directly without an outer licensed wrapper. Existing
runtime/functional records remain untouched; this writes separate watcher state.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess
import time

ROOT = Path('/tmp/raised-stack/closeout/gl00-certificate-v2')
PREP = ROOT / 'validation-prep'
PINS = {
    'runtime-candidate.json': '6b7b4556c202c305e43241e682eb459ce533fc03c3cc48efb26624d6ffc56e86',
    'reconstructed-candidate.json': '7b18a59891d084875c7c0843a3bfe5714ce239d3ed51c10f785039c054cbccf7',
    'amendment.json': '1609514078a49453593d452dc381b6eac0a2c50a0400c24020f48dcbd3a7c897',
    'validation-inputs.json': 'b9740c1a68baaeef17cfe860b927ea7766d65cfa93bf9044adab6dd79c5a76a1',
    'validate-functional-stack.py': 'de6ce4456ada1c03c28e3aba3db921514e457cc4d5cad9ecb4d614764732a609',
    'validate-final-stack.py': 'c3a998b7af734619ce192f9726ed651bf59ea7a8c5d4873fae0e7bba93e10651',
}
SUCCESS = 'V2 C3-C6 validation complete; C1/C2 retained by identical revisions'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--functional-pid', required=True, type=int)
    parser.add_argument('--functional-log', required=True, type=Path)
    args = parser.parse_args()
    assert args.functional_pid > 1
    log = args.functional_log.resolve()
    assert log == ROOT / 'functional-driver-resumed.log'
    output = ROOT / 'final-watcher.json'
    assert not output.exists() and not (PREP / 'boundary-7').exists()
    pinned = {}
    for name, expected in PINS.items():
        path = ROOT / name; data = path.read_bytes()
        assert hashlib.sha256(data).hexdigest() == expected, 'Pinned watcher input differs: ' + name
        pinned[path] = data
    runtime = json.loads(pinned[ROOT / 'runtime-candidate.json'])
    inputs = json.loads(pinned[ROOT / 'validation-inputs.json'])
    assert runtime['revision'] == '9e260684581ab2893eff4032c5ca8ea1fc2c18cb'
    assert runtime['tree'] == '9cebc793fe813699b9d689f1ab245715902ac04e'
    assert inputs['status'] == 'PASS'
    process = Path('/proc') / str(args.functional_pid)
    command = [part.decode() for part in (process / 'cmdline').read_bytes().split(b'\0') if part]
    expected_command = ['/tmp/raised-stack/python', str(ROOT / 'validate-functional-stack.py'), '--candidate-sha256', PINS['reconstructed-candidate.json'], '--amendment-sha256', PINS['amendment.json'], '--verified-inputs-sha256', PINS['validation-inputs.json']]
    assert command == expected_command
    start = (process / 'stat').read_text().rsplit(') ', 1)[1].split()[19]
    receipt = {'schema_version': 1, 'status': 'WAITING', 'started_utc': datetime.now(timezone.utc).isoformat(), 'runtime': runtime, 'functional_pid': args.functional_pid, 'functional_start_ticks': start, 'functional_argv': command, 'pins': PINS, 'scope': 'Wait for complete passing six-boundary collector, final functional success marker and termination of the exact pinned process. Its app-session exit code remains separate evidence because this watcher is not its parent.'}
    with output.open('x') as stream:
        json.dump(receipt, stream, indent=2); stream.write('\n')
    try:
        print('Waiting for completed v2 C3-C6 collector and functional process termination', flush=True)
        while True:
            for path, data in pinned.items():
                assert path.read_bytes() == data, 'Pinned watcher prerequisite changed'
            for number in range(3, 7):
                for path in (PREP / f'boundary-{number}').rglob('*.exit'):
                    data = path.read_text().strip()
                    if data:
                        assert data == '0', 'Functional failure recorded: ' + str(path)
            try:
                stat = (process / 'stat').read_text().rsplit(') ', 1)[1].split()
                alive = stat[0] != 'Z' and stat[19] == start
            except FileNotFoundError:
                alive = False
            if not alive:
                complete = PREP / 'boundary-evidence-through6.json'
                assert complete.exists(), 'Functional process stopped without completed six-boundary evidence'
                data = complete.read_bytes(); collector = json.loads(data)
                rows = collector['boundaries']
                assert [row['boundary'] for row in rows] == list(range(1, 7))
                assert [row['declared_revision'] for row in rows] == [row['commit'] for row in inputs['first_six']]
                assert all(row['status'] == 'completed' and row['all_recorded_required_jobs_pass'] for row in rows)
                progress_data = (ROOT / 'functional-stack-progress.json').read_bytes()
                progress = json.loads(progress_data)
                assert progress['completed_boundaries'] == inputs['first_six']
                assert progress['unchanged_revision_receipts_reused'] == [1, 2] and progress['fresh_completed_boundaries'] == [3, 4, 5, 6]
                log_data = log.read_bytes()
                assert log_data.decode().splitlines()[-1] == SUCCESS, 'Functional process lacks final successful completion marker'
                receipt['functional_completion'] = {'all_six_certificates_complete_and_pass': True, 'final_success_marker_observed': True, 'exact_process_terminated': True, 'app_session_exit_code': 'not observed by non-parent watcher; retain separate app session receipt', 'collector_sha256': hashlib.sha256(data).hexdigest(), 'progress_sha256': hashlib.sha256(progress_data).hexdigest(), 'log_sha256': hashlib.sha256(log_data).hexdigest()}
                break
            time.sleep(3)
        receipt['status'] = 'STARTING_FINAL_DRIVER'
        argv = ['/tmp/raised-stack/python', str(ROOT / 'validate-final-stack.py'), runtime['revision']]
        receipt['final_driver_argv'] = argv
        output.write_text(json.dumps(receipt, indent=2) + '\n')
        print('Six-boundary certificates complete; starting pinned final runtime ' + runtime['revision'], flush=True)
        result = subprocess.run(argv, check=False)
        receipt['final_driver_exit'] = result.returncode
        receipt['status'] = 'PASS' if result.returncode == 0 else 'FAIL'
        assert result.returncode == 0, 'Final driver failed; raw results preserved'
    except Exception as error:
        receipt['status'] = 'FAIL'; receipt['error'] = f'{type(error).__name__}: {error}'
        raise
    finally:
        receipt['updated_utc'] = datetime.now(timezone.utc).isoformat()
        output.write_text(json.dumps(receipt, indent=2) + '\n')


if __name__ == '__main__':
    main()

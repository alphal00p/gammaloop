import json
import pathlib
import subprocess

OUT = pathlib.Path('/tmp/cff-change-audit')
WORK = OUT / 'inventory'
ROOT = pathlib.Path('/common/dev/gammaloop/higher-power-energies-review')
rows = []


def add(id, owner, change, sources, kind, evidence, example, next_action, tests=''):
    rows.append(dict(id=id, owner=owner, change=change, sources=sources.split(),
                     motivation_kind=kind, evidence=evidence, example=example,
                     missing_action=next_action, existing_regression=tests))


add('C2-01', 2, 'Shared generalized CFF engine and selectable representation',
    '8a3512ed 939af81f 481a4301', 'new capability',
    'New crate in commit 2; README and current exact-source architecture; current contour tests. No prior equivalent whole crate exists at main.',
    'Repeated propagator powers and bounded energy numerators, including lower/contact sectors, joined/disconnected components and residual tree denominators.',
    'Feature motivation is established by the requested raised-energy scope. Benchmark comparable old supported cases and final generalized cases separately; unsupported main inputs are not an old wrong-result bug.',
    'three-dimensional-reps eval.rs repeated_cubic_pole_with_squared_denominator_numerator_pinches_to_simple_pole; lower_sector_powered_pole_contact_reconstructs_numerator_derivatives; independent_bubbles_bounded_maps_match_component_cff_product')
add('C2-02', 2, 'Retain independent repeated propagator occurrences',
    'ac99d32d', 'requested optimization / representation change',
    'Source ac99d32d explicitly requests independent degenerate edges and records aggregate GL16/166-case results; not an isolated repeated-occurrence benchmark.',
    'Independent repeated channels retain separate rank capacities and residue entries; complete mapped contours must agree after summation.',
    'Run identical captured CFF input with old merging and new independent occurrences; record native rows, total generation time/memory and complete contour values. Physical numerator with repeated denominators plus a scalar high-rank control is appropriate.',
    'three-dimensional-reps eval.rs repeated_quintic_rank_eight_denominator_pinches_match_lower_channels; terminal_duplicate_contact_sign_is_routing_and_order_invariant')
add('C2-03', 2, 'Stream component products and shorten intermediate lifetimes',
    'd3dd17d9 7b0b09ed', 'observed memory problem; remedy not isolated',
    'Source d3dd17d9: prior GL16 hit actual 30 GB process-tree guard; lazy completed Cartesian layers introduced, individual benefit explicitly unmeasured. 7b0b09ed adds lazy per-parent fanout/owned branches and early release.',
    'Lower-sector products previously retained complete Cartesian intermediate layers and duplicated momentum maps.',
    'A/B the captured multi-component high-rank source, keeping all other caching/compaction unchanged; memory and wall time both matter. Final GL16 completion cannot apportion benefit to this change.')
add('C2-04', 2, 'Reuse exact bases and compact completed products',
    'e4f5f778', 'observed memory problem; limited prototype measurement',
    'Source e4f5f778: captured 12-edge/two-loop prototype completed in 617.75 s with 14.48 GB peak; three complete fixtures byte-identical with optimization off/on. No completed baseline time is given there.',
    'Repeated plain/direct CFF bases are regenerated; completed equal chains increase retained output.',
    'Recover baseline and prototype artifact if possible, then controlled cache-only/compaction-only A/B on the same captured source and smaller routine cases. Compare mathematical outputs, not historical byte identity alone.')
add('C2-05', 2, 'Correct shared terminal/embedded contour normalization',
    'e30d799e 9c8aa0f9', 'recorded wrong-value failure and passing correction',
    'docs/architecture/raised-energy-cff-implementation.md:34-43 records unchanged depth-three banana exposing component-frame versus advertised core-loop convention; unchanged depth-two/depth-three test passes after correction.',
    'An ordinary terminal embedded in a larger UV construction has the wrong sign even though the standalone route supplies the correct prefactor.',
    'Extract/replay the documented minimal embedded/standalone joined/disconnected contour counterexample; no performance justification is necessary for the sign fix.',
    'Independent two-loop contour and unchanged depth-two/depth-three banana; complete signed contours in shared generation/eval and core CFF tests')
add('C2-06', 2, 'Correct diagnostic numerator arithmetic',
    '9c8aa0f9', 'recorded public-API old-fail / fixed-pass',
    'docs/architecture/raised-energy-cff-review.md finding 4 records a compiled public evaluate_expression reproduction; implementation.md finding 4 records corrected contract.',
    'Old -2**2 = 4; 2**3**2 = 64; 2**4294967296 = 1. Correct -4 / 512 / checked error.',
    'Fresh old/new public evaluator replay is cheap and appropriate; physical graph timing does not motivate parser precedence.',
    'crates/three-dimensional-reps/src/eval.rs:1259 evaluates_integer_powers_with_arithmetic_precedence')
add('C2-07', 2, 'Validate bounds before fast paths and reject malformed graph signatures',
    '9c8aa0f9', 'recorded public-API failures and passing correction',
    'review.md findings 10/11: public preserved one-edge zero-loop graph accepts unknown bound 999; public malformed signature [1] with declared zero loops panics. implementation.md records structured rejection.',
    'Invalid edge bounds must not pass because preserved/tree/rational output returns early; malformed dimensions must return invalid GraphValidation.',
    'Fresh minimal invalid-input replay on source before review and current library, retaining error contracts. Inputs are deliberately malformed, not physical benchmark cases.',
    'validator.rs:213 rejects_malformed_signature_dimensions; generation input-bound regressions')
add('C2-08', 2, 'Additional input arithmetic/shape validation',
    '9c8aa0f9 reconstructed-review', 'source-level failure analysis and current regression',
    'Embedded shared review and core reconciliation records: widen momentum residual accumulation, checked bounds/conversions; eval shape/scale/power validation. No recorded old process execution for every rejection branch.',
    'Shape mismatches, zero normalization scale, integer overflow and invalid maps should reject at the public boundary.',
    'Replay focused boundary cases on old implementation where compatible. Do not label all defensive checks as observed physics bugs.',
    'eval.rs:1080 evaluation_rejects_input_shape_zero_scale_and_oversized_power; source momentum and energy-degree overflow regressions')
add('C2-09', 2, 'Rational coefficient storage across shared engine and consumers',
    'ce6654cc', 'domain modeling / simplification',
    'Source ce6654cc and implementation report: stores coefficients as Rational, converts at Atom/Arb output boundaries. Previous rational-valued Atoms were already exact.',
    'Exclude arbitrary symbolic values from coefficient storage; make arithmetic domain explicit.',
    'No old numerical inexactness bug is claimed. Benchmark identical CFF input for coefficient arithmetic/allocation if a performance benefit is asserted; otherwise justify by type invariant and smaller API.')
add('C2-10', 2, 'Shared expression assembly, surface copying and builder consolidation',
    '9c8aa0f9', 'maintenance / KISS',
    'implementation.md Rust-pattern section: existing surface interner becomes owned ExpressionAssembler reused by three builders, removing duplicated insertion/finalization.',
    'One owner for expression surface copying, interning, variant insertion and numerator-label finalization.',
    'No standalone bug or speedup established. Assess deletion/duplication reduction and whole-value parity; microbenchmark only if this changes a hot path.')

add('C2-11', 2, 'Preserve zero values for filtered and infinite denominator trees',
    'reconstructed-review', 'source-traced numeric/symbolic contract mismatch',
    'Embedded review-c6e0ff0ffae8 records numeric panic on filtered empty trees, approximately 1e80 for the Infinite inverse marker, and fusion traversal of an absent root; the symbolic API already defined these as zero.',
    'Filter every denominator branch, or evaluate an Infinite denominator marker: complete value must be zero before and after variant fusion.',
    'Fresh public zero-value evaluation and fusion replay; retain distinction from ordinary exactly-zero linear surfaces, whose separate 1e-80 convention was not changed.',
    'empty_and_infinite_denominator_trees_evaluate_to_zero; fusion_preserves_zero_from_a_filtered_denominator_tree')

add('C3-01', 3, 'Integrate shared raised-energy CFF into GammaLoop and evaluator persistence',
    '939af81f 481a4301 2bbc6f59 d54de204', 'feature integration / required callers',
    'Source-to-owner mapping and complete commit 3 CFF review: core adapters, public surfaces, energy assignments and evaluator migration are consumers of the new shared engine.',
    'Raised cuts/numerator cancellation and repeated equal/split model masses reach generation, runtime selection and saved exports.',
    'Use physical raised denominator input and scalar repeated-mass oracle. Old missing capability and necessary caller migrations do not each need a separate invented bug.',
    'tests/tests/test_runs/repeated_masses.rs; graph fixtures raised_cut_numerator_cancellation.dot and repeated_bubble_*')
add('C3-02', 3, 'Exact owner-preserving local-4D UV source reconstruction',
    '181f77af 5c3e7fca d54de204 e30d799e', 'recorded reconstruction discrepancy / mathematical certificate',
    'exact-powered-denominator-cff-lifting.md:428/522 worked GL04 T0 and 1zs/T2, full reconstruction certificate at :664; source commits identify provenance reconstruction fix.',
    'GL04 retained owner-5/owner-6 A^2 B^3 denominator multiset and owner-local temporal numerator. Reassignment by denominator incidence or common LMB can corrupt numerator owners/signs.',
    'Use live GL04 source capture and exact complete numerator/denominator certificate to isolate old and current first differing boundary. Do not infer a CFF recursion defect from a reconstruction mismatch.',
    'three_d_source.rs GL04 production certificate; exact_source_preserves_the_complete_cubic_propagator_contour; owner relabeling/cancellation/sign/domain regressions')
add('C3-03', 3, 'Typed direct/local/projected UV routes and explicit selector-free sums',
    'c8e76317 d54de204 ac99d32d 9c8aa0f9', 'architecture / requested feature / cleanup',
    'Source ac99d32d explicitly requests clean direct/projected assembly and removal of deferred state. Current architecture defines different complete routes; review reports Result/enum ownership and complete selector truth-table oracles.',
    'Direct per-residue subtraction versus complete projected residue sum; normalized localization kernels remain frozen; projection chart/frame values travel together.',
    'Benchmark supported routes on identical graph/settings and verify complete cut values. Route API cleanup itself has no separate old wrong-value reproducer; assess removed stale state and invariant ownership.')
add('C3-04', 3, 'Owner-specific integrated UV mass scaling',
    '9c8aa0f9', 'recorded physical wrong-value failure and corrected pass',
    'implementation.md:45-65: strict GL04 discrepancy, identical captures and 90-330 digit replay isolate one finite integrated-localizer coefficient; GL00/disjoint controls reject global rescaling.',
    'Scale tagged mUV(owner) only when Taylor subgraph contains that owner; freeze disjoint owner and localization kernel, reject partial overlap.',
    'Retain GL04 enclosing plus GL00/disjoint/nested controls and independent untouched-baseline two-loop renormalization oracle. These are the motivating correctness cases, not a performance claim.')
add('C3-05', 3, 'Keep natural Taylor denominator topologies and factorized numerator ownership',
    '8a197b8c 5c8b46f3 26b57b78', 'observed generation/resource problem plus ownership contract',
    '8a197b8c removes common-denominator collection; exact-powered-denominator-cff-lifting.md:874 onwards explains Taylor topology requirement. Original source request demands general correction starting GL16. Later source fixes collect denominator branches only before incidence fusion.',
    'Forcing different Taylor terms onto one denominator inflates powers/ranks; extracting numerator factors into topology can misassign physical incidence. GL24 quartic DOD1 is a representative owner/rank certificate.',
    'A/B actual Taylor pipeline and output source rows on GL24/GL16 plus physical graph; measure generation/memory without changing numerator algebra. Separate correctness of incidence from performance of natural topologies.',
    'term_projection_preserves_complete_factorized_values; GL24 quartic actual Taylor and nested_vacuum_denominators_preserve_incidence_and_factorized_numerators')
add('C3-06', 3, 'Factorized degree analysis and independent outer rank envelopes',
    'e30d799e 5a5a1bfc ac99d32d', 'observed slow/resource stage; no isolated final A/B',
    'e30d799e user specifically identifies slow rank-envelope analysis; 5a5a1bfc avoids tagged symbolic sum and analyzes identical branch bodies once. No per-intervention measured speedup in source bodies.',
    'Analyze independent branches and combine per-edge maximum rather than expanding numerator or building a large tagged sum solely for capacity.',
    'Time identical retained branch inputs old/new, record temporary memory and exact bounds; include high-rank physical numerator and small scalar controls. Never expand a production graph numerator as a diagnostic.')
add('C3-07', 3, 'Bound exact-CFF cache keys to each request capacity',
    '0ad34794', 'observed GL16 memory limit; design/resource contract',
    'Source 0ad34794: unioning independent terms creates unnecessarily large Cartesian degree envelope; request capacity included in cache key. Prior GL16 exceeds guard; no isolated A/B in commit description.',
    'Cache reuse must retain immutable assignment and requested capacity instead of accumulating unrelated maximal degrees.',
    'Measure retained bytes/generation time under a sequence of realistic distinct capacity requests, with cached/uncached complete-value equality; cache entry counts alone are not a correctness oracle.')
add('C3-08', 3, 'Choose up to three certified derivative-energy assignments by generated map size',
    'ac99d32d', 'explicit optimization request; aggregate measurement only',
    'ac99d32d instructions: actual residue-map size is figure of merit; rank only proxy. Recorded GL16 total improves4.23% while projected setup worsens13.96%, across combined optimizations.',
    'Different derivative-generated hard/soft energy dispatches can produce different native source-map sizes; original numerator owners never move.',
    'Compare all retained certified proposals and old assignment on exact physical source captures, measuring proposal-generation overhead plus selected downstream work; smaller rows are not automatically lower time/memory.',
    'three_d_source candidate certificate matrix; every proposal complete contour tests; exact-source architecture bounded selection sections')
add('C3-09', 3, 'Route child-soft carriers into parent hard chart',
    'ac99d32d', 'recorded physical generation defect',
    'Source ac99d32d explicitly identifies GL08 finite counterterm retaining an unintegrated inner momentum before compatible parent-chart routing.',
    'An energy soft for a child becomes hard for parent UV operation; unconverted chart lets already integrated loop momentum survive.',
    'Recover GL08 smallest retained finite-counterterm pair and rerun old/new with source ownership/denominator certificates. Current scalar matrix pass is corroboration, not a minimal counterexample artifact.')
add('C3-10', 3, 'Resolve symbolic constants before SymJIT compilation',
    '7b0b09ed', 'recorded minimal wrong-value failure',
    'Source7b0b09ed explicitly records pi^-3 -> infinity in unresolved rational program and correct finite result from mapped numeric evaluator; finite pi/pi^-3 regression.',
    'Compile SymJIT from mapped numeric evaluator so registered constants have values.',
    'Fresh pi and inverse-pi public/backend replay is sufficient; no physical speed benchmark required.',
    'crates/gammalooprs/src/integrands/process/evaluators.rs finite pi/pi^-3 JIT regression')
add('C3-11', 3, 'Validate source integer arithmetic and raised residue selections',
    'reconstructed-review', 'static concrete failure cases and current tests',
    'Embedded core reconciliation report: unchecked energy cap arithmetic, i32 transient signature overflow, empty raised-group indexing, zero powers and unknown surface IDs; checked Result migration and focused regressions.',
    'Preserve large transient cancellations in i64 while rejecting unrepresentable output; reject malformed raised groups before indexing.',
    'Fresh old/new boundary probes, especially release overflow behavior. No prior physical input demonstrating these limits is claimed.',
    'overflowing_polynomial_degrees_return_an_error; exact_momentum_signatures_reject_overflow_and_preserve_cancellation; select_indexed_cff_residues malformed-group tests')
add('C3-12', 3, 'Uniform nonzero M evaluator parameter and finalized expression ownership',
    'e30d799e ac99d32d', 'explicit KISS/API choice',
    'e30d799e user requests always adding M to evaluator inputs; source architecture retains frozen localizers and zero finalized sectors. No isolated measured overhead/benefit.',
    'Avoid conditional parameter inventory and keep auxiliary deformation mass distinct from UV owner masses; zero sectors are normalized at producer.',
    'Verify public evaluation and error contract for nonzero/zero M. Justify uniform input by simpler API; no rounding/performance bug should be invented.')

add('C4-01', 4, 'Command templates and invocation scope',
    'bb60b02f 49999ca0 9c8aa0f9', 'new capability plus reproduced scope bugs',
    'review.md findings1/2 run through real CLI: nested inline missing variable and boot-card nested parameterized block exit1, equivalent control exits0; implementation.md records inner overrides/inheritance.',
    'Parameterized reusable blocks need definition-time name/cycle validation and invocation-time variable expansion.',
    'Fresh CLI old/new commands with nested -D overrides and boot definitions. No physical contraction benchmark applies.',
    'commands/run.rs, session.rs and tests/tests/test_cli.rs scoped/nested run tests')
add('C4-02', 4, 'Explicit output, state detection/versioning and history persistence',
    '0ee54199 b58d1ef0 ac99d32d 9c8aa0f9', 'capability/policy plus reproduced state-write defect',
    'review.md finding3 real scalar-box 3Drep build followed by quit-n writes inside unsaved state. ac99d32d increments format5->6 because generated fields change. Embedded API review records manifest/error restoration boundaries.',
    'Scratch folders are blank state; only explicit save writes state; incompatible manifests fail before bincode decode; saved block text retains templates.',
    'Replay scalar-box unsaved/read-only state outputs and saved/reloaded evaluated functions. Version/caller changes are necessary integration, not individual perf optimizations.')
add('C4-03', 4, '3D representation build/validate/export CLI',
    'cf36d272 481a4301 2bbc6f59', 'new public workflow',
    'Source descriptions and test_3d_reps complete public exported-function/load comparisons; shared graph state is the input.',
    'Build exact CFF independent of full integrand generation and inspect/export complete expression.',
    'Use physical graph when measuring export/build overhead, but feature is motivated by inspectability and source captures; supported public results and persistence are its acceptance.')
add('C4-04', 4, 'Benchmark command, timing reports and temporary minimal evaluation settings',
    'a4ea80a9 9c8aa0f9', 'new observability workflow / test improvement',
    'Embedded API review: complete benchmark values and settings restored after success and output error; wall timing separates evaluator and inclusive integrand. No old production settings-loss reproducer is claimed.',
    'Warmup estimates sample count, retains batch, evaluates benchmark, emits report and restores settings.',
    'Execute same process before/after benchmark including deliberate output failure. Long duration can allocate large batch; benchmark resource bound not established. Physical input useful for observer-overhead measurement.')
add('C4-05', 4, 'UV profiling and stable finite-range numerical reports',
    'bd513be5 d54de204 9c8aa0f9 reconstructed-review', 'capability plus reporting/validation defects',
    'review.md finding12 Arb median bound underflows to <0.0e0; core reconciliation records finite exponents generating0/inf scales, ray norm overflow and nonfinite samples getting vanishing-fit exemption.',
    'Keep log exponent through display; normalize fixed rays by max component; use hypot and reject nonfinite/unrepresentable data while retaining graph/cut identity.',
    'Fresh focused extreme-value probes and one physical UV-profile flow. Source-level edge cases are concrete, but old execution not recorded for every branch.',
    'profile_rejects_unrepresentable_scale_ranges; fixed_uv_ray_rejects_invalid_input_shapes; pass_fail_display_lists_multiple_failures_with_context; Arb median display tests')
add('C4-06', 4, 'Numerical-stability histograms, dashboard and integration checkpoint outputs',
    'a4ea80a9 b58d1ef0 d54de204', 'workflow/observable feature and caller integration',
    'Complete commit4 evaluation/workflow reviews:19 evaluation hunks add precision-specific histogram/median statistics,2 observable hunks add weighted-median lookup; integration emits latest/global/per-slot JSON/HWU and optional completed-iteration archives. No independent physics bug claim.',
    'Retain raw batch statistics before sample consumption; interrupted iteration emits a user-facing preview without advancing authoritative completed-iteration checkpoint. Missing/old manifest versions reject incompatible positional decoding.',
    'Run public batch histogram, partition/merge/persistence and successful/interrupted integration-output comparisons. Measure optional reporting overhead on representative batches only if a performance claim is made.')
add('C4-07', 4, 'Resource-aware test execution, Nix inputs and tracing',
    '0ad34794 1b760f63 c1a839f5 32f27225', 'observed build/resource failures and explicit tooling policy',
    '0ad34794: macOS physical footprint guards owned tree including compression/swap; source1b760f63 selected-profile resource override; c1a839f5 includes numerical CFF eval feature in isolated Nix test inputs. Review mapping includes fixture compile inputs and minimum nextest.',
    'Guard realistic concurrent process memory; include compile-time fixtures/features; exclude manual PySecDec integrals while retaining pure Rust adapters.',
    'Platform-specific old/new resource measurement needs owning OS, not Linux timing extrapolation. Verify selected inventories/profile behavior, negative missing-fixture case and suppressed-log payload behavior.')
add('C4-08', 4, 'Behavioral numerical tests and archive unconsumed scalar snapshots',
    '9c8aa0f9 reconstructed-review', 'reproduced test false positives / requested outward tests',
    'review.md findings5/6/7/8/9: factor-two discrepancy1e-18 vs2e-18 accepted; NaN/inf failure predicate can pass; 198 snapshots unread; GL04 denominator certificate compared handwritten expressions.',
    'Require finite affirmative complete-value agreement, correct tiny-value sensitivity, derive denominators from production, avoid private caches/layouts/host order.',
    'Run exact old/new assertion predicate counterexamples and current mathematical oracles. Tests improve detection, not production values; no performance benchmark needed. Existing user approvals cover noted test corrections.')
add('C4-09', 4, 'Remove obsolete wrapped model and migrate examples/metadata',
    '5c8b46f3 b58d1ef0', 'cleanup / required consumer migration',
    'Embedded phase review semantically audits deleted sm_wrapped_indices.json:72couplings/119vertices versus live108/153, no remaining non-document references. Examples, schemas and lockfiles follow owners.',
    'Drop unused stale asset and expose supported current commands/options.',
    'No independent physics bug or timing benefit claimed. Validate references, schema defaults and executable example flows; source-path attribution is not proof every migration hunk is independent behavior.')

add('C4-10', 4, 'Preserve precise stability digits before f64 narrowing and report inclusive bounds',
    'reconstructed-review', 'source-traced concrete reporting defects and current boundary regressions',
    'Embedded review-821e0731fba3.txt: nonzero Arb1e-400 narrows to0 before histogram, falsely reporting bound1e-1000; overflow is x>=xmax and hence must display <= rather than <. Production trace plus Python Decimal illustration, not old Rust runtime failure.',
    'Compute -log10(abs(relative_error)) in active precision before narrowing, export optional decimal digits through all consumers. Exact overflow boundary must be inclusive.',
    'Fresh old/current precise-to-output probes at400/700digits and exact Double/Quad/Arb upper endpoints. No physical performance motivation is needed for mathematically correct reporting.',
    'precise_stability_reporting_preserves_underflowed_estimates; numerical_stability_overflow_includes_exact_upper_boundary')
add('C4-11', 4, 'Process import/reference contracts and named-integrand provenance',
    'b58d1ef0 ac99d32d reconstructed-review', 'workflow feature / input validation and invariant ownership',
    'Embedded complete API review: checked signed/unsigned ProcessRef conversions, import specification/name/append policy, explicit versus inferred process kind agreement, existing definition mismatch rejected before append, generated siblings shared provenance protected.',
    'Commands importing graphs or generating one named integrand must preserve process identity and later source-export provenance; invalid references reject before mutation.',
    'Replay public import/append/overwrite/mismatched-process and named-integrand export flows; no old execution proving every guard needed is recorded. These are concrete supported API contracts, not contraction speedups.')

add('C5-01', 5, 'Physical amplitude/LU and threshold phase normalization',
    'dd134b71', 'mathematical wrong-sign/phase counterexamples; recorded failures',
    'phase-conventions.md gives scalar graph i^L(-1)^P, RHS component marking and cut residue factors; PHASE_CONVENTIONS_FIX.md:347/352 records targeted passing amplitudes and pending/failing triangle sign then :374 complete corrected signed tests.',
    'Uncut1-4loop scalar integrals, Born2-6body phase space, above-threshold bubble discontinuity and left/right virtual triangle mirrors distinguish phase independently of absolute values.',
    'Replay smallest independent signed scalar/mirror oracle against old and new normalization. No speedup is needed to justify correct physical conventions.',
    'tests/test_runs/amplitude_phase_conventions.rs; scalar_phase_conventions.rs; scalar_virtual_phase_conventions.rs; four signed ddx/ttx LO/NLO acceptances')
add('C5-02', 5, 'Inverse-process sewing, complex couplings and explicit CP opt-in',
    'dd134b71 5c8b46f3', 'independent mathematical counterexamples / supported-model contract',
    'phase-conventions.md:41 onward explicit Weyl matrices: charged scalar correct norm21 versus0 after second adjoint; complex charged current105 versus-63+84i. User explicitly retains CP optimization with warning.',
    'Raw RHS vertex already carries Hermitian-partner coupling/spin structure; a second adjoint is wrong. CP whole-side identification is optional user assumption.',
    'Use charged scalar and complex CKM matrix tests, not gluon double triangle alone (real couplings can hide bug). Distinguish proposed double-adjoint counterexample from any actual main-path old failure.',
    'generated_charged_scalar_forward_vertex_is_already_the_hermitian_partner; generated_complex_charged_current_preserves_the_ckm_norm')
add('C5-03', 5, 'Consistent W/Z virtual propagators, covariant cut multiplets and physical event labels',
    '5c8b46f3 26b57b78', 'physical model consistency requirement with independent oracle',
    'PHASE_CONVENTIONS_FIX.md:456 complete generated H->WW/ZZ sums agree with three-polarization norm at rest/boost; sm-conventions-audit.md records Ward/action audit and multiplet contract.',
    'Feynman-gauge virtual tensors need matching Goldstone/ghost cut states; requesting only vector cuts fails physical polarization equivalence. Ghost statistics and displayed events must match physical multiplet.',
    'Run full covariant/physical polarization and Ward oracle on old/current model settings. This electroweak bug cannot be certified by QCD-only double triangle.',
    'generated_sm_virtual_vector_and_goldstone_exchange_matches_unitary_current; generated_higgs_covariant_cuts_equal_three_physical_vector_polarizations')
add('C5-04', 5, 'Reject unsupported complex masses/custom pole rules and use ghost anticommutation',
    'dd134b71 5c8b46f3', 'supported-domain correctness / source-level counterexamples',
    'phase-conventions.md model contract: current code constructs real energies and standard denominators; mass/propagator checks reject incompatible used rules. Phase review identifies common anticommuting predicate for ghost loops/exchange.',
    'Silently dropping custom denominator terms or treating ghosts as commuting yields wrong physics; current model values must be checked again after update.',
    'Fresh used-versus-unused denominator, complex-mass update and ghost loop/exchange probes. Width metadata alone remains allowed. No complete arbitrary Hermiticity validator is claimed.')
add('C5-05', 5, 'Feyngen accepted-numerator lookup optimization',
    '26b57b78', 'observed user slowdown; limited one-sided timing and correctness A/B',
    'PHASE_CONVENTIONS_FIX.md:517 source quadratic scan/global mutex; :539/:558 exact pre/post public API parity4smallSM cases; :566 50,000-record last-match82.237ms sign/322.749ms scalar, explicitly one-sided.',
    'Early sample-ratio rejection, cached zero masks after symbolic matching, per-topology atomic locks and removal of redundant clones.',
    'Benchmark identical accepted classes/candidates old/new for first/last/no match, multiple buckets and1/Nworkers; then realistic many-diagram process generation. One fixed double-triangle does not exercise50k-class lookup.',
    'diagram_generator/lookup_tests.rs; numerator_grouping_preserves_values_across_worker_counts')
add('C5-06', 5, 'Retain fixed-momentum internal bridges during initial-state subtraction',
    'reconstructed-review', 'fresh reconstructed-stack inherited bug old-fail/fixed-pass',
    'Embedded confirmed-initial-state-bridge-cause.md: one-worker/no-grouping GL3 fails; old helper identical in main/originalphase. Gluon bridge8 has neither endpoint on initial cut, yet sink3 removed and both cut-side ranks become0.',
    'Full XS bases{2,5},{2,6},{3,5},{3,6}; cut{5,6} loses node3 and halfedges{2,5,15}, selector requests only{6}.',
    'Use preserved CLI/public API GL3 capture and worker grouping regression; this is a specific physical graph bug, suitable alongside requested quark-loop bridge topology.',
    'get_initial_state_tree callers; numerator_grouping_preserves_values_across_worker_counts')

add('C6-01', 6, 'Projected tensor kernels/scalar coefficient preservation and whole-numerator alternative',
    '5c8b46f3 26b57b78 32f27225', 'architecture plus explicit alternate-mode request; benefit unmeasured',
    'PHASE_CONVENTIONS_FIX.md:653 explicitly says initial split came from overly broad no-expansion interpretation. User clarified analytic UV numerator expansion is permitted/desired, then explicitly requested whole-numerator mode;32f27225 records this.',
    'Projected route factors scalar spectators from universal tensor integration; monolithic route passes complete analytic numerator. Both require identical dimensional closure/Laurent handling.',
    'Benchmark both modes on genuine analytic quark-loop UV subgraph and representative scalar/high-rank tensors, verify full Laurent values. Do not justify projected machinery by claiming analytic expansion remains forbidden.',
    'whole_numerator_and_projected_analytic_backends_have_identical_laurent_coefficients; whole_numerator_and_tensor_projection_preserve_structured_open_slots')
add('C6-02', 6, 'Complete d-dimensional Dirac/metric closure before Laurent truncation',
    '32f27225', 'identified missing algebra boundary with independent exact oracle',
    'PHASE_CONVENTIONS_FIX.md:625-630: angular projection can contract formerly open spin tensors; old return path specializes remaining slots to4D after scalar order selection. integrated.rs independent single/double-pole and scalar-master tests.',
    'A factor proportional to epsilon multiplied by UV1/epsilon contributes a finite term; projection-induced gamma contractions must resolve in d=4-2epsilon first.',
    'Replay explicit projected Dirac numerator with scalar master before/after old boundary. Physical quark-loop UV is appropriate, plus exact toy identity that reveals finite evanescent contribution.',
    'projected_dirac_algebra_precedes_single_and_double_pole_expansion; projected_dirac_numerator_matches_scalar_master_before_backend_truncation')
add('C6-03', 6, 'Account for coefficient/normalization epsilon poles and reject insufficient depth',
    '26b57b78 32f27225', 'concrete mathematical order-budget defect',
    'PHASE_CONVENTIONS_FIX.md:655 identifies custom normalization poles applied after backend truncation; coefficient and normalization pole orders must add. Tests24/167/240 in analytic backend suite give independent Laurent oracles.',
    'Truncated master times1/epsilon or1/epsilon^2 loses finite terms; high-rank1/(4-2epsilon) factors and evanescence must be restored before truncation.',
    'Fresh exact scalar masters with single/double normalization and numerator poles old/new. Preserve conservative requested depth; do not tune based on positive valuations contrary to user request.',
    'analytic_backends_preserve_coefficients_and_epsilon_pole_orders; analytic_backends_account_for_normalization_and_nested_coefficient_poles; analytic_backends_reject_unavailable_epsilon_depth')
add('C6-04', 6, 'Validate Lorentz domains, opaque tensor slots and scoped gamma5 errors',
    '26b57b78 32f27225', 'recorded ddx boundary failure plus deliberate unsupported-domain guard',
    'PHASE_CONVENTIONS_FIX.md:554 odd-open tensor could project to zero before validation; :585 ddx canonical gamma(mu)*k(mu) dummy renaming misclassified free slots.32f27225 requires gamma5 rejection before cancellation within analytic subgraph only.',
    'Malformed/unsupported tensor algebra must not silently vanish; valid gamma metadata survives projection; unrelated cograph gamma5 is outside integration scope.',
    'Replay malformed odd-open and actual ddx trace plus exact gamma5 scope matrix. Gamma5 rejection is explicit unsupported-feature handling, not proof old model had a physical counterexample.',
    'analytic_uv_spin_algebra_rejects_unsupported_residual_contractions; residual_tensor_contractions_are_checked_per_analytic_branch; Vakint lorentz tests')
add('C6-05', 6, 'Remove exactly-zero factorized scalar coefficient subtrees',
    '26b57b78', 'recorded physical generation failures and fixed passing matrix',
    'PHASE_CONVENTIONS_FIX.md:608 GL29 fails after146passes; :613 GL35/38/40/46 fail; :614 identifies2*(-A-B)+2*(-B-C)+2*A+4*B+2*C; :617 focused33pass; :620 full166pass.',
    'Exactly-zero projected coefficients survive AST grouping and create spurious outer CFF energy bounds. Bottom-up exact-zero certificates retain nonzero factorized spectators.',
    'Replay captured scalar coefficient zeros and one failing graph source on old/current accumulator. Test zero mathematical value, not private maps or collector cycles; maintain factorization contract for nonzero spectators.',
    'crates/vakint/src/projection.rs scalar coefficient cancellation tests; GL29/35/38/40/46 scalar LU cases')
add('C6-06', 6, 'Canonical backend serialization and post-restoration notation',
    '26b57b78 32f27225', 'recorded backend input/output corruption',
    'PHASE_CONVENTIONS_FIX.md:585 external dots restored after output notation leak; :687 (1+2i)*(a+b)*tensor serialized as(a+b)*1+2*i_*tensor changing precedence; :689 display callback corrupts canonical identifiers; :715 FORM rejects decimalcomplex tokens.',
    'Serialize AST with complete symbol identity and parentheses, convert finite floats losslessly at FORM boundary; apply requested dot notation after coefficient restoration.',
    'Replay retained FORM serialization inputs and output notation old/new. Pure Rust adapter tests cover encoding; physical PySecDec integration remains manual-only.',
    'tensor_reduction_preserves_symbolica_user_namespaces; dot_conversion_*; backend serialization/adapter tests in vakint lib.rs/utils.rs')
add('C6-07', 6, 'Preserve signed numerical momenta, complex parameters and combined estimator',
    '26b57b78', 'source-level sign loss / statistical contract plus manual validation',
    'Embedded Vakint review records real external component sign loss corrected to signed real part, nonreal component error, transactional settings. PHASE history records four explicit fast PySecDec checks and common-estimator change.',
    'Negative external momentum components must remain negative; complex numerator coefficients differ from real pole masses; uncertainty belongs to sum of sectors.',
    'Fresh pure Rust signed parameter/invalid-update and serialized coefficient tests; manual backend integration only if explicitly included by parent. One-sided manual historical passes are not current automatic coverage.')
add('C6-08', 6, 'Normalize completed analytic return before reinsertion and migrate forest owners',
    '32f27225', 'recorded sunrise boundary mismatch / required complete migration',
    'PHASE_CONVENTIONS_FIX.md:705/707 direct two-loop sunrise integrated node differs, other6outputs equal; exact analytic expansion proves identity; :709 both-owner/both-mode focused111pass.',
    'Completed analytic subgraph must have cancellations resolved before Laurent projection and cograph reinsertion; both forest owners and MUV settings use full API.',
    'Replay exact captured sunrise pair and both modes/owners. This is expression-normalization boundary, not proof the old fully simplified mathematical integral differed.',
    'tests/tests/uv.rs scalar finite/pole both-owner/both-mode regressions; integrated.rs complete return path')

add('C7-01', 7, 'Current reports, Typst/PDF and durable source/validation provenance',
    '3906e661 6b9c51b9 6f9e41de 9c8aa0f9 ce6654cc reconstructed-review', 'explicit documentation/review request',
    'Current report and source mapping; raw historical evidence retained with date/revision qualifications. Current final functional tree unchanged by report-only rewrite.',
    'Account for seven owners, all changed paths, actual commands/tests and coverage limitations; separate current report from archived evidence.',
    'Update current motivation/measurement report from fresh audit, compile Typst and inspect PDF. Documentation has no physical performance motivation.')


commits = {
    2: '0b902a939e522b9adf0819bf19dc49e5bea33e3c',
    3: '4dd826961066c958b19233a80455fc97be5623f8',
    4: '76639bb7184868baf9b6ef4e16d64a96f8abab91',
    5: '4781595eb235774f5e85d20607a89a108339ce59',
    6: '1a7470398d25ad0bacc224a46783ddc165484e93',
    7: 'd55a0f3e9d25e5c64bdb9ef9fb57749ecf680390',
}


def classify(n, p):
    # These are logical ownership links, deliberately many-to-many for mixed files.
    if n == 2:
        if p.endswith('generation.rs') or p.endswith('cff_recursion.rs'):
            return ['C2-01', 'C2-02', 'C2-03', 'C2-04', 'C2-05', 'C2-07', 'C2-09', 'C2-10']
        if p.endswith('eval.rs'):
            return ['C2-01', 'C2-05', 'C2-06', 'C2-08', 'C2-09', 'C2-11']
        if p.endswith('validator.rs') or p.endswith('graph_signatures.rs') or p.endswith('energy_bounds.rs'):
            return ['C2-07', 'C2-08']
        if any(p.endswith(x) for x in ('expression.rs', 'surface.rs', 'tree.rs')):
            return ['C2-01', 'C2-09', 'C2-10', 'C2-11']
        return ['C2-01']
    if n == 3:
        if p.endswith('three_d_source.rs'):
            return ['C3-02', 'C3-06', 'C3-07', 'C3-08', 'C3-11']
        if p.endswith('energy_degree.rs'):
            return ['C3-06', 'C3-11']
        if p.endswith('evaluators.rs'):
            return ['C3-01', 'C3-10', 'C3-12']
        if '/uv/approx/direct_3d/' in p:
            return ['C3-03', 'C3-04', 'C3-05', 'C3-09']
        if '/uv/' in p:
            return ['C3-02', 'C3-03', 'C3-04', 'C3-05', 'C3-09', 'C3-12']
        if '/cff/' in p:
            return ['C3-01', 'C3-03', 'C3-07', 'C3-11']
        if '/numerator/' in p:
            return ['C3-01', 'C3-06']
        if '/graphs/' in p or p.endswith('CONTRIBUTING.md') or '/architecture/' in p:
            return ['C3-01', 'C3-02', 'C3-03', 'C3-04', 'C3-05']
        return ['C3-01']
    if n == 4:
        if '/historical/scalar_3l_inspects/' in p or p.endswith('scalar_3L_cross_section_inspects.rs'):
            return ['C4-08']
        if p.endswith('sm_wrapped_indices.json') or p.startswith('examples/'):
            return ['C4-09']
        if any(x in p for x in ('command_template.rs', 'command_parser.rs', '/commands/run.rs', 'session.rs', 'repl.rs')):
            return ['C4-01', 'C4-02']
        if '/commands/threedreps/' in p or p.endswith('test_3d_reps.rs'):
            return ['C4-02', 'C4-03']
        if p.endswith('bench.rs'):
            return ['C4-04']
        if p.endswith('profile.rs'):
            return ['C4-05']
        if p.endswith('state.rs') or p.endswith('cli.rs') or p.endswith('test_cli.rs'):
            return ['C4-01', 'C4-02', 'C4-03', 'C4-04', 'C4-11']
        if p.endswith('evaluation.rs'):
            return ['C4-05', 'C4-06', 'C4-10']
        if '/integrate/' in p or '/observables/' in p or '/integrands/' in p or p.endswith('test_evaluation_api.rs') or '/snapshots/' in p:
            return ['C4-06', 'C4-10']
        if any(x in p for x in ('.config/', '.github/', 'tracing.rs', 'justfile', 'flake.nix', 'nix/', 'Cargo.', 'bin/README', '.gitattributes')):
            return ['C4-07']
        if '/commands/' in p or p.endswith('/python.rs') or p.endswith('/lib.rs'):
            return ['C4-01', 'C4-02', 'C4-03', 'C4-04', 'C4-05', 'C4-06', 'C4-10', 'C4-11']
        if '/tests/' in p:
            return ['C4-02', 'C4-03', 'C4-04', 'C4-05', 'C4-06', 'C4-08']
        return ['C4-09']
    if n == 5:
        if '/feyngen/' in p or p.endswith('test_feyngen.rs'):
            return ['C5-02', 'C5-03', 'C5-04', 'C5-05', 'C5-06']
        if '/models/' in p or p.endswith('/model/mod.rs') or p.endswith('/import/model.rs') or p.endswith('gauge_sewing_tests.rs'):
            return ['C5-02', 'C5-03', 'C5-04']
        if '/graph/' in p:
            return ['C5-01', 'C5-04', 'C5-06']
        if p.endswith('sewing_tests.rs'):
            return ['C5-02', 'C5-03']
        if p.endswith('processes/cross_section.rs'):
            return ['C5-01', 'C5-02', 'C5-03', 'C5-04', 'C5-06']
        if p.endswith('/state.rs') or p.endswith('/python.rs') or p.endswith('/commands/generate.rs') or '/schemas/' in p or p.endswith('serde_utils.rs'):
            return ['C5-02', 'C5-03', 'C5-04']
        return ['C5-01']
    if n == 6:
        if p.endswith('projection.rs'):
            return ['C6-01', 'C6-03', 'C6-04', 'C6-05']
        if p.endswith('lorentz.rs'):
            return ['C6-04']
        if p.endswith('integrated.rs') or p.endswith('orchestrator.rs') or p.endswith('local_4d.rs'):
            return ['C6-01', 'C6-02', 'C6-03', 'C6-04', 'C6-08']
        if p.endswith('lib.rs'):
            return ['C6-01', 'C6-03', 'C6-04', 'C6-06', 'C6-07']
        if p.endswith('utils.rs') or p.endswith('symbols.rs') or p.endswith('symbolica_community_module/mod.rs') or p.endswith('tensor_reduction_tests.rs'):
            return ['C6-01', 'C6-04', 'C6-06', 'C6-07']
        if 'pysecdec' in p.lower():
            return ['C6-06', 'C6-07']
        if p.endswith('integral_evaluation_analytic_tests.rs'):
            return ['C6-01', 'C6-02', 'C6-03']
        if p.endswith('matad.rs') or p.endswith('fmft.rs'):
            return ['C6-01', 'C6-03', 'C6-06']
        return ['C6-01', 'C6-08']
    return ['C7-01']


paths = []
for n, commit in commits.items():
    raw = subprocess.check_output(['git', 'diff-tree', '--no-commit-id', '--name-status', '-r', commit], cwd=ROOT, text=True)
    for line in raw.splitlines():
        status, path = line.split('\t', 1)
        categories = classify(n, path)
        paths.append(dict(owner=n, commit=commit, status=status, path=path, logical_changes=categories,
                          coverage_scope='logical ownership category; not a fresh complete changed-hunk causal audit'))

inventory = dict(
    scope='Logical motivation inventory for reconstructed commits 2-7; commit 1 delegated separately.',
    source_tip='d55a0f3e9d25e5c64bdb9ef9fb57749ecf680390',
    evidence_policy='Historical records are explicitly historical. This inventory ran read-only source/history searches and no native tests/benchmarks. Existing current-suite passes establish compatibility/correctness coverage, not old-fail causation or isolated performance benefit.',
    coverage_policy='Every changed path in owners 2-7 maps to at least one logical category. Shared-file mapping is deliberately many-to-many. A mapped path is not proof each changed hunk has a motivating reproducer. Required consumer groups inherit their owner but no per-hunk causal completeness is claimed.',
    logical_change_count=len(rows), commit_path_count=len(paths), distinct_path_count=len({p['path'] for p in paths}),
    changes=rows, paths=paths)
OUT.mkdir(exist_ok=True)
(OUT/'nonfoundation-inventory.json').write_text(json.dumps(inventory,indent=2)+'\n')
text = ['# Change motivation inventory: reconstructed commits 2–7', '',
        f'Pinned source: `{inventory["source_tip"]}`. {len(rows)} logical categories, {len(paths)} commit/path records, {inventory["distinct_path_count"]} distinct paths.', '',
        '**This is an evidence inventory, not a claim that fresh old/new benchmarks have finished.** I inspected local source history, source mapping, current code/test names and durable review evidence; I ran no native test or benchmark in this subtask. Historical failures and measurements below retain their original scope. Parent agent owns fresh experimental work.', '',
        'Every changed path is assigned in `nonfoundation-inventory.json`. That provides a complete path census, not a fresh complete hunk-by-hunk causal review. Mixed files intentionally map to several logical behaviors. Consumer migrations, schemas, fixtures and documentation inherit their owning functional behavior. C4-08 is a cross-stack test-policy category: numerical comparison helpers belong to3, shared-crate tests to2, and matrix/archive consumers to4. It is grouped under4 for readability, without asserting that all hunks landed there.', '',
        'Evidence terms: **recorded failure** means an existing report/source body describes an executed failure; **source-level** means a concrete code counterexample without an old executable observation for every branch; **limited measurement** means exactly the stated workload/count, never a universal speedup; **feature/cleanup** does not imply a prior bug.', '',
        'Most urgent performance gaps: C2-02/03/04, C3-05/06/07/08, C5-05, C6-01. The physical gluon double triangle can exercise tensor/CFF/UV work, but cannot alone discriminate parser scope, electroweak sewing, 50,000-class Feyngen lookup, malformed-input validation, or Laurent truncation; those require the listed representative inputs.', '',
        'Important KISS caveat: the original Vakint projection split was partly motivated by an overly broad reading of the no-expansion rule. `PHASE_CONVENTIONS_FIX.md:653` explicitly acknowledges that analytic UV numerators may expand. The user subsequently requested both input modes. Their equality/correctness is tested; comparative benefit remains to be measured.', '']
for n in range(2,8):
    text += [f'## Commit {n}: `{commits[n][:9]}`', '']
    for r in rows:
        if r['owner'] != n:
            continue
        text += [f'### {r["id"]}: {r["change"]}', '',
                 f'**Motivation:** {r["motivation_kind"]}. **Sources:** '+', '.join('`'+s+'`' for s in r['sources'])+'.', '',
                 r['example'], '', '**Evidence:** '+r['evidence'], '',
                 '**Missing or next action:** '+r['missing_action']]
        if r['existing_regression']:
            text += ['', '**Existing regression:** '+r['existing_regression']]
        text += ['']
text += ['## Path coverage', '',
         'The JSON companion lists every changed path/status/owner and its logical categories. Counts by commit:', '',
         '| Owner | Changed paths | Logical categories |', '| --- | ---: | ---: |']
for n in range(2,8):
    text += [f'| {n} | {sum(p["owner"]==n for p in paths)} | {sum(r["owner"]==n for r in rows)} |']
text += ['', 'All source commit messages consulted are copied as plain text under `/tmp/cff-change-audit/inventory/source-<revision>.txt`; extracted durable review reports and their content-addressed index are under that same directory. No credentials or private license-wrapper content was inspected or copied.', '']
(OUT/'nonfoundation-inventory.md').write_text('\n'.join(text))
print(json.dumps({k:inventory[k] for k in ['logical_change_count','commit_path_count','distinct_path_count']},indent=2))

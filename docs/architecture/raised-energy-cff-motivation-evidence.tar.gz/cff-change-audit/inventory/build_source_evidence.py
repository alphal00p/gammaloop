import hashlib,json,pathlib,subprocess
root=pathlib.Path('/tmp/cff-change-audit');repo=pathlib.Path('/common/dev/gammaloop/higher-power-energies-review');inv=root/'inventory'
sections=[]
# Each selection is restricted to explicit diagnostic passages; setup/environment sections are never copied.
specs=[
('C2-05 / C3-04','9c8aa0f9','docs/architecture/raised-energy-cff-implementation.md','## Additional defects exposed by the stronger tests',33),
('C2-06 / C4-01 / C4-02','6f9e41de','docs/architecture/raised-energy-cff-review.md','1. **[P2]',47),
('C4-08','6f9e41de','docs/architecture/raised-energy-cff-review.md','6. **[P2]',22),
('C2-07','6f9e41de','docs/architecture/raised-energy-cff-review.md','10. **[P3]',28),
('C5-01 / C5-02 / C5-04','dd134b71','PHASE_CONVENTIONS_FIX.md','1. The shared energy representation',12),
('C5-03','26b57b78','PHASE_CONVENTIONS_FIX.md','A model-clone 2×2 control',1),
('C6-05','26b57b78','PHASE_CONVENTIONS_FIX.md','The first full acceptance on the generic index repair',12),
('C6-02 / C6-03','32f27225','PHASE_CONVENTIONS_FIX.md','The goal of this follow-up',5),
('C6-04','26b57b78','PHASE_CONVENTIONS_FIX.md','Pipeline triage isolates two representation boundaries',1),
('C6-06','32f27225','PHASE_CONVENTIONS_FIX.md','A retained-binary FORM diagnostic locates',4),
('C6-02 / C6-03 explicit mathematical counterexample','32f27225','crates/gammalooprs/src/uv/approx/integrated.rs','fn projected_dirac_algebra_precedes_single_and_double_pole_expansion',98),
('C3-11 explicit degree-overflow input','d55a0f3e','crates/gammalooprs/src/numerator/energy_degree.rs','fn overflowing_polynomial_degrees_return_an_error',27),
('C3-11 explicit malformed residue input','d55a0f3e','crates/gammalooprs/src/cff/mod.rs','fn lu_residue_selection_rejects_missing_physical_cut_support',31),
('C3-11 concrete integer boundary','d55a0f3e','crates/gammalooprs/src/graph/three_d_source.rs','fn exact_momentum_signatures_reject_overflow_and_preserve_cancellation',34),
('C6-08','32f27225','PHASE_CONVENTIONS_FIX.md','Sunrise triage locates',3),
('C6-07','32f27225','PHASE_CONVENTIONS_FIX.md','Controlled copied-package tests isolate',1),
]
for ids,rev,path,needle,count in specs:
 try:text=subprocess.check_output(['git','show',f'{rev}:{path}'],cwd=repo,text=True,stderr=subprocess.PIPE)
 except subprocess.CalledProcessError as e:sections.append({'ids':ids,'missing':f'{rev}:{path} unavailable'});continue
 lines=text.splitlines();hits=[i for i,l in enumerate(lines) if needle in l]
 if not hits:sections.append({'ids':ids,'missing':f'Need specific passage in {rev}:{path} ({needle})'});continue
 i=hits[0]; excerpt='\n'.join(lines[i:i+count]);sections.append({'ids':ids,'source':f'{rev}:{path}','start_line':i+1,'end_line':min(i+count,len(lines)),'sha256_source':hashlib.sha256(text.encode()).hexdigest(),'excerpt':excerpt,'strength':'Retained original source record; historical outcomes are not fresh runs.'})
for ids,file,start,count in [
 ('C3-02','source-e30d799e.txt',1,24),('C3-09','source-ac99d32d.txt',1,17),('C3-10','source-7b0b09ed.txt',1,9),
 ('C2-08','review-22917944fa8c.txt',13,10),
 ('C3-11','review-0481a87a264c.txt',66,1),('C2-08 / C2-11','review-c6e0ff0ffae8.txt',7,4),
 ('C4-10','review-821e0731fba3.txt',16,15),
 ('C5-06','review-d24e62e4db05.txt',1,12),
]:
 p=inv/file;t=p.read_text();l=t.splitlines();sections.append({'ids':ids,'source':str(p),'start_line':start,'end_line':min(start+count-1,len(l)),'sha256_source':hashlib.sha256(t.encode()).hexdigest(),'excerpt':'\n'.join(l[start-1:start+count-1]),'strength':'Original embedded independent review or original commit body; current inventory does not reclassify static findings as old runtime observations.'})
(root/'nonfoundation-source-evidence.json').write_text(json.dumps(sections,indent=2)+'\n')
out=['# Concrete source evidence for nonfoundation motivations','', 'This companion preserves selected exact diagnostic passages from pinned source history and embedded review artifacts. It deliberately excludes setup/environment sections. Historical test counts describe the recorded source checkpoint; they do not certify current reconstructed code. Fresh CFF replay evidence will be stored separately. Feature requests, type-domain cleanup, and required caller migrations are not relabeled as bugs.','']
for s in sections:
 out += ['## '+s['ids'],'']
 if 'missing'in s:out += [s['missing'],''];continue
 out += [f"Source `{s['source']}`, lines {s['start_line']}–{s['end_line']}. SHA-256 `{s['sha256_source']}`.",s['strength'],'','```text',s['excerpt'],'```','']
(root/'nonfoundation-source-evidence.md').write_text('\n'.join(out)+'\n')
print('Sections',len(sections),'missing',sum('missing'in s for s in sections))
for s in sections:
 if 'missing'in s:print(s)

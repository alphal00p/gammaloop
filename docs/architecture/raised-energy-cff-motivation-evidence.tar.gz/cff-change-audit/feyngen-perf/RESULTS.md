The physical comparator experiment completes 28 CLI observations: four excluded warmups and six interleaved rounds of old/current sign/scalar comparison. Every observation returns the same complete 36-model-rule graph export as the validated default. Candidate-pair keys are unique, and every repeated complete result agrees between modes.

Each observation exercises 12 rejecting physical pairs, each repeated 20 times. All pairs have five numerical samples, five polynomial samples, and no canonical numerator. The comparison graph consists of 12 disjoint size-two components; together with 36 retained candidates and the source's within-topology lookup this identifies 12 two-candidate topology buckets and 12 singleton buckets. No long bucket scan is exercised. The small SM control separately validates one accepted pair with 50,000 repetitions in each of four old/current sign/scalar configurations; those are calibration observations.

| Comparator | Old median per call | Current median per call | Paired old/current ratio, median [range] |
|---|---:|---:|---:|
| Sign | 2.510 ms | 0.355 ms | 7.074 [6.875, 7.349] |
| Scalar rescaling | 172.269 ms | 171.988 ms | 0.9986 [0.9841, 1.0094] |

The body interval includes black-box arguments/results and result-vector pushes. Allocation, the reference call, assertions over every retained result, and audit emission occur outside the interval. Repeated closure calls omit per-method tracing-span entry. Ordinary comparison DEBUG payloads remain disabled by metadata-aware filtering; the source proof is retained. The body driver uses one CPU, one worker, the coordinated measurement lock, and fixed 180-second/8 GB caps.

Current precedes old in four of six sign rounds and five of six scalar rounds. The original balanced description was inaccurate; the actual interleaved schedule and all observations are preserved. This limits inference about small differences. The sign path has a large repeatable measured difference on these rejecting pairs; no scalar-rescaling benefit is established. Body-harness CLI medians include the artificial repetitions (sign old/current 67.22/66.63 seconds, scalar 110.34/110.10 seconds) and cannot quantify normal generation improvement.

The unsuccessful 5,000-repetition physical calibration remains reported: the first old-scalar case reaches 180 seconds without a complete comparison audit or graph export. The separately declared 20-repetition experiment retains the same physical input, comparison bodies, oracles and caps. No numerical result is claimed for the incomplete calibration. From the completed experiment's first pair, approximately 0.174 seconds per scalar comparison would imply approximately 870 seconds for 5,000 repetitions of that pair if costs scale similarly; this is an inference explaining the calibration limit, not an observation of the stopped instruction.

Primary receipts are `body-physical-20-balanced/manifest.json`, `summary.json`, `pair-coverage.json`, `default-binary-parity.json` and `schedule-correction.json`. The exact loaded driver is preserved as `run_balanced_timings.before-independent-failures.py`; the final descriptive metadata update preserves the hash of all raw observation records.

The independent E2E experiment completes one warmup and two exact forward/reverse rounds per 16 variants (48 successful observations), with old/current comparator and global-serialization interventions at one/four workers. Its small sample supports descriptive wall/stage ranges and complete-output checks. It cannot establish the motivating long-bucket benefit. The frozen execution driver and premeasurement design are recorded in `e2e-executed-driver-provenance.json` and `e2e-prospective-design-revision.json`.

Both E2E worker-pool settings (one and four workers) use the same allowed CPUs 8–11. The separate comparator-body experiment uses CPU 8. Worker count and CPU affinity are recorded independently in the actual commands.


All 48 E2E observations finish successfully:16 excluded warmups and 32 measured runs, with no omissions or retries. The final verification freshly rehashes all 1,728 DOT files and checks every complete 36-file map against both its recorded hashes and the independently validated physical default. It also verifies unique observation keys, exact reversed measured orders, common 8–11 affinity, worker pools 1/4, and unchanged frozen driver/binary hashes. The normal-generation repetition hook is unset.

These are descriptive ranges from two observations per variant. The grouping interval includes physical numerator preparation, comparison and combination. The input has no long topology bucket; the small sample does not establish an overall-generation or global-lock performance benefit.

| Grouping | Workers | Execution mode | CLI wall range (s) | Preparation/grouping range (s) |
|---|---:|---|---:|---:|
| sign | 1 | current | 66.002–66.507 | 65.864–66.370 |
| sign | 1 | old-comparator | 66.206–67.265 | 66.070–67.127 |
| sign | 1 | global-lock | 66.208–66.614 | 66.069–66.477 |
| sign | 1 | both | 66.516–66.776 | 66.378–66.638 |
| sign | 4 | current | 19.048–20.435 | 18.909–20.300 |
| sign | 4 | old-comparator | 18.634–18.810 | 18.494–18.676 |
| sign | 4 | global-lock | 18.146–18.170 | 18.013–18.031 |
| sign | 4 | both | 17.737–18.867 | 17.602–18.729 |
| scalar | 1 | current | 68.633–68.913 | 68.496–68.775 |
| scalar | 1 | old-comparator | 68.789–68.800 | 68.652–68.664 |
| scalar | 1 | global-lock | 68.526–69.190 | 68.387–69.057 |
| scalar | 1 | both | 69.236–69.276 | 69.100–69.138 |
| scalar | 4 | current | 19.641–19.725 | 19.506–19.591 |
| scalar | 4 | old-comparator | 18.622–18.761 | 18.488–18.628 |
| scalar | 4 | global-lock | 18.560–18.595 | 18.426–18.460 |
| scalar | 4 | both | 19.005–19.526 | 18.872–19.392 |

Paired old-comparator/current wall ratios, given descriptively as median [range] across the two rounds: sign/1worker 1.0073 [0.9955, 1.0191]; sign/4worker 0.9494 [0.9205, 0.9783]; scalar/1worker 1.0003 [0.9982, 1.0024]; scalar/4worker 0.9496 [0.9482, 0.9511]. These numerical ratios carry no speedup or statistical-significance claim. All global-lock and combined-mode ratios are retained in the final JSON summary.

Authoritative E2E receipts: `e2e-physical-two-rounds/manifest.json`, `summary.json`, and `final-artifact-verification.json`. The exact executed driver is `run_e2e_two_rounds.executed.py` (SHA256 `4d2d332649da701a05aa5cec5afab3e5bf4d2f163c09ddc41fe42c2cbb17a697`); the frozen CLI SHA256 is `f36be7c30c794c41da987aa8ccabf1a0d5aeef1a66b451af806c46dc40055d44`.

The current four-worker path is slower than every ablation in both measured rounds for both grouping modes (`e2e-physical-two-rounds/four-worker-observation.json`). The sample is small and the cause is unestablished. These observations demonstrate no E2E gain; the isolated sign-comparison improvement does not establish whole-generation benefit.

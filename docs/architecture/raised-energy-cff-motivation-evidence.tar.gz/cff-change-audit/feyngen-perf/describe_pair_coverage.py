"""Describe actually exercised comparator pairs, without inferring unseen buckets."""
import collections
import json
import pathlib
import sys

directory = pathlib.Path(sys.argv[1])
manifest = json.loads((directory / 'manifest.json').read_text())
coverage = {'scope': 'Actual recorded candidate-pair comparisons. Components describe only observed comparisons; singleton topology buckets are not instrumented. Every timed invocation repeats the complete comparator body and asserts the complete result after timing.', 'variants': {}}
for run in manifest['runs']:
    label = run['variant']['id']
    if label in coverage['variants']:
        continue
    records = run['comparison_records']
    adjacency = collections.defaultdict(set)
    for record in records:
        left, right = record['self_id'], record['other_id']
        adjacency[left].add(right)
        adjacency[right].add(left)
    remaining = set(adjacency)
    components = []
    while remaining:
        pending = [min(remaining)]
        component = set()
        while pending:
            vertex = pending.pop()
            if vertex in component:
                continue
            component.add(vertex)
            pending.extend(adjacency[vertex] - component)
        remaining -= component
        pairs = [record for record in records if record['self_id'] in component]
        components.append({'candidate_ids': sorted(component), 'comparisons': len(pairs), 'all_pair_results_reject': all(not record['matching'] for record in pairs), 'complete_unordered_pair_set': len({tuple(sorted((record['self_id'], record['other_id']))) for record in pairs}) == len(component) * (len(component) - 1) // 2})
    signatures = collections.Counter((record['self_samples'], record['other_samples'], record['self_polynomial_samples'], record['other_polynomial_samples'], record['self_canonical'], record['other_canonical']) for record in records)
    coverage['variants'][label] = {
        'reference_round': run['round'],
        'comparison_records': len(records),
        'repeated_body_calls': sum(record['repetitions'] for record in records),
        'matching_pairs': sum(record['matching'] for record in records),
        'rejecting_pairs': sum(not record['matching'] for record in records),
        'input_signatures': [{'self_samples': s[0], 'other_samples': s[1], 'self_polynomial_samples': s[2], 'other_polynomial_samples': s[3], 'self_canonical': s[4], 'other_canonical': s[5], 'pair_count': count} for s, count in signatures.items()],
        'observed_comparison_components': components,
    }
(directory / 'pair-coverage.json').write_text(json.dumps(coverage, indent=2) + '\n')
print(json.dumps(coverage, indent=2))

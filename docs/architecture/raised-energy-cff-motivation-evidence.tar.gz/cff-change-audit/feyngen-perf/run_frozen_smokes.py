import os,json,pathlib,subprocess,hashlib
base=pathlib.Path('/tmp/cff-change-audit/feyngen-perf')
binary=pathlib.Path('/tmp/cff-change-audit/root/bin/gammaloop-audit')
records=[]
for case in json.loads((base/'cards.json').read_text()):
 for mode,flags in [('current',[]),('old-comparator',['CFF_AUDIT_FEYNGEN_OLD_COMPARATOR']),('global-lock',['CFF_AUDIT_FEYNGEN_GLOBAL_LOCK']),('both',['CFF_AUDIT_FEYNGEN_OLD_COMPARATOR','CFF_AUDIT_FEYNGEN_GLOBAL_LOCK'])]:
  name=case['name']+'-'+mode
  env=os.environ.copy()
  for flag in ['CFF_AUDIT_FEYNGEN_OLD_COMPARATOR','CFF_AUDIT_FEYNGEN_GLOBAL_LOCK']:env.pop(flag,None)
  env.update({flag:'1' for flag in flags})
  log=base/(name+'-frozen-smoke.log');graphs=base/(name+'-frozen-graphs')
  cmd=['/tmp/raised-stack/python','bin/ram_watchdog.py','--limit-gb','3','--log',str(base/(name+'-watchdog.jsonl')),'--','/tmp/raised-stack/run',str(binary),'-n','-s',str(base/(name+'-frozen-state')),case['card'],'save','dot',str(graphs)]
  with log.open('w') as out:r=subprocess.run(cmd,env=env,stdout=out,stderr=subprocess.STDOUT,timeout=120)
  files={str(p.relative_to(graphs)):hashlib.sha256(p.read_bytes()).hexdigest() for p in graphs.rglob('*.dot')}
  records.append({'case':case['name'],'mode':mode,'flags':flags,'command':cmd,'exit_code':r.returncode,'dot_sha256':files,'log':str(log),'scope':'Correctness-only smoke while builds active; no timing claim.'})
  (base/'frozen-smokes.json').write_text(json.dumps({'binary':str(binary),'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'runs':records},indent=2)+'\n')
  print(name,r.returncode,len(files),flush=True)
  assert r.returncode==0

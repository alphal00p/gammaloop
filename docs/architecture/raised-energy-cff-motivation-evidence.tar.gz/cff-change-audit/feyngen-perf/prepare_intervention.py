from pathlib import Path
import subprocess,difflib,hashlib,json
root=Path('/common/dev/gammaloop/higher-power-energies-review')
relative='crates/gammalooprs/src/feyngen/diagram_generator.rs'
current=(root/relative).read_text()
old=subprocess.check_output(['git','show','26b57b786^:'+relative],cwd=root,text=True)
patched=current
anchors=[('fn compare_with_sign_only(', '    /// Compare two numerators allowing arbitrary scalar rescaling.'),('fn compare_with_scalar_rescaling(', '    #[instrument(skip_all,fields(graph_name = %graph.name))]')]
for signature,end in anchors:
    a=current.index(signature);b=current.index(end,a);section=current[a:b];body_start=section.index('{');body_end=section.rfind('}')
    oa=old.index(signature);ob=old.index(end,oa);osection=old[oa:ob];obody=osection[osection.index('{')+1:osection.rfind('}')].replace('event_enabled!(', 'tracing::event_enabled!(').replace('Span::current()', 'tracing::Span::current()')
    body=section[body_start+1:body_end]
    replacement=section[:body_start+1]+'\n        if *CFF_AUDIT_FEYNGEN_OLD_COMPARATOR {'+obody+'\n        } else {'+body+'\n        }\n    '+section[body_end:]
    assert patched.count(section)==1
    patched=patched.replace(section,replacement)
flags='''// Scratch benchmark intervention only; no production API or persistent behavior change.
static CFF_AUDIT_FEYNGEN_OLD_COMPARATOR: std::sync::LazyLock<bool> =
    std::sync::LazyLock::new(|| std::env::var_os("CFF_AUDIT_FEYNGEN_OLD_COMPARATOR").is_some());
static CFF_AUDIT_FEYNGEN_GLOBAL_LOCK: std::sync::LazyLock<bool> =
    std::sync::LazyLock::new(|| std::env::var_os("CFF_AUDIT_FEYNGEN_GLOBAL_LOCK").is_some());

'''
patched=patched.replace('const CANONIZE_GRAPH_FLOWS: bool = true;',flags+'const CANONIZE_GRAPH_FLOWS: bool = true;')
anchor='        let pooled_bare_graphs_clone = pooled_bare_graphs.clone();'
assert patched.count(anchor)==1
patched=patched.replace(anchor,anchor+'\n        let cff_audit_lookup_serial_gate = Mutex::new(());')
anchor='let bucket = pooled_bare_graphs_clone.lock().unwrap()'
assert patched.count(anchor)==3
patched=patched.replace(anchor,'let _cff_audit_global_guard = (*CFF_AUDIT_FEYNGEN_GLOBAL_LOCK)\n                                    .then(|| cff_audit_lookup_serial_gate.lock().unwrap());\n                                '+anchor)
out=Path('/tmp/cff-change-audit/feyngen-perf')
(out/'diagram_generator.rs.instrumented').write_text(patched)
(out/'intervention.patch').write_text(''.join(difflib.unified_diff(current.splitlines(True),patched.splitlines(True),fromfile='a/'+relative,tofile='b/'+relative)))
(out/'intervention_manifest.json').write_text(json.dumps({'base':'d55a0f3e9d25e5c64bdb9ef9fb57749ecf680390','baseline_comparators_source':'26b57b786^','current_file_sha256':hashlib.sha256(current.encode()).hexdigest(),'instrumented_file_sha256':hashlib.sha256(patched.encode()).hexdigest(),'flags':['CFF_AUDIT_FEYNGEN_OLD_COMPARATOR','CFF_AUDIT_FEYNGEN_GLOBAL_LOCK'],'comparator_intervention':'Exact old comparator bodies wrapped inside existing methods, using cached flag; otherwise current body unchanged. Only old event_enabled macro and Span type get explicit tracing qualifiers.','lock_intervention':'Additional shared mutex held around lookup/search/insertion at all three bucket sites, restores global serialization while retaining current map/bucket storage. It is a serialization ablation, not a byte-for-byte recreation of the old map storage. No inverse acquisition order exists; extra guard is always acquired before map then bucket and there is no recursive lookup.','excluded':'Redundant graph-clone removal remains active in every mode; zero-mask construction overhead remains in every mode.','validation':'Prepared only; root owns formatting/check/build/smoke and must not treat this as compiled.'},indent=2)+'\n')
print('prepared',len(patched),'bytes')

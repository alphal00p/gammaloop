from pathlib import Path
import json
r=Path('/tmp/cff-change-audit/feyngen-perf')
common='''[cli_settings.global]
display_directive = "info"
logfile_directive = "off"
[cli_settings.global.n_cores]
generate = 1
compile = 1
integrate = 1
'''
records=[]
for grouping,label in [('group_identical_graphs_up_to_sign','sign'),('group_identical_graphs_up_to_scalar_rescaling','scalar')]:
 for workers in [1,4]:
  name=f'sm_ddx_{label}_{workers}workers'
  command=f'generate xs e+ e- > d d~ | e- a d g QED^2==4 [{{{{2}}}} QCD] --numerator-grouping {grouping} --symmetrize-left-right-states false --only-diagrams -p lookup -i NLO'
  out=r/(name+'.toml')
  out.write_text('commands = [\n  "import model sm-default.json",\n  '+json.dumps(command)+',\n]\n\n'+common+f'feyngen = {workers}\n')
  records.append({'name':name,'card':str(out),'process_command':command,'workers':workers,'grouping':grouping,'expected_contract':'Complete physical generated diagram sum, exact signed ratios; counts/representative order are diagnostic only.'})
(r/'cards.json').write_text(json.dumps(records,indent=2)+'\n')

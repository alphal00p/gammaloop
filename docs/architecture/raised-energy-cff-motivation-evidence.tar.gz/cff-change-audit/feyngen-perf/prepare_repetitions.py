from pathlib import Path
import difflib,hashlib,json,re
b=Path('/tmp/cff-change-audit/feyngen-perf');source=b/'diagram_generator.rs.instrumented';before=source.read_text();after=before
flags='''static CFF_AUDIT_COMPARE_REPETITIONS: std::sync::LazyLock<usize> =
    std::sync::LazyLock::new(|| {
        let repetitions = std::env::var("CFF_AUDIT_COMPARE_REPETITIONS")
            .map(|value| value.parse::<usize>().expect("positive audit repetition count"))
            .unwrap_or(1);
        assert!(repetitions > 0, "audit repetition count must be positive");
        repetitions
    });

'''
after=after.replace('const CANONIZE_GRAPH_FLOWS: bool = true;',flags+'const CANONIZE_GRAPH_FLOWS: bool = true;')
for signature,end,method in [('fn compare_with_sign_only(', '    /// Compare two numerators allowing arbitrary scalar rescaling.','sign'),('fn compare_with_scalar_rescaling(', '    #[instrument(skip_all,fields(graph_name = %graph.name))]','scalar')]:
 a=before.index(signature);z=before.index(end,a);section=before[a:z];lo=section.index('{');hi=section.rfind('}');body=re.sub(r'\bself\b','candidate',section[lo+1:hi]);wrapper='''
        let compare_once = |candidate: &Self, other: &Self| -> Option<Atom> {BODY
        };
        let repetitions = *CFF_AUDIT_COMPARE_REPETITIONS;
        if repetitions == 1 {
            return compare_once(self, other);
        }
        let expected = compare_once(self, other);
        // Keep allocation and all equality assertions outside the measured interval.
        // Retaining each result adds one Vec push to each measured comparison.
        let mut results = Vec::with_capacity(repetitions);
        let start = std::time::Instant::now();
        for _ in 0..repetitions {
            results.push(std::hint::black_box(compare_once(
                std::hint::black_box(self),
                std::hint::black_box(other),
            )));
        }
        let elapsed_ns = start.elapsed().as_nanos() as u64;
        for result in results {
            assert_eq!(result, expected, "repeated comparator result changed");
        }
        crate::debug_tags!(#feyngen, #audit, #comparison;
            stage = "comparison_repetition_audit",
            method = "METHOD",
            repetitions,
            elapsed_ns,
            self_id = self.diagram_id,
            other_id = other.diagram_id,
            self_samples = self.sample_evaluations.len(),
            other_samples = other.sample_evaluations.len(),
            self_polynomial_samples = self.sample_evaluations_as_polynomial.len(),
            other_polynomial_samples = other.sample_evaluations_as_polynomial.len(),
            self_canonical = self.canonized_numerator.is_some(),
            other_canonical = other.canonized_numerator.is_some(),
            old_comparator = *CFF_AUDIT_FEYNGEN_OLD_COMPARATOR,
            global_lock = *CFF_AUDIT_FEYNGEN_GLOBAL_LOCK,
            matching = expected.is_some(),
            result = ?expected,
            "Repeated actual physical numerator comparison"
        );
        expected
    '''.replace('BODY',body).replace('METHOD',method)
 replacement=section[:lo+1]+wrapper+section[hi:];assert after.count(section)==1;after=after.replace(section,replacement)
(b/'diagram_generator.rs.repetitions').write_text(after)
relative='crates/gammalooprs/src/feyngen/diagram_generator.rs'
(b/'repetitions.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+relative,tofile='b/'+relative)))
(b/'repetitions-manifest.json').write_text(json.dumps({'base':str(source),'base_sha256':hashlib.sha256(before.encode()).hexdigest(),'patched_sha256':hashlib.sha256(after.encode()).hexdigest(),'output':str(b/'diagram_generator.rs.repetitions'),'patch':str(b/'repetitions.patch'),'activation':'CFF_AUDIT_COMPARE_REPETITIONS=N, positive count; default1 bypasses benchmarking. Old comparator and global lock gates remain independent.','timing_scope':'Repeated comparator calls on an actual physical candidate pair, plus black_box and Vec push. Vector allocation, warmup reference and equality assertions over every result are outside timing. The per-call #[instrument] span entry is excluded because the local closure repeats within one instrumented method invocation; disable general comparison debug logs and enable only the dedicated audit tag. Not whole large-bucket lookup or end-to-end generation speedup.','record_filter':'GL_LOGFILE_FILTER=gammalooprs::feyngen::diagram_generator=info,gammalooprs::feyngen::diagram_generator[{#feyngen,#audit,#comparison}]=debug; module-qualified tag is required because target specificity precedes tag specificity. General comparator DEBUG remains disabled.','status':'Prepared only. Root must review,format,check,build before use.'},indent=2)+'\n')
print('prepared',len(after),'bytes')

"""Verify final retained E2E artifacts against recorded and validated full exports."""
import collections
import hashlib
import json
import pathlib

base = pathlib.Path('/tmp/cff-change-audit/feyngen-perf')
directory = base / 'e2e-physical-two-rounds'
manifest = json.loads((directory / 'manifest.json').read_text())
assert len(manifest['runs']) == 48, 'Wait for the complete declared experiment'
assert all(run['exit_code'] == 0 for run in manifest['runs']), 'Retained failure requires explicit omission review'
source = base / 'larger-physical-smokes.json'
reference = next(run['exports'] for run in json.loads(source.read_text()) if run['case'] == 'three_gluon_vertex_2loop_quark')
assert len(reference) == 36
rows = []
for run in manifest['runs']:
    exports_path = pathlib.Path(run['command'][-1])
    actual = {}
    for path in exports_path.rglob('*.dot'):
        with path.open('rb') as stream:
            actual[str(path.relative_to(exports_path))] = hashlib.file_digest(stream, 'sha256').hexdigest()
    row = {'variant': run['variant']['id'], 'round': run['round'], 'files_rehashed': len(actual), 'matches_recorded_complete_map': actual == run['graph_exports'], 'matches_validated_default_complete_map': actual == reference}
    assert row['matches_recorded_complete_map'] and row['matches_validated_default_complete_map']
    rows.append(row)
orders = {index: [run['variant']['id'] for run in manifest['runs'] if run['round'] == index] for index in (-1, 0, 1)}
assert all(len(order) == 16 and len(set(order)) == 16 for order in orders.values())
assert orders[1] == list(reversed(orders[0]))
assert {run['command'][2] for run in manifest['runs']} == {'8-11'}
assert {run['variant']['workers'] for run in manifest['runs']} == {1, 4}
with pathlib.Path(manifest['binary']).open('rb') as stream:
    binary_sha256 = hashlib.file_digest(stream, 'sha256').hexdigest()
with pathlib.Path(manifest['driver']).open('rb') as stream:
    driver_sha256 = hashlib.file_digest(stream, 'sha256').hexdigest()
assert binary_sha256 == manifest['binary_sha256']
assert driver_sha256 == manifest['driver_sha256']
receipt = {'cli_observations': 48, 'warmups': 16, 'measured_observations': 32, 'failures': 0, 'omissions': 0, 'files_rehashed': sum(row['files_rehashed'] for row in rows), 'validated_reference': str(source), 'validated_reference_sha256': hashlib.sha256(source.read_bytes()).hexdigest(), 'reference_export_count': len(reference), 'all_recorded_and_validated_default_maps_match': True, 'exact_forward_reverse_measured_orders': orders, 'allowed_cpu_mask_all_runs': '8-11', 'worker_pool_sizes': [1, 4], 'binary_sha256_unchanged': binary_sha256, 'driver_sha256_unchanged': driver_sha256, 'verification_script_sha256': hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(), 'observations': rows}
(directory / 'final-artifact-verification.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({key: value for key, value in receipt.items() if key not in ('observations', 'exact_forward_reverse_measured_orders')}, indent=2))

"""Summarize retained physical exports and comparison measurements."""
import collections
import hashlib
import json
import pathlib
import statistics
import sys

directory = pathlib.Path(sys.argv[1])
manifest = json.loads((directory / 'manifest.json').read_text())
runs = manifest['runs']
observation_keys = [(run['variant']['id'], run['round']) for run in runs]
assert len(observation_keys) == len(set(observation_keys)), 'Duplicate completed observations must not be silently counted'
for run in runs:
    keys = [(item['method'], item['self_id'], item['other_id']) for item in run['comparison_records']]
    assert len(keys) == len(set(keys)), 'Duplicate candidate-pair records must not be hidden by dictionary conversion'
successful = [run for run in runs if run['exit_code'] == 0 and run['graph_exports'] and not run.get('failure') and (manifest['configuration']['mode'] != 'body' or run['comparison_records'])]
summary = {
    'manifest': str(directory / 'manifest.json'),
    'summary_generator': str(pathlib.Path(__file__).resolve()),
    'summary_generator_sha256': hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),
    'comparison_pair_keys_unique_in_every_observation': True,
    'observations': len(runs),
    'timed_observations': sum(not run['warmup'] for run in successful),
    'successful_observations': len(successful),
    'failures': [{'variant': run['variant']['id'], 'round': run['round'], 'exit_code': run['exit_code'], 'reason': run.get('failure', 'Incomplete physical output or comparison trace')} for run in runs if run not in successful],
    'binary_sha256': manifest['binary_sha256'],
    'all_complete_exports_equal_within_grouping': all(run['complete_export_byte_equal_to_reference'] is True for run in successful) if successful else None,
    'timing_scope': manifest['policy'],
    'variants': {},
    'paired_body_results': [],
}
grouped = collections.defaultdict(list)
for run in runs:
    grouped[run['variant']['id']].append(run)
for variant, observations in grouped.items():
    measured = [run for run in observations if not run['warmup'] and run in successful]
    values = {'successful_warmups': sum(run['warmup'] for run in observations if run in successful), 'measurements': len(measured), 'failures': sum(run not in successful for run in observations)}
    for label, sample in [
        ('wall_seconds', [run['wall_seconds'] for run in measured]),
        ('numerator_preparation_and_grouping_seconds', [run['numerator_preparation_and_grouping_seconds'] for run in measured if run['numerator_preparation_and_grouping_seconds'] is not None]),
        ('max_rss_bytes', [run['max_rss_bytes'] for run in measured]),
        ('body_nanoseconds_per_comparison', [sum(item['elapsed_ns'] for item in run['comparison_records']) / sum(item['repetitions'] for item in run['comparison_records']) for run in measured if run['comparison_records']]),
    ]:
        if sample:
            values[label] = {'median': statistics.median(sample), 'min': min(sample), 'max': max(sample)}
    signatures = []
    for run in observations:
        if run not in successful:
            continue
        signature = sorted((item['method'], item['self_id'], item['other_id'], item['matching'], item['result'], item['self_samples'], item['other_samples'], item['self_polynomial_samples'], item['other_polynomial_samples'], item['self_canonical'], item['other_canonical']) for item in run['comparison_records'])
        signatures.append(signature)
    values['body_result_signature'] = signatures[0] if signatures else None
    values['body_results_stable_across_runs'] = all(signature == signatures[0] for signature in signatures) if signatures else None
    summary['variants'][variant] = values
if manifest['configuration']['mode'] == 'body':
    for grouping in sorted({run['variant']['grouping'] for run in runs}):
        old = {run['round']: run for run in successful if run['variant']['id'] == f'{grouping}-1workers-old-comparator'}
        new = {run['round']: run for run in successful if run['variant']['id'] == f'{grouping}-1workers-current'}
        ratios = []
        for round_index in sorted(old.keys() & new.keys()):
            previous, current = old[round_index], new[round_index]
            old_records = {(item['self_id'], item['other_id']): item for item in previous['comparison_records']}
            new_records = {(item['self_id'], item['other_id']): item for item in current['comparison_records']}
            same_pairs = old_records.keys() == new_records.keys()
            same_results = same_pairs and all(old_records[key]['result'] == new_records[key]['result'] for key in old_records)
            summary['paired_body_results'].append({'grouping': grouping, 'round': round_index, 'same_candidate_pairs': same_pairs, 'same_complete_results': same_results})
            if round_index >= 0 and same_results:
                ratios.append(sum(item['elapsed_ns'] for item in old_records.values()) / sum(item['elapsed_ns'] for item in new_records.values()))
        if ratios:
            summary.setdefault('paired_old_over_current_body_ratios', {})[grouping] = {'median': statistics.median(ratios), 'min': min(ratios), 'max': max(ratios)}
else:
    summary['paired_e2e_intervention_over_current_ratios'] = {}
    for grouping in sorted({run['variant']['grouping'] for run in runs}):
        for workers in (1, 4):
            current = {run['round']: run for run in successful if not run['warmup'] and run['variant']['id'] == f'{grouping}-{workers}workers-current'}
            for intervention in ('old-comparator', 'global-lock', 'both'):
                other = {run['round']: run for run in successful if not run['warmup'] and run['variant']['id'] == f'{grouping}-{workers}workers-{intervention}'}
                values = {}
                for metric in ('wall_seconds', 'numerator_preparation_and_grouping_seconds'):
                    ratios = [other[index][metric] / current[index][metric] for index in sorted(current.keys() & other.keys()) if current[index][metric] is not None and other[index][metric] is not None]
                    if ratios:
                        values[metric] = {'median': statistics.median(ratios), 'min': min(ratios), 'max': max(ratios), 'paired_rounds': len(ratios)}
                summary['paired_e2e_intervention_over_current_ratios'][f'{grouping}-{workers}workers-{intervention}'] = values
configuration = manifest['configuration']
planned_groups = ('sign', 'scalar') if configuration['grouping'] == 'both' else (configuration['grouping'],)
planned_workers = (1, 4) if configuration['mode'] == 'e2e' else (1,)
planned_modes = ('current', 'old-comparator', 'global-lock', 'both') if configuration['mode'] == 'e2e' else ('current', 'old-comparator')
planned_keys = [(f'{grouping}-{workers}workers-{mode}', index) for grouping in planned_groups for workers in planned_workers for mode in planned_modes for index in range(-1, configuration['rounds'])]
failed_at = {run['variant']['id']: run['round'] for run in runs if run not in successful}
omissions = [{'variant': variant, 'round': index, 'reason': 'failed variant omitted from later rounds' if variant in failed_at and index > failed_at[variant] else 'not executed or still pending'} for variant, index in planned_keys if (variant, index) not in observation_keys]
summary['planned_observations'] = len(planned_keys)
summary['completed_observation_keys_unique'] = True
summary['planned_observation_omissions'] = omissions
summary['all_planned_observations_accounted_for'] = all(item['reason'] == 'failed variant omitted from later rounds' for item in omissions)
summary['all_body_results_equal_between_modes'] = all(item['same_complete_results'] for item in summary['paired_body_results']) if summary['paired_body_results'] else None
reference_base = pathlib.Path('/tmp/cff-change-audit/feyngen-perf')
if manifest['configuration']['fixture'] == 'three-gluon':
    reference_path = reference_base / 'larger-physical-smokes.json'
    reference_record = next(item for item in json.loads(reference_path.read_text()) if item['case'] == 'three_gluon_vertex_2loop_quark')
    references = {grouping: reference_record['exports'] for grouping in ('sign', 'scalar')}
else:
    reference_path = reference_base / 'frozen-smokes.json'
    reference_runs = json.loads(reference_path.read_text())['runs']
    references = {grouping: next(item['dot_sha256'] for item in reference_runs if item['case'] == f'sm_ddx_{grouping}_1workers' and item['mode'] == 'current') for grouping in ('sign', 'scalar')}
links = [{'variant': run['variant']['id'], 'round': run['round'], 'export_count': len(run['graph_exports']), 'equals_complete_validated_default': run['graph_exports'] == references[run['variant']['grouping']] if run['graph_exports'] else None} for run in runs]
summary['validated_default_export_linkage'] = {'source': str(reference_path), 'source_sha256': hashlib.sha256(reference_path.read_bytes()).hexdigest(), 'reference_export_counts': {grouping: len(exports) for grouping, exports in references.items()}, 'all_nonempty_export_maps_equal': all(item['equals_complete_validated_default'] for item in links if item['export_count']) if any(item['export_count'] for item in links) else None, 'observations': links}
(directory / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({key: value for key, value in summary.items() if key != 'variants'}, indent=2))

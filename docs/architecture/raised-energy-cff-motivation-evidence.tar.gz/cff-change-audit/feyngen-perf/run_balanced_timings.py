"""Run only after the coordinated build-quiet slot and fresh core CLI are ready."""
import argparse,datetime,fcntl,hashlib,json,os,pathlib,subprocess,time
p=argparse.ArgumentParser();p.add_argument('--binary',type=pathlib.Path,required=True);p.add_argument('--output',type=pathlib.Path,required=True);p.add_argument('--mode',choices=['e2e','body'],required=True);p.add_argument('--rounds',type=int,default=6);p.add_argument('--grouping',choices=['sign','scalar','both'],default='both');p.add_argument('--fixture',choices=['three-gluon','small-control'],default='three-gluon');p.add_argument('--repetitions',type=int,default=50000);p.add_argument('--resume',action='store_true');args=p.parse_args()
base=pathlib.Path('/tmp/cff-change-audit/feyngen-perf');lock_path=pathlib.Path('/tmp/cff-change-audit/measurement.lock');lock=lock_path.open('a');fcntl.flock(lock,fcntl.LOCK_EX)
assert args.output.exists() if args.resume else not args.output.exists(),'Use a fresh output directory or explicitly resume';args.output.mkdir(parents=True,exist_ok=args.resume)
source=base/('three_gluon_vertex_2loop_quark_sign_4workers.toml'if args.fixture=='three-gluon'else'sm_ddx_sign_1workers.toml');template=source.read_text()
variants=[]
for grouping in (['sign','scalar']if args.grouping=='both'else[args.grouping]):
 for workers in ([1,4]if args.mode=='e2e'else[1]):
  modes=[('current',[]),('old-comparator',['CFF_AUDIT_FEYNGEN_OLD_COMPARATOR'])]
  if args.mode=='e2e':modes += [('global-lock',['CFF_AUDIT_FEYNGEN_GLOBAL_LOCK']),('both',['CFF_AUDIT_FEYNGEN_OLD_COMPARATOR','CFF_AUDIT_FEYNGEN_GLOBAL_LOCK'])]
  for mode,flags in modes:variants.append({'id':f'{grouping}-{workers}workers-{mode}','grouping':grouping,'workers':workers,'flags':flags})
with args.binary.open('rb')as binary_stream:
 binary_sha256=hashlib.file_digest(binary_stream,'sha256').hexdigest()
with pathlib.Path(__file__).open('rb')as driver_stream:
 driver_sha256=hashlib.file_digest(driver_stream,'sha256').hexdigest()
manifest={'driver':str(pathlib.Path(__file__).resolve()),'driver_sha256':driver_sha256,'planned_observations':len(variants)*(args.rounds+1),'binary':str(args.binary),'binary_sha256':binary_sha256,'fixture_card':str(source),'fixture_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'configuration':vars(args)|{'binary':str(args.binary),'output':str(args.output)},'measurement_lock':str(lock_path),'policy':'One excluded warmup. E2E uses exact forward/reverse rounds; body uses rotated interleaved rounds, with current leading sign4/6 and scalar5/6 in the six-round design; fresh state/card/export per observation; no retries. e2e includes physical numerator preparation and grouping. body repeats actual private comparator core calls, excludes per-call instrumented span entry, includes black_box/Vec push/result retention; allocation, reference warmup and all equality assertions outside timer. Body results do not establish large-bucket or whole-generation speedup. Parent launches whole runner under the licensed8GB watchdog.','runs':[]}
if args.resume:
 manifest=json.loads((args.output/'manifest.json').read_text())
 assert manifest['binary_sha256']==binary_sha256,'Cannot resume with a different executable'
 for key in ['mode','rounds','grouping','fixture','repetitions']:
  assert manifest['configuration'][key]==getattr(args,key),f'Cannot change {key} while resuming'
completed={(r['variant']['id'],r['round'])for r in manifest['runs']}
failed_variants=set();export_references={}
for run in manifest['runs']:
 valid=run['exit_code']==0 and bool(run['graph_exports']) and (args.mode!='body' or bool(run['comparison_records']) and all(r['repetitions']==args.repetitions for r in run['comparison_records']))
 if not valid:
  failed_variants.add(run['variant']['id']);run['complete_export_byte_equal_to_reference']=None;run['export_reference_variant']=None
 else:
  reference=export_references.setdefault(run['variant']['grouping'],{'variant':run['variant']['id'],'exports':run['graph_exports']})
  run['complete_export_byte_equal_to_reference']=run['graph_exports']==reference['exports'];run['export_reference_variant']=reference['variant']
manifest['failure_policy']='Retain failed observation and skip only that variant in later rounds; continue independent variants. Resume never reruns a completed observation. Incomplete exports have null parity and never seed a reference.'
for round_index in range(-1,args.rounds):
 offset=0 if round_index<0 or args.mode=='e2e' else 3*round_index%len(variants);ordered=variants[offset:]+variants[:offset]
 if round_index%2:ordered=list(reversed(ordered))
 for variant in ordered:
  if (variant['id'],round_index) in completed or variant['id'] in failed_variants:continue
  label=variant['id']+'-'+('warmup'if round_index<0 else str(round_index));out=args.output/label;out.mkdir();text=template
  for workers in [1,4]:text=text.replace(f'feyngen = {workers}',f'feyngen = {variant["workers"]}')
  if variant['grouping']=='scalar':text=text.replace('group_identical_graphs_up_to_sign','group_identical_graphs_up_to_scalar_rescaling')
  text=text.replace('display_directive = "info"','display_directive = "off"');card=out/'card.toml';card.write_text(text)
  env=os.environ.copy()
  for key in list(env):
   if key.startswith(('CFF_AUDIT_','SPENSO_')):del env[key]
  env.pop('GL_ALL_LOG_FILTER',None);env.update({'GL_DISPLAY_FILTER':'off','GL_LOGFILE_FILTER':'gammalooprs::feyngen::diagram_generator=info,gammalooprs::feyngen::diagram_generator[{#feyngen,#audit,#comparison}]=debug'if args.mode=='body'else'gammalooprs::feyngen::diagram_generator=info','RAYON_NUM_THREADS':str(variant['workers']),'INSTA_UPDATE':'no'});env.update({flag:'1'for flag in variant['flags']})
  if args.mode=='body':env['CFF_AUDIT_COMPARE_REPETITIONS']=str(args.repetitions)
  cmd=['taskset','-c','8'if args.mode=='body'else'8-11','timeout','--kill-after=5s','180s',str(args.binary),'-n','-s',str(out/'state'),'-t','comparison.jsonl',str(card),'save','dot',str(out/'graphs')]
  started=time.monotonic()
  with (out/'cli.log').open('wb')as log:
   child=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT,env=env);_,status,usage=os.wait4(child.pid,0);child.returncode=os.waitstatus_to_exitcode(status)
  elapsed=time.monotonic()-started;audit=[];milestones=[]
  for path in (out/'state'/'logs').glob('*'):
   for line in path.read_text().splitlines():
    try:record=json.loads(line);record={**record,**record.get('fields',{})}
    except json.JSONDecodeError:continue
    if record.get('stage')=='comparison_repetition_audit':audit.append(record)
    if any(fragment in record.get('message','')for fragment in ['Number of graphs after canonization','Number of graphs after numerator-aware']):milestones.append(record)
  exports={}
  for x in (out/'graphs').rglob('*.dot'):
   with x.open('rb')as export_stream:exports[str(x.relative_to(out/'graphs'))]=hashlib.file_digest(export_stream,'sha256').hexdigest()
  stage_seconds=None
  if len(milestones)==2:
   stage_seconds=(datetime.datetime.fromisoformat(milestones[1]['timestamp'].replace('Z','+00:00'))-datetime.datetime.fromisoformat(milestones[0]['timestamp'].replace('Z','+00:00'))).total_seconds()
  failure=None
  if child.returncode!=0:failure='CLI failed or reached resource cap'
  elif not exports:failure='Missing complete physical graph exports'
  elif args.mode=='body'and(not audit or not all(r['repetitions']==args.repetitions for r in audit)):failure='Comparator repetition path or dedicated trace was not reached'
  reference=None if failure else export_references.setdefault(variant['grouping'],{'variant':variant['id'],'exports':exports})
  record={'variant':variant,'round':round_index,'warmup':round_index<0,'command':cmd,'exit_code':child.returncode,'wall_seconds':elapsed,'max_rss_bytes':usage.ru_maxrss*1024,'card_sha256':hashlib.sha256(card.read_bytes()).hexdigest(),'comparison_records':audit,'grouping_milestones':milestones,'numerator_preparation_and_grouping_seconds':stage_seconds,'stage_scope':'Existing JSON timestamp delta (millisecond resolution), includes numerator preparation, grouping and combination; not isolated comparator time.','graph_exports':exports,'complete_export_byte_equal_to_reference':exports==reference['exports']if reference else None,'export_reference_variant':reference['variant']if reference else None,'failure':failure}
  if failure:failed_variants.add(variant['id'])
  manifest['failed_variants_skipped_in_later_rounds']=sorted(failed_variants)
  manifest['runs'].append(record);(args.output/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(label,child.returncode,round(elapsed,4),len(audit),flush=True)
manifest['failed_variants_skipped_in_later_rounds']=sorted(failed_variants)
(args.output/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
if failed_variants:raise SystemExit(1)

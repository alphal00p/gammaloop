# Independent benchmark instrumentation review

Read `prepare_instrumentation.py`, `run_matrix.py`, original/current dispatch context, and all inserted switches in the three scratch files. No Cargo command or benchmark was run during this read.

The old kernel switch restores the original `39561014` grouped sparse dispatch and multi-index merge kernel and delegates dense/mixed contractions to the generic implementation. It uses the final dependencies and other tensor code, so this is a scoped old-production ablation, not a complete historical-version performance comparison. The renamed auto-parallel constant remains false. The alias switch reproduces `add_alias` versus `register_alias` at the intended wrapper boundary. The eager switch disables the new automatic large-sum heuristic but preserves the old explicit profiling override. SmallestDegree uses the same concrete library, sequential executor and input as other choices. Timing encloses network execution separately from result extraction and alias wrapping; full aliased outputs remain available for comparison.

Two controls need confirmation before timings are accepted:

1. `run_matrix.py` itself showed only a timeout, not a 30 GB guard. Enforce the resource cap externally or use the existing process-tree watchdog. `wait4.ru_maxrss` is a high-water mark for an individual child/descendant, not peak summed concurrent process-tree RSS. Label it accurately and retain a separately sampled tree measurement if claiming that metric.
2. Clear or explicitly pin inherited `SPENSO_NETWORK_LAZY_TENSOR_SUMS`, `SPENSO_NETWORK_PROFILE`, verbose and atom-byte profiling variables. The eager switch intentionally honors the existing explicit lazy override; an inherited override can make the intended ablation inactive. Profiling/tracing can bias the timed stage. Run separate untimed reachability traces.

The current scratch example contains the summary JSON export (in `SummaryTable::print`) and the measured `alias_registration` row. The saved preparation script does not itself recreate the summary export, so the manifest must pin actual source bytes and the executable rather than treating that script alone as complete reproducibility. The parent was notified of all three points. Semantic comparisons remain a required independent step; successful exits and expression counts alone do not establish equivalence.

No additional clear A/B semantic defect was found in the inspected instrumentation. Environment controls and resource policy above remain for the parent to close before measurement.

import collections,fcntl,hashlib,json,os,pathlib,statistics,subprocess,sys,time
root=pathlib.Path('/tmp/cff-change-audit/cff-perf')
config=json.loads(pathlib.Path(sys.argv[1]).read_text())
binary=pathlib.Path(config['binary']);out=root/config['output'];out.mkdir(exist_ok=True,parents=True)
variants=[('final',{}),('eager_layers',{'CFF_PERF_EAGER_LAYERS':'1'}),('eager_parent_fanout',{'CFF_PERF_EAGER_PARENT_FANOUT':'1'}),('no_base_cache',{'CFF_PERF_NO_BASE_CACHE':'1'}),('no_compaction',{'CFF_PERF_NO_COMPACTION':'1'})]
lock=(root.parent/'measurement.lock').open('a');lock_start=time.monotonic()
if not config.get('trace'):fcntl.flock(lock,fcntl.LOCK_EX)
lock_wait=time.monotonic()-lock_start
manifest={'measurement_lock_wait_seconds':lock_wait,'ambient_host':'not exclusive; shared measurement lock serializes audit benchmark families; all local audit builds must finish first','binary':str(binary),'binary_sha256':hashlib.file_digest(binary.open('rb'),'sha256').hexdigest(),'provenance':json.loads((root/'provenance.json').read_text()),'config':config,'policy':'Fresh process per observation, one generation, no retries, balanced forward/reverse rounds, CPU9 with one worker; one excluded warm-up per variant. Parent invokes whole campaign under process-tree watchdog. Kernel timing excludes evaluation and output; ru_maxrss is largest child peak, not summed tree or isolated generation allocation.','runs':[]}
for fixture in config['fixtures']:
 p=root/'fixtures'/(fixture+'.json');fd=out/fixture;fd.mkdir(exist_ok=True)
 active=variants.copy()
 for round in range(-1,config.get('rounds',4)):
  order=active if round%2==0 else list(reversed(active))
  for variant,flags in order:
   label=f'{variant}-'+('warmup'if round<0 else str(round));log=fd/(label+'.log');result=fd/(label+'.json')
   env=os.environ.copy()
   for key in list(env):
    if key.startswith('CFF_PERF_')or key.startswith('CFF_AUDIT_')or key.startswith('SPENSO_'):env.pop(key)
   env.update({'RAYON_NUM_THREADS':'1','NEXTEST_TEST_THREADS':'1','INSTA_UPDATE':'no',**flags})
   cmd=['taskset','-c',str(config.get('cpu',9)),'timeout','--signal=TERM','--kill-after=5s',str(config.get('timeout_seconds',120))+'s',str(binary),str(p),str(result),'1']
   if config.get('skip_probes'):cmd.append('--skip-probes')
   if config.get('trace'):env['CFF_PERF_TRACE']='1'
   start=time.monotonic()
   with log.open('wb')as stream:
    proc=subprocess.Popen(cmd,stdout=stream,stderr=subprocess.STDOUT,env=env)
    _,status,usage=os.wait4(proc.pid,0);proc.returncode=os.waitstatus_to_exitcode(status)
   elapsed=time.monotonic()-start
   row={'fixture':fixture,'fixture_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'variant':variant,'round':round,'warmup':round<0,'command':cmd,'environment_overrides':{'RAYON_NUM_THREADS':'1','INSTA_UPDATE':'no',**flags},'exit_code':proc.returncode,'wall_seconds':elapsed,'max_child_rss_bytes':usage.ru_maxrss*1024,'log':str(log),'result':str(result),'output':json.loads(result.read_text())if result.exists()else None}
   if config.get('trace'):
    row['trace_counts']=dict(collections.Counter(line for line in log.read_text().splitlines()if line.startswith('CFF_PERF ')))
   manifest['runs'].append(row);(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
   print(f'{fixture} {label}: exit={proc.returncode}; wall={elapsed:.6f}s; child_peak={usage.ru_maxrss*1024/1e6:.3f}MB',flush=True)
   if proc.returncode:
    active=[(v,f)for v,f in active if v!=variant]
  if not active:break
comparisons=[]
for fixture in config['fixtures']:
 baseline=next((r['output']for r in manifest['runs']if r['fixture']==fixture and r['variant']=='final'and r['exit_code']==0),None)
 if baseline is None:continue
 for row in manifest['runs']:
  if row['fixture']!=fixture or row['exit_code']!=0:continue
  got=row['output'];assert len(got['values'])==len(baseline['values'])
  errors=[]
  for a,b in zip(got['values'],baseline['values']):
   assert a['seed']==b['seed']and a['numerator']==b['numerator']
   scale=max(abs(a['value']),abs(b['value']),sys.float_info.min)
   errors.append(abs(a['value']-b['value'])/scale)
  metadata_equal=all(got[k]==baseline[k]for k in['core_sign','denominator_sign','energy_factor_components','source_energy_degree_bounds'])
  same_expression=pathlib.Path(got['expression_file']).read_bytes()==pathlib.Path(baseline['expression_file']).read_bytes()
  ok=metadata_equal and max(errors,default=0)<=1e-9
  trace_equal=None;trace_path=None
  if config.get('skip_probes'):
   trace_root=root/config['correctness_trace_roots'][fixture]
   trace_manifest=json.loads((trace_root/'manifest.json').read_text())
   reference_row=next(r for r in trace_manifest['runs']if r['fixture']==fixture and r['variant']==row['variant']and r['exit_code']==0)
   assert reference_row['fixture_sha256']==row['fixture_sha256'], 'Timed graph/options/witness fixture must be identical to validated trace'
   reference=reference_row['output'];trace_path=reference['expression_file']
   trace_equal=hashlib.file_digest(pathlib.Path(got['expression_file']).open('rb'),'sha256').digest()==hashlib.file_digest(pathlib.Path(trace_path).open('rb'),'sha256').digest()
   trace_metadata_equal=all(got[k]==reference[k]for k in['core_sign','denominator_sign','energy_factor_components','source_energy_degree_bounds'])
   ok=ok and trace_equal and trace_metadata_equal and bool(reference['values']) and got.get('probes_skipped')is True
  elif not got['values']:ok=False
  comparisons.append({'trace_expression_equal':trace_equal,'trace_reference':trace_path,'fixture':fixture,'variant':row['variant'],'round':row['round'],'complete_expression_bytes_equal':same_expression,'metadata_equal':metadata_equal,'max_normalized_value_error':max(errors,default=0),'passed':ok})
summary=[]
for fixture in config['fixtures']:
 for variant,_ in variants:
  r=[x for x in manifest['runs']if x['fixture']==fixture and x['variant']==variant and x['round']>=0 and x['exit_code']==0]
  if r:
   values=[x['output']['generation_seconds'][0]for x in r]
   summary.append({'fixture':fixture,'variant':variant,'runs':len(r),'generation_mean_seconds':statistics.mean(values),'generation_median_seconds':statistics.median(values),'generation_sample_stdev_seconds':statistics.stdev(values)if len(values)>1 else 0.0,'generation_min_seconds':min(values),'generation_max_seconds':max(values),'max_child_rss_bytes':max(x['max_child_rss_bytes']for x in r),'wall_median_seconds':statistics.median(x['wall_seconds']for x in r)})
(out/'comparisons.json').write_text(json.dumps(comparisons,indent=2)+'\n');(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print('Completed',len(manifest['runs']),'observations;',len(comparisons),'value/expression comparisons;',sum(not x['passed']for x in comparisons),'comparison failures.')
if any(not x['passed']for x in comparisons):sys.exit(1)

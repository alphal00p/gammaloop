import json,pathlib
root=pathlib.Path('/tmp/cff-change-audit/cff-perf/fixtures');root.mkdir(exist_ok=True)
def edge(i,tail,head,l,e,m):
 return dict(edge_id=i,tail=tail,head=head,label=f'q{i}',mass_key=m,signature=dict(loop_signature=l,external_signature=e),had_pow=False)
def ext(i,src,dst,e):
 return dict(edge_id=i,source=src,destination=dst,label=f'p{i}',external_coefficients=e)
def save(id,edges,external,loops,exts,nodes,bounds,numerators,masses,classification,oracle=None):
 d=dict(id=id,internal_edges=edges,external_edges=external,loop_names=loops,external_names=exts,nodes={f'v{i}':i for i in range(nodes)},options=dict(representation='cff',cff_generation_context='standalone',energy_degree_bounds=bounds,numerator_sampling_scale='None',preserve_internal_edges_as_four_d_denominators=[]),numerators=numerators,masses=masses,classification=classification,oracle=oracle)
 (root/(id+'.json')).write_text(json.dumps(d,indent=2)+'\n')
# Exact five-edge routing from the importer-resolved SM double triangle.
physical=[edge(0,0,1,[1,0],[0],None),edge(1,0,2,[-1,0],[1],None),edge(2,1,2,[0,1],[0],'mt'),edge(3,2,3,[-1,1],[1],'mt'),edge(4,3,1,[-1,1],[0],'mt')]
external=[ext(10000000,None,0,[1]),ext(10000001,3,None,[-1])]
save('physical_double_triangle_affine',physical,external,['K0','K1'],['P0'],4,[[i,1]for i in range(5)],['1','edges[0][0]*edges[2][0]*edges[3][0]*edges[4][0]'],{'mt':1.7},'Physical SM g-g denominator topology; affine diagnostic polynomial witnesses. Full physical numerator is exercised by parent tensor benchmark; this isolates CFF generation.')
# Raised gluon copies carry exactly the same routed denominator. This is a
# CFF/UV-like derivative workload, not a certified complete UV Taylor sector.
powered=[edge(0,0,4,[1,0],[0],None),*physical[1:],edge(5,4,1,[1,0],[0],None)]
save('physical_double_triangle_dotted',powered,external,['K0','K1'],['P0'],5,[[0,2],[1,1],[2,1],[3,1],[4,1]],['1','edges[0][0]**2','edges[0][0]*edges[2][0]*edges[3][0]*edges[4][0]'],{'mt':1.7},'Physical double-triangle routing with one serial raised gluon; diagnostic-only energy witnesses, not a claimed physical UV certificate.')
box=[edge(0,0,1,[1],[0,0,0],'m1'),edge(1,1,2,[1],[1,0,0],'m2'),edge(2,2,3,[1],[1,1,0],'m3'),edge(3,3,4,[1],[1,1,1],'m4'),edge(4,4,5,[1],[1,1,1],'m4'),edge(5,5,0,[1],[1,1,1],'m4')]
be=[]
for i in range(3):
 e=[0]*3;e[i]=1;be.extend([ext(10000000+2*i,None,i+1,e),ext(10000001+2*i,0,None,[-x for x in e])])
save('box_cubic_rank4',box,be,['k1'],['p1','p2','p3'],6,[[3,4]],['1','edges[3][0]**2','edges[3][0]**4','(dot(edges[3],edges[3])-0.49)**2'],{'m1':0.41,'m2':0.53,'m3':0.67,'m4':0.7},'Existing public-evaluator repeated cubic pole fixture from graph_io.rs:251/eval.rs:1982; exact denominator cancellation oracle.', 'box_cubic_pinches_to_simple')
sunrise=[edge(0,0,1,[-1,-1],[1],'m1'),edge(1,0,1,[1,0],[0],'m2'),edge(2,0,2,[0,1],[0],'m3'),edge(3,2,3,[0,1],[0],'m3'),edge(4,3,4,[0,1],[0],'m3'),edge(5,4,1,[0,1],[0],'m3')]
save('sunrise_quartic_rank4',sunrise,[ext(10000000,None,0,[1]),ext(10000001,1,None,[-1])],['k1','k2'],['p1'],5,[[2,4]],['1','edges[2][0]**2','edges[2][0]**4'],{'m1':0.41,'m2':0.53,'m3':0.67},'Existing sunrise_pow4_graph fixture (graph_io.rs:269); diagnostic energy numerator on raised channel.')
bubbles=[edge(0,0,1,[1,0],[0],'m0'),edge(1,1,0,[1,0],[1],'m1'),edge(2,0,2,[0,1],[0],'m2'),edge(3,2,0,[0,1],[-1],'m3')]
save('independent_bubbles_rank2',bubbles,[ext(10000000,None,1,[1]),ext(10000001,2,None,[-1])],['x','y'],['p'],3,[[0,2],[2,2]],['1','edges[0][0]**2','edges[2][0]**2','edges[0][0]**2*edges[2][0]**2'],{'m0':0.41,'m1':0.53,'m2':0.67,'m3':0.7},'Existing independent rational-component fixture eval.rs:3344; diagnostic numerator witnesses; explicit boundary hairs added to close the exact external balances.')
print('Created',len(list(root.glob('*.json'))),'source fixtures.')

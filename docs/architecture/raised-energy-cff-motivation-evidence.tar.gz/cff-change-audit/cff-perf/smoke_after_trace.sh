#!/usr/bin/env bash
set -euo pipefail
/tmp/raised-stack/python /tmp/cff-change-audit/cff-perf/run_contracts.py > /tmp/cff-change-audit/cff-perf/contracts-driver-v2.log 2>&1
/tmp/raised-stack/python /tmp/cff-change-audit/cff-perf/run_bench.py /tmp/cff-change-audit/cff-perf/rss-trace-config.json > /tmp/cff-change-audit/cff-perf/rss-trace-driver.log 2>&1

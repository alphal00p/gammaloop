import difflib, hashlib, json, pathlib, subprocess
root=pathlib.Path('/tmp/cff-change-audit/cff-perf')
repo=pathlib.Path('/common/dev/gammaloop/higher-power-energies-review')
source=root/'source'
source.mkdir(exist_ok=True)
head='d55a0f3e9d25e5c64bdb9ef9fb57749ecf680390'
if not (source/'Cargo.toml').exists():
    a=subprocess.Popen(['git','archive',head],cwd=repo,stdout=subprocess.PIPE)
    subprocess.run(['tar','-x','-C',str(source)],stdin=a.stdout,check=True)
    a.stdout.close(); assert a.wait()==0
f='crates/three-dimensional-reps/src/generation.rs'
before=subprocess.check_output(['git','show',f'{head}:{f}'],cwd=repo,text=True)
s=before
start=s.index('    fn append_base_terms(')
pos=s.index('        let mut lower_sector_base_expression',start)
s=s[:pos]+'''        // Audit-only independent ablation; not a production setting.
        static NO_BASE_CACHE: std::sync::OnceLock<bool> = std::sync::OnceLock::new();
        static TRACE_BASE_CACHE: std::sync::OnceLock<bool> = std::sync::OnceLock::new();
        let cache_enabled = !*NO_BASE_CACHE.get_or_init(|| std::env::var_os("CFF_PERF_NO_BASE_CACHE").is_some());
        let trace_cache = *TRACE_BASE_CACHE.get_or_init(|| std::env::var_os("CFF_PERF_TRACE").is_some());
'''+s[pos:]
s=s.replace('''            let key = (parsed.clone(), inherited_contour_rows.to_vec());
            if let Some(expression) = self.lower_sector_cache.get(&key) {
                return Ok(expression.clone());
            }
''','''            let key = cache_enabled.then(|| (parsed.clone(), inherited_contour_rows.to_vec()));
            if let Some(expression) = key.as_ref().and_then(|key| self.lower_sector_cache.get(key)) {
                if trace_cache { eprintln!("CFF_PERF lower_base hit"); }
                return Ok(expression.clone());
            }
            if trace_cache { eprintln!("CFF_PERF lower_base build"); }
''',1)
s=s.replace('''            self.lower_sector_cache.insert(key, expression.clone());''','''            if let Some(key) = key { self.lower_sector_cache.insert(key, expression.clone()); }''',1)
s=s.replace('''            if let Some(expression) = self.direct_base_cache.get(parsed) {
                return Ok(expression.clone());
            }
''','''            if let Some(expression) = cache_enabled.then(|| self.direct_base_cache.get(parsed)).flatten() {
                if trace_cache { eprintln!("CFF_PERF direct_base hit"); }
                return Ok(expression.clone());
            }
            if trace_cache { eprintln!("CFF_PERF direct_base build"); }
''',1)
s=s.replace('''            self.direct_base_cache
                .insert(parsed.clone(), direct.clone());''','''            if cache_enabled { self.direct_base_cache.insert(parsed.clone(), direct.clone()); }''',1)
s=s.replace('''            if self.normalize_public_output && depth == 0 {''','''            static NO_ROOT_COMPACTION: std::sync::OnceLock<bool> = std::sync::OnceLock::new();
            if self.normalize_public_output && depth == 0
                && !*NO_ROOT_COMPACTION.get_or_init(|| std::env::var_os("CFF_PERF_NO_COMPACTION").is_some()) {
                if std::env::var_os("CFF_PERF_TRACE").is_some() { eprintln!("CFF_PERF root_compact"); }
''',1)
s=s.replace('''        self.assembly.expression = self.assembly.expression.fuse_compatible_variants();
        self.assembly.finalize_numerator_map_labels();''','''        static NO_PRODUCT_COMPACTION: std::sync::OnceLock<bool> = std::sync::OnceLock::new();
        if !*NO_PRODUCT_COMPACTION.get_or_init(|| std::env::var_os("CFF_PERF_NO_COMPACTION").is_some()) {
            if std::env::var_os("CFF_PERF_TRACE").is_some() { eprintln!("CFF_PERF product_compact"); }
            self.assembly.expression = self.assembly.expression.fuse_compatible_variants();
        }
        self.assembly.finalize_numerator_map_labels();''',1)
start=s.index('        let mut partials: Box<dyn Iterator<Item = LowerSectorPartial>')
loop_start=s.index('            partials = Box::new(partials.flat_map(move |partial| {',start)
loop_end=s.index('\n            }));',loop_start)+len('\n            }));')
lazy=s[loop_start:loop_end]
body=lazy[len('            partials = Box::new(partials.flat_map(move |partial| {'):-len('\n            }));')]
eager_body=body.replace('let mut item = partial.clone();','let mut item = (*partial).clone();')
lazy_eager_parent = lazy.replace('\n            }));', '\n                    .collect::<Vec<_>>()\n            }));')
replacement='''            static EAGER_LAYERS: std::sync::OnceLock<bool> = std::sync::OnceLock::new();
            static EAGER_PARENT_FANOUT: std::sync::OnceLock<bool> = std::sync::OnceLock::new();
            if *EAGER_LAYERS.get_or_init(|| std::env::var_os("CFF_PERF_EAGER_LAYERS").is_some()) {
                let previous = partials.collect::<Vec<_>>();
                let next = previous.iter().flat_map(move |partial| {'''+eager_body+'''
                }).collect::<Vec<_>>();
                if std::env::var_os("CFF_PERF_TRACE").is_some() {
                    eprintln!("CFF_PERF eager_layer previous={} next={}", previous.len(), next.len());
                }
                partials = Box::new(next.into_iter());
            } else if *EAGER_PARENT_FANOUT.get_or_init(|| std::env::var_os("CFF_PERF_EAGER_PARENT_FANOUT").is_some()) {
                if std::env::var_os("CFF_PERF_TRACE").is_some() { eprintln!("CFF_PERF eager_parent_fanout"); }
'''+lazy_eager_parent+'''
            } else {
'''+lazy+'''
            }'''
s=s[:loop_start]+replacement+s[loop_end:]
tracepos=s.index('        let global_basis = components',start)
s=s[:tracepos]+'''        if std::env::var_os("CFF_PERF_TRACE").is_some() {
            eprintln!("CFF_PERF product_components {}", components.len());
        }
'''+s[tracepos:]
(source/f).write_text(s)
(root/'generation-original.rs').write_text(before)
(root/'ablation.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True),s.splitlines(True),fromfile='final/'+f,tofile='audit/'+f)))
(root/'provenance.json').write_text(json.dumps({'source':head,'kind':'independent scoped optimization ablations on final source, not historical full-version benchmarks','production_file':f,'final_sha256':hashlib.sha256(before.encode()).hexdigest(),'instrumented_sha256':hashlib.sha256(s.encode()).hexdigest(),'scope':{'CFF_PERF_EAGER_LAYERS':'retains completed Cartesian layers; current precomputed remaps and later occurrence semantics kept','CFF_PERF_EAGER_PARENT_FANOUT':'retains each parent orientation/variant fanout vector while streaming complete layers','CFF_PERF_NO_BASE_CACHE':'disables both plain lower and direct base retrieval/insertion including key clones','CFF_PERF_NO_COMPACTION':'disables the two completed-output compaction sites from e4f5f778','CFF_PERF_TRACE':'untimed branch-reachability logs'}},indent=2)+'\n')
print('Prepared independent CFF ablation workspace.')

#!/usr/bin/env bash
set -euo pipefail
cd /tmp/cff-change-audit/cff-perf/source
export CARGO_TARGET_DIR=/common/dev/gammaloop/higher-power-energies-review/target
export CARGO_BUILD_JOBS=2
touch crates/three-dimensional-reps/src/generation.rs crates/three-dimensional-reps/src/eval.rs crates/three-dimensional-reps/examples/cff_audit.rs
cargo check -p three-dimensional-reps --example cff_audit --all-features --locked --profile dev-optim > /tmp/cff-change-audit/cff-perf/check.log 2>&1
cargo build -p three-dimensional-reps --example cff_audit --all-features --locked --profile dev-optim > /tmp/cff-change-audit/cff-perf/build.log 2>&1
cp /common/dev/gammaloop/higher-power-energies-review/target/dev-optim/examples/cff_audit /tmp/cff-change-audit/cff-perf/cff_audit

import difflib,hashlib,json,pathlib,subprocess
root=pathlib.Path('/tmp/cff-change-audit/cff-perf'); repo=pathlib.Path('/common/dev/gammaloop/higher-power-energies-review')
f='crates/three-dimensional-reps/src/eval.rs';head='d55a0f3e9d25e5c64bdb9ef9fb57749ecf680390';old='9c8aa0f9^'
current=subprocess.check_output(['git','show',head+':'+f],cwd=repo,text=True)
original=subprocess.check_output(['git','show',old+':'+f],cwd=repo,text=True)
s=current
for name in ['parse_prefix','parse_signed_integer']:
 marker=f'    fn {name}('
 start=original.index(marker); stop=original.index('\n    fn ',start+len(marker))
 oldfn=original[start:stop].rstrip(); oldbody=oldfn[oldfn.index('{')+1:oldfn.rfind('}')]
 begin=s.index(marker); body=s.index('{',begin)+1
 insertion='\n        // Audit-only replay of the exact pre-review parser method body.\n        if std::env::var_os("CFF_PERF_OLD_PARSER").is_some() {\n            return (|| {'+oldbody+'\n            })();\n        }\n'
 s=s[:body]+insertion+s[body:]
(root/'source'/f).write_text(s)
(root/'parser-original.rs').write_text(current)
(root/'parser-historical.rs').write_text(original)
(root/'parser-ablation.json').write_text(json.dumps({'final':head,'historical':subprocess.check_output(['git','rev-parse',old],cwd=repo,text=True).strip(),'scope':'Exact old parse_prefix and parse_signed_integer bodies, selected by CFF_PERF_OLD_PARSER. All other final evaluator code/dependencies retained; not full old-version replay.','old_sha256':hashlib.sha256(original.encode()).hexdigest(),'final_sha256':hashlib.sha256(current.encode()).hexdigest()},indent=2)+'\n')

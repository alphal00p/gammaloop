use std::{collections::BTreeMap, error::Error, fs::File, path::Path, time::Instant};
use three_dimensional_reps::{
    Generate3DExpressionOptions, ParsedGraph,
    eval::{EvaluationInput, evaluate_expression},
    generate_3d_expression,
};

fn main() -> Result<(), Box<dyn Error>> {
    let args = std::env::args().collect::<Vec<_>>();
    if args[1] == "--contract-probes" || args[1] == "--parser-counterexamples" {
        let mut records = Vec::new();
        let empty = ParsedGraph {
            internal_edges: Vec::new(),
            external_edges: Vec::new(),
            initial_state_cut_edges: Vec::new(),
            loop_names: Vec::new(),
            external_names: Vec::new(),
            node_name_to_internal: BTreeMap::new(),
        };
        let generated = generate_3d_expression(&empty, &Default::default())?;
        let input = EvaluationInput {
            external_momenta: Vec::new(),
            loop_spatial_momenta: Vec::new(),
            masses: Vec::new(),
            uniform_scale: None,
        };
        if args[1] == "--parser-counterexamples" {
            for (numerator, expected) in [
                ("-2**2", Some(-4.0)),
                ("2**3**2", Some(512.0)),
                ("2**4294967296", None),
            ] {
                let result = evaluate_expression(&empty, &generated.expression, numerator, &input);
                let actual = result.as_ref().ok().map(|r| r.value);
                records.push(serde_json::json!({"category":"C2-06","input":numerator,"expected_value":expected,"expected_error":expected.is_none(),"actual_value":actual,"error":result.as_ref().err().map(|e|format!("{e}")),"agrees_with_contract":match expected {Some(value)=>actual==Some(value),None=>result.is_err()}}));
            }
            serde_json::to_writer_pretty(
                File::create(&args[2])?,
                &serde_json::json!({"scope":"observational public-evaluator parser counterexamples","old_parser_method_bodies":std::env::var_os("CFF_PERF_OLD_PARSER").is_some(),"records":records}),
            )?;
            return Ok(());
        }
        for (numerator, expected) in [
            ("-2**2", -4.0),
            ("(-2)**2", 4.0),
            ("2**3**2", 512.0),
            ("2**-2", 0.25),
            ("2**-2**2", 0.0625),
            ("2**(-2)**2", 16.0),
            ("3*-2**2+1", -11.0),
            ("1**2147483647", 1.0),
            ("1**-2147483648", 1.0),
        ] {
            let actual =
                evaluate_expression(&empty, &generated.expression, numerator, &input)?.value;
            records.push(serde_json::json!({"category":"C2-06", "input":numerator, "expected":expected,"actual":actual,"passed":actual==expected}));
        }
        for numerator in [
            "2**2147483648",
            "2**-2147483649",
            "2**4294967296",
            "2**2**31",
            "2**-(-2097152)**3",
            "2**999999999999999999999999999999",
        ] {
            let result = evaluate_expression(&empty, &generated.expression, numerator, &input);
            records.push(serde_json::json!({"category":"C2-06", "input":numerator, "expected":"checked error", "actual":format!("{result:?}"),"passed":result.is_err()}));
        }
        for field in [
            "external momenta",
            "loop spatial momenta",
            "masses",
            "zero scale",
        ] {
            let mut malformed = input.clone();
            match field {
                "external momenta" => malformed.external_momenta.push([0.0; 4]),
                "loop spatial momenta" => malformed.loop_spatial_momenta.push([0.0; 3]),
                "masses" => malformed.masses.push(1.0),
                _ => malformed.uniform_scale = Some(0.0),
            }
            let result = evaluate_expression(&empty, &generated.expression, "1", &malformed);
            records.push(serde_json::json!({"category":"C2-08","input":field,"expected":"checked error","actual":format!("{result:?}"),"passed":result.is_err()}));
        }
        for empty_tree in [false, true] {
            let mut zero = generated.expression.clone();
            for orientation in &mut zero.orientations {
                for variant in &mut orientation.variants {
                    variant.denominator = three_dimensional_reps::tree::Tree::from_root(
                        three_dimensional_reps::HybridSurfaceID::Infinite,
                    );
                    if empty_tree {
                        variant
                            .denominator
                            .remove_node(three_dimensional_reps::tree::NodeId::root());
                    }
                }
            }
            for fused in [false, true] {
                let expression = if fused {
                    zero.clone().fuse_compatible_variants()
                } else {
                    zero.clone()
                };
                let result = evaluate_expression(&empty, &expression, "1", &input)?;
                records.push(serde_json::json!({"category":"C2-11","input":if empty_tree {"filtered empty denominator"} else {"Infinite denominator marker"},"fused":fused,"expected":0.0,"actual":result.value,"passed":result.value==0.0}));
            }
        }
        let mut tree = empty.clone();
        tree.node_name_to_internal = BTreeMap::from([("a".into(), 0), ("b".into(), 1)]);
        tree.internal_edges
            .push(three_dimensional_reps::graph_io::ParsedGraphInternalEdge {
                edge_id: 0,
                tail: 0,
                head: 1,
                label: "q0".into(),
                mass_key: Some("m".into()),
                had_pow: false,
                signature: three_dimensional_reps::MomentumSignature {
                    loop_signature: Vec::new(),
                    external_signature: Vec::new(),
                },
            });
        let invalid_bounds = generate_3d_expression(
            &tree,
            &Generate3DExpressionOptions {
                energy_degree_bounds: Some(vec![(999, 2)]),
                preserve_internal_edges_as_four_d_denominators: vec![0],
                ..Default::default()
            },
        );
        records.push(serde_json::json!({"category":"C2-07","input":"one-edge zero-loop tree; preserve edge0; bound(999,2)","expected":"checked error","actual":format!("{invalid_bounds:?}"),"passed":invalid_bounds.is_err()}));
        tree.internal_edges[0].signature.loop_signature = vec![1];
        let invalid_shape = three_dimensional_reps::validate_parsed_graph(&tree);
        records.push(serde_json::json!({"category":"C2-07","input":"edge loop signature [1]; declared zero loops","expected":"invalid graph without panic","actual":format!("{invalid_shape:?}"),"passed":!invalid_shape.ok}));
        let generation = generate_3d_expression(&tree, &Default::default());
        records.push(serde_json::json!({"category":"C2-08","input":"generate malformed loop signature","expected":"checked error","actual":format!("{generation:?}"),"passed":generation.is_err()}));
        for coefficients in [vec![i32::MAX, 1, -i32::MAX, -1], vec![i32::MAX, 1]] {
            let mut graph = empty.clone();
            graph.loop_names = vec!["x".into()];
            graph.node_name_to_internal = tree.node_name_to_internal.clone();
            graph.internal_edges = coefficients
                .iter()
                .enumerate()
                .map(|(edge_id, coefficient)| {
                    let mut edge = tree.internal_edges[0].clone();
                    edge.edge_id = edge_id;
                    edge.signature.loop_signature = vec![*coefficient];
                    edge
                })
                .collect();
            let result = three_dimensional_reps::validate_parsed_graph(&graph);
            let sum = coefficients.iter().map(|c| i64::from(*c)).sum::<i64>();
            let expected = if sum == 0 {
                BTreeMap::new()
            } else {
                BTreeMap::from([(0, vec![-sum]), (1, vec![sum])])
            };
            records.push(serde_json::json!({"category":"C2-08","input":coefficients,"expected_balance":expected,"actual_balance":result.vertex_balance_violations,"passed":result.ok==(sum==0)&&result.vertex_balance_violations==expected}));
        }
        let passed = records.iter().all(|r| r["passed"] == true);
        serde_json::to_writer_pretty(
            File::create(&args[2])?,
            &serde_json::json!({"source":"d55a0f3e","scope":"fresh unchanged public-contract cases on current shared library; arithmetic oracles independent","passed":passed,"records":records}),
        )?;
        if !passed {
            return Err("contract probe failed; no tests or production files changed".into());
        }
        println!("contract probes: {} passed", records.len());
        return Ok(());
    }
    let fixture: serde_json::Value = serde_json::from_reader(File::open(&args[1])?)?;
    let iterations = args.get(3).map_or(Ok(1), |x| x.parse::<usize>())?;
    let parsed = ParsedGraph {
        internal_edges: serde_json::from_value(fixture["internal_edges"].clone())?,
        external_edges: serde_json::from_value(fixture["external_edges"].clone())?,
        initial_state_cut_edges: Vec::new(),
        loop_names: serde_json::from_value(fixture["loop_names"].clone())?,
        external_names: serde_json::from_value(fixture["external_names"].clone())?,
        node_name_to_internal: serde_json::from_value(fixture["nodes"].clone())?,
    };
    let options: Generate3DExpressionOptions = serde_json::from_value(fixture["options"].clone())?;
    let validation = three_dimensional_reps::validate_parsed_graph(&parsed);
    if !validation.ok || !validation.vertex_external_balance_info.is_empty() {
        return Err(
            format!("fixture must satisfy complete momentum balance: {validation:?}").into(),
        );
    }
    let mut times = Vec::new();
    let mut final_generated = None;
    for _ in 0..iterations {
        drop(final_generated.take());
        let start = Instant::now();
        let generated = generate_3d_expression(&parsed, &options)?;
        times.push(start.elapsed().as_secs_f64());
        final_generated = Some(generated);
    }
    let generated = final_generated.ok_or("at least one iteration required")?;
    let masses: BTreeMap<String, f64> = serde_json::from_value(fixture["masses"].clone())?;
    let numerators: Vec<String> = serde_json::from_value(fixture["numerators"].clone())?;
    let mut values = Vec::new();
    let mut independent_oracles = Vec::new();
    for seed in [17, 41, 1337] {
        let input = EvaluationInput::deterministic(&parsed, seed, &masses, None)?;
        for numerator in &numerators {
            let value =
                evaluate_expression(&parsed, &generated.expression, numerator, &input)?.value;
            if !value.is_finite() {
                return Err(
                    format!("nonfinite complete value, seed={seed} numerator={numerator}").into(),
                );
            }
            values.push(serde_json::json!({"seed":seed,"numerator":numerator,"value":value}));
        }
        if fixture["oracle"].as_str() == Some("box_cubic_pinches_to_simple") {
            let mut simple = parsed.clone();
            simple.internal_edges.truncate(4);
            simple.internal_edges[3].head = 0;
            simple.node_name_to_internal.retain(|_, node| *node < 4);
            let reference = generate_3d_expression(
                &simple,
                &Generate3DExpressionOptions {
                    energy_degree_bounds: Some(Vec::new()),
                    ..Default::default()
                },
            )?;
            let simple_input = EvaluationInput {
                masses: input.masses[..4].to_vec(),
                ..input.clone()
            };
            let expected =
                evaluate_expression(&simple, &reference.expression, "1", &simple_input)?.value;
            let actual = evaluate_expression(
                &parsed,
                &generated.expression,
                "(dot(edges[3],edges[3])-0.49)**2",
                &input,
            )?
            .value;
            let scale = actual.abs().max(expected.abs()).max(f64::MIN_POSITIVE);
            let relative = (actual - expected).abs() / scale;
            if !expected.is_finite() || !actual.is_finite() || relative > 1.0e-10 {
                return Err(format!("independent pinch oracle failed: actual={actual} expected={expected} relative={relative}").into());
            }
            independent_oracles.push(serde_json::json!({"seed":seed,"actual":actual,"expected":expected,"normalized_error":relative}));
        }
    }
    let result_path = Path::new(&args[2]);
    let expression_path = result_path.with_extension("expression.json");
    serde_json::to_writer(File::create(&expression_path)?, &generated.expression)?;
    let record = serde_json::json!({
        "fixture":fixture["id"], "classification":fixture["classification"],
        "generation_seconds":times, "iterations":iterations,
        "internal_edges":parsed.internal_edges.len(), "loops":parsed.loop_names.len(),
        "validation":format!("{validation:?}"),
        "orientations":generated.expression.orientations.len(),
        "variants":generated.expression.orientations.iter().map(|o|o.variants.len()).sum::<usize>(),
        "source_energy_degree_bounds":generated.source_energy_degree_bounds,
        "core_sign":generated.core_global_prefactor_sign.factor(),
        "denominator_sign":generated.denominator_only_global_prefactor_sign.factor(),
        "energy_factor_components":format!("{:?}", generated.energy_factor_components),
        "values":values,"independent_oracles":independent_oracles,
        "expression_file":expression_path,"expression_bytes":std::fs::metadata(&expression_path)?.len()
    });
    serde_json::to_writer_pretty(File::create(result_path)?, &record)?;
    println!(
        "{}",
        serde_json::json!({"fixture":fixture["id"],"generation_seconds":record["generation_seconds"],"values":record["values"].as_array().unwrap().len(),"orientations":record["orientations"],"variants":record["variants"]})
    );
    Ok(())
}

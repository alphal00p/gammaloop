import concurrent.futures,hashlib,json,os,pathlib,subprocess,time
r=pathlib.Path('/tmp/cff-change-audit/cff-perf');binary=r/'cff_audit';out=r/'contracts';out.mkdir(exist_ok=True)
rows=[]
def run(job):
 name,mode,flags,cpu=job;env=os.environ.copy()
 for key in list(env):
  if key.startswith(('CFF_PERF_','CFF_AUDIT_','SPENSO_')):env.pop(key)
 env.update({'RAYON_NUM_THREADS':'1','INSTA_UPDATE':'no',**flags})
 result=out/(name+'.json');log=out/(name+'.log');cmd=['taskset','-c',str(cpu),'timeout','--signal=TERM','--kill-after=5s','30s',str(binary),mode,str(result)]
 start=time.monotonic()
 with log.open('wb') as stream:process=subprocess.run(cmd,stdout=stream,stderr=subprocess.STDOUT,env=env)
 return {'name':name,'command':cmd,'environment_overrides':{'RAYON_NUM_THREADS':'1','INSTA_UPDATE':'no',**flags},'exit_code':process.returncode,'wall_seconds':time.monotonic()-start,'output':json.loads(result.read_text()) if result.exists()else None,'result':str(result),'log':str(log)}
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
 rows=list(pool.map(run,[('current-contracts','--contract-probes',{},16),('current-parser','--parser-counterexamples',{},17),('historical-parser-methods','--parser-counterexamples',{'CFF_PERF_OLD_PARSER':'1'},18)]))
d={'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'source':json.loads((r/'provenance.json').read_text()),'runs':rows};(out/'manifest.json').write_text(json.dumps(d,indent=2)+'\n')
for row in rows:print(row['name'],row['exit_code'],row['output'])
assert all(row['exit_code']==0 for row in rows)
assert rows[0]['output']['passed']
assert all(x['agrees_with_contract'] for x in rows[1]['output']['records'])
assert [x['actual_value'] for x in rows[2]['output']['records']]==[4.0,64.0,1.0]
assert not any(x['agrees_with_contract'] for x in rows[2]['output']['records'])

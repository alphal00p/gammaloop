import hashlib,json,pathlib,subprocess,time
r=pathlib.Path('/tmp/cff-change-audit/cff-perf');target=pathlib.Path('/common/dev/gammaloop/higher-power-energies-review/target/dev-optim');source=r/'source/crates/three-dimensional-reps/examples/cff_audit.rs'
cmd=['taskset','-c','16-23','/tmp/raised-stack/run','env','CARGO_CRATE_NAME=cff_audit','rustc','--edition=2024','--crate-name','cff_audit','-C','opt-level=2','-C','debug-assertions=on','-C','overflow-checks=on','-C','debuginfo=2','-C','codegen-units=256','-C','linker=/nix/store/vdaz6sk455r8sbpi7wzaf9vlz5i9yyvx-gcc-wrapper-15.2.0/bin/gcc','-L',f'dependency={target}/deps','-L',f'native={target}/build/gmp-mpfr-sys-2c9c0b34e622e63a/out/lib']
dependencies=[]
for crate,tag in [('three_dimensional_reps','5a320640c769183c'),('serde_json','8d5a1b6683fc5257')]:
 p=r/f'lib{crate}-{tag}.rlib';cmd+=['--extern',f'{crate}={p}'];dependencies.append({'crate':crate,'path':str(p),'sha256':hashlib.file_digest(p.open('rb'),'sha256').hexdigest()})
cmd+=[str(source)];steps=[]
for stage,options in [('check',['--emit=metadata','-o',str(r/'timed-harness.rmeta')]),('build',['-o',str(r/'cff_audit_timed_v2')])]:
 command=cmd+options;start=time.monotonic();log=r/f'timed-harness-v2-{stage}.log'
 with log.open('wb')as stream:result=subprocess.run(command,stdout=stream,stderr=subprocess.STDOUT)
 steps.append({'stage':stage,'command':command,'exit_code':result.returncode,'seconds':time.monotonic()-start,'log':str(log)})
 if result.returncode:break
(r/'timed-harness-build-v2.json').write_text(json.dumps({'scope':'Standalone main relink against frozen exact CFF audit rlib; optimization level2 with development checks, no library production change. --skip-probes only changes post-generation evaluator loop.','source_sha256':hashlib.file_digest(source.open('rb'),'sha256').hexdigest(),'dependencies':dependencies,'steps':steps},indent=2)+'\n')
assert all(s['exit_code']==0 for s in steps)
print('Timed harness frozen',hashlib.file_digest((r/'cff_audit_timed_v2').open('rb'),'sha256').hexdigest())

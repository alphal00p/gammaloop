# Shared CFF: fresh correctness and performance evidence

Pinned source: `d55a0f3e9d25e5c64bdb9ef9fb57749ecf680390`. These are isolated mechanism ablations against the final code and dependencies, not executions of an entire historical release. No repository production source or existing test was changed. Instrumentation and inputs are retained beside this report.

Exact base caching has a measurable benefit on the reached high-rank cases. Neither streaming intervention demonstrates a speed or resident-memory benefit on this fixture set. Completed-product/root compaction adds measurable cost without changing the complete output in the physical quartic-gluon diagnostic; that is a scoped finding requiring a representative multi-component follow-up before removing the mechanism.

## Measurements

Six fresh processes per fixture/variant, after one excluded warmup; forward/reverse variant order alternates by round. Every observation is pinned to CPU 9 with one Rayon worker; benchmark families share a measurement lock. The host is not exclusive (AMD EPYC 9754, boost enabled). Each process generates once. Times below are generation-only mean ± sample standard deviation in milliseconds. Complete JSON serialization and validation are outside that timer.

| Fixture | Current | Eager layers | Eager parent fanout | No base cache | No compaction |
|---|---:|---:|---:|---:|---:|
| box_cubic_rank4 | 55.208 ± 5.258 | 55.471 ± 4.889 | 57.720 ± 6.413 | 108.235 ± 7.318 | 59.550 ± 5.713 |
| independent_bubbles_rank2 | 1.310 ± 0.400 | 1.126 ± 0.025 | 1.182 ± 0.044 | 1.120 ± 0.010 | 1.092 ± 0.030 |
| physical_double_triangle_affine | 0.998 ± 0.017 | 1.005 ± 0.020 | 1.002 ± 0.015 | 1.012 ± 0.035 | 1.007 ± 0.027 |
| physical_double_triangle_dotted | 7.870 ± 1.625 | 6.947 ± 0.092 | 7.422 ± 0.894 | 7.938 ± 1.567 | 7.774 ± 1.344 |
| sunrise_quartic_rank4 | 21.397 ± 2.748 | 20.939 ± 2.561 | 20.522 ± 2.190 | 35.349 ± 3.795 | 18.374 ± 1.491 |
| physical_double_triangle_quartic_gluon | 1474.612 ± 224.815 | 1302.847 ± 67.058 | 1330.942 ± 124.898 | 2357.704 ± 44.825 | 1154.177 ± 34.101 |

Raw means, medians, minima, maxima and RSS: `timed-final/summary.json`. All 210 observations completed (30 excluded warmups, 180 measured runs), with 210/210 complete-expression hash and metadata matches to the same-variant correctness trace. The complete guarded run took 91.191 seconds after a 22.104-second lock wait; peak guarded process-tree RSS was 68.727 MB. No retries or snapshot updates.

On the cubic box, sunrise and physical quartic topology respectively, disabling the base cache increases mean generation time by 1.96×, 1.65× and 1.60×. Stress medians are 1.434 seconds current versus 2.376 seconds without cache. Its traced lower-sector base builds/hits are 14/104 and direct-base builds/hits 14/42; disabling caches changes builds to 118 and 56. Current peak child RSS is 44.089 MB versus 40.940 MB without cache: retained cache storage has a small visible tradeoff.

For physical quartic-gluon compaction, current/no-compaction medians are 1.434/1.156 seconds. Disabling compaction is faster in all six paired rounds, with median paired ratio 0.812. Both produce the same 22,405,353-byte complete expression (2,556 maps; 14,280 variants) and essentially equal 44 MB peak RSS. There are 98 completed product compactions and seven root compactions, all products with one component. This result does not establish that compaction is unnecessary when multiple components generate equal chains; the small box also does not show the same consistent timing direction.

The stress fixture reaches streaming branches, but only single-component products, with maximum next-parent fanout 252. The independent-bubbles fixture reaches two-component products but is too small to establish a memory advantage. Current stress time is noisier and higher than either eager variant, with indistinguishable RSS. Thus the prior 30 GB GL16 motivation is recorded source evidence, not independently reproduced or validated as a per-mechanism memory saving here.

## Inputs and correctness

The affine double triangle uses the physical importer-resolved SM gluon/quark graph, exact two-loop routing and a nonzero quark mass 1.7. Its probes are energy-polynomial witnesses, not the complete spin/color numerator. The dotted and quartic-gluon cases add serial copies of the original gluon line with owner-compatible higher energy capacities; they are diagnostic UV-like stress inputs, not certified Taylor sectors. Parent experiments separately cover the full physical numerator. The remaining inputs are existing cubic box, quartic sunrise and independent-bubble graphs, with external hairs supplied where needed for complete vertex balances. Every parsed fixture is required to validate successfully with no external-balance remainder.

All five variants passed 240 complete numerical observations across the five smaller fixtures, plus 45 nonzero complete observations for the stress fixture (three deterministic points per polynomial). The cubic box additionally passed 15 independent denominator-pinch oracles, with maximum error 1.507e-15. All 30 post-generation skip-probe preflights preserved the full expression bytes and metadata from their fully evaluated correctness traces. Timed runs skip only the already-certified downstream numerical evaluation; complete expressions are still written and matched. `trace-correctness-summary.json`, `stress-trace/manifest.json`, `skip-probes-preflight-v2/manifest.json` and `timed-final/comparisons.json` retain the evidence.

The standalone public-contract probe passes 28/28 checks: arithmetic values and overflow errors, malformed shapes and zero scale, zero-valued/fused denominator trees, invalid bound 999, malformed graph rejection and wide signed momentum balances. A separately gated exact historical parser-method replay reproduces three bugs: `-2**2` returned 4 (current -4), `2**3**2` returned 64 (current 512), and `2**4294967296` returned 1 (current reports an exponent error). The replay uses original methods from the parent of review commit `9c8aa0f9`, with current surrounding code/dependencies; it is not a whole old-crate executable. See `contracts/manifest.json`, `contracts/historical-parser-methods.json`, `parser-ablation.json` and `parser-ablation.patch`.

## Resource and instrumentation boundaries

All timed comparisons use binary `cff_audit_timed_v2`, SHA-256 `0eb897269d461e7cde8f74798647e268525982632731e67253fe69c6ab40cb4e`, directly linked against frozen instrumented CFF rlib SHA-256 `660e2aa1deed0bb014387adf3377feb89576b884c8de2bd38d28e22cb2294785`. Instrumented crate check and build passed; the final timed-main change only skips downstream probes and buffers identical JSON writes. `provenance.json`, `timed-harness-build-v2.json`, `compile_timed.py`, the saved harness sources and patch files make this reviewable. Parent independently reviewed both production ablation patches before execution; review receipt is `independent-review.json`.

Initial trace-v1 RSS is invalid: reading the whole binary to hash it raised the launcher high-water mark inherited by each child. Streaming hashing corrected this before final timing. Tiny children still have a 15.8–19.0 MB launcher RSS floor, so these results do not resolve tiny memory differences. Reported per-child RSS includes startup, generation and output; it is neither allocation accounting nor generation-only live memory. The external watchdog separately measures process-tree RSS.

An initial unbuffered full-expression writer dominated wall time through tiny writes; buffering preserves the exact output and removed that instrumentation cost before final timing. The abandoned unbuffered preflight was explicitly stopped and is not performance evidence. It must not be described as a slow evaluator. Resource-lock setup rejections and all other instrumentation corrections are retained in `instrumentation-corrections.json`; no failing product test was changed.

No result here measures independent-occurrence handling against the old merged representation, core UV assignment proposals, core winner/loser caches, Vakint modes or Rational-versus-Atom coefficient storage. Those need their separately scoped experiments or are feature/domain-model choices. No manual PySecDec integration was executed.

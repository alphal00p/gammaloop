"""Review final published PDF text/geometry and receipt-backed table values."""
from pathlib import Path
import hashlib,json,re,subprocess,xml.etree.ElementTree as ET
root=Path('/tmp/cff-change-audit');folder=Path('/common/dev/gammaloop/higher-power-energies-review/docs/architecture');art=root/'foundation-bugs/artifacts'
reports=[]
for stem,prefix,expected_pages in [('raised-energy-cff-motivation-audit','audit-report-final',13),('raised-energy-cff-stack-review','stack-report-final',6)]:
 for mode,suffix in [('bbox-layout','bbox.html'),('raw','raw.txt')]:
  subprocess.run(['/tmp/raised-stack/run','pdftotext','-'+mode,str(folder/f'{stem}.pdf'),str(art/f'{prefix}-{suffix}')],check=True)
 pages=[node for node in ET.parse(art/f'{prefix}-bbox.html').iter() if node.tag.split('}')[-1]=='page'];assert len(pages)==expected_pages
 bounds=[]
 for number,page in enumerate(pages,1):
  words=[node for node in page.iter() if node.tag.split('}')[-1]=='word'];assert words
  width=float(page.attrib['width']);height=float(page.attrib['height'])
  for word in words:
   x0,y0,x1,y1=(float(word.attrib[key]) for key in ('xMin','yMin','xMax','yMax'))
   assert 0<=x0<=x1<=width and 0<=y0<=y1<=height,(stem,number,word.text)
  bounds.append({'page':number,'words':len(words),'x_min':min(float(word.attrib['xMin'])for word in words),'x_max':max(float(word.attrib['xMax'])for word in words),'y_min':min(float(word.attrib['yMin'])for word in words),'y_max':max(float(word.attrib['yMax'])for word in words),'outside_page':0})
 text=(art/f'{prefix}-raw.txt').read_text();flat=' '.join(text.split())
 sources=[{'path':str(folder/f'{stem}.{suffix}'),'sha256':hashlib.sha256((folder/f'{stem}.{suffix}').read_bytes()).hexdigest(),'bytes':(folder/f'{stem}.{suffix}').stat().st_size} for suffix in ('md','typ','pdf')]
 reports.append({'report':stem,'pages':expected_pages,'sources':sources,'all_text_boxes_within_pages':True,'page_bounds':bounds})
 if stem.endswith('motivation-audit'):
  required=['Fresh validation evidence','308 successful observations: 264 measured, 44 warm-ups','32 storage smokes pass','175 successful observations: 150 measured, 25 warm-ups','28 successful observations: 24 measured, four warm-ups','48 executed observations out of 48 planned','current takes longer than each ablation in both rounds','full build feature sets are not identical','private-stage pass-through','2.00000000000000','cause or a general regression']
  checks={needle:needle in flat for needle in required};assert all(checks.values()),checks
  assert 'pending in draft' not in flat and 'Numerator-matching measurements pending' not in flat
  assert text.count('-2**2')>=2 and text.count('2**3**2')>=2
  expected_ids={f'C{owner}-{number:02}' for owner,count in [(1,24),(2,11),(3,12),(4,11),(5,6),(6,8),(7,1)] for number in range(1,count+1)}
  assert set(re.findall(r'C[1-7]-\d\d',text))==expected_ids
  reports[-1]['fresh_count_and_limit_text_checks']=checks;reports[-1]['all_73_motivation_ids_present']=True;reports[-1]['literal_power_syntax_preserved_in_section_and_inventory']=True
 else:
  assert 'private-stage pass-through' in flat and 'JSON encoding fails' in flat
inv=folder/'raised-energy-cff-motivation-inventory.json';inventory=json.loads(inv.read_text())
assert inventory['logical_change_count']==73 and inventory['commit_path_count']==579 and inventory['distinct_path_count']==505
assert {row['id'] for row in inventory['changes']}==expected_ids
summary=json.loads((root/'feyngen-perf/e2e-physical-two-rounds/summary.json').read_text());md=(folder/'raised-energy-cff-motivation-audit.md').read_text()
for grouping in ('sign','scalar'):
 for workers in (1,4):
  cells=[];ratios=[]
  for mode in ('current','old-comparator','global-lock','both'):
   row=summary['variants'][f'{grouping}-{workers}workers-{mode}']['wall_seconds'];cells.append(f"{row['min']:.3f}–{row['max']:.3f}")
   if mode!='current':
    row=summary['paired_e2e_intervention_over_current_ratios'][f'{grouping}-{workers}workers-{mode}']['wall_seconds'];ratios.append(f"{row['min']:.3f}–{row['max']:.3f}")
    if workers==4:assert row['max']<1
  assert '| '+f'{grouping} / {workers} workers'+' | '+' | '.join(cells)+' |' in md
  assert '| '+f'{grouping} / {workers} workers'+' | '+' | '.join(ratios)+' |' in md
receipt={'scope':'Final published PDF text, metadata and per-word page-bound checks; table/count/inventory receipt linkage. Count cells use raw text order because layout extraction interleaves table columns. Main stack pages 1–2 were independently viewed before the final wording refinement; parent visually reviews all final audit pages. Bounding boxes alone are not a complete visual review.','reports':reports,'inventory':{'path':str(inv),'sha256':hashlib.sha256(inv.read_bytes()).hexdigest(),'logical_categories':73,'commit_path_records':579,'distinct_paths':505},'final_e2e_wall_and_ratio_tables_exactly_match_summary':True,'four_worker_current_slower_all_12_paired_relations':True,'fresh_counts_match_independently_reviewed_receipts':True}
(root/'root-independent-final-pdf-review.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'pdf_pages':[r['pages'] for r in reports],'all_text_bounds_inside_pages':True,'all_73_ids_present':True,'fresh_counts_pass':True,'e2e_tables_pass':True},indent=2))

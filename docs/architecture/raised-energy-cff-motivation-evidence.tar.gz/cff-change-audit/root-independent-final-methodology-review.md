# Independent review of benchmark methodology

Reviewer: foundation audit agent. Scope: read-only review of `root/run_matrix.py`, `root/analyze_matrix.py`, `root/recover_matrix_guard.py`, `root/sum-pressure/compare.py`, `physical/compare_outputs_live.py`, `root/instrumentation-complete.patch`, configuration, trace receipts and the evolving contraction manifest. No extra native tests, algebra-heavy probes or measurements were run for this review.

The methodology supports bounded, descriptive comparisons when each reported speed claim is tied to an activated intervention and a completed semantic comparison. It does not establish a universally best scheduler or a symbolic proof of every captured physical output.

## Findings requiring explicit treatment

1. **Resumed input provenance must be amended.** The inspected runner initially checked only the executable SHA when resuming. Its local config and resumed manifest config were different objects, leaving the later BNL fixture without an input SHA in the saved manifest. **Resolved in metadata.** I checked `resume-provenance-check.json`, independently rehashed all three current inputs against the final manifest, verified the BNL hash against `physical/bnl/current-api-migrations.json`, and confirmed effective config equality. The runner now guards future resumes. Preserve the explicit fact that BNL was amended after the active run; it was not initially stored in that manifest.

2. **Resource termination is not an observed child exit or a numerical failure.** The ttH and BNL `SmallestDegree` warm-ups exceeded the 8 GB process-tree guard at 8,331,112,448 and 8,452,485,120 bytes. The guard killed the whole driver, so `wait4` did not return for either observation. **Resolved in annotations.** `guard-annotations.json` and both manifest rows mark `exit_code_observed=false`:137 is the observed outer-supervisor status reused in the record, not a child wait4 return. The guard event is authoritative. The first ttH observation was reconstructed from preceding manifest order and its retained log; the second has the explicit `in_progress` command receipt. Neither has a valid completion time or peak-child-RSS reading, and neither supports a timing ratio. Skipping subsequent identical pairs is consistent with the no-retry rule.

3. **Semantic comparison must cover every distinct successful output per input.** Runner success and byte hashes alone establish neither algebraic equality nor alias correctness. The final comparison should map every distinct result hash represented in successful measured runs to a passed comparison receipt; identical hashes may reuse that receipt. The analysis script explicitly leaves this as a separate requirement. The two failed resource cases have no completed outputs to certify.

4. **Captured-output probes are finite exact samples.** `compare_outputs_live.py` evaluates the complete root and every alias definition at shared primitive assignments, resolves aliases to a fixed point, rejects unresolved aliases, and checks exact zero residuals. This avoids assigning arbitrary values to aliases and avoids reparsing the problematic canonical complex serialization. Its checks remain three formal algebraic points: pi is 3, selectors are 1, and BNL kinematics/masses are specially chosen. These can miss differences that vanish on those assignments. They are not a general symbolic identity or physical phase-space validation. The code and report already disclose this; retain the qualification wherever “complete values” is used.

5. **The rank-four oracle is independent but sampled in its scalar parameter.** `sum-pressure/compare.py` independently builds `c0*(q0·q2)^4+c1*(q1·q2)^4`, with Q3 temporal components zero, exact spatial metric signs, and Python Fraction coefficient sums. It checks complete contraction values at three E/component assignments and resolves full aliases. This is substantially stronger than comparing private sum/cache counts, but three E values do not prove equality of the entire high-degree rational coefficient function. Do not upgrade this to a full symbolic identity claim.

## Activation and intervention fidelity

- The old-kernel switch reinstates the original sparse-only grouped specialization while retaining current dependencies and all other production behavior. Dense/mixed inputs therefore use the original generic fallback. The fresh foundation matrix independently confirms complete symbolic component equality in all 32 old/current DD/DS/SD/SS combinations, covering 4D/8D and full/1-of16 occupancy. The physical g–g trace activates dense multi-index contraction, so its old/new kernel comparison is meaningful.
- g–g and ttH create **zero scalar aliases** at threshold 4096; BNL creates **four**. An old-alias ratio on either of the first two inputs is an inactive control and must not be sold as a benefit. BNL and the weighted-rank-four alias cases activate the changed registration path.
- No automatic lazy-sum activation appears in the inspected g–g/ttH/BNL traces. The dedicated weighted-rank-four fixture does activate `mode=lazy`; old-eager removes it, and alias compression keeps the sums small enough not to trigger it. Thus deferral claims belong to that stress fixture, not to inert old-eager flags in physical runs.
- The weighted-rank-four source is explicitly synthetic and isolates large scalar coefficient broadcasting. Alias-disabled deferred versus alias-disabled old-eager is the clean deferral pair. Aliased current versus aliased old registration is the registration pair. Cross-pair differences also change aliasing and must be labeled accordingly.
- The `SmallestDegree` environment switch dispatches the existing strategy directly even though the diagnostic CLI argument remains `intermediate-cost`; report the effective strategy from environment plus command. The other five presets use the existing generic strategy configuration.
- The wider patch's Feyngen global mutex is a **lookup serialization ablation**, not a byte-for-byte restoration of the former map architecture. Its repeated-comparator loop times the actual comparison plus one preallocated Vec push; equality assertions are outside timing. No lock-contention improvement can be inferred from a one-worker run or an input without overlapping bucket lookup work.
- `CFF_AUDIT_NO_EXACT_CACHE` sets the entire optional cache to None, also preventing count memoization. Its result measures total-cache disabling. `NO_COUNT_MEMO` retains completed expression lookup and isolates the separate memo table more narrowly. `ONE_PROPOSAL` changes proposal selection work and requires equivalent complete output certificates, not an assumption that row counts must stay equal.

## Timing, resources and accounting

The runner clears inherited audit/SPENSO options, sets one Rayon worker, pins CPU 8, records commands and stage summaries, and alternates forward/reverse order for six measured rounds after one excluded warm-up per input/variant. Stage timers distinguish network execution, alias registration and resolution; wall time and RSS include parsing, output serialization and launcher effects. `analyze_matrix.py` reports descriptive distributions with sample counts and retains failed warm-ups separately. Its warm-up-only failures will not appear as ordinary measured statistical groups, so they must remain visible in the report's failed-run table.

With two failed `SmallestDegree` warm-ups, the completed three-input/nine-variant matrix should contain **177 observations: 175 successes and 2 resource terminations**. This is **150 successful measured runs + 25 successful warm-ups + 2 failed warm-ups**, with 12 later observations deliberately unattempted. The separate four-variant weighted-sum matrix should add 28 observations if all complete. The completed contraction manifest has now been independently checked: these exact counts hold, labels are unique, no `in_progress` remains, and successful outputs have four distinct hashes for g–g, three for ttH and three for BNL. `root-independent-count-check.json` records the group checks. The separate weighted-sum matrix is also independently checked: 28 unique successful observations, 24 measured plus 4 warm-ups, with three distinct output hashes.

Six balanced rounds support per-input descriptive comparisons. They do not measure every contraction tree, all tensor metrics, all models or all threading settings. Whole-machine contention remains an acknowledged limitation. Avoid significance claims for small differences with overlapping observed ranges, and keep process-tree guard bytes distinct from per-child `wait4` RSS.

## Final verification

Contraction count/label checks, effective config/input amendments and supervisor-status annotations are complete. Complete physical-output receipt coverage is now independently verified: 175 successful observations map to all ten distinct original output hashes (four g–g, three ttH, three BNL), and each representative passes all three exact shared algebraic points. Weighted-sum receipt coverage is also now independently verified: all 28 successful observations map to three distinct output hashes, each checked at all three seeds against the independent Fraction/component oracle (nine zero-residual records). These are finite complete-output samples with the limitations described above. No benchmark observation was rerun to repair metadata or the diagnostic literal-domain boundary.


The Feyngen old-body provenance was also checked through `feyngen-perf/prepare_intervention.py` and `intervention_manifest.json`: the generator extracts both comparator bodies directly from `26b57b786^`, qualifying only tracing macro/type references before gating them. The later repetition wrapper preserves those comparisons with a renamed candidate receiver. The global gate still retains current buckets, clone removal and zero-mask construction, as disclosed.

`root/validate_results.py` is correctly prepared to hash-check every successful dump, deduplicate only by exact complete-output hash, and compare all representatives per fixture under the measurement lock. It requires fresh output receipts and stops on a nonzero comparator result. These checks have now completed for all ten physical and three weighted-sum hashes; independent coverage joins verify their passed receipts, without upgrading the finite-probe scope to a symbolic identity proof.


## Draft report review

Read `report-draft.md`, its generator, all 24 C1 conclusion rows and the combined inventory header/path totals. The seven reproduced defect/factorization failures plus three syntax probes classification is accurate. C1-09 correctly leaves necessity unproved, C1-12 distinguishes optimization from missing contraction capability, and the 73-row mapping does not falsely claim 73 bugs.

Requested refinements before publication:

- The blanket 8 GB measurement-cap statement must account for the foundation family's 15 GB watchdog (its observed peak is small); state per-family caps rather than rewriting the actual commands.
- State 177 contraction observations explicitly: 175 successes plus 2 resource terminations.
- “Unnecessary cost” should mean “cost without demonstrated benefit on the tested inputs”; untested adapter boundaries prevent a universal necessity conclusion.
- Recommend public supported ambiguity behavior for the three private materializer tests, without inventing an error contract that the parser may not promise.
- Omit the unrelated 2,868 earlier-runtime total from this current-state report. Fresh evidence should stand on its own.
- Retain draft/pending qualifications for weighted-sum/core/Feyngen and complete physical-output comparisons until their receipts complete. C1-15's measured/independent-oracle conclusion must track the final weighted-sum evidence.

The report's factorization boundaries, exact Rational-versus-Atom distinction, narrow no-chain timing, multi-file pruning attribution, sampled physical-oracle limitations and “not every contraction tree” caveat are sound. Small BNL kernel differences should remain descriptive; the clear physical kernel gains are g–g and ttH. The reported 64-bit/software/platform scope must not imply cross-platform validation.


### Independent exact-literal and receipt-coverage check

`root-independent-semantic-coverage-check.py/.json` independently joins manifest hashes to successful comparator source hashes. I rehashed the original and derived g–g files and reconstructed the full parsed JSON copy: exactly 78 root literals change from `2.00000000000000` to `2`, each in the numeric context `-2.00000000000000*`; every other JSON value is identical. Decimal arithmetic proves exact value equality. The apparent file-size increase comes from JSON reformatting, not added algebra. The normalized output has no aliases. The original SHA maps through the explicit normalization ledger to the passed normalized-source SHA.

The retained setup failure is the unchanged strict comparator's `1.0`-only literal-domain assertion, before value comparison. `normalize_integral_output.py` writes a separate output copy, preserves the failed receipts, and changes only the diagnostic driver routing; it does not edit the comparator or production tests. Reading and hash-mapping receipts does not itself rerun their algebra; the original validator did stream-hash all successful dump files before executing comparisons. This independent check deliberately avoids heavy hashing or algebra outside the measurement lock.


### Reproduction-guide review

Read the top-level `README.md` against the actual foundation entry points. Source pins, measurement-lock ownership, per-family guards, stale-linkage exclusion, normalization ledger and finite-oracle limitations are accurate. Requested explicit `run_probes.py final` / `run_probes.py baseline-definitive` label arguments and the matching regenerated nextest-list prerequisite; bare `run_probes.py` cannot run. Also requested fully qualified foundation artifact paths and a distinction between separately linked foundation/powered probes and the storage probe's single current instrumented Spenso library with `CFF_AUDIT_OLD_KERNEL=1`. The eight-file foundation ablation does not by itself reproduce the old-kernel experiment.


### Final fresh-count review

Foundation timings have 308 successful process observations: 264 measured and 44 excluded warm-ups. The 32 successful storage smokes are additional. The physical family has 175 successes (150 measured, 25 warm-ups) plus two guard-terminated warm-ups, with twelve later observations unattempted. The weighted-sum family has 28 successes (24 measured, four warm-ups). Each of its three exact complete-output hashes now has all three independent Fraction-oracle seed records. `root-independent-semantic-coverage-check.json` certifies the full 13-hash receipt mapping across these two families. No heterogeneous headline test total is warranted.

README reproduction corrections are present: label/list prerequisites, fully qualified foundation paths, distinct two-library versus instrumented-single-library probe entry points, and the nonidentical baseline/current regression feature sets. The revised Markdown's fresh-count table agrees with the accepted manifests. Final rendered-document synchronization is now verified by `root-independent-final-pdf-review.json`: the published 13-page motivation audit includes the fresh-count table, feature caveat and corrected literal exponent syntax; the final six-page stack report is also checked. The earlier preliminary layout pilot is excluded from packaging.


### Whole diagnostic-process scheduler table

`root-independent-whole-process-table-check.json` independently recomputes all 16 completed input/preset medians from successful non-warm-up manifest observations, with exact equality to `analysis.json` and the displayed rounding. Intermediate-cost has the lowest observed whole-process median for ttH (0.675 s) and BNL (0.793 s). The BNL alias-resolution stage is 0.281458 s versus 1.436720–1.458206 s for atom/entry alternatives and 18.809667 s for result-rank-only. The report correctly distinguishes this downstream cost from the network timer and labels whole-process timing as the diagnostic child including parsing, full alias resolution and output, rather than full GammaLoop generation/integration. Whole-child RSS is not isolated intermediate allocation. No new measurement was performed for this table.


### Archive recipe review

The bounded static archive review identified and resolved three concrete issues: omission of 353 foundation `.atom` value dumps, omission of four exact serialized GL04 saved-state inputs needed for the inspection reproduction, and recoverable private-license fragments embedded in the distributed scanner. The revised recipe includes symbolic values and an exact state-file allowlist, excludes compiled outputs and source checkouts, and scans a generic full license format without embedding private material. Its 64-byte overlap covers the 54-byte pattern across chunk boundaries. `root-independent-package-design-review.json` records the revised source/README hashes and scope. No private wrapper or state payload was read. Actual archive integrity and payload scanning remain the packager's subsequent work.


### Final E2E and published-document review

`root-independent-e2e-review.json` independently checks all 48 successful E2E observations (16 excluded warm-ups, 32 measured), 16 variants, the exact forward/reverse schedule, shared CPU mask 8–11 and the 1/4-worker settings. Every small input card is reconstructed and rehashed; all medians/ranges/paired ratios are recomputed. Every complete 36-file export map joins to the validated default and the separate fresh 1,728-file hash-verification receipt. The four-worker current path is slower than every ablation in both measured rounds; all twelve paired relations satisfy this, and the report states it. Two observations per variant do not identify a cause or support a precise general speedup/regression claim.

The final published motivation PDF has 13 pages and the main stack PDF has six. Every text bounding box is inside its page. Raw text confirms the fresh counts, finite-oracle limits, feature-set caveat, private-test distinction, all 73 motivation IDs and both literal power expressions in the main section and inventory row. All E2E wall-time/ratio table cells match the independently verified summary. `root-independent-final-pdf-review.json` pins final Markdown, Typst, PDF and inventory hashes. The parent confirmed completion of the full 13-page final visual review, including corrected exponent syntax; this reviewer independently viewed the main stack report's first two pages and checked final text/geometry across both PDFs.

All assigned bounded methodology, count, semantic-receipt, archive-design and published-document reviews are complete. Archive byte packing/integrity scanning is subsequent parent-owned work; the recipe review does not claim to have scanned an archive that did not yet exist. No production source, product test expectation or benchmark observation was modified by this independent review.

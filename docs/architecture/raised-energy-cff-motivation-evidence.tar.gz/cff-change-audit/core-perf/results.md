# Core CFF caches and bounded assignment proposals

Pinned source: `d55a0f3e9d25e5c64bdb9ef9fb57749ecf680390`. These are independently reviewed narrow ablations in the final code and dependencies. All occurrence capacities, factor owners, reconstruction certificates, rational arithmetic and winner/assignment coupling remain. No repository source/test/history was edited.

## Complete-output evidence

All four variants complete on both GL04 inputs: the existing owned product of two momentum contractions and the owner-specific temporal-square regression. For each input, all nine computed forest/node DOT files are byte-identical across variants, including every complete `full_num` expression; all three full inspection JSON values are exactly identical and finite. The real values are small but nonzero (roughly 1e-21 to 2e-14). The comparison uses no absolute tolerance floor and does not treat a small total as zero. Complete counterterm expressions provide a stronger discriminating check than the near-zero totals alone. No numerator expansion or expression-format regression test was introduced.

Cards preserve the scalar-matrix process `scalar_1 > {scalar_0 scalar_0, scalar_0 scalar_0 scalar_1}`, original DOT factor owners, UV/local/integrated and threshold subtraction, projected local-4D mode, SingleParametric evaluation, summed graphs/orientations, no LMB multichanneling, m_UV=20 and mu_r=3. Exact coordinates and commands are in the manifests. Earlier implicit-process preflights had a different cut set and are excluded.

## Trace coverage

| Input / variant | Scored proposals | Count hits | Actual shared-CFF generations | Alternative wins | Complete workflow |
|---|---:|---:|---:|---:|---|
| GL04 / one-proposal | 165 | 93 | 72 | 0 | yes |
| GL04 / no-count-memo | 187 | 93 | 94 | 0 | yes |
| GL04 / no-exact-cache | 187 | 0 | 187 | 0 | yes |
| GL04 / current | 187 | 93 | 94 | 0 | yes |
| GL04-temporal-square / one-proposal | 51 | 15 | 36 | 0 | yes |
| GL04-temporal-square / no-count-memo | 65 | 15 | 50 | 0 | yes |
| GL04-temporal-square / no-exact-cache | 65 | 0 | 65 | 0 | yes |
| GL04-temporal-square / current | 65 | 15 | 50 | 0 | yes |
| GL16 / one-proposal | 1793 | 1753 | 40 | 0 | 180s timeout |
| GL16 / no-count-memo | 2272 | 1438 | 834 | 1 | 180s timeout |
| GL16 / no-exact-cache | 1783 | 0 | 1783 | 1 | 180s timeout |
| GL16 / current | 2689 | 2637 | 52 | 1 | 180s timeout |

Disabling exact caching increases actual shared-CFF generations from 94 to 187 on GL04 and 50 to 65 on temporal-square. Retaining only winner payloads gives the same calls/hits as current: loser-count cache benefit is unexercised on these inputs. First-proposal-only removes 22/14 trial generations. All eleven GL04 candidate groups have map counts [14,20,20], and all seven temporal-square groups [32,56,44]; the first proposal always wins. These completed cases therefore cannot establish a benefit from scoring alternatives.

All four distinct GL16 trace variants hit the explicit 180-second cap before any complete inspection or computed UV export. They are censored, not passing comparisons, and GL16 is excluded from measured rounds without retries. Peak guarded trace process-tree RSS was 545.083 MB: these are time limits, not reproductions of the original 30 GB failure. The trace invocation took 994.457 seconds including its lock wait.

Partial GL16 traces reach both mechanisms. Bounds [(9,4),(10,1),(11,1)] / [(9,4),(10,2)] / [(9,4),(11,2)] produce map counts [1200,1224,1104]; candidate three improves the selected objective by 96 maps (8%). In the common 2,272-event prefix of current/no-count-memo, matching proposal/bounds/map-count fields have 52 versus 834 unknown contenders. The 1,783-event prefix with no exact cache has 52 versus 1,783. This demonstrates avoided repeated work, not complete-value equality or end-to-end speedup. Those fields are not a unique canonical-source key and all GL16 workflows are censored. See `traces/beneficial-proposal-witness.json` and `traces/partial-prefix-comparison.json`. A further comparison matches all 52 paired full parsed-source/bounds records for current versus either ablation, and 508 for no-count-memo versus no-exact-cache. Cache hits omit parsed_source; EnergyEdgeIndexMap and options beyond bounds are unlogged. This therefore does not establish every complete canonical-key identity. Details: `traces/partial-source-comparison.json`.

## Balanced measurements

The measured unit is one complete fresh CLI workflow: generation, three inspections and computed forest export. It includes repeated work performed by the public exporter, startup and output, rather than isolating the core CFF function. Trace logging is disabled. Six forward/reverse alternating rounds follow one excluded warmup per fixture/variant. Children use CPU 8 and one Rayon worker; the common lock prevents overlapping audit benchmark families. The host is nonexclusive. Each child has a 180-second cap; the family has an 8 GB process-tree RSS guard. No snapshots or retries.

| Input / variant | Runs | Wall mean ± sample SD (s) | Median (s) | Peak child RSS (MB) |
|---|---:|---:|---:|---:|
| GL04 / current | 6 | 15.6009 ± 0.2912 | 15.6221 | 54.989 |
| GL04 / no-count-memo | 6 | 15.8009 ± 0.3918 | 15.6427 | 54.350 |
| GL04 / no-exact-cache | 6 | 15.7289 ± 0.5760 | 15.5521 | 54.489 |
| GL04 / one-proposal | 6 | 15.4375 ± 0.3936 | 15.4162 | 54.436 |
| GL04-temporal-square / current | 6 | 5.7461 ± 0.2847 | 5.8021 | 44.327 |
| GL04-temporal-square / no-count-memo | 6 | 5.7656 ± 0.3004 | 5.7929 | 44.306 |
| GL04-temporal-square / no-exact-cache | 6 | 5.7785 ± 0.3130 | 5.8293 | 44.302 |
| GL04-temporal-square / one-proposal | 6 | 5.6147 ± 0.5151 | 5.7457 | 44.376 |

All 56 timing/warmup observations match the complete trace reference DOT files and inspection JSON exactly. Each cell has six measured observations; warmups are excluded. Per-child RSS includes the whole child/launcher, not isolated CFF allocations or summed process-tree usage. Raw distributions and commands are in `timings/manifest.json` and `timings/analysis.json`.

## Interpretation boundaries

The completed workflow means differ by only about 0.3–2.3 percent across these interventions, with sample spreads of roughly 0.28–0.58 seconds. The six-round measurements do not establish a convincing end-to-end time or RSS benefit on these two completed inputs. Traced reuse and avoided generations remain distinct evidence; neither a reduced call count nor the censored GL16 candidate improvement is presented as a measured full-workflow speedup.

Winner caching has observable reuse on complete GL04 workloads. Loser-count memoization and bounded candidate scoring obtain stronger reachability motivation from GL16, whose completed comparison is unavailable within the cap. One-proposal mode still constructs and certifies the full candidate list; it measures omitted trial generation/scoring and downstream effects, not removal of planning. No-exact-cache disables winner payload and loser-count caches while retaining current independent capacities; it does not reconstruct the historical union-envelope cache.

This core cache is distinct from the shared engine base cache in `../cff-perf/results.md`. These results do not apportion independent repeated occurrences, rank-envelope analysis, factor-preserving UV simplification, scheduling or Vakint input modes. No manual PySecDec integration ran. Capabilities and simpler invariants can motivate an architecture without an unmeasured speedup claim.

`execution-provenance.json` records binary/source/card/DOT/driver hashes and exact commands. `independent-review.md` reviews intervention boundaries; `prepare.py` and `intervention-description.json` specify them. `analyze.py` compares every complete output, records relative errors without a floor, groups proposal metrics and preserves failures/censoring.

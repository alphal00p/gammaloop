from pathlib import Path
import hashlib,json
p=Path('/tmp/cff-change-audit/core-perf/traces');runs={}
for variant in ['current','no-count-memo','no-exact-cache']:
 scores=[];pending=None
 for file in (p/f'GL16-{variant}-warmup/state/logs').glob('*'):
  for line in file.open():
   event=json.loads(line)
   if event.get('message')=='Generating exact CFF at its term-local capacity':
    assert pending is None
    pending={k:event[k]for k in ['parsed_source','term_local_bounds']}
   if event.get('message')=='Scored bounded exact-CFF assignment proposal':
    assert (pending is None)==event['count_memo_hit']
    if pending is not None:assert pending['term_local_bounds']==event['bounds']
    scores.append({'score':{k:event[k]for k in ['proposal','bounds','native_source_maps']},'source':pending});pending=None
 runs[variant]=scores
result=[]
for name in ['no-count-memo','no-exact-cache']:
 a=runs['current'];b=runs[name];n=min(len(a),len(b));assert all(x['score']==y['score']for x,y in zip(a,b))
 comparable=[(i,x['source'],y['source'])for i,(x,y)in enumerate(zip(a,b))if x['source']is not None and y['source']is not None]
 differences=[i for i,x,y in comparable if x!=y]
 result.append({'comparison':'current vs '+name,'scored_prefix':n,'full_logged_sources_compared':len(comparable),'full_logged_source_differences':differences,'current_hit_inputs_without_full_log':sum(x['source']is None for x in a[:n]),'positions':[i for i,_,_ in comparable]})
 assert not differences
# No-exact-cache records every source, so compare all counterpart misses in its prefix.
a=runs['no-count-memo'];b=runs['no-exact-cache'];n=min(len(a),len(b));assert all(x['score']==y['score']for x,y in zip(a,b))
comparable=[(i,x['source'],y['source'])for i,(x,y)in enumerate(zip(a,b))if x['source']is not None and y['source']is not None]
differences=[i for i,x,y in comparable if x!=y];assert not differences
result.append({'comparison':'no-count-memo vs no-exact-cache','scored_prefix':n,'full_logged_sources_compared':len(comparable),'full_logged_source_differences':differences})
out={'comparisons':result,'matched_source_fields':['parsed_source','term_local_bounds'],'unlogged_key_fields':['EnergyEdgeIndexMap','Generate3DExpressionOptions beyond energy bounds'],'scope':'Exact full ParsedGraph debug strings plus bounds match at every paired generation miss. Hits omit parsed_source, and complete canonical keys are not logged. No claim all hit inputs or complete GL16 outputs are independently compared.'}
(p/'partial-source-comparison.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({**out,'comparisons':[{k:v for k,v in r.items()if k!='positions'}for r in result]},indent=2))

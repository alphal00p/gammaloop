from pathlib import Path
import re,json,hashlib
root=Path('/tmp/cff-change-audit/core-perf');records=[]
for graph,factors in [('GL04',{1:'gammalooprs::Q(1,spenso::mink(4,701))',2:'gammalooprs::Q(2,spenso::mink(4,701))',5:'gammalooprs::Q(5,spenso::mink(4,702))',6:'gammalooprs::Q(6,spenso::mink(4,702))'}),('GL16',{7:'*'.join(f'gammalooprs::Q(7,spenso::mink(4,{i}))' for i in (771,771,772,772))})]:
 original=root/f'graphs-autogen/processes/cross_sections/scalar_core_{graph.lower()}/numerator/{graph}.dot'
 lines=original.read_text().splitlines();modified=[];changed=[]
 for line in lines:
  match=re.search(r'\[id=(\d+)\b',line)
  if match and (edge:=int(match.group(1))) in factors:
   old_num=re.search(r'\bnum="([^"]*)"',line).group(1)
   factor=factors[edge];degree=4 if graph=='GL16' else 1
   line=re.sub(r'\bnum="[^"]*"',f'num="({old_num})*({factor})"',line)
   line=re.sub(r'\bdod="[^"]*"',f'dod="{degree-2}"',line)
   line=line.replace(' num_autogen="true"','').replace(' dod_autogen="true"','')
   changed.append({'edge':edge,'original_numerator':old_num,'factor':factor,'dod':degree-2})
  modified.append(line)
 assert len(changed)==len(factors)
 path=root/f'{graph}-owned-numerator.dot';path.write_text('\n'.join(modified)+'\n')
 commands=['import model scalars-default.json',f'import graphs {path} -p core_audit -i numerator -o --process-spec "scalar_1 > {{scalar_0 scalar_0, scalar_0 scalar_0 scalar_1}}"','set model mass_scalar_1=1.0','generate existing -p core_audit -i numerator','set model mass_scalar_1=0.1','set process -p core_audit -i numerator kv general.generate_events=false general.store_additional_weights_in_event=false']
 card='commands = [\n'+''.join('  '+json.dumps(c)+',\n' for c in commands)+']\n\n'+'''[cli_settings.global]
display_directive = "info"
logfile_directive = "[{#generation,#uv,#local,#four_d,#cff,#profile}]=debug"
[cli_settings.global.n_cores]
feyngen=1
generate=1
compile=1
integrate=1
[cli_settings.global.generation]
explicit_orientation_sum_only=true
[cli_settings.global.generation.evaluator]
compile=false
store_atom=false
summed=false
summed_function_map=false
iterative_orientation_optimization=false
[cli_settings.global.generation.uv]
subtract_uv=true
generate_integrated=true
local_uv_cts_from_expanded_4d_integrands=true
[cli_settings.global.generation.threshold_subtraction]
enable_thresholds=true
check_esurface_at_generation=false
[default_runtime_settings.general]
evaluator_method="SingleParametric"
generate_events=true
store_additional_weights_in_event=true
mu_r=3.0
m_uv=20.0
numerator_sampling_scale=1.0
[default_runtime_settings.subtraction]
disable_threshold_subtraction=false
[default_runtime_settings.sampling]
graphs="summed"
orientations="summed"
lmb_multichanneling=false
lmb_channel_weight="ose"
lmb_channels="summed"
coordinate_system="spherical"
mapping="linear"
b=1.0
[default_runtime_settings.kinematics.externals]
type="constant"
[default_runtime_settings.kinematics.externals.data]
momenta=[[1.0,0.0,0.0,0.0]]
helicities=[0]
'''
 card_path=root/f'{graph}.toml';card_path.write_text(card)
 records.append({'graph':graph,'source_test':'tests/tests/test_runs/scalar_3L_cross_section_inspects.rs','source_original':str(original),'source_sha256':hashlib.sha256(original.read_bytes()).hexdigest(),'graph_input':str(path),'graph_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'edge_numerator_multiplications':changed,'card':str(card_path),'card_sha256':hashlib.sha256(card_path.read_bytes()).hexdigest(),'scope':'Same scalar physical topology, edge-local polynomial factors and runtime settings as existing acceptance probes; each original scalar propagator i is retained. DOT roundtrip and generation checks pending.'})
(root/'cards.json').write_text(json.dumps(records,indent=2)+'\n')
print('Prepared',len(records),'source-owned scalar UV benchmark cards')

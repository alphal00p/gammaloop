"""Isolate core CFF caches/scoring on existing physical-owner scalar UV cards."""
import argparse,fcntl,hashlib,json,os,pathlib,subprocess,time
p=argparse.ArgumentParser();p.add_argument('--output',required=True,type=pathlib.Path);p.add_argument('--rounds',type=int,default=6);p.add_argument('--trace',action='store_true');p.add_argument('--fixtures',nargs='+',default=['GL04','GL04-temporal-square','GL16']);args=p.parse_args()
base=pathlib.Path('/tmp/cff-change-audit/core-perf');binary=base/'gammaloop-core-audit'
lock=pathlib.Path('/tmp/cff-change-audit/measurement.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX)
assert not args.output.exists();args.output.mkdir(parents=True)
variants=[('current',{}),('no-exact-cache',{'CFF_AUDIT_NO_EXACT_CACHE':'1'}),('no-count-memo',{'CFF_AUDIT_NO_COUNT_MEMO':'1'}),('one-proposal',{'CFF_AUDIT_ONE_PROPOSAL':'1'})]
points=[[.1,.2,.3,.4,.5,.6,.7,.8,.9],[.15,.23,.31,.41,.53,.61,.73,.81,.89],[.17,.27,.37,.43,.57,.63,.77,.83,.93]]
manifest={'source':'d55a0f3e9d25e5c64bdb9ef9fb57749ecf680390','binary':str(binary),'binary_sha256':hashlib.file_digest(binary.open('rb'),'sha256').hexdigest(),'flags':json.loads((base/'intervention-description.json').read_text()),'policy':'Fresh CLI/state per observation. All inputs retain original factor owners and complete source reconstruction. Explicit scalar process matches the existing scalar matrix. Full generation, three numerical inspections and computed forest export are included in wall/RSS; this is not isolated CFF kernel timing. One excluded warmup then six alternating balanced rounds. Profile traces only in separate --trace runs. No retries; omit subsequent executions of an input/variant on failure. CPU8, one Rayon worker, 180s child cap, caller supplies8GB process-tree watchdog.','points':points,'trace':args.trace,'runs':[]}
for fixture in args.fixtures:
 active=variants[:]
 for round_index in range(-1,args.rounds):
  for variant,flags in (active[:] if round_index%2==0 else list(reversed(active))):
   label=f'{fixture}-{variant}-'+('warmup'if round_index<0 else str(round_index));out=args.output/label;out.mkdir()
   text=(base/(fixture+'.toml')).read_text().replace('display_directive = "info"','display_directive = "off"')
   if not args.trace:text=text.replace('logfile_directive = "[{#generation,#uv,#local,#four_d,#cff,#profile}]=debug"','logfile_directive = "off"')
   card=out/'card.toml';card.write_text(text)
   extra=[]
   for index,point in enumerate(points):extra.append('inspect -p core_audit -i numerator -x '+' '.join(map(str,point))+' --json-output '+str(out/f'point-{index}.json'))
   extra.append('save uv-forest '+str(out/'uv')+' -p core_audit -i numerator --computed')
   env=os.environ.copy()
   for key in list(env):
    if key.startswith(('CFF_AUDIT_','CFF_PERF_','SPENSO_')):del env[key]
   env.pop('GL_ALL_LOG_FILTER',None);env.update({'GL_DISPLAY_FILTER':'off','GL_LOGFILE_FILTER':'[{#generation,#uv,#local,#four_d,#cff,#profile}]=debug'if args.trace else'off','RAYON_NUM_THREADS':'1','INSTA_UPDATE':'no'});env.update(flags)
   cmd=['taskset','-c','8','timeout','--kill-after=5s','180s',str(binary),'-n','-s',str(out/'state'),'-t','core-audit.jsonl',str(card),'run','-c','; '.join(extra)]
   started=time.monotonic()
   with (out/'cli.log').open('wb')as log:
    child=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT,env=env);_,status,usage=os.wait4(child.pid,0);child.returncode=os.waitstatus_to_exitcode(status)
   elapsed=time.monotonic()-started;traces=[]
   for trace in (out/'state'/'logs').glob('*'):
    for line in trace.read_text().splitlines():
     try:record=json.loads(line)
     except json.JSONDecodeError:continue
     if record.get('message')=='Scored bounded exact-CFF assignment proposal':traces.append(record)
   record={'fixture':fixture,'variant':variant,'environment':flags,'round':round_index,'warmup':round_index<0,'command':cmd,'exit_code':child.returncode,'wall_seconds':elapsed,'max_rss_bytes':usage.ru_maxrss*1024,'card_sha256':hashlib.file_digest(card.open('rb'),'sha256').hexdigest(),'points':[json.loads(x.read_text())for x in sorted(out.glob('point-*.json'))],'computed_exports':{str(x.relative_to(out/'uv')):hashlib.file_digest(x.open('rb'),'sha256').hexdigest()for x in (out/'uv').rglob('*.dot')},'scoring':traces}
   manifest['runs'].append(record);(args.output/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(label,child.returncode,round(elapsed,3),len(traces),flush=True)
   if child.returncode:
    active=[v for v in active if v[0]!=variant];continue
   assert len(record['points'])==3 and record['computed_exports'],'Successful process without full expected output is not a completed probe'
print('Finished; compare complete outputs independently before using timings.',flush=True)

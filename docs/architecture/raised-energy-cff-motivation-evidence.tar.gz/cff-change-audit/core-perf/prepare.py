from pathlib import Path
import subprocess,json,hashlib
root=Path('/tmp/cff-change-audit/core-perf');source=Path('/tmp/cff-change-audit/benchmark-source')
path='crates/gammalooprs/src/cff/generation.rs'
old=subprocess.check_output(['git','show','d55a0f3e:'+path]).decode();new=old
needle='''        let ExactCffGenerationPreparation {
            parsed,'''
replacement='''        // Audit-only switches disable one optimization on the same validated source.
        static NO_CACHE: std::sync::LazyLock<bool> = std::sync::LazyLock::new(||
            std::env::var_os("CFF_AUDIT_NO_EXACT_CACHE").is_some());
        static NO_COUNT_MEMO: std::sync::LazyLock<bool> = std::sync::LazyLock::new(||
            std::env::var_os("CFF_AUDIT_NO_COUNT_MEMO").is_some());
        static ONE_PROPOSAL: std::sync::LazyLock<bool> = std::sync::LazyLock::new(||
            std::env::var_os("CFF_AUDIT_ONE_PROPOSAL").is_some());
        if *NO_CACHE {
            cache = None;
        }
        let ExactCffGenerationPreparation {
            parsed,'''
assert new.count(needle)==1;new=new.replace(needle,replacement)
needle='''        for (proposal, plan) in energy_assignment_plans.into_iter().enumerate() {'''
replacement='''        let proposal_limit = if *ONE_PROPOSAL { 1 } else { usize::MAX };
        for (proposal, plan) in energy_assignment_plans.into_iter().take(proposal_limit).enumerate() {'''
assert new.count(needle)==1;new=new.replace(needle,replacement)
needle='''            let known_count = cache
                .as_deref()
                .and_then(|cache| cache.map_counts.get(&key).copied());'''
replacement='''            let known_count = cache.as_deref().and_then(|cache| {
                if *NO_COUNT_MEMO {
                    cache.entries.get(&key).map(|entry| entry.expression.orientations.len())
                } else {
                    cache.map_counts.get(&key).copied()
                }
            });'''
assert new.count(needle)==1;new=new.replace(needle,replacement)
# When count memoization is disabled, retain full winners only, not loser counts.
needle='''            if let Some(cache) = cache.as_deref_mut() {
                cache.map_counts.insert(key, map_count);
            }'''
replacement='''            if !*NO_COUNT_MEMO && let Some(cache) = cache.as_deref_mut() {
                cache.map_counts.insert(key, map_count);
            }'''
assert new.count(needle)==1;new=new.replace(needle,replacement)
(source/path).write_text(new)
(root/'original.rs').write_text(old)
(root/'intervention-description.json').write_text(json.dumps({'base':'d55a0f3e9d25e5c64bdb9ef9fb57749ecf680390','path':path,'flags':{'CFF_AUDIT_NO_EXACT_CACHE':'Disable both exact payload and losing-count cache for this call; preserve independent requested capacities.','CFF_AUDIT_NO_COUNT_MEMO':'Retain complete cached winners and reuse their counts; regenerate contenders absent from the payload cache; do not retain loser counts.','CFF_AUDIT_ONE_PROPOSAL':'Score only the first rank-ordered certified proposal. Proposal planning itself still constructs the same list; this isolates contender generation/scoring/downstream effects, not a complete old planner.'},'unchanged':'Exact occurrence capacities, independent occurrences, physical ownership, all certificates, rational coefficients and selected payload/assignment association.'},indent=2)+'\n')
print('Prepared three independent core optimization ablations')

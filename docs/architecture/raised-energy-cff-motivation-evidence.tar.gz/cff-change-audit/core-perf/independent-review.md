# Independent review of core CFF benchmark ablations

Read the complete preparation script, intervention description, and modified `generate_3d_expression_for_4d_term` body against the pinned final source. No confirmed intervention correctness defect was found.

- `NO_EXACT_CACHE` clears the optional cache for the call, disabling payload reuse and count memoization together. Request capacities and key construction remain final; this is not a reconstruction of historical union envelopes.
- `NO_COUNT_MEMO` obtains a known count only from an existing full winner payload. Absent contenders are regenerated; losers are not retained, while the selected payload remains paired with its plan. This isolates losing-count memoization while preserving winner caching.
- `ONE_PROPOSAL` retains the complete preparation/planning stage and takes the first certified rank-ordered proposal for generation/scoring. Ownership and exact reconstruction certificates remain. It does not measure eliminating alternative-plan construction.

The existing per-proposal `elapsed_ms` starts after key/count lookup and excludes preparation; whole-generation wall time is needed for the total cost. Separate trace runs must prove actual payload/count hits and multiple proposals occur on the selected UV-on input. Final selected source-map sizes and capacity reports may differ in the one-proposal variant; complete physical values must still agree. Map counts are optimization metrics, not a mathematical correctness oracle. Disabling both cache mechanisms cannot apportion their individual effects.

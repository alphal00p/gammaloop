"""Validate complete exports/observations and summarize separately traced variants."""
import argparse,collections,json,math,pathlib,statistics
p=argparse.ArgumentParser();p.add_argument('directory',type=pathlib.Path);p.add_argument('--reference',type=pathlib.Path);a=p.parse_args()
m=json.loads((a.directory/'manifest.json').read_text());refm=json.loads((a.reference/'manifest.json').read_text())if a.reference else m
refs={r['fixture']:r for r in refm['runs']if r['variant']=='current'and r['exit_code']==0}
checks=[];stats=[];coverage=[]
for r in m['runs']:
 if m['trace']:
  groups=[]
  for x in r['scoring']:
   if x['proposal']==0:groups.append([])
   groups[-1].append(x)
  if r['exit_code']:groups=groups[:-1]  # Do not call the final truncated proposal set complete.
  actual_generations=0
  label=r['fixture']+'-'+r['variant']+'-'+('warmup' if r['round']<0 else str(r['round']))
  for trace in (a.directory/label/'state'/'logs').glob('*'):
   for line in trace.read_text().splitlines():
    try:event=json.loads(line)
    except json.JSONDecodeError:continue
    actual_generations+=event.get('message')=='Generating exact CFF at its term-local capacity'
  coverage.append({'actual_generation_calls':actual_generations,'fixture':r['fixture'],'complete_workflow':r['exit_code']==0,'exit_code':r['exit_code'],'variant':r['variant'],'proposals':dict(collections.Counter(x['proposal']for x in r['scoring'])),'count_hits':sum(x['count_memo_hit']for x in r['scoring']),'unknown_contender_generations':sum(not x['count_memo_hit']for x in r['scoring']),'score_ms':sum(x['elapsed_ms']for x in r['scoring']),'assignment_groups':len(groups),'multi_proposal_groups':sum(len(g)>1 for g in groups),'baseline_beaten_groups':sum(min(x['native_source_maps']for x in g)<g[0]['native_source_maps']for g in groups),'multi_proposal_map_counts':[list(x['native_source_maps']for x in g)for g in groups if len(g)>1]})
 if r['exit_code']:
  checks.append({'fixture':r['fixture'],'variant':r['variant'],'round':r['round'],'status':'incomplete','exit_code':r['exit_code']});continue
 if r['fixture']not in refs:continue
 ref=refs[r['fixture']];errors=[]
 for i,(point,rp)in enumerate(zip(r['points'],ref['points'],strict=True)):
  x=point['evaluation']['integrand_result'];y=rp['evaluation']['integrand_result']
  assert all(math.isfinite(z)for z in (*x.values(),*y.values())),(r['fixture'],r['variant'],'nonfinite')
  xv=complex(x['re'],x['im']);yv=complex(y['re'],y['im']);scale=max(abs(xv),abs(yv));error=abs(xv-yv)/scale if scale else 0.0
  errors.append(error)
 check={'fixture':r['fixture'],'variant':r['variant'],'round':r['round'],'status':'pass','complete_exports_identical':r['computed_exports']==ref['computed_exports'],'complete_points_identical':r['points']==ref['points'],'point_relative_errors_no_floor':errors,'export_count':len(r['computed_exports'])}
 assert check['complete_exports_identical']and check['complete_points_identical']and len(errors)==3,check
 checks.append(check)

for fixture in refs:
 for variant in sorted({r['variant']for r in m['runs']}):
  runs=[r for r in m['runs']if r['fixture']==fixture and r['variant']==variant and not r['warmup']and r['exit_code']==0]
  if not runs:continue
  wall=[r['wall_seconds']for r in runs]
  stats.append({'fixture':fixture,'variant':variant,'runs':len(runs),'wall_mean_seconds':statistics.mean(wall),'wall_median_seconds':statistics.median(wall),'wall_sample_stdev_seconds':statistics.stdev(wall)if len(wall)>1 else None,'wall_min_seconds':min(wall),'wall_max_seconds':max(wall),'max_child_rss_bytes':max(r['max_rss_bytes']for r in runs)})
result={'source':m['source'],'binary_sha256':m['binary_sha256'],'reference':str(a.reference or a.directory),'comparisons':checks,'trace_coverage':coverage,'summary':stats,'numerical_policy':'Complete inspection JSON equality plus finite complex relative differences without any absolute tolerance floor. Complete computed forest/node DOT byte equality; no graph numerator expansion.'}
(a.directory/'analysis.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'observations':len(m['runs']),'completed':sum(r['exit_code']==0 for r in m['runs']),'checks':len(checks),'measured_cells':len(stats)},indent=2))

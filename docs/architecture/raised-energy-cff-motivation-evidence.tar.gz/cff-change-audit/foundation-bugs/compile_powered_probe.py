import hashlib,json,subprocess,sys,time
from pathlib import Path
root=Path('/tmp/cff-change-audit/foundation-bugs')
label=sys.argv[1]
hashes=dict(zip(['vakint','symbolica'],sys.argv[2:]))
target=Path('/common/dev/gammaloop/higher-power-energies-review/target/dev-optim')
source=root/'powered_dot_probe.rs'
command=['taskset','-c','16-23','/tmp/raised-stack/run','env','CARGO_CRATE_NAME=powered_dot_probe','rustc','--edition=2024','--crate-name','powered_dot_probe','-C','opt-level=2','-C','linker=/nix/store/vdaz6sk455r8sbpi7wzaf9vlz5i9yyvx-gcc-wrapper-15.2.0/bin/gcc','-L',f'dependency={target}/deps','-L',f'native={target}/build/gmp-mpfr-sys-2c9c0b34e622e63a/out/lib']
dependencies=[]
for crate,hash_value in hashes.items():
 p=target/'deps'/f'lib{crate}-{hash_value}.rlib'
 command += ['--extern',f'{crate}={p}']
 dependencies.append({'crate':crate,'rlib':str(p),'sha256':hashlib.file_digest(p.open('rb'),'sha256').hexdigest(),'cargo_fingerprint':json.loads((target/'.fingerprint'/f'{crate}-{hash_value}'/f'lib-{crate}.json').read_text())})
command += [str(source)]
steps=[]
for step,options in [('check',['--emit=metadata','-o',str(root/'artifacts'/f'{label}-probe.rmeta')]),('build',['-o',str(root/'artifacts'/f'{label}-powered-probe')])]:
 cmd=command+options
 start=time.monotonic()
 log=root/'artifacts'/f'{label}-powered-{step}.log'
 with log.open('w') as out:
  result=subprocess.run(cmd,stdout=out,stderr=subprocess.STDOUT)
 steps.append({'command':cmd,'exit_code':result.returncode,'seconds':time.monotonic()-start,'log':str(log)})
 if result.returncode: break
record={'label':label,'source_sha256':hashlib.file_digest(source.open('rb'),'sha256').hexdigest(),'dependencies':dependencies,'steps':steps}
(root/'artifacts'/f'{label}-powered-build.json').write_text(json.dumps(record,indent=2)+'\n')
if all(x['exit_code']==0 for x in steps):
 print(label,'probe built',hashlib.file_digest((root/'artifacts'/f'{label}-powered-probe').open('rb'),'sha256').hexdigest())
else:sys.exit(1)

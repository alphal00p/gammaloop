# Foundation correctness motivation audit

Pinned reviewed tree: `d55a0f3e9d25e5c64bdb9ef9fb57749ecf680390`.
Owning reconstructed change: `5687de4b4bbf0eb963ff018fc6f560f5607ffc48` above `39561014`.
This audit executes reduced existing regressions using unchanged test sources, then reverses narrow production interventions on the reviewed dependency set. Such an intervention is an ablation, not a claim to execute the full original parent. Numeric references and failing tests are not edited.

| Change | Concrete distinguishing input | Motivation and attribution |
|---|---|---|
| Spenso reserves serialized explicit index names before compact parsing | One compact `dot(p(mink(4)),q(mink(4)))` times an independent explicit closed pair named `Dummy(1000000)` | Capturing the explicit name overcontracts an index. Original `26b57b786:PHASE_CONVENTIONS_FIX.md` records this reduced failure and the physical slow ttH UV `ContractedMoreThanOnce` failure. The original raw Vakint returns matched, excluding downstream phase/integration physics. `Rc<Cell<usize>>` sharing across parser clones was already present in `39561014`; the added behavior is reservation and skipping collisions. |
| Idenso reserves external and dual slots during canonical dummy relabeling | Product of two vector sums with a genuine external `Dummy(0)` or `Dummy(1)`; independent Lorentz contraction beside dual external `Dummy(0)` | A canonical contracted dummy must not acquire the existing external label. These are outward index-domain/idempotence contracts, not a storage representation requirement. Original source records generic external-slot regressions as part of the ttH follow-up. |
| Idenso ignores validated dummy names absent after cancellation | Difference of alpha-equivalent closed contractions in one representation beside a surviving contraction in another | A canceled representation must not consume canonical names and break alpha-equivalence/idempotence. This is a reduced algebraic canonicalization requirement; no separate end-to-end physics failure is recorded for this exact subcase. |
| Symbolica nested-sum contraction counter pin | `s*((A(i)+B(i))*(C(i)+D(i))+(E(i)+F(i))*(G(i)+H(i)))` | Source `26b57b786` records this exact minimal expression panicking at `tensors.rs:469`, after compact-name capture was repaired, and later complete slow ttH acceptance. This audit's local ablation retains the fixed dependency; a passing nested-sum test is therefore a control, not a fresh old-dependency reproduction. Old raw `/tmp/gammaloop-phase-*` logs named by the source record are unavailable here. |
| Idenso prunes antisymmetric zeros without distributing unrelated products of sums | `S*(A+B)*(1+odd_cycle)` with a closed odd cycle of antisymmetric tensors | Required output is `S*(A+B)` with the existing factor preserved. This is an explicit factorization contract motivated by the user ban on numerator expansion; numerical equality alone does not distinguish old and new. A separate no-zero public canonicalization probe improves from 7.430ms to 0.361ms median under the scoped ablation; the measurement covers the complete method. |
| Chain collection avoids work when no chain exists | `(a+b)^8*(c+d)^8/(1+a*c+b*d)` | Both old and current code preserve this scalar factorization. Symbolica collection explicitly does not expand; the added no-chain early return removes unnecessary traversal/collection work. A captured physical g–g numerator and this reduced scalar are benchmark inputs; no wrong-value bug is claimed. |
| Compact syntax admits exactly one implicit axis alongside explicit spectator axes | `dot(L(a,b,mink(4)),R(c,d,mink(4)))`, plus one repeated spectator | Old matcher explicitly rejected any explicit slot. The change adds useful unambiguous syntax; it is not established as a previously supported dense/mixed contraction fix. Public parser tests check resulting external slots. |
| Compact syntax admits scalar-weighted vectors | `f(w*p(mink(4)))` | Old compact-vector matcher handled functions and sums, not products. The new behavior is a syntax extension; guards keep products of two vectors and vector-times-open-tensor ambiguous. The existing narrow regression calls a private materializer and inspects its product/slot form. This establishes mechanism activation, but it should be migrated to complete public parsing/contraction behavior if the suite is required to avoid implementation constraints. |
| Vakint makes powered scalar-dot copies independent | `(dot(p(5),k(1))+dot(k(1),k(2)))^2` and nested powers | The implementation explicitly freshens scalar-dot powers. However, all four powered-dot/GL06 regressions pass with the old converter on current dependencies and Lorentz consumers. These results do not demonstrate a current outward failure requiring explicit copies. Possible serializer/backend differences remain untested; no necessity or speedup is established for this subchange. Reciprocal cases are algebraic controls, not asserted physical energy numerators. |
| Vakint normalization uses numeric imaginary coefficients | Register canonical user symbol `symbolica::{}::𝑖`, then form builtin normalization for 1–3 loops at epsilon=0 | A user symbol registration must not turn numerical `i` into an arbitrary symbolic parameter. Independent result is `(i*pi^2)^(-L)`. No benchmark is appropriate for a wrong normalization coefficient. |
| Vakint escapes canonical user namespaces and seeds builtin names on FORM parsing | Coefficients `symbolica::{}::x`, `symbolica::{}::𝑖`, `symbolica::{}::f(vakint::{}::x)` multiplying rank-two vacuum input | User scalar identity must survive sanitizer/output round-trip and tensor reduction. Only Vakint names were stripped initially; stripping other namespaces confuses canonical symbols and builtin spellings. Tests cover both adapter round-trip and complete tensor reduction. |

Fresh execution results are recorded separately once the final and ablated binaries complete. Existing physical-history evidence is provenance, not fresh runtime validation or proof that every cleanup was required by the same failure.

## Fresh final-tree execution

All **22 selected existing probes pass** on the pinned reviewed source. Each probe ran in its own process, with two processes concurrently and Rayon limited to two workers. Snapshot updates were disabled. No manual PySecDec integration was selected.

The final build command was:

```text
/tmp/raised-stack/python bin/ram_watchdog.py --log /tmp/cff-change-audit/foundation-bugs/artifacts/final-build-watchdog.json --limit-gb 15 -- /tmp/raised-stack/run env CARGO_BUILD_JOBS=2 CARGO_TARGET_DIR=/common/dev/gammaloop/higher-power-energies-review/target cargo nextest list -p idenso -p spenso -p vakint --lib --test network_dumb --test tensor_reduction_tests --cargo-profile dev-optim --locked --message-format json
```

Cargo reports 15m57s; the complete watchdog duration is 957.885s with peak process-tree RSS 6,837,489,664 bytes. The narrowed package features required a fresh Symbolica build. This compilation time is not a performance measurement of the tensor changes.

The probe driver command was:

```text
/tmp/raised-stack/python bin/ram_watchdog.py --log /tmp/cff-change-audit/foundation-bugs/artifacts/final-tests-watchdog.json --limit-gb 15 -- /tmp/raised-stack/python /tmp/cff-change-audit/foundation-bugs/run_probes.py final
```

The full driver, including copying and hashing test binaries, took 7.609s and peaked at 570,474,496 bytes. Per-test subprocess times total 0.820s. These are correctness-run accounting, not before/after benchmarks. `artifacts/final/results.json` records every exact command, binary SHA-256, test name, return code, duration and retained log.

## Definitive scoped baseline

The baseline passes formatting and a fresh scoped Cargo check/build. It reverses eight production files on the final dependency set; `baseline-provenance.json` verifies four separate test files and two embedded test modules unchanged, and `actual-baseline-ablation.patch` is the exact intervention. The baseline enables `idenso/bincode,idenso/reference-cases` for compatibility with the supplemental public-method probe; the initial final regression build used default package features. These serialization/reference-case feature differences do not change the scoped production arithmetic methods, but the full build configurations are not identical.

The definitive baseline result is **12 passes / 10 failures**, against final **22 passes / 0 failures**. Exact binaries, SHA-256 values, commands and logs are in `baseline-definitive/results.json` and `final/results.json`.

| Newly distinguished behavior | Observed old-code failure |
|---|---|
| Compact explicit-name reservation | `ContractedMoreThanOnce` for `spenso::mink(4,spenso::d_1000000)` |
| External canonical dummy reservation | `ContractedMoreThanOnce` for `spenso::mink(4,spenso::d_0)` |
| Dual external reservation | `ContractedMoreThanOnce` for `spenso::lor(4,spenso::d_0)` |
| Ignore canceled representation indices | Canonical result uses dummy `d_1` where alpha-equivalent standalone result uses `d_0`; canonical identity contract fails |
| Local antisymmetric-zero pruning | Returns expanded `A*S+B*S` instead of retaining `(A+B)*S`; values remain algebraically equal |
| Weighted compact vector spelling | Parser does not recognize the supported weighted compact argument |
| Explicit spectator spelling (2 cases) | Parser does not recognize the compact dot with explicit spectator slots |
| Numeric imaginary normalization | Builtin normalization contains the independently registered user symbol `𝑖` |
| FORM namespace round-trip | `FormOutputParsingError`: invalid `{` in duplicated `symbolica::symbolica::{}...` namespace |

The 12 unchanged outcomes include four powered-dot/GL06 cases, no-chain scalar preservation, nested-sum counter controls with the fixed Symbolica dependency, and rejection of ambiguous compact vector products. These passing controls limit the motivation claims; they are not silently counted as fixed bugs.

The definitive Cargo check takes 7.220s and peaks at 801,550,336 bytes; the native build/list takes 221.087s and peaks at 1,966,653,440 bytes; freezing and running the 22 tests takes 7.421s and peaks at 570,699,776 bytes. These are execution accounting, not performance claims. The build uses two Cargo jobs, CPU16–23, and a 15GB process-tree watchdog. Tests use two concurrent processes and two Rayon workers; snapshots are disabled and no retries are used.

A preliminary baseline run reused a later Spenso dependency from the shared Cargo target because checkout source mtimes predated that dependency. Its 13/9 result and copied binaries are retained under `baseline/` with `baseline-cache-mix-notice.json`, and are **invalid for baseline certification**. The definitive build explicitly touched all eight ablated source files immediately before Cargo, rebuilt Spenso/Idenso/Vakint, and recovered the expected compact-capture failure. A mistakenly linked preliminary supplemental binary is likewise retained with `setup-wrong-library-` names and excluded.

## Supplemental public-method probes

`foundation_motivation_probe.rs` invokes existing public `collect_chains` and `canonize` methods without adding production APIs. Frozen final and baseline executables have distinct recorded SHA-256 values. The no-chain physical input is the captured g–g double triangle numerator (`physical-input-pin.json`), a 140,004-byte canonical expression containing no chain head. Untimed smokes show identical complete outputs for physical/scalar chain collection and pruning without a removable zero. A separate zero-pruning smoke passes current code and fails old code's exact factorization contract. Controlled timings are now complete below; smoke durations remain outside benchmark evidence.

The final supplemental library is from root's current instrumented build with `idenso/bincode,reference-cases`; the old supplemental library is from the definitive ablation with matching features. Root's extra Spenso ParamTensor/alias trace switches are not exercised by these methods. Rlib paths, hashes and Cargo fingerprints are recorded in both `*-perf-build.json` files.


The three existing compact materializer unit tests in this selection are mechanism-oriented: one inspects product/slot form and two preserve unrecognized input form. The compact spectator and dummy-capture cases exercise the broader parser/canonicalizer contracts. No existing failing test was changed during this audit.

For `prune_nozero`, the timed boundary is the full public canonicalization method under the scoped foundation ablation. Several canonicalizer reservations also differ, so any timing difference measures this complete method on the targeted pruning fixture, not an isolated internal-pruning function. Chain collection and scalar-dot conversion do not invoke those unrelated changed canonicalizer paths.

## Additional current/old correctness smokes

The powered-dot standalone probe passes its square, nested-power, and GL06 cases on both frozen versions. Complete scalar round-trips match structurally, and the GL06 result agrees with the independent scalar identity at all 27 exact degree-certifying points. No physical numerator expansion is used. `baseline-powered-smoke.json` and `final-powered-smoke.json` record the six passes.

`multi_storage_probe.rs` supplements the physical contraction trace with a bounded synthetic storage matrix copied from the existing symbolic benchmark's public API pattern: two shared Euclidean axes, dimensions 4 and 8, full and exactly 1/16 nonzero occupancy, and factorized symbolic components. Both old and current kernels pass all 32 combinations across DD/DS/SD/SS. Each output component is checked against an independent coordinate double sum by expanded subtraction; these are finite synthetic components, not a copied physical numerator. Complete values agree across every storage and kernel variant. This establishes that dense and mixed multi-index contraction already work on these cases. It does not claim exhaustive contraction-order or metric coverage; the existing separate metric/permutation regression owns that boundary. Trace activation and frozen binary/dependency hashes are retained in `multi-storage-smoke.json` and `multi-storage-build.json`.

All three performance matrices completed after all audit native builds finished and while holding the shared `measurement.lock`: 264 measured processes and 44 excluded warm-ups, with six balanced order rounds per pair.

## Controlled benchmark results

Every one of **308 observations passes** its complete value oracle: 264 measured observations plus 44 excluded warm-ups. The three matrices run sequentially under `/tmp/cff-change-audit/measurement.lock`, with no other audit build or heavy probe active. Each process is pinned to CPU8 with one Rayon worker; synthetic kernel cases additionally select `SymbolicParallelism::Serial`. Each pair has six rounds with balanced old/current ordering. Setup, parsing, complete component/scalar certificates and output serialization occur outside the timed operation loop. A 15GB process-tree watchdog surrounds the entire run; no timeout, failure, retry or snapshot update occurs.

The watchdog reports 200.181s including the initial measurement-lock wait, and 42,229,760-byte peak process-tree RSS. Summed observation wall time is 104.052s. Per-child peak RSS remains around 12.6MB for these short probes and includes launch, parsing and oracle work, so it does not isolate operation allocations or establish a memory improvement. Whole-host one-minute load ranges from 18.23 to 25.26; the audit controls its own processes but does not reserve the machine from unrelated users. Small differences with overlapping ranges should not be read as robust improvements.

| Public operation / input | Old median (ms) | Current median (ms) | Old/current | Meaning |
|---|---:|---:|---:|---|
| Chain collection, captured physical g–g numerator | 14.483235 | 0.083504 | 173.44× | Saves about 14.4ms per call on this input; this is not an end-to-end generation speedup |
| Chain collection, factorized scalar control | 0.031408 | 0.000239 | 131.19× | Old/current factors and complete values already agree |
| Canonicalization, no-zero factorization stress | 7.430241 | 0.360509 | 20.61× | Full public method under the scoped foundation ablation; not a uniquely isolated internal-pruning measurement |
| Scalar-dot conversion, square | 0.039461 | 0.055606 | 0.71× | Current explicit freshening costs more; complete scalar round-trip unchanged |
| Scalar-dot conversion, nested power | 0.054603 | 0.115079 | 0.47× | Current explicit freshening costs more; complete scalar round-trip unchanged |
| Scalar-dot conversion, GL06 numerator | 0.195927 | 0.229500 | 0.85× | Current explicit freshening costs more; independent complete scalar identity unchanged |

Powered-dot indexed payload sizes rise from 106→211 bytes for the square, 139→727 bytes for the nested power, and 519→617 bytes for GL06. These are observed conversion-output sizes, not assertions constraining storage. The results provide no performance justification for freshening and do not reproduce an outward correctness failure without it on current Lorentz consumers. That makes this subchange a concrete simplification candidate to investigate across every remaining adapter, particularly the unexecuted PySecDec path; it is not safe to infer that every consumer can already omit it.

The following synthetic storage matrix uses two common Euclidean axes and independent factorized component formulas. Dimension4 is representative of spacetime/spinor-sized axes; dimension8 is a stress extension, not an additional physical graph. Density `1/16` means the same mostly-zero values stored in all four representations. DD/DS/SD/SS denote dense/sparse left/right storage. All old/current results already satisfy the complete component oracle, so this is performance evidence, not a missing-contraction repair.

| Dimension | Nonzero occupancy | Storage | Old median (ms) | Current median (ms) | Old/current |
|---:|---:|---|---:|---:|---:|
| 4 | full | DD | 0.449361 | 0.313800 | 1.43× |
| 4 | full | DS | 0.395418 | 0.285952 | 1.38× |
| 4 | full | SD | 0.380271 | 0.290341 | 1.31× |
| 4 | full | SS | 0.284296 | 0.273942 | 1.04× |
| 4 | 1/16 | DD | 0.232835 | 0.009971 | 23.35× |
| 4 | 1/16 | DS | 0.025218 | 0.013012 | 1.94× |
| 4 | 1/16 | SD | 0.026520 | 0.013260 | 2.00× |
| 4 | 1/16 | SS | 0.013519 | 0.013388 | 1.01× |
| 8 | full | DD | 8.150993 | 4.110531 | 1.98× |
| 8 | full | DS | 8.174028 | 4.213872 | 1.94× |
| 8 | full | SD | 8.231255 | 4.151459 | 1.98× |
| 8 | full | SS | 4.143866 | 4.194086 | 0.99× |
| 8 | 1/16 | DD | 3.924491 | 0.086953 | 45.13× |
| 8 | 1/16 | DS | 0.351918 | 0.126642 | 2.78× |
| 8 | 1/16 | SD | 0.399674 | 0.152578 | 2.62× |
| 8 | 1/16 | SS | 0.195875 | 0.137176 | 1.43× |

Full-support dense and mixed cases improve by roughly 1.3–2.0× in median. Sparse–sparse full-support results are effectively unchanged; the 8D full case is 1.2% slower in median with strongly overlapping ranges. The large dense mostly-zero gains reflect avoided useless work on these stress inputs and should not be presented as general physical gains. The separate physical g–g kernel timing belongs to root's captured-input matrix.

`matrix-summary.json` and `matrix-summary.txt` retain medians, minima, maxima, complete-output hashes and peak-RSS summaries. Full commands, binary hashes, per-observation timings, load snapshots and logs are in `performance/manifest.json`, `powered-performance/manifest.json` and `multi-performance/manifest.json`. `measurement-lock-receipt.json` and `performance-watchdog.json` record coordination/resource evidence. These exact receipts supersede the prepared/pending descriptions in setup logs; no failed setup run is converted into a passing measurement.

The C1 logical inventory separately maps all **36 changed paths into 24 categories**, including tooling, dependency/consumer migrations and documentation. Combined with the C2–7 inventory, this yields 579 commit/path records, 505 distinct paths and 73 logical categories. A complete path mapping does not establish a motivating bug or speedup for every hunk.

# Commit1 logical change/path coverage

24 logical categories cover all 36 changed paths. Mapping is many-to-many; it does not claim causal evidence for each hunk.

| ID | Change | Motivation |
|---|---|---|
| C1-01 | Reserve explicit compact-parser dummy names | reproduced error |
| C1-02 | Reserve external and dual indices during canonical dummy naming | reproduced errors |
| C1-03 | Ignore canonical names from canceled representation groups | reproduced canonical identity defect |
| C1-04 | Preserve completed contractions across nested tensor sums in pinned Symbolica | source-recorded physical and reduced bug |
| C1-05 | Prune antisymmetric zeros locally without distributing spectators | reproduced factorization defect; full-method timing measured |
| C1-06 | Skip chain collection on expressions with no chains | performance simplification; no old correctness failure |
| C1-07 | Allow one implicit compact axis beside explicit spectator slots | new supported syntax |
| C1-08 | Allow scalar-weighted compact vectors while retaining ambiguity checks | new supported syntax |
| C1-09 | Freshen independent copies of powered scalar dots | correctness motivation currently unproved; measured extra cost |
| C1-10 | Use numeric imaginary coefficients in Vakint normalization | reproduced wrong symbolic coefficient |
| C1-11 | Preserve canonical user namespaces across FORM | reproduced parsing failure |
| C1-12 | Generalize grouped Atom contraction across tensor storage kinds | performance change, not missing dense/mixed capability |
| C1-13 | Score contraction candidates by intermediate symbolic cost | selectable performance heuristic |
| C1-14 | Register already-created scalar aliases without recompressing the root | performance simplification |
| C1-15 | Defer large coefficient broadcasting while preserving ordinary terminal results | resource policy plus terminal-result API contract |
| C1-16 | Select clang for macOS Rust unwinding | source-recorded platform defect |
| C1-17 | Guard heavy process trees and keep local runtime outputs out of version control | requested resource/tooling support |
| C1-18 | Keep manual PySecDec integrations outside automated selections and require supported nextest | explicit test policy/tool compatibility |
| C1-19 | Pin compatible Python Symbolica and UFO loader | source-recorded import fixed-point bug and API requirement |
| C1-20 | Regenerate shared dependency feature metadata | build metadata consistency |
| C1-21 | Remove excess trait bounds and migrate sum-capable consumers | API simplification and required consumer migration |
| C1-22 | Preserve physical numerator factors in diagnostic consumers | explicit factorization policy and revised behavioral checks |
| C1-23 | Regenerate current optional defaults and schema formatting | generated schema compatibility/formatting |
| C1-24 | Clarify the scope of older large-expression observations | documentation correction |

| Path | Categories |
|---|---|
| `.cargo/config.toml` | C1-16 |
| `.config/nextest.toml` | C1-18 |
| `.gitignore` | C1-17 |
| `Cargo.lock` | C1-04, C1-20 |
| `Cargo.toml` | C1-04 |
| `assets/schemas/runhistory.json` | C1-23 |
| `assets/schemas/runtime.json` | C1-23 |
| `bin/README.md` | C1-17 |
| `bin/ram_watchdog.py` | C1-17 |
| `crates/gammaloop-workspace-hack/Cargo.toml` | C1-04, C1-20 |
| `crates/idenso/src/lib.rs` | C1-02, C1-03 |
| `crates/idenso/src/shorthands/chain.rs` | C1-06 |
| `crates/idenso/src/tensor/canonicalize.rs` | C1-04, C1-05 |
| `crates/idenso/src/tensor/tests/canonicalization.rs` | C1-02, C1-04, C1-05 |
| `crates/idenso/tests/bare_symb.rs` | C1-22 |
| `crates/idenso/tests/network_dumb.rs` | C1-01, C1-02, C1-03, C1-04, C1-22 |
| `crates/idenso/tests/network_informed.rs` | C1-22 |
| `crates/spenso/src/algebra/complex/symbolica_traits.rs` | C1-21 |
| `crates/spenso/src/network/contract.rs` | C1-13 |
| `crates/spenso/src/network/mod.rs` | C1-13, C1-14, C1-15, C1-21 |
| `crates/spenso/src/network/parsing/materialization.rs` | C1-07, C1-08 |
| `crates/spenso/src/network/parsing/mod.rs` | C1-01 |
| `crates/spenso/src/network/parsing/structure_inference.rs` | C1-08 |
| `crates/spenso/src/network/parsing/tensor_from_expression.rs` | C1-15, C1-21 |
| `crates/spenso/src/network/parsing/test.rs` | C1-07 |
| `crates/spenso/src/network/tests.rs` | C1-13, C1-14, C1-15 |
| `crates/spenso/src/tensors/parametric.rs` | C1-12, C1-13 |
| `crates/vakint/src/fmft.rs` | C1-10 |
| `crates/vakint/src/lib.rs` | C1-09, C1-10, C1-11 |
| `crates/vakint/src/matad.rs` | C1-10 |
| `crates/vakint/tests/integral_evaluation_analytic_tests.rs` | C1-10 |
| `crates/vakint/tests/tensor_reduction_tests.rs` | C1-09, C1-10, C1-11 |
| `docs/architecture/spenso-large-expression-pathology.md` | C1-24 |
| `examples/api/rust/epem_a_ddxg_xs_LO/inspect_events.rs` | C1-04 |
| `pyproject.toml` | C1-19 |
| `uv.lock` | C1-19 |

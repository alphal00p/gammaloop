import difflib
import hashlib
import json
from pathlib import Path
import subprocess

root=Path('/tmp/cff-change-audit/foundation-bugs')
source=root/'source'
repo=Path('/common/dev/gammaloop/higher-power-energies-review')
head='d55a0f3e9d25e5c64bdb9ef9fb57749ecf680390'
patch=root/'artifacts/intervention.patch'
subprocess.run(['git','apply','--reverse',str(patch)],cwd=source,check=True)
normalization=[]
for relative in ['crates/vakint/src/lib.rs','crates/vakint/src/fmft.rs','crates/vakint/src/matad.rs']:
 path=source/relative
 old=path.read_text()
 count=old.count('1𝑖*')
 assert count == (4 if relative.endswith('lib.rs') else 1), (relative,count)
 path.write_text(old.replace('1𝑖*','𝑖*'))
 normalization.append({'path':relative,'literal_changes':count,'from':'1𝑖*','to':'𝑖*'})
paths=[
'crates/idenso/src/lib.rs','crates/idenso/src/shorthands/chain.rs','crates/idenso/src/tensor/canonicalize.rs',
'crates/spenso/src/network/parsing/mod.rs','crates/spenso/src/network/parsing/materialization.rs',
'crates/vakint/src/lib.rs','crates/vakint/src/fmft.rs','crates/vakint/src/matad.rs',
]
changes=[]
all_diff=[]
for relative in paths:
 before=subprocess.check_output(['git','show',f'{head}:{relative}'],cwd=repo)
 after=(source/relative).read_bytes()
 changes.append({'path':relative,'final_sha256':hashlib.sha256(before).hexdigest(),'baseline_ablation_sha256':hashlib.sha256(after).hexdigest()})
 all_diff.extend(difflib.unified_diff(before.decode().splitlines(True),after.decode().splitlines(True),fromfile='final/'+relative,tofile='baseline-ablation/'+relative))
(root/'artifacts/actual-baseline-ablation.patch').write_text(''.join(all_diff))
test_paths=[
'crates/idenso/tests/network_dumb.rs','crates/idenso/src/tensor/tests/canonicalization.rs',
'crates/spenso/src/network/parsing/test.rs','crates/vakint/tests/tensor_reduction_tests.rs',
]
tests=[]
for relative in test_paths:
 before=subprocess.check_output(['git','show',f'{head}:{relative}'],cwd=repo)
 after=(source/relative).read_bytes()
 assert before==after, relative
 tests.append({'path':relative,'unchanged':True,'sha256':hashlib.sha256(after).hexdigest()})
for relative in ['crates/idenso/src/shorthands/chain.rs','crates/spenso/src/network/parsing/materialization.rs']:
 before=subprocess.check_output(['git','show',f'{head}:{relative}'],cwd=repo).decode().split('#[cfg(test)]',1)[1]
 after=(source/relative).read_text().split('#[cfg(test)]',1)[1]
 assert before==after, relative
 tests.append({'path':relative,'section':'cfg(test) module','unchanged':True,'sha256':hashlib.sha256(after.encode()).hexdigest()})
record={'final_source':head,'old_source_for_reversed_hunks':'39561014','owning_commit':'5687de4b','kind':'scoped old-production ablation on final dependency set, not full historical baseline','normalization_literal_reversal':normalization,'changes':changes,'test_sources':tests}
(root/'artifacts/baseline-provenance.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'changed_production_files':len(changes),'unchanged_test_sections':len(tests)},indent=2))

import hashlib,json,os,resource,subprocess,time
from pathlib import Path
root=Path('/tmp/cff-change-audit/foundation-bugs')
artifacts=root/'artifacts'
out=artifacts/'powered-performance'
out.mkdir(exist_ok=True)
fixtures={'square':10000,'nested':1000,'gl06':5000}
variants=['final','baseline']
manifest={'purpose':'controlled public-method A/B; run only after all audit compilations complete','source':str(root/'powered_dot_probe.rs'),'source_sha256':hashlib.file_digest((root/'powered_dot_probe.rs').open('rb'),'sha256').hexdigest(),'cpu_affinity':'8','rayon_workers':1,'rounds':6,'warmup_policy':'one excluded process per version/case, plus two deterministic correctness evaluations before each process timing starts','memory_policy':'wait4 peak RSS of the whole child, including parsing, untimed output assertions and result serialization; not isolated allocation','runs':[]}
expected={}
for case,iterations in fixtures.items():
 for round_index in range(-1,6):
  for variant in (variants if round_index%2==0 else list(reversed(variants))):
   binary=artifacts/f'{variant}-powered-probe'
   name=f'{case}-{variant}-{round_index}'
   atom=out/f'{name}.atom'
   log=out/f'{name}.log'
   cmd=['taskset','-c','8','timeout','--signal=TERM','--kill-after=5s','120s','/tmp/raised-stack/run','env','RAYON_NUM_THREADS=1',str(binary),case,str(iterations),str(atom)]
   load_before=os.getloadavg();started=time.monotonic()
   with log.open('w') as stream:
    proc=subprocess.Popen(cmd,stdout=stream,stderr=subprocess.STDOUT)
    _,status,usage=os.wait4(proc.pid,0)
    proc.returncode=os.waitstatus_to_exitcode(status)
   row={'case':case,'variant':variant,'round':round_index,'warmup':round_index<0,'command':cmd,'binary_sha256':hashlib.file_digest(binary.open('rb'),'sha256').hexdigest(),'exit_code':proc.returncode,'wall_seconds':time.monotonic()-started,'host_loadavg_before':load_before,'host_loadavg_after':os.getloadavg(),'max_rss_bytes':usage.ru_maxrss*1024,'log':str(log)}
   if proc.returncode==0:
    row['measurement']=json.loads(log.read_text().strip().splitlines()[-1])
    row['output_sha256']=hashlib.file_digest(atom.open('rb'),'sha256').hexdigest()
    expected.setdefault(case,row['output_sha256'])
    row['complete_output_matches']=row['output_sha256']==expected[case]
   manifest['runs'].append(row)
   (out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
   print(json.dumps(row),flush=True)
   if proc.returncode or not row.get('complete_output_matches'):
    raise SystemExit('failed correctness or completion; no retries')

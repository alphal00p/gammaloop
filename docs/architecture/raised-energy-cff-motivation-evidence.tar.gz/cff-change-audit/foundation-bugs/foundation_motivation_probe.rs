use std::{env, fs, hint::black_box, time::Instant};

use idenso::{
    IndexTooling,
    representations::{Bispinor, initialize},
    shorthands::chain::Chain,
};
use spenso::{
    antisym, mink,
    structure::{abstract_index::AbstractIndex, representation::LibraryRep},
    tensor,
};
use symbolica::{
    atom::{Atom, AtomCore},
    parse,
};

fn main() {
    initialize();
    let arguments = env::args().collect::<Vec<_>>();
    let case = &arguments[1];
    let iterations = arguments[2].parse::<usize>().unwrap();
    let output_path = &arguments[3];
    let spectator =
        parse!("(audit_a+audit_b)^8*(audit_c+audit_d)^8/(1+audit_a*audit_c+audit_b*audit_d)");
    let input = match case.as_str() {
        "chain_scalar" => spectator,
        "chain_physical" => parse!(fs::read_to_string(&arguments[4]).unwrap().as_str()),
        "prune_nozero" => {
            spectator
                * tensor!(audit_scalar)
                * (Atom::one() + antisym!(mink!(4, audit_i), mink!(4, audit_j)).pow(2))
        }
        "prune_zero" => {
            let [i, j, k] = [mink!(4, audit_i), mink!(4, audit_j), mink!(4, audit_k)];
            (parse!("audit_a+audit_b") * parse!("audit_c+audit_d"))
                * tensor!(audit_scalar)
                * (Atom::one()
                    + antisym!(i.clone(), j.clone()) * antisym!(j, k.clone()) * antisym!(k, i))
        }
        _ => panic!("unknown case"),
    };
    let representation: LibraryRep = Bispinor {}.into();
    let operation = |expression: &Atom| {
        if case.starts_with("chain_") {
            expression.collect_chains(representation)
        } else {
            expression.canonize::<AbstractIndex>(AbstractIndex::Dummy)
        }
    };
    let output = operation(&input);
    assert_eq!(output, operation(&input));
    if case == "chain_scalar" {
        assert_eq!(output, input);
    }
    if case == "prune_zero" {
        assert_eq!(
            output,
            parse!("audit_a+audit_b") * parse!("audit_c+audit_d") * tensor!(audit_scalar)
        );
    }
    fs::write(output_path, output.to_canonical_string()).unwrap();
    let started = Instant::now();
    for _ in 0..iterations {
        let _ = black_box(operation(black_box(&input)));
    }
    let elapsed = started.elapsed();
    println!(
        "{{\"case\":\"{case}\",\"iterations\":{iterations},\"elapsed_ns\":{},\"input_bytes\":{},\"output_bytes\":{}}}",
        elapsed.as_nanos(),
        input.to_canonical_string().len(),
        output.to_canonical_string().len()
    );
}

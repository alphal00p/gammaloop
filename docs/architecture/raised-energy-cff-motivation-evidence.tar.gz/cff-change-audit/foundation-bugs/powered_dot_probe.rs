use std::{env, fs, hint::black_box, time::Instant};
use symbolica::atom::{Atom, AtomCore};
use vakint::{Vakint, VakintSettings, vakint_parse};

fn main() {
    let arguments = env::args().collect::<Vec<_>>();
    let case = &arguments[1];
    let iterations = arguments[2].parse::<usize>().unwrap();
    let _ = vakint::symbols::S.dot;
    let input = match case.as_str() {
        "square" => vakint_parse!("(dot(p(5),k(1))+dot(k(1),k(2)))^2").unwrap(),
        "nested" => vakint_parse!("((dot(p(5),k(1))+dot(k(1),k(2)))^2+dot(k(1),k(1)))^3").unwrap(),
        "gl06" => {
            let a = vakint_parse!("dot(p(5),k(1))").unwrap();
            let b = vakint_parse!("dot(k(1),k(2))").unwrap();
            let c = vakint_parse!("dot(k(1),k(1))").unwrap();
            8 * (&a + &b) * &a * c.clone().pow(2)
                - 4 * (&a + &b).pow(2) * c.clone().pow(2)
                - 4 * a.pow(2) * c.pow(2)
        }
        _ => panic!("unknown case"),
    };
    let indexed = Vakint::convert_from_dot_notation(input.as_view());
    let scalar = Vakint::convert_to_dot_notation(&VakintSettings::default(), indexed.as_view()).unwrap();
    assert_eq!(scalar, input);
    assert_eq!(indexed, Vakint::convert_from_dot_notation(indexed.as_view()));
    if case == "gl06" {
        let expected: Atom = -4 * vakint_parse!("dot(k(1),k(2))").unwrap().pow(2)
            * vakint_parse!("dot(k(1),k(1))").unwrap().pow(2);
        let [a, b, c] = [
            vakint_parse!("dot(p(5),k(1))").unwrap(),
            vakint_parse!("dot(k(1),k(2))").unwrap(),
            vakint_parse!("dot(k(1),k(1))").unwrap(),
        ];
        // Both polynomials have degree at most two in each scalar product.
        // Three distinct exact points per variable certify the full identity.
        for a_value in [-1, 0, 1] {
            for b_value in [-1, 0, 1] {
                for c_value in [-1, 0, 1] {
                    let evaluate = |expression: &Atom| expression
                        .replace(a.clone()).with(Atom::num(a_value))
                        .replace(b.clone()).with(Atom::num(b_value))
                        .replace(c.clone()).with(Atom::num(c_value));
                    assert_eq!(evaluate(&scalar), evaluate(&expected));
                }
            }
        }
    }
    fs::write(&arguments[3], scalar.to_canonical_string()).unwrap();
    let started = Instant::now();
    for _ in 0..iterations {
        let _ = black_box(Vakint::convert_from_dot_notation(black_box(input.as_view())));
    }
    println!("{{\"case\":\"{case}\",\"iterations\":{iterations},\"elapsed_ns\":{},\"input_bytes\":{},\"indexed_bytes\":{}}}",
        started.elapsed().as_nanos(), input.as_view().get_byte_size(), indexed.as_view().get_byte_size());
}

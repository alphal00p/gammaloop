use std::{env, fs, hint::black_box, time::Instant};

use spenso::{
    contraction::Contract,
    structure::{
        OrderedStructure,
        representation::{Euclidean, RepName},
    },
    symbolic_parallelism::{SymbolicParallelism, set_symbolica_rayon_enabled},
    tensors::{
        data::{DataTensor, DenseTensor, SetTensorData},
        parametric::ParamTensor,
    },
};
use symbolica::{
    atom::{Atom, AtomCore},
    parse,
};

fn main() {
    let args = env::args().collect::<Vec<_>>();
    let dimension = args[1].parse::<usize>().unwrap();
    let density = args[2].parse::<usize>().unwrap();
    let storage = &args[3];
    let iterations = args[4].parse::<usize>().unwrap();
    assert!([4, 8].contains(&dimension));
    assert!([1, 16].contains(&density));
    assert!(["DD", "DS", "SD", "SS"].contains(&storage.as_str()));
    set_symbolica_rayon_enabled(SymbolicParallelism::Serial);
    let left_structure: OrderedStructure<Euclidean> = OrderedStructure::new(vec![
        Euclidean {}.new_slot(dimension, 1),
        Euclidean {}.new_slot(dimension, 2),
        Euclidean {}.new_slot(dimension, 3),
    ])
    .structure;
    let right_structure: OrderedStructure<Euclidean> = OrderedStructure::new(vec![
        Euclidean {}.new_slot(dimension, 2),
        Euclidean {}.new_slot(dimension, 3),
        Euclidean {}.new_slot(dimension, 4),
    ])
    .structure;
    // Coordinate formulas are independent of tensor fibers and storage traversal.
    let left_value = |free: usize, a: usize, b: usize| {
        if (a * dimension + b + free * 5) % density != 0 {
            Atom::Zero
        } else {
            (parse!("audit_x") + Atom::num((a * dimension + b + 1) as i64))
                * (parse!("audit_y") + Atom::num((free + 1) as i64))
        }
    };
    let right_value = |a: usize, b: usize, free: usize| {
        if (a * dimension + b + free * 7) % density != 0 {
            Atom::Zero
        } else {
            (parse!("audit_u") + Atom::num((a * dimension + b + 1) as i64))
                * (parse!("audit_v") + Atom::num((free + 1) as i64))
        }
    };
    let mut left = DenseTensor::repeat(left_structure, Atom::Zero);
    let mut right = DenseTensor::repeat(right_structure, Atom::Zero);
    for free in 0..dimension {
        for a in 0..dimension {
            for b in 0..dimension {
                left.set(&[free, a, b], left_value(free, a, b)).unwrap();
                right.set(&[a, b, free], right_value(a, b, free)).unwrap();
            }
        }
    }
    let left = ParamTensor::composite(if storage.starts_with('D') {
        DataTensor::Dense(left)
    } else {
        DataTensor::Sparse(left.to_sparse())
    });
    let right = ParamTensor::composite(if storage.ends_with('D') {
        DataTensor::Dense(right)
    } else {
        DataTensor::Sparse(right.to_sparse())
    });
    let actual = left.contract(&right).unwrap().tensor.to_bare_dense().data;
    assert_eq!(actual.len(), dimension * dimension);
    let mut canonical_output = String::new();
    for free_left in 0..dimension {
        for free_right in 0..dimension {
            let mut expected = Atom::Zero;
            for a in 0..dimension {
                for b in 0..dimension {
                    expected += left_value(free_left, a, b) * right_value(a, b, free_right);
                }
            }
            let result = &actual[free_left * dimension + free_right];
            assert!(
                (result - &expected).expand().is_zero(),
                "component {free_left},{free_right}"
            );
            canonical_output.push_str(&result.expand().to_canonical_string());
            canonical_output.push('\n');
        }
    }
    fs::write(&args[5], canonical_output).unwrap();
    let started = Instant::now();
    for _ in 0..iterations {
        let _ = black_box(black_box(&left).contract(black_box(&right)).unwrap());
    }
    println!(
        "{{\"dimension\":{dimension},\"density_denominator\":{density},\"storage\":\"{storage}\",\"iterations\":{iterations},\"elapsed_ns\":{}}}",
        started.elapsed().as_nanos()
    );
}

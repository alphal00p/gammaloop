import fcntl,json,subprocess,time
from pathlib import Path
root=Path('/tmp/cff-change-audit/foundation-bugs')
with Path('/tmp/cff-change-audit/measurement.lock').open('a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 (root/'artifacts'/'measurement-lock-receipt.json').write_text(json.dumps({'acquired_epoch':time.time(),'lock':'/tmp/cff-change-audit/measurement.lock','timings_started_after_parent_native_build_complete_signal':True},indent=2)+'\n')
 for script in ['run_perf_matrix.py','run_powered_matrix.py','run_multi_matrix.py']:
  with (root/'artifacts'/f'{Path(script).stem}.log').open('w') as out:
   result=subprocess.run(['/tmp/raised-stack/python',str(root/script)],cwd=root,stdout=out,stderr=subprocess.STDOUT)
  if result.returncode:raise SystemExit(f'{script} failed: {result.returncode}; no retries')
 print('All three matrices completed; releasing measurement lock',flush=True)

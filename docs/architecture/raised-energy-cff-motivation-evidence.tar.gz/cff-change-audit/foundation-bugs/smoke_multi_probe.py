import hashlib,itertools,json,subprocess,time
from pathlib import Path
p=Path('/tmp/cff-change-audit/foundation-bugs/artifacts');out=p/'multi-smoke';out.mkdir(exist_ok=True)
rows=[];outputs={}
for dimension,density,storage,variant in itertools.product([4,8],[1,16],['DD','DS','SD','SS'],['final','baseline']):
 name=f'd{dimension}-density{density}-{storage}-{variant}';atom=out/f'{name}.atom';log=out/f'{name}.log'
 switches=['CFF_AUDIT_OLD_KERNEL=1'] if variant=='baseline' else []
 cmd=['taskset','-c','16-23','/tmp/raised-stack/run','env','RAYON_NUM_THREADS=2','CFF_AUDIT_TRACE=1',*switches,str(p/'multi-storage-probe'),str(dimension),str(density),storage,'1',str(atom)]
 start=time.monotonic()
 with log.open('w') as stream:r=subprocess.run(cmd,stdout=stream,stderr=subprocess.STDOUT,timeout=120)
 row={'dimension':dimension,'density_denominator':density,'storage':storage,'variant':variant,'command':cmd,'exit_code':r.returncode,'seconds':time.monotonic()-start,'log':str(log)}
 if atom.exists():
  row['output_sha256']=hashlib.file_digest(atom.open('rb'),'sha256').hexdigest();key=f'{dimension}-{density}';outputs.setdefault(key,row['output_sha256']);row['all_storage_and_variants_match']=row['output_sha256']==outputs[key]
 row['trace_activated']='CFF_AUDIT_CONTRACT' in log.read_text()
 rows.append(row);(p/'multi-storage-smoke.json').write_text(json.dumps(rows,indent=2)+'\n')
 if r.returncode or not row.get('all_storage_and_variants_match') or not row['trace_activated']:raise SystemExit(json.dumps(row))
print(json.dumps({'passed':len(rows),'variants_and_storages_match':True,'seconds':sum(r['seconds'] for r in rows)},indent=2))

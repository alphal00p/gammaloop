import json,statistics,sys
from pathlib import Path
root=Path('/tmp/cff-change-audit/foundation-bugs/artifacts')
rows=[]
for directory in sys.argv[1:]:
 p=root/directory/'manifest.json';data=json.loads(p.read_text());group={}
 for run in data['runs']:
  if run['warmup']:continue
  assert run['exit_code']==0 and run['complete_output_matches']
  group.setdefault((run['case'],run['variant']),[]).append(run)
 for case in sorted({key[0] for key in group}):
  row={'suite':directory,'case':case,'variants':{}}
  for variant in ['baseline','final']:
   runs=group[case,variant]
   per_op=[r['measurement']['elapsed_ns']/r['measurement']['iterations'] for r in runs]
   row['variants'][variant]={'runs':len(runs),'median_ns':statistics.median(per_op),'min_ns':min(per_op),'max_ns':max(per_op),'median_max_rss_bytes':statistics.median(r['max_rss_bytes'] for r in runs),'max_rss_bytes':max(r['max_rss_bytes'] for r in runs),'complete_output_sha256':runs[0]['output_sha256']}
  row['baseline_over_final_ratio']=row['variants']['baseline']['median_ns']/row['variants']['final']['median_ns'];rows.append(row)
(root/'matrix-summary.json').write_text(json.dumps(rows,indent=2)+'\n')
for row in rows:
 a=row['variants']['baseline'];b=row['variants']['final'];print(f"{row['suite']:20} {row['case']:25} old {a['median_ns']/1e6:10.6f} ms [{a['min_ns']/1e6:.6f},{a['max_ns']/1e6:.6f}] current {b['median_ns']/1e6:10.6f} ms [{b['min_ns']/1e6:.6f},{b['max_ns']/1e6:.6f}] ratio {row['baseline_over_final_ratio']:.3f}")

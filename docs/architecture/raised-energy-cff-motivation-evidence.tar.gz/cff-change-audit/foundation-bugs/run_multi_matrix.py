import hashlib,itertools,json,os,subprocess,time
from pathlib import Path
root=Path('/tmp/cff-change-audit/foundation-bugs')
artifacts=root/'artifacts';out=artifacts/'multi-performance';out.mkdir(exist_ok=True)
binary=artifacts/'multi-storage-probe';binary_hash=hashlib.file_digest(binary.open('rb'),'sha256').hexdigest()
manifest={'purpose':'synthetic 4D and 8D symbolic component stress supplementing physical multi-index traces','source':str(root/'multi_storage_probe.rs'),'source_sha256':hashlib.file_digest((root/'multi_storage_probe.rs').open('rb'),'sha256').hexdigest(),'binary_sha256':binary_hash,'cpu_affinity':'8','rayon_workers':1,'symbolic_parallelism':'Serial','rounds':6,'warmup_policy':'one excluded process per variant/case; complete component oracle outside each timed loop','memory_policy':'wait4 whole child peak RSS, includes fixture/oracle/setup/output, not isolated allocation','runs':[]}
expected={}
for dimension,density,storage in itertools.product([4,8],[1,16],['DD','DS','SD','SS']):
 case=f'd{dimension}-density{density}-{storage}'
 iterations=10 if dimension==8 and density==1 else 100
 for round_index in range(-1,6):
  for variant in (['final','baseline'] if round_index%2==0 else ['baseline','final']):
   name=f'{case}-{variant}-{round_index}';atom=out/f'{name}.atom';log=out/f'{name}.log'
   switches=['CFF_AUDIT_OLD_KERNEL=1'] if variant=='baseline' else []
   cmd=['taskset','-c','8','timeout','--signal=TERM','--kill-after=5s','120s','/tmp/raised-stack/run','env','RAYON_NUM_THREADS=1',*switches,str(binary),str(dimension),str(density),storage,str(iterations),str(atom)]
   load_before=os.getloadavg();started=time.monotonic()
   with log.open('w') as stream:
    proc=subprocess.Popen(cmd,stdout=stream,stderr=subprocess.STDOUT)
    _,status,usage=os.wait4(proc.pid,0);proc.returncode=os.waitstatus_to_exitcode(status)
   row={'case':case,'variant':variant,'round':round_index,'warmup':round_index<0,'command':cmd,'exit_code':proc.returncode,'wall_seconds':time.monotonic()-started,'host_loadavg_before':load_before,'host_loadavg_after':os.getloadavg(),'max_rss_bytes':usage.ru_maxrss*1024,'log':str(log)}
   if proc.returncode==0:
    row['measurement']=json.loads(log.read_text().strip().splitlines()[-1])
    row['output_sha256']=hashlib.file_digest(atom.open('rb'),'sha256').hexdigest()
    # Storage must not change complete components; density/dimension define input.
    key=f'd{dimension}-density{density}'
    expected.setdefault(key,row['output_sha256']);row['complete_output_matches']=row['output_sha256']==expected[key]
   manifest['runs'].append(row);(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
   print(json.dumps(row),flush=True)
   if proc.returncode or not row.get('complete_output_matches'):raise SystemExit('failed correctness or completion; no retries')

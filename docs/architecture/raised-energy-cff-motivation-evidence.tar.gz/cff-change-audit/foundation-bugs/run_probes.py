import concurrent.futures
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import time

root = Path('/tmp/cff-change-audit/foundation-bugs')
label = sys.argv[1]
data = json.loads((root / 'artifacts' / f'{label}-list.json').read_text())
selected = {
'canonicalization_keeps_explicit_dummies_distinct_from_compact_dot_indices',
'canonicalization_keeps_external_dummy_names_distinct_from_canonical_dummies',
'canonicalization_keeps_dual_external_slots_distinct_from_canonical_dummies',
'canonicalization_ignores_indices_from_canceled_representation_groups',
'products_of_tensor_sums_keep_closed_indices_and_factorization',
'products_of_tensor_sums_preserve_genuine_external_indices',
'factorized_canonicalization_rejects_mismatched_external_indices',
'factorized_canonicalization_rejects_overcontracted_indices',
'tensor_canonicalization_closes_contractions_inside_nested_sums',
'pruning_nested_zero_preserves_unrelated_sum_factors',
'collect_chains_preserves_factorized_scalars_without_chains',
'compact_inner_product_preserves_explicit_spectator_slots',
'compact_inner_product_contracts_only_repeated_spectators',
'scalar_weighted_compact_vector_argument_becomes_slot_and_factor',
'product_of_two_compact_vectors_is_not_a_rank_one_argument',
'compact_vector_times_explicit_tensor_is_not_a_rank_one_argument',
'dot_conversion_preserves_factorized_scalar_powers',
'dot_conversion_preserves_existing_indices',
'dot_conversion_preserves_reciprocal_powers',
'loop_normalization_uses_numeric_imaginary_coefficients',
'tensor_reduction_preserves_symbolica_user_namespaces',
'tensor_reduction_preserves_factorized_scalar_cancellation',
}
folder = root / 'artifacts' / label
folder.mkdir(parents=True, exist_ok=True)
probes=[]
for suite in data['rust-suites'].values():
 tests=[name for name in suite['testcases'] if name.split('::')[-1] in selected]
 if not tests: continue
 binary=Path(suite['binary-path'])
 copied=folder / binary.name
 shutil.copy2(binary,copied)
 binary_hash=hashlib.sha256(copied.read_bytes()).hexdigest()
 for name in tests:
  probes.append({'test':name,'binary':str(copied),'binary_sha256':binary_hash,'cwd':suite['cwd']})
found={p['test'].split('::')[-1] for p in probes}
assert found == selected, sorted(selected-found)

def run(probe):
 name=probe['test'].replace('::','__')
 log=folder / f'{name}.log'
 cmd=['/tmp/raised-stack/run','env','INSTA_UPDATE=no','INSTA_FORCE_PASS=0','RAYON_NUM_THREADS=2',probe['binary'],probe['test'],'--exact','--nocapture']
 if label.startswith('baseline'):
  cmd=['taskset','-c','16-23',*cmd]
 start=time.monotonic()
 with log.open('w') as out:
  result=subprocess.run(cmd,cwd=probe['cwd'],stdout=out,stderr=subprocess.STDOUT,timeout=180)
 return {**probe,'command':cmd,'cwd':probe['cwd'],'exit_code':result.returncode,'elapsed_seconds':time.monotonic()-start,'log':str(log)}
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as workers:
 results=list(workers.map(run,probes))
report={'source':'d55a0f3e9d25e5c64bdb9ef9fb57749ecf680390','label':label,'test_processes':2,'cpu_affinity':('16-23' if label.startswith('baseline') else 'inherited'),'results':results,'passed':sum(p['exit_code']==0 for p in results),'failed':sum(p['exit_code']!=0 for p in results)}
(folder/'results.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'label':label,'passed':report['passed'],'failed':report['failed'],'tests':[{k:p[k] for k in ['test','exit_code']} for p in results]},indent=2))

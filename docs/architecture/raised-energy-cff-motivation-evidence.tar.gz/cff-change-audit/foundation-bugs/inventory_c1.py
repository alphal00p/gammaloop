import json,subprocess
from pathlib import Path
root=Path('/tmp/cff-change-audit/foundation-bugs');repo=Path('/common/dev/gammaloop/higher-power-energies-review')
commit='5687de4b4bbf0eb963ff018fc6f560f5607ffc48';base='39561014'
rows=[]
def add(number,change,kind,evidence,paths,missing=''):
 rows.append({'id':f'C1-{number:02}','owner':1,'change':change,'motivation_kind':kind,'evidence':evidence,'missing_action':missing,'paths':paths})
I='crates/idenso/';S='crates/spenso/';V='crates/vakint/'
add(1,'Reserve explicit compact-parser dummy names','reproduced error',
 'Current pass / old scoped implementation ContractedMoreThanOnce(d_1000000); source26b57 records physical ttH reduction to this case. Rc<Cell> sharing predates this change.',
 [S+'src/network/parsing/mod.rs',I+'tests/network_dumb.rs'])
add(2,'Reserve external and dual indices during canonical dummy naming','reproduced errors',
 'Current passes / old scoped implementation overcontracts genuine external mink(d_0) and lor(d_0) indices.',[I+'src/lib.rs',I+'tests/network_dumb.rs',I+'src/tensor/tests/canonicalization.rs'])
add(3,'Ignore canonical names from canceled representation groups','reproduced canonical identity defect',
 'Old result chooses d_1 while equivalent isolated contraction chooses d_0; current canonical forms coincide. This is canonical identity, not a demonstrated numerical discrepancy.',[I+'src/lib.rs',I+'tests/network_dumb.rs'])
add(4,'Preserve completed contractions across nested tensor sums in pinned Symbolica','source-recorded physical and reduced bug',
 'Actual4d0a833 patch merges max occurrence counts including completed contractions. Source26b57 records reduced panic and ttH lineage; fresh audit retains fixed dependency and passes controls.',
 ['Cargo.toml','Cargo.lock','crates/gammaloop-workspace-hack/Cargo.toml','examples/api/rust/epem_a_ddxg_xs_LO/inspect_events.rs',I+'src/tensor/canonicalize.rs',I+'src/tensor/tests/canonicalization.rs',I+'tests/network_dumb.rs'],
 'No fresh execution of the old0441 dependency; do not present source-history receipts as a fresh run.')
add(5,'Prune antisymmetric zeros locally without distributing spectators','reproduced factorization defect; full-method timing measured',
 'Old returns A*S+B*S, current retains (A+B)*S. Exact values agree; requested factorization contract differs. Public canonicalizer no-zero stress median7.430→0.361ms (20.61x) measures the full method under scoped ablation.',[I+'src/tensor/canonicalize.rs',I+'src/tensor/tests/canonicalization.rs'])
add(6,'Skip chain collection on expressions with no chains','performance simplification; no old correctness failure',
 'Both old/current preserve existing scalar and captured140KB physical g-g numerator exactly. Old Symbolica collection does not inherently expand. Controlled six-round public-method matrix: captured g-g14.483→0.0835ms; scalar31.408→0.239us, complete outputs unchanged.',[I+'src/shorthands/chain.rs'])
add(7,'Allow one implicit compact axis beside explicit spectator slots','new supported syntax',
 'Old public parsing rejects both spectator cases; current external-slot checks pass. Component values are not certified by these particular tests.',[S+'src/network/parsing/materialization.rs',S+'src/network/parsing/test.rs'])
add(8,'Allow scalar-weighted compact vectors while retaining ambiguity checks','new supported syntax',
 'Old private materializer fails the weighted-vector test, which inspects product/slot form. Two added controls assert private-stage pass-through for two vectors and vector-times-open-tensor. None checks a complete public contraction.',[S+'src/network/parsing/materialization.rs',S+'src/network/parsing/structure_inference.rs'],
 'Prefer complete public parser/contraction certificates and supported ambiguity behavior over the private product/slot assertion and private-stage pass-through assertions.')
add(9,'Freshen independent copies of powered scalar dots','correctness motivation currently unproved; measured extra cost',
 'Four existing powered-dot/GL06 tests pass both old and current converter with final Lorentz consumers. Separate square/nested/GL06 probes also give identical complete scalar round-trips. Current conversion medians are1.41x/2.11x/1.17x slower; no current necessity is established.',[V+'src/lib.rs',V+'tests/tensor_reduction_tests.rs'],
 'No necessity established by current tests; PySecDec serialization/manual integration remains outside fresh coverage.')
add(10,'Use numeric imaginary coefficients in Vakint normalization','reproduced wrong symbolic coefficient',
 'After canonical user i registration old builtin normalization contains that variable; current uses exact numeric i and matches (i*pi^2)^(-L) for1–3loops.',[V+'src/lib.rs',V+'src/fmft.rs',V+'src/matad.rs',V+'tests/tensor_reduction_tests.rs',V+'tests/integral_evaluation_analytic_tests.rs'])
add(11,'Preserve canonical user namespaces across FORM','reproduced parsing failure',
 'Old tensor reduction produces invalid duplicated symbolica namespace with braces; current round-trip/tensor-reduction regression passes.',[V+'src/lib.rs',V+'tests/tensor_reduction_tests.rs'])
add(12,'Generalize grouped Atom contraction across tensor storage kinds','performance change, not missing dense/mixed capability',
 'Root physical g-g trace activates dense multi-index path; all32 fresh synthetic DD/DS/SD/SS dimension4/8 full/1-of16 cases pass old and current with independent complete component sums. Six-round timing matrix completes: full-support DD/DS/SD medians1.31–1.98x faster, mostly unchanged SS; zero-filled dense stress23.35x/45.13x faster. No universal speedup follows.',[S+'src/tensors/parametric.rs'])
add(13,'Score contraction candidates by intermediate symbolic cost','selectable performance heuristic',
 'Root benchmarks all available presets on physical/captured inputs. Existing ac99d32d source has limited earlier scheduler comparisons; no universal optimality or allocation measurement is claimed.',[S+'src/network/contract.rs',S+'src/network/mod.rs',S+'src/network/tests.rs',S+'src/tensors/parametric.rs'])
add(14,'Register already-created scalar aliases without recompressing the root','performance simplification',
 'Root owns targeted alias replay and complete output checks. Public alias contract is exact expansion of registered definitions; no missing contraction functionality is implied.',[S+'src/network/mod.rs',S+'src/network/tests.rs'])
add(15,'Defer large coefficient broadcasting while preserving ordinary terminal results','resource policy plus terminal-result API contract',
 'Root owns threshold activation and measured memory/time. Ordinary result() remains materialized in sequential and parallel execution; explicit opt-in lazy behavior stays distinct.',[S+'src/network/mod.rs',S+'src/network/tests.rs',S+'src/network/parsing/tensor_from_expression.rs'])
add(16,'Select clang for macOS Rust unwinding','source-recorded platform defect',
 'Source26b57 records GCC Darwin caught-panic abort and standalone clang success. This Linux audit does not freshly reproduce a macOS linker failure.',['.cargo/config.toml'])
add(17,'Guard heavy process trees and keep local runtime outputs out of version control','requested resource/tooling support',
 'New RSS/swap budget watchdog and documented invocation; audit uses existing watchdog for fresh bounded builds and tests. Ignore entries cover generated workspaces, benchmark outputs and lockfiles. No isolated speedup claim.',
 ['bin/ram_watchdog.py','bin/README.md','.gitignore'])
add(18,'Keep manual PySecDec integrations outside automated selections and require supported nextest','explicit test policy/tool compatibility',
 'Filters apply to default/curated/CI profiles; nextest0.9.115 supports custom profile inheritance. This is an acknowledged coverage boundary, not repair of mathematical behavior.',['.config/nextest.toml'])
add(19,'Pin compatible Python Symbolica and UFO loader','source-recorded import fixed-point bug and API requirement',
 'Source26b57 records full SM import hanging on unchanged sqrt rewrite; pinned loader0bdd60a adds fixed-point behavior and was checked on Symbolica2.0/2.2. Current metadata requires Symbolica>=2. No fresh old-loader run in this audit.',['pyproject.toml','uv.lock'])
add(20,'Regenerate shared dependency feature metadata','build metadata consistency',
 'Hakari feature unification adds aho-corasick/rust-embed-utils and updated regex feature sets, along with the pinned algebra dependency. No independent physics or runtime speed claim.',
 ['Cargo.lock','crates/gammaloop-workspace-hack/Cargo.toml'])
add(21,'Remove excess trait bounds and migrate sum-capable consumers','API simplification and required consumer migration',
 'Complex EvaluationDomain no longer unnecessarily requires FloatLike; network execution/parsing consumers carry the bounds needed for terminal sum materialization; unused AddAssign lifetime binder removed. Build compatibility is evidence, not a reproduced old numerical failure.',
 [S+'src/algebra/complex/symbolica_traits.rs',S+'src/network/mod.rs',S+'src/network/parsing/tensor_from_expression.rs'])
add(22,'Preserve physical numerator factors in diagnostic consumers','explicit factorization policy and revised behavioral checks',
 'Idenso gluon diagnostics stop distributing vertex/numerator products and retain index-domain checks. Existing timing comments are preserved and clarified; no isolated benchmark claim for each test edit.',
 [I+'tests/bare_symb.rs',I+'tests/network_dumb.rs',I+'tests/network_informed.rs'])
add(23,'Regenerate current optional defaults and schema formatting','generated schema compatibility/formatting',
 'runhistory hide_non_existing_thresholds gets its false default and ceases being required; runtime change is only final-newline removal. Neither is a tensor performance improvement.',
 ['assets/schemas/runhistory.json','assets/schemas/runtime.json'])
add(24,'Clarify the scope of older large-expression observations','documentation correction',
 'Pathology note distinguishes recorded sparse-rank runs from current intermediate-cost preset; no new production behavior.',
 ['docs/architecture/spenso-large-expression-pathology.md'])
changed=[line.split('\t',1) for line in subprocess.check_output(['git','diff','--name-status',base,commit],cwd=repo,text=True).splitlines()]
paths=[]
for status,path in changed:
 ids=[r['id'] for r in rows if path in r['paths']]
 assert ids,path
 paths.append({'owner':1,'commit':commit,'status':status,'path':path,'logical_changes':ids,'coverage_scope':'logical ownership category; no claim every hunk independently has a motivating reproducer'})
assert {path for r in rows for path in r['paths']}=={p['path'] for p in paths}
report={'scope':'Logical motivation inventory for reconstructed commit1','source_tip':'d55a0f3e9d25e5c64bdb9ef9fb57749ecf680390','evidence_policy':'Fresh narrow ablation results are distinguished from source-recorded bugs, new capability, cleanup and pending performance measurements. See foundation-bugs/artifacts/motivation-inventory.md for full scope and invalidated cache receipts.','coverage_policy':'Every changed C1 path maps to at least one logical category; many-to-many shared-file mapping is not proof every hunk had a bug or speedup.','logical_change_count':len(rows),'commit_path_count':len(paths),'distinct_path_count':len(paths),'changes':rows,'paths':paths}
(root/'artifacts'/'foundation-inventory.json').write_text(json.dumps(report,indent=2)+'\n')
md=['# Commit1 logical change/path coverage','',f'{len(rows)} logical categories cover all {len(paths)} changed paths. Mapping is many-to-many; it does not claim causal evidence for each hunk.','','| ID | Change | Motivation |','|---|---|---|']
md += [f"| {r['id']} | {r['change']} | {r['motivation_kind']} |" for r in rows]
md += ['','| Path | Categories |','|---|---|']+[f"| `{p['path']}` | {', '.join(p['logical_changes'])} |" for p in paths]
(root/'artifacts'/'foundation-inventory.md').write_text('\n'.join(md)+'\n')
print(json.dumps({'logical_changes':len(rows),'covered_paths':len(paths),'missing_paths':[]},indent=2))

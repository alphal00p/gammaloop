# Final C2–C7 report review

Reviewed all 49 C2–C7 rows, their inventory evidence, the CFF/core headline conclusions, the relevant Rust/KISS rows and the CFF/core portions of the reproduction guide. Foundation implementation claims and pending Feyngen results are outside this review. No native tests or benchmarks were run, and no production/test/history edits were made. The only additional work was independently hashing evidence files and retaining the authorized final CFF harness artifact.

Initial report digest: `cc70a1c6a065c1ed46fa32764a2a3f11981ec473aa8c8b2bb4688fd177d55a83`. Initial complete-inventory digest: `567b87b379311f8cea1d0afbb09dabb8cefad40834c4868f5f8cc168720e026f`. The parent edited the draft concurrently; resolved findings below were checked in the updated text or corresponding artifacts.

## Findings

1. **Resolved — final timed CFF source was missing from the proposed archive.** `harness-full-probes.rs` plus `skip-probes.patch` reconstructs the unbuffered writer, whereas accepted timing uses `BufWriter` and explicit flush. The final source lived only inside an excluded checkout. At the parent's explicit authorization, copied it without modification to `cff-perf/harness-timed-final.rs`; SHA-256 `0b5abecec5cb6d4cbed0c491901b4c51a4656c78c6367e0542ad871e1699e4e3` matches `timed-harness-build-v2.json`. Receipt: `cff-perf/timed-harness-source-retention.json`; local CFF README now identifies this exact source. The parent is updating the top-level guide.

2. **Resolved — lock provenance was overstated.** The draft said the shared lock prevents build overlap, but `cff-perf/build.sh` itself has no such lock. Builds were coordinated to finish before accepted timing families. The updated report/guide now distinguish build coordination from the measurement lock.

3. **Resolved — absence of a demonstrated GL04 benefit was stated as absence of benefit.** The Rust-pattern row originally said losing-count memoization and contenders “do not pay.” Six-run wall distributions with small differences do not establish that categorical conclusion. Updated wording correctly says no benefit is demonstrated on the completed GL04 inputs. The distinct partial GL16 reachability evidence remains visible.

4. **Resolved — extra-adjoint causal scope needed qualification.** The explicit Weyl-matrix examples reject applying an additional adjoint to an inverse-process RHS. They are not, by themselves, a fresh reproduction of original-main behavior. C5-02 now explicitly identifies the proposed route and preserves this distinction.

5. **Minor scope/wording corrections sent to parent.** Shared CFF has five variants (current plus four ablations), not “five mechanisms.” The no-compaction flag disables both root normalization and completed-product compaction; wording that attributes the measured cost solely to product compaction is narrower than the actual intervention. Prefer “the combined compaction intervention on this single-component workload.” The largest quark-bubble median is 1.404528 seconds, so a three-decimal range ends at 1.405, not 1.404. These do not alter the substantive findings.

The draft's remaining numerator-matching-pending marker is outside this bounded review and must be replaced by its owning reviewer before publication.

## Coverage and evidence checks

The report contains every expected C2–C7 ID exactly once: 11, 12, 11, 6, 8 and 1 rows respectively. Overall inventory counts independently agree: 73 categories, 579 commit/path records and 505 distinct paths. This is complete row/path ownership coverage, not proof every changed hunk has an independent causal reproducer.

Shared CFF table medians agree with `cff-perf/timed-final/summary.json`. The 210 successful observations comprise 180 measured runs and 30 warmups. All complete-expression comparisons pass. The 285 numerical observations, 15 independent pinch oracles, maximum 1.507e-15 pinch error and 28 public-contract checks agree with the receipts. Cache benefit and the scoped compaction cost are supported; no streaming memory benefit, Rational-storage speedup or merged-occurrence comparison is claimed.

Core tables agree with `core-perf/timings/analysis.json`: 56 completed observations, including 48 measured and eight warmups, with complete DOT and inspection JSON equality. Four GL16 observations are correctly censored at 180 seconds without complete outputs. The 8% map-count objective improvement is a partial trace result, not completed physical-value parity or a total-time speedup. Full parsed-source/bounds records match at all 52 paired misses; hits and other canonical-key fields remain unlogged. The report preserves that limit.

**Vakint linkage independently established.** Rehashed 24 actual earlier smoke DOT files and 168 actual timed/warmup DOT files, verified each digest against its own manifest, then compared each complete relative-path/digest map directly with its earlier validated case. All 56 observations match. This does not rely on warmup-only stability. Inspected the existing scalar and quark full-Laurent parity receipts; did not rerun their algebra. New independent receipt: `nonfoundation-vakint-linkage-review.json`; replay script: `verify_vakint_linkage.py`. The prior agent receipt `physical/vakint-modes/balanced-results/default-binary-parity.json` is consistent.

The unresolved inspect-JSON headline is supported by the current saved-state reproduction and `physical/inspect-weights/attribution.json`: plain numerical values agree, additional-weight JSON fails, and the map-key representation is inherited while commit 4 introduces the JSON path. It is correctly presented as a newly found output defect, not historical motivation.

## Causal distinctions retained

Fresh historical-method wrong-value replay in this scope applies to the three parser cases. Current malformed-input, wide-balance and zero-tree probes validate the final behavior; their older failures are recorded source evidence, not newly rebuilt old validators. Embedded-contour normalization, owner-mass scaling, GL08 routing, symbolic-pi resolution, CLI scope/persistence, phase/gauge sewing, Laurent-depth and analytic-return failures remain explicitly sourced historical evidence or independent counterexamples. Current physical/Vakint comparisons do not turn all of those into fresh old-versus-new reproductions.

Requested functionality and type/API cleanup remain legitimate categories without invented bugs: generalized raised-power support, rational coefficient storage, direct/projected routes, uniform M, command/reporting workflows, both Vakint modes and documentation. No unsupported isolated performance claim was found for those rows after the corrections above.

## Final reproduction-guide addendum

The top-level README now names the exact buffered timed CFF main and its v2 receipt; its retained-source SHA was rechecked and still matches. Shared CFF contract/timing drivers, core driver/build/binary/source-refresh receipts, and Vakint cards/drivers/resource-limit files exist at the referenced family paths. Commands are documented as original-path provenance, with fresh output destinations and local path/environment adjustment required. No native, build or benchmark commands were executed. The per-family CFF README still named the earlier timed-harness-build.json in one sentence; corrected that artifact reference to timed-harness-build-v2.json under the earlier authorization to update its evidence reference.

The report generator is root/build_audit_report.py. Its five-variants, combined root/product compaction, 1.405-second rounding, proposed-extra-adjoint and no-demonstrated-GL04-benefit corrections are present.

**Remaining method-label correction sent to parent:** Vakint also rotates and reverses its case order. The actual six measured rounds have projected mode first 4/6 times for scalar/hedge, scalar/legacy and quark/legacy, and 3/6 for quark/hedge. Call these interleaved rounds and preserve this imbalance when discussing small effects. The current report/guide distinguishes Feyngen order imbalance but still describes the remaining primary families collectively as exactly balanced. Receipt: nonfoundation-vakint-order-review.json. This does not invalidate the observations or the no-consistent-mode-speed-benefit conclusion; no rerun is requested.

Current C2–C7 inventory audit conclusions, CFF results and core results contain no stale pending/in-progress execution claim. The only inventory occurrence of pending is an explicitly historical phase-source sequence followed by its completed correction; it should retain that source-evidence scope. Feyngen publication placeholders remain the owning agent's responsibility.

The Vakint entry-point cell currently names the directory generically. For a concrete reproduction command, identify `physical/vakint-modes/run_balanced_timings.py --binary PATH_TO_REBUILT_CLI --output NEW_OUTPUT --rounds 6 --cpu 8` under its 8 GB watchdog; it acquires the measurement lock internally. Existing per-observation manifests already retain the actual CLI commands.

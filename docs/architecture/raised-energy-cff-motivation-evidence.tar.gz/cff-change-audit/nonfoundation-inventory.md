# Change motivation inventory: reconstructed commits 2–7

Pinned source: `d55a0f3e9d25e5c64bdb9ef9fb57749ecf680390`. 49 logical categories, 543 commit/path records, 480 distinct paths.

**This is a source-evidence inventory, not a claim that every change has fresh causal proof.** The initial inventory phase inspected local history, mapping, code/test names and durable review evidence. Fresh shared-CFF correctness, parser replay and five-variant performance experiments are now recorded in `cff-perf/results.md`; historical evidence below retains its original scope. Parent and sibling agents own the other fresh experiment families.

Every changed path is assigned in `nonfoundation-inventory.json`. That provides a complete path census, not a fresh complete hunk-by-hunk causal review. Mixed files intentionally map to several logical behaviors. Consumer migrations, schemas, fixtures and documentation inherit their owning functional behavior. C4-08 is a cross-stack test-policy category: numerical comparison helpers belong to3, shared-crate tests to2, and matrix/archive consumers to4. It is grouped under4 for readability, without asserting that all hunks landed there.

Evidence terms: **recorded failure** means an existing report/source body describes an executed failure; **source-level** means a concrete code counterexample without an old executable observation for every branch; **limited measurement** means exactly the stated workload/count, never a universal speedup; **feature/cleanup** does not imply a prior bug.

Remaining performance questions: C2-02; a larger multi-component case for C2-03/04; C3-05/06/07/08; C5-05; C6-01. Fresh C2-03/04 experiments are reported separately and establish cache benefit, no streaming benefit on the selected cases, and a scoped compaction cost. Fresh core cache/proposal comparisons are in `core-perf/results.md`: complete GL04 output parity and small whole-workflow differences; GL16 full workflows timed out, with bounded partial mechanism evidence only. Historical union-envelope policy and rank-analysis changes remain unisolated. The physical gluon double triangle can exercise tensor/CFF/UV work, but cannot alone discriminate parser scope, electroweak sewing, 50,000-class Feyngen lookup, malformed-input validation, or Laurent truncation; those require the listed representative inputs.

Important KISS caveat: the original Vakint projection split was partly motivated by an overly broad reading of the no-expansion rule. `PHASE_CONVENTIONS_FIX.md:653` explicitly acknowledges that analytic UV numerators may expand. The user subsequently requested both input modes. Their equality/correctness is tested; comparative benefit remains to be measured.

## Commit 2: `0b902a939`

### C2-01: Shared generalized CFF engine and selectable representation

**Motivation:** new capability. **Sources:** `8a3512ed`, `939af81f`, `481a4301`.

Repeated propagator powers and bounded energy numerators, including lower/contact sectors, joined/disconnected components and residual tree denominators.

**Evidence:** New crate in commit 2; README and current exact-source architecture; current contour tests. No prior equivalent whole crate exists at main.

**Missing or next action:** Feature motivation is established by the requested raised-energy scope. Benchmark comparable old supported cases and final generalized cases separately; unsupported main inputs are not an old wrong-result bug.

**Existing regression:** three-dimensional-reps eval.rs repeated_cubic_pole_with_squared_denominator_numerator_pinches_to_simple_pole; lower_sector_powered_pole_contact_reconstructs_numerator_derivatives; independent_bubbles_bounded_maps_match_component_cff_product

### C2-02: Retain independent repeated propagator occurrences

**Motivation:** requested optimization / representation change. **Sources:** `ac99d32d`.

Independent repeated channels retain separate rank capacities and residue entries; complete mapped contours must agree after summation.

**Evidence:** Source ac99d32d explicitly requests independent degenerate edges and records aggregate GL16/166-case results; not an isolated repeated-occurrence benchmark.

**Missing or next action:** Run identical captured CFF input with old merging and new independent occurrences; record native rows, total generation time/memory and complete contour values. Physical numerator with repeated denominators plus a scalar high-rank control is appropriate.

**Existing regression:** three-dimensional-reps eval.rs repeated_quintic_rank_eight_denominator_pinches_match_lower_channels; terminal_duplicate_contact_sign_is_routing_and_order_invariant

### C2-03: Stream component products and shorten intermediate lifetimes

**Motivation:** observed memory problem; remedy not isolated. **Sources:** `d3dd17d9`, `7b0b09ed`.

Lower-sector products previously retained complete Cartesian intermediate layers and duplicated momentum maps.

**Evidence:** Source d3dd17d9: prior GL16 hit actual 30 GB process-tree guard; lazy completed Cartesian layers introduced, individual benefit explicitly unmeasured. 7b0b09ed adds lazy per-parent fanout/owned branches and early release.

**Missing or next action:** A/B the captured multi-component high-rank source, keeping all other caching/compaction unchanged; memory and wall time both matter. Final GL16 completion cannot apportion benefit to this change.

### C2-04: Reuse exact bases and compact completed products

**Motivation:** observed memory problem; limited prototype measurement. **Sources:** `e4f5f778`.

Repeated plain/direct CFF bases are regenerated; completed equal chains increase retained output.

**Evidence:** Source e4f5f778: captured 12-edge/two-loop prototype completed in 617.75 s with 14.48 GB peak; three complete fixtures byte-identical with optimization off/on. No completed baseline time is given there.

**Missing or next action:** Recover baseline and prototype artifact if possible, then controlled cache-only/compaction-only A/B on the same captured source and smaller routine cases. Compare mathematical outputs, not historical byte identity alone.

### C2-05: Correct shared terminal/embedded contour normalization

**Motivation:** recorded wrong-value failure and passing correction. **Sources:** `e30d799e`, `9c8aa0f9`.

An ordinary terminal embedded in a larger UV construction has the wrong sign even though the standalone route supplies the correct prefactor.

**Evidence:** docs/architecture/raised-energy-cff-implementation.md:34-43 records unchanged depth-three banana exposing component-frame versus advertised core-loop convention; unchanged depth-two/depth-three test passes after correction.

**Missing or next action:** Extract/replay the documented minimal embedded/standalone joined/disconnected contour counterexample; no performance justification is necessary for the sign fix.

**Existing regression:** Independent two-loop contour and unchanged depth-two/depth-three banana; complete signed contours in shared generation/eval and core CFF tests

### C2-06: Correct diagnostic numerator arithmetic

**Motivation:** recorded public-API old-fail / fixed-pass. **Sources:** `9c8aa0f9`.

Old -2**2 = 4; 2**3**2 = 64; 2**4294967296 = 1. Correct -4 / 512 / checked error.

**Evidence:** docs/architecture/raised-energy-cff-review.md finding 4 records a compiled public evaluate_expression reproduction; implementation.md finding 4 records corrected contract.

**Missing or next action:** Fresh old/new public evaluator replay is cheap and appropriate; physical graph timing does not motivate parser precedence.

**Existing regression:** crates/three-dimensional-reps/src/eval.rs:1259 evaluates_integer_powers_with_arithmetic_precedence

### C2-07: Validate bounds before fast paths and reject malformed graph signatures

**Motivation:** recorded public-API failures and passing correction. **Sources:** `9c8aa0f9`.

Invalid edge bounds must not pass because preserved/tree/rational output returns early; malformed dimensions must return invalid GraphValidation.

**Evidence:** review.md findings 10/11: public preserved one-edge zero-loop graph accepts unknown bound 999; public malformed signature [1] with declared zero loops panics. implementation.md records structured rejection.

**Missing or next action:** Fresh minimal invalid-input replay on source before review and current library, retaining error contracts. Inputs are deliberately malformed, not physical benchmark cases.

**Existing regression:** validator.rs:213 rejects_malformed_signature_dimensions; generation input-bound regressions

### C2-08: Additional input arithmetic/shape validation

**Motivation:** source-level failure analysis and current regression. **Sources:** `9c8aa0f9`, `reconstructed-review`.

Shape mismatches, zero normalization scale, integer overflow and invalid maps should reject at the public boundary.

**Evidence:** Embedded shared review and core reconciliation records: widen momentum residual accumulation, checked bounds/conversions; eval shape/scale/power validation. No recorded old process execution for every rejection branch.

**Missing or next action:** Replay focused boundary cases on old implementation where compatible. Do not label all defensive checks as observed physics bugs.

**Existing regression:** eval.rs:1080 evaluation_rejects_input_shape_zero_scale_and_oversized_power; source momentum and energy-degree overflow regressions

### C2-09: Rational coefficient storage across shared engine and consumers

**Motivation:** domain modeling / simplification. **Sources:** `ce6654cc`.

Exclude arbitrary symbolic values from coefficient storage; make arithmetic domain explicit.

**Evidence:** Source ce6654cc and implementation report: stores coefficients as Rational, converts at Atom/Arb output boundaries. Previous rational-valued Atoms were already exact.

**Missing or next action:** No old numerical inexactness bug is claimed. Benchmark identical CFF input for coefficient arithmetic/allocation if a performance benefit is asserted; otherwise justify by type invariant and smaller API.

### C2-10: Shared expression assembly, surface copying and builder consolidation

**Motivation:** maintenance / KISS. **Sources:** `9c8aa0f9`.

One owner for expression surface copying, interning, variant insertion and numerator-label finalization.

**Evidence:** implementation.md Rust-pattern section: existing surface interner becomes owned ExpressionAssembler reused by three builders, removing duplicated insertion/finalization.

**Missing or next action:** No standalone bug or speedup established. Assess deletion/duplication reduction and whole-value parity; microbenchmark only if this changes a hot path.

### C2-11: Preserve zero values for filtered and infinite denominator trees

**Motivation:** source-traced numeric/symbolic contract mismatch. **Sources:** `reconstructed-review`.

Filter every denominator branch, or evaluate an Infinite denominator marker: complete value must be zero before and after variant fusion.

**Evidence:** Embedded review-c6e0ff0ffae8 records numeric panic on filtered empty trees, approximately 1e80 for the Infinite inverse marker, and fusion traversal of an absent root; the symbolic API already defined these as zero.

**Missing or next action:** Fresh public zero-value evaluation and fusion replay; retain distinction from ordinary exactly-zero linear surfaces, whose separate 1e-80 convention was not changed.

**Existing regression:** empty_and_infinite_denominator_trees_evaluate_to_zero; fusion_preserves_zero_from_a_filtered_denominator_tree

## Commit 3: `4dd826961`

### C3-01: Integrate shared raised-energy CFF into GammaLoop and evaluator persistence

**Motivation:** feature integration / required callers. **Sources:** `939af81f`, `481a4301`, `2bbc6f59`, `d54de204`.

Raised cuts/numerator cancellation and repeated equal/split model masses reach generation, runtime selection and saved exports.

**Evidence:** Source-to-owner mapping and complete commit 3 CFF review: core adapters, public surfaces, energy assignments and evaluator migration are consumers of the new shared engine.

**Missing or next action:** Use physical raised denominator input and scalar repeated-mass oracle. Old missing capability and necessary caller migrations do not each need a separate invented bug.

**Existing regression:** tests/tests/test_runs/repeated_masses.rs; graph fixtures raised_cut_numerator_cancellation.dot and repeated_bubble_*

### C3-02: Exact owner-preserving local-4D UV source reconstruction

**Motivation:** recorded reconstruction discrepancy / mathematical certificate. **Sources:** `181f77af`, `5c3e7fca`, `d54de204`, `e30d799e`.

GL04 retained owner-5/owner-6 A^2 B^3 denominator multiset and owner-local temporal numerator. Reassignment by denominator incidence or common LMB can corrupt numerator owners/signs.

**Evidence:** exact-powered-denominator-cff-lifting.md:428/522 worked GL04 T0 and 1zs/T2, full reconstruction certificate at :664; source commits identify provenance reconstruction fix.

**Missing or next action:** Use live GL04 source capture and exact complete numerator/denominator certificate to isolate old and current first differing boundary. Do not infer a CFF recursion defect from a reconstruction mismatch.

**Existing regression:** three_d_source.rs GL04 production certificate; exact_source_preserves_the_complete_cubic_propagator_contour; owner relabeling/cancellation/sign/domain regressions

### C3-03: Typed direct/local/projected UV routes and explicit selector-free sums

**Motivation:** architecture / requested feature / cleanup. **Sources:** `c8e76317`, `d54de204`, `ac99d32d`, `9c8aa0f9`.

Direct per-residue subtraction versus complete projected residue sum; normalized localization kernels remain frozen; projection chart/frame values travel together.

**Evidence:** Source ac99d32d explicitly requests clean direct/projected assembly and removal of deferred state. Current architecture defines different complete routes; review reports Result/enum ownership and complete selector truth-table oracles.

**Missing or next action:** Benchmark supported routes on identical graph/settings and verify complete cut values. Route API cleanup itself has no separate old wrong-value reproducer; assess removed stale state and invariant ownership.

### C3-04: Owner-specific integrated UV mass scaling

**Motivation:** recorded physical wrong-value failure and corrected pass. **Sources:** `9c8aa0f9`.

Scale tagged mUV(owner) only when Taylor subgraph contains that owner; freeze disjoint owner and localization kernel, reject partial overlap.

**Evidence:** implementation.md:45-65: strict GL04 discrepancy, identical captures and 90-330 digit replay isolate one finite integrated-localizer coefficient; GL00/disjoint controls reject global rescaling.

**Missing or next action:** Retain GL04 enclosing plus GL00/disjoint/nested controls and independent untouched-baseline two-loop renormalization oracle. These are the motivating correctness cases, not a performance claim.

### C3-05: Keep natural Taylor denominator topologies and factorized numerator ownership

**Motivation:** observed generation/resource problem plus ownership contract. **Sources:** `8a197b8c`, `5c8b46f3`, `26b57b78`.

Forcing different Taylor terms onto one denominator inflates powers/ranks; extracting numerator factors into topology can misassign physical incidence. GL24 quartic DOD1 is a representative owner/rank certificate.

**Evidence:** 8a197b8c removes common-denominator collection; exact-powered-denominator-cff-lifting.md:874 onwards explains Taylor topology requirement. Original source request demands general correction starting GL16. Later source fixes collect denominator branches only before incidence fusion.

**Missing or next action:** A/B actual Taylor pipeline and output source rows on GL24/GL16 plus physical graph; measure generation/memory without changing numerator algebra. Separate correctness of incidence from performance of natural topologies.

**Existing regression:** term_projection_preserves_complete_factorized_values; GL24 quartic actual Taylor and nested_vacuum_denominators_preserve_incidence_and_factorized_numerators

### C3-06: Factorized degree analysis and independent outer rank envelopes

**Motivation:** observed slow/resource stage; no isolated final A/B. **Sources:** `e30d799e`, `5a5a1bfc`, `ac99d32d`.

Analyze independent branches and combine per-edge maximum rather than expanding numerator or building a large tagged sum solely for capacity.

**Evidence:** e30d799e user specifically identifies slow rank-envelope analysis; 5a5a1bfc avoids tagged symbolic sum and analyzes identical branch bodies once. No per-intervention measured speedup in source bodies.

**Missing or next action:** Time identical retained branch inputs old/new, record temporary memory and exact bounds; include high-rank physical numerator and small scalar controls. Never expand a production graph numerator as a diagnostic.

### C3-07: Bound exact-CFF cache keys to each request capacity

**Motivation:** observed GL16 memory limit; design/resource contract. **Sources:** `0ad34794`.

Cache reuse must retain immutable assignment and requested capacity instead of accumulating unrelated maximal degrees.

**Evidence:** Source 0ad34794: unioning independent terms creates unnecessarily large Cartesian degree envelope; request capacity included in cache key. Prior GL16 exceeds guard; no isolated A/B in commit description.

**Missing or next action:** Measure retained bytes/generation time under a sequence of realistic distinct capacity requests, with cached/uncached complete-value equality; cache entry counts alone are not a correctness oracle.

### C3-08: Choose up to three certified derivative-energy assignments by generated map size

**Motivation:** explicit optimization request; aggregate measurement only. **Sources:** `ac99d32d`.

Different derivative-generated hard/soft energy dispatches can produce different native source-map sizes; original numerator owners never move.

**Evidence:** ac99d32d instructions: actual residue-map size is figure of merit; rank only proxy. Recorded GL16 total improves4.23% while projected setup worsens13.96%, across combined optimizations.

**Missing or next action:** Compare all retained certified proposals and old assignment on exact physical source captures, measuring proposal-generation overhead plus selected downstream work; smaller rows are not automatically lower time/memory.

**Existing regression:** three_d_source candidate certificate matrix; every proposal complete contour tests; exact-source architecture bounded selection sections

### C3-09: Route child-soft carriers into parent hard chart

**Motivation:** recorded physical generation defect. **Sources:** `ac99d32d`.

An energy soft for a child becomes hard for parent UV operation; unconverted chart lets already integrated loop momentum survive.

**Evidence:** Source ac99d32d explicitly identifies GL08 finite counterterm retaining an unintegrated inner momentum before compatible parent-chart routing.

**Missing or next action:** Recover GL08 smallest retained finite-counterterm pair and rerun old/new with source ownership/denominator certificates. Current scalar matrix pass is corroboration, not a minimal counterexample artifact.

### C3-10: Resolve symbolic constants before SymJIT compilation

**Motivation:** recorded minimal wrong-value failure. **Sources:** `7b0b09ed`.

Compile SymJIT from mapped numeric evaluator so registered constants have values.

**Evidence:** Source7b0b09ed explicitly records pi^-3 -> infinity in unresolved rational program and correct finite result from mapped numeric evaluator; finite pi/pi^-3 regression.

**Missing or next action:** Fresh pi and inverse-pi public/backend replay is sufficient; no physical speed benchmark required.

**Existing regression:** crates/gammalooprs/src/integrands/process/evaluators.rs finite pi/pi^-3 JIT regression

### C3-11: Validate source integer arithmetic and raised residue selections

**Motivation:** static concrete failure cases and current tests. **Sources:** `reconstructed-review`.

Preserve large transient cancellations in i64 while rejecting unrepresentable output; reject malformed raised groups before indexing.

**Evidence:** Embedded core reconciliation report: unchecked energy cap arithmetic, i32 transient signature overflow, empty raised-group indexing, zero powers and unknown surface IDs; checked Result migration and focused regressions.

**Missing or next action:** Fresh old/new boundary probes, especially release overflow behavior. No prior physical input demonstrating these limits is claimed.

**Existing regression:** overflowing_polynomial_degrees_return_an_error; exact_momentum_signatures_reject_overflow_and_preserve_cancellation; select_indexed_cff_residues malformed-group tests

### C3-12: Uniform nonzero M evaluator parameter and finalized expression ownership

**Motivation:** explicit KISS/API choice. **Sources:** `e30d799e`, `ac99d32d`.

Avoid conditional parameter inventory and keep auxiliary deformation mass distinct from UV owner masses; zero sectors are normalized at producer.

**Evidence:** e30d799e user requests always adding M to evaluator inputs; source architecture retains frozen localizers and zero finalized sectors. No isolated measured overhead/benefit.

**Missing or next action:** Verify public evaluation and error contract for nonzero/zero M. Justify uniform input by simpler API; no rounding/performance bug should be invented.

## Commit 4: `76639bb71`

### C4-01: Command templates and invocation scope

**Motivation:** new capability plus reproduced scope bugs. **Sources:** `bb60b02f`, `49999ca0`, `9c8aa0f9`.

Parameterized reusable blocks need definition-time name/cycle validation and invocation-time variable expansion.

**Evidence:** review.md findings1/2 run through real CLI: nested inline missing variable and boot-card nested parameterized block exit1, equivalent control exits0; implementation.md records inner overrides/inheritance.

**Missing or next action:** Fresh CLI old/new commands with nested -D overrides and boot definitions. No physical contraction benchmark applies.

**Existing regression:** commands/run.rs, session.rs and tests/tests/test_cli.rs scoped/nested run tests

### C4-02: Explicit output, state detection/versioning and history persistence

**Motivation:** capability/policy plus reproduced state-write defect. **Sources:** `0ee54199`, `b58d1ef0`, `ac99d32d`, `9c8aa0f9`.

Scratch folders are blank state; only explicit save writes state; incompatible manifests fail before bincode decode; saved block text retains templates.

**Evidence:** review.md finding3 real scalar-box 3Drep build followed by quit-n writes inside unsaved state. ac99d32d increments format5->6 because generated fields change. Embedded API review records manifest/error restoration boundaries.

**Missing or next action:** Replay scalar-box unsaved/read-only state outputs and saved/reloaded evaluated functions. Version/caller changes are necessary integration, not individual perf optimizations.

### C4-03: 3D representation build/validate/export CLI

**Motivation:** new public workflow. **Sources:** `cf36d272`, `481a4301`, `2bbc6f59`.

Build exact CFF independent of full integrand generation and inspect/export complete expression.

**Evidence:** Source descriptions and test_3d_reps complete public exported-function/load comparisons; shared graph state is the input.

**Missing or next action:** Use physical graph when measuring export/build overhead, but feature is motivated by inspectability and source captures; supported public results and persistence are its acceptance.

### C4-04: Benchmark command, timing reports and temporary minimal evaluation settings

**Motivation:** new observability workflow / test improvement. **Sources:** `a4ea80a9`, `9c8aa0f9`.

Warmup estimates sample count, retains batch, evaluates benchmark, emits report and restores settings.

**Evidence:** Embedded API review: complete benchmark values and settings restored after success and output error; wall timing separates evaluator and inclusive integrand. No old production settings-loss reproducer is claimed.

**Missing or next action:** Execute same process before/after benchmark including deliberate output failure. Long duration can allocate large batch; benchmark resource bound not established. Physical input useful for observer-overhead measurement.

### C4-05: UV profiling and stable finite-range numerical reports

**Motivation:** capability plus reporting/validation defects. **Sources:** `bd513be5`, `d54de204`, `9c8aa0f9`, `reconstructed-review`.

Keep log exponent through display; normalize fixed rays by max component; use hypot and reject nonfinite/unrepresentable data while retaining graph/cut identity.

**Evidence:** review.md finding12 Arb median bound underflows to <0.0e0; core reconciliation records finite exponents generating0/inf scales, ray norm overflow and nonfinite samples getting vanishing-fit exemption.

**Missing or next action:** Fresh focused extreme-value probes and one physical UV-profile flow. Source-level edge cases are concrete, but old execution not recorded for every branch.

**Existing regression:** profile_rejects_unrepresentable_scale_ranges; fixed_uv_ray_rejects_invalid_input_shapes; pass_fail_display_lists_multiple_failures_with_context; Arb median display tests

### C4-06: Numerical-stability histograms, dashboard and integration checkpoint outputs

**Motivation:** workflow/observable feature and caller integration. **Sources:** `a4ea80a9`, `b58d1ef0`, `d54de204`.

Retain raw batch statistics before sample consumption; interrupted iteration emits a user-facing preview without advancing authoritative completed-iteration checkpoint. Missing/old manifest versions reject incompatible positional decoding.

**Evidence:** Complete commit4 evaluation/workflow reviews:19 evaluation hunks add precision-specific histogram/median statistics,2 observable hunks add weighted-median lookup; integration emits latest/global/per-slot JSON/HWU and optional completed-iteration archives. No independent physics bug claim.

**Missing or next action:** Run public batch histogram, partition/merge/persistence and successful/interrupted integration-output comparisons. Measure optional reporting overhead on representative batches only if a performance claim is made.

### C4-07: Resource-aware test execution, Nix inputs and tracing

**Motivation:** observed build/resource failures and explicit tooling policy. **Sources:** `0ad34794`, `1b760f63`, `c1a839f5`, `32f27225`.

Guard realistic concurrent process memory; include compile-time fixtures/features; exclude manual PySecDec integrals while retaining pure Rust adapters.

**Evidence:** 0ad34794: macOS physical footprint guards owned tree including compression/swap; source1b760f63 selected-profile resource override; c1a839f5 includes numerical CFF eval feature in isolated Nix test inputs. Review mapping includes fixture compile inputs and minimum nextest.

**Missing or next action:** Platform-specific old/new resource measurement needs owning OS, not Linux timing extrapolation. Verify selected inventories/profile behavior, negative missing-fixture case and suppressed-log payload behavior.

### C4-08: Behavioral numerical tests and archive unconsumed scalar snapshots

**Motivation:** reproduced test false positives / requested outward tests. **Sources:** `9c8aa0f9`, `reconstructed-review`.

Require finite affirmative complete-value agreement, correct tiny-value sensitivity, derive denominators from production, avoid private caches/layouts/host order.

**Evidence:** review.md findings5/6/7/8/9: factor-two discrepancy1e-18 vs2e-18 accepted; NaN/inf failure predicate can pass; 198 snapshots unread; GL04 denominator certificate compared handwritten expressions.

**Missing or next action:** Run exact old/new assertion predicate counterexamples and current mathematical oracles. Tests improve detection, not production values; no performance benchmark needed. Existing user approvals cover noted test corrections.

### C4-09: Remove obsolete wrapped model and migrate examples/metadata

**Motivation:** cleanup / required consumer migration. **Sources:** `5c8b46f3`, `b58d1ef0`.

Drop unused stale asset and expose supported current commands/options.

**Evidence:** Embedded phase review semantically audits deleted sm_wrapped_indices.json:72couplings/119vertices versus live108/153, no remaining non-document references. Examples, schemas and lockfiles follow owners.

**Missing or next action:** No independent physics bug or timing benefit claimed. Validate references, schema defaults and executable example flows; source-path attribution is not proof every migration hunk is independent behavior.

### C4-10: Preserve precise stability digits before f64 narrowing and report inclusive bounds

**Motivation:** source-traced concrete reporting defects and current boundary regressions. **Sources:** `reconstructed-review`.

Compute -log10(abs(relative_error)) in active precision before narrowing, export optional decimal digits through all consumers. Exact overflow boundary must be inclusive.

**Evidence:** Embedded review-821e0731fba3.txt: nonzero Arb1e-400 narrows to0 before histogram, falsely reporting bound1e-1000; overflow is x>=xmax and hence must display <= rather than <. Production trace plus Python Decimal illustration, not old Rust runtime failure.

**Missing or next action:** Fresh old/current precise-to-output probes at400/700digits and exact Double/Quad/Arb upper endpoints. No physical performance motivation is needed for mathematically correct reporting.

**Existing regression:** precise_stability_reporting_preserves_underflowed_estimates; numerical_stability_overflow_includes_exact_upper_boundary

### C4-11: Process import/reference contracts and named-integrand provenance

**Motivation:** workflow feature / input validation and invariant ownership. **Sources:** `b58d1ef0`, `ac99d32d`, `reconstructed-review`.

Commands importing graphs or generating one named integrand must preserve process identity and later source-export provenance; invalid references reject before mutation.

**Evidence:** Embedded complete API review: checked signed/unsigned ProcessRef conversions, import specification/name/append policy, explicit versus inferred process kind agreement, existing definition mismatch rejected before append, generated siblings shared provenance protected.

**Missing or next action:** Replay public import/append/overwrite/mismatched-process and named-integrand export flows; no old execution proving every guard needed is recorded. These are concrete supported API contracts, not contraction speedups.

## Commit 5: `4781595eb`

### C5-01: Physical amplitude/LU and threshold phase normalization

**Motivation:** mathematical wrong-sign/phase counterexamples; recorded failures. **Sources:** `dd134b71`.

Uncut1-4loop scalar integrals, Born2-6body phase space, above-threshold bubble discontinuity and left/right virtual triangle mirrors distinguish phase independently of absolute values.

**Evidence:** phase-conventions.md gives scalar graph i^L(-1)^P, RHS component marking and cut residue factors; PHASE_CONVENTIONS_FIX.md:347/352 records targeted passing amplitudes and pending/failing triangle sign then :374 complete corrected signed tests.

**Missing or next action:** Replay smallest independent signed scalar/mirror oracle against old and new normalization. No speedup is needed to justify correct physical conventions.

**Existing regression:** tests/test_runs/amplitude_phase_conventions.rs; scalar_phase_conventions.rs; scalar_virtual_phase_conventions.rs; four signed ddx/ttx LO/NLO acceptances

### C5-02: Inverse-process sewing, complex couplings and explicit CP opt-in

**Motivation:** independent mathematical counterexamples / supported-model contract. **Sources:** `dd134b71`, `5c8b46f3`.

Raw RHS vertex already carries Hermitian-partner coupling/spin structure; a second adjoint is wrong. CP whole-side identification is optional user assumption.

**Evidence:** phase-conventions.md:41 onward explicit Weyl matrices: charged scalar correct norm21 versus0 after second adjoint; complex charged current105 versus-63+84i. User explicitly retains CP optimization with warning.

**Missing or next action:** Use charged scalar and complex CKM matrix tests, not gluon double triangle alone (real couplings can hide bug). Distinguish proposed double-adjoint counterexample from any actual main-path old failure.

**Existing regression:** generated_charged_scalar_forward_vertex_is_already_the_hermitian_partner; generated_complex_charged_current_preserves_the_ckm_norm

### C5-03: Consistent W/Z virtual propagators, covariant cut multiplets and physical event labels

**Motivation:** physical model consistency requirement with independent oracle. **Sources:** `5c8b46f3`, `26b57b78`.

Feynman-gauge virtual tensors need matching Goldstone/ghost cut states; requesting only vector cuts fails physical polarization equivalence. Ghost statistics and displayed events must match physical multiplet.

**Evidence:** PHASE_CONVENTIONS_FIX.md:456 complete generated H->WW/ZZ sums agree with three-polarization norm at rest/boost; sm-conventions-audit.md records Ward/action audit and multiplet contract.

**Missing or next action:** Run full covariant/physical polarization and Ward oracle on old/current model settings. This electroweak bug cannot be certified by QCD-only double triangle.

**Existing regression:** generated_sm_virtual_vector_and_goldstone_exchange_matches_unitary_current; generated_higgs_covariant_cuts_equal_three_physical_vector_polarizations

### C5-04: Reject unsupported complex masses/custom pole rules and use ghost anticommutation

**Motivation:** supported-domain correctness / source-level counterexamples. **Sources:** `dd134b71`, `5c8b46f3`.

Silently dropping custom denominator terms or treating ghosts as commuting yields wrong physics; current model values must be checked again after update.

**Evidence:** phase-conventions.md model contract: current code constructs real energies and standard denominators; mass/propagator checks reject incompatible used rules. Phase review identifies common anticommuting predicate for ghost loops/exchange.

**Missing or next action:** Fresh used-versus-unused denominator, complex-mass update and ghost loop/exchange probes. Width metadata alone remains allowed. No complete arbitrary Hermiticity validator is claimed.

### C5-05: Feyngen accepted-numerator lookup optimization

**Motivation:** observed user slowdown; limited one-sided timing and correctness A/B. **Sources:** `26b57b78`.

Early sample-ratio rejection, cached zero masks after symbolic matching, per-topology atomic locks and removal of redundant clones.

**Evidence:** PHASE_CONVENTIONS_FIX.md:517 source quadratic scan/global mutex; :539/:558 exact pre/post public API parity4smallSM cases; :566 50,000-record last-match82.237ms sign/322.749ms scalar, explicitly one-sided.

**Missing or next action:** Benchmark identical accepted classes/candidates old/new for first/last/no match, multiple buckets and1/Nworkers; then realistic many-diagram process generation. One fixed double-triangle does not exercise50k-class lookup.

**Existing regression:** diagram_generator/lookup_tests.rs; numerator_grouping_preserves_values_across_worker_counts

### C5-06: Retain fixed-momentum internal bridges during initial-state subtraction

**Motivation:** fresh reconstructed-stack inherited bug old-fail/fixed-pass. **Sources:** `reconstructed-review`.

Full XS bases{2,5},{2,6},{3,5},{3,6}; cut{5,6} loses node3 and halfedges{2,5,15}, selector requests only{6}.

**Evidence:** Embedded confirmed-initial-state-bridge-cause.md: one-worker/no-grouping GL3 fails; old helper identical in main/originalphase. Gluon bridge8 has neither endpoint on initial cut, yet sink3 removed and both cut-side ranks become0.

**Missing or next action:** Use preserved CLI/public API GL3 capture and worker grouping regression; this is a specific physical graph bug, suitable alongside requested quark-loop bridge topology.

**Existing regression:** get_initial_state_tree callers; numerator_grouping_preserves_values_across_worker_counts

## Commit 6: `1a7470398`

### C6-01: Projected tensor kernels/scalar coefficient preservation and whole-numerator alternative

**Motivation:** architecture plus explicit alternate-mode request; benefit unmeasured. **Sources:** `5c8b46f3`, `26b57b78`, `32f27225`.

Projected route factors scalar spectators from universal tensor integration; monolithic route passes complete analytic numerator. Both require identical dimensional closure/Laurent handling.

**Evidence:** PHASE_CONVENTIONS_FIX.md:653 explicitly says initial split came from overly broad no-expansion interpretation. User clarified analytic UV numerator expansion is permitted/desired, then explicitly requested whole-numerator mode;32f27225 records this.

**Missing or next action:** Benchmark both modes on genuine analytic quark-loop UV subgraph and representative scalar/high-rank tensors, verify full Laurent values. Do not justify projected machinery by claiming analytic expansion remains forbidden.

**Existing regression:** whole_numerator_and_projected_analytic_backends_have_identical_laurent_coefficients; whole_numerator_and_tensor_projection_preserve_structured_open_slots

### C6-02: Complete d-dimensional Dirac/metric closure before Laurent truncation

**Motivation:** identified missing algebra boundary with independent exact oracle. **Sources:** `32f27225`.

A factor proportional to epsilon multiplied by UV1/epsilon contributes a finite term; projection-induced gamma contractions must resolve in d=4-2epsilon first.

**Evidence:** PHASE_CONVENTIONS_FIX.md:625-630: angular projection can contract formerly open spin tensors; old return path specializes remaining slots to4D after scalar order selection. integrated.rs independent single/double-pole and scalar-master tests.

**Missing or next action:** Replay explicit projected Dirac numerator with scalar master before/after old boundary. Physical quark-loop UV is appropriate, plus exact toy identity that reveals finite evanescent contribution.

**Existing regression:** projected_dirac_algebra_precedes_single_and_double_pole_expansion; projected_dirac_numerator_matches_scalar_master_before_backend_truncation

### C6-03: Account for coefficient/normalization epsilon poles and reject insufficient depth

**Motivation:** concrete mathematical order-budget defect. **Sources:** `26b57b78`, `32f27225`.

Truncated master times1/epsilon or1/epsilon^2 loses finite terms; high-rank1/(4-2epsilon) factors and evanescence must be restored before truncation.

**Evidence:** PHASE_CONVENTIONS_FIX.md:655 identifies custom normalization poles applied after backend truncation; coefficient and normalization pole orders must add. Tests24/167/240 in analytic backend suite give independent Laurent oracles.

**Missing or next action:** Fresh exact scalar masters with single/double normalization and numerator poles old/new. Preserve conservative requested depth; do not tune based on positive valuations contrary to user request.

**Existing regression:** analytic_backends_preserve_coefficients_and_epsilon_pole_orders; analytic_backends_account_for_normalization_and_nested_coefficient_poles; analytic_backends_reject_unavailable_epsilon_depth

### C6-04: Validate Lorentz domains, opaque tensor slots and scoped gamma5 errors

**Motivation:** recorded ddx boundary failure plus deliberate unsupported-domain guard. **Sources:** `26b57b78`, `32f27225`.

Malformed/unsupported tensor algebra must not silently vanish; valid gamma metadata survives projection; unrelated cograph gamma5 is outside integration scope.

**Evidence:** PHASE_CONVENTIONS_FIX.md:554 odd-open tensor could project to zero before validation; :585 ddx canonical gamma(mu)*k(mu) dummy renaming misclassified free slots.32f27225 requires gamma5 rejection before cancellation within analytic subgraph only.

**Missing or next action:** Replay malformed odd-open and actual ddx trace plus exact gamma5 scope matrix. Gamma5 rejection is explicit unsupported-feature handling, not proof old model had a physical counterexample.

**Existing regression:** analytic_uv_spin_algebra_rejects_unsupported_residual_contractions; residual_tensor_contractions_are_checked_per_analytic_branch; Vakint lorentz tests

### C6-05: Remove exactly-zero factorized scalar coefficient subtrees

**Motivation:** recorded physical generation failures and fixed passing matrix. **Sources:** `26b57b78`.

Exactly-zero projected coefficients survive AST grouping and create spurious outer CFF energy bounds. Bottom-up exact-zero certificates retain nonzero factorized spectators.

**Evidence:** PHASE_CONVENTIONS_FIX.md:608 GL29 fails after146passes; :613 GL35/38/40/46 fail; :614 identifies2*(-A-B)+2*(-B-C)+2*A+4*B+2*C; :617 focused33pass; :620 full166pass.

**Missing or next action:** Replay captured scalar coefficient zeros and one failing graph source on old/current accumulator. Test zero mathematical value, not private maps or collector cycles; maintain factorization contract for nonzero spectators.

**Existing regression:** crates/vakint/src/projection.rs scalar coefficient cancellation tests; GL29/35/38/40/46 scalar LU cases

### C6-06: Canonical backend serialization and post-restoration notation

**Motivation:** recorded backend input/output corruption. **Sources:** `26b57b78`, `32f27225`.

Serialize AST with complete symbol identity and parentheses, convert finite floats losslessly at FORM boundary; apply requested dot notation after coefficient restoration.

**Evidence:** PHASE_CONVENTIONS_FIX.md:585 external dots restored after output notation leak; :687 (1+2i)*(a+b)*tensor serialized as(a+b)*1+2*i_*tensor changing precedence; :689 display callback corrupts canonical identifiers; :715 FORM rejects decimalcomplex tokens.

**Missing or next action:** Replay retained FORM serialization inputs and output notation old/new. Pure Rust adapter tests cover encoding; physical PySecDec integration remains manual-only.

**Existing regression:** tensor_reduction_preserves_symbolica_user_namespaces; dot_conversion_*; backend serialization/adapter tests in vakint lib.rs/utils.rs

### C6-07: Preserve signed numerical momenta, complex parameters and combined estimator

**Motivation:** source-level sign loss / statistical contract plus manual validation. **Sources:** `26b57b78`.

Negative external momentum components must remain negative; complex numerator coefficients differ from real pole masses; uncertainty belongs to sum of sectors.

**Evidence:** Embedded Vakint review records real external component sign loss corrected to signed real part, nonreal component error, transactional settings. PHASE history records four explicit fast PySecDec checks and common-estimator change.

**Missing or next action:** Fresh pure Rust signed parameter/invalid-update and serialized coefficient tests; manual backend integration only if explicitly included by parent. One-sided manual historical passes are not current automatic coverage.

### C6-08: Normalize completed analytic return before reinsertion and migrate forest owners

**Motivation:** recorded sunrise boundary mismatch / required complete migration. **Sources:** `32f27225`.

Completed analytic subgraph must have cancellations resolved before Laurent projection and cograph reinsertion; both forest owners and MUV settings use full API.

**Evidence:** PHASE_CONVENTIONS_FIX.md:705/707 direct two-loop sunrise integrated node differs, other6outputs equal; exact analytic expansion proves identity; :709 both-owner/both-mode focused111pass.

**Missing or next action:** Replay exact captured sunrise pair and both modes/owners. This is expression-normalization boundary, not proof the old fully simplified mathematical integral differed.

**Existing regression:** tests/tests/uv.rs scalar finite/pole both-owner/both-mode regressions; integrated.rs complete return path

## Commit 7: `d55a0f3e9`

### C7-01: Current reports, Typst/PDF and durable source/validation provenance

**Motivation:** explicit documentation/review request. **Sources:** `3906e661`, `6b9c51b9`, `6f9e41de`, `9c8aa0f9`, `ce6654cc`, `reconstructed-review`.

Account for seven owners, all changed paths, actual commands/tests and coverage limitations; separate current report from archived evidence.

**Evidence:** Current report and source mapping; raw historical evidence retained with date/revision qualifications. Current final functional tree unchanged by report-only rewrite.

**Missing or next action:** Update current motivation/measurement report from fresh audit, compile Typst and inspect PDF. Documentation has no physical performance motivation.

## Path coverage

The JSON companion lists every changed path/status/owner and its logical categories. Counts by commit:

| Owner | Changed paths | Logical categories |
| --- | ---: | ---: |
| 2 | 22 | 11 |
| 3 | 111 | 12 |
| 4 | 281 | 11 |
| 5 | 74 | 6 |
| 6 | 32 | 8 |
| 7 | 23 | 1 |

All source commit messages consulted are copied as plain text under `/tmp/cff-change-audit/inventory/source-<revision>.txt`; extracted durable review reports and their content-addressed index are under that same directory. No credentials or private license-wrapper content was inspected or copied.

# CFF change-motivation audit: evidence and reproduction

This bundle supports the current motivation audit of the seven reviewed commits.
It contains observations and isolated diagnostic interventions, not production
fixes. Consult `complete-inventory.json` for all 73 logical categories and all
579 commit/path records. The inventory distinguishes reproduced defects,
recorded source counterexamples, requested capabilities, cleanup, measured
optimizations and unresolved motivation gaps.

## Source and environment

The reviewed source is `d55a0f3e9d25e5c64bdb9ef9fb57749ecf680390`; its executable
parent is `1a7470398d25ad0bacc224a46783ddc165484e93`. Foundation before-methods
come from `39561014`; numerator-comparison methods come from the parent of
`26b57b786`; arithmetic-parser before-methods come from the parent of
`9c8aa0f9`. These are scoped reversals on current dependencies, not full old
release builds. The old Symbolica dependency itself is not rebuilt.

`source-pin.json`, `root/host.json`, the per-family provenance files and the
build records identify exact inputs, sources, dependency fingerprints,
compiler/linker arguments and frozen binary hashes. The host is a shared AMD
EPYC 9754 Linux system. Results do not assume exclusive CPUs or fixed frequency.
Root, foundation, core and Vakint timings use one worker on CPU 8; shared CFF
uses CPU 9. Feyngen body timing uses CPU 8. End-to-end Feyngen uses the same
CPU affinity 8–11 with either one or four workers; the one-worker process can
migrate within that mask. Native builds use `dev-optim`; standalone probes
record their explicit compiler flags. Source formatting and checks precede
the native builds. This documentation audit does not rerun the earlier full
workspace suite or certify its totals as fresh benchmark observations.

Commands retain their original absolute paths as provenance. The original
working source was `/common/dev/gammaloop/higher-power-energies-review`, and
experiments were isolated under `/tmp/cff-change-audit`. To reproduce elsewhere,
use a separate checkout at the pin and adjust these paths in copies of the
drivers and JSON configs. Give a new experiment a new output directory; do not
overwrite these receipts. Drivers which support resume skip completed labels
and retain failed observations rather than retrying them.

`/tmp/raised-stack/run` in the commands is an invocation-only environment wrapper
from the original workspace. Its contents and all license material are excluded.
Provide your own already-configured licensed environment and the dependencies
required by the repository. `/tmp/raised-stack/python` identifies the original
Python 3.14.6 environment. Python expression checks also use the compatible
Symbolica module through `PYTHONPATH=/tmp/raised-stack/python-deps`.

## Rebuild the interventions

The archive excludes executables, compiled libraries, targets and complete
source checkouts. It includes exact source interventions and input graphs.
Recreate a clean source archive at the pinned revision before applying a patch.

- `root/instrumentation-complete.patch` and its JSON manifest contain the final
  five-file contraction/Feyngen/core instrumentation. The constituent preparation
  scripts are `root/prepare_instrumentation.py`,
  `feyngen-perf/prepare_intervention.py`,
  `feyngen-perf/prepare_repetitions.py` and `core-perf/prepare.py`. Use the complete
  patch or regenerate it from these sources; do not apply both.
- `core-perf/build-fixed-records.json` records the final CLI's successful
  `cargo fmt --all -- --check`, locked `cargo check -p gammaloop-api --bin
  gammaloop --profile dev-optim` and corresponding build. `core-perf/binary.json`
  pins the actual executable used for core, body and end-to-end measurements.
  `root/binaries.json` pins the separately frozen contraction executable.
- `foundation-bugs/artifacts/actual-baseline-ablation.patch` is the exact
  eight-production-file baseline. `foundation-bugs/artifacts/baseline-provenance.json` confirms unchanged
  existing test sources. The baseline regression build additionally enables
  Idenso serialization/reference-case features; this is not an assertion of
  identical full build feature sets. The `compile_*probe.py` scripts and build JSON records
  reconstruct the public-API probes against each side's libraries.
  `compile_probe.py LABEL IDENSO_HASH SPENSO_HASH SYMBOLICA_HASH` and
  `compile_powered_probe.py LABEL VAKINT_HASH SYMBOLICA_HASH` link separately
  rebuilt final/ablated libraries. `compile_multi_probe.py SPENSO_HASH
  SYMBOLICA_HASH` instead links current instrumented Spenso once and selects
  the faithful old kernel through `CFF_AUDIT_OLD_KERNEL=1`; that intervention is
  in the root patch, not the eight-file foundation baseline.
- `cff-perf/ablation.patch`, `parser-ablation.patch`, `prepare.py`,
  `prepare_parser_ablation.py` and `fixtures.py` define the independent CFF
  source experiment. `harness-full-probes.rs` retains full-value checking;
  `compile_timed.py`, `skip-probes.patch` and the final build receipt record the
  timed variant. `cff-perf/harness-timed-final.rs` is the exact final buffered
  main, verified against `timed-harness-build-v2.json`. It skips only separately
  certified downstream evaluation and writes the same complete output with
  buffering; `skip-probes.patch` alone reconstructs the discarded unbuffered
  variant and must not substitute for this final source.

Use isolated Cargo target directories when rebuilding different source variants.
The original shared target demonstrated stale cross-checkout mtime reuse.
`core-perf/source-refresh.json` and foundation/CFF provenance record how source
refreshes and actual intervention execution checks excluded that stale linkage
before the accepted runs. Hashing a source file alone does not establish what
code a binary executed. Freeze each validated executable before another build.

## Run contracts

Snapshot updates are disabled (`INSTA_UPDATE=no`). Each failed observation is
retained; there are no retries of failed product tests. Resource caps apply to
the entire child process tree. Main families use 8 GB; foundation probes use
15 GB. Timeout and memory termination do not produce numerical parity evidence.
All raw distributions remain available, including warmups and censored runs.

Benchmark drivers serialize expensive work through `measurement.lock`; builds
were additionally coordinated to finish before the timing families started.
The root contraction driver requires an external `flock`. Other family drivers
take this lock themselves: do not wrap those drivers in the same lock again.
Each watchdog also uses a separate same-directory heavy-run lock. Keep resource
caps even when using a license that supports concurrent execution. Serial timing
families prevent this audit from perturbing its own measurements; this is not a
license restriction or a requirement to run ordinary tests one at a time.

Root contraction, foundation, shared CFF and core timing use six balanced
forward/reverse measured rounds after one excluded warmup. Vakint uses six
interleaved rounds: projected mode leads three of six rounds for quark/hedge
and four for the other pairs. Feyngen body timing also uses six interleaved rounds:
rotation plus reversal is not pair-order balanced (current sign comparison leads
four of six rounds; current scalar comparison leads five). Keep that order
imbalance when interpreting small differences. Feyngen end-to-end uses two exact
forward/reverse rounds after a warmup, declared before measurements and reported
descriptively without a precise speedup claim. Repetitions within a body probe are not independent
process observations.

## Accepted data and commands

The following commands are the recorded driver entry points, assuming the
original configured environment and paths. Their manifests retain every actual
child command and relevant environment override. Rebuild and change output
destinations before using them as a new experiment.

| Family | Entry point | Authoritative results |
| --- | --- | --- |
| Physical contraction, six strategies and kernel/alias/deferral interventions | `flock /tmp/cff-change-audit/measurement.lock /tmp/raised-stack/run /tmp/raised-stack/python bin/ram_watchdog.py --limit-gb 8 --log WATCHDOG -- /tmp/raised-stack/python /tmp/cff-change-audit/root/run_matrix.py /tmp/cff-change-audit/root/matrix-config.json` | `contraction-benchmarks/manifest.json`, `analysis.json`, `complete-value-coverage.json` |
| Factorized scalar-weight stress | Same guarded root driver with `root/sum-matrix-config.json` | `sum-pressure-benchmarks/manifest.json`, `analysis.json`, `complete-value-coverage.json` |
| Foundation bug cases and storage probes | `foundation-bugs/run_probes.py LABEL` with matching freshly generated `artifacts/<label>-list.json`; `smoke_multi_probe.py` for storage | `foundation-bugs/artifacts/final/results.json`, `foundation-bugs/artifacts/baseline-definitive/results.json`, `foundation-bugs/artifacts/multi-storage-smoke.json` |
| Foundation controlled timings | `/tmp/raised-stack/run /tmp/raised-stack/python /tmp/cff-change-audit/foundation-bugs/run_all_matrices.py` under the 15 GB watchdog | `foundation-bugs/artifacts/matrix-summary.json`, `performance/`, `powered-performance/`, `multi-performance/` |
| Shared CFF | `/tmp/raised-stack/run /tmp/raised-stack/python /tmp/cff-change-audit/cff-perf/run_bench.py /tmp/cff-change-audit/cff-perf/timed-config.json` under the 8 GB watchdog; `run_contracts.py` for public input contracts | `cff-perf/timed-final/`, `trace-correctness-summary.json`, `stress-trace/`, `contracts/` |
| Core reconstruction/cache/scoring | `/tmp/raised-stack/run /tmp/raised-stack/python /tmp/cff-change-audit/core-perf/run_matrix.py --rounds 6 --fixtures GL04 GL04-temporal-square --output /tmp/cff-change-audit/core-perf/timings` under its 8 GB watchdog | `core-perf/execution-provenance.json`, `timings/`, `traces/`, `results.md` |
| Vakint modes and forest owners | `physical/vakint-modes/run_balanced_timings.py --binary BINARY --output NEW_DIRECTORY --rounds 6` under its licensed 8 GB watchdog; per-run command cards | `physical/vakint-modes/balanced-results/`, `two-loop-resource-limits.json` |
| Physical numerator matching | `feyngen-perf/run_balanced_timings.py` with the recorded body and end-to-end options | `feyngen-perf/body-physical-20-balanced/`, `feyngen-perf/e2e-physical-two-rounds/` and `feyngen-perf/RESULTS.md` |
| Inspection JSON defect | Same saved state, events enabled, additional weights toggled; commands in the manifest | `physical/inspect-weights/README.md`, `manifest.json`, `finding.json`, `attribution.json` |

The physical source graph, model rules, projector, routing and exact captured
input are in `physical/README.md`, `model_rules.json`, `provenance.json` and
`gg_double_triangle_top.dot`. The full scalar input includes its CFF expression;
UV and thresholds are disabled for this particular capture. It is one physical
diagram, not a full gauge-invariant amplitude. Other families deliberately use
separate physical or controlled inputs to reach the relevant mechanism.

## Complete-value checks

`root/validate_results.py` groups every successful contraction output by its
original SHA-256 and checks every distinct complete result. Ten physical outputs
are checked at three common exact algebraic points. The comparison resolves
complete aliases and keeps live Symbolica expressions. It does not expand a
graph numerator or reparse intermediate canonical-printer output. Finite probes
are not general symbolic identity proofs or physical phase-space acceptances.

`root/integral-output-normalization.json` explicitly maps one original output
to a derived copy: 78 occurrences of the exact integral decimal literal
`2.00000000000000` become `2`. Exact Decimal equality, original and derived
hashes, and an independent structural reconstruction certify that conversion.
The original dump and the comparator's pre-comparison guard failure are retained.
No benchmark or product test was rerun to obtain the derived representation.

The scalar-weight stress uses `root/sum-pressure/compare.py` and independent
Python Fraction arithmetic for the entire rank-four value, including aliases.
Controlled storage probes compare every output component against independent
coordinate sums. Finite tensor-component expansion is allowed and is distinct
from distributing a physical graph numerator. CFF traces include independent
denominator-pinch oracles as well as cross-strategy comparisons. Vakint checks
the full nonzero Laurent expression, including poles and finite terms.

`root-independent-count-check.json`,
`root-independent-semantic-coverage-check.json` and the independent review
documents check coverage and interpretation separately from the measurement
drivers. A changed cache count is branch-reachability evidence, never a
behavioral acceptance oracle.

## Retained limits and excluded setup observations

- Root SmallestDegree reaches the 8 GB guard on ttH and BNL. The manifest marks
  the supervisor's exit 137 separately from an unobserved child return code.
  `guard-annotations.json`, `recover_matrix_guard.py` and
  `resume-provenance-check.json` explain continuation to untouched variants.
  The twelve later observations of these failed pairs are unattempted.
- Foundation `artifacts/baseline/results.json` is a preliminary stale-linkage
  result and must not be counted. Use `baseline-definitive/results.json`.
- CFF `trace-v1` memory is invalid because whole-binary hashing inflated the
  inherited launcher high-water mark. Accepted timings use streaming hashes.
  The abandoned unbuffered writer preflight measures instrumentation overhead,
  not slow numerical evaluation. Corrected full-output hashes agree. Setup lock
  rejections occurred before measurements and remain distinct from test failures.
- All four GL16 core traces time out at 180 seconds. Partial source/map records
  show reached work and one smaller proposal, but no complete output or runtime
  comparison. Earlier implicit-process preflights are different inputs and are
  excluded from the accepted explicit-process matrix.
- Full two-loop double-triangle Vakint exceeds the declared time/memory limits
  in all four mode/owner combinations. Completed bubble results do not certify
  that missing coverage. Manual PySecDec integrations are outside this audit.
- Feyngen's small control, logging calibration, 5,000-repeat resource failure
  and unused 50,000-repeat physical plan are explicitly separate from the final
  20-repeat body experiment. An empty export set never establishes parity.
  Its large four-gluon generation times out; the completed three-gluon family
  has at most two candidates per topology and cannot establish a long-bucket
  scaling benefit. The end-to-end global mutex is a serialization intervention,
  not reconstruction of every old allocation/clone operation.
- Canonical-printer round-trip and exact-decimal parser guard findings are
  diagnostic representation boundaries. They are not relabelled as physical
  GammaLoop wrong-value bugs. The inspection JSON failure is a separate current
  user-facing defect, isolated after successful numerical evaluation.

## Archive integrity

`package-index.json` lists each archived path, byte length and SHA-256. Repeated
content uses archive hard links; extraction recovers all original paths.
Symbolic `.atom` outputs and the four exact GL04 saved-state `.bin` payloads
needed by the inspection-JSON reproduction are included. These are data, not
compiled artifacts. Compiled artifacts, source checkouts, the private environment
wrapper and license material are excluded. Driver paths and failed diagnostics are retained
for reviewability, so a raw log's presence does not make it accepted timing data.

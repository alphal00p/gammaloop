import json,pathlib
from symbolica import Expression as E
source='(2+3𝑖)/7*x'
original=E.parse(source)
canonical=original.to_canonical_string()
reparsed=E.parse(canonical)
x=E.parse('x')
record={'source':source,'canonical':canonical,'original_at_x_2':original.replace(x,E.num(2)).to_canonical_string(),'reparsed_at_x_2':reparsed.replace(x,E.num(2)).to_canonical_string(),'roundtrip_equal':bool((original-reparsed).together().cancel()==0),'plain':original.format_plain(),'plain_roundtrip_equal':bool(original==E.parse(original.format_plain())),'scope':'Python Symbolica canonical pretty serialization boundary; this is not a Rust contraction-kernel failure.'}
print(json.dumps(record,indent=2))
pathlib.Path('/tmp/cff-change-audit/physical/canonical_complex_roundtrip.json').write_text(json.dumps(record,indent=2)+'\n')
assert not record['roundtrip_equal']

import hashlib,json,pathlib,re
from symbolica import Expression as E
root=pathlib.Path('/tmp/cff-change-audit/physical')
orders=['intermediate-cost','sparse-atom-aware','atom-aware','result-rank-only','entry-aware']
exprs={}
for order in orders:
    dump=json.loads((root/f'smoke-{order}.json').read_text())
    assert not dump['aliases'], 'This smoke comparison expects the recorded alias-free physical input'
    decimals=set(re.findall(r'(?<![\w.])\d+\.\d+(?:[eE][+-]?\d+)?',dump['root']))
    assert all(float(x)==1 for x in decimals), decimals
    expression=re.sub(r'(?<![\w.])1\.0+(?![\d.eE])', '1', dump['root'])
    exprs[order]=E.parse(expression)
variables=sorted({x.to_canonical_string() for expr in exprs.values() for x in expr.get_all_indeterminates(False)})
records=[]
for seed in [1,2,3]:
    replacements={}
    for index,var in enumerate(variables):
        if '𝜋' in var:
            continue
        numerator=(index+3)*(seed+2)+seed
        denominator=index%5+2
        if 'OSE(' in var:
            numerator+=100
        if 'sigma(' in var or 'tree_denoms(' in var:
            numerator=denominator
        replacements[var]=f'{numerator}/{denominator}'
    values={}
    for order,expr in exprs.items():
        value=expr
        for var,assigned in replacements.items():
            value=value.replace(E.parse(var),E.parse(assigned))
        values[order]=value
    reference=values[orders[0]]
    equality={order:bool(value-reference==0) for order,value in values.items()}
    row={'seed':seed,'assignments':replacements,'values':{o:v.to_canonical_string() for o,v in values.items()},'all_equal':all(equality.values()),'equal_to_intermediate_cost':equality,'reference_nonzero':bool(reference!=0)}
    records.append(row)
    print(seed,row['all_equal'],row['reference_nonzero'],flush=True)
    assert row['all_equal'] and row['reference_nonzero']
(root/'exact_probe_comparison.json').write_text(json.dumps({'method':'Substitute shared scalar atoms with identical exact rational values; all sigma=1 sums supported residue selectors; retain symbolic pi; exact normalized differences zero. Pre-existing decimal coefficients are all exact unit values 1.00000000000000 and are parsed as exact integer 1; record source retained unchanged. No graph numerator expansion. Finite algebraic probes, not a general symbolic identity proof.','variables':variables,'records':records},indent=2)+'\n')

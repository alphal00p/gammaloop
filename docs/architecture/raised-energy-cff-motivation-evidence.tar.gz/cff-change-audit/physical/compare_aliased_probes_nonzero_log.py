"""Finite exact probes of complete diagnostic scalar outputs, without expansion."""
import argparse,hashlib,json,pathlib,re
from symbolica import Expression as E,Replacement
parser=argparse.ArgumentParser()
parser.add_argument('--output',type=pathlib.Path,required=True)
parser.add_argument('inputs',type=pathlib.Path,nargs='+')
args=parser.parse_args()
exprs={};sources=[]
for path in args.inputs:
    dump=json.loads(path.read_text())
    assert dump['format']=='gammaloop-aliased-atom' and dump['version']==1
    texts=[dump['root']]+[part for entry in dump['aliases'] for part in [entry['alias'],entry['original']]]
    decimals={x for text in texts for x in re.findall(r'(?<![\w.])\d+\.\d+(?:[eE][+-]?\d+)?',text)}
    assert all(re.fullmatch(r'1\.0+',x) for x in decimals), (path,decimals)
    texts=[re.sub(r'(?<![\w.])1\.0+(?![\d.eE])','1',text) for text in texts]
    expr=E.parse(texts[0]);aliases=[(E.parse(texts[i]),E.parse(texts[i+1])) for i in range(1,len(texts),2)]
    label=path.stem;assert label not in exprs
    exprs[label]=(expr,aliases)
    sources.append({'label':label,'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'aliases':len(aliases),'unit_decimal_literals':sorted(decimals)})
variables=sorted({x.to_canonical_string() for expr,aliases in exprs.values() for part in [expr]+[body for _,body in aliases] for x in part.get_all_indeterminates(False) if '::scalar(' not in x.to_canonical_string()})
records=[]
for seed in [1,2,3]:
    assignments={}
    for index,var in enumerate(variables):
        if '𝜋' in var:
            assignments[var]='3'
            continue
        n=(index+3)**2*(seed+2)+seed;d=1
        if 'OSE(' in var:n+=1000000
        if any(head in var for head in ['sigma(','tree_denoms(','σ(','θ(']):n=d
        if 'δ(' in var:
            indices=re.findall(r'cind\((\d+)\)',var)
            assert len(indices)==2, var
            n=int(indices[0]==indices[1]);d=1
        # Pythagorean values make the captured BNL hard-line energy exact.
        # These formal probes keep all denominators nonzero; they are not phase-space events.
        if var.endswith('::mUV'):n=1;d=1
        if var.startswith('log('):
            assert '::mUV)' in var or '::μᵣ²)' in var, var
            n=(seed if '::μᵣ²)' in var else 0);d=1
        if re.search(r'::Q\(16,spenso::(?:\{[^}]*\}::)?cind\(1\)\)',var):n=3;d=4
        if re.search(r'::Q\(16,spenso::(?:\{[^}]*\}::)?cind\([23]\)\)',var):n=0;d=1
        assignments[var]=f'{n}/{d}'
    replacements=[Replacement(E.parse(var),E.parse(number)) for var,number in assignments.items()]
    values={}
    for label,(expr,aliases) in exprs.items():
        value=expr.replace_multiple(replacements)
        evaluated_aliases=[Replacement(alias,body.replace_multiple(replacements)) for alias,body in aliases]
        for iteration in range(len(aliases)+2):
            resolved=value.replace_multiple(evaluated_aliases) if aliases else value
            if bool(resolved==value):break
            value=resolved
        else:raise AssertionError('Alias resolution did not reach a fixed point')
        assert not any('::scalar(' in var.to_canonical_string() for var in value.get_all_indeterminates(False))
        values[label]=value
    reference=next(iter(values.values()))
    equal={label:bool(value-reference==0) for label,value in values.items()}
    records.append({'seed':seed,'assignments':assignments,'values':{label:value.to_canonical_string() for label,value in values.items()},'equal_to_first':equal,'all_equal':all(equal.values()),'reference_nonzero':bool(reference!=0)})
    print('seed',seed,'all_equal',all(equal.values()),'reference_nonzero',bool(reference!=0),flush=True)
report={'method':'Substitute common exact integer scalar/function atoms into each complete alias body and root, then resolve evaluated aliases to a fixed point. This commutes with full alias substitution and avoids materializing repeated huge bodies; no alias is assigned an arbitrary value; legacy temporal Kronecker delta components receive exact0/1; sigma/theta/tree-denominator selectors set1; retain symbolicpi. BNL mUV=1, muR2=exp(seed), Q16spatial=(3/4,0,0), so hard energy=5/4 and log(mUV)=0 and log(muR2)=seed from their primitives. Pi is assigned common exact3 as a formal algebraic probe, not physicalpi. Unit decimalcoefficients are parsed as exactinteger1. No graph numerator expansion. Finite algebraic probes, not a general symbolic identity or physical phase-space validation.','sources':sources,'variables':variables,'records':records,'all_passed':all(r['all_equal'] and r['reference_nonzero'] for r in records)}
args.output.write_text(json.dumps(report,indent=2)+'\n')
assert report['all_passed'], 'Probe mismatch; exact values retained in report'

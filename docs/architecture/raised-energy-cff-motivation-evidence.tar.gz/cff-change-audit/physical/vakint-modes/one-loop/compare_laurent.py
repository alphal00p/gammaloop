import json,pathlib,re
from symbolica import Expression as E,Replacement
b=pathlib.Path('/tmp/cff-change-audit/physical/vakint-modes/one-loop');data=json.loads((b/'laurent-parity-inputs.json').read_text());results=[]
for record in data['runs']:
 normalized=[]
 for raw in record['full_laurent_outputs']:
  # Each named dot dummy here occurs only in the contracted square p(0,mu)^2.
  # Renaming those bound indices to the same opaque p^2 preserves their value.
  indices=sorted(set(re.findall(r'vakint::dot_dummy_ind\((\d+)\)',raw)))
  for index in indices:
   token=f'vakint::p(0,vakint::dot_dummy_ind({index}))'
   assert raw.count(token)==raw.count(token+'^2'), 'Unpaired dummy index needs separate analysis'
  value=E.parse(raw)
  value=value.replace_multiple([Replacement(E.parse(f'vakint::p(0,vakint::dot_dummy_ind({i}))^2'),E.parse('audit::p_squared'))for i in indices])
  # Closed-form Laurent coefficient algebra; the input graph numerator is untouched.
  normalized.append(value)
 results.append((record['name'],normalized))
reference=results[0][1][0];rows=[]
for name,values in results:
 residuals=[(value-reference).together().cancel()for value in values]
 rows.append({'name':name,'all_full_laurent_equal':all(bool(r==0)for r in residuals),'exact_residuals':[r.format_plain()for r in residuals],'nonzero':all(bool(value.together().cancel()!=0)for value in values)})
report={'method':'Full emitted Laurent expression comparison after alpha-renaming only verified contracted squared momentum dummy indices to one opaque p_squared; exact rational Laurent-coefficient cancellation. Same immutable integrated inputs; all tensor/colour factors retained, no graph numerator expansion. No intermediate canonical-string reparse.','all_inputs_identical':data['all_complete_inputs_identical'],'all_modes_reached':data['all_requested_modes_reached'],'runs':rows,'all_passed':all(r['all_full_laurent_equal']and r['nonzero']for r in rows)}
(b/'laurent-parity.json').write_text(json.dumps(report,indent=2)+'\n');print([(r['name'],r['all_full_laurent_equal'])for r in rows]);assert report['all_passed']

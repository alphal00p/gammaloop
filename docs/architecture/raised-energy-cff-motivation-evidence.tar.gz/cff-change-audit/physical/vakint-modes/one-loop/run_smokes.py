import pathlib,json,subprocess,hashlib
b=pathlib.Path('/tmp/cff-change-audit/physical/vakint-modes/one-loop');binary=pathlib.Path('/tmp/cff-change-audit/root/bin/gammaloop-audit');records=[]
for card in json.loads((b/'cards.json').read_text()):
 name=card['name'];log=b/(name+'-smoke.log');state=b/(name+'-state')
 cmd=['/tmp/raised-stack/python',str(b/'ram_watchdog.py'),'--log',str(b/(name+'-watchdog.jsonl')),'--limit-gb','3','--','/tmp/raised-stack/run','timeout','90',str(binary),'-n','-s',str(state),'-t',name+'.jsonl',card['path']]
 with log.open('w') as out:r=subprocess.run(cmd,stdout=out,stderr=subprocess.STDOUT,timeout=105)
 records.append({'card':card,'command':cmd,'exit_code':r.returncode,'log':str(log),'logfiles':[str(x)for x in (state/'logs').glob('*')],'uv_exports':{str(p.relative_to(b)):hashlib.sha256(p.read_bytes()).hexdigest()for p in (b/(name+'-uv')).rglob('*')if p.is_file()},'scope':'Correctness-only smoke during builds,3GB/90s cap; no timing claim.'})
 (b/'smokes.json').write_text(json.dumps({'binary':str(binary),'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'runs':records},indent=2)+'\n')
 print(name,r.returncode,len(records[-1]['uv_exports']),flush=True)

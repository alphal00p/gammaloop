import argparse,json,pathlib,statistics
p=argparse.ArgumentParser();p.add_argument('directory',type=pathlib.Path);args=p.parse_args();d=json.loads((args.directory/'manifest.json').read_text());groups={}
for row in d['runs']:
 if not row['warmup']:groups.setdefault(row['case'],[]).append(row)
summary=[]
for case,rows in groups.items():
 wall=[r['wall_seconds']for r in rows];rss=[r['max_rss_bytes']for r in rows];summary.append({'case':case,'runs':len(rows),'all_success':all(r['exit_code']==0 for r in rows),'wall_seconds_median':statistics.median(wall),'wall_seconds_min':min(wall),'wall_seconds_max':max(wall),'rss_bytes_median':statistics.median(rss),'rss_bytes_max':max(rss),'complete_exports_stable':all(r['complete_export_byte_equal_to_case_warmup']for r in rows)})
pairs=[]
for case,rows in groups.items():
 if not case.endswith('-projected'):continue
 other=groups[case[:-len('projected')]+'monolithic'];lookup={r['round']:r for r in other};ratios=[lookup[r['round']]['wall_seconds']/r['wall_seconds']for r in rows];pairs.append({'case':case[:-len('-projected')],'paired_rounds':len(ratios),'monolithic_over_projected_median':statistics.median(ratios),'ratio_min':min(ratios),'ratio_max':max(ratios)})
report={'source_manifest':str(args.directory/'manifest.json'),'binary_sha256':d['binary_sha256'],'timing_scope':d['policy'],'case_summaries':summary,'paired_mode_ratios':pairs,'all_six_rounds_complete':len(groups)==8 and all(len(rows)==6 for rows in groups.values()),'semantic_scope':'Complete computed forest exports must match within each identicalcase and be compared to the earlier exact full-Laurent proof. Byte differences across projected/monolithic modes can reflect factorization; do not treat that as failure or erase it.','statistical_scope':'Six interleaved paired observations, with projected leading4/6 rounds for both scalar owners and quark legacy and3/6 for quark hedge. All small differences are descriptive; no mode speedup claim. See schedule-correction.json.'}
(args.directory/'summary.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))

"""Run only after the coordinated build-quiet slot is granted by the root audit."""
import argparse,fcntl,hashlib,json,os,pathlib,subprocess,time
p=argparse.ArgumentParser();p.add_argument('--binary',type=pathlib.Path,required=True);p.add_argument('--output',type=pathlib.Path,required=True);p.add_argument('--cpu',default='8');p.add_argument('--rounds',type=int,default=6);args=p.parse_args()
base=pathlib.Path('/tmp/cff-change-audit/physical/vakint-modes');lock_path=pathlib.Path('/tmp/cff-change-audit/measurement.lock')
lock=lock_path.open('a');fcntl.flock(lock,fcntl.LOCK_EX)
assert not args.output.exists(), 'Use a fresh output directory; never overwrite measurements'
args.output.mkdir(parents=True)
cards=[c for c in json.loads((base/'cards.json').read_text())if c['name'].startswith('scalar')]+json.loads((base/'one-loop/cards.json').read_text())
with args.binary.open('rb')as binary_stream:
 binary_sha256=hashlib.file_digest(binary_stream,'sha256').hexdigest()
manifest={'binary':str(args.binary),'binary_sha256':binary_sha256,'cpu':args.cpu,'measurement_lock':str(lock_path),'policy':'One excluded warmup per input/mode/owner, six balanced forward/reverse rounds by default, separate states/cards/exports, no retries. Disable display and file tracing; all physics and backend settings unchanged. Wall time covers full CLI model+graph import, evaluator generation and computed UV forest export; not isolated Vakint backend time. Parent must launch this whole runner under the licensed8GB watchdog.','runs':[]}
export_references={}
for round_index in range(-1,args.rounds):
 offset=0 if round_index<0 else (3*round_index)%len(cards)
 ordered=cards[offset:]+cards[:offset]
 if round_index%2:ordered=list(reversed(ordered))
 for case in ordered:
  label=case['name']+'-'+('warmup'if round_index<0 else str(round_index));out=args.output/label;out.mkdir()
  card=out/'card.toml';source=pathlib.Path(case['path']);text=source.read_text()
  for suffix in ['-graphs','-uv']:text=text.replace(str(source.parent/(case['name']+suffix)),str(out/suffix[1:]))
  text=text.replace('display_directive = "info"','display_directive = "off"').replace('logfile_directive = "[{#uv,#integrated,#vakint}]"','logfile_directive = "off"').replace('logfile_directive = "[{#uv,#integrated,#vakint}]=debug"','logfile_directive = "off"');card.write_text(text)
  env=os.environ.copy()
  for key in list(env):
   if key.startswith(('CFF_AUDIT_','SPENSO_')):del env[key]
  env.pop('GL_ALL_LOG_FILTER',None)
  env.update({'GL_DISPLAY_FILTER':'off','GL_LOGFILE_FILTER':'off','RAYON_NUM_THREADS':'1','INSTA_UPDATE':'no'})
  cmd=['taskset','-c',args.cpu,'timeout','--kill-after=5s','180s',str(args.binary),'-n','-s',str(out/'state'),str(card)]
  started=time.monotonic()
  with (out/'cli.log').open('wb')as log:
   child=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT,env=env);_,status,usage=os.wait4(child.pid,0);child.returncode=os.waitstatus_to_exitcode(status)
  elapsed=time.monotonic()-started
  exports={}
  for x in (out/'uv').rglob('*.dot'):
   with x.open('rb')as export_stream:exports[str(x.relative_to(out/'uv'))]=hashlib.file_digest(export_stream,'sha256').hexdigest()
  reference=export_references.setdefault(case['name'],exports)
  record={'case':case['name'],'round':round_index,'warmup':round_index<0,'command':cmd,'exit_code':child.returncode,'wall_seconds':elapsed,'max_rss_bytes':usage.ru_maxrss*1024,'card_sha256':hashlib.sha256(card.read_bytes()).hexdigest(),'computed_uv_exports':exports,'complete_export_byte_equal_to_case_warmup':exports==reference}
  manifest['runs'].append(record);(args.output/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(label,child.returncode,round(elapsed,4),flush=True)
  assert child.returncode==0, 'Preserve failed measurement; stop without retries'
  assert record['computed_uv_exports'], 'A timing without computed UV exports is incomplete'

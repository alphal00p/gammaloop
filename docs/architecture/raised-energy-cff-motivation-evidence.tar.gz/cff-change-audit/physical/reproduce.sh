#!/usr/bin/env bash
set -eu
cd /common/dev/gammaloop/higher-power-energies-review
/tmp/raised-stack/run target/dev-optim/gammaloop -s /tmp/cff-change-audit/physical/reproduced-state -n -g /tmp/cff-change-audit/physical/global.toml -t reproduced.jsonl run -c 'import model sm-default.json; import graphs /tmp/cff-change-audit/physical/gg_double_triangle_top.dot -p gg_dt -i top -o; save dot /tmp/cff-change-audit/physical/reproduced_graphs; generate existing -p gg_dt -i top'

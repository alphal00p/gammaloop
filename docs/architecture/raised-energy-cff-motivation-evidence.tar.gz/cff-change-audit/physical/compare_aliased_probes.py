"""Finite exact probes of complete diagnostic scalar outputs, without expansion."""
import argparse,hashlib,json,pathlib,re
from symbolica import Expression as E,Replacement
parser=argparse.ArgumentParser()
parser.add_argument('--output',type=pathlib.Path,required=True)
parser.add_argument('inputs',type=pathlib.Path,nargs='+')
args=parser.parse_args()
exprs={};sources=[]
for path in args.inputs:
    dump=json.loads(path.read_text())
    assert dump['format']=='gammaloop-aliased-atom' and dump['version']==1
    texts=[dump['root']]+[part for entry in dump['aliases'] for part in [entry['alias'],entry['original']]]
    decimals={x for text in texts for x in re.findall(r'(?<![\w.])\d+\.\d+(?:[eE][+-]?\d+)?',text)}
    assert all(re.fullmatch(r'1\.0+',x) for x in decimals), (path,decimals)
    texts=[re.sub(r'(?<![\w.])1\.0+(?![\d.eE])','1',text) for text in texts]
    expr=E.parse(texts[0]);aliases=[Replacement(E.parse(texts[i]),E.parse(texts[i+1])) for i in range(1,len(texts),2)]
    for iteration in range(len(aliases)+2):
        resolved=expr.replace_multiple(aliases) if aliases else expr
        if bool(resolved==expr):break
        expr=resolved
    else:raise AssertionError('Alias resolution did not reach a fixed point')
    assert not any('::scalar(' in var.to_canonical_string() for var in expr.get_all_indeterminates(False))
    label=path.stem;assert label not in exprs
    exprs[label]=expr
    sources.append({'label':label,'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'aliases_resolved':len(aliases),'alias_resolution_rounds':iteration,'unit_decimal_literals':sorted(decimals)})
variables=sorted({x.to_canonical_string() for expr in exprs.values() for x in expr.get_all_indeterminates(False)})
records=[]
for seed in [1,2,3]:
    assignments={}
    for index,var in enumerate(variables):
        if '𝜋' in var:continue
        n=(index+3)*(seed+2)+seed;d=index%5+2
        if 'OSE(' in var:n+=1000
        if any(head in var for head in ['sigma(','tree_denoms(','σ(','θ(']):n=d
        if 'δ(' in var:
            indices=re.findall(r'cind\((\d+)\)',var)
            assert len(indices)==2, var
            n=int(indices[0]==indices[1]);d=1
        # Pythagorean values make the captured BNL hard-line energy exact.
        # These formal probes keep all denominators nonzero; they are not phase-space events.
        if var.endswith('::mUV'):n=3*(seed+2);d=1
        if re.search(r'::Q\(16,spenso::(?:\{[^}]*\}::)?cind\(1\)\)',var):n=4*(seed+2);d=1
        if re.search(r'::Q\(16,spenso::(?:\{[^}]*\}::)?cind\([23]\)\)',var):n=0;d=1
        assignments[var]=f'{n}/{d}'
    replacements=[Replacement(E.parse(var),E.parse(number)) for var,number in assignments.items()]
    values={label:expr.replace_multiple(replacements) for label,expr in exprs.items()}
    reference=next(iter(values.values()))
    equal={label:bool(value-reference==0) for label,value in values.items()}
    records.append({'seed':seed,'assignments':assignments,'values':{label:value.to_canonical_string() for label,value in values.items()},'equal_to_first':equal,'all_equal':all(equal.values()),'reference_nonzero':bool(reference!=0)})
    print('seed',seed,'all_equal',all(equal.values()),'reference_nonzero',bool(reference!=0),flush=True)
report={'method':'Resolve every alias to a fixed point using supported Symbolica replacement; substitute common exact rational scalar/function atoms simultaneously; legacy temporal Kronecker delta components receive exact0/1; sigma/theta/tree-denominator selectors set1; retain symbolicpi. BNL mUV and Q16 form a3-4-5 triple so its square-root energy is exact. Unit decimalcoefficients are parsed as exactinteger1. No graph numerator expansion. Finite algebraic probes, not a general symbolic identity or physical phase-space validation.','sources':sources,'variables':variables,'records':records,'all_passed':all(r['all_equal'] and r['reference_nonzero'] for r in records)}
args.output.write_text(json.dumps(report,indent=2)+'\n')
assert report['all_passed'], 'Probe mismatch; exact values retained in report'

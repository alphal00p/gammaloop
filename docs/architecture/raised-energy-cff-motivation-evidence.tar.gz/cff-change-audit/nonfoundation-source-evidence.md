# Concrete source evidence for nonfoundation motivations

This companion preserves selected exact diagnostic passages from pinned source history and embedded review artifacts. It deliberately excludes setup/environment sections. Historical test counts describe the recorded source checkpoint; they do not certify current reconstructed code. Fresh CFF replay evidence will be stored separately. Feature requests, type-domain cleanup, and required caller migrations are not relabeled as bugs.

## C2-05 / C3-04

Source `9c8aa0f9:docs/architecture/raised-energy-cff-implementation.md`, lines 25–57. SHA-256 `1132e68da91e180cf30545ee91042baed8a409594c93d4dc7af290659a509770`.
Retained original source record; historical outcomes are not fresh runs.

```text
## Additional defects exposed by the stronger tests

The unchanged depth-three scalar banana regression exposed a sign mismatch when an ordinary
terminal CFF is embedded in a larger UV construction. The shared generator used its component
frame sign while advertising the core loop-count convention. The embedded ordinary terminal
now supplies the source prefactor consistent with that advertised convention, as the standalone
route already does. The generalized normalization remains separate.

An independent two-loop contour regression covers joined and disconnected components in both
standalone and embedded contexts. The previously failing depth-two/depth-three core test passes
without changing its assertions or tolerance.

The strict GL04 comparisons exposed a second defect in mixed integrated/local UV subtraction.
The direct 3D Taylor kernel omitted hard vacuum-mass scaling in a finite integrated coefficient
when the Taylor subgraph encloses its owner. Broader GL00 and GL04 comparisons also establish
why applying that scaling globally is incorrect: an integrated coefficient from a disjoint
component must stay fixed while the other component is expanded.

The direct route now tags each connected coefficient's vacuum mass as transient `mUV(owner)`
before multiplying coefficients. A Taylor operation scales that mass only when its subgraph
contains the owner; it leaves disjoint owners fixed and rejects partial overlaps. A later
enclosing operation can scale those retained owners. `DirectSector::combine` restores physical
`mUV` on output copies, preserving the stored owners for further forest steps. Normalized
localization kernels stay frozen throughout, and the auxiliary OSE deformation mass retains
its separate role.

Identical captured inputs, independent 90–330 digit replays and exact source algebra isolate
the initial GL04 discrepancy to one coefficient of a one-loop integrated localizer. The default
localization scale of 1000 suppresses its visible size; it is not an Arb arithmetic limit.
The independent two-loop renormalization oracle passes on the untouched pre-implementation
baseline and rejects changing the established four-dimensional mass scaling. The correction
therefore stays in the direct route; the four-dimensional Taylor and integrated-coefficient
code retain their established mass scaling.
```

## C2-06 / C4-01 / C4-02

Source `6f9e41de:docs/architecture/raised-energy-cff-review.md`, lines 27–73. SHA-256 `28889aaf05c4b2e03fb3ada01e516b65738a8f4a9f48e48553843d7c69103e1d`.
Retained original source record; historical outcomes are not fresh runs.

```text
1. **[P2] Nested inline runs expand variables before entering the inner scope.**
   [run.rs:268](/common/dev/gammaloop/higher-power-energies-review/crates/gammaloop-api/src/commands/run.rs:268)
   sends any placeholder-containing inline command through template expansion
   before recognizing a nested `run`. A direct invocation with its own
   `-D level=warn` and a body using `$(level)` succeeds; wrapping that same
   invocation inside `run -c` fails with “Missing command-block variable 'level'”.
   Both cases were run through the real CLI. Source tracing also shows an outer
   definition can capture the inner placeholder before the inner override applies.
   Prepare the inner invocation in its own environment, as the ordinary block
   path already does at line 477. One environment-aware preparation boundary
   would remove this divergence.

2. **[P2] Loading nested command blocks demands variables intended for invocation.**
   [session.rs:238](/common/dev/gammaloop/higher-power-energies-review/crates/gammaloop-api/src/session.rs:238)
   skips static validation only when a command's own raw text contains a
   placeholder. For `outer = ["run inner"]` and a parameterized `inner`, it
   recursively prepares `inner` with an empty environment before the top-level
   `run outer -D level=warn` can execute. A real boot-card reproduction exits 1;
   the equivalent single-block control exits 0. Reusable nested block libraries
   are affected even before execution. Keep static name/cycle validation, but
   defer invocation-variable resolution until the inherited environment exists.

3. **[P2] Default 3Drep output violates the explicit state-write policy.**
   [threedreps/mod.rs:476](/common/dev/gammaloop/higher-power-energies-review/crates/gammaloop-api/src/commands/threedreps/mod.rs:476)
   selects `<active-state>/threed_workspace` in ordinary mode, and lines 395–410
   save JSON and an output pointer by default. I imported a scalar box, ran
   `3Drep build --no-pretty`, and ended with `quit -n`; both files were created
   inside the state directory despite no save command. [CONTRIBUTING.md:369](/common/dev/gammaloop/higher-power-energies-review/CONTRIBUTING.md:369)
   reserves state-directory writes for explicit save/quit-output operations
   and enabled logs. Use the existing cwd-output policy consistently, or obtain
   a deliberate repository-policy change. This is a filesystem behavior issue,
   not a CFF-value discrepancy.

4. **[P2] The public diagnostic numerator parser silently changes arithmetic.**
   [eval.rs:756](/common/dev/gammaloop/higher-power-energies-review/crates/three-dimensional-reps/src/eval.rs:756)
   bypasses its right binding power for exponentiation;
   [eval.rs:777](/common/dev/gammaloop/higher-power-energies-review/crates/three-dimensional-reps/src/eval.rs:777)
   binds unary minus more tightly than powers; and
   [eval.rs:836](/common/dev/gammaloop/higher-power-energies-review/crates/three-dimensional-reps/src/eval.rs:836)
   narrows an exponent to `i32` without checking its range. A compiled public
   `evaluate_expression` reproduction on a generated unit graph gives
   `-2**2 = 4`, `-(2**2) = -4`, `2**3**2 = 64`, and
   `2**4294967296 = 1`. The first and chained-power cases contradict conventional
   power precedence; the last silently wraps the exponent to zero. Use checked
   conversion and define or reject chained powers explicitly. Tests should
   compare evaluated arithmetic at this public boundary. This parser belongs
   to the shared crate's diagnostic evaluation feature; the production compiled
```

## C4-08

Source `6f9e41de:docs/architecture/raised-energy-cff-review.md`, lines 94–115. SHA-256 `28889aaf05c4b2e03fb3ada01e516b65738a8f4a9f48e48553843d7c69103e1d`.
Retained original source record; historical outcomes are not fresh runs.

```text
6. **[P2] Numerical failure predicates can accept NaN and infinity.**
   [utils.rs:635](/common/dev/gammaloop/higher-power-energies-review/tests/tests/test_runs/utils.rs:635)
   only panics when `distance > tolerance`. With a NaN total, the distance is
   NaN and the comparison is false. With an infinite total, both distance and
   tolerance can be infinite, so the comparison is false again. This can pass
   when the remaining event data agree, including empty event groups. The
   explicit finite checks in the scalar test are inside the optional
   `localized_3d_results` branch; they do not protect every caller path. Require
   finite components before an affirmative `distance <= tolerance` assertion.
   This also affects failure-list aggregation in the independent shared-crate
   tests ([eval.rs:2066](/common/dev/gammaloop/higher-power-energies-review/crates/three-dimensional-reps/src/eval.rs:2066),
   [generation.rs:6818](/common/dev/gammaloop/higher-power-energies-review/crates/three-dimensional-reps/src/generation.rs:6818))
   and Arb raised-LU comparisons
   ([cff/mod.rs:4418](/common/dev/gammaloop/higher-power-energies-review/crates/gammalooprs/src/cff/mod.rs:4418),
   repeated at 4510, 4626, 4692 and 4791). A compiled reproduction confirms that
   the actual `F<ArbPrec>` NaN compares neither greater than nor less than or
   equal to a finite tolerance. An empty failure list therefore does not prove
   valid agreement. No current production NaN at those sample points is claimed.
   Using `hypot` would also avoid avoidable overflow in the norm calculation.

7. **[P2] Multiple tests freeze private construction choices.**
   The following would fail under valid implementation simplifications:
```

## C2-07

Source `6f9e41de:docs/architecture/raised-energy-cff-review.md`, lines 168–195. SHA-256 `28889aaf05c4b2e03fb3ada01e516b65738a8f4a9f48e48553843d7c69103e1d`.
Retained original source record; historical outcomes are not fresh runs.

```text
10. **[P3] The preserved-tree fast path skips energy-bound validation.**
   [generation.rs:668](/common/dev/gammaloop/higher-power-energies-review/crates/three-dimensional-reps/src/generation.rs:668)
   returns before checking the bound IDs at line 689. A public call with a
   one-edge, zero-loop `ParsedGraph`, preserved edge `[0]`, and bounds
   `[(999, 2)]` succeeds and retains those invalid source bounds. I reproduced
   this against the compiled library. `ParsedGraph` uses the default absent
   edge-index map, so the earlier optional remapping validation does not catch
   it. Validate all input bound IDs before the early return. This is an input
   validation inconsistency; no valid-input CFF algebra error is claimed.

11. **[P3] The public graph validator panics on malformed signature dimensions.**
   [validator.rs:39](/common/dev/gammaloop/higher-power-energies-review/crates/three-dimensional-reps/src/validator.rs:39)
   allocates vertex balances from declared loop/external counts, then indexes
   them using unchecked signature lengths at lines 52–53. A compiled public-API
   call with an edge signature `[1]` and no declared loops panics with a
   zero-length out-of-bounds index instead of returning an invalid
   `GraphValidation`. Public `ParsedGraph` fields allow this construction.
   Validate dimensions before balance accumulation and return a structured
   rejection. This concerns malformed external Rust input; no valid internally
   generated graph failure was demonstrated.

12. **[P3] Arb stability overflow renders an impossible accuracy bound.**
   [evaluation.rs:443](/common/dev/gammaloop/higher-power-energies-review/crates/gammalooprs/src/integrands/evaluation.rs:443)
   computes `10.0_f64.powf(-1000.0)` for the Arb histogram's overflow bound.
   That underflows to zero. An Arb stability result with estimated relative
   accuracy zero is placed in this overflow bin, and the displayed median
   becomes `<0.0e0` via lines 500–513. Keep the logarithmic exponent through
   formatting, or otherwise represent the bound without first converting it
```

## C5-01 / C5-02 / C5-04

Source `dd134b71:PHASE_CONVENTIONS_FIX.md`, lines 16–27. SHA-256 `a736658552d5a95622b833d804cd5e13b95fb6584f7539df7a68adee6fc64a79`.
Retained original source record; historical outcomes are not fresh runs.

```text
1. The shared energy representation is J = integral product[dq0/(2*pi*i)] N/product(D^a), with D = q^2 - m^2 + i0. GammaLoop's existing source-frame and inverse-energy signs correctly recover J. Production then multiplies by (-i)^L/(2*pi)^(3L), whereas the physical Minkowski measure requires i^L/(2*pi)^(3L). The current uncut amplitude therefore differs from the Feynman-rule result by (-1)^L. This statement holds for the audited scalar contour boundary; each subtraction branch must be verified consistently during implementation.
2. The independent tadpole and tadpole-times-bubble contour check in crates/gammalooprs/src/cff/mod.rs:6879 explicitly strips the production (-i)^L factor at line 6946 before comparison with J. This distinguishes loop parity from denominator parity. The three production normalization sites are cff/mod.rs:392, :699, and :828. The real source-frame adapter at :224 and the 1/product(-2E) convention in graph/mod.rs:724 must not be independently flipped.
3. Integrated UV terms have the same historical convention: uv/settings.rs:425 defaults additional_normalization to "-1", and uv/approx/integrated.rs:977 applies it once per integrated loop. The amplitude correction must change this default coherently to "1", including its serialization-default predicate. Preserve forest subtraction signs and actual causal prescriptions.
4. The vendored scalar UFO uses +i*lambda, while the standard interaction L_int = -lambda*phi^4/4! requires -i*lambda. Its full JSON export has +i scalar propagator numerators, as expected. The actively used scalars_2p_3p.json instead has propagator numerators 1; its coupling expression and cached numerical value also use +i*lambda. Both JSON variants and the UFO must be corrected consistently.
5. LU currently retains the full forward-graph CFF loop phase, keeps the final-cut propagator numerators, and multiplies by a real 2*pi cut factor. The right integrated threshold coefficient is conjugated, but the RHS numerator and the remaining RHS virtual-loop measure are not treated as a complete conjugated amplitude.
6. An isolated diagnostic with the existing, unrebuilt target/dev-optim/gammaloop binary selected one symmetric scalar contact graph and one Born cut for each multiplicity n = 2,3,4,5. With no UV or remaining threshold subtraction, the phases were respectively -i,+i,-i,+i at forward loop counts L = 1,2,3,4. This corroborates the source-derived phase (-1)^(n+1)*i. It is diagnostic evidence, not fresh-build acceptance or an MC integral. Artifacts: /var/folders/xx/c9yqv8gs07b7n6njwdjymg4w0000gn/T/gammaloop-phase-born-55povae7/.
7. The present scalar LU matrix's "no_numerator" cases retain complete UFO Feynman rules; the label means no additional momentum numerator. A graph-level DOT num="1" also does not clear edge and vertex factors. Reuse Graph::with_global_numerator_only for a genuinely complete unit numerator.
8. RHS ownership first becomes insufficient when CrossSectionCut is reduced to LuCutSelection: physical cut alternatives survive, but the side-dependent numerator information does not. UV forest values are also computed and shared before the current cut loop. Applying conjugation only to the final numerator would therefore leave UV counterterms incorrect.
9. This checkout has no method literally named complex_conjugate. Existing spenso_conj, scalar/tensor network mapping, and Dirac simplifiers provide the required operations. dirac_adjoint additionally inserts gamma0 and transposes open spin-line endpoints; it must not be substituted blindly for elementwise conjugation of an amputated RHS tensor.
10. Current ddx/ttx acceptances contain phase-selecting probes, norm-based LO/NLO comparisons, and manually supplied +/-i generation prefactors. Some individual graph comparisons already retain signs, but their inputs still contain these compensating conventions.

## Convention to impose
```

## C5-03

Source `26b57b78:PHASE_CONVENTIONS_FIX.md`, lines 463–463. SHA-256 `2a62b366928208de8a4c8f11233d21861b7c5a70221aabd6b53ce72c61fb1de1`.
Retained original source record; historical outcomes are not fresh runs.

```text
- The ttH selector/channel migrations are applied with all numerical targets, sample coordinates and cut/channel order retained. A model-clone 2×2 control attributes the full-SM grouping change solely to the approved FFS1/FFS3 projector corrections: all 47 raw directed graphs remain identical, while eight formerly spurious Lorentz zeros become the required nonzero mass-insertion traces. Restoring only the old W/Z propagators leaves the result unchanged. Full-SM and CP grouping references are updated from these controls; their signed sums are independently checked.
```

## C6-05

Source `26b57b78:PHASE_CONVENTIONS_FIX.md`, lines 599–610. SHA-256 `2a62b366928208de8a4c8f11233d21861b7c5a70221aabd6b53ce72c61fb1de1`.
Retained original source record; historical outcomes are not fresh runs.

```text
- The first full acceptance on the generic index repair passed fresh Python/API model parity, exact `just test_gammaloop` (2,084/2,084; run `010d820d-f6db-4582-91b8-14b77c7b3344`) and all four explicitly enabled fast PySecDec tests (run `839e0276-0d26-475b-a35a-15d0901ea515`). The full scalar matrix then failed at GL29 after 146 passes, leaving 19 cases unrun (run `8d8fbcb6-eb50-44f1-8852-c344155a9f43`). This was a generation failure, before numerical assertions: an exactly-zero external coefficient survived angular projection in a factorized form and induced spurious CFF energy bounds. The first differing boundary is Vakint scalar-coefficient accumulation, before integrated-localizer CFF construction. Graph selection and Feyngen lookup are excluded; no CFF rank limit or physical reference is changed.
- `ScalarTerms::insert` now uses the existing equal-numerical-coefficient collector on a temporary candidate solely to certify zero, with a cycle guard. A nonzero stored coefficient retains its original AST. This avoids numerator expansion, polynomial conversion and numerical-coefficient GCDs, including their problematic complex-coefficient path. The regression reproduces the mixed angular sector while preserving a nonzero product-of-sums spectator; another covers cycles and accumulated cancellation with rational, complex and floating coefficients. The two tests supplement the generic index regressions rather than specializing the implementation to GL29 or ttH.
- Current-source test-target checking (9.04s), workspace/all-target Clippy with UFO support and warnings denied (15.81s), and the focused 28-test native run all pass. The latter includes GL29, complete slow ttH, Vakint Lorentz validation and tensor reduction (run `4ecf08c9-2923-481e-bcac-47f6e5592984`; 346.363s execution; watchdog peak 5,405,081,728 bytes; `/tmp/gammaloop-phase-review-zero-coefficient-safe-v2-targeted.log`). Fresh API/parity, the exact suite, enabled fast PySecDec and the complete 166-case scalar matrix must pass again on this final zero-coefficient repair before publishing the root commit.

- The refreshed Python/API build and SM UFO/JSON parity pass (`public-api-sm-parity-f1wjcf6w/report.json`), exact `just test_gammaloop` passes 2,086/2,086 with 296 existing skips (run `c6082736-0127-42af-9082-3d491e08f3a5`, 248.150s), and explicitly enabled fast PySecDec passes 4/4 (run `b9d9b6ad-cbdb-4534-9e29-d5d0631c2468`, 49.627s). Nextest reported one successful test with delayed output-handle cleanup; no worker survived the run, and the standard output settings did not retain its identity. This was not an assertion failure.
- The complete scalar release gate passed 152 cases, including GL29 and every quadratic/quartic probe, before GL35 failed with the same outer-CFF energy bounds (run `b33668d4-ebc4-49ef-8ba9-e2b3a0c81ad4`, 28m22s build, 1,810.805s execution, peak 20,215,427,072 bytes). A separate run of the 13 previously unrun cases passed ten and exposed the same generation failure in GL38, GL40 and GL46. All 166 cases have now been exercised on this checkpoint; four fail, so publication remains blocked on a code repair, not approval.
- Structured traces locate all four failures at the same scalar-coefficient boundary. With A=p3², B=p3·p4, C=p4², GL35 adds the zero `2*(-A-B)+2*(-B-C)+2*A+4*B+2*C` inside complex epsilon/logarithmic prefactors. Equal-coefficient collection reaches a nonzero-looking fixed point. GL38 and GL46 have exactly the same tensor-reduced numerator; GL40 combines the same zeros with surviving mass and loop terms. The exact numerical-content collector proves this real-rational zero without expansion. No additional phase, tensor, graph-selection or CFF-sector defect is implicated.
- Scalar-coefficient accumulation now certifies additive subexpressions from the inside out, committing only exact-zero replacements and retaining surviving factors. Its scratch candidates use numerical-content collection only when arithmetic numeric leaves are exact real rationals and arithmetic powers are positive integers; functions remain opaque. Other domains retain equal-coefficient grouping, and every subtree has a cycle guard. This avoids unsafe complex GCDs and powers that could introduce complex/infinite coefficients. A new regression covers both a zero nested inside a surviving complex coefficient and the complete mixed angular product; nonzero complex, floating, inverse and fractional-power expressions retain their original ASTs. Checking, linting and native acceptance must be refreshed on this repair.

- The guarded bottom-up zero repair passes test-target checking (9.10s), all-target Clippy with UFO support and warnings denied (14.73s), and all 33 focused native tests (run `61226ff3-e000-484d-a9ed-80e3a55e9f42`, 345.256s execution, peak 5,439,783,552 bytes; `/tmp/gammaloop-phase-review-zero-subtree-safe-targeted.log`). This includes GL29, GL35, GL38, GL40, GL46, all relevant Vakint projection/Lorentz/tensor tests and complete slow ttH. The source is frozen for a fresh full API/parity, exact suite, enabled fast PySecDec and complete scalar-matrix acceptance.

- Final acceptance of the guarded zero-subtree and generic index repairs passes on the same frozen source. The rebuilt Python API passes SM UFO/JSON parity, including the real-input declarations and complex CKM values (`/tmp/gammaloop-phase-plan/public-api-sm-parity-4gadzay7/report.json`). Exact `just test_gammaloop`, without added arguments or exclusions, passes 2,087/2,087 tests with 296 existing skips (run `acd44189-9934-4810-8877-6016d7f566f5`, 237.100s). All four signed photon/lepton ddx/ttx LO/NLO acceptances pass at their existing MC statistics. Nextest reports two passed-test output-handle cleanup notes, with no assertion failures or surviving workers.
```

## C6-02 / C6-03

Source `32f27225:PHASE_CONVENTIONS_FIX.md`, lines 618–622. SHA-256 `cc000486b2630bc4663192d71e469505323d99a8928a5536ac46b3101fb2f6a9`.
Retained original source record; historical outcomes are not fresh runs.

```text
The goal of this follow-up is to finish every Lorentz and ordinary Dirac contraction of the complete analytically integrated subgraph at symbolic d=4-2epsilon before Laurent coefficients are discarded, including contractions introduced by vacuum tensor projection. Expansion is explicitly permitted and desired inside that analytic subgraph; retained cograph and numerical-production numerators remain factorized. Reject gamma5 anywhere in the analytic UV subgraph before simplification can erase it, with a contextual error. Gamma5 prescriptions are out of scope.

The shared input already reconstructs symbolic Feynman-rule tensors and maps their Minkowski slots to d before GammaLoop evaluates ordinary closed fermion traces. The first missing boundary is after Vakint angular projection: previously opaque open spin tensors can acquire contracted slots, but the current return path merely collects chains and later specializes remaining slots to four dimensions. A second GammaLoop algebra pass must therefore occur before Vakint scalar integration performs coefficient-order selection and Laurent truncation. Preserve separate denominator topologies and complete loop-momentum mappings throughout this round trip.

Implement and vet three coordinated pieces: (1) restore projected tensors, complete their d-dimensional gamma/metric algebra and re-encode the numerator before scalar backend evaluation; (2) audit coefficient and integral epsilon valuations, nested-forest composition and backend depth limits so pole multiplication cannot discard evanescent contributions, with explicit errors where sufficient orders cannot be supplied; (3) reject gamma5 and implicit gamma5-bearing chiral tensors at the earliest shared analytic-subgraph boundary, without rejecting an unrelated cograph. Use independent cross-audits and exact single/double-pole regressions, ordinary closed traces, new projector contractions and gamma5 scope tests. Run formatting/checking and Clippy, focused native tests, then the required full gates on the final tree. Previous 26b57b786 results do not certify these changes; PR #103 stays draft during implementation and is republished only after verification.
```

## C6-04

Source `26b57b78:PHASE_CONVENTIONS_FIX.md`, lines 576–576. SHA-256 `2a62b366928208de8a4c8f11233d21861b7c5a70221aabd6b53ce72c61fb1de1`.
Retained original source record; historical outcomes are not fresh runs.

```text
- Pipeline triage isolates two representation boundaries. Retained external-dot coefficients were restored after the analytic backend had applied `use_dot_product_notation=false`, so bare Vakint dots leaked into GammaLoop's evaluator; apply output notation after coefficient restoration at the owning boundary. Separately, the new Lorentz validator knows momentum/metric slots but not the gamma tensors restored by GammaLoop's pre-Vakint conversion. The canonical ddx trace contains contracted `gamma(mu)*k(mu)` terms with different dummy names, which the validator incorrectly classifies as different free-index sets. Carry explicit opaque tensor-slot metadata from the existing GammaLoop tensor parser into Vakint; keep the tensor bodies and graph coefficients factorized outside FORM. Preserve all signed acceptance targets and rerun the affected paths before the exact suite. Trace: `/tmp/gammaloop-phase-plan/integrated-domain-trace/ddx-canonical.json`.
```

## C6-06

Source `32f27225:PHASE_CONVENTIONS_FIX.md`, lines 679–682. SHA-256 `cc000486b2630bc4663192d71e469505323d99a8928a5536ac46b3101fb2f6a9`.
Retained original source record; historical outcomes are not fresh runs.

```text
- A retained-binary FORM diagnostic locates the monolithic tensor failure before reduction: `(1+2i)*(a+b)*tensor*loop_momenta` was serialized as `(a+b)*1+2*i_*tensor*loop_momenta`, changing precedence and creating scalar summands with no tensor slots. The repair belongs to canonical backend serialization, preserving full symbol attributes and bypassing custom display printers. Standard backend normalizations are built as exponentials of their epsilon-weighted formal real logarithms before user coefficients are combined; arbitrary complex coefficient functions and custom normalizations retain their branches. No production reference or phase is adjusted to obtain parity.

- The second focused checkpoint passes 106/109 tests, including complete slow ttH (190.010s; `/tmp/gammaloop-phase-d-dimensional-v2-targeted.log`, saved `d-dimensional-v2-baseline-junit.xml`). Three remaining failures are isolated at representation boundaries: custom display callbacks corrupt canonical backend identifiers, the whole-input FORM route cancels rational denominator factors that simple expansion does not cancel, and the quark oracle assumes an explicit `log(μ_R²)` term. Captured FORM inputs and outputs prove that both tensor routes retain the same complex coefficient and projector: `2/(2ε−4) = 1/(ε−2)`.
- The backend serializer now follows the existing expression tree with raw symbol names, attributes and tags, preserving complex parentheses and antisymmetric signs without display callbacks or temporary wrapper symbols. Both tensor modes are compared against the same exact `k²/d` projector over complex rationals. The quark scale-log coefficient is extracted as `μ_R² ∂/∂μ_R²`, retaining the original signed pole residue and normalization without imposing logarithm branch rewrites. These changes require a fresh native run and the final full gates; no commit or push has occurred.
```

## C6-02 / C6-03 explicit mathematical counterexample

Source `32f27225:crates/gammalooprs/src/uv/approx/integrated.rs`, lines 1489–1586. SHA-256 `ca9289e7f5f7018283db7601b6db7cd1d363db61df1b17b866716695c5e2efa8`.
Retained original source record; historical outcomes are not fresh runs.

```text
    fn projected_dirac_algebra_precedes_single_and_double_pole_expansion() {
        test_initialise().unwrap();
        let vakint = Vakint::new().unwrap();
        let epsilon = Atom::var(GS.dim_epsilon);
        let radial = vakint::symbols::S.dot(
            function!(vakint::symbols::S.k, 1),
            function!(vakint::symbols::S.k, 2),
        );
        let mink = Minkowski {}.new_rep(GS.dim);
        let mu = mink.to_symbolic([Aind::new_dummy().to_atom()]);
        let nu = mink.to_symbolic([Aind::new_dummy().to_atom()]);
        let bis = Bispinor {}.new_rep(4);
        let a = bis.to_symbolic([Aind::new_dummy().to_atom()]);
        let b = bis.to_symbolic([Aind::new_dummy().to_atom()]);
        let c = bis.to_symbolic([Aind::new_dummy().to_atom()]);

        for project_onto_tensor_integrals in [true, false] {
            for use_dot_product_notation in [false, true] {
                let settings = vakint::VakintSettings {
                    use_dot_product_notation,
                    project_onto_tensor_integrals,
                    ..VakintSettings::default().true_settings()
                };
                let integrated = Integrated::new(&vakint, &settings);
                for closed in [false, true] {
                    // Distinct loop slashes have no repeated gamma index before
                    // angular projection. Its projector creates the contraction.
                    let numerator = function!(GS.loop_mom, 1, &mu)
                        * function!(GS.loop_mom, 2, &nu)
                        * function!(AGS.gamma, &a, &b, &mu)
                        * function!(AGS.gamma, &b, if closed { &a } else { &c }, &nu);
                    let mut term = vakint::VakintTerm {
                        integral: vakint::vakint_parse!("topo(I2L(mUVsq,1,1,1))").unwrap(),
                        numerator: Integrated::to_vakint_numerator(&numerator),
                        vectors: vec![("k".into(), 1), ("k".into(), 2)],
                    };
                    term.tensor_reduce(&vakint, &settings).unwrap();
                    let spin = if closed {
                        Atom::num(4)
                    } else {
                        function!(ETS.metric, &a, &c)
                    };
                    let late_four_dimensional = simplify(
                        &Integrated::restore_numerator(
                            Vakint::convert_to_dot_notation(&settings, term.numerator.as_view())
                                .unwrap(),
                            0,
                        )
                        .replace(GS.dim)
                        .with(4),
                    )
                    .unwrap();
                    assert!(
                        !truncate(
                            &series(
                                &(late_four_dimensional
                                    .replace(radial.to_pattern())
                                    .with(epsilon.pow(-1))
                                    - &spin * epsilon.pow(-1)),
                                1,
                            )
                            .unwrap(),
                            true,
                        )
                        .is_zero(),
                        "the old late-4D contraction must miss a nonzero finite term"
                    );
                    for evanescent_power in 0..=2 {
                        let projected = &term.numerator
                            * (Atom::var(GS.dim) - Atom::num(4)).pow(evanescent_power);
                        let resolved = integrated
                            .simplify_projected_numerator(&projected, 0)
                            .unwrap();
                        assert!(!resolved.contains_symbol(AGS.gamma));
                        assert!(!resolved.contains_symbol(SPENSO_TAG.trace));
                        assert!(!resolved.contains_symbol(GS.dim));
                        let coefficient = &spin * (Atom::num(-2) * &epsilon).pow(evanescent_power);
                        for pole in [
                            epsilon.pow(-1) + Atom::num(5) + Atom::num(7) * &epsilon,
                            Atom::num(2) * epsilon.pow(-2)
                                + Atom::num(3) * epsilon.pow(-1)
                                + Atom::num(5)
                                + Atom::num(7) * &epsilon,
                        ] {
                            // Mock only the scalar master value: the angular
                            // projection and d-dimensional Dirac algebra above use
                            // the production pipeline. This isolates the pole ×
                            // evanescent finite terms from master normalization.
                            let evaluated = resolved
                                .replace(radial.to_pattern())
                                .with(pole.to_pattern());
                            assert!(
                                series(&(evaluated - &coefficient * pole), 2)
                                    .unwrap()
                                    .to_atom()
                                    .is_zero(),
                                "project={project_onto_tensor_integrals}, closed={closed}, dot={use_dot_product_notation}, evanescent power={evanescent_power}"
                            );
```

## C3-11 explicit degree-overflow input

Source `d55a0f3e:crates/gammalooprs/src/numerator/energy_degree.rs`, lines 2359–2385. SHA-256 `8ebaf652747aa3630471d952eeab4bd1b6874525bae6b45d2f91681b32faa002`.
Retained original source record; historical outcomes are not fresh runs.

```text
    fn overflowing_polynomial_degrees_return_an_error() {
        let energy = GS.emr_mom(EdgeIndex(0), GS.cind(0));
        let large_degree = usize::MAX / 3 + 1;
        let exponent = Atom::num(large_degree as u64);
        let powered = energy.clone().pow(exponent.clone());
        let overflow_product = (1..=3).fold(Atom::one(), |product, shift| {
            product * (energy.clone() + Atom::num(shift)).pow(exponent.clone())
        });
        let analyzer = EnergyPowerAnalyzer::for_physical_emr_edges([EdgeIndex(0)]);
        for expression in [(powered.clone() + Atom::one()).pow(3), overflow_product] {
            assert!(matches!(
                analyzer.analyze_atom(&expression),
                Err(EnergyPowerAnalysisError::EnergyDegreeOverflow)
            ));
            assert!(matches!(
                analyzer.analyze_atom_upper_bound(&expression),
                Err(EnergyPowerAnalysisError::EnergyDegreeOverflow)
            ));
        }
        assert_eq!(
            analyzer
                .analyze_atom(&(powered + Atom::one()).pow(2))
                .unwrap()
                .into_generation_bounds(),
            vec![(0, 2 * large_degree)]
        );
    }
```

## C3-11 explicit malformed residue input

Source `d55a0f3e:crates/gammalooprs/src/cff/mod.rs`, lines 1026–1056. SHA-256 `452db5843cdb536e7340886a83c0625da2665c124592311769a2db40c8d9b8e7`.
Retained original source record; historical outcomes are not fresh runs.

```text
    fn lu_residue_selection_rejects_missing_physical_cut_support() {
        let mut cutset = CutSet::empty(0);
        cutset.residue_selector.lu = Some(crate::graph::cuts::LuCutSelection {
            raised_group: crate::cff::esurface::RaisedEsurfaceGroup {
                esurface_ids: Vec::new(),
                max_occurence: 1,
            },
            cut_edge_alternatives: Vec::new(),
        });

        assert!(select_indexed_cff_residues(ThreeDExpression::new_empty(), &cutset).is_err());

        let mut expression = ThreeDExpression::new_empty();
        expression.surfaces.esurface_cache.push(esurface::Esurface {
            energies: vec![EdgeIndex(0)],
            external_shift: Vec::new(),
            vertex_set: VertexSet::dummy(),
        });
        for (esurface_ids, max_occurence) in [
            (Vec::new(), 1),
            (vec![esurface::EsurfaceID(0)], 0),
            (vec![esurface::EsurfaceID(1)], 1),
        ] {
            let group = esurface::RaisedEsurfaceGroup {
                esurface_ids,
                max_occurence,
            };
            for axis in [
                CutCffResidueAxis::RightThreshold,
                CutCffResidueAxis::LeftThreshold,
                CutCffResidueAxis::LuCut,
```

## C3-11 concrete integer boundary

Source `d55a0f3e:crates/gammalooprs/src/graph/three_d_source.rs`, lines 3304–3337. SHA-256 `9239ae1ff69e499e03d0e440db9f65c8a773131f9867535679bb145641c21394`.
Retained original source record; historical outcomes are not fresh runs.

```text
    fn exact_momentum_signatures_reject_overflow_and_preserve_cancellation() -> Result<()> {
        test_initialise()?;
        let graph: Graph = dot!(digraph exact_momentum_integer_range {
            edge [num=1 mass=1]
            node [num=1]
            a -> b [id=0 lmb_id=0]
            b -> c [id=1]
            c -> a [id=2]
        })?;
        let momentum = |edge| function!(GS.emr_mom, edge);
        let large = Atom::num(i32::MAX);
        let mut denominator = FourDDenominator {
            source_edge: EdgeIndex(0),
            momentum: &large * momentum(0) + momentum(1),
            mass_squared: Atom::one(),
            full_expr: Atom::one(),
        };
        assert!(denominator.momentum_signature(&graph, true).is_err());
        assert!(denominator.momentum_signature(&graph, false).is_err());
        denominator.momentum -= large * momentum(2);
        assert_eq!(
            denominator.momentum_signature(&graph, true)?.loop_signature,
            vec![1]
        );
        assert_eq!(
            denominator
                .momentum_signature(&graph, false)?
                .loop_signature,
            vec![1]
        );
        Ok(())
    }

    #[test]
```

## C6-08

Source `32f27225:PHASE_CONVENTIONS_FIX.md`, lines 699–701. SHA-256 `cc000486b2630bc4663192d71e469505323d99a8928a5536ac46b3101fb2f6a9`.
Retained original source record; historical outcomes are not fresh runs.

```text
- Sunrise triage locates the first unequal expression at the direct two-loop analytically integrated node; the other six integrated outputs match. An exact symbolic check proves that full analytic expansion makes the two expressions identical, whereas numerical-coefficient expansion and factor collection do not. The common master constants were treated as independent symbols, without relying on rounding. Normalize the completed analytic subgraph at `Integrated::integrate` before Laurent projection and cograph reinsertion. The existing factorized comparator remains unchanged and now records a structured expression pair on mismatch. The scalar finite/pole regression compares both forest orchestrators in both Vakint input modes. All three reviewers approve this bounded repair; native validation follows.

- Final focused validation of the analytic-return repair passes 111/111 tests, including unchanged sunrise and slow ttH acceptance, both forest owners, and both Vakint modes (run `60625d82-21a1-4000-8868-3d7ee0dcca57`, 11m33s build, 205.959s execution, peak 8,109,173,760 bytes). Formatting, Hakari, test-target checking (9.81s), and all-target Clippy (16.80s) pass. One output-handle cleanup note is reported; no test failure or surviving worker is found. The list-only selection audit also passes: all seven automatic profiles and the slow-test bypass exclude the 24 physical PySecDec tests even with the opt-in set; manual inventories are exactly 24 ignored tests/four fast checks, and three pure Rust adapter tests remain automatic. Final full gates continue on the same frozen sources.
```

## C6-07

Source `32f27225:PHASE_CONVENTIONS_FIX.md`, lines 709–709. SHA-256 `cc000486b2630bc4663192d71e469505323d99a8928a5536ac46b3101fb2f6a9`.
Retained original source record; historical outcomes are not fresh runs.

```text
- Controlled copied-package tests isolate two PySecDec input boundaries. Exact complex rationals fix FORM parsing; with no complex parameter aliases, a literal imaginary coefficient additionally requires `enforce_complex` on the parsed numerator. Both copied generation/compilation/integration runs pass for `1+2i` and the exact IEEE representation of `-0.1+3i/8`, preserving their signed real/imaginary pole and finite parts. The implementation uses existing `Rational::try_from(f64)` without additional rounding, and derives the complex-return flag from PySecDec's parsed numerator. A pure Rust test checks the whole polynomial, multiple monomials, exact coefficients, epsilon powers, and absence of aliases. Both reviewers approve the two-file repair; physical references, epsilon depths, and manual-only selection remain unchanged. Run the manual fast checks first after rebuilding, then refresh the broader final gates.
```

## C3-02

Source `/tmp/cff-change-audit/inventory/source-e30d799e.txt`, lines 1–24. SHA-256 `d9a3b0388b0a15b813c38ba35a3c82d3935c28d2fc16ec57215788982c269b7e`.
Original embedded independent review or original commit body; current inventory does not reclassify static findings as old runtime observations.

```text
fix local UV counterterms and prepare validation candidate

Preserve factorized direct and projected UV constructions and exact source
ownership; fix CFF scalar/contact normalization and integrated UV handling.
Reduce repeated alias and capacity-envelope work, simplify the nonzero M input
contract, and add the guarded release scalar matrix target. Refresh generated
Nix metadata and remove temporary handoff material from the tracked tree.

This is a validation candidate for a draft PR, not the ALL_GREEN milestone.
Strict release check, Clippy and formatting passed. The fresh 166-case scalar
matrix, 54 focused regressions, full just test_gammaloop and remote CI remain
pending. Regenerate saved states/evaluator archives for the changed layouts.
Phase work and extended physical studies remain deferred.

User request (verbatim):

Assign yourself the goal in:
```
./HANDOFF_REMOVE_FOR_PR/HANDOFF_GOAL.md
```

which instructs you to start things off by fixing:
```
./HANDOFF_REMOVE_FOR_PR/HANDOFF_T2_DISCREPANCY.md
```

## C3-09

Source `/tmp/cff-change-audit/inventory/source-ac99d32d.txt`, lines 1–17. SHA-256 `a05c43bc00b30b769d5e3c6cb39d0e183b3e21130385e2181ce104fe30f3a05e`.
Original embedded independent review or original commit body; current inventory does not reclassify static findings as old runtime observations.

```text
ALL_GREEN: preserve independent CFF occurrences and simplify UV generation

Keep repeated propagator occurrences independent through CFF construction.
Select up to three certified derivative-energy assignments by actual native
source-map count, preserving each selected assignment with its generated CFF.
Add Spenso's intermediate_cost preset through the existing strategy selector;
sparse_atom_aware remains available for rollback.

Simplify direct/projected UV assembly and remove unused deferred state paths.
Preserve direct per-residue subtraction, complete projected residue sums,
frozen localizers and integrated ownership. Normalize valid zero projected
sectors at their producer. Route child-soft carriers into the compatible
parent chart before they become hard, preventing the GL08 finite counterterm
from retaining an unintegrated inner momentum. Keep original owners, the strict
CFF capacity guard and Vakint's analytic vacuum-numerator expansion.

Advance saved-state format from version 5 to version 6 for the changed
```

## C3-10

Source `/tmp/cff-change-audit/inventory/source-7b0b09ed.txt`, lines 1–9. SHA-256 `822908c37e67c99e7415c2ecadc96f14078f5929cea51dd982d29e9c6aec1ef8`.
Original embedded independent review or original commit body; current inventory does not reclassify static findings as old runtime observations.

```text
resolve JIT constants and shorten CFF intermediate lifetimes

Compile SymJIT from the existing mapped numeric evaluator so registered
constants such as pi have resolved values. A minimal pi^-3 reproduction gives
infinity with the unresolved rational program and the correct finite result
with the mapped program. Add a finite pi/pi^-3 regression while retaining the
existing Arb constant and backend consistency assertions and JIT options.

Keep lower-sector per-parent fanout lazy, consume owned base branches, and
```

## C2-08

Source `/tmp/cff-change-audit/inventory/review-22917944fa8c.txt`, lines 13–22. SHA-256 `22917944fa8c755fe47d4c1dee73d28262adbaa78c096692d8aeabc5ba673de8`.
Original embedded independent review or original commit body; current inventory does not reclassify static findings as old runtime observations.

```text
- The public generator returned Result but could panic on hand-built ParsedGraph input with invalid compact edge IDs, absent endpoint nodes, wrong signature dimensions, or out-of-range initial-cut aliases. It now returns existing GraphIoError::Source before recursive indexing. Existing validator diagnostics supply dimensional checks; full physical graph validity is deliberately not imposed, because diagnostic algebraic sources are supported. Added a public error regression with eight malformed input cases.
- The terminal residue builder already requires D=L and full rank. Its nonbasis-denominator loop could never run; removed this dead general-residue scaffolding and directly emits the unit terminal denominator.
- Derived KnownLinearExpr Default; removed rational_from_usize forwarding wrapper; avoided cloning the union-find map for each root lookup.
- Corrected the coefficient-range error text: Rational storage is unbounded, while projected integer momentum coordinates remain bounded.
- Test-only generated-expression convenience function calls the public source API.
- Fixed a passing reversed-occurrence sampling fixture to declare degree one on the second occurrence whose mixed moment it samples. The owner-permutation regression now constructs its numerator from each declared occurrence envelope and compares complete physical values after the documented source-frame conversion.
- Removed three private recursion/cut-layout smoke tests already covered by independent one-/two-loop signed-contour oracles.
- Auto-numerator regression compares exact algebraic expressions rather than literal formatting and multiplication order.
- GL04 contour test accepts equivalent cached surface aliases and numerator/denominator cancellation; it no longer demands exactly one internal surface-cache row.
- Shared vertex balance accumulation and public residual vectors now use i64. Four individually valid routes MAX,1,-MAX,-1 cancel without intermediate i32 overflow, and a MAX+1 residual remains exact. Existing validation tests exercise both; core migrated corresponding source consumers.
```

## C3-11

Source `/tmp/cff-change-audit/inventory/review-0481a87a264c.txt`, lines 66–66. SHA-256 `0481a87a264c4f7e100a020ed7f0fd7572ffc4df5c341e93f2fc64d82646cf51`.
Original embedded independent review or original commit body; current inventory does not reclassify static findings as old runtime observations.

```text
- `mod.rs` couples each exact source's mapper and assignment in an immutable shared `Arc`. Ordinary production map IDs remain distinct even when physical orientations coincide. Exact maps stay occurrence-local. Typed energy-factor ownership supplies the source convention, while an explicit residue-axis enum handles LU/left/right order indexing. Invalid empty/missing residue groups return errors instead of indexing blindly. Physical cut alternatives are remapped independently of numerator energy samples.
```

## C2-08 / C2-11

Source `/tmp/cff-change-audit/inventory/review-c6e0ff0ffae8.txt`, lines 7–10. SHA-256 `c6e0ff0ffae876e98e00eba8cbcd8e7aee0afe5a75f26987f88e14088cf3f79b`.
Original embedded independent review or original commit body; current inventory does not reclassify static findings as old runtime observations.

```text
- Public `evaluate_expression` accepted short mass/momentum arrays then indexed past the end. Added one concise dimension check at the existing public boundary, reporting field, expected length and actual length. Both too-short and too-long external, loop and mass inputs now return structured errors. No new validation helper or parallel API was introduced.
- Direct `EvaluationInput { uniform_scale: Some(0.0), ... }` bypassed the existing parser's zero-scale rejection. The public evaluator now applies the same contract. Uniform-scale powers now use checked i32 conversion just like the existing residual denominator powers, rather than wrapping `usize as i32`.
- The symbolic tree API already defines a filtered empty tree as zero and an infinite denominator as a zero inverse. Numeric evaluation formerly panicked on the former and produced approximately 1e80 on the latter. Existing evaluator methods now implement the same zero contract, with complete public evaluation regressions.
- Variant fusion traversed root zero of a filtered empty tree. It now contributes no denominator chains for that tree, preserving the existing zero value; a regression checks fusion alongside a nonzero variant.
```

## C4-10

Source `/tmp/cff-change-audit/inventory/review-821e0731fba3.txt`, lines 16–30. SHA-256 `821e0731fba30436186b63de982d9e03314520682b5517186d0e503ecfc33071`.
Original embedded independent review or original commit body; current inventory does not reclassify static findings as old runtime observations.

```text
### P2: preserve arbitrary-precision estimates before the f64 metadata boundary

At `integrands/evaluation.rs:572`, a zero `estimated_relative_accuracy` is assigned to `x_max + 1`, which becomes an overflow result. For Arb the histogram upper bound is 1000, so `NumericalStabilityMedian::formatted_relative_accuracy` reports `<1.0e-1000`.

The input is `Option<F<f64>>` in `StabilityResult` (`evaluation.rs:862`). The production upstream is `PreciseStabilityLevelResult<T>::into_f64` in `integrands/process/mod.rs:1891`: it converts the precise nonzero relative estimate with `into_ff64()` before assembling `StabilityResult` at line 3845. A positive estimate of `1e-400` therefore becomes zero in the new histogram, which incorrectly reports a bound of `1e-1000`. Keeping the decimal exponent separate in the final formatter avoids a second underflow but does not recover information already discarded upstream.

Fix this by preserving a logarithmic estimate before narrowing, or by explicitly retaining/reporting a conservative underflow bound or unknown status. An exact computed zero must not be silently conflated with a nonzero estimate lost during conversion. Keep the required metadata changes and all constructors/consumers together in commit 4 if the metadata representation changes. A regression should traverse the existing precise-to-output boundary using a nonzero estimate below f64 range; the current test uses f64 zero and `1e-320`, so it cannot detect this defect.

Evidence: production source tracing plus an independent Python Decimal illustration (`Decimal('1e-400') > 0`, `float(...) == 0.0`). This illustration is not a Rust runtime test. Parent notified; no fix applied by this reviewer.

### P2: overflow accuracy bound must include equality

`HistogramAccumulatorState` puts values `>= x_max` into overflow (`observables/mod.rs:4266`). The stability histogram variable is `x=-log10(relative_accuracy)`, so overflow establishes `relative_accuracy <= 10^-x_max`, not a strict inequality. `NumericalStabilityMedian::Overflow` currently renders `<...` (`evaluation.rs:506`). A Double estimate exactly `1e-17` or Quad estimate exactly `1e-34` therefore displays a strictly smaller bound than the estimate itself.

Render an inclusive bound and verify the exact boundary through the public histogram/median output. Underflow's existing strict `>` direction is correct because the histogram tests `value < x_min`. Existing zero-overflow tests do not exercise equality. Parent notified; no test changed and no runtime test run.
```

## C5-06

Source `/tmp/cff-change-audit/inventory/review-d24e62e4db05.txt`, lines 1–11. SHA-256 `d24e62e4db059ca6df405a38cde9e2a14cd7b70c309bda135554582f6113da4b`.
Original embedded independent review or original commit body; current inventory does not reclassify static findings as old runtime observations.

```text
# Confirmed GL3 cut-side truncation

The fresh CLI capture and public-API diagnostic both reproduce the one-worker/no-grouping failure on commit `3638e5e6`. The saved state remains byte-identical after the read-only diagnostic. No numerical value or worker-count comparison is reached.

The actual full XS bases are `{2,5}`, `{2,6}`, `{3,5}`, and `{3,6}`. Before initial-state subtraction, the raw cut `{5,6}` retains the complete other fermion loop. After subtraction, its left side loses node 3 and halfedges `{2,5,15}`; both side ranks become zero and the selector requests only `{6}`.

`get_initial_state_tree` considers every zero-loop-momentum edge. For the internal gluon bridge 8, neither endpoint 2 nor 3 attaches to the initial-state cut, but the old unconditional `else` removes sink node 3 anyway. The helper body is identical in pinned main, commit 4, commit 5 and the original phase branch. This is an exposed inherited defect. The newer singleton LMB branch cannot affect the full XS builder or the zero-rank cut sides.

The prepared existing-function fix removes a crown only when its endpoint actually attaches to the initial-state cut, retaining source-first behavior when both endpoints qualify. All four callers discard the old second return value, so the unused vector is removed and callers migrate together. The known failing worker test is unchanged; one existing scalar test only updates its helper call, preserving every assertion. No helper or compatibility path is added.

Production application and fresh gates/tests remain pending at this record. Diagnostic compiler attempts are separate evidence: first private-access and then missing-import failures were corrected in scratch-only code; v3 and v4 compiled, and both read-only diagnostic executions succeeded. These are diagnostic runs, not additional passing tests.
```


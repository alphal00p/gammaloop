"""Independent metadata and bounded literal-copy checks; no algebra execution."""
from pathlib import Path
from decimal import Decimal
import collections, hashlib, json, re
root = Path('/tmp/cff-change-audit')
ledger = json.loads((root/'root/integral-output-normalization.json').read_text())
original_path = Path(ledger['original']); normalized_path = Path(ledger['normalized'])
for path, expected in [(original_path, ledger['original_sha256']), (normalized_path, ledger['normalized_sha256'])]:
    assert hashlib.sha256(path.read_bytes()).hexdigest() == expected
original = json.loads(original_path.read_text()); normalized = json.loads(normalized_path.read_text())
assert Decimal(ledger['conversion']['from']) == Decimal(ledger['conversion']['to']) == Decimal(2)
pattern = re.compile(r'(?<![\w.])2\.00000000000000(?![\d.eE])')
expected = json.loads(original_path.read_text())
counts = {}; contexts = collections.Counter()
fields = [('root', expected)] + [(key, entry) for entry in expected['aliases'] for key in ['alias', 'original']]
for key, entry in fields:
    text = entry[key]
    for match in pattern.finditer(text):
        previous = text[match.start()-1] if match.start() else 'START'
        following = text[match.end()] if match.end() < len(text) else 'END'
        contexts[(previous, following)] += 1
        assert previous in ('START', '+', '-', '*', '/', '^', '(', ',', ' ')
        assert following in ('END', '+', '-', '*', '/', '^', ')', ',', ' ')
    entry[key], count = pattern.subn('2', text)
    counts[key] = counts.get(key, 0) + count
assert expected == normalized
assert sum(counts.values()) == ledger['conversion']['occurrences'] == 78
output = {
 'scope': 'Independent receipt/manifest mapping, SHA check of the two 2 MB literal copies, and exact parsed-JSON differential reconstruction. No algebra-heavy execution or rehash of all large physical dumps; validate_results.py performed those full-file hashes before oracle execution.',
 'normalization': {'original_sha256': ledger['original_sha256'], 'normalized_sha256': ledger['normalized_sha256'], 'exact_decimal_equality': True, 'independent_json_differential_match': True, 'changes_by_field': counts, 'standalone_literal_contexts': [{'previous': p, 'following': f, 'count': c} for (p, f), c in contexts.items()]},
 'families': []
}
for family in ['contraction-benchmarks', 'sum-pressure-benchmarks']:
    directory = root/family
    manifest = json.loads((directory/'manifest.json').read_text())
    coverage_path = directory/'complete-value-coverage.json'
    if not coverage_path.exists():
        output['families'].append({'family': family, 'status': 'pending receipt'})
        continue
    coverage = json.loads(coverage_path.read_text())
    successful = [run for run in manifest['runs'] if run['exit_code'] == 0]
    grouped = collections.defaultdict(list)
    for run in successful:
        grouped[run['fixture']].append(run)
    assert set(grouped) == {row['fixture'] for row in coverage}
    summaries = []
    for row in coverage:
        runs = grouped[row['fixture']]
        manifest_hashes = {run['result_sha256'] for run in runs}
        assert manifest_hashes == set(row['unique_output_hashes'])
        assert len(runs) == row['successful_observations_covered']
        assert row['exit_code'] == 0
        receipt = json.loads(Path(row['result']).read_text())
        assert receipt['all_passed']
        receipt_sources = receipt['inputs'] if family == 'sum-pressure-benchmarks' else receipt['sources']
        receipt_hashes = {source['sha256'] for source in receipt_sources}
        mapped_hashes = {ledger['normalized_sha256'] if value == ledger['original_sha256'] else value for value in manifest_hashes}
        assert receipt_hashes == mapped_hashes
        assert {source['path'] for source in receipt_sources} == set(row['command'][4:])
        if family == 'sum-pressure-benchmarks':
            assert len(receipt['records']) == 3 * len(receipt_sources)
            for source in receipt_sources:
                records = [record for record in receipt['records'] if record['input'] == source['path']]
                assert {record['seed'] for record in records} == {1, 2, 3}
                assert all(record['equal_to_independent_component_oracle'] and record['exact_residual'] == '0' for record in records)
            for seed in (1, 2, 3):
                assert len({record['expected_fraction_sha256'] for record in receipt['records'] if record['seed'] == seed}) == 1
        else:
            assert len(receipt['records']) == 3
            for record in receipt['records']:
                assert set(record['normalized_residuals']) == {source['label'] for source in receipt_sources}
                assert record['all_equal'] and record['reference_nonzero']
                assert set(record['normalized_residuals'].values()) == {'0'}
        summaries.append({'fixture': row['fixture'], 'successful_observations': len(runs), 'distinct_original_output_hashes': sorted(manifest_hashes), 'oracle_source_hashes': sorted(receipt_hashes), 'three_exact_points_pass': True, 'receipt_sha256': hashlib.sha256(Path(row['result']).read_bytes()).hexdigest()})
    output['families'].append({'family': family, 'status': 'passed receipt coverage', 'successful_observations': len(successful), 'distinct_outputs': sum(len(row['distinct_original_output_hashes']) for row in summaries), 'fixtures': summaries})
(root/'root-independent-semantic-coverage-check.json').write_text(json.dumps(output, indent=2)+'\n')
print(json.dumps({'normalization': output['normalization'], 'families': [{key: row[key] for key in ['family','status','successful_observations','distinct_outputs'] if key in row} for row in output['families']]}, indent=2))

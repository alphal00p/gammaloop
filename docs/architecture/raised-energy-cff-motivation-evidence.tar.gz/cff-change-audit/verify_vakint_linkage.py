from pathlib import Path
import hashlib,json
base=Path('/tmp/cff-change-audit/physical/vakint-modes');refs={};reference_files=[]
for path in [base/'smokes.json',base/'one-loop/smokes.json']:
 for r in json.loads(path.read_text())['runs']:
  if r['exit_code']!=0:continue
  items={}
  for rel,expected in r['uv_exports'].items():
   if not rel.endswith('.dot'):continue
   file=path.parent/rel;actual=hashlib.file_digest(file.open('rb'),'sha256').hexdigest();assert actual==expected
   items[rel.split('/',1)[1]]=actual;reference_files.append({'path':str(file),'sha256':actual})
  refs[r['card']['name']]=items
manifest=base/'balanced-results/manifest.json';m=json.loads(manifest.read_text());checks=[];timed_files=0
for r in m['runs']:
 label=r['case']+'-'+('warmup' if r['warmup'] else str(r['round']));actual={}
 for rel,expected in r['computed_uv_exports'].items():
  file=manifest.parent/label/'uv'/rel;digest=hashlib.file_digest(file.open('rb'),'sha256').hexdigest();assert digest==expected;actual[rel]=digest;timed_files+=1
 assert actual==refs[r['case']]
 checks.append({'case':r['case'],'round':r['round'],'complete_dot_files':len(actual),'all_actual_files_match_validated_smoke':True})
scalar=base/'scalar-laurent-parity.json';quark=base/'one-loop/laurent-parity.json';s=json.loads(scalar.read_text());q=json.loads(quark.read_text());assert s['all_full_laurent_outputs_identical'] and q['all_passed']
result={'method':'Independently rehash actual complete DOT exports for each earlier successful smoke and all56 timed/warmup observations, verify each against its recorded manifest digest, then compare complete relative-path/digest maps directly to the corresponding earlier case. Does not use warmup-only parity. Existing full-Laurent receipts are inspected, not rerun.','reference_files_rehashed':len(reference_files),'timed_files_rehashed':timed_files,'observations':len(checks),'checks':checks,'reference_files':reference_files,'laurent_proofs':{str(p):hashlib.file_digest(p.open('rb'),'sha256').hexdigest()for p in [scalar,quark]},'all_passed':True}
Path('/tmp/cff-change-audit/nonfoundation-vakint-linkage-review.json').write_text(json.dumps(result,indent=2)+'\n');print({k:result[k]for k in ['reference_files_rehashed','timed_files_rehashed','observations','all_passed']})

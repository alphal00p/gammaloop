"""Independently check final E2E metadata, inputs, distributions and oracle linkage."""
from pathlib import Path
import collections, hashlib, json, re, statistics
root=Path('/tmp/cff-change-audit');base=root/'feyngen-perf';directory=base/'e2e-physical-two-rounds'
manifest=json.loads((directory/'manifest.json').read_text());summary=json.loads((directory/'summary.json').read_text());verified=json.loads((directory/'final-artifact-verification.json').read_text())
runs=manifest['runs'];config=manifest['configuration']
assert config['mode']=='e2e' and config['rounds']==2 and config['grouping']=='both' and config['resume'] is False
assert len(runs)==summary['observations']==summary['successful_observations']==48
assert sum(run['warmup'] for run in runs)==16
assert summary['timed_observations']==32 and summary['all_planned_observations_accounted_for'] and not summary['planned_observation_omissions'] and not summary['failures']
expected_variants=[f'{group}-{workers}workers-{mode}' for group in ('sign','scalar') for workers in (1,4) for mode in ('current','old-comparator','global-lock','both')]
expected_keys={(variant,round_index) for variant in expected_variants for round_index in (-1,0,1)}
assert {(run['variant']['id'],run['round']) for run in runs}==expected_keys
orders={round_index:[run['variant']['id'] for run in runs if run['round']==round_index] for round_index in (-1,0,1)}
assert orders[0]==expected_variants and orders[1]==list(reversed(expected_variants))
assert orders[-1]==list(reversed(expected_variants))
for round_index,order in orders.items():assert order==verified['exact_forward_reverse_measured_orders'][str(round_index)]
source=Path(manifest['fixture_card']);template=source.read_text();assert hashlib.sha256(source.read_bytes()).hexdigest()==manifest['fixture_sha256']
reference_path=base/'larger-physical-smokes.json';reference_hash=hashlib.sha256(reference_path.read_bytes()).hexdigest();reference=next(row for row in json.loads(reference_path.read_text()) if row['case']=='three_gluon_vertex_2loop_quark')
assert reference['exit_code']==0 and len(reference['exports'])==36
assert summary['validated_default_export_linkage']['source_sha256']==reference_hash==verified['validated_reference_sha256']
verification_rows={(row['variant'],row['round']):row for row in verified['observations']}
summary_links={(row['variant'],row['round']):row for row in summary['validated_default_export_linkage']['observations']}
assert set(verification_rows)==set(summary_links)==expected_keys
card_hashes=set()
for run in runs:
    variant=run['variant'];assert run['exit_code']==0 and not run['failure'] and run['warmup']==(run['round']<0)
    assert run['command'][:3]==['taskset','-c','8-11'] and variant['workers'] in (1,4)
    assert run['graph_exports']==reference['exports'] and run['complete_export_byte_equal_to_reference']
    card=Path(run['command'][run['command'].index('comparison.jsonl')+1]);text=card.read_text()
    assert hashlib.sha256(card.read_bytes()).hexdigest()==run['card_sha256'];card_hashes.add(run['card_sha256'])
    expected=template
    for workers in (1,4):expected=expected.replace(f'feyngen = {workers}',f'feyngen = {variant["workers"]}')
    if variant['grouping']=='scalar':expected=expected.replace('group_identical_graphs_up_to_sign','group_identical_graphs_up_to_scalar_rescaling')
    expected=expected.replace('display_directive = "info"','display_directive = "off"')
    assert text==expected
    assert re.findall(r'^\s*feyngen\s*=\s*(\d+)\s*$',text,re.M)==[str(variant['workers'])]
    key=(variant['id'],run['round']);v=verification_rows[key];s=summary_links[key]
    assert v['files_rehashed']==s['export_count']==36 and v['matches_recorded_complete_map'] and v['matches_validated_default_complete_map'] and s['equals_complete_validated_default']
assert len(card_hashes)==4
assert verified['files_rehashed']==1728 and verified['failures']==verified['omissions']==0
for path,expected_hash in [(Path(manifest['driver']),manifest['driver_sha256']),(Path(summary['summary_generator']),summary['summary_generator_sha256']),(base/'verify_e2e_outputs.py',verified['verification_script_sha256'])]:
    assert hashlib.sha256(path.read_bytes()).hexdigest()==expected_hash
assert manifest['binary_sha256']==summary['binary_sha256']==verified['binary_sha256_unchanged']
rows=[]
for variant in expected_variants:
    observed=[run for run in runs if run['variant']['id']==variant and not run['warmup']]
    values=summary['variants'][variant];assert values['measurements']==2 and values['successful_warmups']==1 and values['failures']==0
    row={'variant':variant}
    for metric in ('wall_seconds','numerator_preparation_and_grouping_seconds','max_rss_bytes'):
        sample=[run[metric] for run in observed];assert all(value is not None for value in sample)
        actual={'median':statistics.median(sample),'min':min(sample),'max':max(sample)}
        assert actual==values[metric]
        row[metric]=actual
    rows.append(row)
for variant,ratios in summary['paired_e2e_intervention_over_current_ratios'].items():
    current_id=variant.rsplit('-',1)[0]+'-current' if not variant.endswith(('old-comparator','global-lock')) else variant.rsplit('-',2)[0]+'-current'
    observed={run['round']:run for run in runs if run['variant']['id']==variant and not run['warmup']}
    controls={run['round']:run for run in runs if run['variant']['id']==current_id and not run['warmup']}
    assert set(observed)==set(controls)=={0,1},(variant,current_id)
    for metric,values in ratios.items():
        samples=[observed[index][metric]/controls[index][metric] for index in (0,1)]
        assert values=={'median':statistics.median(samples),'min':min(samples),'max':max(samples),'paired_rounds':2}
receipt={'scope':'Independent metadata and source review; all 48 small input cards rehashed/reconstructed, all manifest statistics recomputed, complete export maps joined to the separately rehashed 1728-file verification receipt. No native execution or repeated export/binary hashing.','observations':48,'warmups':16,'measured':32,'variants':16,'rounds_exact_reverse':True,'affinity_all':'8-11','worker_pools':[1,4],'input_card_hashes':len(card_hashes),'complete_exports_per_observation':36,'export_file_receipt_coverage':1728,'all_statistics_and_ratios_match':True,'all_reference_maps_match':True,'manifest_sha256':hashlib.sha256((directory/'manifest.json').read_bytes()).hexdigest(),'summary_sha256':hashlib.sha256((directory/'summary.json').read_bytes()).hexdigest(),'verification_sha256':hashlib.sha256((directory/'final-artifact-verification.json').read_bytes()).hexdigest(),'rows':rows,'interpretation':'Two measured observations per variant support descriptive ranges, not precise speedup claims. Wall time includes physical numerator preparation/generation/export; timestamp delta includes numerator preparation, grouping and combination at millisecond resolution. Comparator-body timing is a different measurement. One-worker global locking is a serialization control, and the ablation retains current bucket/allocation design. At most two candidates per topology do not establish long-bucket scalability.'}
(root/'root-independent-e2e-review.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({key:value for key,value in receipt.items() if key!='rows'},indent=2))
for row in rows:print(row['variant'],f"wall={row['wall_seconds']['median']:.3f}s stage={row['numerator_preparation_and_grouping_seconds']['median']:.3f}s RSS={row['max_rss_bytes']['median']/1e6:.1f}MB")

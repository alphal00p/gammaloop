"""Retain a guard-killed in-progress observation, without retrying its pair."""
import json,pathlib,sys,shutil
manifest_path=pathlib.Path(sys.argv[1]);watchdog=pathlib.Path(sys.argv[2]);j=json.loads(manifest_path.read_text());failure=[json.loads(line)for line in watchdog.read_text().splitlines()][-1]
assert failure['event']=='memory_limit' and j['in_progress']
current=j.pop('in_progress');shutil.copy2(manifest_path,manifest_path.with_name('manifest-before-'+watchdog.stem+'.json'))
record=current|{'warmup':current['round']<0,'exit_code':137,'exit_code_observed':False,'supervisor_exit_code_observed':137,'wall_seconds':None,'max_rss_bytes':None,'stage_rows':None,'result_sha256':None,'watchdog_tree_bytes':failure['tree_bytes'],'failure':'Process-tree guard killed the whole driver; in_progress records the exact command and log. No wait4 result was returned. Resume omits this input/variant pair and all completed labels.','watchdog':str(watchdog)}
assert pathlib.Path(record['log']).exists();j['runs'].append(record);manifest_path.write_text(json.dumps(j,indent=2)+'\n');print(record['fixture'],record['variant'],record['round'],failure['tree_bytes'])

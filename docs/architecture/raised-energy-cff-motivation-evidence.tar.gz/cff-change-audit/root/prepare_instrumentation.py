from pathlib import Path
import subprocess, json, hashlib

p = Path('/tmp/cff-change-audit/benchmark-source')
paths = ['crates/spenso/src/tensors/parametric.rs', 'crates/spenso/src/network/mod.rs', 'crates/gammalooprs/examples/bnl_evaluator_atom_mwe.rs']
original = {f: subprocess.check_output(['git', 'show', 'd55a0f3e:'+f], text=True) for f in paths}
f = paths[0]
s = original[f]
old = subprocess.check_output(['git', 'show', '39561014:'+f], text=True)
old_top = old[old.index('fn grouped_sparse_atom_contract<I>'):old.index('// Finishing grouped')]
old_multi = old[old.index('fn grouped_sparse_atom_multi_contract<I>'):old.index('\nimpl<I> ParamTensor<I>', old.index('fn grouped_sparse_atom_multi_contract<I>'))].replace('GROUPED_SPARSE_ATOM_SUM_AUTO_PARALLEL', 'GROUPED_ATOM_SUM_AUTO_PARALLEL')
start = s.index('fn grouped_atom_contract<I>')
pos = s.index('{\n', s.index('    I: TensorStructure + Clone + StructureContract,', start))+2
s = s[:pos]+'''    // Audit-only replay of the original specialization with final dependencies.
    static OLD_KERNEL: std::sync::OnceLock<bool> = std::sync::OnceLock::new();
    static TRACE: std::sync::OnceLock<bool> = std::sync::OnceLock::new();
    if *TRACE.get_or_init(|| std::env::var_os("CFF_AUDIT_TRACE").is_some()) {
        let common = left.structure().match_indices(right.structure())
            .map_or(0, |(_, m, _)| m.into_iter().filter(|v| *v).count());
        eprintln!("CFF_AUDIT_CONTRACT left_sparse={} right_sparse={} common={}",
            matches!(left, DataTensor::Sparse(_)), matches!(right, DataTensor::Sparse(_)), common);
    }
    if *OLD_KERNEL.get_or_init(|| std::env::var_os("CFF_AUDIT_OLD_KERNEL").is_some()) {
        return grouped_sparse_atom_contract(left, right);
    }
'''+s[pos:]
s = s.replace('fn grouped_atom_contract<I>', old_top+old_multi+'\nfn grouped_atom_contract<I>', 1)
(p/f).write_text(s)
f = paths[1]
s = original[f]
needle = '        let mut aliased = AliasedAtom::from(root);\n        for index in self.aliased_indices() {'
assert s.count(needle) == 1
s = s.replace(needle, '''        let mut aliased = AliasedAtom::from(root);
        let old_registration = std::env::var_os("CFF_AUDIT_OLD_ALIAS").is_some();
        for index in self.aliased_indices() {''')
s = s.replace('            aliased.register_alias(scalar_store_alias(index), original);', '''            if old_registration {
                aliased = aliased.add_alias(scalar_store_alias(index), original);
            } else {
                aliased.register_alias(scalar_store_alias(index), original);
            }''', 1)
start = s.index('    let keep_lazy = !all_scalar_terms')
end = s.index('\n    if profile::enabled()', start)
block = s[start:end]
assert block.count('profile::lazy_tensor_sums() || {') == 1
block = block.replace('profile::lazy_tensor_sums() || {', 'profile::lazy_tensor_sums() || (!*OLD_EAGER.get_or_init(|| std::env::var_os("CFF_AUDIT_OLD_EAGER").is_some()) && {').replace('        });', '        }));')
s = s[:start]+'    static OLD_EAGER: std::sync::OnceLock<bool> = std::sync::OnceLock::new();\n'+block+s[end:]
(p/f).write_text(s)
f = paths[2]
s = original[f]
s = s.replace('        match $order {', '''        if std::env::var_os("CFF_AUDIT_SMALLEST_DEGREE").is_some() {
            $net.execute::<Sequential, SmallestDegree, _, _, _>(
                TENSORLIB.read().unwrap().deref(), FUN_LIB.deref())
        } else { match $order {''', 1)
s = s.replace('        }\n    };\n}', '        }}\n    };\n}', 1)
needle = '        let aliased = net.aliased_atom(aliases, root);'
assert s.count(needle) == 1
s = s.replace(needle, '''        let alias_wrap_started = Instant::now();
        let aliased = net.aliased_atom(aliases, root);
        let alias_wrap_elapsed = alias_wrap_started.elapsed();
        summary.push("alias_registration", "done", format_duration(alias_wrap_elapsed), "", "", "");''')
s = s.replace('    fn print(&self) {\n        if self.rows.is_empty() {', '\n'.join([
    '    fn print(&self) {',
    '        if let Some(path) = std::env::var_os("CFF_AUDIT_SUMMARY") {',
    '            std::fs::write(path, serde_json::to_vec_pretty(&self.rows).unwrap()).unwrap();',
    '        }',
    '        if self.rows.is_empty() {']), 1)
(p/f).write_text(s)
manifest = []
for f in paths:
    before = original[f]
    after = (p/f).read_text()
    manifest.append({'path': f, 'original_sha256': hashlib.sha256(before.encode()).hexdigest(), 'audit_sha256': hashlib.sha256(after.encode()).hexdigest()})
    (Path('/tmp/cff-change-audit/root')/(Path(f).name+'.original')).write_text(before)
Path('/tmp/cff-change-audit/root/instrumentation.json').write_text(json.dumps(manifest, indent=2)+'\n')
print('Prepared audit-only old kernel, old alias registration, old eager materialization, and SmallestDegree switches.')

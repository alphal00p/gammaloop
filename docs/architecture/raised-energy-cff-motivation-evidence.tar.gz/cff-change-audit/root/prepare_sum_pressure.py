"""A controlled factorized rank-four tensor block; not a physical Feynman graph."""
from pathlib import Path
import hashlib,json
root=Path('/tmp/cff-change-audit/root/sum-pressure');root.mkdir(exist_ok=True)
terms=12000
coefficients=['('+'+'.join(f'1/({j}+audit::E)' for j in range(1+shift,terms+1+shift))+')' for shift in (0,terms)]
products=[]
for edge in (0,1,2):
 products.append('*'.join(f'gammalooprs::{{spenso::rank1,spenso::tensor}}::Q3({edge},spenso::{{spenso::representation,spenso::self_dual}}::mink(4,gammalooprs::{{spenso::index}}::hedge({i})))' for i in range(4)))
expr=f'({coefficients[0]}*{products[0]}+{coefficients[1]}*{products[1]})*{products[2]}\n'
path=root/'weighted-rank-four.sym';path.write_text(expr)
(root/'provenance.json').write_text(json.dumps({'kind':'controlled scalar-weighted tensor stress input, not a physical graph or UV oracle','terms_per_coefficient':terms,'input':str(path),'sha256':hashlib.sha256(expr.encode()).hexdigest(),'oracle':'c0*(q0·q2)^4+c1*(q1·q2)^4 with Q3 temporal components zero, c0=sum_{j=1}^{12000}1/(j+E), c1=sum_{j=12001}^{24000}1/(j+E). This is a finite tensor-component contraction; no distribution of a graph numerator.','purpose':'Isolate broadcasting large factorized scalar coefficients into a rank-four tensor sum before its open indices contract. Aliasing can be enabled/disabled independently; production threshold remains16MiB.'},indent=2)+'\n')
print(path,len(expr))

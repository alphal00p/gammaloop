from pathlib import Path
import json, statistics
root=Path('/tmp/cff-change-audit')
load=lambda p:json.loads((root/p).read_text())
parts=['''# Raised-energy CFF change motivation and benchmarks

Current evidence, physical inputs, measured costs and open findings · 11 September 2026

## Assessment

The changes do not all have the same justification. Several repair concrete wrong values, index capture, invalid-input handling or output contracts. Others add requested capabilities or simplify ownership. The measurements support grouped dense/mixed contraction, no-chain collection, direct alias registration and exact base caching on their reached workloads. They also expose cost without demonstrated benefit on the tested inputs: powered scalar-dot freshening, CFF compaction and unproductive assignment contenders deserve reconsideration. No universally best contraction ordering is established.

The inventory covers **73 logical categories, all 579 commit/path records and 505 distinct paths** in the seven reconstructed commits. A category is a semantic group, not an assertion that each changed hunk has a separate causal reproducer. The complete inventory includes source revisions, concrete inputs, current conclusions and a path-to-owner map. A successful current test alone is not evidence that the old implementation failed.

This audit changes documentation and retains isolated experimental sources. It does not change production implementations, failing test expectations or the reviewed seven-commit bookmark. The executable source is pinned to `d55a0f3e9d25e5c64bdb9ef9fb57749ecf680390` (functional parent `1a747039`); the original tensor baseline is `39561014`. Most A/B experiments restore one old method or disable one optimization on current dependencies. They are not whole historical-release comparisons.

## Inputs and measurement contract

The requested physical input is an isolated two-loop gluon two-point double triangle: a three-gluon vertex at 0, gluons 0–1 and 0–2, and a closed top-quark loop 1→2→3→1. Vertices use the SM `V_36` and three `V_137` rules, with the fermion-loop sign and complete propagator/vertex numerators retained. An external Lorentz/color trace closes the tensor. This is one physical diagram, not a complete gauge-invariant amplitude or integrated cross section. The 140,005-byte captured contraction input includes its complete CFF expression; UV and thresholds are disabled for that contraction benchmark.

The ttH capture is the physical GL38 NLO numerator (the source's GL20 label), with UV and threshold terms. BNL supplies four scalar aliases; nine legacy delta-head names are migrated to the current owner without changing arguments, coefficients or factorization. The factorized rank-four stress input supplies large scalar sums specifically to reach automatic deferred broadcasting. Controlled 4D/8D DD/DS/SD/SS tensors isolate storage effects. The CFF-only double-triangle-derived cases use owner-compatible energy-polynomial witnesses, not the full spin/color numerator or certified Taylor sectors. Quark-bubble Vakint inputs retain actual tensor and color algebra.

Root contraction, foundation, shared CFF and core variants have one excluded warm-up followed by six balanced forward/reverse rounds. Vakint and Feyngen body timing instead use six interleaved rounds with unequal pair-leading order. Feyngen end-to-end uses two exact forward/reverse rounds after a warm-up, a resource-based design revision declared before its measurements. Those limitations constrain small-difference claims. Rust builds use `dev-optim` (GammaLoop optimization level 2, dependency package overrides at 3). Executables, inputs and patches are hash-pinned. Root, foundation, core and Vakint timings use one worker on CPU 8; shared CFF uses CPU 9. Feyngen body timing uses CPU 8. Feyngen end-to-end uses the same CPU affinity 8–11 with either one or four workers; a one-worker process may migrate within that mask. A shared lock serializes the timing families and heavy comparisons; builds were coordinated to finish before measurements. Other users run on the host, an AMD EPYC 9754; there is no exclusive-machine or fixed-frequency guarantee. Small differences with overlapping ranges are descriptive observations.

Stage times exclude parsing/output when named. Whole-child RSS includes initialization, parsing, contraction and output, and can include a launcher high-water floor. It is not isolated kernel allocation. Binary hashing streams bytes; an invalid preliminary whole-binary-hash RSS experiment is excluded. Process-tree watchdog caps are 8GB for the main workflow families and 15GB for foundation probes; builds have separate caps within the coordinated 30GB aggregate budget. Failed observations remain visible and are not retried. Snapshot updates are disabled. Resource-guard termination is distinct from a returned wrong value.

## Tensor scheduling

Cells show median network-execution milliseconds / median whole-child RSS in decimal MB. All six scheduling choices use the same complete input, alias threshold and execution mode. SmallestDegree is the existing strategy selected by the diagnostic switch, even though its underlying CLI argument names the default preset.
''']
def table(headers,rows):
 return '\n| '+' | '.join(headers)+' |\n| '+' | '.join(['---']*len(headers))+' |\n'+''.join('| '+' | '.join(map(str,row))+' |\n'for row in rows)+'\n'
contraction=load('contraction-benchmarks/analysis.json');groups={(x['fixture'],x['variant']):x for x in contraction['groups']}
fixtures=['gg-double-triangle','ttH-GL38','BNL-alias-pressure']
rows=[]
for variant in ['intermediate-cost','sparse-atom-aware','atom-aware','result-rank-only','entry-aware','smallest-degree']:
 row=[variant]
 for f in fixtures:
  if (f,variant)not in groups:row.append('8GB guard; no result');continue
  s=groups[f,variant]['statistics'];row.append(f"{s['network_execute_seconds']['median']*1e3:.3f} / {s['max_rss_bytes']['median']/1e6:.1f}")
 rows.append(row)
parts.append(table(['Strategy','Double triangle','ttH','BNL'],rows))
rows=[]
for variant in ['intermediate-cost','sparse-atom-aware','atom-aware','result-rank-only','entry-aware','smallest-degree']:
 row=[variant]
 for fixture in fixtures:
  row.append(f"{groups[fixture,variant]['statistics']['wall_seconds']['median']:.3f}" if (fixture,variant)in groups else '8GB guard; no result')
 rows.append(row)
parts.append('Whole diagnostic-process medians in seconds include parsing, complete alias resolution and output dumping. They are not full GammaLoop generation or integration times.\n')
parts.append(table(['Strategy','Double triangle s','ttH s','BNL s'],rows))
parts.append('Intermediate-cost has the lowest whole-process median on ttH and BNL despite slower network execution than some alternatives. In BNL, alias resolution alone takes 0.281s with intermediate-cost versus approximately 1.44–1.46s with the atom/entry alternatives and 18.81s with result-rank-only. Choosing from the network timer alone would miss this measured downstream cost.\n')

parts.append('''Intermediate-cost uses less whole-child memory on ttH and BNL, with some network-execution cost relative to faster presets. These measurements do not separate live intermediate allocation from parsing and output. Result-rank-only is especially costly on ttH and BNL. SmallestDegree crosses the 8GB guard during warm-up on both, at 8.33GB and 8.45GB process-tree RSS; those runs have no valid completion time or full result. Its twelve later observations are deliberately unattempted. This compares the provided choices, not every possible contraction tree, cost-weight configuration or threading strategy.

The scheduling/kernel matrix records 177 observations: 150 measured successes, 25 successful warm-ups and two guard-terminated warm-ups. All ten distinct successful output hashes map to passed complete-value comparisons at three shared exact algebraic points. One output prints 78 instances of the exactly integral literal 2.00000000000000; an explicit 2.0→2 conversion ledger covers that representation boundary while retaining the unchanged oracle and original dump. Representation differences are not correctness failures. Raw distributions retain minima, maxima and sample standard deviations.

## Multi-index contraction and scalar aliases

Dense–dense and mixed multi-index contraction already worked through the generic API. The change extends grouped symbolic accumulation to those storage combinations. It does not add previously missing contraction semantics. The physical g–g trace reaches dense contractions over two, three and four common axes; both versions also pass the independent storage-component oracle.
''')
rows=[]
for f in fixtures:
 a=groups[f,'old-multi-index-kernel']['statistics']['network_execute_seconds']['median']
 b=groups[f,'intermediate-cost']['statistics']['network_execute_seconds']['median']
 rows.append([f,f'{a*1000:.3f}',f'{b*1000:.3f}',f'{a/b:.2f}×'])
parts.append(table(['Input','Old network ms','Current network ms','Old / current'],rows))
parts.append('The strongest physical kernel gains are on gg and ttH. BNL has a smaller approximately 4% median difference; raw paired samples and spread remain in the evidence. These are network-stage comparisons, not equivalent total-workflow speedups.\n')
foundation=load('foundation-bugs/artifacts/matrix-summary.json')
rows=[]
for x in foundation:
 if x['suite']!='multi-performance':continue
 a=x['variants']['baseline']['median_ns']/1e6;b=x['variants']['final']['median_ns']/1e6
 rows.append([x['case'],f'{a:.4f}',f'{b:.4f}',f'{a/b:.2f}×'])
parts.append(table(['Controlled input','Old ms','Current ms','Old / current'],rows))
parts.append('''Each controlled tensor has two common Euclidean axes and one free axis per operand. Density16 means one populated coordinate in sixteen, including deliberately zero-filled dense storage. Every output component is compared with an independent coordinate sum using expanded subtraction on finite components. This does not distribute a graph numerator. The 32 old/current storage smokes and all 224 timed/warm-up storage observations agree. Sparse–sparse is mostly unchanged; neither the old sparse fiber nor the new loop is a nonzero-only traversal. These dimensions/densities do not establish asymptotic performance for enormous sparse domains.
''')
a=groups['BNL-alias-pressure','old-alias-registration']['statistics']['alias_registration_seconds']['median'];b=groups['BNL-alias-pressure','intermediate-cost']['statistics']['alias_registration_seconds']['median']
parts.append(f'On BNL, direct registration changes the alias-registration stage from **{a*1000:.3f} ms to {b*1000:.3f} ms** ({a/b:.1f}×), with four aliases and equivalent complete results. That stage is a small part of total runtime; the total-wall distributions do not establish an end-to-end speedup. The double triangle and ttH create no aliases, so their old-registration flag timings are inactive controls.\n')
parts.append('## Chain collection, factorization and powered dots\n')
rows=[]
for x in foundation:
 if x['suite']=='multi-performance':continue
 a=x['variants']['baseline'];b=x['variants']['final']
 rows.append([x['case'],f"{a['median_ns']/1000:.3f}",f"{b['median_ns']/1000:.3f}",f"{x['baseline_over_final_ratio']:.2f}×"])
parts.append(table(['Operation/input','Old µs','Current µs','Old / current'],rows))
parts.append('''The no-chain early return removes work while preserving the complete physical numerator. The no-zero result times full canonicalization under a scoped multi-file ablation; it cannot apportion the improvement solely to pruning. Separately, the old zero-pruning path distributes an unrelated spectator, violating the explicit factorization contract even though its expanded algebra is equal.

Powered scalar-dot freshening has no reproduced necessity on the current consumers: square, nested and GL06 conversions give the same complete scalar results with the old converter. The GL06 oracle uses a known degree bound and exact interpolation coordinates rather than expanding the graph numerator. Freshening is slower on every measured input. Keep it only with a concrete case that needs it, or simplify it after verifying the remaining backend boundary (including manual PySecDec, untested here); these measurements do not justify a correctness-fix label.
''')
parts.append('## Deferred scalar-weight broadcasting\n')
if (root/'sum-pressure-benchmarks/analysis.json').exists():
 sums=load('sum-pressure-benchmarks/analysis.json');rows=[]
 for x in sums['groups']:
  s=x['statistics'];rows.append([x['variant'],f"{s['network_execute_seconds']['median']*1000:.3f}",f"{s['wall_seconds']['median']:.3f}",f"{s['max_rss_bytes']['median']/1e6:.1f}"])
 parts.append(table(['Variant','Network ms','Whole wall s','Child RSS MB'],rows))
else:parts.append('Measurements pending in draft.\n')
parts.append('''The controlled factorized input is `(c0 q0⊗q0⊗q0⊗q0 + c1 q1⊗q1⊗q1⊗q1) : q2⊗q2⊗q2⊗q2`, where each coefficient sums 12,000 simple rational terms. The independent value is `c0(q0·q2)^4 + c1(q1·q2)^4`. Python Fraction arithmetic checks three complete values, including full alias definitions. It is a representative scalar-broadcast stress input, not a physical UV-locality certificate or an identity proof for all scalar parameters. Current versus old-eager with aliases disabled isolates automatic deferral; enabling aliases is a separate intervention. None of the ordinary physical captures reaches automatic deferral.
''')
parts.append('## Shared CFF generation\n\nGeneration medians in milliseconds; complete output serialization is outside the timer. The complete distributions and all five variants are retained in the evidence bundle.\n')
cff=load('cff-perf/timed-final/summary.json');cffmap={(x['fixture'],x['variant']):x for x in cff};rows=[]
for f in ['physical_double_triangle_affine','physical_double_triangle_dotted','box_cubic_rank4','sunrise_quartic_rank4','independent_bubbles_rank2','physical_double_triangle_quartic_gluon']:
 rows.append([{'physical_double_triangle_affine':'gg affine','physical_double_triangle_dotted':'gg dotted','box_cubic_rank4':'cubic box','sunrise_quartic_rank4':'quartic sunrise','independent_bubbles_rank2':'two bubbles','physical_double_triangle_quartic_gluon':'gg rank-6 stress'}[f]]+[f"{cffmap[f,v]['generation_median_seconds']*1000:.3f}"for v in ['final','eager_layers','eager_parent_fanout','no_base_cache','no_compaction']])
parts.append(table(['Input','Current','Eager layers','Eager fanout','No base cache','No compaction'],rows))
parts.append('''All 210 observations complete (180 measured, 30 warm-ups), and every dumped expression matches its fully evaluated trace for the same variant. Exact base caching helps the reached box, sunrise and larger gg topology. On the larger gg diagnostic, disabling compaction is faster in every paired round; mean generation falls from 1.475s to 1.154s, with the same 22.4MB expression and approximately 44MB peak child RSS. This is a concrete simplification candidate for this path, not proof that compaction is unnecessary for products of multiple components.

Streaming reaches only one-component products in that larger stress case; the two-component bubble is tiny. Neither eager/streaming comparison demonstrates a resident-memory saving here. Source evidence records a GL16 30GB failure, but these isolated experiments do not reproduce or apportion that resource failure. No isolated Rational-versus-Atom or merged-versus-independent-occurrence benchmark is claimed.

The complete CFF checks include 285 numerical observations and 15 independent denominator-pinch oracles, with maximum pinch error 1.507e-15. The 28 fresh public contracts pass. Exact old-parser-method replay distinguishes `-2**2` (4→−4), `2**3**2` (64→512), and an oversized exponent (wrapped value→error). These are small public-API counterexamples, not physical benchmark inputs.

## Core UV caches and assignment scoring

The core experiments keep physical numerator owners, request-local capacities, exact reconstruction certificates and selected payload/assignment association intact. Total-cache disabling removes both payload and count reuse; count-only disabling retains completed winners. The one-proposal variant scores the first certified rank-ordered candidate but still constructs the proposal list. It is not a complete recreation of the old planner or union-envelope cache.
''')
core=load('core-perf/timings/analysis.json');rows=[]
for x in core['summary']:
 rows.append([x['fixture']+' / '+x['variant'],f"{x['wall_mean_seconds']:.3f} ± {x['wall_sample_stdev_seconds']:.3f}",f"{x['wall_median_seconds']:.3f}",f"{x['max_child_rss_bytes']/1e6:.1f}"])
parts.append(table(['Input / variant','Wall mean ± SD s','Wall median s','Peak child MB'],rows))
parts.append('All 56 observations pass (48 measured, 8 warm-ups). The measured unit includes fresh import/generation, three inspections and computed forest export, including work repeated by that exporter. Mean differences of 0.3–2.3% are small relative to the 0.28–0.58s sample spread; these runs do not establish a convincing total-workflow speed or memory benefit.\n')
parts.append('''Both GL04 inputs have exact equality of all three complete inspection JSON values and all nine computed forest/node DOT exports across variants. Their small real values are compared directly, without a unit-sized absolute tolerance floor. All alternative proposals lose: eleven GL04 groups have map counts `[14,20,20]`; seven temporal-square groups have `[32,56,44]`. Count-only disabling retains the same hit counts as current code, so these inputs do not demonstrate losing-count reuse. They exercise scoring overhead but do not justify its benefit. A partial GL16 trace does reach a winning third proposal: `[1200,1224,1104]` reduces the rank-first map count by 8%. All four GL16 variants time out at 180s before inspection or computed exports; none supplies full-value parity or a total-runtime comparison. The traced peak process-tree RSS is 545MB, so this is a time limit, not a reproduction of the source's 30GB failure. Matching diagnostic prefixes show far fewer generated contenders with memoization, and 52 paired parsed-source/bounds records match exactly. Cache hits omit the source and some canonical-key fields, so the traces are not an independent proof of every hit's key identity.
''')
parts.append('## Vakint and numerator matching\n')
parts.append('''Both Vakint input modes and both forest owners produce the same complete nonzero Laurent expression for the physical gluon–top-quark bubble. Exact dummy-name normalization and rational cancellation check pole and finite terms; mode flags are verified at the actual backend boundary. The scalar self-energy is a control. All 56 measured/warm-up workflows complete and their full computed exports match the validated results. Scalar medians are 0.783–0.809s; quark-bubble medians are 1.382–1.405s, with 35MB/69MB peak child RSS. Paired monolithic/projected ratios are about 0.990 and 1.003 for the two owners, with overlapping ranges: no consistent speed advantage is established. Projected mode leads three of six paired rounds for quark/hedge and four of six for the other mode pairs; the schedule is interleaved, not exactly balanced.

For the full two-loop double triangle, projected processing exceeds 180 seconds for both owners, while whole-numerator processing reaches the 8GB guard for both. These are explicit coverage limits, not failed numerical comparisons. Both modes still require d-dimensional closure and adequate Laurent depth; choosing an input mode does not replace those correctness requirements.
''')
parts.append('''The numerator-matching input is a two-loop three-gluon vertex family with top-quark loops: 36 candidates in 24 topologies. Twelve nonsingleton buckets contain two candidates each; all twelve compared pairs are rejected. The inputs carry five numerical and five polynomial samples, with no canonical numerator. Twenty repeated calls use each actual physical pair. This reaches early rejection but neither long bucket scans nor the canonical-numerator path. The smaller physical control additionally exercises a matching pair with complete result `Some(1)`.

The body experiment completes all 28 observations (24 measured, four warm-ups). Every pair key is unique; all complete comparison results agree between old and current methods, and every 36-graph DOT map agrees with the validated physical reference. Times below are medians per comparison call, averaged across the twelve physical pairs within each process. The timer includes black-box argument/result handling and a push into a preallocated result vector; setup, allocation and equality assertions are outside it. These microbenchmarks repeat the comparator, not the full generator.
''')
body=load('feyngen-perf/body-physical-20-balanced/summary.json');rows=[]
for mode in ['sign','scalar']:
 old=body['variants'][mode+'-1workers-old-comparator']['body_nanoseconds_per_comparison'];new=body['variants'][mode+'-1workers-current']['body_nanoseconds_per_comparison'];ratio=body['paired_old_over_current_body_ratios'][mode]
 rows.append([mode,f"{old['median']/1e6:.3f}",f"{new['median']/1e6:.3f}",f"{ratio['median']:.3f} [{ratio['min']:.3f}, {ratio['max']:.3f}]"])
parts.append(table(['Comparison','Old ms/call','Current ms/call','Paired old/current ratio [range]'],rows))
parts.append('Ratios are computed within each paired round before taking their median; they need not equal the ratio of the two marginal time medians.\n')
parts.append('''Sign-only rejection is faster on this reached workload; scalar-factor comparison shows no benefit beyond run-to-run variation. The six body rounds are interleaved with current first in four sign rounds and five scalar rounds, so small differences must not be presented as precise causal effects. Repetition-inclusive CLI medians are about 67s for sign and 110s for scalar: most of that work is numerator preparation, and twenty artificial comparator repetitions must not be confused with default generation cost.

The global-lock intervention retains current bucket storage, clone removal and zero-mask construction. It restores serialization around lookup/search/insertion rather than rebuilding the complete old architecture. The larger four-gluon case reaches 567 candidates but times out during preparation/grouping at 180 seconds; it supplies no completed graph parity or timing ratio. A 5,000-repetition calibration also times out, which is a limit of the artificially amplified body experiment, not a demonstrated timeout of default generation.
''')
if (root/'feyngen-perf/e2e-physical-two-rounds/summary.json').exists():
 e2e=load('feyngen-perf/e2e-physical-two-rounds/summary.json')
 assert e2e['all_planned_observations_accounted_for']
 assert e2e['validated_default_export_linkage']['all_nonempty_export_maps_equal']
 parts.append(f"The end-to-end experiment accounts for {e2e['observations']} executed observations out of {e2e['planned_observations']} planned: {e2e['successful_observations']} successful, {e2e['timed_observations']} measured, {len(e2e['failures'])} failed and {len(e2e['planned_observation_omissions'])} omitted after a failed variant. Successful observations retain all 36 physical graph exports and agree directly with the validated default. Each variant has one excluded warm-up and two exact forward/reverse measured rounds; the repetition hook is disabled.\n")
 parts.append('The cells below contain the range of the two complete CLI wall times in seconds. Preparation, lookup and grouping remain included; these are descriptive observations on a shared host.\n')
 rows=[]
 for mode in ['sign','scalar']:
  for workers in [1,4]:
   row=[f'{mode} / {workers} workers']
   for variant in ['current','old-comparator','global-lock','both']:
    v=e2e['variants'][f'{mode}-{workers}workers-{variant}']
    row.append(f"{v['wall_seconds']['min']:.3f}–{v['wall_seconds']['max']:.3f}" if 'wall_seconds'in v else 'No completed measurement')
   rows.append(row)
 parts.append(table(['Mode / workers','Current s','Old comparator s','Global lock s','Both s'],rows))
 rows=[]
 for mode in ['sign','scalar']:
  for workers in [1,4]:
   row=[f'{mode} / {workers} workers']
   for variant in ['old-comparator','global-lock','both']:
    v=e2e['paired_e2e_intervention_over_current_ratios'][f'{mode}-{workers}workers-{variant}']
    ratio=v.get('wall_seconds')
    row.append(f"{ratio['min']:.3f}–{ratio['max']:.3f}" if ratio else 'No paired measurement')
   rows.append(row)
 parts.append(table(['Mode / workers','Old/current ratio','Global/current ratio','Both/current ratio'],rows))
 parts.append('No end-to-end gain is established. In the four-worker observations, current takes longer than each ablation in both rounds; these results must not be hidden by the faster isolated sign-comparison body. The small shared-host sample does not establish the cause or a general regression.\n')
 parts.append('The numerator-preparation/grouping milestones, whole-child RSS and full samples are retained in the evidence. The milestone is an inclusive preparation/grouping duration, not isolated lock time. Two observations per variant cannot establish a precise speedup; worker scaling mostly reflects the complete parallel preparation workload. With at most two candidates per bucket, this experiment cannot certify the motivating large-bucket/global-lock claim.\n')
else:parts.append('End-to-end numerator-matching measurements pending in draft.\n')

parts.append('''## Reproduced defects and open findings

The focused foundation suite has 22/22 current passes. Reversing eight production files on current dependencies gives 12 passes and 10 failures: seven index/normalization/namespace/factorization failures and three newly supported compact-syntax probes. These are not ten independent physics bugs. The baseline regression build additionally enables Idenso serialization/reference-case features; the named arithmetic paths are unchanged, but the full build feature sets are not identical. The nested-sum Symbolica panic is a pinned-source counterexample; the fixed dependency remains in this local ablation. No failing product test is edited.

**Inspection JSON remains defective.** On the same saved GL04 state and point, event generation with additional weights disabled writes three events successfully. Enabling additional weights preserves the plain numerical result but `inspect --json-output` fails with `key must be a string`, before writing the JSON file. `AdditionalWeightKey::ThresholdCounterterm { subset_index }` is a structured enum used as a map key. The map representation is inherited unchanged from the base; commit 4 adds the JSON inspection workflow and exposes the incompatibility. The first differing boundary is JSON serialization, after successful evaluation. Source state hashes are unchanged. This audit reports the defect without patching it.

A diagnostic boundary also needs care: reparsing Python Symbolica's canonical string for `(2+3i)/7*x` changes coefficient grouping. The plain printer round-trips in the reproducer. This is not evidence of a GammaLoop evaluation defect; the comparison harness retains live expressions and parses original Rust plain-string dumps, never intermediate canonical strings. The exact reproducer is retained.

The three added compact-materializer tests exercise a private parsing stage. `scalar_weighted_compact_vector_argument_becomes_slot_and_factor` asserts its intermediate product and shared slots; `product_of_two_compact_vectors_is_not_a_rank_one_argument` and `compact_vector_times_explicit_tensor_is_not_a_rank_one_argument` assert private-stage pass-through. They are in [materialization.rs](../../crates/spenso/src/network/parsing/materialization.rs), at lines 1032, 1072 and 1087 on the pinned source. They do not satisfy the strongest requested outward-only test standard. Replace them with full public parse/contraction values and supported ambiguity behavior; retain separate external-slot contracts. Exact factorization assertions remain appropriate where preservation of factorization is itself the intended public behavior.

## Rust patterns and KISS

| Pattern | Effectiveness supported by the audit |
| --- | --- |
| Shared `Rc<Cell<_>>` allocation plus explicit reservations | Shared allocation is established behavior; reservations fix a reproduced capture. Keep ownership local to one parse and do not claim this introduces sharing. |
| Borrowed input views and grouped iterator accumulation | Avoid repeated symbolic normalization/copying; dense/mixed measurements support the specialization. General sparse-coordinate traversal remains a limit. |
| Owned scalar aliases and direct registration | The alias already exists, so registering it avoids a redundant root replacement search. The four-alias BNL stage supports this simplification. |
| Explicit deferred-result alternatives | Preserve a factorized sum until terminal materialization when eager broadcasting is expensive. The added branch must earn its complexity on an activated workload. |
| Concrete `Rational` coefficients and boundary conversions | Excludes unsupported symbolic coefficient states and makes exact arithmetic intent clear. Previous rational Atoms were already exact; no rounding or speed claim follows from the type alone. |
| One expression assembler and fallible public conversions | Shared invariant ownership reduces duplicate construction logic. Small malformed-input counterexamples justify Result-based rejection before indexing. |
| Immutable assignment plans and typed occurrence/owner IDs | Keep capacity, routing, physical owner and selected expression together. Reconstruction certificates justify these distinctions; LMB coordinates do not replace physical ownership. |
| Exact-key caches and bounded heuristic search | Base caching pays on reached high-rank inputs. No benefit from losing-count memoization or extra contenders is demonstrated on the completed GL04 inputs; a smaller map is only a proxy for total cost. |
| Mode enums and builder-owned settings | Clarify supported alternatives and keep migration at an owner. Both Vakint modes are requested functionality; no measured universal advantage justifies presenting one as inherently superior. |
| Short bucket locks and staged exact/sample comparisons | The reached sign-rejection body is faster; scalar matching has no demonstrated gain. The physical family has only two-candidate buckets, so the large-bucket motivation remains unproved. Canonical-numerator matching is not reached, and sampled matches remain probabilistic. |

Keep the demonstrated correctness fixes and required feature boundaries. Treat powered-dot freshening, combined root/product compaction on the reached single-component path, unproductive proposal scoring and unproved large-domain sparse behavior as review findings with explicit evidence limits. Do not remove mathematically necessary ownership distinctions merely to reduce line count, or retain a performance mechanism only because current tests pass.

## Per-change motivation inventory

Each row states the current justification or unresolved gap. The machine-readable inventory adds pinned source evidence, distinguishing inputs, existing regressions and complete file ownership. Recorded counterexamples identify a concrete failure in retained source evidence; they are not relabelled as fresh executions. Capability, policy and consumer migrations need not invent a motivating bug.
''')
inv=load('complete-inventory.json')
for owner in range(1,8):
 rows=[[x['id']+' — '+x['change'],x['audit_conclusion']]for x in inv['changes']if x['owner']==owner]
 parts.append(f'## Commit {owner}: motivation rows\n'+table(['Change','Evidence and conclusion'],rows))
parts.append('''## Fresh validation evidence

Counts describe the accepted command families in this audit. Warm-ups are retained separately from measured observations; repeated calls within one process are not independent test executions. The report does not combine these heterogeneous checks into a headline test total.

| Family | Fresh result | Complete-result evidence |
| --- | --- | --- |
| Foundation regressions | Current 22/22; scoped baseline 12 passes and 10 observed distinguishing failures | Seven defect/factorization cases and three supported-syntax probes; unchanged product tests |
| Foundation timing and storage | 308 successful observations: 264 measured, 44 warm-ups; 32 storage smokes pass | Independent component/value oracles outside the timed operation |
| Physical contraction matrix | 175 successful observations: 150 measured, 25 warm-ups; two guard terminations | All ten successful output hashes checked at three exact shared algebraic points |
| Deferred scalar-weight stress | 28 successful observations: 24 measured, four warm-ups | Three distinct full output hashes checked with the independent Fraction oracle |
| Shared CFF | 210/210 observations: 180 measured, 30 warm-ups; 28/28 public contracts | Full-expression trace linkage, 285 numerical observations and 15 independent pinch oracles |
| Core GL04 reconstruction | 56/56 observations: 48 measured, eight warm-ups; four GL16 timeouts | Three full inspections and nine complete computed forest/node exports |
| Vakint modes and owners | 56/56 observations: 48 measured, eight warm-ups; four full two-loop limits | Full nonzero Laurent oracle and direct linkage of every timed export |

Feyngen's body and end-to-end counts are reported with their timing tables and actual schedule. The reproduction bundle records formatting, locked checks and builds of the diagnostic executables, exact compiler/dependency hashes, commands and failures. No production source is modified by this audit, and no earlier workspace-suite total is presented as fresh measurement coverage.
''')
parts.append('''## Evidence and reproduction

The [complete inventory](raised-energy-cff-motivation-inventory.json) and [evidence bundle](raised-energy-cff-motivation-evidence.tar.gz) accompany this report. The bundle contains source pins, exact intervention patches, public-API probes, physical graph/model captures, input hashes, full timing manifests, per-output comparison receipts, resource failures and independent methodology review. It excludes executable binaries and license material. The reproducibility guide distinguishes valid final observations from discarded setup measurements and states how to provide a licensed local environment.

The validation counts in this audit come from its own pinned commands and receipts. No manual PySecDec integration is run, no full gauge-invariant two-loop gg acceptance is claimed, and no result demonstrates every possible contraction tree or arbitrary sparse domain. Unsupported performance necessity is a finding, not a silently completed benchmark.
''')
(root/'report-draft.md').write_text('\n'.join(parts))
print('Draft written',len('\n'.join(parts)),'characters')

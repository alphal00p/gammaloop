import os, json, time, resource, subprocess, pathlib, sys, hashlib

root = pathlib.Path('/tmp/cff-change-audit')
config = json.loads(pathlib.Path(sys.argv[1]).read_text())
binary = pathlib.Path(config['binary'])
out = root / config['output']
out.mkdir(parents=True, exist_ok=True)
variants = config['variants']
rounds = config.get('rounds', 6)
manifest = {'source_pin': json.loads((root/'source-pin.json').read_text()),
            'binary': str(binary), 'binary_sha256': hashlib.file_digest(binary.open('rb'), 'sha256').hexdigest(),
            'config': config, 'timing_policy': 'One excluded warm-up per variant/input, then balanced forward/reverse rounds; no retries; parse, execution, alias registration and resolution separately; one worker pinned to CPU8.',
            'memory_policy': 'Peak child RSS from wait4 includes parse, contraction, result and JSON output; this is not isolated kernel allocation.', 'runs': []}
for fixture in config['fixtures']:
    input_path = pathlib.Path(fixture['path'])
    fixture_dir = out / fixture['id']
    fixture_dir.mkdir(exist_ok=True)
    fixture['sha256'] = hashlib.file_digest(input_path.open('rb'), 'sha256').hexdigest()
    for round_index in range(-1, rounds):
        ordered = variants if round_index % 2 == 0 else list(reversed(variants))
        for variant in ordered:
            label = f"{variant['id']}-{'warmup' if round_index < 0 else round_index}"
            log = fixture_dir / (label+'.log')
            summary = fixture_dir / (label+'.summary.json')
            result = fixture_dir / (label+'.result.json')
            env = os.environ.copy()
            for key in list(env):
                if key.startswith(('CFF_AUDIT_', 'SPENSO_')):
                    del env[key]
            env.update({'RAYON_NUM_THREADS':'1','NEXTEST_TEST_THREADS':'1','INSTA_UPDATE':'no','GL_DISPLAY_FILTER':'off','GL_LOGFILE_FILTER':'off','CFF_AUDIT_SUMMARY':str(summary)})
            env.update(variant.get('env', {}))
            command = ['taskset','-c','8','timeout','--signal=TERM','--kill-after=5s',str(config.get('timeout_seconds',180))+'s',str(binary),str(input_path),'all','--contraction-order',variant.get('order','intermediate-cost'),'--dump-aliased',str(result)]
            alias_threshold = variant.get('alias_threshold', fixture.get('alias_threshold', 4096))
            if alias_threshold is not None:
                command.extend(['--alias-scalars', str(alias_threshold)])
                if config.get('resolve_aliases', True):
                    command.append('--resolve-aliases')
            started = time.monotonic()
            with log.open('wb') as stream:
                child = subprocess.Popen(command,stdout=stream,stderr=subprocess.STDOUT,env=env)
                _, status, usage = os.wait4(child.pid, 0)
                child.returncode = os.waitstatus_to_exitcode(status)
            elapsed = time.monotonic()-started
            record = {'fixture':fixture['id'],'variant':variant['id'],'round':round_index,'warmup':round_index<0,'command':command,'environment_overrides':{**{'RAYON_NUM_THREADS':'1','INSTA_UPDATE':'no','SPENSO_*':'cleared to production defaults','GL_DISPLAY_FILTER':'off','GL_LOGFILE_FILTER':'off'},**variant.get('env',{})},'exit_code':child.returncode,'wall_seconds':elapsed,'max_rss_bytes':usage.ru_maxrss*1024,'log':str(log),'summary':str(summary),'result':str(result),'stage_rows':json.loads(summary.read_text()) if summary.exists() else None,'result_sha256':hashlib.file_digest(result.open('rb'),'sha256').hexdigest() if result.exists() else None}
            manifest['runs'].append(record)
            (out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
            print(f"{fixture['id']} {label}: exit={child.returncode}, wall={elapsed:.3f}s, peak={usage.ru_maxrss/1e6:.3f}GB",flush=True)
            if child.returncode != 0:
                # Preserve a failed/timed-out observation, then omit identical subsequent
                # attempts. Changing a cap or input is a separately recorded experiment.
                variants = [v for v in variants if v['id'] != variant['id']]
        if not variants:
            break
    variants = config['variants']
print('Finished. Semantic output comparisons are a separate required step.',flush=True)

import argparse,json,pathlib,re,sys,hashlib
from fractions import Fraction
from symbolica import Expression as E,Replacement
sys.set_int_max_str_digits(0)
parser=argparse.ArgumentParser();parser.add_argument('--output',type=pathlib.Path,required=True);parser.add_argument('inputs',type=pathlib.Path,nargs='+');args=parser.parse_args()
exprs=[]
for path in args.inputs:
 j=json.loads(path.read_text());exprs.append((path,E.parse(j['root']),[(E.parse(a['alias']),E.parse(a['original'])) for a in j['aliases']]))
variables=sorted({v.to_canonical_string() for _,root,aliases in exprs for part in [root]+[b for _,b in aliases] for v in part.get_all_indeterminates(False) if '::scalar(' not in v.to_canonical_string()})
records=[]
for seed in (1,2,3):
 replacements=[]; q={}
 for var in variables:
  if var=='audit::{}::E':value=seed
  else:
   match=re.fullmatch(r'gammalooprs::\{\}::Q\((\d+),spenso::\{\}::cind\((\d+)\)\)',var);assert match,var
   edge,component=map(int,match.groups());value=(edge+2)*component+seed;q[edge,component]=value
  replacements.append(Replacement(E.parse(var),E.num(value)))
 dots=[-sum(q[e,c]*q[2,c] for c in (1,2,3)) for e in (0,1)]
 coefficients=[sum((Fraction(1,j+seed) for j in range(1+offset,12001+offset)),Fraction()) for offset in (0,12000)]
 expected=sum(c*d**4 for c,d in zip(coefficients,dots));expected_expr=E.parse(str(expected.numerator)+'/'+str(expected.denominator))
 for path,root,aliases in exprs:
  value=root.replace_multiple(replacements)
  substitutions=[Replacement(a,b.replace_multiple(replacements)) for a,b in aliases]
  for _ in range(len(aliases)+2):
   resolved=value.replace_multiple(substitutions) if substitutions else value
   if resolved==value:break
   value=resolved
  else:raise AssertionError('Alias substitution did not converge')
  difference=value-expected_expr
  assert difference==0,(path,seed,'independent complete tensor contraction mismatch')
  records.append({'input':str(path),'seed':seed,'equal_to_independent_component_oracle':True,'exact_residual':'0','expected_numerator_digits':len(str(expected.numerator)),'expected_denominator_digits':len(str(expected.denominator)),'expected_fraction_sha256':hashlib.sha256(str(expected).encode()).hexdigest()})
 print('seed',seed,'all',len(exprs),'passed',flush=True)
args.output.write_text(json.dumps({'method':'Exact primitive substitutions into complete root and alias definitions; compare against independent finite Minkowski component contraction c0*(q0·q2)^4+c1*(q1·q2)^4. Coefficients evaluated independently with Python Fraction. No graph numerator expansion; no canonical complex serialization.','inputs':[{'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p,_,_ in exprs],'records':records,'all_passed':True},indent=2)+'\n')

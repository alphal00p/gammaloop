"""Validate every distinct completed output after timing, under the shared lock."""
import collections,fcntl,hashlib,json,pathlib,subprocess,sys
root=pathlib.Path('/tmp/cff-change-audit');manifest_path=pathlib.Path(sys.argv[1]);j=json.loads(manifest_path.read_text());lock=(root/'measurement.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX)
groups=collections.defaultdict(dict)
for r in j['runs']:
 if r['exit_code']==0:
  p=pathlib.Path(r['result']);assert hashlib.file_digest(p.open('rb'),'sha256').hexdigest()==r['result_sha256']
  groups[r['fixture']].setdefault(r['result_sha256'],r)
normalization=json.loads((root/'root/integral-output-normalization.json').read_text())
validation=[]
for fixture,by_hash in groups.items():
 out=manifest_path.parent/(fixture+'-complete-values.json');assert not out.exists()
 script=root/('root/sum-pressure/compare.py'if fixture=='weighted-rank-four'else'physical/compare_outputs_live.py')
 command=['/tmp/raised-stack/python',str(script),'--output',str(out)]+[normalization['normalized']if r['result_sha256']==normalization['original_sha256']else r['result']for r in by_hash.values()]
 print('Compare',fixture,len(by_hash),'distinct complete outputs',flush=True)
 with out.with_suffix('.log').open('wb')as log:
  result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
 record={'fixture':fixture,'exit_code':result.returncode,'command':command,'result':str(out),'unique_output_hashes':list(by_hash),'exact_integral_literal_normalization':normalization if normalization['original_sha256']in by_hash else None,'successful_observations_covered':sum(r['exit_code']==0 and r['fixture']==fixture for r in j['runs'])}
 validation.append(record);(manifest_path.parent/'complete-value-coverage.json').write_text(json.dumps(validation,indent=2)+'\n')
 assert result.returncode==0,'Keep mismatch or resource failure; do not change the oracle'
 print('Passed',fixture,flush=True)

from pathlib import Path
import difflib,hashlib,json,subprocess
root=Path('/tmp/cff-change-audit'); src=root/'benchmark-source'; pin='d55a0f3e9d25e5c64bdb9ef9fb57749ecf680390'
paths=['crates/spenso/src/tensors/parametric.rs','crates/spenso/src/network/mod.rs','crates/gammalooprs/examples/bnl_evaluator_atom_mwe.rs','crates/gammalooprs/src/feyngen/diagram_generator.rs','crates/gammalooprs/src/cff/generation.rs']
patch='';records=[]
for path in paths:
 old=subprocess.check_output(['git','show',pin+':'+path]).decode();new=(src/path).read_text()
 patch+=''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+path,tofile='b/'+path))
 records.append({'path':path,'original_sha256':hashlib.sha256(old.encode()).hexdigest(),'instrumented_sha256':hashlib.sha256(new.encode()).hexdigest()})
(root/'root/instrumentation-complete.patch').write_text(patch)
(root/'root/instrumentation-complete.json').write_text(json.dumps({'pin':pin,'files':records,'scope':'Audit-only source checkout. No production changes. Original old kernels/comparators copied from pinned source; one-proposal and cache switches are controlled optimization removals, not whole historical builds.'},indent=2)+'\n')
print('Frozen',len(paths),'paths',len(patch),'patch bytes')

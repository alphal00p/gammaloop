from pathlib import Path
import json
import re
import sys

source_path = Path(sys.argv[1])
folder = source_path.parent
source = source_path.read_text()
# The generated Typst file is self-contained; this draft helper is not a runtime dependency.
def inline(value):
    parts = re.split(r'(`[^`]+`|\*\*[^*]+\*\*|\[[^\]]+\]\([^)]+\))', value)
    out = []
    for part in parts:
        if not part:
            continue
        if part.startswith('`'):
            out.append('#text(font: "DejaVu Sans Mono", size: 0.86em, ' + json.dumps(part[1:-1], ensure_ascii=False) + ')')
        elif part.startswith('**'):
            out.append('#strong(' + json.dumps(part[2:-2], ensure_ascii=False) + ')')
        elif part.startswith('['):
            label, target = re.fullmatch(r'\[([^\]]+)\]\(([^)]+)\)', part).groups()
            out.append('#link(' + json.dumps(target, ensure_ascii=False) + ')[#text(' + json.dumps(label, ensure_ascii=False) + ')]')
        else:
            out.append('#text(' + json.dumps(part, ensure_ascii=False) + ')')
    return ''.join(out)

header = '''// Self-contained typesetting of raised-energy-cff-stack-review.md.
// Current implementation, validation results, and coverage limits.
#set document(date: datetime(year: 2026, month: 9, day: 11), title: "Raised-energy CFF stack review", author: "Codex",
  description: "Seven-commit reconstruction: correctness, Rust idioms, KISS and outward test contracts; current implementation and completed validation.")
#set page(paper: "a4", margin: (x: 18mm, top: 19mm, bottom: 18mm),
  header: align(right)[#text(font: "DejaVu Sans", size: 8pt, fill: rgb("667085"))[GammaLoop / Reconstructed stack review]],
  footer: context [#line(length: 100%, stroke: 0.4pt + rgb("d0d5dd"))
    #v(2mm)
    #text(font: "DejaVu Sans", size: 8pt, fill: rgb("667085"))[Current implementation review #h(1fr) #counter(page).display("1 / 1", both: true)]])
#set text(font: "Libertinus Serif", size: 10.5pt, fill: rgb("202939"))
#set par(leading: 0.58em, spacing: 0.78em, justify: false)
#set heading(numbering: none)
#show heading.where(level: 1): set text(font: "DejaVu Sans", size: 16pt, fill: rgb("163e59"))
#show heading.where(level: 2): set text(font: "DejaVu Sans", size: 11pt, weight: "bold")
#show link: set text(fill: rgb("146c94"))
#set table(stroke: 0.4pt + rgb("d0d5dd"), inset: 6pt,
  fill: (x, y) => if y == 0 { rgb("e8eff5") } else if calc.odd(y) { rgb("f7f9fb") } else { none })

#text(font: "DejaVu Sans", size: 9pt, weight: "bold", fill: rgb("146c94"))[ENGINEERING REVIEW]
#v(4mm)
#text(font: "DejaVu Sans", size: 26pt, weight: "bold", fill: rgb("163e59"))[Raised-energy CFF stack]
#v(2mm)
#text(font: "DejaVu Sans", size: 12pt)[Functionality · Test contracts · Rust idioms · KISS]
#v(3mm)
#text(size: 9pt, fill: rgb("667085"))[11 September 2026 · Seven reviewed commits]
#v(4mm)
'''
if 'motivation' in source_path.stem or 'draft' in source_path.stem:
    header = header.replace('Raised-energy CFF stack review', 'Raised-energy CFF motivation audit')
    header = header.replace('Seven-commit reconstruction: correctness, Rust idioms, KISS and outward test contracts; current implementation and completed validation.', 'Current change motivations, controlled physical and representative benchmarks, reproduced defects, Rust patterns, KISS and coverage limits.')
    header = header.replace('Self-contained typesetting of raised-energy-cff-stack-review.md.', 'Self-contained typesetting of raised-energy-cff-motivation-audit.md.')
    header = header.replace('Raised-energy CFF stack]', 'CFF changes: evidence and cost]')
    header = header.replace('Functionality · Test contracts · Rust idioms · KISS', 'Physical benchmarks · Motivating bugs · Rust patterns · KISS')
    header = header.replace('Seven reviewed commits', '73 logical changes across seven commits')
    header = header.replace('Reconstructed stack review', 'Change motivation and benchmarks')
    header = header.replace('Current implementation review', 'Current motivation audit')
lines = source.splitlines()
blocks = [header]
i = 4
while i < len(lines):
    line = lines[i]
    if not line.strip():
        i += 1
        continue
    if line.startswith('## '):
        blocks.append('= ' + inline(line[3:]) + '\n')
        i += 1
        continue
    if line.startswith('| '):
        rows=[]
        while i < len(lines) and lines[i].startswith('| '):
            cells=[x.strip() for x in lines[i].strip('|').split('|')]
            if not all(re.fullmatch(r'[-: ]+', x) for x in cells):
                rows.append(cells)
            i += 1
        count=len(rows[0])
        widths = {2:'(0.35fr, 0.65fr)',3:'(0.42fr, 0.29fr, 0.29fr)',4:'(0.31fr, 0.23fr, 0.23fr, 0.23fr)',5:'(0.32fr, 0.17fr, 0.17fr, 0.17fr, 0.17fr)',6:'(0.26fr, 0.148fr, 0.148fr, 0.148fr, 0.148fr, 0.148fr)'}[count]
        if rows[0] == ['#', 'Commit', 'Scope']:
            widths = '(0.07fr, 0.21fr, 0.72fr)'
        cells=[]
        for row in rows[1:]:
            cells.extend('['+inline(c)+']' for c in row)
        table_header='table.header('+', '.join('['+inline(c)+']' for c in rows[0])+'),'
        blocks.append('#block[\n#set text(size: 8.6pt)\n#table(columns: '+widths+',\n'+table_header+'\n'+',\n'.join(cells)+',\n)\n]\n')
        continue
    para=[]
    while i < len(lines) and lines[i].strip() and not lines[i].startswith('## ') and not lines[i].startswith('| '):
        para.append(lines[i]);i+=1
    text=' '.join(para)
    rendered=inline(text)
    if text.startswith('**DRAFT'):
        rendered='#block(fill: rgb("fff4df"), stroke: 0.6pt + rgb("b7791f"), inset: 9pt)[\n'+rendered+'\n]'
    blocks.append(rendered+'\n')
source_path.with_suffix('.typ').write_text('\n'.join(blocks))
print('wrote self-contained Typst source')

"""Adapt one newly encountered exact integral literal; preserve the value oracle."""
from pathlib import Path
from decimal import Decimal
import hashlib,json,re,shutil
root=Path('/tmp/cff-change-audit');source=root/'contraction-benchmarks/gg-double-triangle/smallest-degree-warmup.result.json';out=source.with_name('smallest-degree-warmup.integral-literals.result.json')
value=json.loads(source.read_text());before='2.00000000000000';after='2';assert Decimal(before)==Decimal(after)
pattern=re.compile(r'(?<![\w.])2\.00000000000000(?![\d.eE])');count=0
texts=[('root',value)]+[(key,entry)for entry in value['aliases']for key in ['alias','original']]
for key,entry in texts:
 entry[key],n=pattern.subn(after,entry[key]);count+=n
assert count>0
out.write_text(json.dumps(value,indent=2)+'\n')
record={'original':str(source),'original_sha256':hashlib.file_digest(source.open('rb'),'sha256').hexdigest(),'normalized':str(out),'normalized_sha256':hashlib.file_digest(out.open('rb'),'sha256').hexdigest(),'conversion':{'from':before,'to':after,'exact_decimal_values_equal':True,'occurrences':count},'scope':'Only an exact integral output literal is normalized. Root, aliases, coefficients, terms and expected values otherwise unchanged. The original strict comparator remains byte-identical. Failure was its literal-domain guard before any value comparison; retain that failed setup receipt. No benchmark observation is rerun.'}
(root/'root/integral-output-normalization.json').write_text(json.dumps(record,indent=2)+'\n')
for p in [root/'contraction-benchmarks/complete-value-coverage.json',root/'contraction-benchmarks/gg-double-triangle-complete-values.log',root/'root/contraction-complete-values-driver.log']:
 shutil.copy2(p,p.with_name('setup-integral-literal-guard-'+p.name))
p=root/'root/validate_results.py';s=p.read_text()
s=s.replace("validation=[]", "normalization=json.loads((root/'root/integral-output-normalization.json').read_text())\nvalidation=[]")
s=s.replace("+[r['result']for r in by_hash.values()]", "+[normalization['normalized']if r['result_sha256']==normalization['original_sha256']else r['result']for r in by_hash.values()]")
s=s.replace("'unique_output_hashes':list(by_hash),", "'unique_output_hashes':list(by_hash),'exact_integral_literal_normalization':normalization if normalization['original_sha256']in by_hash else None,")
p.write_text(s)
print('Normalized exact integral literal',count,'times; unchanged comparator and original dump retained.')

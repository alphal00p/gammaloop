import json,pathlib,statistics,re,sys
manifest_path=pathlib.Path(sys.argv[1]);j=json.loads(manifest_path.read_text());groups={}
for run in j['runs']:
 if run['warmup']:continue
 groups.setdefault((run['fixture'],run['variant']),[]).append(run)
output=[]
for (fixture,variant),runs in groups.items():
 good=[r for r in runs if r['exit_code']==0];stats={}
 values={'wall_seconds':[r['wall_seconds'] for r in good],'max_rss_bytes':[r['max_rss_bytes'] for r in good]}
 for r in good:
  for row in r.get('stage_rows') or []:
   value=row[2]
   match=re.fullmatch(r'([0-9]+(?:\.[0-9]+)?)(ns|µs|μs|ms|s)',value)
   if match:
    scale={'ns':1e-9,'µs':1e-6,'μs':1e-6,'ms':1e-3,'s':1}[match.group(2)]
    values.setdefault(row[0]+'_seconds',[]).append(float(match.group(1))*scale)
 for metric,entries in values.items():
  if entries:stats[metric]={'n':len(entries),'median':statistics.median(entries),'mean':statistics.mean(entries),'min':min(entries),'max':max(entries),'sample_stddev':statistics.stdev(entries) if len(entries)>1 else None,'samples':entries}
 output.append({'fixture':fixture,'variant':variant,'successful_measured_runs':len(good),'failures':[{'round':r['round'],'exit_code':r['exit_code'],'log':r['log']} for r in runs if r['exit_code']],'statistics':stats,'distinct_output_hashes':sorted({r['result_sha256'] for r in good if r['result_sha256']})})
result={'manifest':str(manifest_path),'method':'Six balanced forward/reverse rounds following one excluded warmup per input/variant. Descriptive statistics, no universal performance or inferential-significance claim. Stage timers exclude parsing and result dumping where named; peak RSS is complete child process, including launcher inheritance/initialization/output.','groups':output,'failed_runs':[{'fixture':r['fixture'],'variant':r['variant'],'warmup':r['warmup'],'exit_code':r['exit_code'],'log':r['log']} for r in j['runs'] if r['exit_code']]}
p=manifest_path.with_name('analysis.json');p.write_text(json.dumps(result,indent=2)+'\n')
for row in output:
 stats=row['statistics'];stage=stats.get('network_execute_seconds',{});rss=stats.get('max_rss_bytes',{})
 print(row['fixture'],row['variant'],'n',row['successful_measured_runs'],'network_ms',round(stage.get('median',0)*1e3,4),'rss_MB',round(rss.get('median',0)/1e6,3))

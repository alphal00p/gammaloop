from pathlib import Path
import json,hashlib
root=Path('/tmp/cff-change-audit')
a=json.loads((root/'foundation-bugs/artifacts/foundation-inventory.json').read_text());b=json.loads((root/'nonfoundation-inventory.json').read_text())
changes=a['changes']+b['changes'];paths=a['paths']+b['paths']
conclusions=json.loads((root/'root/audit-conclusions.json').read_text())
for row in changes:
    row.pop('missing_action',None)
    row['audit_conclusion']=conclusions[row['id']]

assert len(changes)==73 and len(paths)==579 and len({x['path']for x in paths})==505
assert all(x['logical_changes']for x in paths)
result={'source_tip':a['source_tip'],'scope':'All seven reconstructed commits,73 logical categories,579 commit/path records,505 distinct paths. Categories are semantic groups, not a count of individual changed hunks.','evidence_policy':'Distinguish fresh execution, pinned-source counterexamples, requested capabilities, required consumer migrations and unproved performance necessity. Current-suite passes alone do not establish an old failure or speedup. See audit report for completed measurements and limits.','logical_change_count':len(changes),'commit_path_count':len(paths),'distinct_path_count':len({x['path']for x in paths}),'changes':changes,'paths':paths}
(root/'complete-inventory.json').write_text(json.dumps(result,indent=2)+'\n')
print('73 categories;579 commit/path records;505 unique paths; no unmapped paths')

"""Fixed native C3 executor replay for an exact, denominator-preserving common-factor extraction."""
from pathlib import Path
import fcntl,importlib.util,json,datetime
BASE=Path('/tmp/raised-energy-expression-perf-20260914')
OUT=Path('/tmp/raised-energy-causal-20260914/gl1-term16-factor-replay')
lock=(BASE/'measurement.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
spec=importlib.util.spec_from_file_location('measure',BASE/'measure.py');measure=importlib.util.module_from_spec(spec);spec.loader.exec_module(measure)
assert measure.digest(BASE/'measure.py')=='6f6ca7cbb51f5b606b93da4e00fe42465f3a194bc5efaf6e492df737cafad4d9'
recipe=json.loads((OUT/'recipe.json').read_text());assert measure.digest(recipe['proof'])==recipe['proof_sha256']
build=json.loads(Path(recipe['build_receipt']).read_text());assert build['status']=='PASS' and build['binary_sha256']==recipe['expected_binary_sha256']
assert measure.digest(build['binary'])==build['binary_sha256']
measure.PREFIX=BASE/'diagnostic-workspaces/c3';revision=build['revision'];assert measure.audit(revision)['passed']
for run in recipe['runs']:assert not Path(run['fresh_directory']).exists()
for run in recipe['runs']:
 out=Path(run['fresh_directory']);out.mkdir()
 record=dict(status='STARTED',label=run['label'],input=run['input'],binary_sha256=build['binary_sha256'],build_receipt=recipe['build_receipt'],build_receipt_sha256=measure.digest(recipe['build_receipt']),recipe_sha256=measure.digest(OUT/'recipe.json'),proof=recipe['proof'],proof_sha256=recipe['proof_sha256'],tracked_before=measure.audit(revision),started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
 measure.write(out/'receipt.json',record)
 try:
  assert record['tracked_before']['passed'] and measure.digest(run['input']['path'])==run['input']['sha256']
  env=dict(CARGO_TARGET_DIR='/common/dev/gammaloop/higher-power-energies-review/target',CARGO_BUILD_JOBS='4',RAYON_NUM_THREADS='8',RUST_MIN_STACK='134217728',INSTA_UPDATE='no',NEXTEST_RETRIES='0',GL_ALL_LOG_FILTER='off')
  command=['env','-u','GAMMALOOP_DUMP_EVALUATOR_PRE_NETWORK_PARSE','-u','GAMMALOOP_STOP_AFTER_EVALUATOR_PRE_NETWORK_PARSE','-u','SPENSO_NETWORK_PROFILE','-u','SPENSO_NETWORK_PROFILE_VERBOSE','-u','SPENSO_NETWORK_PROFILE_ATOM_BYTES',build['binary'],run['input']['path'],run['result']]
  result=measure.guarded(out,'runtime',command,env);record.update(status=result['status'],runtime=result)
  if result['status']=='PASS':record['output']={'path':run['result'],'sha256':measure.digest(run['result']),'bytes':Path(run['result']).stat().st_size}
 except BaseException as error:record.update(status='LAUNCH_OR_EVIDENCE_FAILURE',error=repr(error))
 finally:
  try:
   record['tracked_after']=measure.audit(revision);assert record['tracked_after']['passed']
   assert measure.digest(run['input']['path'])==run['input']['sha256'] and measure.digest(recipe['proof'])==recipe['proof_sha256'] and measure.digest(build['binary'])==build['binary_sha256']
  except BaseException as error:record.update(prior_status=record['status'],status='SOURCE_INTEGRITY_FAILURE',error=repr(error))
  record['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();measure.write(out/'receipt.json',record)
  print(json.dumps({'case':run['label'],'status':record['status'],'receipt':str(out/'receipt.json')}),flush=True)
 if record['status']!='PASS':raise SystemExit(1)

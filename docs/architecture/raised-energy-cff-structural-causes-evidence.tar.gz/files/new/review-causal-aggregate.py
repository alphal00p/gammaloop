"""Independent native-receipt/phase count review; no archive or scalar-output read."""
from pathlib import Path
from collections import Counter
import hashlib,json,re
B=Path('/tmp/raised-energy-causal-20260914');P=Path('/tmp/raised-energy-expression-perf-20260914');aggregate_path=B/'causal-results.json';a=json.loads(aggregate_path.read_text());hashes={}
# Native receipt objects and native log events are compared in full to aggregate copies.
replay_counts=Counter();comparison_counts=Counter();sparse_counts=Counter()
for row in a['factor_replays']:
 p=Path(row['receipt']['path']);receipt=json.loads(p.read_text());assert hashlib.sha256(p.read_bytes()).hexdigest()==row['receipt']['sha256']
 assert row['runtime']==receipt['runtime'] and row['output']==receipt['output']
 events=[json.loads(line) for line in (p.parent/'runtime/stdout.log').read_text().splitlines() if line.startswith('{')];assert row['events']==events
 replay_counts[receipt['status']]+=1
for row in a['complete_output_supplements']:
 p=Path(row['comparison']['path']);native=json.loads(p.read_text());assert hashlib.sha256(p.read_bytes()).hexdigest()==row['comparison']['sha256']
 receipt=json.loads(Path(row['receipt']['path']).read_text());assert receipt['status']=='PASS'
 for field in ['status','samples','exact_atom_equal','expansion_performed']:assert row[field]==native[field]
 assert len(row['samples'])==3 and all(x['status']=='NUMERICAL_AGREEMENT' and x['threshold']=='2^-128' and x['precision_bits']==256 for x in row['samples'])
 comparison_counts[native['status']]+=1
for row in a['sparse_controls']:
 native=json.loads(Path(row['receipt']['path']).read_text());assert row['stages']==native['stages'] and row['status']==native['status']
 sparse_counts.update(x['status'] for x in native['stages'])
series=json.loads(Path(a['relative_zero_reproducer']['receipt']['path']).read_text());cases=[s for s in series['stages'] if s['stage'] not in ['fmt','check','build','clippy','metadata']];assert cases==a['relative_zero_reproducer']['cases']
series_counts=Counter(s['status'] for s in cases)
phase_path=B/'c6-absolute-pole-order/run-01/phase-events.log';phase_counts=Counter(re.findall(r'\bphase=([A-Za-z_0-9]+)',phase_path.read_text()));assert dict(phase_counts)==a['c6_depth_only_control']['phase_counts']
assert json.loads((B/'c6-absolute-pole-order/run-01/receipt.json').read_text())['status']=='PASS'
main_path=B/'c6-absolute-pole-order/run-01/main-events.jsonl';main=[json.loads(line) for line in main_path.read_text().splitlines()];assert main==a['c6_depth_only_control']['main_events']
c7=json.loads(Path(a['c7_early_color_control']['result']['path']).read_text());assert c7['status']==a['c7_early_color_control']['status'] and c7['comparisons']==a['c7_early_color_control']['comparisons']
c7receipt=json.loads(Path(c7['run_receipt']).read_text());assert c7receipt['status']=='PASS_CAPTURE_EXPECTED_DIAGNOSTIC_STOP' and c7receipt['stages'][0]==c7['runtime']
observed=dict(factor_replay_processes=dict(replay_counts),complete_output_comparisons={**comparison_counts,'fixed_points_per_pair':3},sparse_profile_processes=dict(sparse_counts),minimal_series_cases=dict(series_counts),depth_only_batch=dict(completed_terms=phase_counts['evaluate_term_done'],completed_pole_queries=phase_counts['kernel_coefficient_pole_done'],completed_series_calls=phase_counts['epsilon_series_done']),c7_full_input_capture=dict(expected_stop_capture=1,raw_exit_code=c7receipt['stages'][0]['exit_code']))
assert observed==a['group_counts']
allow=json.loads((B/'causal-evidence-allowlist.json').read_text());roots={k:Path(v) for k,v in allow['roots'].items()};selected={str(roots[x['root']]/x['path']):x for x in allow['files']}
prior=json.loads(Path(allow['prior_archive']['manifest_path']).read_text());prior_members={str(P/x['path']):x for x in prior['files']}
refs={};mismatches=[];missing=[]
for entry in allow['files']:
 p=roots[entry['root']]/entry['path']
 if p.suffix!='.json' or not p.exists():continue
 todo=[json.loads(p.read_text())]
 while todo:
  v=todo.pop()
  if isinstance(v,list):todo.extend(v);continue
  if not isinstance(v,dict):continue
  todo.extend(q for q in v.values() if isinstance(q,(dict,list)));pairs=[]
  if isinstance(v.get('path'),str) and isinstance(v.get('sha256'),str):pairs.append((v['path'],v['sha256']))
  for k,value in v.items():
   if k.startswith('/') and isinstance(value,str):pairs.append((k,value))
   if k.endswith('_sha256') and isinstance(value,str) and isinstance(v.get(k[:-7]),str):pairs.append((v[k[:-7]],value))
  for path,sha in pairs:
   if not path.startswith('/') or not re.fullmatch('[0-9a-f]{64}',sha):continue
   key=(path,sha);refs.setdefault(key,[]).append(str(p))
for (path,sha),origins in refs.items():
 if path in selected:
  if path not in hashes:
   with Path(path).open('rb') as stream:hashes[path]=hashlib.file_digest(stream,'sha256').hexdigest()
  if hashes[path]!=sha:mismatches.append(dict(path=path,expected=sha,actual=hashes[path],origins=origins))
 elif path in prior_members and prior_members[path]['sha256']==sha:continue
 elif '/sources/' in path or '/diagnostic-workspaces/' in path or '/standalone/crates/' in path or '/target/' in path:continue
 elif Path(path).suffix not in ['.json','.jsonl','.md','.toml','.lock','.py','.rs','.log','.csv','.atom','.dot','.txt','.patch']:continue
 elif any(x in Path(path).name for x in ['-result.atom','result.atom','exact-dyadic-coefficients.atom','exact-integer-coefficients.atom','metadata']):continue
 elif path=='/tmp/raised-stack-latest-review-20260914/ram-watchdog-ps10.py':
  assert sha==hashlib.sha256((P/'diagnostics/watchdog/ram-watchdog-ps10.py').read_bytes()).hexdigest()
 else:missing.append(dict(path=path,sha256=sha,origins=sorted(set(origins))))
result=dict(status='PASS_NATIVE_AGGREGATE_COUNTS' if not mismatches else 'REFERENCE_HASH_MISMATCH',aggregate_sha256=hashlib.sha256(aggregate_path.read_bytes()).hexdigest(),builder_sha256=hashlib.sha256((B/'build-causal-results.py').read_bytes()).hexdigest(),observed_native_counts=observed,complete_native_objects_equal=True,all_depth_phase_counts_recounted_from_full_log=True,large_scalar_outputs_read=False,archive_created=False,unique_reference_pairs=len(refs),selected_references_hashed=len(hashes),reference_hash_mismatches=mismatches,missing_reference_paths=missing)
(B/'causal-aggregate-independent-review.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))

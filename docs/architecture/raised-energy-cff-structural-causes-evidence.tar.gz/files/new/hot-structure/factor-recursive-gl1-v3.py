"""Extract only complete factors common to every arm; denominator objects stay opaque."""
from pathlib import Path
from collections import Counter
import json,hashlib,gc,sys
base=Path('/tmp/raised-energy-expression-perf-20260914/upstream-expression-analysis')
ns={};exec((base/'extract-factor-witnesses.py').read_text().split('records=[]')[0],ns)
parse=ns['parse'];Node=ns['ns']['Node'];normalize_product=ns['normalize_product']
out=Path('/tmp/raised-energy-causal-20260914/hot-structure/gl1-recursive-common-factors-03');out.mkdir(exist_ok=True)
def product_node(factors):
    # Synthetic Inv nodes belong directly to a Mul; preserve that parser shape.
    factors=list(factors)
    if not factors or factors[0].kind=='inv':
        factors.insert(0,Node('leaf','1',[],'1'))
    if len(factors)==1:
        return factors[0]
    text='('+factors[0].text+')'
    for factor in factors[1:]:
        text+=('/('+factor.children[0].text+')') if factor.kind=='inv' else '*('+factor.text+')'
    return Node('mul','',factors,text)

for index in map(int,sys.argv[1:] or ['15','16']):
 source=base/f'c3-g_gl1-pre_network-000-terms/{index:03d}.atom';directory=out/f'term{index}';directory.mkdir(exist_ok=True)
 root=parse(source.read_text());counts=[];proofs=[];initial_digest=root.digest
 for pass_index in range(2):
  order=[];stack=[('root',root)]
  while stack:
   path,n=stack.pop();order.append((path,n))
   if n.kind in ['add','mul','neg']:
    stack.extend((f'{path}/{n.kind}[{i}]',c) for i,c in enumerate(n.children))
  replacement={};pass_proofs=[]
  for path,n in reversed(order):
   if n.kind not in ['add','mul','neg']:
    replacement[id(n)]=n;continue
   cs=[replacement[id(c)] for c in n.children]
   current=n
   if any(a is not b for a,b in zip(cs,n.children)):
    if n.kind=='mul':current=product_node(cs)
    else:
     text='+'.join('('+c.text+')' for c in cs) if n.kind=='add' else '-('+cs[0].text+')'
     current=Node(n.kind,n.name,cs,text)
   if n.kind!='add':replacement[id(n)]=current;continue
   branches=[]
   for c in cs:
    sign=1;fs=[];pending=[c]
    while pending:
     f=pending.pop()
     if f.kind=='neg':sign=-sign;pending.append(f.children[0])
     elif f.kind=='mul':pending.extend(reversed(f.children))
     elif f.kind=='leaf' and f.name=='1':pass
     else:fs.append(f)
    branches.append((sign,fs))
   common=Counter(f.digest for f in branches[0][1])
   for sign,fs in branches[1:]:common&=Counter(f.digest for f in fs)
   if not common:replacement[id(n)]=current;continue
   remaining_common=common.copy();G=[]
   for f in branches[0][1]:
    if remaining_common[f.digest]:G.append(f);remaining_common[f.digest]-=1
   remainders=[];branch_proofs=[]
   for sign,fs in branches:
    pending=common.copy();rest=[]
    for f in fs:
     if pending[f.digest]:pending[f.digest]-=1
     else:rest.append(f)
    assert not any(pending.values())
    assert common+Counter(f.digest for f in rest)==Counter(f.digest for f in fs)
    r=product_node(rest)
    if sign<0:r=Node('neg','',[r],'-('+r.text+')')
    actual_sign,actual_factors=normalize_product([r])
    assert actual_sign==sign and actual_factors==Counter(f.digest for f in rest)
    remainders.append(r);branch_proofs.append({'sign':sign,'original_complete_factor_multiset':dict(Counter(f.digest for f in fs)),'remainder_complete_factor_multiset':dict(actual_factors)})
   summed=Node('add','',remainders,'+'.join('('+r.text+')' for r in remainders))
   result=product_node(G+[summed])
   pass_proofs.append({'path':path,'before_sha256':hashlib.sha256(current.text.encode()).hexdigest(),'before_digest':current.digest,'after_sha256':hashlib.sha256(result.text.encode()).hexdigest(),'after_digest':result.digest,'before_utf8_bytes':len(current.text.encode()),'after_utf8_bytes':len(result.text.encode()),'common_factor_multiset':dict(common),'common_complete_factors':[{'digest':f.digest,'text':f.text,'tensor_bearing':f.tensor} for f in G],'branches':branch_proofs,'all_full_signed_factor_multisets_reassemble':True,'before_expression':current.text,'after_expression':result.text})
   replacement[id(n)]=result
  newroot=replacement[id(root)];counts.append(len(pass_proofs))
  print('TERM',index,'PASS',pass_index,'changes',len(pass_proofs),'bytes',len(newroot.text.encode()),flush=True)
  if pass_index==0:
   proofs=pass_proofs;root=newroot;first_digest=root.digest;first_text=root.text
  else:
   assert not pass_proofs and newroot.digest==first_digest and newroot.text==first_text
  del replacement,order,stack,branches
 with (directory/'local-factor-certificates.jsonl').open('w') as file:
  for p in proofs:file.write(json.dumps(p,ensure_ascii=False)+'\n')
 (directory/'original.atom').write_text(source.read_text());(directory/'factored.atom').write_text(root.text)
 reparsed=parse(root.text)
 if reparsed.digest!=root.digest:
  pending=[('root',root,reparsed)]
  while pending:
   where,left,right=pending.pop()
   if left.digest==right.digest:continue
   if left.kind!=right.kind or left.name!=right.name or len(left.children)!=len(right.children):
    print('FIRST_SERIALIZATION_DIFFERENCE',where,'LEFT',left.kind,left.name,len(left.children),'RIGHT',right.kind,right.name,len(right.children),'LTXT',left.text[:700],'RTXT',right.text[:700],flush=True);break
   pending.extend((f'{where}/{left.kind}[{j}]',lc,rc) for j,(lc,rc) in reversed(list(enumerate(zip(left.children,right.children)))))
 assert reparsed.digest==root.digest
 record={'source':ns['fingerprint'](source),'original':ns['fingerprint'](directory/'original.atom'),'factored':ns['fingerprint'](directory/'factored.atom'),'initial_ast_digest':initial_digest,'final_ast_digest':root.digest,'local_transformations':len(proofs),'common_factor_occurrences':sum(sum(p['common_factor_multiset'].values()) for p in proofs),'tensor_factor_occurrences':sum(f['tensor_bearing'] for p in proofs for f in p['common_complete_factors']),'second_pass_transformations':counts[1],'exact_fixed_point':True,'final_reparse_matches_ast':True,'proof_file':ns['fingerprint'](directory/'local-factor-certificates.jsonl'),'proof':'Bottom-up induction over Add/Mul/Neg: children preserve value; each changed Add extracts exactly the complete signed factor-multiset intersection shared by all arms. The complete before/after expressions and all factors are retained per operation. Mul/Neg only rebuild around proven-equivalent children. Fun/Pow/Inv nodes are opaque and unchanged. No numerator product is distributed; no absent denominator factor is inserted and no distinct denominator topologies are combined.','scope':'Exact within-C3 input rewrite, runtime effect and C1 full-forest equality not certified.'}
 (directory/'proof.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n');print(json.dumps(record),flush=True)
 del root,reparsed,proofs,pass_proofs,newroot;gc.collect()

from pathlib import Path
from collections import Counter
import hashlib,json
B=Path('/tmp/raised-energy-causal-20260914');O=B/'hot-structure'
prep=json.loads((O/'gl1-output-comparison-05/term16/preparation.json').read_text())
needles={}
for e in (3,5):
 qs=[f'gammalooprs::{{spenso::rank1,spenso::tensor}}::Q({e},spenso::{{}}::cind({i}))' for i in (1,2,3)]
 poly='('+'+'.join('('+q+')^2*-1' for q in qs)+')*-1+gammalooprs::{}::mUV^2'
 needles[f'D{e}']=poly.encode()
# These are intact scalar quadratic blocks already present in the output, not expanded diagnostics.
rows=[];longest=max(map(len,needles.values()))
for row in prep['rows']:
 counts=Counter();carry=b'';digest=hashlib.sha256();size=0;max_buffer=0
 with Path(row['original']['path']).open('rb') as source:
  while True:
   chunk=source.read(1024*1024);size+=len(chunk);digest.update(chunk);data=carry+chunk
   max_buffer=max(max_buffer,len(data));assert len(data)<=1024*1024+longest
   boundary=max(0,len(data)-longest+1) if chunk else len(data)
   for name,needle in needles.items():
    start=0
    while True:
     i=data.find(needle,start)
     if i<0 or i>=boundary:break
     counts[name]+=1;start=i+len(needle)
   carry=data[boundary:]
   if not chunk:break
 assert digest.hexdigest()==row['original']['sha256'] and size==row['original']['bytes']
 parts={k:sum(len(s.encode())*n for s,n in row[k].items()) for k in ['variables','concrete_components','scalar_functions','unicode_tokens']}
 parts['arithmetic_and_numeric_remainder']=size-sum(parts.values())
 rows.append(dict(label=row['label'],source=row['original'],exact_scalar_quadratic_block_occurrences=dict(counts),Q_component_occurrences=sum(row['concrete_components'].values()),exact_text_byte_partition=parts,maximum_buffer_bytes=max_buffer))
 print(json.dumps(rows[-1]),flush=True)
result=dict(status='PASS_BOUNDED_INTACT_SCALAR_BLOCK_INVENTORY',needles={k:v.decode() for k,v in needles.items()},rows=rows,interpretation='Component occurrences and unchanged scalar quadratic blocks quantify the extra fully resolved scalar text. Common coupling/tree-denominator factors can be better shared while kinematic scalar subexpressions are repeated more often; this diagnoses output growth without claiming end-to-end generation improvement or numerator expansion.')
(O/'gl1-term16-scalar-growth.json').write_text(json.dumps(result,indent=2)+'\n')

"""Read only factorized ASTs; infer free slot signatures without expansion."""
from pathlib import Path
from collections import Counter
import json, hashlib
b=Path('/tmp/raised-energy-expression-perf-20260914/upstream-expression-analysis')
out=Path('/tmp/raised-energy-causal-20260914/hot-structure')
ns={};exec((b/'analyze-captured-structure.py').read_text().split('records=[]')[0],ns)
selected=[('c3','orientation58',6),('c3','orientation58',7),('c3','orientation58',8),('c3','g_gl1',15),('c3','g_gl1',16),('c1','g_gl1',0)]+[('c1','orientation58',i) for i in range(14)]
results=[]
for rev,w,i in selected:
 label=f'{rev}-{w}-pre_network-000-terms/{i:03d}.atom';p=b/label
 print('START',label,flush=True)
 n=ns['parse'](p.read_text()); walked=list(ns['walk'](n)); info={}; mismatches=[]
 for path,x in reversed(walked):
  cs=[info[id(c)] for c in x.children]
  if x.kind=='fun' and x.name in ['spenso::mink','spenso::bis','spenso::adj','spenso::fund']:
   sig=(x.text,)
  elif x.kind=='add':
   sig=cs[0]['slots']
   if any(c['slots']!=sig for c in cs):mismatches.append({'path':path,'children':[c['slots'] for c in cs]})
  else:
   ct=Counter(s for c in cs for s in c['slots']);sig=tuple(sorted(s for s,k in ct.items() if k%2))
  td=(x.kind=='add' and bool(sig))+max((c['tensor_add_depth'] for c in cs),default=0)
  info[id(x)]={'slots':sig,'rank':len(sig),'tensor_add_depth':td}
 adds=[]
 for path,x in walked:
  sig=info[id(x)]
  if x.kind!='add' or not sig['rank']:continue
  ct=Counter(f.digest for f in ns['factors'](x.children[0]))
  for c in x.children[1:]:ct&=Counter(f.digest for f in ns['factors'](c))
  common=[{'text':f.text,'slots':info[id(f)]['slots']} for f in ns['factors'](x.children[0]) if ct[f.digest] and info[id(f)]['rank']]
  adds.append({'path':path,'utf8_bytes':len(x.text.encode()),'summands':len(x.children),**sig,'common_tensor_factors':common})
 rootfs=ns['factors'](n)
 r={'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'root':info[id(n)],'slot_disagreement_count':len(mismatches),'slot_disagreements':mismatches[:20], 'tensor_add_count':len(adds),'tensor_add_ranks':dict(Counter(a['rank'] for a in adds)),'tensor_add_depth':info[id(n)]['tensor_add_depth'],'root_factors':[{'index':j,'kind':x.kind,'name':x.name,'bytes':len(x.text.encode()),**info[id(x)],'text':x.text if len(x.text)<180 else None} for j,x in enumerate(rootfs)], 'tensor_adds':sorted(adds,key=lambda a:a['utf8_bytes'],reverse=True)}
 results.append(r)
 print(json.dumps({k:v for k,v in r.items() if k not in ['tensor_adds','slot_disagreements','root_factors']}),flush=True)
 print('ROOT_FACTORS',json.dumps(r['root_factors']),flush=True)
 (out/'connectivity.json').write_text(json.dumps(results,indent=2)+'\n')
 del n,walked,info,adds,rootfs,r

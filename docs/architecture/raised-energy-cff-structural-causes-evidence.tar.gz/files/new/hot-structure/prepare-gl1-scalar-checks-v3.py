"""Bounded lexical preparation, reusing the prior streaming inventory and oracle."""
from collections import Counter
from fractions import Fraction
import hashlib
import json
from pathlib import Path
import re
import shutil

BASE = Path('/tmp/raised-energy-causal-20260914')
OUT = BASE / 'hot-structure/gl1-output-comparison-03'
OUT.mkdir(exist_ok=False)
ORACLE = BASE / 'metric-output-comparison'
OLD = Path('/tmp/raised-energy-expression-perf-20260914/diagnostics/common-factor-output-comparison')
assert (ORACLE / 'src/main.rs').read_bytes() == (OLD / 'src/main.rs').read_bytes()
name = rb'[A-Za-z_][A-Za-z_0-9]*(?:::\{[^{}]*\}::[A-Za-z_][A-Za-z_0-9]*)?'
names = re.compile(name)
component = re.compile(rb'gammalooprs::\{spenso::rank1,spenso::tensor\}::Q\(-?\d+,spenso::\{\}::cind\([0-3]\)\)')
simple_function = re.compile(name + rb'\([^()]{0,256}\)')
decimal = re.compile(rb'[+-]?[0-9]+[.][0-9]+(?:[eE][+-]?[0-9]+)?(?:`[0-9.]+)?')
all_rows = []
for term in (15, 16):
    target = OUT / f'term{term}'
    (target / 'src').mkdir(parents=True)
    rows = []
    for label in ('original', 'factored'):
        receipt_path = BASE / f'gl1-term{term}-factor-replay/run-{label}-01/receipt.json'
        receipt = json.loads(receipt_path.read_text())
        assert receipt['status'] == 'PASS' and receipt['tracked_before']['passed'] and receipt['tracked_after']['passed']
        assert hashlib.file_digest(Path(receipt['input']['path']).open('rb'), 'sha256').hexdigest() == receipt['input']['sha256']
        assert hashlib.file_digest(Path(receipt['proof']).open('rb'), 'sha256').hexdigest() == receipt['proof_sha256']
        stages = [json.loads(x) for x in (receipt_path.parent / 'runtime/stdout.log').read_text().splitlines()]
        assert any(x['stage'] == 'resolve_aliases' for x in stages)
        assert any(x.get('status') == 'PASS_CONTRACTION_ONLY' for x in stages)
        variables, functions, components, scalar_functions, unicode_tokens, decimals = (Counter() for _ in range(6))
        replacements = {}
        source = receipt['output']
        destination = target / f'{label}-exact-dyadic-coefficients.atom'
        digest, new_digest, total, new_total, carry, max_buffer = hashlib.sha256(), hashlib.sha256(), 0, 0, b'', 0
        with Path(source['path']).open('rb') as stream, destination.open('xb') as normalized:
            while True:
                chunk = stream.read(1024 * 1024)
                digest.update(chunk)
                total += len(chunk)
                data = carry + chunk
                max_buffer = max(max_buffer, len(data))
                assert len(data) <= 1024 * 1024 + 8192, 'Unbounded lexical carry'
                boundary = data.rfind(b'*') + 1 if chunk else len(data)
                assert boundary or not chunk, 'No safe scalar-expression boundary'
                prefix, carry = data[:boundary], data[boundary:]
                unicode_tokens.update(m.decode('utf-8') for m in re.findall(rb'[\x80-\xff]+', prefix))
                for match in names.finditer(prefix):
                    target_counter = functions if prefix[match.end():match.end()+1] == b'(' else variables
                    target_counter[match[0].decode()] += 1
                components.update(m[0].decode() for m in component.finditer(prefix))
                scalar_functions.update(m[0].decode() for m in simple_function.finditer(prefix) if not m[0].startswith(b'spenso::{}::cind('))
                for match in decimal.finditer(prefix):
                    token = match[0]
                    assert len(token) <= 512
                    decimals[token.decode()] += 1
                    if token not in replacements:
                        value = Fraction(token.decode().split('`')[0])
                        assert value.denominator & (value.denominator - 1) == 0, ('Non-dyadic decimal, stop without weakening oracle', token)
                        if value.denominator == 1:
                            sign = token[:1] if token.startswith((b'+', b'-')) else b''
                            replacements[token] = sign + str(abs(value.numerator)).encode()
                        else:
                            assert prefix[match.end():match.end()+1] != '𝑖'.encode()[:1], ('Imaginary fractional coefficient needs complete-token conversion', token)
                            sign = token[:1].decode() if token.startswith((b'+', b'-')) else ''
                            replacements[token] = f'{sign}({abs(value.numerator)}/{value.denominator})'.encode()
                for token, replacement in replacements.items():
                    sign = token[:1] if token.startswith((b'+', b'-')) else b''
                    assert replacement.startswith(sign)
                    assert Fraction(replacement.decode().replace('(', '').replace(')', '')) == Fraction(token.decode().split('`')[0])
                new = decimal.sub(lambda match: replacements[match[0]], prefix)
                normalized.write(new)
                new_digest.update(new)
                new_total += len(new)
                if not chunk:
                    break
        assert digest.hexdigest() == source['sha256'] and total == source['bytes']
        assert functions.pop('gammalooprs::{spenso::rank1,spenso::tensor}::Q', 0) == sum(components.values())
        assert functions.pop('spenso::{}::cind', 0) == sum(components.values())
        scalar_name_counts = Counter()
        for application, count in scalar_functions.items():
            scalar_name_counts[application.split('(')[0]] += count
        assert scalar_name_counts == functions, ('Incomplete function capture', scalar_name_counts, functions)
        assert set(unicode_tokens) <= {'𝑖', '𝜋'}, unicode_tokens
        assert all('::{' in leaf for leaf in variables), variables
        assert not any('spenso::' in leaf for leaf in scalar_functions), scalar_functions
        generic = sorted(set(variables) | set(components) | set(scalar_functions))
        rows.append(dict(label=label, receipt=str(receipt_path), receipt_sha256=hashlib.sha256(receipt_path.read_bytes()).hexdigest(), original=source, path=str(destination), sha256=new_digest.hexdigest(), bytes=new_total, maximum_buffer_bytes=max_buffer, variables=dict(sorted(variables.items())), scalar_functions=dict(sorted(scalar_functions.items())), concrete_components=dict(sorted(components.items())), unicode_tokens=dict(sorted(unicode_tokens.items())), exact_dyadic_decimal_tokens=dict(sorted(decimals.items())), exact_token_substitutions={k.decode():v.decode() for k,v in sorted(replacements.items())}, generic_leaves=generic))
        print(json.dumps(dict(term=term, label=label, status='PREPARED', original_bytes=total, normalized_bytes=new_total, leaves=len(generic), decimal_tokens=sum(decimals.values()), maximum_buffer_bytes=max_buffer)), flush=True)
    context = dict(precision_bits=256, relative_threshold='2^-128', generic_leaves=sorted(set(rows[0]['generic_leaves']) | set(rows[1]['generic_leaves'])), fixed_leaves={}, native_constants=['𝑖','𝜋'], inputs=[{k:r[k] for k in ('path','sha256','bytes')} for r in rows], interpretation='Complete closed GL1 scalar outputs. Every complete scalar function application, including selectors and tree denominators, is an independent formal leaf. The same deterministic 256-bit oracle and 2^-128 threshold are unchanged; points are supplementary algebraic checks, not physical kinematics. Exact dyadic-valued decimal coefficient notation only; no numerator expansion.')
    (target / 'scalar-context.json').write_text(json.dumps(context, indent=2)+'\n')
    shutil.copyfile(ORACLE / 'src/main.rs', target / 'src/main.rs')
    for filename in ('Cargo.toml', 'Cargo.lock'):
        (target / filename).write_text((ORACLE / filename).read_text().replace('cff-metric-output-comparison', f'cff-gl1-term{term}-output-comparison'))
    preparation = dict(status='READY_NOT_EXECUTED', term=term, rows=rows, pair_leaf_sets_equal=rows[0]['generic_leaves']==rows[1]['generic_leaves'], source_oracle=str(ORACLE/'src/main.rs'), source_oracle_sha256=hashlib.sha256((ORACLE/'src/main.rs').read_bytes()).hexdigest(), old_oracle_byte_identical=True, coefficient_signs_preserved=True, normalization='Only complete exact dyadic-valued decimal coefficient tokens are rewritten to exact integer or rational notation; every denominator is proven a power of two. Fractions.Fraction proves every replacement value exactly; each explicit leading sign is retained outside any fraction parentheses, and all remaining byte subsequences are passed through unchanged. One MiB streaming reads, safe multiplication boundaries, bounded carry.', oracle='Unchanged source, three predetermined nonsingular points at 256 bits, unchanged threshold 2^-128. The checker validates the complete native scalar-leaf set against this streaming allowlist before evaluation.')
    (target / 'preparation.json').write_text(json.dumps(preparation, indent=2)+'\n')
    runner = (ORACLE/'run.py').read_text().replace(str(ORACLE), str(target)).replace('cff-metric-output-comparison', f'cff-gl1-term{term}-output-comparison')
    (target / 'run.py').write_text(runner)
    all_rows.append(dict(term=term, path=str(target), input_bytes=[r['bytes'] for r in rows], scalar_leaves=len(context['generic_leaves']), preparation_sha256=hashlib.sha256((target/'preparation.json').read_bytes()).hexdigest()))
(OUT/'preparation-index.json').write_text(json.dumps(dict(status='READY_NOT_EXECUTED',rows=all_rows),indent=2)+'\n')

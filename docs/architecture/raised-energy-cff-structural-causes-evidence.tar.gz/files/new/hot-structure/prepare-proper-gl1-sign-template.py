from pathlib import Path
from collections import Counter
import hashlib,json,re,itertools
B=Path('/tmp/raised-energy-expression-perf-20260914/upstream-expression-analysis')
CAP=Path('/tmp/raised-energy-causal-20260914/uv-boundaries/attempts/c3/run-g_gl1-01')
OUT=Path('/tmp/raised-energy-causal-20260914/hot-structure/gl1-proper-uv-sign-template-01');OUT.mkdir(exist_ok=False)
ns={};exec((B/'analyze-captured-structure.py').read_text().split('records=[]')[0],ns);parse=ns['parse']
source=Path('/tmp/raised-energy-causal-20260914/hot-structure/build-gl1-sign-template.py').read_text()
exec('def factor_key('+source.split('def factor_key(',1)[1].split('vector_templates=[]',1)[0])
map_path=CAP/'numerator-map-records.json';caller_path=CAP/'taylor-caller-records.json';owner_path=CAP/'owner-index.json'
all_maps=json.loads(map_path.read_text());all_callers=json.loads(caller_path.read_text());owners=json.loads(owner_path.read_text())
rows=[next(r for r in all_maps if r['_line']==484+11*k) for k in range(18)]
callers=[next(r for r in all_callers if r['_line']==483+11*k) for k in range(18)]
original=rows[0]['unmapped_numerator'];assert all(r['unmapped_numerator']==original for r in rows)
root=parse(original);replacements={}
for _,node in ns['walk'](root):
 if node.kind=='fun' and node.name=='gammalooprs::Q' and node.children[0].text in ['2','3','4','5','6']:
  e=node.children[0].text;index=node.children[1].text
  replacements[node.text]='('+node.text.replace('gammalooprs::Q(', 'gammalooprs::Q3(',1)+f'+spenso::δ(spenso::cind(0),{index})*gammalooprs::σ({e})*gammalooprs::OSE({e}))'
assert len(replacements)==7
template=original
for old,new in replacements.items():template=template.replace(old,new)
(OUT/'unmapped-complete-numerator.atom').write_text(original)
(OUT/'parametric-complete-numerator.atom').write_text(template)
certified=[];old_branches=[];scalar_branches=[]
for k,(row,caller) in enumerate(zip(rows,callers)):
 assert row['selector_id']==caller['residue_map_key']==k
 assert caller['current']=='subgraph=140, topo_order=0, dod=2' and caller['given']=='subgraph=0, topo_order=0, dod=0'
 assert caller['active_subgraph']=='Some("140")' and caller['reduced']=='140'
 assert caller['loop_edges']=='{LoopIndex(0): EdgeIndex(3), LoopIndex(1): EdgeIndex(5)}'
 assert not row['source_map_used'] and row['source_edge_energy_map']==caller['source_edge_energy_map']=='None'
 pairs=re.findall(r'\(EdgeIndex\((\d+)\), Fraction \{ numerator: (-?\d+), denominator: (\d+) \}\)',row['effective_edge_energy_map'])
 assert [int(e) for e,s,d in pairs]==list(range(2,7)) and all(d=='1' and s in ['1','-1'] for e,s,d in pairs)
 signs=[int(s) for e,s,d in pairs]
 parts=[]
 for e in range(7):
  internal='[]' if e<2 else f'[(EdgeIndex({e}), Fraction {{ numerator: {signs[e-2]}, denominator: 1 }})]'
  parts.append('LinearEnergyExpr { internal_terms: '+internal+', external_terms: [], uniform_scale_coeff: Fraction { numerator: 0, denominator: 1 }, constant: Fraction { numerator: 0, denominator: 1 } }')
 assert row['effective_edge_energy_map']=='['+', '.join(parts)+']'
 assert row['physical_orientation']=='EdgeVec([Undirected, Undirected, '+', '.join('Default' if s==1 else 'Reversed' for s in signs)+'])'
 specialized=template
 for e,s in zip(range(2,7),signs):specialized=specialized.replace(f'gammalooprs::σ({e})',f'({s})')
 before_key=factor_key(parse(row['mapped_numerator']));after_key=factor_key(parse(specialized))
 assert before_key==after_key,(k,before_key,after_key)
 raw_weight=caller['integrand'];weight=raw_weight
 for old,new in [('Q','gammalooprs::Q'),('OSE','gammalooprs::OSE'),('tree_denoms','gammalooprs::tree_denoms'),('cind','spenso::cind')]:
  weight=re.sub(r'(?<![\w:])'+old+r'(?=\()',new,weight)
 assert set(re.findall(r'(?<![\w:])([A-Za-z_][\w:]*)\(',raw_weight))<={'Q','OSE','tree_denoms','cind'}
 selector=f'three_dimensional_reps::sigma({k})'
 old_branch=f'({selector})*({weight})*({row["mapped_numerator"]})'
 scalar_branch=f'({selector})*({weight})'
 assert factor_key(parse(old_branch))==factor_key(parse(f'({scalar_branch})*({specialized})'))
 files={}
 for label,text in [('mapped-complete-numerator',row['mapped_numerator']),('scalar-weight-as-recorded',raw_weight),('scalar-weight-qualified',weight),('complete-branch',old_branch),('specialized-template',specialized)]:
  p=OUT/f'branch-{k:02d}-{label}.atom';p.write_text(text);files[label]=dict(path=str(p),sha256=hashlib.sha256(text.encode()).hexdigest(),utf8_bytes=len(text.encode()))
 certified.append(dict(selector_id=k,signs_edges2_through6=signs,caller_log_line=caller['_line'],map_log_line=row['_line'],logfile=row['_logfile'],complete_numerator_specialization_equal=True,complete_signed_factor_key=before_key,complete_weight_retained=True,files=files))
 old_branches.append(old_branch);scalar_branches.append(scalar_branch)
old=' + '.join('('+x+')' for x in old_branches);shared=f'({template})*('+'+'.join('('+x+')' for x in scalar_branches)+')'
(OUT/'complete-recorded-pre-taylor-family.atom').write_text(old);(OUT/'shared-parametric-pre-taylor-family.atom').write_text(shared)
truth=[]
for signs in itertools.product([-1,1],repeat=5):
 selected=[r['selector_id'] for r in certified if tuple(r['signs_edges2_through6'])==signs]
 assert len(selected)<=1
 truth.append(dict(signs_edges2_through6=signs,selected_selector_ids=selected,complete_family_identity=True))
owner=next(r for r in owners if r['node_index']=='3' and 'orientation_parametric_atom' in r)
assert owner['source']=='140' and owner['forest_term']=='{140}'
proof=dict(status='PASS_EXACT_PRE_TAYLOR_FAMILY_TEMPLATE',boundary='Complete actual source140 proper-UV Taylor-entry family. This certifies the numerator-mapping boundary before Taylor differentiation; it is not a factorization of the post-Taylor hot15/16 coefficients.',sources={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [map_path,caller_path,owner_path]},owner=owner,common_unmapped_numerator_byte_exact_across18=True,source_edge_map='None',effective_maps='Exactly diagonal ±OSE(2..6), with zero external/uniform/constant terms and zero maps for external edges0,1.',replacement_rules=replacements,template=dict(path=str(OUT/'parametric-complete-numerator.atom'),sha256=hashlib.sha256(template.encode()).hexdigest(),utf8_bytes=len(template.encode())),recorded_family=dict(path=str(OUT/'complete-recorded-pre-taylor-family.atom'),sha256=hashlib.sha256(old.encode()).hexdigest(),utf8_bytes=len(old.encode())),shared_family=dict(path=str(OUT/'shared-parametric-pre-taylor-family.atom'),sha256=hashlib.sha256(shared.encode()).hexdigest(),utf8_bytes=len(shared.encode())),all18_complete_numerator_specializations_pass=True,all18_complete_scalar_weights_retained=True,all32_sign_rows_pass=True,normalization='Only existing factor_key product association, unit factors, signs and Add/Mul ordering. Source vector/vertex sums remain factors. Recorded scalar weights receive only explicit namespace qualification; all coefficients and denominator structures are preserved.',identity='Under the recorded selector truth table, exactly one branch is active on each of18 supported sign rows and none on14 unsupported rows. The shared numerator specializes to the whole native mapped numerator for that branch; its unchanged full scalar weight gives the same complete family value. No graph numerator is distributed.',branches=certified,truth_table=truth)
(OUT/'proof.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in proof.items() if k in ['status','boundary','template','recorded_family','shared_family']}),flush=True)

"""Verify certificates against original AST paths; avoid ambiguous global text locators."""
from pathlib import Path
from collections import Counter
import json,hashlib,gc
base=Path('/tmp/raised-energy-expression-perf-20260914/upstream-expression-analysis');ns={};exec((base/'analyze-captured-structure.py').read_text().split('records=[]')[0],ns);Node=ns['Node'];parse=ns['parse']
parent=Path('/tmp/raised-energy-causal-20260914/hot-structure/gl1-recursive-common-factors-04')
for index in [15,16]:
 directory=parent/f'term{index}';proof=json.loads((directory/'proof.json').read_text());certificates={p['path']:p for p in map(json.loads,(directory/'local-factor-certificates.jsonl').open())}
 original=parse((directory/'original.atom').read_text());assert original.digest==proof['initial_ast_digest'];order=[];pending=[('root',original)]
 while pending:
  path,node=pending.pop();order.append((path,node))
  if node.kind in ['add','mul','neg']:pending.extend((f'{path}/{node.kind}[{j}]',c) for j,c in enumerate(node.children))
 verified={};used=set();branch_count=0
 for path,node in reversed(order):
  if node.kind not in ['add','mul','neg']:
   assert path not in certificates;verified[id(node)]=node;continue
  children=[verified[id(c)] for c in node.children];current=Node(node.kind,node.name,children,'')
  if path not in certificates:verified[id(node)]=current;continue
  cert=certificates[path];assert current.kind=='add' and current.digest==cert['before_digest']
  for label in ['before','after']:assert hashlib.sha256(cert[label+'_expression'].encode()).hexdigest()==cert[label+'_sha256']
  common=Counter(cert['common_factor_multiset']);assert Counter(f['digest'] for f in cert['common_complete_factors'])==common
  kept_common=[];remainders=[]
  for arm_index,arm in enumerate(children):
   sign=1;factors=[];stack=[arm]
   while stack:
    f=stack.pop()
    if f.kind=='neg':sign=-sign;stack.append(f.children[0])
    elif f.kind=='mul':stack.extend(reversed(f.children))
    elif f.kind=='leaf' and f.name=='1':pass
    else:factors.append(f)
   row=cert['branches'][arm_index];assert sign==row['sign'] and Counter(f.digest for f in factors)==Counter(row['original_complete_factor_multiset'])
   todo=common.copy();rest=[]
   for f in factors:
    if todo[f.digest]:
     todo[f.digest]-=1
     if arm_index==0:kept_common.append(f)
    else:rest.append(f)
   assert not any(todo.values()) and Counter(f.digest for f in rest)==Counter(row['remainder_complete_factor_multiset'])
   if not rest or rest[0].kind=='inv':rest.insert(0,Node('leaf','1',[],'1'))
   r=rest[0] if len(rest)==1 else Node('mul','',rest,'')
   if sign<0:r=Node('neg','',[r],'')
   remainders.append(r);branch_count+=1
  assert len(remainders)==len(cert['branches'])
  output_factors=kept_common+[Node('add','',remainders,'')]
  if output_factors[0].kind=='inv':output_factors.insert(0,Node('leaf','1',[],'1'))
  result=Node('mul','',output_factors,'');assert result.digest==cert['after_digest'];verified[id(node)]=result;used.add(path)
 reconstructed=verified[id(original)];target=parse((directory/'factored.atom').read_text())
 assert used==set(certificates) and reconstructed.digest==target.digest==proof['final_ast_digest']
 record={'original_sha256':proof['original']['sha256'],'factored_sha256':proof['factored']['sha256'],'certificates_checked':len(used),'complete_branch_multisets_checked':branch_count,'all_certificates_bound_to_exact_original_ast_path':True,'all_transformed_child_contexts_match_certified_before_digest':True,'all_common_factors_removed_with_exact_sign_and_multiplicity':True,'all_reconstructed_results_match_certified_after_digest':True,'complete_reconstructed_final_ast_matches_frozen_factored_input':True,'opaque_fun_pow_inv_subtrees_unchanged':True,'proof_method':'Structural induction on original Add/Mul/Neg nodes, with complete frozen opaque Fun/Pow/Inv nodes. Verify each certified multiset subtraction from the actual transformed children, then bind the resulting whole AST to the frozen alternative. This handles duplicated factors without ambiguous global string substitutions.'}
 (directory/'independent-tree-proof.json').write_text(json.dumps(record,indent=2)+'\n');print(index,json.dumps(record),flush=True)
 del original,target,reconstructed,verified,order,certificates;gc.collect()

from pathlib import Path
from collections import Counter
import hashlib,json,re
B=Path('/tmp/raised-energy-expression-perf-20260914/upstream-expression-analysis')
N=Path('/tmp/raised-energy-causal-20260914/uv-boundaries/attempts/c3/run-orientation58-01')
OUT=Path('/tmp/raised-energy-causal-20260914/hot-structure')
ns={};exec((B/'analyze-captured-structure.py').read_text().split('records=[]')[0],ns)
index_path=N/'owner-index.json'; index=json.loads(index_path.read_text())
prior={p.read_text():p for p in sorted((B/'c3-orientation58-pre_network-000-terms').glob('*.atom'))}
rows=[];seen=[]
before_store={r['node_index']:r for r in index if r['stage']=='hedge_poset_final_node_before_store'}
for record in index:
 if 'orientation_parametric_atom' not in record:continue
 artifact=record['orientation_parametric_atom'];p=Path(artifact['path']);s=p.read_text()
 assert hashlib.sha256(s.encode()).hexdigest()==artifact['sha256']
 root=ns['parse'](s);children=root.children if root.kind=='add' else [root]
 matches=[]
 for child in children:
  if child.text=='0':continue
  assert child.text in prior, record['node_index']
  old=prior[child.text]; seen.append(str(old))
  matches.append(dict(path=str(old),sha256=hashlib.sha256(child.text.encode()).hexdigest(),utf8_bytes=len(child.text.encode()),byte_exact=True))
 stored=before_store[record['node_index']]
 assert all(stored[k]==record[k] for k in ['source','forest_term','cover','operation_count','source_loop_edges','residue_index'])
 merged={**stored,**record}
 owner={k:merged[k] for k in ['node_index','source','forest_term','cover','order','operation_count','source_loop_edges','residue_index']}
 owner['semantic_cutset']=re.sub(r'addr: 0x[0-9a-fA-F]+','addr: <runtime-address>',record['cutset'])
 rows.append(dict(owner=owner,artifact=artifact,root_kind=root.kind,existing_top_level_add_arms=len(children) if root.kind=='add' else 0,matches=matches,logfile=record['_logfile'],log_line=record['_line']))
assert Counter(seen)==Counter(str(p) for p in prior.values())
old_path=B/'c3-orientation58-pre_network-000.atom';new_path=N/'pre-network.atom'
old=old_path.read_text();new=new_path.read_text()
oldroot=ns['parse'](old);newroot=ns['parse'](new)
assert oldroot.kind==newroot.kind=='add'
oldterms=Counter(c.text for c in oldroot.children);newterms=Counter(c.text for c in newroot.children)
assert oldterms==newterms
result=dict(status='PASS_COMPLETE_BYTE_EXACT_OWNER_JOIN',owner_index=str(index_path),owner_index_sha256=hashlib.sha256(index_path.read_bytes()).hexdigest(),all_prior_terms_joined_once=True,prior_term_count=len(prior),owner_count=len(rows),whole_pre_network=dict(old_path=str(old_path),new_path=str(new_path),old_sha256=hashlib.sha256(old.encode()).hexdigest(),new_sha256=hashlib.sha256(new.encode()).hexdigest(),byte_exact=old==new,existing_top_level_term_multisets_byte_exact=True,old_utf8_bytes=len(old.encode()),new_utf8_bytes=len(new.encode()),terms=len(newroot.children)),transformation='Split only existing top-level Add nodes; every complete arm is byte-identical to a prior captured term. No algebra, numerator expansion, slot relabeling, or namespace normalization. Runtime addresses removed only from semantic owner metadata.',rows=rows)
(OUT/'c3-attachment-complete-owner-join.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='rows'},indent=2))

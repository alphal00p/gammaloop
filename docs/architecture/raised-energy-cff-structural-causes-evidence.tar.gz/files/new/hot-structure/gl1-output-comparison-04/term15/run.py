from pathlib import Path
import fcntl,importlib.util,json,datetime,shutil
BASE=Path('/tmp/raised-energy-expression-perf-20260914')
OUT=Path('/tmp/raised-energy-causal-20260914/hot-structure/gl1-output-comparison-04/term15')
ROOT=Path('/common/dev/gammaloop/higher-power-energies-review')
lock=(BASE/'measurement.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
spec=importlib.util.spec_from_file_location('measure',BASE/'measure.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
assert m.digest(BASE/'measure.py')=='6f6ca7cbb51f5b606b93da4e00fe42465f3a194bc5efaf6e492df737cafad4d9'
m.PREFIX=BASE/'diagnostic-workspaces/c3';rev=next(x for x in json.loads((BASE/'revisions.json').read_text()) if x['label']=='c3')
pins={str(p):m.digest(p) for p in [OUT/'Cargo.toml',OUT/'Cargo.lock',OUT/'src/main.rs',OUT/'scalar-context.json',OUT/'preparation.json']}
context=json.loads((OUT/'scalar-context.json').read_text())
for r in context['inputs']:pins[r['path']]=r['sha256'];assert m.digest(r['path'])==r['sha256']
assert m.digest(OUT/'src/main.rs')==m.digest(BASE/'diagnostics/common-factor-output-comparison/src/main.rs')
out=OUT/'run-01';out.mkdir()
r=dict(status='STARTED',pins=pins,tracked_before=m.audit(rev),stages=[],started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());assert r['tracked_before']['passed'];m.write(out/'receipt.json',r)
env=dict(CARGO_TARGET_DIR=str(ROOT/'target'),CARGO_BUILD_JOBS='4',RAYON_NUM_THREADS='8',RUST_MIN_STACK='134217728',INSTA_UPDATE='no',NEXTEST_RETRIES='0',GL_ALL_LOG_FILTER='off')
manifest=str(OUT/'Cargo.toml')
commands=[('metadata',['cargo','metadata','--offline','--locked','--format-version','1','--manifest-path',manifest]),('fmt',['cargo','fmt','--manifest-path',manifest,'--check'])]+[(x,['cargo',x,'--offline','--locked','--manifest-path',manifest,'--profile','dev-optim','-j','4']) for x in ['check','build','clippy']]
try:
 for name,command in commands:
  result=m.guarded(out,name,command,env);r['stages'].append(dict(stage=name,**result));m.write(out/'receipt.json',r)
  if result['status']!='PASS':raise RuntimeError(name+':'+result['status'])
 binary=out/'cff-gl1-term15-output-comparison';shutil.copy2(ROOT/'target/dev-optim'/binary.name,binary);r.update(binary=str(binary),binary_sha256=m.digest(binary))
 result=m.guarded(out,'runtime',[str(binary),str(out/'comparison.json')],env);r['stages'].append(dict(stage='runtime',**result));assert result['status']=='PASS'
 comparison=json.loads((out/'comparison.json').read_text());r.update(status='PASS',comparison_status=comparison['status'],comparison_sha256=m.digest(out/'comparison.json'))
except BaseException as e:r.update(status='FAILURE',error=repr(e))
finally:
 r['tracked_after']=m.audit(rev)
 assert r['tracked_after']['passed']
 for path,sha in pins.items():assert m.digest(path)==sha,path
 r['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();m.write(out/'receipt.json',r)
 print(json.dumps(dict(status=r['status'],comparison_status=r.get('comparison_status'),receipt=str(out/'receipt.json'))),flush=True)
if r['status']!='PASS':raise SystemExit(1)

The frozen recursive GL1 controls live under `gl1-recursive-common-factors-04/term15/` and `term16/`. Each directory contains complete `original.atom` and `factored.atom` inputs, `proof.json`, all local before/after expressions and signed factor multisets in `local-factor-certificates.jsonl`, independent tree verification in `independent-tree-proof.json`, and before/after structure audits.

The operation recursively traverses only existing Add/Mul/Neg nodes. At each Add it removes the exact complete factor multiset present in every arm and carries the same factors outside the remaining sum. Functions, powers and inverses stay opaque. It never inserts a denominator missing from another arm, joins distinct denominator topologies, expands numerator products, or invokes approximate arithmetic. This deliberately differs from locked Symbolica `collect_factors`, whose minimum signed-exponent rule can create common denominators.

| Captured C3 contribution | Term 15 original | Term 15 factored | Term 16 original | Term 16 factored |
|---|---:|---:|---:|---:|
| UTF-8 input bytes | 1,347,029 | 1,065,784 | 2,864,683 | 2,681,637 |
| Tensor-bearing Add nodes | 2,935 | 1,575 | 2,850 | 1,897 |
| Rank-six Add nodes | 40 | 4 | 89 | 41 |
| Maximum nested tensor Adds | 11 | 10 | 11 | 11 |
| Scalar blocks >=4,096 text bytes | 0 | 18 | 56 | 151 |
| Largest scalar block, text bytes | 1,592 | 6,916 | 44,405 | 43,765 |

There are 821 certified local extractions on term 15 and 1,638 on term 16. The independent checker follows the exact original AST paths, verifies each complete signed branch factor multiset from the actual transformed children, checks every certified before/after digest, and reconstructs the whole frozen alternative AST. It checks 1,830 and 3,535 complete branch multisets respectively. Both final strict serialization/reparse AST comparisons pass. A second factoring pass makes zero changes for either input.

The initial scratch preparation attempts failed the unchanged final AST check because synthetic inverse factors and unary subtraction nodes were printed with different product grouping. The successful fourth attempt fixes the printer instead of weakening that assertion. The initial global inverse-text locator experiment is also retained as unsuccessful: repeated identical factors make global string occurrence selection ambiguous. The authoritative independent check is the AST-path induction in `verify-recursive-gl1-tree.py`, which passes every local certificate and binds the complete reconstructed result to the frozen final file. No production test or numerical oracle changed.

The controls recover some of the old scalar-versus-tensor separation without recreating C1 wholesale. C1's hot contribution has only four rank-six Add nodes and a largest 798,132-byte scalar coefficient; term 15's rank-six count reaches four, but its largest scalar coefficient remains only 6,916 bytes. C3 term 16 retains 41 rank-six Adds. This is therefore a useful bounded test of common-factor collection loss, separate from the earlier numerator mapping change.

The earlier change is visible in actual complete branch payloads, not only source code. `gl1-selector-fragmentation.json` records two exact locators:

- C1 term 0: `root/mul[0]/add[1]/mul[4]/add[2]/mul[5]` is a 798,132-byte, 18-arm **scalar** Add. Each arm carries five theta/sign selectors for graph edges 2–6.
- C3 term 16: `root/mul[0]/add[2]/mul[1]` is a 2,511,894-byte, 18-arm **rank-six tensor** Add. Each arm carries exactly one `three_dimensional_reps::sigma(k)` and the complete IDs are 0–17, each once. The complete arms range from 115,981 to 166,712 text bytes.

The C3 source maps a complete residual numerator separately for every exact residue key in `direct_3d/branches.rs:199–213`, multiplying it into that key's scalar CFF expression, before `materialize` sums selector-weighted bodies (`:218–230`). The direct final-integrand caller performs this ordering at `final_integrand.rs:109–121`. C1 instead multiplies a sign-parametric residual numerator into the earlier scalar selector aggregate before factor collection (`final_integrand.rs:100–143`). C3 also omits that later factor collection in `simplify_final` to retain separate denominator topologies (`:283–297`). These are two distinct representation changes; the present exact control tests only the latter's recoverable sharing.

The selector payload comparison does not certify equality of the full C1/C3 UV coefficients or identify a forest owner from aggregate term order. Independent runtime energy-map/owner capture is needed before replacing a hot proper-UV branch family with a shared sign-parametric numerator. The earlier complete bare certificate already establishes such a numerator template for the physical five-edge unit-pole bare graph under its 18 sign sectors, but that certificate must not be promoted to a proper-UV sector identity.

The same immutable C3 contraction binary has now completed both replay pairs. Exact runtime receipts and stages are indexed in `gl1-recursive-factor-runtime.json`:

| Complete C3 contribution | Term 15 original | Term 15 factored | Term 16 original | Term 16 factored |
|---|---:|---:|---:|---:|
| Contraction boundary, seconds | 10.655996628 | 4.319782642 | 49.460072441 | 20.148276466 |
| Execute stage, seconds | 10.314388069 | 3.542973628 | 45.681227703 | 16.638775836 |
| Output packed Atom bytes | 42,236,243 | 37,844,104 | 313,749,436 | 378,306,347 |
| Peak process-tree RSS bytes | 7,018,176,512 | 2,589,036,544 | 16,628,248,576 | 8,326,254,592 |

Both complete contribution boundaries improve by approximately 2.46 times. The term16 scalar output grows by 20.6%, despite faster contraction and roughly half the peak memory. Thus common-factor sharing is a causal performance factor, but scalar output size alone does not predict contraction cost and local factoring does not restore C1's large scalar branch blocks. The factor-multiset identities already certify both complete inputs; unchanged-oracle numerical checks of the fully resolved outputs are being prepared separately with exact dyadic coefficient notation.

The attachment ownership boundary is now closed in `c3-attachment-complete-owner-join.json`: the newly instrumented C3 full pre-network expression is byte-identical to the prior measured 1,986,903-byte input, SHA256 `6c705ae54d4fc06df260aa205dd0b6bb0e97a7a5591125b2c2b21a1616838bcd`. All 18 prior contributions join exactly once to the 14 nonzero owners by splitting only existing top-level Adds. Hot term006 and term001 belong to node5/source16C4/forest `{16C4}`/order5. The same C1 semantic owner contributes its term001. The owner payload's larger size is an ordinary sum of existing terms, not evidence of a changed tensor representation from instrumentation.

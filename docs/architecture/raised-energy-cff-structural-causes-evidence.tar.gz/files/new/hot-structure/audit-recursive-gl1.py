"""Independent trace reassembly and scalar/tensor boundary statistics; inputs untouched."""
from pathlib import Path
from collections import Counter
import json,hashlib,gc
base=Path('/tmp/raised-energy-expression-perf-20260914/upstream-expression-analysis');ns={};exec((base/'analyze-captured-structure.py').read_text().split('records=[]')[0],ns)
parent=Path('/tmp/raised-energy-causal-20260914/hot-structure/gl1-recursive-common-factors-04')
for index in [15,16]:
 directory=parent/f'term{index}';proof=json.loads((directory/'proof.json').read_text());records=[json.loads(line) for line in (directory/'local-factor-certificates.jsonl').open()]
 recovered=(directory/'factored.atom').read_text();inverse_steps=0
 for record in reversed(records):
  for label in ['before','after']:
   assert hashlib.sha256(record[label+'_expression'].encode()).hexdigest()==record[label+'_sha256']
  common=Counter(record['common_factor_multiset']);assert Counter(f['digest'] for f in record['common_complete_factors'])==common
  for branch in record['branches']:
   assert common+Counter(branch['remainder_complete_factor_multiset'])==Counter(branch['original_complete_factor_multiset'])
   assert branch['sign'] in [-1,1]
  count=recovered.count(record['after_expression'])
  if not count:
   print('INVERSE_TEXT_LOCATOR_ABSENT',index,record['path'],flush=True);break
  recovered=recovered.replace(record['after_expression'],record['before_expression'],1);inverse_steps+=1
 all_steps=inverse_steps==len(records)
 recovered_digest=ns['parse'](recovered).digest if all_steps else None
 audit={'inverse_steps':inverse_steps,'all_local_steps_reversed':all_steps,'restored_ast_digest':recovered_digest,'expected_original_ast_digest':proof['initial_ast_digest'],'inverse_trace_restores_original_ast':recovered_digest==proof['initial_ast_digest'],'all_recorded_complete_factor_multisets_and_expression_hashes_pass':True}
 (directory/'independent-trace-reassembly.json').write_text(json.dumps(audit,indent=2)+'\n');print('TRACE',index,json.dumps(audit),flush=True)
 for label in ['original','factored']:
  path=directory/f'{label}.atom';root=ns['parse'](path.read_text());walked=list(ns['walk'](root));node_by_path=dict(walked);scalar=[];tensor_adds=[];information={}
  for astpath,n in reversed(walked):
   cs=[information[id(c)] for c in n.children]
   if n.kind=='fun' and n.name in ['spenso::mink','spenso::bis']:slots=(n.text,)
   elif n.kind=='add':
    slots=cs[0]['slots'];assert all(c['slots']==slots for c in cs)
   else:
    counter=Counter(s for c in cs for s in c['slots']);slots=tuple(sorted(s for s,n in counter.items() if n%2))
   information[id(n)]={'slots':slots,'tensor_add_depth':(n.kind=='add' and bool(slots))+max((c['tensor_add_depth'] for c in cs),default=0)}
  for astpath,n in walked:
   parentnode=node_by_path.get(astpath.rsplit('/',1)[0])
   if n.kind=='add' and n.tensor:tensor_adds.append({'path':astpath,'utf8_bytes':len(n.text.encode()),'width':len(n.children),'rank':len(information[id(n)]['slots'])})
   if parentnode is not None and parentnode.kind in ['mul','add','neg'] and parentnode.tensor and not n.tensor:
    scalar.append({'path':astpath,'utf8_bytes':len(n.text.encode()),'kind':n.kind,'direct_children':len(n.children),'digest':n.digest})
  result={'input_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'tensor_bearing_adds':len(tensor_adds),'rank6_adds':sum(a['rank']==6 for a in tensor_adds),'tensor_add_rank_histogram':dict(Counter(a['rank'] for a in tensor_adds)),'max_nested_tensor_adds':information[id(root)]['tensor_add_depth'],'scalar_algebra_blocks':len(scalar),'scalar_blocks_at_least4096_text_bytes':sum(x['utf8_bytes']>=4096 for x in scalar),'scalar_blocks_at_least65536_text_bytes':sum(x['utf8_bytes']>=65536 for x in scalar),'largest_scalar_blocks':sorted(scalar,key=lambda x:x['utf8_bytes'],reverse=True)[:8],'largest_tensor_sums':sorted(tensor_adds,key=lambda x:x['utf8_bytes'],reverse=True)[:8]}
  (directory/f'{label}-structure-audit.json').write_text(json.dumps(result,indent=2)+'\n');print('STRUCT',index,label,json.dumps({k:v for k,v in result.items() if k not in ['largest_scalar_blocks','largest_tensor_sums']}),'largest_scalar',result['largest_scalar_blocks'][0]['utf8_bytes'],flush=True)
  del root,walked,node_by_path,information,scalar,tensor_adds;gc.collect()

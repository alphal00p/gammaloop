"""Reuse the prior factor-preserving certificate for the measured hot term."""
from pathlib import Path
from collections import Counter
import json
base=Path('/tmp/raised-energy-expression-perf-20260914/upstream-expression-analysis')
ns={};exec((base/'extract-factor-witnesses.py').read_text().split('records=[]')[0],ns)
parse=ns['parse'];product_parts=ns['product_parts'];normalize_product=ns['normalize_product'];fingerprint=ns['fingerprint']
directory=Path('/tmp/raised-energy-causal-20260914/hot-structure/attachment6-common-metrics');directory.mkdir(exist_ok=True)
source=base/'c3-orientation58-pre_network-000-terms/006.atom';raw=source.read_text();root=parse(raw);node=root.children[1]
assert root.kind=='mul' and node.kind=='add' and len(node.children)==2
common=[f for f in ns['product_parts'](node.children[0])[1] if f.kind=='fun' and f.name=='spenso::g']
assert len(common)==2
target=Counter(f.digest for f in common);remainders=[];branches=[]
for i,branch in enumerate(node.children):
 sign,fs=product_parts(branch);pending=target.copy();remaining=[];removed=[]
 for f in fs:
  if pending[f.digest]:pending[f.digest]-=1;removed.append(f)
  else:remaining.append(f)
 assert not any(pending.values())
 assert Counter(f.digest for f in remaining)+target==Counter(f.digest for f in fs)
 rest='*'.join('('+f.text+')' for f in remaining) or '1'
 if sign<0:rest='-('+rest+')'
 expected_sign,expected_factors=normalize_product(remaining)
 actual_sign,actual_factors=normalize_product([parse(rest)])
 assert actual_sign==sign*expected_sign and actual_factors==expected_factors
 p=directory/f'branch-{i:02d}-remainder.atom';p.write_text(rest);remainders.append(rest)
 branches.append({'index':i,'sign':sign,'original_factors':[f.digest for f in fs],'remaining_factors':[f.digest for f in remaining],'common_factors':[f.digest for f in removed],'remainder':fingerprint(p),'signed_complete_factor_multiset_reassembly_equal':True})
metrics='*'.join('('+f.text+')' for f in common)
replacement='('+metrics+')*('+'+'.join('('+r+')' for r in remainders)+')'
assert raw.count(node.text)==1
alternative=raw.replace(node.text,replacement,1)
assert alternative.count(replacement)==1 and alternative.replace(replacement,node.text,1)==raw
for name,text in [('original-complete-enclosing-term.atom',raw),('common-metric-product.atom',metrics),('original-complete-sum.atom',node.text),('factored-equivalent-complete-sum.atom',replacement),('factored-equivalent-complete-enclosing-term.atom',alternative)]:
 (directory/name).write_text(text)
record={'source':fingerprint(source),'ast_locator':'root/mul[1]','whole_capture_locator':'root/add[6]/mul[1]','source_log':'/tmp/raised-energy-expression-perf-20260914/controls/measurements/c3/run-orientation58_expression_boundaries-01/state/logs/gammalog-2026-09-14T20-10-57.742Z.jsonl','source_log_line':193,'measured_execute_log_line':241,'common_metrics':[f.text for f in common],'branches':branches,'original':fingerprint(directory/'original-complete-enclosing-term.atom'),'alternative':fingerprint(directory/'factored-equivalent-complete-enclosing-term.atom'),'inverse_text_replacement_restores_complete_original':True,'identity_proof':'Each complete original branch equals the same two intact metrics times its complete signed remainder. Every other scalar, tensor, denominator, function, sum and power remains intact. Factoring the two metrics out of the two-arm sum is exact distributivity in reverse. No graph-numerator product is expanded and no denominator algebra performed.','scope':'Exact within-C3 identity on the contribution that consumed 11.405 s in the completed capture. Runtime comparison pending; C1 matching scalar UV coefficient not certified.'}
(directory/'proof.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'original':record['original'],'alternative':record['alternative'],'metrics':record['common_metrics']}))

from pathlib import Path
from collections import Counter
import json,hashlib
B=Path('/tmp/raised-energy-expression-perf-20260914/upstream-expression-analysis');P=Path('/tmp/raised-energy-causal-20260914/attachment7-sparse-profile/common-vectors/proof.json');O=Path('/tmp/raised-energy-causal-20260914/hot-structure')
ns={};exec((B/'extract-factor-witnesses.py').read_text().split('records=[]')[0],ns)
parse,locate,normal=ns['parse'],ns['locate'],ns['normalize_product'];proof=json.loads(P.read_text())
source=Path(proof['source']['path']).read_text();assert hashlib.sha256(source.encode()).hexdigest()==proof['source']['sha256'];assembled=source;checks=[];intervals=[]
for row in proof['controls']:
 d=P.parent/row['label'];old=(d/'original-complete-sum.atom').read_text();new=(d/'factored-complete-sum.atom').read_text();common=(d/'common-vector-product.atom').read_text()
 assert locate(source,row['locator'])['text']==old
 assert source.count(old)==1;start=source.index(old);intervals.append((start,start+len(old)))
 original=parse(old);assert original.kind=='add' and len(original.children)==2
 common_node=parse(common);sign,common_factors=normal([common_node]);assert sign==1
 assert common_factors==Counter(x['digest'] for x in row['common_vectors'])
 rest=[]
 for i,branch in enumerate(original.children):
  original_text=(d/f'arm-{i:02d}-original.atom').read_text();remainder=(d/f'arm-{i:02d}-remainder.atom').read_text();rest.append(remainder)
  assert normal([parse(original_text)])==normal([branch])
  os,of=normal([branch]);rs,rf=normal([parse(remainder)])
  assert os==rs and of==rf+common_factors
  assert Counter(row['branches'][i]['complete_original_factors'])==Counter(x.digest for x in ns['product_parts'](branch)[1])
  assert row['branches'][i]['sign']==ns['product_parts'](branch)[0]
 expected='('+common+')*('+'+'.join('('+r+')' for r in rest)+')'
 assert parse(expected).digest==parse(new).digest
 alternative=(d/'factored-complete-term.atom').read_text();assert alternative==source.replace(old,new,1)
 assert alternative.count(new)==1 and alternative.replace(new,old,1)==source
 assert hashlib.sha256(alternative.encode()).hexdigest()==row['alternative']['sha256']
 assembled=assembled.replace(old,new,1)
 checks.append(dict(label=row['label'],complete_signed_arm_multisets_pass=True,common_complete_factor_multiset_pass=True,whole_term_forward_and_inverse_replacement_pass=True,alternative_sha256=row['alternative']['sha256']))
assert intervals[0][1]<=intervals[1][0] or intervals[1][1]<=intervals[0][0]
combined=Path(proof['combined_alternative']['path']).read_text();assert assembled==combined
inverse=combined
for row in proof['controls']:
 d=P.parent/row['label'];old=(d/'original-complete-sum.atom').read_text();new=(d/'factored-complete-sum.atom').read_text();assert inverse.count(new)==1;inverse=inverse.replace(new,old,1)
assert inverse==source and hashlib.sha256(combined.encode()).hexdigest()==proof['combined_alternative']['sha256']
result=dict(status='PASS_INDEPENDENT_EXACT_FACTOR_REVIEW',proof=str(P),proof_sha256=hashlib.sha256(P.read_bytes()).hexdigest(),source_sha256=proof['source']['sha256'],checks=checks,combined_sha256=proof['combined_alternative']['sha256'],combined_disjoint_replacements_pass=True,combined_inverse_restores_complete_source=True,scope='Complete original and alternative expressions reviewed using existing signed product normalizer, no tensor/native execution and no numerator expansion. Rank claims remain separately auditable in preparation metadata; this review certifies expression identity.')
(O/'attachment7-common-vectors-independent-review.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))

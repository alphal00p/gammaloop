"""Inventory opaque scalar blocks in the existing preserved AST; no rewriting."""
from pathlib import Path
from collections import Counter
import json,gc
b=Path('/tmp/raised-energy-expression-perf-20260914/upstream-expression-analysis');out=Path('/tmp/raised-energy-causal-20260914/hot-structure');ns={};exec((b/'analyze-captured-structure.py').read_text().split('records=[]')[0],ns);results=[]
for rev,w,i in [('c1','g_gl1',0),('c3','g_gl1',15),('c3','g_gl1',16),('c1','orientation58',1),('c3','orientation58',6)]:
 p=b/f'{rev}-{w}-pre_network-000-terms/{i:03d}.atom';print('START',p,flush=True);tree=ns['parse'](p.read_text());nodes=dict(ns['walk'](tree));boundaries=[];sums=[]
 for path,n in nodes.items():
  parent=nodes.get(path.rsplit('/',1)[0]);size=len(n.text.encode())
  if not n.tensor and parent is not None and parent.tensor:
   boundaries.append({'path':path,'kind':n.kind,'utf8_bytes':size,'digest':n.digest,'direct_children':len(n.children),'nested_add_depth':n.max_add_depth,'contains_inverse':n.counts.get('inv',0),'preview':n.text[:100]})
  if n.kind=='add' and n.tensor:
   sums.append({'path':path,'utf8_bytes':size,'width':len(n.children)})
 r={'path':str(p),'maximal_scalar_boundaries':len(boundaries),'scalar_boundary_bytes':sum(a['utf8_bytes'] for a in boundaries),'scalar_boundary_distinct_digests':len({a['digest'] for a in boundaries}),'scalar_boundary_size_histogram':dict(Counter('>=65536' if a['utf8_bytes']>=65536 else '>=4096' if a['utf8_bytes']>=4096 else '>=1024' if a['utf8_bytes']>=1024 else '<1024' for a in boundaries)),'largest_scalar_boundaries':sorted(boundaries,key=lambda a:a['utf8_bytes'],reverse=True)[:30],'tensor_sum_width_histogram':dict(Counter(a['width'] for a in sums)),'tensor_sum_count':len(sums),'largest_tensor_sums':sorted(sums,key=lambda a:a['utf8_bytes'],reverse=True)[:30]}
 results.append(r);(out/'scalar-boundaries.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items() if k not in ['largest_scalar_boundaries','largest_tensor_sums']}),flush=True)
 del tree,nodes,boundaries,sums,r;gc.collect()

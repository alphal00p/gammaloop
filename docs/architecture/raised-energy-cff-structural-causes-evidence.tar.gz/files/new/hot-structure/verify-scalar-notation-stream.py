"""Independent bounded reconstruction of only certified numeric token substitutions."""
from collections import Counter
from fractions import Fraction
import hashlib,json,re,sys
from pathlib import Path
root=Path(sys.argv[1]);preparation=json.loads((root/'preparation.json').read_text())
pattern=re.compile(rb'[+-]?[0-9]+[.][0-9]+(?:[eE][+-]?[0-9]+)?(?:`[0-9.]+)?'+rb'(?:'+'𝑖'.encode()+rb')?')
rows=[]
for row in preparation['rows']:
 replacements={a.encode():b.encode() for a,b in row['exact_token_substitutions'].items()}
 for token,replacement in replacements.items():
  original=Fraction(token.decode().removesuffix('𝑖').split('`')[0])
  restored=Fraction(replacement.decode().replace('(','').replace(')','').replace('𝑖',''))
  assert original==restored
  assert original.denominator & (original.denominator-1)==0
  sign=token[:1] if token[:1] in (b'+',b'-') else b''
  assert not sign or replacement.startswith(sign)
  assert replacement.count('𝑖'.encode())==token.count('𝑖'.encode())
 total=new_total=max_buffer=0;carry=b'';count=Counter();original_hash=hashlib.sha256();new_hash=hashlib.sha256()
 with Path(row['original']['path']).open('rb') as source,Path(row['path']).open('rb') as target:
  while True:
   chunk=source.read(1024*1024);original_hash.update(chunk);total+=len(chunk)
   data=carry+chunk;max_buffer=max(max_buffer,len(data));assert len(data)<=1024*1024+8192
   boundary=data.rfind(b'*')+1 if chunk else len(data);assert boundary or not chunk
   prefix,carry=data[:boundary],data[boundary:]
   pieces=[];previous=0
   for match in pattern.finditer(prefix):
    token=match[0]
    # Attempt04 keeps integer imaginary suffixes outside the captured real token.
    if token not in replacements and token.endswith('𝑖'.encode()):
     coefficient=token[:-len('𝑖'.encode())]
     assert coefficient in replacements
     replacement=replacements[coefficient]+'𝑖'.encode();count[coefficient.decode()]+=1
    else:
     assert token in replacements,token
     replacement=replacements[token];count[token.decode()]+=1
    pieces.extend((prefix[previous:match.start()],replacement));previous=match.end()
   pieces.append(prefix[previous:]);expected=b''.join(pieces)
   actual=target.read(len(expected));assert actual==expected,(row['label'],total)
   new_total+=len(actual);new_hash.update(actual)
   if not chunk:break
  assert target.read(1)==b''
 assert original_hash.hexdigest()==row['original']['sha256'] and total==row['original']['bytes']
 assert new_hash.hexdigest()==row['sha256'] and new_total==row['bytes']
 assert count==Counter(row['exact_dyadic_decimal_tokens'])
 rows.append(dict(label=row['label'],input_sha256=original_hash.hexdigest(),normalized_sha256=new_hash.hexdigest(),numeric_tokens=sum(count.values()),explicit_plus_tokens=sum(v for k,v in count.items() if k.startswith('+')),all_noncoefficient_bytes_exact=True,all_exact_rational_coefficients_equal=True,all_explicit_signs_retained=True,imaginary_units_retained_exactly_once=True,maximum_buffer_bytes=max_buffer))
 print(json.dumps(rows[-1]),flush=True)
(root/'independent-notation-proof.json').write_text(json.dumps(dict(status='PASS',oracle_source_unchanged=True,rows=rows),indent=2)+'\n')

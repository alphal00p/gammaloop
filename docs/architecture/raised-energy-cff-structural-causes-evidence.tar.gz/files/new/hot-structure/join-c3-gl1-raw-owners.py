from pathlib import Path
from collections import Counter
import json,re,hashlib
B=Path('/tmp/raised-energy-expression-perf-20260914/upstream-expression-analysis');C=Path('/tmp/raised-energy-causal-20260914/uv-boundaries/attempts/c3/run-g_gl1-01');OUT=Path('/tmp/raised-energy-causal-20260914/hot-structure')
ns={};exec((B/'analyze-captured-structure.py').read_text().split('records=[]')[0],ns)
rawpath=B/'c3-g_gl1-raw_pre_algebra-000.atom';raw=ns['parse'](rawpath.read_text());assert raw.kind=='add'
prior={x.text:i for i,x in enumerate(raw.children)}
rows=[];seen=[]
for record in json.loads((C/'owner-index.json').read_text()):
 if 'orientation_parametric_atom' not in record:continue
 artifact=record['orientation_parametric_atom'];s=Path(artifact['path']).read_text();assert hashlib.sha256(s.encode()).hexdigest()==artifact['sha256']
 hidden=re.sub(r'(?:[A-Za-z_][A-Za-z_0-9]*::)+','',s);n=ns['parse'](hidden);children=n.children if n.kind=='add' else[n]
 matches=[]
 for child in children:
  assert child.text in prior,(record['node_index'],len(child.text))
  i=prior[child.text];seen.append(i);matches.append(dict(raw_term=i,utf8_bytes=len(child.text.encode()),namespace_hidden_sha256=hashlib.sha256(child.text.encode()).hexdigest(),byte_exact_after_namespace_hiding=True))
 row={k:record[k] for k in ['node_index','source','forest_term','source_loop_edges','cover','residue_index','_logfile','_line']}
 row.update(artifact=artifact,existing_top_level_add_arms=len(children) if n.kind=='add' else 0,matches=matches);rows.append(row)
 print(row['node_index'],row['forest_term'],matches,flush=True)
assert Counter(seen)==Counter(range(len(prior)))
result=dict(status='PASS_ALL_RAW_TERMS_MATCH_OWNERS',raw_capture=str(rawpath),raw_capture_sha256=hashlib.sha256(rawpath.read_bytes()).hexdigest(),raw_term_count=len(prior),owner_index=str(C/'owner-index.json'),owner_index_sha256=hashlib.sha256((C/'owner-index.json').read_bytes()).hexdigest(),normalization='Hide only namespaces omitted by the prior raw capture printer, split only pre-existing top-level Add nodes, compare complete resulting strings byte-exactly.',post_gamma_assignment='Pending; raw owner joins alone do not assign later regrouped evaluator terms.',rows=rows)
(OUT/'c3-gl1-complete-raw-owner-join.json').write_text(json.dumps(result,indent=2)+'\n')

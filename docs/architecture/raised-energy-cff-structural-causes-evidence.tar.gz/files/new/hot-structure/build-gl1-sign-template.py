"""Actual complete bare unit-pole branch template; retain every C3 scalar weight."""
from pathlib import Path
from collections import Counter
import hashlib,json,re,itertools
base=Path('/tmp/raised-energy-expression-perf-20260914/upstream-expression-analysis');ns={};exec((base/'analyze-captured-structure.py').read_text().split('records=[]')[0],ns);parse=ns['parse']
audit=json.loads((base/'gl1-bare-factor-audit.json').read_text());rows=sorted(audit['c3_branches'],key=lambda r:r['sigma_id'])
out=Path('/tmp/raised-energy-causal-20260914/hot-structure/gl1-bare-sign-template');out.mkdir(exist_ok=True)
# Normalize only associative products, unit factors, signs and Add/Mul order.
# Nested sums stay factors and no product is distributed into any sum.
def factor_key(root):
 info={}
 one=hashlib.sha256(b'["leaf","1",[]]').hexdigest()
 for _,n in reversed(list(ns['walk'](root))):
  cs=[info[id(c)] for c in n.children]
  if n.kind=='neg':
   s,h,fs=cs[0];info[id(n)]=(-s,h,fs);continue
  if n.kind=='mul':
   sign=1;factors=[]
   for s,h,fs in cs:
    sign*=s
    if fs is not None:factors.extend(fs)
    elif h!=one:factors.append(h)
   factors.sort()
   if not factors:info[id(n)]=(sign,one,None)
   elif len(factors)==1:info[id(n)]=(sign,factors[0],None)
   else:info[id(n)]=(sign,hashlib.sha256(json.dumps(['mul',factors],separators=(',',':')).encode()).hexdigest(),tuple(factors))
   continue
  children=[(s,h) for s,h,_ in cs]
  if n.kind=='add':children.sort()
  h=hashlib.sha256(json.dumps([n.kind,n.name,children],separators=(',',':'),ensure_ascii=False).encode()).hexdigest()
  info[id(n)]=(1,h,None)
 return info[id(root)][:2]
vector_templates=[]
for edge in [2,3,4]:
 pair=next(p for r in rows for p in r['three_compact_to_explicit_pairs'] if p['edge']==edge and p['sign']==1)
 vector=pair['c3_vector_factor'];assert vector.count(f'OSE({edge})')==1
 vector_templates.append(vector.replace(f'OSE({edge})',f'σ({edge})*OSE({edge})'))
gammas=[f for f in rows[0]['complete_numerator_factors'] if f.startswith('gamma(')];assert len(gammas)==6
vvv=audit['bare']['c1']['complete_three_gluon_factor']
template_factors=vector_templates+[vvv]+gammas;template='*'.join('('+f+')' for f in template_factors)
(out/'complete-parametric-numerator.atom').write_text(template);scalar_rows=[];certified=[]
for row in rows:
 index=row['sigma_id'];signs=row['physical_signs_from_recorded_numerator_edges_2_through_6'];full=parse(row['complete_inner_branch']);fs=ns['factors'](full)
 tensors=[f for f in fs if f.tensor];scalars=[f for f in fs if not f.tensor]
 assert len(tensors)==10
 numerator='*'.join('('+f.text+')' for f in tensors);scalar='*'.join('('+f.text+')' for f in scalars)
 specialized=template
 for edge,sign in zip(range(2,7),signs):specialized=specialized.replace(f'σ({edge})',f'({sign})')
 assert factor_key(parse(numerator))==factor_key(parse(specialized)),index
 assert factor_key(parse('('+numerator+')*('+scalar+')'))==factor_key(full),index
 scalar_rows.append(scalar)
 for name,text in [('original',row['complete_inner_branch']),('scalar',scalar),('numerator',numerator)]:
  (out/f'branch-{index:02d}-{name}.atom').write_text(text)
 certified.append({'sigma_id':index,'signs_edges2_through6':signs,'mapped_edge_energies':{str(e):f'{s}*OSE({e})' for e,s in zip(range(2,7),signs)},'complete_numerator_matches_single_template':True,'complete_branch_reassembly_equal':True,'scalar_weight_sha256':hashlib.sha256(scalar.encode()).hexdigest(),'original_branch_sha256':hashlib.sha256(row['complete_inner_branch'].encode()).hexdigest(),'normalization':'Only product association, unit factors, signs and Add/Mul ordering; every vector and vertex sum stays intact.'})
original_reassembled='6𝑖*('+'+'.join('('+row['complete_inner_branch']+')' for row in rows)+')'
assert factor_key(parse(Path(audit['bare']['c3']['path']).read_text()))==factor_key(parse(original_reassembled))
shared='6𝑖*('+template+')*('+'+'.join('('+s+')' for s in scalar_rows)+')'
(out/'shared-template-with-complete-c3-weights.atom').write_text(shared)
truth=[]
for signs in itertools.product([-1,1],repeat=5):
 selected=[r['sigma_id'] for r in certified if tuple(r['signs_edges2_through6'])==signs]
 assert len(selected)<=1
 truth.append({'signs_edges2_through6':signs,'selected_sigma_ids':selected,'original_and_shared_agree':True})
proof={'scope':'Complete captured C3 bare unit-pole branch family; not the hot proper-UV coefficient family. Formal edge-sign symbols σ(e) obey the production selector truth table; no claim of free-symbol polynomial identity without that constraint.','source_audit_sha256':hashlib.sha256((base/'gl1-bare-factor-audit.json').read_bytes()).hexdigest(),'source_complete_c3_bare':audit['bare']['c3'],'common_outer_factor':'6𝑖','template_sha256':hashlib.sha256(template.encode()).hexdigest(),'shared_expression_sha256':hashlib.sha256(shared.encode()).hexdigest(),'branches':certified,'truth_table':truth,'all32_physical_sign_rows_pass':True,'complete_original_c3_bare_reassembly_passes':True,'all18_complete_scalar_weights_retained':True,'all18_complete_numerator_specializations_pass':True,'loop_energy_and_fixed_affine_maps':'The current captured bare numerator displays ±OSE on each physical edge2–6. This does not independently decode runtime maps or certify that a hot proper-UV map has no affine fixed term.','identity':'On each of the eighteen supported physical sign rows, exactly one sigma(k) is one and the common template specializes to that complete original branch numerator. The same full scalar weight therefore multiplies the same numerator. On the remaining fourteen rows every selector is zero. No numerator products are expanded and no CFF weights are simplified.'}
(out/'proof.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'branches':len(certified),'truth_rows':len(truth),'template_bytes':len(template.encode()),'shared_bytes':len(shared.encode()),'output':str(out)}))

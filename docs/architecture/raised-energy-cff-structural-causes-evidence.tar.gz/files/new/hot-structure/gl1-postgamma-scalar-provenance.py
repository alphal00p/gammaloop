from pathlib import Path
from collections import defaultdict,Counter
import json,re,hashlib
B=Path('/tmp/raised-energy-expression-perf-20260914/upstream-expression-analysis');O=Path('/tmp/raised-energy-causal-20260914/hot-structure')
ns={};exec((B/'analyze-captured-structure.py').read_text().split('records=[]')[0],ns)
raw=ns['parse']((B/'c3-g_gl1-raw_pre_algebra-000.atom').read_text())
lookup=defaultdict(list)
for i,r in enumerate(raw.children):
 for path,n in ns['walk'](r):
  if len(n.text)<1000 or n.tensor or 'mink(' in n.text or 'bis(' in n.text:continue
  lookup[n.digest].append(dict(raw_term=i,path=path,bytes=len(n.text.encode())))
print('raw scalar fingerprints',len(lookup),flush=True)
result=[]
for term in [15,16]:
 p=B/f'c3-g_gl1-pre_network-000-terms/{term:03d}.atom';hidden=re.sub(r'(?:[A-Za-z_][A-Za-z_0-9]*::)+','',p.read_text());n=ns['parse'](hidden)
 matches=[]
 for path,x in ns['walk'](n):
  if x.digest in lookup:
   matches.append(dict(path=path,bytes=len(x.text.encode()),source_raw_terms=sorted(set(r['raw_term'] for r in lookup[x.digest])),raw_locators=lookup[x.digest],digest=x.digest))
 matches.sort(key=lambda x:x['bytes'],reverse=True)
 summary=dict(term=term,total_matches=len(matches),unique_source_raw_terms=dict(Counter(tuple(x['source_raw_terms']) for x in matches)),largest=matches[:20])
 print(term,'matches',len(matches),'sourcecounts',str(summary['unique_source_raw_terms']),flush=True)
 result.append(dict(term=term,input=str(p),input_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),matches=matches))
(O/'gl1-postgamma-scalar-provenance.json').write_text(json.dumps(dict(scope='Exact untouched scalar subtree matches; association evidence, not complete owner-to-output algebra proof.',rows=result),indent=2)+'\n')

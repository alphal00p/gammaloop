The verified C1→C3 regression has two upstream representation changes: loss of common-factor collection and per-branch materialization of sign-specialized numerator copies. Exact within-C3 controls establish that recoverable factor sharing materially affects tensor-contraction cost. They do not establish a full-generation speedup or explain every sparse failure.

C1's final-integrand builder multiplies the residual numerator and calls `collect_factors().simplify_metrics()`; C3's `simplify_final` omits collection to preserve separate denominator sums. The source owners are `crates/gammalooprs/src/uv/approx/final_integrand.rs` (C1 lines 130–143; C3 lines 283–297). Restoring global collection is not yet a production recommendation: locked Symbolica collection can clear denominators, whereas the certified controls below move only complete common factors and leave powers/inverses opaque.

The strongest attachment witness is complete C3 term 006, owned by source16C4/forest `{16C4}`. Its structure is schematically

\[
\Gamma_{12}\,[g_{10,11}g_{12,13}A+g_{10,11}g_{12,13}B]
\quad\longrightarrow\quad
\Gamma_{12}\,g_{10,11}g_{12,13}[A+B].
\]

The twelve gamma factors already sit outside the sum. Extracting the two common metrics reduces its exposed Lorentz rank 10→6, so the full component-space dimension is potentially 256 times smaller; this is not a measured allocation ratio. The same C1 owner already has the corresponding rank-six structure. Complete newly instrumented C3 pre-network input is byte-identical to the earlier measured capture, excluding logging-induced regrouping. Exact coefficients, selectors and denominators remain in the replay. See [metric identity and ranks](/tmp/raised-energy-causal-20260914/hot-structure/attachment6-common-metrics/proof.json) and [complete owner join](/tmp/raised-energy-causal-20260914/hot-structure/c3-attachment-complete-owner-join.json).

All following timings use the same immutable C3 executor (`Sequential / MinIntermediateCost`), with complete scalar-alias restoration. Decimal GB means 10^9 bytes; scalar sizes are packed Atom bytes, not printed text.

| Complete input control | Contraction interval, seconds | Speed ratio | Peak tree RSS, GB | Packed scalar bytes |
|---|---:|---:|---:|---:|
| Attachment006: two common metrics | 11.300339→0.738415 | 15.30× | 6.1518→0.4805 | 56,239,868→22,430,444 |
| GL1 term015: recursive complete common factors | 10.655997→4.319783 | 2.47× | 7.0182→2.5890 | 42,236,243→37,844,104 |
| GL1 term016: recursive complete common factors | 49.460072→20.148276 | 2.45× | 16.6282→8.3263 | 313,749,436→378,306,347 |

The two GL1 improvements are approximately 2.46×. Their exact input proofs independently reconstruct 821/1,638 local extractions through the whole AST, preserving complete signed factor multisets; a second factoring pass changes nothing. Tensor-bearing Add counts fall 2,935→1,575 and2,850→1,897; rank-six Add counts fall 40→4 and89→41. [Runtime stages](/tmp/raised-energy-causal-20260914/hot-structure/gl1-recursive-factor-runtime.json) and [factor-control protocol](/tmp/raised-energy-causal-20260914/hot-structure/gl1-common-factor-control.md) retain the details.

All three fully resolved output pairs additionally agree at all three predetermined 256-bit formal scalar points under the unchanged 2^-128 threshold. These are numerical supplements to exact input identities, not exact output-expression or physical phase-space proofs. The oracle source is unchanged; separately certified exact integer/dyadic coefficient notation avoids reparsing printed coefficients through limited decimal precision. Results: [attachment metric](/tmp/raised-energy-causal-20260914/metric-output-comparison/run-01/comparison.json), [GL1 term015](/tmp/raised-energy-causal-20260914/hot-structure/gl1-output-comparison-04/term15/run-01/comparison.json), [GL1 term016](/tmp/raised-energy-causal-20260914/hot-structure/gl1-output-comparison-05/term16/run-01/comparison.json).

The earlier gamma-only sharing control is a null performance result: extracting eight common gamma factors from attachment term 008 changes its contraction interval 3.320→3.237 seconds, packed scalar 136,523,268→139,627,496 bytes, and guarded wall 16.944→17.247 seconds. It does not test the rank-reducing metric mechanism above. Its original failed numerical checker remains unchanged and must not be conflated with the new successful controls. General compact-slash reconstruction remains a distinct proposal, not a measured fix.

The earlier numerator-materialization boundary has a separate exact certificate. In C1's organization, a sign-parametric numerator can remain outside scalar selector weights; C3 stores complete mapped copies:

\[
N(\sigma_2,\ldots,\sigma_6)\sum_k S_k(\sigma)C_k
\quad\leftrightarrow\quad
\sum_k S_k(\sigma)C_kN(s_{k,2},\ldots,s_{k,6}).
\]

For the actual proper-UV source140/{140} Taylor-entry family, all 18 native complete mapped numerators are exact specializations of one 3,780-byte template. Each effective map is diagonal ±OSE on edges 2–6; source_map=None, loop carriers 3/5. All complete CFF coefficients and denominators are retained. The 32-row truth table verifies 18 singly selected sectors and 14 unsupported sectors; the complete diagnostic family shrinks 73,536→11,602 text bytes. This certifies early duplication before Taylor differentiation, not a direct refactor of post-Taylor coefficients. Source ownership: `uv/approx/mod.rs` applies the complete branch energy map, `direct_3d/kernel.rs` supplies each Taylor-entry branch, and `direct_3d/branches.rs:199–230` maps/multiplies before selector materialization; the final-integrand caller is `final_integrand.rs:109–121`. [Complete source140 certificate](/tmp/raised-energy-causal-20260914/hot-structure/gl1-proper-uv-sign-template-01/proof.json) and [all 11 raw-owner joins](/tmp/raised-energy-causal-20260914/hot-structure/c3-gl1-complete-raw-owner-join.json) retain ownership. Hot term 016 has 413 large untouched scalar subtrees unique to this raw owner; this association is not a complete per-owner post-gamma algebra proof.

Term 016's faster contraction still produces 20.6% more packed scalar data. The added printed output is predominantly repeated kinematic structure: Q-component occurrences grow 8,357,369→10,194,881, accounting for 90.6% of the 139,984,492 additional text bytes. Intact quadratic D3/D5 blocks gain 186,703 occurrences, while both couplings and tree_denoms become globally shared. Scalar writing slows 28.254→33.814 seconds; downstream optimization/compilation has not been measured for the alternatives. [Bounded exact inventory](/tmp/raised-energy-causal-20260914/hot-structure/gl1-term16-scalar-growth.json) explains the size growth without expanding a numerator.

The sparse attachment result remains separate and unresolved. On actual complete term 007, both the original and the exact vector-factored alternative hit the 30 GB cap under the native sparse strategy (sampled peaks 30.377/30.362 GB). The proposed rank 6→3 and rank 5→3 extractions have an [independent complete identity review](/tmp/raised-energy-causal-20260914/hot-structure/attachment7-common-vectors-independent-review.json), but they do not remove the failure: [original receipt](/tmp/raised-energy-causal-20260914/attachment7-sparse-profile/run-01/receipt.json), [factored receipt](/tmp/raised-energy-causal-20260914/attachment7-sparse-profile/common-vector-replay/run-01/receipt.json). Both finish with MinIntermediateCost. A completed baseline cannot be reported as a sparse-strategy fix; tracing of the remaining lazy tensor sum continues.

C6's integrated zero-series behavior is another active diagnostic, owned upstream by integrated UV/Vakint preparation and the locked series machinery. Root is tracing that boundary. No causal conclusion or completed-generation timing from that investigation is included here, and neither it nor the C7/C8 parser failure is evidence for faster generation.

from pathlib import Path
import json
import re
import argparse
from datetime import date

folder = Path('/tmp/raised-stack-latest-review-20260914/report-templates')
parser = argparse.ArgumentParser(description='Render a filled Markdown report into self-contained Typst source; no PDF compilation.')
parser.add_argument('--source', type=Path, default=folder / 'raised-energy-cff-structural-causes.md')
parser.add_argument('--out', type=Path, default=folder / 'raised-energy-cff-structural-causes.typ')
parser.add_argument('--date', default='2026-09-14')
args = parser.parse_args()
report_date = date.fromisoformat(args.date)
source = args.source.read_text()
# The generated Typst file is self-contained; this draft helper is not a runtime dependency.
def inline(value):
    parts = re.split(r'(`[^`]+`|\*\*[^*]+\*\*|\[[^\]]+\]\([^)]+\))', value)
    out = []
    for part in parts:
        if not part:
            continue
        if part.startswith('`'):
            out.append('#text(font: "DejaVu Sans Mono", size: 0.86em, ' + json.dumps(part[1:-1], ensure_ascii=False) + ')')
        elif part.startswith('**'):
            out.append('#strong(' + json.dumps(part[2:-2], ensure_ascii=False) + ')')
        elif part.startswith('['):
            label, target = re.fullmatch(r'\[([^\]]+)\]\(([^)]+)\)', part).groups()
            out.append('#link(' + json.dumps(target, ensure_ascii=False) + ')[#text(' + json.dumps(label, ensure_ascii=False) + ')]')
        else:
            out.append('#text(' + json.dumps(part, ensure_ascii=False) + ')')
    return ''.join(out)

header = '''// Self-contained typesetting of raised-energy-cff-structural-causes.md.
// Current validation status is recorded with explicit counts.
#set document(date: datetime(year: 2026, month: 9, day: 14), title: "CFF expression structure and cost", author: "Lucien Huber",
  description: "Source-pinned expression structures, causal controls and validation.")
#set page(paper: "a4", margin: (x: 18mm, top: 19mm, bottom: 18mm),
  header: align(right)[#text(font: "DejaVu Sans", size: 8pt, fill: rgb("667085"))[GammaLoop / Expression structure and cost]],
  footer: context [#line(length: 100%, stroke: 0.4pt + rgb("d0d5dd"))
    #v(2mm)
    #text(font: "DejaVu Sans", size: 8pt, fill: rgb("667085"))[Structural performance review #h(1fr) #counter(page).display("1 / 1", both: true)]])
#set text(font: "Libertinus Serif", size: 10.5pt, fill: rgb("202939"))
#set par(leading: 0.58em, spacing: 0.78em, justify: false)
#set heading(numbering: none)
#show heading.where(level: 1): set text(font: "DejaVu Sans", size: 16pt, fill: rgb("163e59"))
#show heading.where(level: 2): set text(font: "DejaVu Sans", size: 11pt, weight: "bold")
#show link: set text(fill: rgb("146c94"))
#set table(stroke: 0.4pt + rgb("d0d5dd"), inset: 6pt,
  fill: (x, y) => if y == 0 { rgb("e8eff5") } else if calc.odd(y) { rgb("f7f9fb") } else { none })

#text(font: "DejaVu Sans", size: 9pt, weight: "bold", fill: rgb("146c94"))[ENGINEERING REVIEW]
#v(4mm)
#text(font: "DejaVu Sans", size: 26pt, weight: "bold", fill: rgb("163e59"))[Why CFF generation slows down]
#v(2mm)
#text(font: "DejaVu Sans", size: 12pt)[Expression structure · Tensor cost · Causal evidence]
#v(3mm)
#text(size: 9pt, fill: rgb("667085"))[@@REPORT_DATE@@ · Source-pinned investigation]
#v(4mm)
'''
header = header.replace('datetime(year: 2026, month: 9, day: 14)', f'datetime(year: {report_date.year}, month: {report_date.month}, day: {report_date.day})').replace('@@REPORT_DATE@@', report_date.isoformat())
header += '\n// BEGIN GENERATED MARKDOWN BODY\n'
lines = source.splitlines()
blocks = [header]
i = 2
while i < len(lines):
    line = lines[i]
    if not line.strip():
        i += 1
        continue
    if line.startswith('```'):
        code=[]
        i+=1
        while i < len(lines) and not lines[i].startswith('```'):
            code.append(lines[i]);i+=1
        i+=1
        blocks.append('#block(fill: rgb("f3f5f7"), inset: 8pt, width: 100%)[#set text(size: 8.5pt)\n#raw('+json.dumps('\n'.join(code),ensure_ascii=False)+', block: true)]\n')
        continue
    if line.startswith('## '):
        blocks.append('= ' + inline(line[3:]) + '\n')
        i += 1
        continue
    if line.startswith('|'):
        rows=[]
        while i < len(lines) and lines[i].startswith('|'):
            cells=[x.strip() for x in lines[i].strip('|').split('|')]
            if not all(re.fullmatch(r'[-: ]+', x) for x in cells):
                rows.append(cells)
            i += 1
        count=len(rows[0])
        widths={2:'(0.32fr, 0.68fr)',3:'(0.30fr, 0.25fr, 0.45fr)',4:'(0.25fr, 0.25fr, 0.25fr, 0.25fr)',5:'(0.18fr, 0.17fr, 0.17fr, 0.19fr, 0.29fr)'}[count]
        if rows[0][0] == 'Commit':
            widths='(0.10fr, 0.23fr, 0.67fr)'
        elif rows[0][0] == 'Boundary':
            widths='(0.12fr, 0.46fr, 0.42fr)'
        cells=[]
        for row in rows[1:]:
            cells.extend('['+inline(c)+']' for c in row)
        table_header='table.header('+', '.join('['+inline(c)+']' for c in rows[0])+'),'
        blocks.append('#block[\n#set text(size: 8.6pt)\n#table(columns: '+widths+',\n'+table_header+'\n'+',\n'.join(cells)+',\n)\n]\n')
        continue
    para=[]
    while i < len(lines) and lines[i].strip() and not lines[i].startswith('## ') and not lines[i].startswith('|'):
        para.append(lines[i]);i+=1
    text=' '.join(para)
    rendered=inline(text)
    if text.startswith('**DRAFT'):
        rendered='#block(fill: rgb("fff4df"), stroke: 0.6pt + rgb("b7791f"), inset: 9pt)[\n'+rendered+'\n]'
    blocks.append(rendered+'\n')
args.out.write_text('\n'.join(blocks))
print('wrote self-contained Typst source')

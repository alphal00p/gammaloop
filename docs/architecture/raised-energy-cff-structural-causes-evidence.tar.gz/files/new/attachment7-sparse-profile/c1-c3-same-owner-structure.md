# Same-owner C1/C3 tensor boundary

The complete owner is node 14, forest `{11vs} · {168C} · {16C4}`, source `16C4`, operation count 3, loop edges 5/6/8, uncut residue. The existing complete-owner certificates join C1 term 009 and C3 term 007 byte-exactly to the separately logged owner payload in each revision. This is an ownership comparison, not a proof that complete scalar coefficients agree between versions. The attached JSON retains full owner metadata, hashes, function counts and free-slot incidence records.

| Complete input | C1 term 009 | C3 term 007 |
|---|---:|---:|
| UTF-8 bytes | 148,786 | 315,751 |
| Gamma syntax occurrences | 12 | 108 |
| Distinct gamma texts | 12 | 12 |
| Gamma factors directly outside all sums | 12 | 0 |
| Compact gamma arguments | 0 | 0 |
| Largest tensor-Add rank | 3 | 6 |
| Tensor-Add depth | 7 | 8 |

C1 keeps one shared product of twelve gamma factors outside its Taylor coefficient. Within that product the six vertex Lorentz slots pair off as hedge 1 twice, hedge 11 twice and hedge 13 twice, leaving exactly the six edge slots 2, 3, 4, 5, 8 and 9. Three outer vector sums close edge 2, edge 5 and edge 8. The remaining 145,308-byte five-arm Add exposes only edge 3, edge 4 and edge 9. Thus the enclosing expression is scalar, and no tensor sum in this complete owner has rank above three. Large scalar blocks and shared tensor factors sit outside the varying sum rather than becoming repeated tensor coordinates.

C3 has twelve distinct gamma texts, repeated in 108 syntactic occurrences inside sums, with none shared at the outermost product. Nine distinct gamma texts match C1 exactly; the other three differ only at Lorentz hedge slots 0 versus 1 and 12 versus 13. Replacing those slots for this gamma-text comparison yields the same twelve texts, but is not a complete-expression equality proof. Its outer 315,625-byte Add exposes hedge 0 and hedge 1 and is closed by a metric. Two nested sums expose edge 2, edge 3, edge 4, edge 5, hedge 11 and hedge 12: the 74,451-byte two-arm Add and the 215,169-byte three-arm Add. The second contains a 138,818-byte rank-five Add. A rank-six four-dimensional tensor has 4,096 coordinates per tensor term versus 64 at rank three. These are measured free-slot signatures with zero sum-arm disagreements, not rank estimates from text depth.

The sparse replay witnesses precisely these C3 boundaries. Factoring the local common vectors lowered two local sums to rank three and reduced their materialized tensor storage, but a later remaining three-arm rank-six sum still formed four lazy tensor terms (16,384 tensor entries, 7,634,796,800 stored atom bytes) before the capped contraction. The original C1 owner has no corresponding enclosing rank-six Add. No further sparse performance or optimization probe was run for this comparison.

## Source order and the compact-notation limit

Paths here are relative to each pinned diagnostic workspace's `crates/` directory. C1 `gammalooprs/src/uv/approx/final_integrand.rs` obtains one cograph numerator, applies parametric signs and multiplies it into the coefficient (lines 104–132); it then calls `collect_factors`, metric/color simplification and `expand_dots` (lines 136–143). The final aggregate momentum split is later in `uv/hedge_poset.rs:1260`. Shared Idenso `src/shorthands/metric.rs:455` begins `expand_dots` by calling `to_dots`; `src/shorthands/schoonschip/api.rs:298` enables rank-one compaction. Its vector rule in `with_settings.rs:199–210` requires an intact rank-one function as a multiplicative factor.

C3 maps newly owned numerators in `direct_3d/kernel.rs:273` and maps the final cograph numerator in `final_integrand.rs:114` before the final simplification. The mapping replaces each internal four-vector by `Q3 + branch_energy * delta_0` (`cff/expression.rs:172–177`, with external momenta excluded). Its `simplify_final` performs the same `expand_dots` after mapping, without the C1 final `collect_factors` pass; the aggregate split remains later in `hedge_poset.rs:1346`.

This proves the compactor API is reached before the remaining aggregate split in C1, and after branch mapping in C3. It does not prove an actual gamma/vector compaction occurred for this owner: both complete pre-network inputs have zero compact gamma arguments, and the logged owner atoms before aggregate processing also have zero. The defensible downstream explanation here is the demonstrated placement of shared factors and the rank-three versus rank-six sum boundary. Any stronger claim that compact gamma notation itself causes this owner's difference would require an earlier captured boundary.

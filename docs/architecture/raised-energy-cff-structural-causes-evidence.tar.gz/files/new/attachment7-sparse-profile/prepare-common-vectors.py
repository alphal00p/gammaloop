"""Reuse existing syntax-only complete-factor certificates; never distribute products."""
from pathlib import Path
from collections import Counter
import json

base = Path('/tmp/raised-energy-expression-perf-20260914/upstream-expression-analysis')
ns = {}
exec((base / 'extract-factor-witnesses.py').read_text().split('records=[]')[0], ns)
parse = ns['parse']
product_parts = ns['product_parts']
normalize_product = ns['normalize_product']
fingerprint = ns['fingerprint']
source = base / 'c3-orientation58-pre_network-000-terms/007.atom'
raw = source.read_text()
root = parse(raw)
walked = list(ns['ns']['walk'](root))
nodes = dict(walked)
info = {}
for path, node in reversed(walked):
    children = [info[id(child)] for child in node.children]
    if node.kind == 'fun' and node.name in ['spenso::mink', 'spenso::bis', 'spenso::adj', 'spenso::fund']:
        slots = (node.text,)
    elif node.kind == 'add':
        slots = children[0]
        assert all(child == slots for child in children)
    else:
        counts = Counter(slot for child in children for slot in child)
        slots = tuple(sorted(slot for slot, count in counts.items() if count % 2))
    info[id(node)] = slots
out = Path('/tmp/raised-energy-causal-20260914/attachment7-sparse-profile/common-vectors')
out.mkdir(exist_ok=True)
controls = [
    ('rank6', 'root/mul[1]/add[0]/mul[0]', 6, 3),
    ('rank5', 'root/mul[1]/add[1]/mul[0]/add[0]/mul[0]', 5, 2),
]
records = []
combined = raw
for label, locator, original_rank, expected_common in controls:
    node = nodes[locator]
    assert node.kind == 'add' and len(node.children) == 2 and len(info[id(node)]) == original_rank
    common_counts = Counter(f.digest for f in product_parts(node.children[0])[1])
    for arm in node.children[1:]:
        common_counts &= Counter(f.digest for f in product_parts(arm)[1])
    common = [f for f in product_parts(node.children[0])[1] if common_counts[f.digest] and len(info[id(f)]) == 1]
    assert len(common) == expected_common
    target = Counter(f.digest for f in common)
    common_slots = tuple(sorted(slot for factor in common for slot in info[id(factor)]))
    assert len(common_slots) == len(set(common_slots)) == expected_common
    directory = out / label
    directory.mkdir(exist_ok=True)
    branches = []
    remainders = []
    for index, arm in enumerate(node.children):
        sign, factors = product_parts(arm)
        pending = target.copy()
        remaining = []
        removed = []
        for factor in factors:
            if pending[factor.digest]:
                pending[factor.digest] -= 1
                removed.append(factor)
            else:
                remaining.append(factor)
        assert not any(pending.values())
        assert Counter(f.digest for f in remaining) + target == Counter(f.digest for f in factors)
        rest = '*'.join('(' + f.text + ')' for f in remaining) or '1'
        if sign < 0:
            rest = '-(' + rest + ')'
        expected_sign, expected_factors = normalize_product(remaining)
        actual_sign, actual_factors = normalize_product([parse(rest)])
        assert actual_sign == sign * expected_sign and actual_factors == expected_factors
        counts = Counter(slot for factor in remaining for slot in info[id(factor)])
        remainder_slots = tuple(sorted(slot for slot, count in counts.items() if count % 2))
        assert len(remainder_slots) == original_rank - expected_common
        assert sorted(common_slots + remainder_slots) == sorted(info[id(node)])
        path = directory / f'arm-{index:02d}-remainder.atom'
        path.write_text(rest)
        (directory / f'arm-{index:02d}-original.atom').write_text(arm.text)
        remainders.append(rest)
        branches.append({'index': index, 'sign': sign, 'complete_original_factors': [f.digest for f in factors], 'complete_remaining_factors': [f.digest for f in remaining], 'removed_common_factors': [f.digest for f in removed], 'remainder': fingerprint(path), 'remainder_free_slots': remainder_slots, 'remainder_rank': len(remainder_slots), 'complete_signed_factor_multiset_reassembly_equal': True})
    common_text = '*'.join('(' + f.text + ')' for f in common)
    replacement = '(' + common_text + ')*(' + '+'.join('(' + rest + ')' for rest in remainders) + ')'
    assert raw.count(node.text) == combined.count(node.text) == 1
    alternative = raw.replace(node.text, replacement, 1)
    assert alternative.replace(replacement, node.text, 1) == raw
    combined = combined.replace(node.text, replacement, 1)
    for name, text in [('original-complete-sum.atom', node.text), ('common-vector-product.atom', common_text), ('factored-complete-sum.atom', replacement), ('factored-complete-term.atom', alternative)]:
        (directory / name).write_text(text)
    record = {'label': label, 'source': fingerprint(source), 'locator': locator, 'original_sum': fingerprint(directory / 'original-complete-sum.atom'), 'original_rank': original_rank, 'original_free_slots': info[id(node)], 'common_vectors': [{'text': f.text, 'digest': f.digest, 'slots': info[id(f)]} for f in common], 'common_vector_count': expected_common, 'remainder_rank': original_rank - expected_common, 'branches': branches, 'alternative': fingerprint(directory / 'factored-complete-term.atom'), 'inverse_text_replacement_restores_original': True, 'proof': 'Each complete signed arm equals exactly G times its intact remainder by complete factor multiset equality. Therefore A+B=G*(R_A+R_B). Only the displayed rank1 vector factors move outward; every denominator, scalar coefficient, sign, nested sum, power, gamma and metric remains intact. No numerator product is expanded.', 'runtime_status': 'NOT_RUN'}
    (directory / 'proof.json').write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n')
    records.append(record)
(out / 'combined-factored-complete-term.atom').write_text(combined)
(out / 'proof.json').write_text(json.dumps({'source': fingerprint(source), 'controls': records, 'combined_alternative': fingerprint(out / 'combined-factored-complete-term.atom'), 'both_replacements_are_disjoint': True, 'runtime_status': 'NOT_RUN'}, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'source': fingerprint(source), 'controls': [{'label': r['label'], 'rank': [r['original_rank'], r['remainder_rank']], 'vectors': r['common_vector_count'], 'alternative': r['alternative']} for r in records], 'combined': fingerprint(out / 'combined-factored-complete-term.atom')}))

"""Build the sparse clone or profile fixed baseline then sparse strategy, sequentially."""
from pathlib import Path
import argparse
import datetime
import fcntl
import importlib.util
import json
import shutil

base = Path('/tmp/raised-energy-causal-20260914/attachment7-sparse-profile/common-vector-replay')
prior = Path('/tmp/raised-energy-expression-perf-20260914')
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('action', choices=['build', 'run'])
parser.add_argument('--attempt', required=True)
parser.add_argument('--build-receipt', type=Path)
args = parser.parse_args()
assert args.attempt.replace('-', '').replace('_', '').isalnum()
lock = (prior / 'measurement.lock').open('a')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
recipe = json.loads((base / 'recipe.json').read_text())
spec = importlib.util.spec_from_file_location('measure', prior / 'measure.py')
measure = importlib.util.module_from_spec(spec)
spec.loader.exec_module(measure)
assert measure.digest(prior / 'measure.py') == recipe['measure_sha256']
assert measure.digest(measure.WATCH) == recipe['watchdog_sha256']
measure.PREFIX = Path(recipe['native_workspace'])
for row in recipe['pinned_files'] + [recipe['input']]:
    assert measure.digest(row['path']) == row['sha256'], row['path']
assert measure.digest(recipe['baseline_binary']) == recipe['baseline_binary_sha256']
out = base / f'{args.action}-{args.attempt}'
out.mkdir(exist_ok=False)
record = {'status': 'STARTED', 'action': args.action, 'recipe_sha256': measure.digest(base / 'recipe.json'), 'runner_sha256': measure.digest(__file__), 'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'stages': []}
measure.write(out / 'receipt.json', record)
try:
    record['tracked_before'] = measure.audit(recipe['revision'])
    assert record['tracked_before']['passed']
    overrides = dict(CARGO_TARGET_DIR=str(measure.ROOT / 'target'), CARGO_BUILD_JOBS='4', RAYON_NUM_THREADS='8', RUST_MIN_STACK='134217728', INSTA_UPDATE='no', NEXTEST_RETRIES='0', GL_ALL_LOG_FILTER='off')
    manifest = str(base / 'Cargo.toml')
    if args.action == 'build':
        for name, command in [
            ('fmt', ['cargo', 'fmt', '--manifest-path', manifest, '--', '--check']),
            ('check', ['cargo', 'check', '--offline', '--locked', '--manifest-path', manifest, '--profile', 'dev-optim', '-j', '4']),
            ('build', ['cargo', 'build', '--offline', '--locked', '--manifest-path', manifest, '--profile', 'dev-optim', '-j', '4']),
            ('clippy', ['cargo', 'clippy', '--offline', '--locked', '--manifest-path', manifest, '--profile', 'dev-optim', '-j', '4']),
        ]:
            stage = measure.guarded(out, name, command, overrides)
            record['stages'].append(stage)
            measure.write(out / 'receipt.json', record)
            if stage['status'] != 'PASS':
                record['status'] = stage['status']
                break
        else:
            binary = out / 'cff-sparse-term7-contraction-probe'
            shutil.copy2(measure.ROOT / 'target/dev-optim/cff-sparse-term7-contraction-probe', binary)
            record.update(status='PASS', binary=str(binary), binary_sha256=measure.digest(binary))
    else:
        assert args.build_receipt is not None
        build = json.loads(args.build_receipt.read_text())
        assert build['status'] == 'PASS' and build['recipe_sha256'] == recipe['native_build_recipe_sha256']
        assert measure.digest(build['binary']) == build['binary_sha256']
        assert measure.digest(recipe['timeout']['path']) == recipe['timeout']['sha256']
        record.update(binary=build['binary'], binary_sha256=build['binary_sha256'], build_receipt=str(args.build_receipt), input=recipe['input'])
        overrides.update(recipe['profiling_env'])
        for label, binary in [('fixed_baseline', recipe['baseline_binary']), ('native_sparse_profile', build['binary'])]:
            result_path = out / f'{label}-result.atom'
            command = [recipe['timeout']['path'], '--verbose', '--signal=TERM', '--kill-after=15s', '60s', binary, recipe['input']['path'], str(result_path)]
            stage = measure.guarded(out, label, command, overrides)
            lines = (out / label / 'stdout.log').read_text(errors='replace').splitlines()
            signals = [line for line in lines if line.startswith('timeout: sending signal ') and binary in line]
            if stage['status'] == 'CHILD_FAILURE' and stage['exit_code'] in [124, 137] and signals:
                stage['status'] = 'TIME_LIMIT'
                stage['timeout_signal_lines'] = signals
                measure.write(out / label / 'result.json', stage)
            stage['case'] = label
            if result_path.exists():
                stage['output'] = {'path': str(result_path), 'sha256': measure.digest(result_path), 'bytes': result_path.stat().st_size}
            (out / label / 'spenso-profile.log').write_text('\n'.join(line for line in lines if 'spenso_profile' in line) + '\n')
            stage['last_profile_events'] = [line for line in lines if 'spenso_profile' in line][-12:]
            record['stages'].append(stage)
            record['status'] = stage['status']
            measure.write(out / 'receipt.json', record)
            if label == 'fixed_baseline' and stage['status'] != 'PASS':
                record['sparse_not_run'] = 'Fixed baseline on exactly the same input did not complete; no second heavy run launched.'
                break
        if len(record['stages']) == 2 and all(stage['status'] == 'PASS' for stage in record['stages']):
            record['output_bytes_equal'] = (out / 'fixed_baseline-result.atom').read_bytes() == (out / 'native_sparse_profile-result.atom').read_bytes()
            record['output_equality_scope'] = 'Byte comparison only; differing symbolic output needs factor-preserving exact comparison.'
        assert measure.digest(build['binary']) == build['binary_sha256']
except BaseException as error:
    record.update(status='PREPARATION_OR_EXECUTION_FAILURE', error=repr(error))
    raise
finally:
    try:
        record['tracked_after'] = measure.audit(recipe['revision'])
        assert record['tracked_after']['passed']
        for row in recipe['pinned_files'] + [recipe['input']]:
            assert measure.digest(row['path']) == row['sha256'], row['path']
        assert measure.digest(recipe['baseline_binary']) == recipe['baseline_binary_sha256']
    except BaseException as error:
        record.update(prior_status=record['status'], status='SOURCE_INTEGRITY_FAILURE', integrity_error=repr(error))
    record['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    measure.write(out / 'receipt.json', record)
print(json.dumps({'status': record['status'], 'receipt': str(out / 'receipt.json')}), flush=True)

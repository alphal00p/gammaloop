use std::{env, fs, ops::Deref, time::Instant};

use color_eyre::{Result, eyre::eyre};
use gammalooprs::{
    initialisation::initialise,
    numerator::symbolica_ext::NumeratorAtomExt,
    utils::{FUN_LIB, TENSORLIB},
};
use serde_json::json;
use spenso::network::{ExecutionResult, MinResultRank, Sequential, SequentialRef, SmallestDegree};
use symbolica::{
    atom::{Atom, AtomCore, AtomView},
    parser::ParseSettings,
    wrap_input,
};

fn main() -> Result<()> {
    let args = env::args().skip(1).collect::<Vec<_>>();
    if args.len() != 2 {
        return Err(eyre!(
            "usage: cff-common-factor-contraction-probe INPUT.atom FRESH_OUTPUT.atom"
        ));
    }
    if std::path::Path::new(&args[1]).exists() {
        return Err(eyre!("output already exists"));
    }
    let total = Instant::now();
    initialise()?;
    drop(TENSORLIB.read().unwrap());
    let _ = FUN_LIB.deref();
    println!(
        "{}",
        json!({"stage":"initialized", "seconds":total.elapsed().as_secs_f64()})
    );
    let input = fs::read_to_string(&args[0])?;
    let started = Instant::now();
    let atom = Atom::parse_with_default_namespace(wrap_input!(&input), ParseSettings::default())
        .map_err(|error| eyre!("input parse failed: {error}"))?;
    println!(
        "{}",
        json!({"stage":"symbolica_parse", "seconds":started.elapsed().as_secs_f64(),
        "input_utf8_bytes":input.len(), "atom_bytes":atom.as_view().get_byte_size(), "terms":atom.nterms()})
    );
    // Input was captured after the production algebra/colour-normalization boundary.
    // Preserve existing top-level scalar summands exactly as preprocess_atom does.
    let terms = if let AtomView::Add(sum) = atom.as_view() {
        sum.iter().collect::<Vec<_>>()
    } else {
        vec![atom.as_view()]
    };
    let contraction = Instant::now();
    let mut results = Vec::with_capacity(terms.len());
    for (index, term) in terms.into_iter().enumerate() {
        println!("{}", json!({"stage":"network_parse_start", "term":index}));
        let started = Instant::now();
        let mut net = term.parse_into_net()?;
        println!(
            "{}",
            json!({"stage":"network_parse", "term":index, "seconds":started.elapsed().as_secs_f64()})
        );
        let started = Instant::now();
        // Native C3 preprocess_atom uses this exact threshold (evaluators.rs:70).
        let aliases = net.alias_scalar_refs(|_, scalar| scalar.as_view().get_byte_size() >= 4096);
        net.graph.contract_ready_sum_boundaries();
        println!(
            "{}",
            json!({"stage":"prepare", "term":index, "seconds":started.elapsed().as_secs_f64()})
        );
        let started = Instant::now();
        net.execute::<Sequential, MinResultRank, _, _, _>(
            TENSORLIB.read().unwrap().deref(),
            FUN_LIB.deref(),
        )?;
        // Preserve the native completion pass, including its strategy.
        net.execute::<SequentialRef, SmallestDegree, _, _, _>(
            TENSORLIB.read().unwrap().deref(),
            FUN_LIB.deref(),
        )?;
        println!(
            "{}",
            json!({"stage":"execute", "term":index, "seconds":started.elapsed().as_secs_f64()})
        );
        let started = Instant::now();
        let root = match net.result_scalar()? {
            ExecutionResult::One => Atom::num(1),
            ExecutionResult::Zero => Atom::Zero,
            ExecutionResult::Val(value) => value.into_owned(),
        };
        results.push(net.resolve_scalar_aliases(&aliases, root));
        println!(
            "{}",
            json!({"stage":"resolve_aliases", "term":index, "seconds":started.elapsed().as_secs_f64()})
        );
    }
    let result = Atom::add_many(results);
    println!(
        "{}",
        json!({"stage":"contraction_complete", "seconds":contraction.elapsed().as_secs_f64(),
        "result_atom_bytes":result.as_view().get_byte_size(), "result_terms":result.nterms()})
    );
    let started = Instant::now();
    fs::write(&args[1], result.to_canonical_string())?;
    println!(
        "{}",
        json!({"stage":"output_written", "seconds":started.elapsed().as_secs_f64(),
        "total_seconds":total.elapsed().as_secs_f64(), "status":"PASS_CONTRACTION_ONLY"})
    );
    Ok(())
}

"""Index decisive causal receipts without replacing their native verdicts."""
from collections import Counter
from pathlib import Path
import hashlib
import json

base = Path('/tmp/raised-energy-causal-20260914')
def reference(relative):
    path = base / relative
    return {'path': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}

def load(relative):
    return json.loads((base / relative).read_text())

replays = []
for group in ['attachment6-metric-replay', 'gl1-term15-factor-replay', 'gl1-term16-factor-replay']:
    for label in ['original', 'factored']:
        prefix = f'{group}/run-{label}-01'
        receipt = load(f'{prefix}/receipt.json')
        assert receipt['status'] == 'PASS'
        events = [json.loads(line) for line in (base / prefix / 'runtime/stdout.log').read_text().splitlines() if line.startswith('{')]
        replays.append({'group': group, 'input': label, 'receipt': reference(f'{prefix}/receipt.json'),
                        'runtime': receipt['runtime'], 'events': events, 'output': receipt['output']})
comparisons = []
for prefix in ['metric-output-comparison/run-01', 'hot-structure/gl1-output-comparison-04/term15/run-01', 'hot-structure/gl1-output-comparison-05/term16/run-01']:
    comparison = load(prefix + '/comparison.json')
    assert comparison['status'] == 'NUMERICAL_SUPPLEMENT_AGREES', comparison['status']
    assert len(comparison['samples']) == 3
    comparisons.append({'receipt': reference(prefix + '/receipt.json'), 'comparison': reference(prefix + '/comparison.json'),
                        'status': comparison['status'], 'samples': comparison['samples'],
                        'exact_atom_equal': comparison['exact_atom_equal'], 'expansion_performed': comparison['expansion_performed']})
sparse = []
for prefix in ['attachment7-sparse-profile/run-01', 'attachment7-sparse-profile/common-vector-replay/run-01']:
    receipt = load(prefix + '/receipt.json')
    assert [s['status'] for s in receipt['stages']] == ['PASS', 'MEMORY_CAP']
    sparse.append({'receipt': reference(prefix + '/receipt.json'), 'status': receipt['status'], 'stages': receipt['stages']})
series_prefix = 'c6-series-zero-reproducer/run-01'
series = load(series_prefix + '/receipt.json')
cases = [s for s in series['stages'] if s['stage'] not in ['fmt', 'check', 'build', 'clippy', 'metadata']]
assert len(cases) == 5
assert Counter(s['status'] for s in cases) == {'PASS': 2, 'TIME_LIMIT': 3}
c6 = load('c6-absolute-pole-order/run-01/terminal-assessment.json')
assert c6['status'] == 'PASS' and c6['phase_counts']['evaluate_term_done'] == 10
c7 = load('uv-boundaries/c7-no-early-color/causal-result.json')
assert c7['comparisons'][0]['exact_utf8_equal_after_outer_whitespace_strip']
proof_paths = [
 'hot-structure/attachment6-common-metrics/proof.json',
 'hot-structure/gl1-recursive-common-factors-04/root-certificate-review.json',
 'hot-structure/gl1-recursive-common-factors-04/term15/independent-tree-proof.json',
 'hot-structure/gl1-recursive-common-factors-04/term16/independent-tree-proof.json',
 'hot-structure/gl1-proper-uv-sign-template-01/proof.json',
 'uv-boundaries/gl1-owner-map-audit/proof.json',
 'hot-structure/c3-gl1-complete-raw-owner-join.json',
 'hot-structure/gl1-term16-scalar-growth.json',
 'attachment7-sparse-profile/c1-c3-same-owner-structure.json',
 'hot-structure/attachment7-common-vectors-independent-review.json',
 'attachment7-sparse-profile/common-vector-replay/null-result-structure-review.json',
 'c6-coefficient-boundary/complete-coefficient/proof.json',
 'c6-series-zero-reproducer/independent-review.json',
 'c6-c7-direct-boundaries/backend-equality.json',
 'uv-boundaries/grouping-residual-review/review.json',
]
result = {
 'schema_version': 1, 'status': 'COMPLETE_CAUSAL_AUDIT', 'date_utc': '2026-09-15',
 'scope': 'Index of decisive structural experiments. Full archived receipts retain setup failures, null results and earlier diagnostics. Counts below are these groups only, not a repository test-suite total.',
 'source_pins_companion': '/tmp/raised-energy-expression-perf-20260914/revisions.json',
 'factor_replays': replays, 'complete_output_supplements': comparisons, 'sparse_controls': sparse,
 'relative_zero_reproducer': {'receipt': reference(series_prefix + '/receipt.json'), 'cases': cases},
 'c6_original_phase_capture': reference('c6-vakint-phases/run-01/receipt.json'),
 'c6_complete_coefficient_capture': reference('c6-coefficient-boundary/run-01/receipt.json'),
 'c6_depth_only_control': {'assessment': reference('c6-absolute-pole-order/run-01/terminal-assessment.json'), 'phase_counts': c6['phase_counts'], 'main_events': c6['main_events'], 'limits': c6['interpretation_limits']},
 'c7_early_color_control': {'result': reference('uv-boundaries/c7-no-early-color/causal-result.json'), 'status': c7['status'], 'scope': c7['scope'], 'comparisons': c7['comparisons']},
 'structural_proofs_and_reviews': [reference(p) for p in proof_paths],
 'group_counts': {'factor_replay_processes': {'PASS': 6}, 'complete_output_comparisons': {'NUMERICAL_SUPPLEMENT_AGREES': 3, 'fixed_points_per_pair': 3},
                  'sparse_profile_processes': {'PASS': 2, 'MEMORY_CAP': 2}, 'minimal_series_cases': dict(Counter(s['status'] for s in cases)),
                  'depth_only_batch': {'completed_terms': 10, 'completed_pole_queries': 47, 'completed_series_calls': 57},
                  'c7_full_input_capture': {'expected_stop_capture': 1, 'raw_exit_code': c7['runtime']['exit_code']}},
 'limits': ['No production code or existing tests changed.', 'Exact input factor identities are separate from finite numerical output supplements.',
            'Factor alternatives were not benchmarked through evaluator construction or code compilation.', 'C6 standalone completion is not full GammaLoop completion or independent integrated-physics validation.',
            'C7 paired reversal was measured only up to the complete pre-network input, not through downstream execution.', 'Manual PySecDec and exhaustive contraction-strategy benchmarking are excluded.',
            'Single guarded observations on a shared host; no automatic retries or snapshot updates.'],
}
(base / 'causal-results.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result['group_counts'], indent=2))

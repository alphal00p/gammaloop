"""Guarded standalone C6 build or 5-second replay; no work runs on import elsewhere."""
from pathlib import Path
import argparse
import datetime
import fcntl
import importlib.util
import json
import shutil

base = Path('/tmp/raised-energy-causal-20260914/c6-coefficient-boundary')
prior = Path('/tmp/raised-energy-expression-perf-20260914')
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('action', choices=['build', 'run'])
parser.add_argument('--attempt', required=True)
parser.add_argument('--build-receipt', type=Path)
args = parser.parse_args()
assert args.attempt.replace('-', '').replace('_', '').isalnum()
lock = (prior / 'measurement.lock').open('a')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
recipe = json.loads((base / 'standalone-recipe.json').read_text())
spec = importlib.util.spec_from_file_location('measure', prior / 'measure.py')
measure = importlib.util.module_from_spec(spec)
spec.loader.exec_module(measure)
assert measure.digest(prior / 'measure.py') == recipe['measure_sha256']
assert measure.digest(measure.WATCH) == recipe['watchdog_sha256']
measure.PREFIX = Path(recipe['native_workspace'])
revision = recipe['revision']
for row in recipe['pinned_files']:
    assert measure.digest(row['path']) == row['sha256'], row['path']
for row in recipe['captured_files']:
    assert measure.digest(row['path']) == row['sha256'], row['path']
out = base / f'{args.action}-{args.attempt}'
out.mkdir(exist_ok=False)
record = {'status': 'STARTED', 'action': args.action, 'recipe_sha256': measure.digest(base / 'standalone-recipe.json'), 'runner_sha256': measure.digest(__file__), 'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'stages': []}
measure.write(out / 'receipt.json', record)
try:
    record['tracked_before'] = measure.audit(revision)
    assert record['tracked_before']['passed']
    overrides = dict(CARGO_TARGET_DIR=str(measure.ROOT / 'target'), CARGO_BUILD_JOBS='4', RAYON_NUM_THREADS='8', RUST_MIN_STACK='134217728', INSTA_UPDATE='no', NEXTEST_RETRIES='0', GL_ALL_LOG_FILTER='off')
    manifest = str(base / 'standalone/Cargo.toml')
    if args.action == 'build':
        for name, command in [
            ('fmt', ['cargo', 'fmt', '--manifest-path', manifest, '--all', '--', '--check']),
            ('check', ['cargo', 'check', '--offline', '--locked', '--manifest-path', manifest, '--profile', 'dev-optim', '-p', 'c6-vakint-phase-replay', '-j', '4']),
            ('build', ['cargo', 'build', '--offline', '--locked', '--manifest-path', manifest, '--profile', 'dev-optim', '-p', 'c6-vakint-phase-replay', '-j', '4']),
            ('clippy', ['cargo', 'clippy', '--offline', '--locked', '--manifest-path', manifest, '--profile', 'dev-optim', '-p', 'c6-vakint-phase-replay', '-j', '4']),
        ]:
            stage = measure.guarded(out, name, command, overrides)
            record['stages'].append(stage)
            measure.write(out / 'receipt.json', record)
            if stage['status'] != 'PASS':
                record['status'] = stage['status']
                break
        else:
            binary = out / 'c6-vakint-phase-replay'
            shutil.copy2(measure.ROOT / 'target/dev-optim/c6-vakint-phase-replay', binary)
            record.update(status='PASS', binary=str(binary), binary_sha256=measure.digest(binary))
    else:
        assert args.build_receipt is not None
        build = json.loads(args.build_receipt.read_text())
        assert build['status'] == 'PASS'
        assert build['recipe_sha256'] == record['recipe_sha256']
        assert measure.digest(build['binary']) == build['binary_sha256']
        assert measure.digest(recipe['timeout']['path']) == recipe['timeout']['sha256']
        record.update(binary=build['binary'], binary_sha256=build['binary_sha256'], build_receipt=str(args.build_receipt), build_receipt_sha256=measure.digest(args.build_receipt))
        command = [recipe['timeout']['path'], '--verbose', '--signal=TERM', '--kill-after=15s', '5s', build['binary'], str(base), str(out / 'results')]
        stage = measure.guarded(out, 'runtime', command, overrides)
        record['stages'].append(stage)
        log = out / 'runtime/stdout.log'
        lines = log.read_text(errors='replace').splitlines()
        signals = [line for line in lines if line.startswith('timeout: sending signal ') and build['binary'] in line]
        if stage['status'] == 'CHILD_FAILURE' and stage['exit_code'] in [124, 137] and signals:
            stage['status'] = 'TIME_LIMIT'
            stage['timeout_signal_lines'] = signals
            measure.write(out / 'runtime/result.json', stage)
        record['status'] = stage['status']
        # Preserve the complete merged stream, plus separate main and Vakint phase logs.
        (out / 'main-events.jsonl').write_text('\n'.join(line for line in lines if line.startswith('{') and '"stage"' in line) + '\n')
        (out / 'phase-events.log').write_text('\n'.join(line for line in lines if 'vakint::phase' in line) + '\n')
        record['phase_logs'] = [{'path': str(path), 'sha256': measure.digest(path)} for path in [out / 'main-events.jsonl', out / 'phase-events.log']]
        record['last_phase_events'] = (out / 'phase-events.log').read_text().splitlines()[-12:]
        if record['status'] == 'PASS':
            assert any('"settings_match":true' in line for line in lines)
            assert any('"stage":"complete"' in line for line in lines)
            assert len(list((out / 'results').glob('term-*-result.atom'))) == 10
        assert measure.digest(build['binary']) == build['binary_sha256']
except BaseException as error:
    record.update(status='PREPARATION_OR_EXECUTION_FAILURE', error=repr(error))
    raise
finally:
    try:
        record['tracked_after'] = measure.audit(revision)
        assert record['tracked_after']['passed']
        for row in recipe['pinned_files'] + recipe['captured_files']:
            assert measure.digest(row['path']) == row['sha256'], row['path']
    except BaseException as error:
        record.update(prior_status=record['status'], status='SOURCE_INTEGRITY_FAILURE', integrity_error=repr(error))
    record['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    measure.write(out / 'receipt.json', record)
print(json.dumps({'status': record['status'], 'receipt': str(out / 'receipt.json')}), flush=True)

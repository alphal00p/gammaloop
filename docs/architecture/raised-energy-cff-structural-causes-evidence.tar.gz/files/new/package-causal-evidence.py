"""Finite text-only causal evidence archive; review and terminal receipts gate --write."""
from pathlib import Path
import argparse,codecs,fcntl,gzip,hashlib,io,json,os,re,stat,tarfile

BASE=Path('/tmp/raised-energy-causal-20260914')
ALLOWLIST=BASE/'causal-evidence-allowlist.json'
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--write',action='store_true',help='Scan and archive only reviewed, terminal evidence under the shared lock')
args=parser.parse_args()
allow=json.loads(ALLOWLIST.read_text())
roots={k:Path(v) for k,v in allow['roots'].items()}
assert roots=={'new':BASE,'prior':Path('/tmp/raised-energy-expression-perf-20260914')}

# Adapted from the prior packager: no symlinks, hardlinks, binary types or escapes.
def safe(root,relative):
    path=Path(relative)
    if path.is_absolute() or any(x in ['..','.git','.jj','__pycache__','target'] for x in path.parts) or any(c in relative for c in '*?[]'):
        raise ValueError(f'Only exact safe relative paths are permitted: {relative}')
    if any(x in ['sources','diagnostic-workspaces'] for x in path.parts):
        raise ValueError(f'Source tree excluded: {relative}')
    if 'standalone/crates' in path.as_posix():
        raise ValueError(f'Vendored tree excluded: {relative}')
    if path.name=='run' or 'environment' in path.name.lower() or path.name=='.env':
        raise ValueError(f'Environment or licensed launcher excluded: {relative}')
    if path.suffix not in ['.json','.jsonl','.md','.toml','.lock','.py','.rs','.log','.csv','.atom','.dot','.txt','.patch']:
        raise ValueError(f'Unlisted content type: {relative}')
    cursor=roots[root]
    for part in path.parts:
        cursor/=part
        if cursor.is_symlink():raise ValueError(f'Symlink rejected: {relative}')
    if not cursor.resolve().is_relative_to(roots[root]):raise ValueError(f'Outside root: {relative}')
    info=cursor.stat()
    if not stat.S_ISREG(info.st_mode) or info.st_nlink!=1:raise ValueError(f'Nonregular file/hardlink: {relative}')
    if info.st_size>allow['file_size_cap_bytes']:raise ValueError(f'Selected oversized file: {relative}')
    if path.suffix=='.atom' and any(x in path.name for x in ['result','exact-dyadic','exact-integer']) and info.st_size>allow['large_scalar_output_cap_bytes']:
        raise ValueError(f'Large scalar output excluded: {relative}')
    return cursor,info

selected={};gaps=[]
for row in allow['files']:
    key=(row['root'],row['path'])
    if key in selected:raise ValueError(f'Duplicate selection: {key}')
    try:path,info=safe(*key)
    except FileNotFoundError:
        gaps.append(dict(root=key[0],path=key[1],status='MISSING_SELECTED_FILE'));continue
    selected[key]=dict(row,bytes=info.st_size)
    if path.name in ['receipt.json','execution-receipt.json']:
        status=json.loads(path.read_text()).get('status')
        if status not in allow['terminal_statuses']:gaps.append(dict(root=key[0],path=key[1],status=status))
for row in allow['required_terminal_receipts']:
    key=(row['root'],row['path'])
    if key not in selected:gaps.append(dict(row,status='MISSING_REQUIRED_RECEIPT'))
controller=allow['required_controller'];key=(controller['root'],controller['path'])
if key in selected:
    status=json.loads((roots[key[0]]/key[1]).read_text()).get('status')
    if status not in controller['allowed_statuses']:gaps.append(dict(controller,status=status))
else:gaps.append(dict(controller,status='MISSING_FINAL_AGGREGATE'))
if not allow['review_approved']:gaps.append(dict(status='PENDING_ALLOWLIST_AND_SCRIPT_REVIEW'))
gaps.extend(dict(status='PENDING_REVIEW_ITEM',description=x) for x in allow['pending_review_items'])
summary=dict(files=len(selected),source_bytes=sum(r['bytes'] for r in selected.values()),terminal_and_review_gaps=gaps)
if not args.write:
    print(json.dumps(dict(status='INVENTORY_ONLY_NO_CONTENT_SCAN_OR_ARCHIVE',**summary),indent=2));raise SystemExit(0)
if gaps:raise RuntimeError('Pending terminal/review evidence; no archive created')
lock=(roots['prior']/'measurement.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
# From the prior reviewed packager. Matches report categories only, never secret bytes.
secrets={
 'symbolica_license':rb'(?i)[0-9a-f]{8}#[0-9a-f]{8}#[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}',
 'openai_key':rb'\bsk-(?:proj-|svcacct-)?[A-Za-z0-9_-]{24,}',
 'github_token':rb'\b(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,})',
 'aws_access_key':rb'\bAKIA[0-9A-Z]{16}\b',
 'private_key':rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----',
 'authorization_header':rb'(?i)authorization\s*[:=]\s*["\x27]?(?:bearer|basic)\s+[A-Za-z0-9_./+=-]{16,}',
}
patterns={name:re.compile(pattern) for name,pattern in secrets.items()}
entries=[]
for key,row in sorted(selected.items()):
    path,before=safe(*key);digest=hashlib.sha256();decoder=codecs.getincrementaldecoder('utf-8')();tail=b''
    with path.open('rb') as stream:
        while chunk:=stream.read(1024*1024):
            if b'\0' in chunk:raise ValueError(f'Binary content rejected: {key}')
            decoder.decode(chunk);window=tail+chunk
            for category,pattern in patterns.items():
                if pattern.search(window):raise ValueError(f'Credential category {category} detected in {key}; value suppressed')
            digest.update(chunk);tail=window[-8192:]
        decoder.decode(b'',final=True)
    _,after=safe(*key)
    if (before.st_size,before.st_mtime_ns,before.st_ino)!=(after.st_size,after.st_mtime_ns,after.st_ino):raise RuntimeError(f'Changed while scanning: {key}')
    entries.append(dict(row,archive_path='files/'+key[0]+'/'+key[1],sha256=digest.hexdigest(),mode='0644'))
# Recheck selected receipts after the byte scan so a late mutation cannot pass the earlier terminal gate.
for row in entries:
    if Path(row['path']).name in ['receipt.json','execution-receipt.json']:
        assert json.loads((roots[row['root']]/row['path']).read_text()).get('status') in allow['terminal_statuses']
by_key={(r['root'],r['path']):r for r in entries}
by_absolute={str(roots[r['root']]/r['path']):r for r in entries}
prior_manifest_path=Path(allow['prior_archive']['manifest_path'])
assert hashlib.sha256(prior_manifest_path.read_bytes()).hexdigest()==allow['prior_archive']['manifest_sha256']
prior_manifest=json.loads(prior_manifest_path.read_text())
assert prior_manifest['archive_sha256']==allow['prior_archive']['sha256']
prior_members={str(roots['prior']/r['path']):r for r in prior_manifest['files']}
# Reference audit never opens an excluded binary, source tree, scalar output or launcher.
# Each selected JSON path/hash pair is either verified in this package or explicitly recorded as external.
references={};unclassified=[]
for entry in entries:
    if not entry['path'].endswith('.json'):continue
    document=json.loads((roots[entry['root']]/entry['path']).read_text())
    pending=[document]
    while pending:
        value=pending.pop()
        if isinstance(value,list):pending.extend(value);continue
        if not isinstance(value,dict):continue
        pending.extend(x for x in value.values() if isinstance(x,(dict,list)))
        pairs=[]
        if isinstance(value.get('path'),str) and isinstance(value.get('sha256'),str):pairs.append((value['path'],value['sha256']))
        for name,sha in value.items():
            if name.startswith('/') and isinstance(sha,str):pairs.append((name,sha))
            if name.endswith('_sha256') and isinstance(sha,str) and isinstance(value.get(name[:-7]),str):pairs.append((value[name[:-7]],sha))
        for path,sha in pairs:
            if not path.startswith('/') or not re.fullmatch('[0-9a-f]{64}',sha):continue
            if path in by_absolute:
                if by_absolute[path]['sha256']==sha:
                    scope='verified_selected_file'
                else:
                    historical=[r for r in allow.get('historical_reference_exceptions',[]) if r['referenced_by']==entry['archive_path'] and r['historical_source_path']==path and r['pre_format_hash']==sha and r['current_selected_hash']==by_absolute[path]['sha256']]
                    assert len(historical)==1,f'Stale selected reference: {path}'
                    scope='historical_pre_format_source_reference_preserved_final_source_separately_verified'
            elif path in prior_members and prior_members[path]['sha256']==sha:
                scope='verified_prior_archive_member'
            elif path in allow.get('reference_exceptions',{}):scope=allow['reference_exceptions'][path]
            elif '/diagnostic-workspaces/' in path or '/sources/' in path or '/standalone/crates/' in path:
                scope='excluded_source_tree_reconstruct_from_pinned_revision_recipe_and_patch'
            elif any(path.startswith(str(root)+'/') for root in roots.values()) and (path in {str(roots[r['root']]/r['path']) for r in allow['excluded'] if 'root' in r and 'path' in r} or any(marker in Path(path).name for marker in ['-result.atom','result.atom','exact-dyadic-coefficients.atom','exact-integer-coefficients.atom']) or 'metadata' in Path(path).name):
                scope='excluded_derived_output_hash_retained_regenerate_from_archived_inputs_and_runners'
            elif '/target/' in path or Path(path).suffix not in ['.json','.jsonl','.md','.toml','.lock','.py','.rs','.log','.csv','.atom','.dot','.txt','.patch']:
                scope='excluded_binary_or_external_tool_hash_retained'
            elif path.startswith('/tmp/raised-stack-latest-review-20260914/') and Path(path).name=='ram-watchdog-ps10.py':
                watchdog=by_key.get(('prior','diagnostics/watchdog/ram-watchdog-ps10.py'))
                assert watchdog and watchdog['sha256']==sha
                scope='exact_reviewed_watchdog_copy_bundled_under_prior'
            else:
                scope='UNCLASSIFIED';unclassified.append(dict(path=path,sha256=sha,referenced_by=entry['archive_path']))
            key=(path,sha)
            references.setdefault(key,dict(path=path,sha256=sha,scope=scope,referenced_by=[]))['referenced_by'].append(entry['archive_path'])
if unclassified:
    print(json.dumps(dict(status='REFERENCE_REVIEW_REQUIRED_NO_ARCHIVE',references=unclassified),indent=2));raise SystemExit(1)
manifest=dict(schema_version=1,allowlist_sha256=by_key[('new',ALLOWLIST.name)]['sha256'],files=entries,file_count=len(entries),source_bytes=sum(x['bytes'] for x in entries),prior_archive=allow['prior_archive'],excluded=allow['excluded'],external_and_verified_references=[dict(r,referenced_by=sorted(set(r['referenced_by']))) for _,r in sorted(references.items())],terminal_gaps=[],comparison_receipt_semantics=allow['comparison_receipt_semantics'],utf8_text_only=True,credential_scan='All selected bytes scanned for listed categories; no match. Not a claim to detect every possible secret format.',credential_categories=sorted(secrets),determinism='Sorted USTAR members; mode0644; uid/gid/mtime0; empty user/group/gzip filename; gzip mtime0. Same frozen inputs/toolchain yield identical archive bytes.')
manifest_bytes=(json.dumps(manifest,indent=2,sort_keys=True)+'\n').encode()
out=BASE/'causal-evidence-package';out.mkdir(exist_ok=False)
archive=out/(allow['archive_stem']+'.tar.gz');temporary=out/(archive.name+'.partial')
with temporary.open('xb') as raw,gzip.GzipFile(filename='',fileobj=raw,mode='wb',mtime=0,compresslevel=6) as compressed,tarfile.open(fileobj=compressed,mode='w|',format=tarfile.USTAR_FORMAT) as tar:
    info=tarfile.TarInfo('MANIFEST.json');info.size=len(manifest_bytes);info.mode=0o644;tar.addfile(info,io.BytesIO(manifest_bytes))
    for entry in entries:
        path,_=safe(entry['root'],entry['path']);info=tarfile.TarInfo(entry['archive_path']);info.size=entry['bytes'];info.mode=0o644
        with path.open('rb') as stream:tar.addfile(info,stream)
        with path.open('rb') as stream:assert hashlib.file_digest(stream,'sha256').hexdigest()==entry['sha256'],f'Changed while archiving: {entry["archive_path"]}'
archive_entries={x['archive_path']:x for x in entries}
with tarfile.open(temporary,'r:gz') as tar:
    assert tar.getnames()==['MANIFEST.json']+[x['archive_path'] for x in entries]
    for member in tar:
        assert member.isfile() and not member.issym() and not member.islnk()
        expected=hashlib.sha256(manifest_bytes).hexdigest() if member.name=='MANIFEST.json' else archive_entries[member.name]['sha256']
        assert hashlib.file_digest(tar.extractfile(member),'sha256').hexdigest()==expected,member.name
os.replace(temporary,archive)
with archive.open('rb') as stream:archive_sha=hashlib.file_digest(stream,'sha256').hexdigest()
manifest.update(archive=str(archive),archive_sha256=archive_sha,archive_bytes=archive.stat().st_size,archived_hashes_reverified=True)
index=out/(allow['archive_stem']+'.json');index.write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
print(json.dumps(dict(status='PACKAGED',archive=str(archive),manifest=str(index),files=len(entries),source_bytes=manifest['source_bytes'],archive_bytes=manifest['archive_bytes'],archive_sha256=archive_sha)))

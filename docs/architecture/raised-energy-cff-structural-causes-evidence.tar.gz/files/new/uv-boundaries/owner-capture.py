"""Build or run prepared C1/C3 owner captures, one guarded stage at a time."""
import argparse
import datetime
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import shlex
import stat
import sys
import tomllib

BASE = Path('/tmp/raised-energy-expression-perf-20260914')
OUT = Path('/tmp/raised-energy-causal-20260914/uv-boundaries')
ROOT = Path('/common/dev/gammaloop/higher-power-energies-review')
MEASURE_SHA = '6f6ca7cbb51f5b606b93da4e00fe42465f3a194bc5efaf6e492df737cafad4d9'
STOP = 'GAMMALOOP_STOP_AFTER_EVALUATOR_PRE_NETWORK_PARSE'
OWNER_STAGES = ('hedge_poset_final_node_before_store', 'hedge_poset_final_node_before_aggregation')
OWNER_FILTER = ','.join(f'gammalooprs::uv::hedge_poset[{{stage={stage}}}]=debug' for stage in (*OWNER_STAGES, 'hedge_poset_4d_node_done'))

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('action', choices=['build', 'run'])
parser.add_argument('revision', choices=['c1', 'c3'])
parser.add_argument('--attempt', required=True)
parser.add_argument('--workload', choices=['orientation58', 'g_gl1'])
parser.add_argument('--build-receipt', type=Path)
args = parser.parse_args()
assert re.fullmatch(r'[A-Za-z0-9_-]+', args.attempt)
if args.action == 'run' and (not args.workload or not args.build_receipt):
    parser.error('run needs --workload and --build-receipt')
measure_path = BASE / 'measure.py'
assert hashlib.sha256(measure_path.read_bytes()).hexdigest() == MEASURE_SHA
spec = importlib.util.spec_from_file_location('native_measure', measure_path)
measure = importlib.util.module_from_spec(spec)
spec.loader.exec_module(measure)
prepared = json.loads((OUT / f'{args.revision}-source-audit.json').read_text())
source = Path(prepared['source'])
measure.PREFIX = source
assert measure.digest(measure.WATCH) == measure.WATCH_SHA
lock = (BASE / 'measurement.lock').open('a')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
name = f'{args.action}-{args.workload + "-" if args.workload else ""}{args.attempt}'
out = OUT / 'attempts' / args.revision / name
out.mkdir(parents=True, exist_ok=False)
record = {'status': 'STARTED', 'action': args.action, 'revision': prepared['commit'], 'tree': prepared['tree'], 'source': str(source), 'source_audit_sha256': measure.digest(OUT / f'{args.revision}-source-audit.json'), 'driver_sha256': measure.digest(__file__), 'stages': [], 'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'limits': {'rss_decimal_gb': 30, 'build_jobs': 4, 'rayon_workers': 8, 'worker_stack_bytes': 134217728, 'generation_cores': 1, 'runtime_seconds': 120, 'build_stage_seconds': 1800}}
measure.write(out / 'receipt.json', record)


def audit():
    mismatches = []
    for row in prepared['tracked_files']:
        path = source / row['path']
        info = path.lstat()
        data = os.fsencode(os.readlink(path)) if stat.S_ISLNK(info.st_mode) else path.read_bytes()
        mode = '120000' if stat.S_ISLNK(info.st_mode) else '100755' if info.st_mode & stat.S_IXUSR else '100644'
        if mode != row['mode'] or hashlib.sha256(data).hexdigest() != row['instrumented_sha256']:
            mismatches.append(row['path'])
    return {'passed': not mismatches, 'checked_paths': len(prepared['tracked_files']), 'mismatches': mismatches, 'allowed_native_deltas': prepared['changed_files']}


try:
    record['source_before'] = audit()
    assert record['source_before']['passed'], 'prepared source audit failed'
    overrides = dict(CARGO_TARGET_DIR=str(ROOT / 'target'), CARGO_BUILD_JOBS='4', RAYON_NUM_THREADS='8', RUST_MIN_STACK='134217728', INSTA_UPDATE='no', NEXTEST_RETRIES='0')
    if args.action == 'build':
        for action in ('fmt', 'check', 'build', 'clippy'):
            cargo = ['cargo', 'fmt', '--all', '--check'] if action == 'fmt' else ['cargo', action, '--offline', '--locked', '-p', 'gammaloop-api', '--bin', 'gammaloop', '--profile', 'dev-optim', '-j', '4']
            result = measure.guarded(out, action, ['timeout', '--signal=TERM', '--kill-after=15s', '1800s', *cargo], overrides)
            record['stages'].append(result)
            measure.write(out / 'receipt.json', record)
            if result['status'] != 'PASS':
                record['status'] = result['status']
                raise RuntimeError(f'{action} did not pass')
        binary = out / 'gammaloop-owner-capture'
        shutil.copy2(ROOT / 'target/dev-optim/gammaloop', binary)
        record.update(status='PASS_BUILD', binary=str(binary), binary_sha256=measure.digest(binary))
    else:
        build = json.loads(args.build_receipt.read_text())
        assert build['status'] == 'PASS_BUILD' and build['revision'] == prepared['commit']
        assert build['source_audit_sha256'] == record['source_audit_sha256']
        assert measure.digest(build['binary']) == build['binary_sha256']
        card = BASE / 'controls/attachments' / f'{args.revision}-{args.workload}_expression_boundaries.toml'
        text = card.read_text()
        before = tomllib.loads(text)
        imported_graphs = [shlex.split(command)[2] for block in before['command_blocks'] for command in block['commands'] if command.startswith('import graphs ')]
        inventory = json.loads((BASE / 'attachments/run-card-inventory.json').read_text())
        expected_graphs = {row['path']: row['sha256'] for row in inventory['graph_inputs']}
        record['input_graph_sha256'] = {path: measure.digest(path) for path in imported_graphs}
        assert all(expected_graphs.get(path) == value for path, value in record['input_graph_sha256'].items())
        directive = before['cli_settings']['global']['logfile_directive'] + ',' + OWNER_FILTER
        if args.revision == 'c3':
            directive += ',gammalooprs::uv::approx[{stage=cff_branch_numerator_mapped}]=debug,gammalooprs::uv::approx::final_integrand[{span_context}]=debug,gammalooprs::uv::approx::direct_3d::kernel[{stage=direct_3d_taylor_branch}]=debug,gammalooprs::uv::approx::direct_3d::kernel[{stage=direct_3d_taylor_mapped_numerator}]=debug'
        text, count = re.subn(r'(?m)^logfile_directive\s*=.*$', 'logfile_directive = ' + json.dumps(directive), text)
        assert count == 1
        state = out / 'state'
        before['cli_settings']['global']['logfile_directive'] = directive
        before.setdefault('cli_settings', {}).setdefault('state', {})['folder'] = str(state)
        section = re.search(r'(?ms)^\[cli_settings\.state\]\s*\n.*?(?=^\[|\Z)', text)
        if section:
            changed, count = re.subn(r'(?m)^folder\s*=.*$', 'folder = ' + json.dumps(str(state)), section.group())
            assert count == 1
            text = text[:section.start()] + changed + text[section.end():]
        else:
            text += '\n[cli_settings.state]\nfolder = ' + json.dumps(str(state)) + '\n'
        assert tomllib.loads(text) == before, 'card changed beyond logging and fresh state'
        assert before['cli_settings']['global']['n_cores']['generate'] == 1
        effective = out / 'run.toml'
        effective.write_text(text)
        record.update(workload=args.workload, original_card=str(card), original_card_sha256=measure.digest(card), effective_card_sha256=measure.digest(effective), binary=build['binary'], binary_sha256=build['binary_sha256'], build_receipt=str(args.build_receipt), build_receipt_sha256=measure.digest(args.build_receipt))
        overrides[STOP] = '1'
        result = measure.guarded(out, 'runtime', ['timeout', '--signal=TERM', '--kill-after=10s', '120s', build['binary'], '-n', '-s', str(state), str(effective), 'run', 'generate'], overrides)
        record['stages'].append(result)
        rows = []
        for logfile in sorted((state / 'logs').glob('*.jsonl')):
            for lineno, line in enumerate(logfile.read_text().splitlines(), 1):
                row = json.loads(line)
                row['_logfile'] = str(logfile)
                row['_line'] = lineno
                rows.append(row)
        expected_count = 6 if args.workload == 'g_gl1' else 16
        owners = [row for row in rows if row.get('stage') in OWNER_STAGES]
        counts = {stage: sum(row.get('stage') == stage for row in owners) for stage in OWNER_STAGES}
        pre_network = [row for row in rows if row.get('stage') == 'evaluator_stack_parse_atom_before_network_parse']
        forbidden = [row.get('stage') for row in rows if row.get('stage') in ('evaluator_stack_parse_atom_terms_start', 'evaluator_stack_parse_atom_net_done', 'evaluator_stack_parse_atom_execute_done')]
        sentinel_seen = ('stopped after evaluator pre-network parse dump because ' + STOP + ' is set') in (out / 'runtime/stdout.log').read_text()
        record['capture_checks'] = {'expected_node_count': expected_count, 'node_counts': counts, 'pre_network_records': len(pre_network), 'forbidden_tensor_stages': forbidden, 'expected_stop_sentinel': sentinel_seen}
        if args.revision == 'c3':
            map_rows = [row for row in rows if row.get('stage') == 'cff_branch_numerator_mapped']
            cograph_rows = [row for row in map_rows if row.get('span', {}).get('name') == 'build_direct']
            record['capture_checks']['map_records'] = len(map_rows)
            record['capture_checks']['cograph_map_records_with_build_direct_span'] = len(cograph_rows)
            record['capture_checks']['cograph_spans_have_current'] = all('current' in row.get('span', {}).get('fields', '') for row in cograph_rows)
            measure.write(out / 'numerator-map-records.json', map_rows)
            taylor_rows = [row for row in rows if row.get('stage') in ('direct_3d_taylor_branch', 'direct_3d_taylor_mapped_numerator')]
            taylor_counts = {stage: sum(row['stage'] == stage for row in taylor_rows) for stage in ('direct_3d_taylor_branch', 'direct_3d_taylor_mapped_numerator')}
            record['capture_checks']['taylor_caller_counts'] = taylor_counts
            measure.write(out / 'taylor-caller-records.json', taylor_rows)
        payloads = out / 'owners'
        payloads.mkdir()
        owner_index = []
        for index, row in enumerate(owners):
            metadata = {key: value for key, value in row.items() if key not in ('atom', 'orientation_parametric_atom')}
            for field in ('atom', 'orientation_parametric_atom'):
                if field in row:
                    path = payloads / f'{index:03}-{field}.atom'
                    path.write_text(row[field])
                    metadata[field] = {'path': str(path), 'sha256': measure.digest(path), 'utf8_bytes': path.stat().st_size}
            owner_index.append(metadata)
        measure.write(out / 'owner-index.json', owner_index)
        record['owner_index_sha256'] = measure.digest(out / 'owner-index.json')
        assert result['status'] in ('PASS', 'CHILD_FAILURE'), result['status']
        assert sentinel_seen and len(pre_network) == 1 and not forbidden
        assert all(value == expected_count for value in counts.values()), counts
        if args.revision == 'c3':
            assert map_rows and cograph_rows and record['capture_checks']['cograph_spans_have_current'], 'C3 map/caller capture incomplete'
            assert len(set(taylor_counts.values())) == 1 and all(taylor_counts.values()), 'C3 Taylor caller capture incomplete'
        assert measure.digest(build['binary']) == build['binary_sha256']
        record['status'] = 'PASS_CAPTURE_EXPECTED_DIAGNOSTIC_STOP'
except BaseException as error:
    if record['status'] == 'STARTED':
        record['status'] = 'CAPTURE_OR_BUILD_FAILURE'
    record['error'] = repr(error)
finally:
    record['source_after'] = audit()
    if not record['source_after']['passed']:
        record['status'] = 'SOURCE_INTEGRITY_FAILURE'
    record['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    measure.write(out / 'receipt.json', record)
    print(json.dumps({'status': record['status'], 'receipt': str(out / 'receipt.json')}), flush=True)
if record['status'] not in ('PASS_BUILD', 'PASS_CAPTURE_EXPECTED_DIAGNOSTIC_STOP'):
    sys.exit(1)

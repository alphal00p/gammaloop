"""Inspect frozen canonical strings; retain every sum/product and symbol attribute."""

import collections
import hashlib
import json
from pathlib import Path

BASE = Path('/tmp/raised-energy-causal-20260914')
SOURCE = BASE / 'c6-c7-direct-boundaries/grouping-identity/run-01'
OUT = BASE / 'uv-boundaries/grouping-residual-review'
OUT.mkdir(exist_ok=False)
parser_path = Path('/tmp/raised-energy-expression-perf-20260914/upstream-expression-analysis/analyze-captured-structure.py')
ns = {}
exec(parser_path.read_text().split('records=[]')[0], ns)


def positions(text, operators):
    depth = braces = 0
    found = []
    for i, char in enumerate(text):
        if char == '{':
            braces += 1
        elif char == '}':
            braces -= 1
        elif braces:
            continue
        elif char == '(':
            depth += 1
        elif char == ')':
            depth -= 1
        elif depth == 0 and char in operators:
            if char in '+-' and (i == 0 or text[i - 1] in '+-*/^,'):
                continue
            if char in '+-' and i > 1 and text[i - 1] in 'eE' and text[i - 2].isdigit():
                continue
            found.append((i, char))
        assert depth >= 0 and braces >= 0
    assert depth == braces == 0
    return found


ns['positions'] = positions
parse = ns['parse']
walk = ns['walk']
paths = [SOURCE / f'results/pass3-common_factors-side{side}.atom' for side in [0, 1]]
roots = [parse(path.read_text()) for path in paths]
assert all(root.kind == 'mul' and len(root.children) == 25 for root in roots)
factors = [collections.Counter(child.text for child in root.children) for root in roots]
common = factors[0] & factors[1]
assert sum(common.values()) == 24
remaining = [list((factor - common).elements()) for factor in factors]
assert all(len(items) == 1 for items in remaining)
common_text = '*'.join('(' + text + ')' for text in common.elements())
(OUT / 'complete-common-factor.atom').write_text(common_text)
residuals = []
alphabets = []
for label, path, items in zip(['c6', 'c7'], paths, remaining):
    text = items[0]
    root = parse(text)
    assert root.kind == 'add'
    result_path = OUT / f'{label}-complete-residual.atom'
    result_path.write_text(text)
    counts = collections.Counter(
        node.text for _, node in walk(root)
        if node.kind == 'fun' and node.name.split('::')[-1] in ns['TENSOR_NAMES']
    )
    alphabets.append(counts)
    arms = []
    for index, arm in enumerate(root.children):
        arm_path = OUT / f'{label}-existing-arm{index:02d}.atom'
        arm_path.write_text(arm.text)
        tensor_factors = [node for node in ns['factors'](arm) if node.tensor]
        arms.append(dict(index=index, path=str(arm_path), sha256=hashlib.sha256(arm.text.encode()).hexdigest(),
                         utf8_bytes=len(arm.text.encode()), direct_factor_count=len(ns['factors'](arm)),
                         direct_tensor_factors=[dict(kind=n.kind, utf8_bytes=len(n.text.encode()), digest=n.digest) for n in tensor_factors]))
    residuals.append(dict(side=label, full_source=str(path), full_source_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                          path=str(result_path), sha256=hashlib.sha256(text.encode()).hexdigest(),
                          existing_add_arms=len(root.children), arms=arms,
                          tensor_leaf_occurrences=sum(counts.values()), tensor_leaf_unique=len(counts),
                          tensor_leaf_counts=[dict(atom=atom, occurrences=n) for atom, n in sorted(counts.items())]))
report = json.loads((SOURCE / 'results/report.json').read_text())
result = dict(
    status='PASS_EXACT_COMMON_FACTOR_RESIDUAL_EXTRACTION',
    scope='Final outputs of the completed four-pass public-API diagnostic; this is structural extraction, not an equality proof of the complete residuals.',
    parser='Existing balanced AST parser with explicit brace depth for canonical symbol attributes. No metadata stripping or relabeling, no expansion, no factor collection, no algebraic simplification.',
    original_parser_sha256=hashlib.sha256(parser_path.read_bytes()).hexdigest(),
    source_receipt=str(SOURCE / 'receipt.json'), comparison_status=report['status'],
    exact_common_direct_factors=24, complete_direct_factors_per_side=25,
    common_factor_path=str(OUT / 'complete-common-factor.atom'),
    common_factors=[dict(atom=t, multiplicity=n, sha256=hashlib.sha256(t.encode()).hexdigest()) for t, n in common.items()],
    residuals=residuals,
    residual_tensor_leaf_alphabets_equal=alphabets[0].keys() == alphabets[1].keys(),
    residual_tensor_leaf_occurrence_multisets_equal=alphabets[0] == alphabets[1],
    unique_left_tensor_leaves=list(alphabets[0].keys() - alphabets[1].keys()),
    unique_right_tensor_leaves=list(alphabets[1].keys() - alphabets[0].keys()),
    fixed_point_certified=False,
    review=[
        'The four-pass bound was reached while the output states were still changing. UNEQUAL_AT_THIS_BOUNDARY is inconclusive about symbolic equality.',
        'Source reachability excludes locally_expand_residual_product_boundary: simplify_metrics uses SchoonschipWithSettings::run/apply_once with metric replacements and DotNormalizer, not network contraction. The local expansion is under a separate EXPANDSUMS sum-by-sum contraction path.',
        'The launcher omitted run.py from pins and duplicated preparation.json; it did not assert prepared source/runner digests, watchdog digest, or full metadata against the dependency audit. Before/after tracked native Git blob and mode audits did pass. Runtime has a120-second cap; build stages did not have a time cap.',
        'No original preparation, receipt, report, input, or generated output was modified by this review.',
    ],
)
(OUT / 'review.json').write_text(json.dumps(result, indent=2, ensure_ascii=False) + '\n')
print(json.dumps({k: v for k, v in result.items() if k not in ['common_factors', 'residuals']}, indent=2))

# Owner-certified C1/C3 UV comparison

Prepared from pinned diagnostic sources and existing logs only. No production or
scratch Rust source was changed; no generation, build, tensor execution, or
licensed launcher/environment inspection was performed.

C1: `665658b168981c5c508e6cd51d3b57bbb55a27fb`.
C3: `3ea313789a1a5290093579febd7d1c601b92594e`.
Source roots: `/tmp/raised-energy-expression-perf-20260914/diagnostic-workspaces/{c1,c3}`.
All source references below are relative to those roots.

## What is established

The same conceptual graph/forest orchestration precedes different residue
representations. C1 attaches a parametric-sign cograph numerator after local
CFF assembly and calls `collect_factors`; C3 attaches a complete numerator per
exact residue key, materializes selectors, then simplifies without that
collection. The first differing intermediate is earlier than tensor parsing.
Actual proper-UV input equality across this boundary is still uncertified.

The four complete upstream logs contain no `hedge_poset_4d_node_done` or
`direct_3d_taylor_branch` events. Their final-builder summary has no source,
current, given, node, or operation key. Existing expression-term ordinals cannot
be joined to owners. The logger also writes `graph: true` for the `#graph` tag;
new payloads should use `graph_name`, not reuse `graph` as a string field.

| Workload | C1 final-builder calls | C3 final-builder calls | C1 Taylor kernel calls | C3 Taylor kernel calls |
|---|---:|---:|---:|---:|
| physical projected g→g GL1 | 6 | 6 | 10 | 90 |
| selected orientation58 attachment | 16 | 16 | 34 | 20 |

These are counted log events, not certified matching node/sector inventories.
Fewer Taylor calls on the attachment excludes total call-count growth as a
sufficient common explanation. The added GL1 calls may reflect exact key
splitting; their source content must be captured before interpreting cost.
`inspect-existing.py` reproduces these counts; `existing-log-coverage.json`
contains the log hashes and complete stage-count inventory.

## Existing selectors and hooks

Attachment settings are already physically selective:

```toml
[cli_settings.global.generation]
explicit_orientation_sum_only = false
[cli_settings.global.generation.orientation_pattern]
pat = "(0,0,+,+,-,-,+,+,+,-)"
[cli_settings.global.generation.uv]
final_integrand = "ThreeD"
local_uv_cts_from_expanded_4d_integrands = false
subtract_uv = true
generate_integrated = false
add_marker = false
inner_products = true
orchestrator = "hedge_poset"
```

Do not replace this by an assumed literal production ID on C1. At C3 the
catalog must establish that the physical pattern selects exactly stored host
58; source maps hosted by 58 may still differ. `sigma(58)` selects an opaque
host; `σ(edge)` supplies an edge sign. They are different parameters.

The GL1 selector is the unchanged generation request `generate amp g > g [{2}]
| g u`, graph `GL1`, process `double_triangle`, integrand `2L`, with the native
projector from the preserved input card. Its baseline has integrated UV on,
softct off, thresholds off, and evaluator algebra on. Keep this baseline, then
use the already meaningful local-only control for reducing the dominant local
owner; label that change in the receipt. Do not silently make the two physics
contents equivalent.

Existing native log filters (they select real events on the named revisions):

```text
off,gammalooprs::uv::hedge_poset[{stage=hedge_poset_4d_node_done}]=debug,gammalooprs::uv::approx::final_integrand[{#generation,#summary}]=debug
```

C3 adds a complete kernel entry with current/given/reduced, active subgraph,
selector host, optional source energy map, coordinate LMB, and incoming body:

```text
gammalooprs::uv::approx::direct_3d::kernel[{stage=direct_3d_taylor_branch}]=debug,gammalooprs::uv::approx::direct_3d::kernel[{stage=direct_3d_taylor_mapped_numerator}]=debug,gammalooprs::uv::approx::direct_3d::kernel[{stage=direct_3d_taylor_started}]=debug,gammalooprs::uv::approx::direct_3d::kernel[{stage=direct_3d_coordinate_lmb}]=debug
```

Kernel source is C3 `uv/approx/direct_3d/kernel.rs:219,255,274,292` (all under
`crates/gammalooprs/src/`). The payload expressions there use `%atom`, so add
namespace-preserving `to_plain_string()` only in the scratch source if needed;
never infer full symbol identity from pretty names. The original unmapped
numerator is a local variable at line 268 but is not currently logged.

C1's analogous existing entry/output checkpoints are in
`uv/approx/local_3d.rs:644,669,691` (`local_3d_start_initial`,
`local_3d_start_after_ose_full`, `local_3d_start_output`). They lack current/given
in the event itself. Neither their position in the file nor timestamp adjacency
certifies a particular owner.

## Existing public calls, and a bounded execution route

The existing public API can stop before building an evaluator:

```rust
ProcessList::preprocess(
    &mut self,
    model: &Model,
    settings: &GlobalSettings,
    locked_runtime_settings: &LockedRuntimeSettings,
    thread_pool: &ThreadPool,
) -> Result<Vec<GeneratedGraphReport>>
```

It exists at C1 `processes/mod.rs:516`, C3 `:517`. `Amplitude::preprocess`
(C1 `processes/amplitude.rs:371`, C3 `:372`) is the corresponding one-amplitude
entry. At C3 its graph path is `generate_cff` → `build_integrands` → disabled
threshold/tropical setup → LMB/channel metadata. `ProcessList::generate_integrands`
is a separate later call. A scratch public-API executable can execute the
existing import/only-diagrams setup, invoke preprocess once, read the public
`Amplitude.graphs[*].derived_data.all_mighty_integrand`, and exit successfully.
This is preferable to letting a complete generate call reach a 30-GB tensor
workload and killing it after the desired capture. It needs no production API
addition. It still computes the normal 4D forest pass even with integrated UV
disabled; do not claim otherwise.

Existing public computed-export call:

```rust
ProcessList::export_uv_forests(
    &self, path: impl AsRef<Path>, process_id: usize,
    integrand_name: &str, graph_ids: &[usize],
    settings: &UVForestExportSettings,
) -> Result<()>
```

Exact CLI selectors, with a new output directory outside the loaded state:

```text
save uv-forest /tmp/raised-energy-causal-20260914/uv-boundaries/FRESH_EXPORT -p name:double_triangle -i 2L --graph GL1
save uv-forest /tmp/raised-energy-causal-20260914/uv-boundaries/FRESH_COMPUTED_EXPORT -p name:double_triangle -i 2L --graph GL1 --computed
```

This export requires an already generated integrand, so it is an immediate
option for the saved GL1 states, not an alternative to initial attachment
preprocessing. It recomputes forests; it does not retrieve old per-node bodies.
The computed node DOT holds full numerator in Typst syntax, not plain Atom
syntax. Both C1/C3 apply an additional `(2*pi)^(-3L)` amplitude-export factor;
record and invert this known boundary explicitly before comparing production
amplitudes. Forest DOT is useful for Foata keys/cover/incidence, not an exact
plain-expression interchange format. Public export syntax is in
`crates/gammaloop-api/src/commands/save.rs:57,151`, implementation in
`processes/mod.rs:478`, `processes/process.rs:846`, and `uv/export.rs:261`.

## Smallest missing capture: extend existing loops in isolated scratch only

No new helper function, struct, method, production switch, or algebraic rewrite
is required. Reuse the existing owner and iteration variables in the following
functions, after source auditing the scratch copy against its pin.

1. In `Forests::compute`, surround `local_3d_for_node` with a structured owner
   record carrying graph_name, cut selector, raw node index, operation key,
   cover, source spinney, union flag, and operation count. This establishes a
   deterministic serial caller envelope, not an inference from line adjacency.
2. In `Forests::orientation_parametric_exprs`, log each complete per-node
   `CutCFFIndex`/Atom before and after its existing `collect_color()`, before
   `zip_add`. C1 location `uv/hedge_poset.rs:1221`; C3 `:1327`. Log through the
   existing `FinalIntegrands::iter` on C1. On C3 the method is test-only, so
   iterate the already available `into_integrands()` on a diagnostic clone, or
   use the existing `.map` callback to capture bodies together with its exact
   cut key in a neighboring `into_integrands` loop. Do not widen the API just
   for the probe. Record `to_plain_string()` and `get_byte_size()` separately.
3. At C3 `FinalIntegrandBuilder::build_direct` (`final_integrand.rs:90–121`),
   capture its existing `resnum`, `localized_integrated`, `localized_local`,
   and `final_branches`, using `iter_keys()` and each `Integrands::iter()`.
   Pair each key with `selector_host`, full `DirectEnergyMap` (Production vs
   complete Source vector), mapped numerator and complete coefficient body.
   `DirectResidueKey::map_numerator` is the exact current implementation; it
   must be used on the same numerator without substituting sign-only guesses.
4. At C1 `FinalIntegrandBuilder::build_3d` (`final_integrand.rs:99–143`), capture
   the same reduced cograph numerator before/after parametric signs,
   `localized_integrated`, `local_terms`, combined `final_int`, and the complete
   product before/after existing `collect_factors`. Keep graph numerators
   intact. This is where to certify whether factoring/mapping first diverge.
5. Emit the final aggregate after `split_momentum_replacements` and den-wrapper
   removal; require exact reassembly from the complete owner contributions.
   The graph sum, not a term-order match, must reproduce `all_mighty_integrand`.

Add plain atom payloads at the current Taylor source locations only if steps
2–4 identify the first unequal owner there. The broad all-forest capture should
be counts/keys/packed bytes; full detailed Taylor payloads should then be
restricted to that owner. Never use the exporter ordinal as the raw forest
index: computed DOT's `node_index` is compatible-topological enumeration,
whereas 4D log `node_index` is the internal `NodeIndex`.

`add_marker=true, keep_marker=true` is an existing optional alternative for
visualizing UV operation history (`uv/marker.rs`). It decorates expressions and
can affect canonical grouping, and its subgraph-history marker is not the
complete direct residue key. It is therefore useful supporting evidence, not
a replacement for the unmodified-expression owner capture or a timing A/B.

## Required causal certificate and next comparison

Each row must bind: source graph hash and factorized edge/vertex/global
numerators; model/parameter hashes; exact graph ID/name and edge occurrence
incidence; source spinney and full operation/Foata key; dependency frontier,
current/given and reduced subgraphs; cut/residue order; final-integrand mode;
local vs integrated caller; coordinate LMB and momentum-routing assignments;
active/frozen owner fields; complete exact source key and production host;
physical direction vector; selector truth-table value; complete scalar
coefficient/denominator and numerator factors; every prefactor and subtraction
sign. Production/source-map numerator energy assignments are distinct fields.

At C3, `apply_taylor` explicitly does not add the subtraction minus.
`Direct3dApproximation::run_local` (forest.rs:367) and `run_integrated` (:427)
negate their active branch results once. Root `production_prefactor_factor()`
is attached in `Direct3dCts::root` (:140) separately. `DirectSector::combine`
(:67) materializes scoped vacuum masses and multiplies frozen factors on an
output copy. Preserve those boundaries and do not infer signs from UV order.

First choose the greatest contributing nonempty owner by complete packed input
size, tensor-bearing sum structure, and native preparation/contraction cost
where an owner can be replayed. Size alone is only a ranking hint. For the
attachment, first join the existing three-term/eight-gamma witness to this
owner map; do not assume it is a particular bubble/overall node from its gamma
subset. For GL1, reduce the dominant proper-UV owner; use its bare root only
as the independent sign/catalog control already motivated by prior evidence.

Before any engine blame, prove source-owner/denominator correspondence and the
selector partition: evaluate every production host against the full direction
catalog; establish exactly one host selection per explicit branch, including
all source maps sharing a host. Compare `sum(selector * body)` with explicit
`sum(body)`, after each body's own numerator map. Then compare C1/C3 scalar
weights with an exact denominator-only identity while preserving tensor
factors. A failed source reconstruction/owner/sign check stops downstream
attribution.

Pre-network normalization for a chosen complete owner must use existing
production calls: GL1 `simplify_color_with(default cof invariants)` →
`simplify_gamma()` → `simplify_metrics().to_dots()`; attachment
`to_cof_dimension_invariants()`. C3 code is
`integrands/process/evaluators.rs:574–632`. Independently normalizing owners can
change across-owner common-factor simplification, so certify that their sum
matches the native normalized aggregate before treating it as a production
input partition. Capture full tensor incidence, nested tensor-bearing Add/Mul
nodes, sum arities, vector argument compaction, and common exact factors.

Only after these input certificates run two owner-complete inputs through the
same immutable public replay executor (the existing common-factor probe is a
starting point), one change at a time. First compare vector-compaction/grouping
with all denominators and tensor factors preserved; global collect_factors is
not a justified remedy because it can join distinct denominator topologies.
Timing excludes log serialization; use fixed limits, fresh outputs and terminal
receipts. Retain in-memory exact output checks when possible; decimal text
round-trips previously lost coefficient precision and cannot certify exact
returned-value equality.

The single next useful measurement is therefore a preprocessing-only C1/C3
owner capture, not another full sparse attachment run. Existing plain aggregate
captures plus counts cannot yet name the dominant proper-UV owner or prove the
cause of the overall slowdown.

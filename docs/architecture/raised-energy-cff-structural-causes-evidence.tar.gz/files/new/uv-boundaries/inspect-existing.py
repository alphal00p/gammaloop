from pathlib import Path
from collections import Counter
import hashlib
import json

base = Path('/tmp/raised-energy-expression-perf-20260914')
out = Path('/tmp/raised-energy-causal-20260914/uv-boundaries')
records = []
for revision in ('c1', 'c3'):
    for workload in ('g_gl1', 'orientation58'):
        logfile, = (base / 'controls/measurements' / revision / f'run-{workload}_expression_boundaries-01/state/logs').glob('*.jsonl')
        rows = [json.loads(line) for line in logfile.read_text().splitlines()]
        counts = Counter(row.get('stage', '') for row in rows)
        final_calls = [row for row in rows if row.get('message') == 'Computed global numerator']
        records.append({
            'revision': revision, 'workload': workload,
            'logfile': str(logfile), 'sha256': hashlib.sha256(logfile.read_bytes()).hexdigest(),
            'row_count': len(rows), 'final_builder_events': len(final_calls),
            'taylor_kernel_events': counts['local_3d_kernel_after_start'] + counts['direct_3d_kernel_after_start'],
            'four_d_owner_events': counts['hedge_poset_4d_node_done'],
            'direct_branch_owner_events': counts['direct_3d_taylor_branch'],
            'final_builder_keys': sorted(set().union(*(row.keys() for row in final_calls))),
            'stage_counts': dict(sorted(counts.items())),
        })
(out / 'existing-log-coverage.json').write_text(json.dumps(records, indent=2) + '\n')
print(json.dumps([{k: r[k] for k in ('revision', 'workload', 'final_builder_events', 'taylor_kernel_events', 'four_d_owner_events', 'direct_branch_owner_events')} for r in records], indent=2))

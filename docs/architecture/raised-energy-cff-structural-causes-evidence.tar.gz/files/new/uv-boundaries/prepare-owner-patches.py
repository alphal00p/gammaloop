from pathlib import Path
import difflib
import hashlib
import json

base = Path('/tmp/raised-energy-expression-perf-20260914/diagnostic-workspaces')
out = Path('/tmp/raised-energy-causal-20260914/uv-boundaries')
relative = Path('crates/gammalooprs/src/uv/hedge_poset.rs')
metadata = []
for revision in ('c1', 'c3'):
    path = base / revision / relative
    original = path.read_text()
    modified = original
    anchor = '''                let cut_computation =
                    self.local_3d_for_node(nidx, graph, &cutset, localizer, settings)?;
'''
    assert modified.count(anchor) == 1
    store_iter = 'cut_computation.final_integrands.iter()' if revision == 'c1' else 'cut_computation\n                    .final_integrands\n                    .clone()\n                    .into_integrands()\n                    .iter()\n               '
    store = f'''                for (residue_index, atom) in {store_iter} {{
                    debug_tags!(#generation, #uv, #graph, #term, #inspect, #dump;
                        stage = "hedge_poset_final_node_before_store",
                        graph_name = %graph.name,
                        node_index = %nidx,
                        order,
                        forest_term = %operation,
                        operation_count = operation.key.op_count(),
                        cover = ?operation.covers().map(|cover| cover.string_label()),
                        source = %self.source_spinney(nidx).filter().string_label(),
                        source_loop_edges = ?self.source_spinney(nidx).lmb.loop_edges,
                        is_union = self.graph.is_disjoint_union(nidx),
                        cutset = ?cutset,
                        residue_index = ?residue_index,
                        byte_size = atom.as_view().get_byte_size(),
                        file.atom = %atom.to_plain_string(),
                        "Owner-bound final integrand before forest storage"
                    );
                }}
'''
    modified = modified.replace(anchor, anchor + store)
    start = modified.index('    pub(crate) fn orientation_parametric_exprs(')
    end = modified.index('    pub(crate) fn export_node_expressions(', start)
    section = modified[start:end]
    anchor = '''                sum = Some(match sum {
'''
    assert section.count(anchor) == 1
    aggregate_iter = 'terms.iter()' if revision == 'c1' else 'terms.clone().into_integrands().iter()'
    aggregate = f'''                for (residue_index, atom) in {aggregate_iter} {{
                    let orientation_parametric_atom = atom
                        .replace_multiple(&split_momentum_replacements)
                        .replace(function!(GS.den, W_.a_, W_.b_, W_.c_, W_.d_))
                        .with(W_.d_);
                    debug_tags!(#generation, #uv, #graph, #term, #inspect, #dump;
                        stage = "hedge_poset_final_node_before_aggregation",
                        graph_name = %graph.name,
                        node_index = %nidx,
                        forest_term = %operation,
                        operation_count = operation.key.op_count(),
                        cover = ?operation.covers().map(|cover| cover.string_label()),
                        source = %self.source_spinney(nidx).filter().string_label(),
                        source_loop_edges = ?self.source_spinney(nidx).lmb.loop_edges,
                        is_union = self.graph.is_disjoint_union(nidx),
                        cutset = ?cutset,
                        residue_index = ?residue_index,
                        byte_size = atom.as_view().get_byte_size(),
                        file.atom = %atom.to_plain_string(),
                        file.orientation_parametric_atom = %orientation_parametric_atom.to_plain_string(),
                        "Owner-bound final integrand before forest aggregation"
                    );
                }}
'''
    section = section.replace(anchor, aggregate + anchor)
    modified = modified[:start] + section + modified[end:]
    patch = ''.join(difflib.unified_diff(original.splitlines(keepends=True), modified.splitlines(keepends=True), fromfile=f'a/{relative}', tofile=f'b/{relative}'))
    (out / f'{revision}-owner-capture.patch').write_text(patch)
    preview = out / f'{revision}-hedge_poset.rs'
    preview.write_text(modified)
    metadata.append({'revision': revision, 'source': str(path), 'source_sha256': hashlib.sha256(original.encode()).hexdigest(), 'patch': str(out / f'{revision}-owner-capture.patch'), 'patch_sha256': hashlib.sha256(patch.encode()).hexdigest(), 'preview': str(preview), 'mutated_source': False, 'compiled': False})
(out / 'owner-patch-manifest.json').write_text(json.dumps(metadata, indent=2) + '\n')
print(json.dumps(metadata, indent=2))

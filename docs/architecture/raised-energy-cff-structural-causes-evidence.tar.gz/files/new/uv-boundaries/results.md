# Owner-certified C1/C3 UV captures

The four native pre-network inputs are unchanged by the isolated logging patches.
`full-pre-network-identity.json` records exact UTF-8 equality to the prior captures,
after removing only outer whitespace. Source checks passed before and after every
build/capture against immutable Git trees, with only the reviewed logging and C3
diagnostic-stop changes allowed. The original workspace was not modified.

| Pin | Commit | Native tree |
| --- | --- | --- |
| C1 | `665658b168981c5c508e6cd51d3b57bbb55a27fb` | `c3332f4fc05fdd3369d0ef15b48c5fc5ded29bdf` |
| C3 | `3ea313789a1a5290093579febd7d1c601b92594e` | `339cb1816585d275240f5f8094794fad83a3ecfc` |

Both native builds passed format, check, optimized build, and clippy in order,
with locked dependencies, offline Cargo, four build jobs, eight Rayon workers,
and a 30 GB RSS guard. The capture uses one generation core, the unchanged prior
workload card, and the native public CLI. It stops deliberately after logging the
complete pre-network Atom, before network parsing or tensor contraction.

| Capture | Owner records before store / aggregation | Map records | Result |
| --- | --- | --- | --- |
| C1 attachment orientation58 | 16 / 16 | not instrumented | expected diagnostic stop |
| C1 physical GL1 | 6 / 6 | not instrumented | expected diagnostic stop |
| C3 attachment orientation58 | 16 / 16 | 36 | expected diagnostic stop |
| C3 physical GL1 | 6 / 6 | 216 | expected diagnostic stop |

All four have exactly one complete pre-network event, the expected stop sentinel,
and no forbidden tensor stage. Each `attempts/<pin>/run-<workload>-01` directory
contains its original raw log, full owner Atom payloads, owner index, and capture
receipt. C1 attachment's original receipt preserves the driver's initial mistaken
expectation of a nonzero CLI exit; its separate `capture-assessment.json` confirms
all semantic checks passed. The native CLI handles the deliberate stop and exits
zero. There was no rerun or source/oracle change to repair that bookkeeping.

The C3 GL1 caller audit in `gl1-owner-map-audit/proof.json` certifies every primary
map call, using consecutive native Taylor call/map/return events or integrated
localizer completion events, and the actual `build_direct` span for final cograph
maps. A sequential final-owner storage boundary assigns those calls to their
forest operation; no final term ordering, size, or timestamp heuristic is used.

- 90 maps attach a newly owned numerator before a Taylor operation.
- 15 maps belong to integrated counterterm localization.
- 111 maps attach the final cograph numerator.
- 120 primary records carry a `build_direct` span, including nine integrated
  localization calls; that span count alone is not a cograph-call count.

All 1,512 applied edge-map rows are zero or diagonal signed OSE substitutions.
The 180 production maps have nonzero slots on internal edges 2–6. The 36 explicit
source maps retain subsets {2,3} (10 records), {5,6} (15), {6} (5), or no energy
slots (6). None contains an affine shift or an off-diagonal linear combination.
Unpaired external slots 0 and 1 are skipped by native `energy_map_replacements_gs`;
their four-momenta remain external. Zero internal slots mean zero temporal energy,
with spatial Q3 retained. All 216 production *loop-coordinate metadata* maps have
external shifts. Those metadata maps are not the applied edge-energy replacements.

The proper UV owner is internal node 3, forest `{140}`, source/cover `140`, with
loop carriers 3 and 5. Its eighteen Taylor calls have current `140/topo0/dod2`,
given `empty/topo0/dod0`, active/reduced subgraph `140`, hosts 0–17, and no explicit
source override. The complete unmapped numerator is identical across all eighteen
calls. The decoded signed edge maps exactly match the corresponding physical
orientations, and the recorded return from each Taylor mapper exactly matches its
primary complete mapped numerator after removing only printer namespaces and
whitespace. Complete numerator and CFF-weight files are retained separately in
`gl1-owner-map-audit`, with hashes and full caller identities in its proof.

That owner has an existing outer factor multiplying an Add of nineteen arms:
one integrated contribution and eighteen local contributions. The separate hot
structure task owns its factor-preserving join to evaluator terms and the complete
parametric-numerator template certificate. This map audit does not infer physical
source incidence from map signatures and does not claim an algebraic identity for
the post-Taylor hot coefficient from the pre-Taylor numerator alone.

No heavy process remains from this work. Ruff was unavailable both in the supplied
Python and on PATH; the final map-audit script ran successfully as bounded pure
Python without invoking Symbolica or native tensor work.

# Concrete isolated owner capture

Prepared source directories already exist:

- `sources/c1`, exact tree `c3332f4fc05fdd3369d0ef15b48c5fc5ded29bdf` with only
  `uv/hedge_poset.rs` logging additions.
- `sources/c3`, exact tree `339cb1816585d275240f5f8094794fad83a3ecfc` with the
  same owner logging and the small `c3-pre-network-stop.patch` addition.

`c1-source-audit.json` / `c3-source-audit.json` bind every tracked file to its
native Git blob and prepared SHA-256; file modes were checked. Native Cargo.lock
and model sources remain unchanged. Archives were read from the review repo's
pinned commits; no Git/JJ checkout or current working copy was mutated.

Correction to the earlier API survey: C1 has an existing native CLI stop hook,
`GAMMALOOP_STOP_AFTER_EVALUATOR_PRE_NETWORK_PARSE`, at evaluator line 541. C3
removed it. The C3 scratch patch reinstates only that conditional stop at the
matching full pre-network log, using the same setting name. This preserves
native graph generation, all UV construction, and native color/gamma preparation,
then returns the deliberate diagnostic error before tensor parsing/execution.
It avoids a new public API or preprocessing driver and captures the exact
pre-network boundary needed for the hot tensor contributions.

Only Python compilation and standalone Rust syntax/format checks have run.
No Cargo build, CLI generation, tensor workload, or benchmark has run. The
licensed launcher has not been read, hashed, or copied.

Run these commands sequentially, inspecting each terminal receipt before the
next command. The launcher holds the existing shared measurement lock for the
entire build or capture and uses the unchanged reviewed 30-GB watchdog adapter.
The existing licensed environment launcher is invoked by `measure.guarded`;
its contents are neither inspected nor included in evidence.

```sh
/tmp/raised-stack/python /tmp/raised-energy-causal-20260914/uv-boundaries/owner-capture.py build c1 --attempt 01
/tmp/raised-stack/python /tmp/raised-energy-causal-20260914/uv-boundaries/owner-capture.py run c1 --attempt 01 --workload orientation58 --build-receipt /tmp/raised-energy-causal-20260914/uv-boundaries/attempts/c1/build-01/receipt.json
/tmp/raised-stack/python /tmp/raised-energy-causal-20260914/uv-boundaries/owner-capture.py run c1 --attempt 01 --workload g_gl1 --build-receipt /tmp/raised-energy-causal-20260914/uv-boundaries/attempts/c1/build-01/receipt.json
/tmp/raised-stack/python /tmp/raised-energy-causal-20260914/uv-boundaries/owner-capture.py build c3 --attempt 01
/tmp/raised-stack/python /tmp/raised-energy-causal-20260914/uv-boundaries/owner-capture.py run c3 --attempt 01 --workload orientation58 --build-receipt /tmp/raised-energy-causal-20260914/uv-boundaries/attempts/c3/build-01/receipt.json
/tmp/raised-stack/python /tmp/raised-energy-causal-20260914/uv-boundaries/owner-capture.py run c3 --attempt 01 --workload g_gl1 --build-receipt /tmp/raised-energy-causal-20260914/uv-boundaries/attempts/c3/build-01/receipt.json
```

The build action runs native `cargo fmt --all --check`, then
`cargo check`, `cargo build`, and `cargo clippy`, each sequentially with
`--offline --locked -p gammaloop-api --bin gammaloop --profile dev-optim -j 4`
(the formatter uses its own flags). No lock refresh/dependency override is
allowed. Shared target caching matches the preceding native comparison; each
completed build is copied to its fresh attempt directory and hashed before
another revision is built.

Resource controls: four Cargo jobs; eight Rayon workers; 128-MiB worker stacks;
one generation core in each preserved card; 30 decimal GB process-tree RSS;
1800-second cap per build stage and 120-second cap per capture, with bounded
TERM/KILL cleanup. The GNU timeout runs inside the watched process tree.
No retry, tolerance, snapshot, or existing test change is introduced.

The cards come from prior completed upstream captures. A structural TOML check
permits only the logfile directive additions and fresh state path to change.
Attachment stays on its native single physical sign pattern, local-only direct
3D UV; GL1 retains its physical projector and integrated baseline. Imported DOT
hashes are checked against the supplied-input inventory. State and output paths
are fresh and refuse overwrite.

A run is successful only as `PASS_CAPTURE_EXPECTED_DIAGNOSTIC_STOP`. Its raw
child status is retained as `CHILD_FAILURE`: this is deliberately not a passing
native generation benchmark. Success also requires the expected stop text,
one full pre-network record, no tensor parsing/execution stages, and complete
before-store/before-aggregation record counts (6 each for GL1, 16 each for the
attachment). Any deviation is a terminal capture failure requiring inspection,
not a reason to edit an existing test or automatically retry.

Each run writes `owner-index.json`, complete `.atom` payloads under `owners/`,
the full JSONL trace, native measurement receipts, binary/card/source hashes,
and pre/post source audits. Match by graph_name + exact operation key + source
subgraph + CutSet + CutCFFIndex; NodeIndex and output ordinal are supplementary.
The `orientation_parametric_atom` copy applies the same final split/den-wrapper
replacement as native aggregation. Require exact owner reassembly before
joining the attachment six-child rank-10 tensor Add or GL1 hot terms 15/16 to
these owner rows. Do not assign a forest from gamma subsets or term position.

This capture establishes final owner correspondence. It does not by itself
certify exact source-energy-map correspondence inside every local Taylor
branch. If the paired owner already differs before final assembly, activate
the existing C3 direct Taylor map hooks and extend only that source boundary as
described in `plan.md` before attributing any difference to CFF machinery.

## Completed C1 captures and C3 map extension

C1 build 01 passed native format/check/build/Clippy and both source audits.
The attachment capture produced all 16 before-store and 16 before-aggregation
rows, one pre-network atom, and no tensor stages (3.488 s / 55.3 MB). Native CLI
handles the deliberate stop error and exits zero. The original capture driver's
assumption of nonzero exit therefore failed after all semantic checks passed;
its receipt is preserved, with `capture-assessment.json` recording the complete
capture. No repeat was run. The subsequent distinct GL1 capture passed the same
unchanged semantic checks with 6+6 owner records (21.075 s / 109.9 MB). Neither
observation is a complete native generation timing.

Only raw exit bookkeeping was corrected: capture may end with native CLI zero
or nonzero status, but still requires the exact stop sentinel, complete owner
counts, a single pre-network boundary, no tensor work and clean source audit.

Before the first C3 build, `c3-primary-numerator-map.patch` adds the requested
`cff_branch_numerator_mapped` event in existing `OrientationProjection::map_numerator`.
It records complete unmapped/mapped numerator and authoritative edge-energy map
without applying the map twice. `prepare-c3-map.py` prepared the patch and updated
only C3 source audits. The C3 card adds its semantic-stage filter and enables the
existing `FinalIntegrandBuilder::build_direct` debug span with
`gammalooprs::uv::approx::final_integrand[{span_context}]=debug`.
`FileJsonFmt` includes that enabled current span in JSONL (native tracing.rs:688).
The runner checks actual build_direct/current presence and saves all map rows in
`numerator-map-records.json`; missing caller metadata is a capture failure,
not an inferred owner link. C3 remains unbuilt/unrun pending the exclusive slot.

The reviewed C3 configuration additionally enables the two existing
`direct_3d_taylor_branch` and `direct_3d_taylor_mapped_numerator` kernel stages.
Their current/given/source-map fields bind Taylor callers to the new exact
primary-map payload. The runner requires nonzero matching stage counts and
saves `taylor-caller-records.json` alongside `numerator-map-records.json`.
This change only widens diagnostic logging for C3; no extra Taylor computation
or numerator rewrite is introduced.

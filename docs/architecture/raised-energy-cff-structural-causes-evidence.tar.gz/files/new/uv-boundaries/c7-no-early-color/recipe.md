# Prepared C7 early-color reversal

Review `two-early-color-calls.patch`, `pre-network-stop.patch`,
`capture-driver-adaptation.patch`, and `preparation.json` before running.
No native build or execution has been performed for this intervention.

The source archive is native C7 commit
`6d7a9220129c0fac37bdc0e04ebefccb1688c7be`, tree
`b3648e9563ed64ff8a8a68815e1a804b3fcc093b`. Its only functional intervention
removes color simplification before the direct Taylor numerator map and before
the direct final cograph map. The projected-4D color call, branch `zip_add`,
local-4D behavior, all dependencies, and all tests are native C7. The direct
cograph comment is retained and updated. A separate diagnostic stop runs after
the complete pre-network log and before tensor-network parsing.

Once root approves and gives this task the exclusive heavy slot, run sequentially:

```bash
/tmp/raised-stack/python /tmp/raised-energy-causal-20260914/uv-boundaries/c7-no-early-color/capture.py build c7 --attempt 01
/tmp/raised-stack/python /tmp/raised-energy-causal-20260914/uv-boundaries/c7-no-early-color/capture.py run c7 --attempt 01 --workload orientation58 --build-receipt /tmp/raised-energy-causal-20260914/uv-boundaries/c7-no-early-color/attempts/c7/build-01/receipt.json
```

Each action acquires the existing shared measurement lock. The build runs format,
check, optimized compilation, and clippy in order. Cargo is offline and locked;
build jobs are four, Rayon workers eight, worker stacks 128 MiB, and the RSS guard
is 30 decimal GB. Each build stage has an 1,800-second limit. The one-core capture
has a 120-second limit. No update or retry is enabled. Source files and modes are
checked against the prepared native-blob audit before and after each action.

The runtime uses the prior native C7 card, with the same graph, orientation58,
MUV prescription and existing log filters. Only its state path changes. It must
record 20 Taylor call/return pairs, 16 cograph boundaries, 16 final-before-color
boundaries, one complete pre-network expression, the expected stop sentinel,
and no tensor-network stage. The CLI handles the diagnostic stop and can exit
zero; passing requires the semantic boundary checks.

`baseline-comparison.json` compares the complete pre-network UTF-8 strings with
the original C6 and C7 logs after removing only outer whitespace. Equality with
C6 would certify that this intervention restores its actual network input for
this workload. Inequality remains a captured structural result, not a failed
oracle, and does not authorize further transformations or a rerun.

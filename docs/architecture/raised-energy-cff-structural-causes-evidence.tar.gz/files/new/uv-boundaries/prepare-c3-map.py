"""Extend only the unbuilt C3 scratch copy with the requested primary-map event."""
from pathlib import Path
import difflib
import hashlib
import json

out = Path('/tmp/raised-energy-causal-20260914/uv-boundaries')
relative = Path('crates/gammalooprs/src/uv/approx/mod.rs')
source = out / 'sources/c3'
path = source / relative
original = path.read_text()
old = '''        Ok(numerator.replace_multiple(replacements))
'''
assert original.count(old) == 1
new = '''        let mapped_numerator = numerator.replace_multiple(replacements);
        debug_tags!(#generation, #uv, #cff, #numerator, #trace, #dump;
            stage = "cff_branch_numerator_mapped",
            graph_name = %graph.name,
            selector_id = selector_id.0,
            physical_orientation = ?orientation.data.orientation,
            source_map_used = source_edge_energy_map.is_some(),
            file.source_edge_energy_map = ?source_edge_energy_map,
            file.production_loop_energy_map = ?orientation.loop_energy_map,
            file.effective_edge_energy_map = ?source_edge_energy_map.unwrap_or(&orientation.edge_energy_map),
            input_byte_size = numerator.as_view().get_byte_size(),
            output_byte_size = mapped_numerator.as_view().get_byte_size(),
            file.unmapped_numerator = %numerator.to_plain_string(),
            file.mapped_numerator = %mapped_numerator.to_plain_string(),
            "Applied the branch-owned exact energy map to the complete numerator"
        );
        Ok(mapped_numerator)
'''
modified = original.replace(old, new)
path.write_text(modified)
patch = ''.join(difflib.unified_diff(original.splitlines(keepends=True), modified.splitlines(keepends=True), fromfile=f'a/{relative}', tofile=f'b/{relative}'))
(out / 'c3-primary-numerator-map.patch').write_text(patch)
sha = hashlib.sha256(modified.encode()).hexdigest()
audit_path = out / 'c3-source-audit.json'
audit = json.loads(audit_path.read_text())
row, = [row for row in audit['tracked_files'] if row['path'] == str(relative)]
assert row['instrumented_sha256'] == hashlib.sha256(original.encode()).hexdigest()
row['instrumented_sha256'] = sha
audit['changed_files'][str(relative)] = sha
audit['native_changed_paths'] = sorted(audit['changed_files'])
audit_path.write_text(json.dumps(audit, indent=2) + '\n')
prepared_path = out / 'isolated-preparation.json'
prepared = json.loads(prepared_path.read_text())
prepared[1] = {key: value for key, value in audit.items() if key != 'tracked_files'}
prepared_path.write_text(json.dumps(prepared, indent=2) + '\n')
manifest_path = out / 'owner-patch-manifest.json'
manifest = json.loads(manifest_path.read_text())
manifest[1]['primary_map_patch'] = {'path': str(out / 'c3-primary-numerator-map.patch'), 'patch_sha256': hashlib.sha256(patch.encode()).hexdigest(), 'source_file': str(relative), 'native_sha256': hashlib.sha256(original.encode()).hexdigest(), 'instrumented_sha256': sha, 'compiled': False}
manifest_path.write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps(manifest[1]['primary_map_patch'], indent=2))

"""Prepare, but never build/run, the native C7 two-call early-color reversal."""

from pathlib import Path
import difflib
import hashlib
import io
import json
import os
import stat
import subprocess
import tarfile

ROOT = Path('/common/dev/gammaloop/higher-power-energies-review')
BASE = Path('/tmp/raised-energy-causal-20260914/uv-boundaries')
OUT = BASE / 'c7-no-early-color'
COMMIT = '6d7a9220129c0fac37bdc0e04ebefccb1688c7be'
OUT.mkdir(exist_ok=False)
source = OUT / 'sources/c7'
source.mkdir(parents=True)
archive = subprocess.check_output(['git', '-C', str(ROOT), 'archive', '--format=tar', COMMIT])
with tarfile.open(fileobj=io.BytesIO(archive)) as stream:
    stream.extractall(source, filter='data')

changed = {}
patches = []
for name, old, new in [
    ('crates/gammalooprs/src/uv/approx/direct_3d/kernel.rs',
     '.numerator(&reduced, given.subgraph())\n        .color_simplify()\n',
     '.numerator(&reduced, given.subgraph())\n'),
    ('crates/gammalooprs/src/uv/approx/final_integrand.rs',
     '''        // Resolve the cograph's color algebra before residue mapping repeats its
        // momentum numerator. The final pass still closes attached UV/projector
        // color indices that remain open at this boundary.
        let resnum = graph
            .numerator(&reduced, current.subgraph())
            .color_simplify()
''',
     '''        // Diagnostic reversal: retain the cograph's color algebra during
        // residue mapping. The final pass closes its attached UV/projector
        // color indices along with the untouched cograph color factors.
        let resnum = graph
            .numerator(&reduced, current.subgraph())
'''),
]:
    path = source / name
    native = path.read_text()
    assert native.count(old) == 1
    modified = native.replace(old, new)
    path.write_text(modified)
    changed[name] = hashlib.sha256(modified.encode()).hexdigest()
    patches.extend(difflib.unified_diff(native.splitlines(keepends=True), modified.splitlines(keepends=True), fromfile='a/' + name, tofile='b/' + name))
(OUT / 'two-early-color-calls.patch').write_text(''.join(patches))

name = 'crates/gammalooprs/src/integrands/process/evaluators.rs'
path = source / name
native = path.read_text()
anchor = '            "Evaluator atom before network parsing"\n        );\n'
assert native.count(anchor) == 1
stop = '''        if std::env::var_os("GAMMALOOP_STOP_AFTER_EVALUATOR_PRE_NETWORK_PARSE").is_some() {
            return Err(eyre!(
                "stopped after evaluator pre-network parse dump because GAMMALOOP_STOP_AFTER_EVALUATOR_PRE_NETWORK_PARSE is set"
            ));
        }
'''
modified = native.replace(anchor, anchor + stop)
path.write_text(modified)
changed[name] = hashlib.sha256(modified.encode()).hexdigest()
(OUT / 'pre-network-stop.patch').write_text(''.join(difflib.unified_diff(native.splitlines(keepends=True), modified.splitlines(keepends=True), fromfile='a/' + name, tofile='b/' + name)))

tracked = []
mismatches = []
for entry in subprocess.check_output(['git', '-C', str(ROOT), 'ls-tree', '-rz', COMMIT]).split(b'\0'):
    if not entry:
        continue
    metadata, raw = entry.split(b'\t', 1)
    mode, kind, blob = metadata.split()
    name = os.fsdecode(raw)
    path = source / name
    info = path.lstat()
    data = os.fsencode(os.readlink(path)) if stat.S_ISLNK(info.st_mode) else path.read_bytes()
    actual_mode = b'120000' if stat.S_ISLNK(info.st_mode) else b'100755' if info.st_mode & stat.S_IXUSR else b'100644'
    actual_blob = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest().encode()
    assert mode == actual_mode and kind == b'blob'
    if actual_blob != blob:
        mismatches.append(name)
    tracked.append(dict(path=name, mode=mode.decode(), native_blob=blob.decode(), instrumented_sha256=hashlib.sha256(data).hexdigest()))
assert sorted(mismatches) == sorted(changed)
tree = subprocess.check_output(['git', '-C', str(ROOT), 'rev-parse', COMMIT + '^{tree}'], text=True).strip()
assert tree == 'b3648e9563ed64ff8a8a68815e1a804b3fcc093b'
audit = dict(revision='c7', commit=COMMIT, tree=tree, source=str(source), status='PREPARED_ONLY',
             native_lock_sha256=hashlib.sha256((source / 'Cargo.lock').read_bytes()).hexdigest(),
             changed_files=changed, native_changed_paths=mismatches, mode_mismatches=[],
             tracked_files=tracked, compiled=False, executed=False)
(OUT / 'c7-source-audit.json').write_text(json.dumps(audit, indent=2) + '\n')

driver_path = BASE / 'owner-capture.py'
driver_original = driver_path.read_text()
assert hashlib.sha256(driver_original.encode()).hexdigest() == '388603f7335f0ce37aa86ccfd44c30cfac6f33e0e23fd261548a0359f3c8751d'
driver = driver_original
edits = [
    ('Build or run prepared C1/C3 owner captures, one guarded stage at a time.', 'Build or run the prepared native C7 early-color reversal with existing guarded stages.'),
    ("OUT = Path('/tmp/raised-energy-causal-20260914/uv-boundaries')", 'OUT = Path(' + repr(str(OUT)) + ')'),
    ("choices=['c1', 'c3']", "choices=['c7']"),
    ("choices=['orientation58', 'g_gl1']", "choices=['orientation58']"),
    ("card = BASE / 'controls/attachments' / f'{args.revision}-{args.workload}_expression_boundaries.toml'", "card = Path('/tmp/raised-energy-causal-20260914/c6-c7-direct-boundaries/c7.toml')\n        assert measure.digest(card) == '5c8d9dab7f569f20588cd19b27f00eb407a1fd74b1ca3772fbb0b9609fc7775b'"),
    ("directive = before['cli_settings']['global']['logfile_directive'] + ',' + OWNER_FILTER", "directive = before['cli_settings']['global']['logfile_directive']"),
    ("expected_count = 6 if args.workload == 'g_gl1' else 16", "expected_count = 0  # Native C7 existing boundaries; no owner instrumentation."),
    ("        assert measure.digest(build['binary']) == build['binary_sha256']\n        record['status']", '''        native_counts = {stage: sum(row.get('stage') == stage for row in rows) for stage in ('direct_3d_taylor_branch', 'direct_3d_taylor_mapped_numerator', 'final_cograph_numerator_ready', 'final_integrand_before_color')}
        assert native_counts == {'direct_3d_taylor_branch': 20, 'direct_3d_taylor_mapped_numerator': 20, 'final_cograph_numerator_ready': 16, 'final_integrand_before_color': 16}, native_counts
        record['capture_checks']['native_boundary_counts'] = native_counts
        full_atom = pre_network[0]['atom'].split('expr:', 1)[1].strip()
        (out / 'pre-network.atom').write_text(full_atom)
        record['pre_network_sha256'] = measure.digest(out / 'pre-network.atom')
        comparisons = []
        baseline_root = Path('/tmp/raised-energy-causal-20260914/c6-c7-direct-boundaries')
        for label in ('c6', 'c7'):
            baseline_rows = [json.loads(line) for file in (baseline_root / f'run-{label}-01/state/logs').glob('*.jsonl') for line in file.read_text().splitlines()]
            baseline = [row for row in baseline_rows if row.get('stage') == 'evaluator_stack_parse_atom_before_network_parse']
            assert len(baseline) == 1
            baseline_atom = baseline[0]['atom'].split('expr:', 1)[1].strip()
            comparisons.append({'baseline': label, 'exact_utf8_equal_after_outer_whitespace_strip': full_atom == baseline_atom, 'baseline_sha256': hashlib.sha256(baseline_atom.encode()).hexdigest(), 'current_sha256': record['pre_network_sha256']})
        measure.write(out / 'baseline-comparison.json', comparisons)
        assert measure.digest(build['binary']) == build['binary_sha256']
        record['status']'''),
]
for old, new in edits:
    assert driver.count(old) == 1, old
    driver = driver.replace(old, new)
compile(driver, str(OUT / 'capture.py'), 'exec')
(OUT / 'capture.py').write_text(driver)
(OUT / 'capture-driver-adaptation.patch').write_text(''.join(difflib.unified_diff(driver_original.splitlines(keepends=True), driver.splitlines(keepends=True), fromfile=str(driver_path), tofile=str(OUT / 'capture.py'))))
preparation = dict(status='PREPARED_NOT_BUILT_OR_EXECUTED', source=str(source), commit=COMMIT, tree=tree,
                   tracked_files=len(tracked), allowed_changed_files=changed,
                   intervention='Remove only early color simplification from direct Taylor numerator and build_direct cograph numerator; preserve projected-4D early color, zip_add, local4D, and all other C7 source. Existing comment retained and updated. Separate diagnostic stop precedes tensor-network parsing.',
                   reused_driver=str(driver_path), reused_driver_sha256=hashlib.sha256(driver_original.encode()).hexdigest(),
                   capture_driver_sha256=hashlib.sha256(driver.encode()).hexdigest(),
                   native_prior_recipe='/tmp/raised-energy-causal-20260914/c6-c7-direct-boundaries/recipe.json',
                   sequence=['root review', 'fmt', 'check', 'optimized build', 'clippy', 'one orientation58 pre-network capture', 'compare complete native C6/C7 inputs'],
                   limits=dict(build_seconds_per_stage=1800, runtime_seconds=120, rss_decimal_gb=30, build_jobs=4, rayon_workers=8, generation_cores=1),
                   no_retries=True, tests_changed=False, production_workspace_changed=False)
(OUT / 'preparation.json').write_text(json.dumps(preparation, indent=2) + '\n')
print(json.dumps(preparation, indent=2))

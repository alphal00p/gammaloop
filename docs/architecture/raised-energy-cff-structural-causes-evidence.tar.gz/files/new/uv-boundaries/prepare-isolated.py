"""Prepare immutable-pin source copies and logging/stop-only deltas; never build or run."""
from pathlib import Path
import difflib
import hashlib
import io
import json
import os
import stat
import subprocess
import tarfile

ROOT = Path('/common/dev/gammaloop/higher-power-energies-review')
OUT = Path('/tmp/raised-energy-causal-20260914/uv-boundaries')
PINS = {'c1': '665658b168981c5c508e6cd51d3b57bbb55a27fb', 'c3': '3ea313789a1a5290093579febd7d1c601b92594e'}
OWNER = Path('crates/gammalooprs/src/uv/hedge_poset.rs')
EVALUATOR = Path('crates/gammalooprs/src/integrands/process/evaluators.rs')
manifest = json.loads((OUT / 'owner-patch-manifest.json').read_text())
results = []
for revision, commit in PINS.items():
    source = OUT / 'sources' / revision
    source.mkdir(parents=True, exist_ok=False)
    archive = subprocess.check_output(['git', '-C', str(ROOT), 'archive', '--format=tar', commit])
    with tarfile.open(fileobj=io.BytesIO(archive)) as stream:
        stream.extractall(source, filter='data')
    tree = subprocess.check_output(['git', '-C', str(ROOT), 'rev-parse', commit + '^{tree}'], text=True).strip()
    expected = next(row for row in manifest if row['revision'] == revision)
    original = (source / OWNER).read_bytes()
    assert hashlib.sha256(original).hexdigest() == expected['source_sha256']
    (source / OWNER).write_bytes(Path(expected['preview']).read_bytes())
    changes = {str(OWNER): hashlib.sha256((source / OWNER).read_bytes()).hexdigest()}
    if revision == 'c3':
        original = (source / EVALUATOR).read_text()
        anchor = '''            "Evaluator atom before network parsing"
        );
'''
        assert original.count(anchor) == 1
        addition = '''        if std::env::var_os("GAMMALOOP_STOP_AFTER_EVALUATOR_PRE_NETWORK_PARSE").is_some() {
            return Err(eyre!(
                "stopped after evaluator pre-network parse dump because GAMMALOOP_STOP_AFTER_EVALUATOR_PRE_NETWORK_PARSE is set"
            ));
        }
'''
        modified = original.replace(anchor, anchor + addition)
        (source / EVALUATOR).write_text(modified)
        patch = ''.join(difflib.unified_diff(original.splitlines(keepends=True), modified.splitlines(keepends=True), fromfile=f'a/{EVALUATOR}', tofile=f'b/{EVALUATOR}'))
        (OUT / 'c3-pre-network-stop.patch').write_text(patch)
        changes[str(EVALUATOR)] = hashlib.sha256(modified.encode()).hexdigest()
    else:
        assert 'STOP_AFTER_EVALUATOR_PRE_NETWORK_PARSE_ENV' in (source / EVALUATOR).read_text()
    tracked = []
    mismatches = []
    mode_mismatches = []
    for entry in subprocess.check_output(['git', '-C', str(ROOT), 'ls-tree', '-rz', commit]).split(b'\0'):
        if not entry:
            continue
        metadata, raw_path = entry.split(b'\t', 1)
        mode, kind, blob = metadata.split()
        name = os.fsdecode(raw_path)
        path = source / name
        info = path.lstat()
        data = os.fsencode(os.readlink(path)) if stat.S_ISLNK(info.st_mode) else path.read_bytes()
        actual_mode = b'120000' if stat.S_ISLNK(info.st_mode) else b'100755' if info.st_mode & stat.S_IXUSR else b'100644'
        actual_blob = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest().encode()
        if actual_mode != mode:
            mode_mismatches.append(name)
        if actual_blob != blob:
            mismatches.append(name)
        tracked.append({'path': name, 'mode': mode.decode(), 'native_blob': blob.decode(), 'instrumented_sha256': hashlib.sha256(data).hexdigest()})
    assert sorted(mismatches) == sorted(changes), mismatches
    assert not mode_mismatches, mode_mismatches
    combined = subprocess.check_output(['git', '-C', str(ROOT), 'show', commit + ':' + str(OWNER)])
    assert hashlib.sha256(combined).hexdigest() == expected['source_sha256']
    receipt = {'revision': revision, 'commit': commit, 'tree': tree, 'source': str(source), 'status': 'PREPARED_ONLY', 'native_lock_sha256': hashlib.sha256((source / 'Cargo.lock').read_bytes()).hexdigest(), 'changed_files': changes, 'native_changed_paths': mismatches, 'mode_mismatches': mode_mismatches, 'tracked_files': tracked, 'compiled': False, 'executed': False}
    (OUT / f'{revision}-source-audit.json').write_text(json.dumps(receipt, indent=2) + '\n')
    results.append({key: value for key, value in receipt.items() if key != 'tracked_files'})
(OUT / 'isolated-preparation.json').write_text(json.dumps(results, indent=2) + '\n')
print(json.dumps(results, indent=2))

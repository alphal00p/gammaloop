"""Join frozen native semantic records; do not run or expand symbolic algebra."""

import collections
import hashlib
import json
import re
from pathlib import Path

BASE = Path('/tmp/raised-energy-causal-20260914/uv-boundaries')
RUN = BASE / 'attempts/c3/run-g_gl1-01'
OUT = BASE / 'gl1-owner-map-audit'
OUT.mkdir(exist_ok=False)
maps = json.loads((RUN / 'numerator-map-records.json').read_text())
owners = json.loads((RUN / 'owner-index.json').read_text())
stored = [r for r in owners if r['stage'].endswith('before_store')]
aggregated = {r['node_index']: r for r in owners if r['stage'].endswith('before_aggregation')}
logfiles = list((RUN / 'state/logs').glob('*.jsonl'))
assert len(logfiles) == 1
logfile = logfiles[0]
logs = {i: json.loads(s) for i, s in enumerate(logfile.read_text().splitlines(), 1)}
assert len(maps) == 216 and len(stored) == 6
assert json.loads((RUN / 'receipt.json').read_text())['limits']['generation_cores'] == 1

expr_pattern = re.compile(
    r'LinearEnergyExpr \{ internal_terms: \[(.*?)\], external_terms: \[(.*?)\], '
    r'uniform_scale_coeff: Fraction \{ numerator: (-?\d+), denominator: (\d+) \}, '
    r'constant: Fraction \{ numerator: (-?\d+), denominator: (\d+) \} \}'
)
term_pattern = re.compile(
    r'\(EdgeIndex\((\d+)\), Fraction \{ numerator: (-?\d+), denominator: (\d+) \}\)'
)


def decode_map(text):
    matches = list(expr_pattern.finditer(text))
    assert '[' + ', '.join(m.group() for m in matches) + ']' == text
    result = []
    for edge, match in enumerate(matches):
        internal, external, scale, scale_den, constant, constant_den = match.groups()
        terms = []
        for raw in [internal, external]:
            found = list(term_pattern.finditer(raw))
            assert ', '.join(m.group() for m in found) == raw
            terms.append([list(map(int, m.groups())) for m in found])
        internal_terms, external_terms = terms
        scale, scale_den, constant, constant_den = map(int, [scale, scale_den, constant, constant_den])
        if not internal_terms and not external_terms and scale == constant == 0:
            classification = 'zero'
        elif (
            len(internal_terms) == 1
            and internal_terms[0][0] == edge
            and internal_terms[0][1] in [-1, 1]
            and internal_terms[0][2] == 1
            and not external_terms
            and scale == constant == 0
        ):
            classification = 'signed_diagonal_OSE'
        elif external_terms or scale or constant:
            classification = 'affine'
        else:
            classification = 'other_linear'
        result.append(dict(
            slot=edge, internal_terms=internal_terms, external_terms=external_terms,
            uniform_scale=[scale, scale_den], constant=[constant, constant_den],
            classification=classification,
        ))
    return result


def digest(text):
    return hashlib.sha256(text.encode()).hexdigest()


def atom_file(name, text):
    path = OUT / name
    path.write_text(text)
    return dict(path=str(path), sha256=digest(text), utf8_bytes=len(text.encode()))


records = []
owner_rows = []
proper_branches = []
previous_owner_line = 0
for owner in stored:
    final = aggregated[owner['node_index']]
    assert all(owner[k] == final[k] for k in [
        'forest_term', 'source', 'cover', 'operation_count', 'residue_index', 'source_loop_edges'
    ])
    group = [m for m in maps if previous_owner_line < m['_line'] < owner['_line']]
    owner_records = []
    for m in group:
        line = m['_line']
        assert m['_logfile'] == str(logfile)
        assert logs[line]['unmapped_numerator'] == m['unmapped_numerator']
        before, after = logs.get(line - 1, {}), logs.get(line + 1, {})
        caller = None
        if before.get('stage') == 'direct_3d_taylor_branch':
            role = 'Taylor_newly_owned_numerator'
            assert after['stage'] == 'direct_3d_taylor_mapped_numerator'
            assert before['residue_map_key'] == after['residue_map_key'] == m['selector_id']
            assert before['current'] == after['current']
            assert before['given'] == after['given']
            assert before['source_edge_energy_map'] == m['source_edge_energy_map']
            assert before['current'].startswith('subgraph=' + owner['source'] + ', ')
            assert 'topo_order=' + str(owner['operation_count'] - 1) + ',' in before['current']
            # Native Display suppresses namespaces and inserts harmless whitespace.
            returned = re.sub(r'\s+', '', after['mapped_numerator'])
            plain = re.sub(r'\s+', '', m['mapped_numerator'])
            for namespace in ['gammalooprs::', 'spenso::', 'UFO::']:
                plain = plain.replace(namespace, '')
            assert returned == plain
            caller = {k: before[k] for k in [
                'current', 'given', 'reduced', 'active_subgraph', 'loop_edges', 'residue_map_key',
                'source_edge_energy_map',
            ]}
            caller.update(branch_log_line=line - 1, returned_map_log_line=line + 1,
                          input_integrand_sha256=digest(before['integrand']),
                          returned_map_exact_after_display_namespace_and_whitespace_removal=True)
        elif after.get('stage') == 'localize_integrated_ct_term':
            role = 'integrated_localizer_numerator'
            assert m['selector_id'] == after['residue_map_key']
            caller = {k: after[k] for k in ['integrated_node', 'contracted', 'reduced']}
            caller['completed_localizer_log_line'] = line + 1
        else:
            role = 'final_cograph_numerator'
            assert m['span']['name'] == 'build_direct'
            fields = m['span']['fields']
            assert f'graph=GL1 current=subgraph={owner["source"]}, topo_order={owner["operation_count"]},' in fields
        effective = decode_map(m['effective_edge_energy_map'])
        production_loop = decode_map(m['production_loop_energy_map'])
        assert len(effective) == 7
        assert all(e['classification'] in ['zero', 'signed_diagonal_OSE'] for e in effective)
        if m['source_map_used']:
            assert m['source_edge_energy_map'] == 'Some(' + m['effective_edge_energy_map'] + ')'
        else:
            assert m['source_edge_energy_map'] == 'None'
            orientations = m['physical_orientation'].removeprefix('EdgeVec([').removesuffix('])').split(', ')
            assert orientations[:2] == ['Undirected', 'Undirected']
            assert all(effective[e]['internal_terms'] == [[e, 1 if orientations[e] == 'Default' else -1, 1]] for e in range(2, 7))
        record = dict(
            owner_node=owner['node_index'], forest_term=owner['forest_term'], source=owner['source'],
            log_line=line, role=role, caller=caller, build_span=m.get('span'),
            full_residue_key=dict(selector_host=m['selector_id'], energy_map_kind='Source' if m['source_map_used'] else 'Production',
                                  source_edge_energy_map=m['source_edge_energy_map']),
            physical_orientation=m['physical_orientation'], effective_edge_energy_map=effective,
            production_loop_energy_map=production_loop,
            input_numerator_sha256=digest(m['unmapped_numerator']),
            output_numerator_sha256=digest(m['mapped_numerator']),
            input_packed_bytes=m['input_byte_size'], output_packed_bytes=m['output_byte_size'],
        )
        if owner['node_index'] == '3' and role == 'Taylor_newly_owned_numerator':
            host = m['selector_id']
            record['input_numerator'] = atom_file(f'proper140-host{host:02d}-unmapped.atom', m['unmapped_numerator'])
            record['mapped_numerator'] = atom_file(f'proper140-host{host:02d}-mapped.atom', m['mapped_numerator'])
            record['input_integrand'] = atom_file(f'proper140-host{host:02d}-complete-cff-weight.atom', before['integrand'])
            proper_branches.append(record)
        records.append(record)
        owner_records.append(record)
    cograph = [r for r in owner_records if r['role'] == 'final_cograph_numerator']
    assert len({r['input_numerator_sha256'] for r in cograph}) == 1
    owner_rows.append(dict(
        identity={k: owner[k] for k in ['node_index', 'forest_term', 'source', 'cover', 'operation_count', 'source_loop_edges', 'residue_index']},
        semantic_cutset=re.sub(r'addr: 0x[0-9a-fA-F]+', 'addr: <runtime-address>', owner['cutset']),
        pre_store_line=owner['_line'], pre_aggregate_line=final['_line'], previous_owner_store_line=previous_owner_line,
        complete_raw_atom=final['atom'], complete_orientation_parametric_atom=final['orientation_parametric_atom'],
        role_counts=dict(collections.Counter(r['role'] for r in owner_records)),
        cograph_complete_input_numerator_sha256=cograph[0]['input_numerator_sha256'],
        complete_map_records=[r['log_line'] for r in owner_records],
    ))
    previous_owner_line = owner['_line']

assert len(records) == len(maps)
assert len(proper_branches) == 18
assert sorted(r['full_residue_key']['selector_host'] for r in proper_branches) == list(range(18))
assert len({r['input_numerator_sha256'] for r in proper_branches}) == 1
assert len({tuple(row['internal_terms'][0][1] for row in r['effective_edge_energy_map'][2:]) for r in proper_branches}) == 18
role_counts = collections.Counter(r['role'] for r in records)
assert role_counts == {'Taylor_newly_owned_numerator': 90, 'integrated_localizer_numerator': 15, 'final_cograph_numerator': 111}
subsets = collections.Counter((r['full_residue_key']['energy_map_kind'], tuple(e['slot'] for e in r['effective_edge_energy_map'] if e['classification'] != 'zero')) for r in records)
result = dict(
    status='PASS_COMPLETE_OWNER_CALLER_MAP_JOIN', logfile=str(logfile), logfile_sha256=hashlib.sha256(logfile.read_bytes()).hexdigest(),
    capture_receipt=str(RUN / 'receipt.json'), source_audit=str(BASE / 'c3-source-audit.json'),
    owner_index=str(RUN / 'owner-index.json'), primary_records=str(RUN / 'numerator-map-records.json'),
    joining_rule='One generation core; consecutive native Taylor call/map/return triples and map/integrated-localizer completion pairs, within the sequential final-owner store boundaries. Remaining maps have the exact build_direct graph/current span. No final term ordinal, expression size, timestamp heuristic, or algebraic expansion is used.',
    map_records=len(records), role_counts=dict(role_counts),
    build_direct_span_records=sum(r['build_span'] is not None for r in records),
    effective_map_rows=7 * len(records), affine_effective_edge_rows=0, other_linear_effective_edge_rows=0,
    effective_nonzero_slot_groups=[dict(map_kind=k[0], nonzero_edge_slots=k[1], records=n) for k, n in subsets.items()],
    production_loop_records_with_affine_external_rows=sum(any(e['external_terms'] for e in r['production_loop_energy_map']) for r in records),
    zero_semantics='Unpaired external-edge rows0,1 are skipped by energy_map_replacements_gs and external four-momenta remain unchanged. Zero rows on paired internal edges are actual zero-energy substitutions, leaving their spatial Q3 factors. Production loop-energy chart metadata has external shifts, but this function applies the effective edge map and takes loop-energy substitutions from the graph loop-carrier edge rows.',
    limitations='Certifies the actual complete mapped numerator and caller identity before each Taylor operation or final assembly. A separate factor-preserving owner-to-final-term join is required to relate transformed Taylor outputs to hot evaluator terms. Does not identify physical source-edge incidence merely from a map signature.',
    owners=owner_rows, proper140_taylor_branches=proper_branches, records=records,
)
(OUT / 'proof.json').write_text(json.dumps(result, indent=2, ensure_ascii=False) + '\n')
print(json.dumps({k: v for k, v in result.items() if k not in ['owners', 'proper140_taylor_branches', 'records']}, indent=2))

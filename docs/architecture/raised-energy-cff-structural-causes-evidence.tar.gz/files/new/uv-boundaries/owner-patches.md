# Prepared logging-only patches

Apply `c1-owner-capture.patch` / `c3-owner-capture.patch` only to new isolated
copies of their source pins. `owner-patch-manifest.json` records the exact
source-file hash expected by each patch. The prior diagnostic workspaces and
the live review workspace have not been changed.

Each patch adds two records in existing HedgePoset loops:

- `hedge_poset_final_node_before_store`: complete finalized per-node Atom before
  the existing compute-store insertion, before aggregation/color collection.
- `hedge_poset_final_node_before_aggregation`: the same owner after the existing
  `collect_color()` and before `zip_add`. `atom` is that unmodified body.
  `orientation_parametric_atom` is a diagnostic copy with the exact existing
  final momentum split and denominator-wrapper removal applied. Its sum must
  be checked against the production aggregate; it does not alter that aggregate.

Both carry graph_name, internal NodeIndex, full operation display key, operation
count, cover, source spinney, source loop edges, union flag, full CutSet,
CutCFFIndex, packed Atom size, and complete namespace-preserving plain text.
They do not attach markers, change source selection, change a test, expose a
new helper/API, or change any production algebra. C3 uses existing
`clone().into_integrands().iter()` because its direct `FinalIntegrands::iter`
is intentionally test-only.

Native log filter additions:

```text
gammalooprs::uv::hedge_poset[{stage=hedge_poset_final_node_before_store}]=debug,gammalooprs::uv::hedge_poset[{stage=hedge_poset_final_node_before_aggregation}]=debug
```

A useful combined filter for the owner capture is:

```text
off,gammalooprs::uv::hedge_poset[{stage=hedge_poset_final_node_before_store}]=debug,gammalooprs::uv::hedge_poset[{stage=hedge_poset_final_node_before_aggregation}]=debug,gammalooprs::uv::hedge_poset[{stage=hedge_poset_4d_node_done}]=debug,[{#generation,#summary}]=debug
```

Use `graph_name`, not `graph`: `#graph` occupies `graph: true` in these JSONL
records. Do not equate logged NodeIndex with computed-export ordinal.

Validation performed: Python patch generator executed with unique-anchor
assertions; both complete preview files passed `rustfmt --edition 2024 --check`
using `/home/codex/.rustup/toolchains/1.89.0-x86_64-unknown-linux-gnu/bin/rustfmt`.
The native locked Symbolica `Atom::to_plain_string` method was checked directly:
it uses portable `PrintOptions::file()` (`4d0a833/src/atom.rs:3215`). No Cargo
check/build/run was performed. Root should use the native recorded toolchain to
format/check/build the fresh instrumented copy before running it.

There is no existing dedicated CLI preprocessing-only command found. Existing
public `ProcessList::preprocess` and `Amplitude::preprocess` stop before evaluator
construction, as documented in `plan.md`. For saved generated GL1 states,
`save uv-forest FRESH_DIR -p name:double_triangle -i 2L --graph GL1 --computed`
recomputes only the forest, so it reaches the before-store record; export does
not call `orientation_parametric_exprs`, hence it does not reach the
before-aggregation record. To recover that second boundary and prove aggregate
reassembly, use public preprocessing or a normal native generation path stopped
through a prearranged scratch diagnostic boundary before tensor evaluation.

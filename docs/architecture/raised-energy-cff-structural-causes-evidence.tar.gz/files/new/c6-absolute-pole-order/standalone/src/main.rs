use std::{env, fs, path::PathBuf, time::Instant};

use eyre::{Result, eyre};
use serde_json::json;
use spenso::network::{library::symbolic::ETS, tags::SPENSO_TAG};
use symbolica::{
    atom::{Atom, AtomCore},
    parser::ParseSettings,
    symbol, wrap_input,
};
use vakint::{
    AlphaLoopOptions, EvaluationMethod, EvaluationOrder, FMFTOptions,
    InputFloatRationalizationPrecision, LoopNormalizationFactor, MATADOptions, Vakint,
    VakintExpression, VakintSettings, VakintTerm,
};

fn main() -> Result<()> {
    let args = env::args().skip(1).collect::<Vec<_>>();
    if args.len() != 2 {
        return Err(eyre!(
            "usage: c6-vakint-phase-replay CAPTURE_DIRECTORY FRESH_OUTPUT_DIRECTORY"
        ));
    }
    let input = PathBuf::from(&args[0]);
    let output = PathBuf::from(&args[1]);
    if output.exists() {
        return Err(eyre!("output directory already exists"));
    }
    fs::create_dir_all(&output)?;
    env_logger::Builder::new()
        .filter_module("vakint::phase", log::LevelFilter::Debug)
        .format_timestamp_millis()
        .init();
    let total = Instant::now();
    // Reuse the native owners of all captured color and representation symbols.
    // GS's captured scalar symbols have no algebraic attributes; its hedge head
    // has only the same index tag below. Printer-only callbacks are not needed.
    let _ = idenso::color::CS.t;
    let _ = ETS.metric;
    let _ = symbol!("gammalooprs::hedge", tags = [SPENSO_TAG.index.clone()]);
    for name in [
        "gammalooprs::dim",
        "gammalooprs::ε",
        "gammalooprs::mUV",
        "gammalooprs::mUVexp",
        "gammalooprs::μᵣ²",
        "UFO::GC_10",
        "UFO::GC_11",
    ] {
        let _ = symbol!(name);
    }
    let vakint = Vakint::new()?;
    let settings = VakintSettings {
        epsilon_symbol: "gammalooprs::ε".into(),
        mu_r_sq_symbol: "gammalooprs::μᵣ²".into(),
        form_exe_path: "form".into(),
        python_exe_path: "python3".into(),
        verify_numerator_identification: false,
        integral_normalization_factor: LoopNormalizationFactor::MSbar,
        run_time_decimal_precision: 100,
        allow_unknown_integrals: false,
        clean_tmp_dir: true,
        evaluation_order: EvaluationOrder(vec![
            EvaluationMethod::AlphaLoop(AlphaLoopOptions {
                susbstitute_masters: true,
            }),
            EvaluationMethod::MATAD(MATADOptions {
                expand_masters: true,
                susbstitute_masters: true,
                substitute_hpls: true,
                direct_numerical_substition: true,
            }),
            EvaluationMethod::FMFT(FMFTOptions {
                expand_masters: true,
                susbstitute_masters: true,
            }),
        ]),
        number_of_terms_in_epsilon_expansion: 3,
        precision_for_input_float_rationalization:
            InputFloatRationalizationPrecision::FullPrecision,
        use_dot_product_notation: false,
        project_onto_tensor_integrals: true,
        temporary_directory: None,
    };
    let recorded_settings = fs::read_to_string(input.join("settings-debug.txt"))?;
    if format!("{settings:?}") != recorded_settings.trim_end() {
        return Err(eyre!(
            "explicit replay settings do not match native captured settings"
        ));
    }
    println!(
        "{}",
        json!({"stage":"initialized", "seconds":total.elapsed().as_secs_f64(), "settings_match":true})
    );
    let mut terms = Vec::with_capacity(10);
    for index in 0..10 {
        let numerator_text =
            fs::read_to_string(input.join(format!("term-{index:02}-numerator.atom")))?;
        let integral_text =
            fs::read_to_string(input.join(format!("term-{index:02}-integral.atom")))?;
        let numerator = Atom::parse_with_default_namespace(
            wrap_input!(&numerator_text),
            ParseSettings::default(),
        )
        .map_err(|error| eyre!("numerator {index}: {error}"))?;
        let integral = Atom::parse_with_default_namespace(
            wrap_input!(&integral_text),
            ParseSettings::default(),
        )
        .map_err(|error| eyre!("integral {index}: {error}"))?;
        fs::write(
            output.join(format!("term-{index:02}-parsed-numerator.atom")),
            numerator.to_canonical_string(),
        )?;
        fs::write(
            output.join(format!("term-{index:02}-parsed-integral.atom")),
            integral.to_canonical_string(),
        )?;
        println!(
            "{}",
            json!({"stage":"parsed_term", "term_index":index, "numerator_bytes":numerator.as_view().get_byte_size(), "numerator_terms":numerator.nterms()})
        );
        // This field is not read by evaluate_integral. Keep it empty just as the
        // existing public direct-evaluation unit example in Vakint does.
        terms.push(VakintTerm {
            integral,
            numerator,
            vectors: vec![],
        });
    }
    let mut expression = VakintExpression(terms);
    let started = Instant::now();
    expression.evaluate_integral(&vakint, &settings)?;
    println!(
        "{}",
        json!({"stage":"evaluate_complete", "seconds":started.elapsed().as_secs_f64()})
    );
    for (index, term) in expression.0.into_iter().enumerate() {
        fs::write(
            output.join(format!("term-{index:02}-result.atom")),
            (term.numerator * term.integral).to_canonical_string(),
        )?;
    }
    println!(
        "{}",
        json!({"stage":"complete", "total_seconds":total.elapsed().as_secs_f64()})
    );
    Ok(())
}

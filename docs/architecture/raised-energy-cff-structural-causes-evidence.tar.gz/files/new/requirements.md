# Causal understanding required

User objective: yeah so what changes structurally about the expression.. Dont stop untill you fully understand the problem/slowdown

The earlier bounded report is a starting point, not completion of this objective.

1. Match actual costly UV contributions by graph, forest/source owner, residue/energy map and tensor content across the C3 boundary.
2. Explain the changed nested sums, scalar/tensor separation, vector compaction and graph connectivity on complete expressions.
3. Isolate which structural changes account for measured time and memory using semantically certified same-executor replays or controlled source experiments. Preserve graph-numerator factorization and all signs/denominators.
4. Explain every material observed slowdown: C3 GL1, C3 attachment/sparse cap, C6 integrated long wait, and C7 scalar-growth change; retain small-sunrise controls. Do not replace a causal explanation with another timing table.
5. Preserve failing tests/oracles, native sources and previous evidence. Use exact public-value checks and precision-aware validation without weakening thresholds.
6. Update the explanation/report only as evidence establishes causes; leave goal active while material attribution remains unproved.

No production fix is authorized by inference. Logging-only scratch instrumentation and controlled diagnostic replays are within investigation scope. Existing license is invoked externally and never inspected/copied. One heavy workload at a time,30GB RSScap, fixed native workers, snapshot updates/retries disabled.

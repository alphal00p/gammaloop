from pathlib import Path
import fcntl,importlib.util,json,datetime
BASE=Path('/tmp/raised-energy-expression-perf-20260914')
OUT=Path('/tmp/raised-energy-causal-20260914/c6-c7-direct-boundaries')
lock=(BASE/'measurement.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
spec=importlib.util.spec_from_file_location('measure',BASE/'measure.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
assert m.digest(BASE/'measure.py')=='6f6ca7cbb51f5b606b93da4e00fe42465f3a194bc5efaf6e492df737cafad4d9'
recipe=json.loads((OUT/'recipe.json').read_text())
for item in recipe['runs']:
 for key in ['audit','build_receipt','binary','card','original_card']:assert m.digest(item[key])==item[key+'_sha256'],key
 audit=json.loads(Path(item['audit']).read_text());m.PREFIX=Path(item['source'])
 for row in audit['files']:assert m.digest(m.PREFIX/row['path'])==row['sha256'],row['path']
 out=Path(item['fresh_directory']);out.mkdir();r=dict(status='STARTED',recipe=item,recipe_sha256=m.digest(OUT/'recipe.json'),source_before=True,started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());m.write(out/'receipt.json',r)
 try:
  env=dict(RAYON_NUM_THREADS='8',RUST_MIN_STACK='134217728',INSTA_UPDATE='no',NEXTEST_RETRIES='0',LC_ALL='C')
  command=['env','-u','GAMMALOOP_DUMP_EVALUATOR_PRE_NETWORK_PARSE','-u','GAMMALOOP_STOP_AFTER_EVALUATOR_PRE_NETWORK_PARSE','-u','SPENSO_NETWORK_PROFILE','-u','SPENSO_NETWORK_PROFILE_VERBOSE','-u','SPENSO_NETWORK_PROFILE_ATOM_BYTES','timeout','--verbose','--signal=TERM','--kill-after=15s','10s',item['binary'],'-n','-s',item['state'],item['card'],'run','generate']
  result=m.guarded(out,'runtime',command,env);r['runtime']=result
  signal_lines=[x for x in (out/'runtime/stdout.log').read_text(errors='replace').splitlines() if x.startswith('timeout: sending signal ') and item['binary'] in x]
  r['timeout_signals']=signal_lines
  r['execution_status']='TIME_LIMIT' if result['status']=='CHILD_FAILURE' and result['exit_code'] in [124,137] and signal_lines else result['status']
  logs=[];events=[]
  for p in sorted(Path(item['state']).glob('logs/*.jsonl')):
   logs.append(dict(path=str(p),sha256=m.digest(p),bytes=p.stat().st_size))
   for n,line in enumerate(p.read_text().splitlines(),1):
    row=json.loads(line);events.append(dict(path=str(p),line=n,**row))
  r['logs']=logs;r['pre_network_records']=sum(x.get('stage')=='evaluator_stack_parse_atom_before_network_parse' for x in events);r['mapped_numerator_records']=sum(x.get('stage')=='direct_3d_taylor_mapped_numerator' for x in events)
  r['status']='PASS_UPSTREAM_CAPTURE' if r['execution_status'] in ['TIME_LIMIT','PASS'] and r['pre_network_records']==1 and r['mapped_numerator_records'] else 'CAPTURE_FAILURE'
 except BaseException as e:r.update(status='EVIDENCE_FAILURE',error=repr(e))
 finally:
  for key in ['audit','build_receipt','binary','card','original_card']:assert m.digest(item[key])==item[key+'_sha256'],key
  for row in audit['files']:assert m.digest(m.PREFIX/row['path'])==row['sha256'],row['path']
  r.update(source_after=True,finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());m.write(out/'receipt.json',r);print(json.dumps(dict(label=item['label'],status=r['status'],execution_status=r.get('execution_status'),receipt=str(out/'receipt.json'))),flush=True)
 if r['status']!='PASS_UPSTREAM_CAPTURE':raise SystemExit(1)

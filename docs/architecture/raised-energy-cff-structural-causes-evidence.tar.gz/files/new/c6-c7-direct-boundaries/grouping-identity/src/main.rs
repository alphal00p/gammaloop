use std::{collections::HashSet, env, fs, ops::Deref, path::Path, time::Instant};

use color_eyre::{Result, eyre::eyre};
use gammalooprs::{
    initialisation::initialise,
    utils::{FUN_LIB, TENSORLIB},
};
use idenso::shorthands::metric::MetricSimplifier;
use serde_json::json;
use symbolica::{
    atom::{Atom, AtomCore},
    parser::ParseSettings,
    wrap_input,
};

fn main() -> Result<()> {
    let args = env::args().skip(1).collect::<Vec<_>>();
    if args.len() != 3 || Path::new(&args[2]).exists() {
        return Err(eyre!(
            "usage: cff-grouping-identity LEFT.atom RIGHT.atom FRESH_DIRECTORY"
        ));
    }
    fs::create_dir(&args[2])?;
    initialise()?;
    drop(TENSORLIB.read().unwrap());
    let _ = FUN_LIB.deref();
    let mut atoms = Vec::new();
    for input in &args[..2] {
        let text = fs::read_to_string(input)?;
        atoms.push(
            Atom::parse_with_default_namespace(wrap_input!(&text), ParseSettings::default())
                .map_err(|error| eyre!("complete input parse failed: {error}"))?,
        );
    }
    let mut seen = [HashSet::new(), HashSet::new()];
    let mut stages = Vec::new();
    let mut equal = atoms[0] == atoms[1];
    let mut repeated = [false; 2];
    for pass in 0..4 {
        if equal || repeated.iter().all(|value| *value) {
            break;
        }
        for (side, atom) in atoms.iter().enumerate() {
            seen[side].insert(atom.clone());
        }
        for operation in ["metrics", "numeric_collection", "common_factors"] {
            for (side, atom) in atoms.iter_mut().enumerate() {
                println!(
                    "{}",
                    json!({"stage":"operation_start", "pass":pass, "side":side, "operation":operation})
                );
                let started = Instant::now();
                *atom = match operation {
                    "metrics" => atom.simplify_metrics(),
                    "numeric_collection" => atom.collect_num(),
                    "common_factors" => atom.collect_factors(),
                    _ => unreachable!(),
                };
                let seconds = started.elapsed().as_secs_f64();
                let output =
                    Path::new(&args[2]).join(format!("pass{pass}-{operation}-side{side}.atom"));
                fs::write(&output, atom.to_canonical_string())?;
                let stage = json!({"stage":"operation_complete", "pass":pass, "side":side,
                    "operation":operation, "seconds":seconds, "atom_bytes":atom.as_view().get_byte_size(), "output":output});
                println!("{stage}");
                stages.push(stage);
            }
            equal = atoms[0] == atoms[1];
            fs::write(
                Path::new(&args[2]).join("report.json"),
                serde_json::to_vec_pretty(&json!({
                    "status":if equal {"EXACT_ATOM_EQUAL"} else {"UNEQUAL_AT_THIS_BOUNDARY"},
                    "complete_inputs":&args[..2], "stages":stages, "expansion_performed":false,
                    "denominator_recombination_allowed_for_identity_only":true
                }))?,
            )?;
            if equal {
                break;
            }
        }
        for (side, atom) in atoms.iter().enumerate() {
            repeated[side] = seen[side].contains(atom);
        }
    }
    println!(
        "{}",
        json!({"stage":"comparison_complete", "exact_atom_equal":equal, "repeated_states":repeated})
    );
    Ok(())
}

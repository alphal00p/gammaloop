import ast
import collections
import hashlib
import json
import re
from pathlib import Path

base = Path('/tmp/raised-energy-causal-20260914/c6-c7-direct-boundaries')
out = base / 'paired-captures'
out.mkdir(exist_ok=True)
source = ast.parse(Path('/tmp/raised-energy-expression-perf-20260914/upstream-expression-analysis/analyze-captured-structure.py').read_text())
ns = {}
allowed = []
for node in source.body:
    if isinstance(node, ast.For):
        break
    allowed.append(node)
exec(compile(ast.Module(body=allowed, type_ignores=[]), '<existing parser>', 'exec'), ns)
parse, factors, unparen, positions, split_at = (ns[k] for k in ['parse', 'factors', 'unparen', 'positions', 'split_at'])
events = {}
owner_fields = ['current', 'given', 'residue_map_key', 'source_edge_energy_map', 'active_subgraph', 'reduced', 'loop_edges']
result = {'logs': {}, 'branch_pairs': [], 'whole_network_inputs': {}, 'complete_owner_key_fields': owner_fields}
for phase in ['c6', 'c7']:
    log = next((base / f'run-{phase}-01/state/logs').glob('*.jsonl'))
    rows = [json.loads(line) for line in log.open()]
    result['logs'][phase] = {'path': str(log), 'sha256': hashlib.sha256(log.read_bytes()).hexdigest(), 'rows': len(rows)}
    counts = collections.Counter()
    events[phase] = {}
    pending_branch = None
    for index, row in enumerate(rows):
        stage = row.get('stage')
        if stage == 'direct_3d_taylor_branch':
            assert pending_branch is None
            pending_branch = (index, row)
        if stage == 'direct_3d_taylor_mapped_numerator':
            assert pending_branch is not None
            branch_index, branch = pending_branch
            assert all(row[k] == branch[k] for k in ['current', 'given', 'residue_map_key'])
            key = tuple(branch[k] for k in owner_fields)
            pending_branch = None
            occurrence = counts[key]
            counts[key] += 1
            events[phase][key + (occurrence,)] = (index, row, branch_index, branch)
        if stage in ['evaluator_stack_parse_atom_before_network_parse', 'final_cograph_numerator_ready', 'final_integrand_before_color']:
            path = out / f'{phase}-{stage}-{index:03d}.atom'
            text = row['atom']
            header = re.match(r'n-terms: (\d+), byte size: (\d+),expr:', text)
            if header:
                text = text[header.end():]
            path.write_text(text)
            if stage == 'evaluator_stack_parse_atom_before_network_parse':
                found = positions(text, '+-')
                parts = split_at(text, found)
                parts = [parts[0]] + [('' if op == '+' else '-') + part for (_, op), part in zip(found, parts[1:])]
                assert len(parts) == int(header[1])
                termdir = out / f'{phase}-pre-network-terms'
                termdir.mkdir(exist_ok=True)
                terms = []
                for termindex, part in enumerate(parts):
                    termfile = termdir / f'{termindex:03d}.atom'
                    termfile.write_text(unparen(part))
                    terms.append({'index': termindex, 'path': str(termfile), 'utf8_bytes': termfile.stat().st_size, 'sha256': hashlib.sha256(termfile.read_bytes()).hexdigest()})
                result['whole_network_inputs'][phase] = {'event_index_zero_based': index, 'path': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'utf8_bytes': path.stat().st_size, 'packed_bytes': int(header[2]), 'term_count': len(parts), 'terms': terms, 'namespace_scope': 'Complete native namespace-qualified plain expression; only n-terms/byte-size printer header removed.'}
assert events['c6'].keys() == events['c7'].keys()
for pairindex, key in enumerate(events['c6']):
    record = {'index': pairindex, 'current': key[0], 'given': key[1], 'residue_map_key': key[2], 'key_occurrence_zero_based': key[-1], 'complete_owner_key': dict(zip(owner_fields, key[:-1])), 'namespace_scope': 'Native display field %mapped_numerator omits namespaces/attributes; raw text retained exactly and not treated as canonical replay input.'}
    counters = {}
    factor_text = {}
    for phase in ['c6', 'c7']:
        index, row, branch_index, branch = events[phase][key]
        text = row['mapped_numerator']
        path = out / f'{phase}-mapped-{pairindex:02d}.display.atom'
        path.write_text(text)
        tree = parse(text)
        fs = factors(tree)
        counters[phase] = collections.Counter(f.digest for f in fs)
        factor_text.update({f.digest: f.text for f in fs})
        record[phase] = {'branch_event_index_zero_based': branch_index, 'event_index_zero_based': index, 'path': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'utf8_bytes': path.stat().st_size, 'structural_sha256': tree.digest}
    record['same_exact_text'] = record['c6']['sha256'] == record['c7']['sha256']
    for phase, other in [('c6', 'c7'), ('c7', 'c6')]:
        record[f'{phase}_exclusive_factors'] = [{'text': factor_text[d], 'multiplicity': n} for d, n in (counters[phase] - counters[other]).items()]
    record['shared_direct_factors'] = [{'text': factor_text[d], 'multiplicity': n} for d, n in (counters['c6'] & counters['c7']).items()]
    result['branch_pairs'].append(record)
result['all_40_source_edge_energy_maps_are_none'] = all(key[3] == 'None' for phase in events for key in events[phase])
assert result['all_40_source_edge_energy_maps_are_none']
result['duplicate_complete_owner_mapped_numerators_identical_within_each_revision'] = all(len({value[1]['mapped_numerator'] for candidate, value in events[phase].items() if candidate[:-1] == key[:-1]}) == 1 for phase in events for key in events[phase])
assert result['duplicate_complete_owner_mapped_numerators_identical_within_each_revision']
networksets = {phase: collections.Counter(t['sha256'] for t in result['whole_network_inputs'][phase]['terms']) for phase in ['c6', 'c7']}
result['whole_network_inputs']['common_exact_top_level_term_count'] = sum((networksets['c6'] & networksets['c7']).values())
(out / 'paired-captures.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print('pairs', len(result['branch_pairs']), 'equal', sum(r['same_exact_text'] for r in result['branch_pairs']))
for record in result['branch_pairs']:
    print(record['index'], record['current'], record['given'], record['c6']['utf8_bytes'], record['c7']['utf8_bytes'], 'C6-only', record['c6_exclusive_factors'], 'C7-only', record['c7_exclusive_factors'])
print('network', {phase: {k: v for k, v in data.items() if k != 'terms'} if isinstance(data, dict) else data for phase, data in result['whole_network_inputs'].items()})

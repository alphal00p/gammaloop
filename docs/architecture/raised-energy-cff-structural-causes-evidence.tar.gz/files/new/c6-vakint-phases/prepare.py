"""Extract paired captured inputs and prepare logging-only source copies."""
from pathlib import Path
import difflib
import hashlib
import json
import re

out = Path('/tmp/raised-energy-causal-20260914/c6-vakint-phases')
source = Path('/tmp/raised-energy-expression-perf-20260914/diagnostic-workspaces/c6')
log = next(Path('/tmp/raised-energy-causal-20260914/c6-stage-boundary/run-01/state/logs').glob('*.jsonl'))
rows = [(line, json.loads(text)) for line, text in enumerate(log.open(), 1)]
projected = [(line, row) for line, row in rows if row.get('stage') == 'projected_numerator_after_d_dimensional_algebra']
context = projected[-1][1]['span']['fields']
projected = [(line, row) for line, row in projected if row['span']['fields'] == context]
assert len(projected) == 10
settings = [(line, row) for line, row in rows if row.get('message') == 'Vakint args' and row['span']['fields'] == context]
assert len(settings) == 1
settings_line, settings_row = settings[0]
(out / 'settings-debug.txt').write_text(settings_row['settings'] + '\n')
(out / 'settings-event.json').write_text(json.dumps(settings_row, ensure_ascii=False, indent=2) + '\n')
inputs = []
for projected_line, row in projected:
    index = int(row['term_index'])
    reduced = [(line, r) for line, r in rows if r.get('message') == 'Vakint term after tensor reduction' and r['span']['fields'] == context and int(r['term_index']) == index]
    assert len(reduced) == 1
    reduced_line, previous = reduced[0]
    numerator = row['numerator'].split('expr:', 1)[1]
    integral = previous['integral'].split('expr:', 1)[1]
    record = {'term_index': index, 'projected_line': projected_line, 'integral_line': reduced_line, 'timestamp': row['timestamp'], 'numerator_reported_packed_bytes': int(re.search(r'byte size: (\d+)', row['numerator']).group(1)), 'numerator_reported_terms': int(re.search(r'n-terms: (\d+)', row['numerator']).group(1))}
    for name, text in [('numerator', numerator), ('integral', integral)]:
        path = out / f'term-{index:02}-{name}.atom'
        path.write_text(text)
        record[name] = {'path': str(path), 'utf8_bytes': len(text.encode()), 'sha256': hashlib.sha256(text.encode()).hexdigest()}
    inputs.append(record)
(out / 'captured-inputs.json').write_text(json.dumps({'log': str(log), 'log_sha256': hashlib.sha256(log.read_bytes()).hexdigest(), 'span_context': context, 'settings_line': settings_line, 'inputs': inputs, 'pairing_proof': 'Term indices and exact integrate span match the tensor-reduced integral to the final projected numerator. The intervening GammaLoop loop only mutates term.numerator; term.integral is unchanged. Evaluation has not yet been called when the tenth projected event is logged.', 'vectors': 'VakintTerm.vectors is not read by evaluate_integral/apply_numerator_replacement_rules; replay need not perform tensor_reduce again.', 'logging_limit': 'GammaLoop emits evaluated-term events only after the whole batch; existing log cannot identify which term stalls.'}, ensure_ascii=False, indent=2) + '\n')

lib = (source / 'crates/vakint/src/lib.rs').read_text()
start = lib.index('impl VakintTerm {\n    pub fn evaluate_integral(')
end = lib.index('    pub fn apply_numerator_replacement_rules(', start)
chunk = lib[start:end]
replacements = [
('        let mut integral_specs =', '        log::debug!(target: "vakint::phase", "phase=term_topology_start numerator_bytes={} integral={}", self.numerator.as_view().get_byte_size(), self.integral);\n        let mut integral_specs ='),
('        integral_specs.apply_replacement_rules()?;\n        self.apply_numerator_replacement_rules(&integral_specs, settings)?;', '        log::debug!(target: "vakint::phase", "phase=topology_rules_start");\n        integral_specs.apply_replacement_rules()?;\n        log::debug!(target: "vakint::phase", "phase=numerator_rules_start");\n        self.apply_numerator_replacement_rules(&integral_specs, settings)?;\n        log::debug!(target: "vakint::phase", "phase=numerator_rules_done bytes={}", self.numerator.as_view().get_byte_size());'),
('        let numerator = Vakint::convert_to_dot_notation(settings, self.numerator.as_view())?;\n        let terms = projection::ScalarTerms::parse(numerator.as_view())?;', '        log::debug!(target: "vakint::phase", "phase=dot_conversion_start");\n        let numerator = Vakint::convert_to_dot_notation(settings, self.numerator.as_view())?;\n        log::debug!(target: "vakint::phase", "phase=dot_conversion_done bytes={}", numerator.as_view().get_byte_size());\n        log::debug!(target: "vakint::phase", "phase=scalar_parse_start");\n        let terms = projection::ScalarTerms::parse(numerator.as_view())?;\n        log::debug!(target: "vakint::phase", "phase=scalar_parse_done monomials={}", terms.0.len());'),
('        let (kernel, aliases, numerator_orders) =', '        log::debug!(target: "vakint::phase", "phase=backend_kernel_start projected={}", settings.project_onto_tensor_integrals);\n        let (kernel, aliases, numerator_orders) ='),
('        let epsilon_overflow =', '        log::debug!(target: "vakint::phase", "phase=backend_kernel_done bytes={} aliases={} numerator_orders={}", kernel.as_view().get_byte_size(), aliases.len(), numerator_orders);\n        let epsilon_overflow ='),
('        let normalization_order = normalization', '        log::debug!(target: "vakint::phase", "phase=normalization_series_start");\n        let normalization_order = normalization'),
('        let normalization_orders =', '        log::debug!(target: "vakint::phase", "phase=normalization_series_done");\n        let normalization_orders ='),
('        let evaluated = evaluation_approach.evaluate_kernel(', '        log::debug!(target: "vakint::phase", "phase=backend_start approach={:?} kernel_bytes={} kernel_order={}", evaluation_approach, kernel.as_view().get_byte_size(), kernel_order);\n        let evaluated = evaluation_approach.evaluate_kernel('),
('        let restored = evaluated.replace_multiple(', '        log::debug!(target: "vakint::phase", "phase=backend_done bytes={}", evaluated.as_view().get_byte_size());\n        log::debug!(target: "vakint::phase", "phase=restore_aliases_start count={}", aliases.len());\n        let restored = evaluated.replace_multiple('),
('        self.numerator = projection::ScalarTerms::epsilon_series(\n            restored.as_view(),', '        log::debug!(target: "vakint::phase", "phase=restore_aliases_done bytes={}", restored.as_view().get_byte_size());\n        log::debug!(target: "vakint::phase", "phase=final_epsilon_series_start target_order={}", target_order);\n        self.numerator = projection::ScalarTerms::epsilon_series(\n            restored.as_view(),'),
('        // Coefficients are restored', '        log::debug!(target: "vakint::phase", "phase=final_epsilon_series_done bytes={}", self.numerator.as_view().get_byte_size());\n        // Coefficients are restored'),
]
for old, new in replacements:
    assert chunk.count(old) == 1, old
    chunk = chunk.replace(old, new, 1)
lib = lib[:start] + chunk + lib[end:]
old = '        for term in self.0.iter_mut() {\n            term.evaluate_integral(vakint, settings)?;\n        }'
new = '        for (term_index, term) in self.0.iter_mut().enumerate() {\n            log::debug!(target: "vakint::phase", "phase=evaluate_term_start term_index={} numerator_bytes={} integral={}", term_index, term.numerator.as_view().get_byte_size(), term.integral);\n            term.evaluate_integral(vakint, settings)?;\n            log::debug!(target: "vakint::phase", "phase=evaluate_term_done term_index={} numerator_bytes={}", term_index, term.numerator.as_view().get_byte_size());\n        }'
assert lib.count(old) == 1
lib = lib.replace(old, new)

projection = (source / 'crates/vakint/src/projection.rs').read_text()
replacements = [
('        check(input, epsilon)?;\n        let series = input', '        log::debug!(target: "vakint::phase", "phase=epsilon_check_start bytes={}", input.get_byte_size());\n        check(input, epsilon)?;\n        log::debug!(target: "vakint::phase", "phase=epsilon_series_start bytes={}", input.get_byte_size());\n        let series = input'),
('        if series.terms().any(|(power, coefficient)| {', '        log::debug!(target: "vakint::phase", "phase=epsilon_series_done");\n        if series.terms().any(|(power, coefficient)| {'),
('        let coefficient = self.0.entry(key.clone()).or_insert_with(Atom::zero);', '        log::debug!(target: "vakint::phase", "phase=scalar_insert_start key={} value_bytes={}", key, value.as_view().get_byte_size());\n        let coefficient = self.0.entry(key.clone()).or_insert_with(Atom::zero);'),
('        *coefficient = coefficient.replace_map_bottom_up(|term, _, out| {', '        log::debug!(target: "vakint::phase", "phase=insert_zero_certification_start key={} bytes={}", key, coefficient.as_view().get_byte_size());\n        *coefficient = coefficient.replace_map_bottom_up(|term, _, out| {'),
('                candidate = if rational {', '                if seen.len() <= 3 || seen.len().is_power_of_two() {\n                    log::debug!(target: "vakint::phase", "phase=insert_collect_start iteration={} rational={} bytes={} terms={} candidate={}", seen.len(), rational, candidate.as_view().get_byte_size(), candidate.nterms(), candidate);\n                }\n                candidate = if rational {'),
('                    candidate.collect_by_coefficient()\n                };', '                    candidate.collect_by_coefficient()\n                };\n                if seen.len() <= 3 || seen.len().is_power_of_two() {\n                    log::debug!(target: "vakint::phase", "phase=insert_collect_done iteration={} bytes={} terms={}", seen.len(), candidate.as_view().get_byte_size(), candidate.nterms());\n                }'),
('            if candidate.is_zero() {', '            log::debug!(target: "vakint::phase", "phase=insert_add_done iterations={} zero={} bytes={}", seen.len(), candidate.is_zero(), candidate.as_view().get_byte_size());\n            if candidate.is_zero() {'),
('        if coefficient.is_zero() {\n            self.0.remove(&key);', '        log::debug!(target: "vakint::phase", "phase=scalar_insert_done key={} bytes={}", key, coefficient.as_view().get_byte_size());\n        if coefficient.is_zero() {\n            self.0.remove(&key);'),
('        inventory(view, &mut dots)?;', '        log::debug!(target: "vakint::phase", "phase=scalar_inventory_start bytes={}", view.get_byte_size());\n        inventory(view, &mut dots)?;\n        log::debug!(target: "vakint::phase", "phase=scalar_inventory_done dots={}", dots.len());'),
('        let protected = view.replace_map(|term, _, out| {', '        log::debug!(target: "vakint::phase", "phase=scalar_protect_start");\n        let protected = view.replace_map(|term, _, out| {'),
('        for (monomial, mut coefficient) in protected.coefficient_list::<i32>(&dots) {', '        log::debug!(target: "vakint::phase", "phase=scalar_protect_done bytes={} aliases={}", protected.as_view().get_byte_size(), aliases.len());\n        log::debug!(target: "vakint::phase", "phase=coefficient_list_start");\n        for (monomial, mut coefficient) in protected.coefficient_list::<i32>(&dots) {\n            log::debug!(target: "vakint::phase", "phase=coefficient_row key={} bytes={}", monomial, coefficient.as_view().get_byte_size());'),
('            result.insert(monomial, coefficient);', '            log::debug!(target: "vakint::phase", "phase=coefficient_restored key={} bytes={}", monomial, coefficient.as_view().get_byte_size());\n            result.insert(monomial, coefficient);'),
('        let mut used = self.expression().get_all_symbols(true);', '        log::debug!(target: "vakint::phase", "phase=kernel_symbol_inventory_start monomials={}", self.0.len());\n        let mut used = self.expression().get_all_symbols(true);\n        log::debug!(target: "vakint::phase", "phase=kernel_symbol_inventory_done");'),
('            let pole_order = Self::epsilon_pole_order(coefficient.as_view(), settings)?;', '            log::debug!(target: "vakint::phase", "phase=kernel_coefficient_pole_start key={} bytes={}", monomial, coefficient.as_view().get_byte_size());\n            let pole_order = Self::epsilon_pole_order(coefficient.as_view(), settings)?;\n            log::debug!(target: "vakint::phase", "phase=kernel_coefficient_pole_done key={} pole_order={}", monomial, pole_order);'),
]
for old, new in replacements:
    expected = 2 if old == '        let mut used = self.expression().get_all_symbols(true);' else 1
    assert projection.count(old) == expected, old
    projection = projection.replace(old, new, 1)
patches = []
for relative, text in [('crates/vakint/src/lib.rs', lib), ('crates/vakint/src/projection.rs', projection)]:
    path = out / 'modified' / relative
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text)
    original = (source / relative).read_text()
    patches.extend(difflib.unified_diff(original.splitlines(keepends=True), text.splitlines(keepends=True), fromfile='a/' + relative, tofile='b/' + relative))
(out / 'vakint-phase-logging.patch').write_text(''.join(patches))
(out / 'preparation.json').write_text(json.dumps({'source_workspace': str(source), 'modified_files': [{'path': str(out / 'modified' / relative), 'source_sha256': hashlib.sha256((source / relative).read_bytes()).hexdigest(), 'modified_sha256': hashlib.sha256((out / 'modified' / relative).read_bytes()).hexdigest()} for relative in ['crates/vakint/src/lib.rs', 'crates/vakint/src/projection.rs']], 'filter': 'off,gammalooprs::uv::approx::integrated=debug,vakint::phase=debug', 'logging_only': True, 'new_helpers_types_methods': 0, 'production_mutated': False, 'build_run': False}, indent=2) + '\n')
print(json.dumps({'projected_terms': len(inputs), 'patch': str(out / 'vakint-phase-logging.patch'), 'source_files': 2}))

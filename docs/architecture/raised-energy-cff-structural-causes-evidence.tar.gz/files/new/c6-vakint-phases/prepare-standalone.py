"""Copy only native Vakint plus the phase logs into an isolated replay workspace."""
from pathlib import Path
import hashlib
import json
import shutil

base = Path('/tmp/raised-energy-causal-20260914/c6-vakint-phases')
source = Path('/tmp/raised-energy-expression-perf-20260914/diagnostic-workspaces/c6')
out = base / 'standalone'
assert not out.exists()
(out / 'src').mkdir(parents=True)
shutil.copytree(source / 'crates/vakint', out / 'crates/vakint')
for relative in ['crates/vakint/src/lib.rs', 'crates/vakint/src/projection.rs']:
    shutil.copy2(base / 'modified' / relative, out / relative)
shutil.copy2(source / 'Cargo.lock', out / 'Cargo.lock')
manifest = '''[package]
name = "c6-vakint-phase-replay"
version = "0.0.0"
edition = "2024"
publish = false

[workspace]
resolver = "2"
members = ["crates/vakint"]

[workspace.dependencies]
colored = "3.1.1"
eyre = "0.6.12"
pyo3 = "0.28"
pyo3-stub-gen = { version = "0.17", default-features = false }
thiserror = "2.0"
symbolica = { version = "2.2.0", default-features = false, features = ["gmp", "native_code_generation"] }

[dependencies]
env_logger = "=0.11.10"
eyre.workspace = true
idenso = { path = "NATIVE/crates/idenso" }
log = "0.4.29"
serde_json = "1"
spenso = { path = "NATIVE/crates/spenso", features = ["shadowing"] }
symbolica.workspace = true
vakint = { path = "crates/vakint" }

[patch.crates-io]
graphica = { git = "https://github.com/alphal00p/symbolica", rev = "4d0a833eb8e059d1f95bdae5abed2559830b235f" }
numerica = { git = "https://github.com/alphal00p/symbolica", rev = "4d0a833eb8e059d1f95bdae5abed2559830b235f" }
symbolica = { git = "https://github.com/alphal00p/symbolica", rev = "4d0a833eb8e059d1f95bdae5abed2559830b235f" }

[profile.dev-optim]
inherits = "dev"
opt-level = 2

[profile.dev-optim.package."*"]
opt-level = 3

[profile.dev-optim.package.idenso]
opt-level = 2

[profile.dev-optim.package.linnet]
opt-level = 2

[profile.dev-optim.package.spenso]
opt-level = 2

[profile.dev-optim.package.spenso-macros]
opt-level = 2

[profile.dev-optim.package.symbolica-utils]
opt-level = 2
'''.replace('NATIVE', str(source))
(out / 'Cargo.toml').write_text(manifest)
main = '''use std::{env, fs, path::PathBuf, time::Instant};

use eyre::{Result, eyre};
use serde_json::json;
use spenso::network::{library::symbolic::ETS, tags::SPENSO_TAG};
use symbolica::{atom::{Atom, AtomCore}, parser::ParseSettings, symbol, wrap_input};
use vakint::{
    AlphaLoopOptions, EvaluationMethod, EvaluationOrder, FMFTOptions,
    InputFloatRationalizationPrecision, LoopNormalizationFactor, MATADOptions, Vakint,
    VakintExpression, VakintSettings, VakintTerm,
};

fn main() -> Result<()> {
    let args = env::args().skip(1).collect::<Vec<_>>();
    if args.len() != 2 {
        return Err(eyre!("usage: c6-vakint-phase-replay CAPTURE_DIRECTORY FRESH_OUTPUT_DIRECTORY"));
    }
    let input = PathBuf::from(&args[0]);
    let output = PathBuf::from(&args[1]);
    if output.exists() {
        return Err(eyre!("output directory already exists"));
    }
    fs::create_dir_all(&output)?;
    env_logger::Builder::new()
        .filter_module("vakint::phase", log::LevelFilter::Debug)
        .format_timestamp_millis()
        .init();
    let total = Instant::now();
    // Reuse the native owners of all captured color and representation symbols.
    // GS's captured scalar symbols have no algebraic attributes; its hedge head
    // has only the same index tag below. Printer-only callbacks are not needed.
    let _ = idenso::color::CS.t;
    let _ = ETS.metric;
    let _ = symbol!("gammalooprs::hedge", tags = [SPENSO_TAG.index.clone()]);
    for name in ["gammalooprs::dim", "gammalooprs::ε", "gammalooprs::mUV", "gammalooprs::mUVexp", "gammalooprs::μᵣ²", "UFO::GC_10", "UFO::GC_11"] {
        let _ = symbol!(name);
    }
    let vakint = Vakint::new()?;
    let settings = VakintSettings {
        epsilon_symbol: "gammalooprs::ε".into(),
        mu_r_sq_symbol: "gammalooprs::μᵣ²".into(),
        form_exe_path: "form".into(),
        python_exe_path: "python3".into(),
        verify_numerator_identification: false,
        integral_normalization_factor: LoopNormalizationFactor::MSbar,
        run_time_decimal_precision: 100,
        allow_unknown_integrals: false,
        clean_tmp_dir: true,
        evaluation_order: EvaluationOrder(vec![
            EvaluationMethod::AlphaLoop(AlphaLoopOptions { susbstitute_masters: true }),
            EvaluationMethod::MATAD(MATADOptions {
                expand_masters: true,
                susbstitute_masters: true,
                substitute_hpls: true,
                direct_numerical_substition: true,
            }),
            EvaluationMethod::FMFT(FMFTOptions { expand_masters: true, susbstitute_masters: true }),
        ]),
        number_of_terms_in_epsilon_expansion: 3,
        precision_for_input_float_rationalization: InputFloatRationalizationPrecision::FullPrecision,
        use_dot_product_notation: false,
        project_onto_tensor_integrals: true,
        temporary_directory: None,
    };
    let recorded_settings = fs::read_to_string(input.join("settings-debug.txt"))?;
    if format!("{settings:?}") != recorded_settings.trim_end() {
        return Err(eyre!("explicit replay settings do not match native captured settings"));
    }
    println!("{}", json!({"stage":"initialized", "seconds":total.elapsed().as_secs_f64(), "settings_match":true}));
    let mut terms = Vec::with_capacity(10);
    for index in 0..10 {
        let numerator_text = fs::read_to_string(input.join(format!("term-{index:02}-numerator.atom")))?;
        let integral_text = fs::read_to_string(input.join(format!("term-{index:02}-integral.atom")))?;
        let numerator = Atom::parse_with_default_namespace(wrap_input!(&numerator_text), ParseSettings::default())
            .map_err(|error| eyre!("numerator {index}: {error}"))?;
        let integral = Atom::parse_with_default_namespace(wrap_input!(&integral_text), ParseSettings::default())
            .map_err(|error| eyre!("integral {index}: {error}"))?;
        fs::write(output.join(format!("term-{index:02}-parsed-numerator.atom")), numerator.to_canonical_string())?;
        fs::write(output.join(format!("term-{index:02}-parsed-integral.atom")), integral.to_canonical_string())?;
        println!("{}", json!({"stage":"parsed_term", "term_index":index, "numerator_bytes":numerator.as_view().get_byte_size(), "numerator_terms":numerator.nterms()}));
        // This field is not read by evaluate_integral. Keep it empty just as the
        // existing public direct-evaluation unit example in Vakint does.
        terms.push(VakintTerm { integral, numerator, vectors: vec![] });
    }
    let mut expression = VakintExpression(terms);
    let started = Instant::now();
    expression.evaluate_integral(&vakint, &settings)?;
    println!("{}", json!({"stage":"evaluate_complete", "seconds":started.elapsed().as_secs_f64()}));
    for (index, term) in expression.0.into_iter().enumerate() {
        fs::write(output.join(format!("term-{index:02}-result.atom")), (term.numerator * term.integral).to_canonical_string())?;
    }
    println!("{}", json!({"stage":"complete", "total_seconds":total.elapsed().as_secs_f64()}));
    Ok(())
}
'''
(out / 'src/main.rs').write_text(main)
checks = []
for path in sorted((source / 'crates/vakint').rglob('*')):
    if not path.is_file():
        continue
    relative = path.relative_to(source)
    copy = out / relative
    changed = relative.as_posix() in ['crates/vakint/src/lib.rs', 'crates/vakint/src/projection.rs']
    assert copy.exists()
    same = path.read_bytes() == copy.read_bytes()
    assert same != changed, relative
    checks.append({'relative': str(relative), 'source_sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'copy_sha256': hashlib.sha256(copy.read_bytes()).hexdigest(), 'phase_logging_change': changed})
(base / 'standalone-preparation.json').write_text(json.dumps({'path': str(out), 'source_revision_tree': '82e9ef7f1ef2362d61f0a9d8fe39059f590cefc5', 'copied_native_lock_sha256': hashlib.sha256((source / 'Cargo.lock').read_bytes()).hexdigest(), 'file_audit': checks, 'settings': 'Every field explicit; runtime Debug equality assertion against exact native capture precedes parsing/evaluation.', 'symbol_equivalence': 'Native Idenso and Spenso initialization registers color/representation heads and attributes. Vakint::new registers native S; plain GS scalar heads and index-tagged hedge match algebraic attributes. Native model UFO GC symbols have printer-only callbacks. Whole GammaLoop symbol allocation order and printer-only callbacks are not replayed; this is semantic named-symbol equivalence, not an identical Symbolica global state.', 'execution': 'Public VakintExpression::evaluate_integral on the complete ordered ten captured post-projection terms, with no recanonicalization, tensor reduction or numerator simplification outside that API.', 'source_changes': 'Only logging additions in copied Vakint, plus enumeration for per-term log index; logging-only-verification.json certifies restored source lines.', 'build': 'NOT_RUN', 'metadata': 'NOT_RUN', 'license': 'No OEM activation added; use already authorized runtime environment without accessing launcher contents.'}, indent=2) + '\n')
print(json.dumps({'workspace': str(out), 'copied_files': len(checks), 'changed_native_files': sum(row['phase_logging_change'] for row in checks), 'prepared': True}))

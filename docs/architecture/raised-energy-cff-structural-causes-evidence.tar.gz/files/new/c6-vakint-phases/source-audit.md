# C6 Vakint wait: source boundary and prepared replay

The native run completes all ten projected numerator algebra steps for reduced graph 140 by 23:14:26.344Z, 5.958 seconds after the receipt start. It reaches its 60-second observation limit with no completed evaluation-batch event. The late watchdog samples contain only the timeout process and GammaLoop process, at 99,954,688 total RSS bytes. They do not show a live FORM/Python backend process at those sample times.

The absence of `Vakint term after evaluation` does not locate the unfinished term: GammaLoop emits all those events only after `VakintExpression::evaluate_integral` returns for the entire batch. The first needed boundary is the per-term loop, not another numerator-algebra trace.

`captured-inputs.json` pairs each exact final projected numerator with its unchanged tensor-reduced integral by term index and identical integration span. The intervening source loop changes only `term.numerator`. All ten `.atom` pairs are preserved without algebraic transformation. `settings-debug.txt` is the exact native settings record. The expressions have three loop-dot variables each, 34–132 Add nodes, and maximum nested Add depth five. No function body depends on epsilon. Complete structure inventories, including every epsilon-dependent denominator, are in `input-structure.json`.

## Ordered stages and candidate mechanisms

Native source paths below are relative to `/tmp/raised-energy-expression-perf-20260914/diagnostic-workspaces/c6/crates/vakint/src/`.

1. `lib.rs:2971–2979`: sequentially evaluate each complete `VakintTerm`.
2. `lib.rs:2316–2354`: identify topology, apply denominator/numerator replacement rules, convert dot notation, call `ScalarTerms::parse`, then `backend_kernel` when projection is enabled.
3. `projection.rs:134–237`: inventory complete loop-dot variables, protect maximal external composite coefficients as aliases, collect only loop monomials using the existing AtomField collector, restore complete coefficient ASTs, and insert each coefficient.
4. `projection.rs:79–132`: `insert` accumulates the coefficient, then visits every additive subtree from the bottom up. Each subtree is copied to a scratch candidate and repeatedly passed through `collect_num` for exact real rational content, otherwise `collect_by_coefficient`. A BTreeSet stops exact-form recurrence; it is not a monotone complexity bound. Every nonzero transformed candidate is discarded, while proven-zero subtrees replace the corresponding source subtree. Repeated recursive collection, or a long sequence of distinct equivalent candidates, can therefore consume time without increasing the surviving expression. This is the specific extra expression-processing loop to measure; source inspection alone does not prove it is the long wait.
5. `projection.rs:253–283`: `backend_kernel` assembles one synthetic scalar kernel and calls `epsilon_pole_order` for each coefficient. That function invokes `epsilon_series` with relative depth one. `epsilon_series` first rejects epsilon-dependent opaque functions, then calls Symbolica's series machinery. The captured inputs pass the syntactic opaque-function exclusion, but series cost and leading-term cancellation remain candidates.
6. `lib.rs:2365–2399`: expand the small normalization factor to determine required raw orders; choose the supported backend. Captured settings request AlphaLoop, MATAD, FMFT in that order, MSbar normalization, three epsilon terms, projection enabled and 100 decimal digits.
7. `lib.rs:2465–2508`: execute the chosen backend, restore the complete external coefficients, perform final epsilon-series expansion, and restore requested non-dot output notation.

The pinned Symbolica source is `/home/codex/.cargo/git/checkouts/symbolica-7e92af2066df6214/4d0a833/src/collect.rs`, as required by native C6 Cargo.lock. Both collectors traverse expressions recursively. The Vakint-level recurrence guard is the additional loop under investigation. No polynomial conversion of the full graph numerator or trial expansion was used in this audit.

## Logging-only patch

`vakint-phase-logging.patch` and `modified/crates/vakint/src/{lib,projection}.rs` add `log::debug!` events with target `vakint::phase`. The only surrounding control-flow adjustment enumerates the existing evaluation loop to print its term index. There are no new functions, structs, helpers, semantic branches, tests, or changes to algebra. `logging-only-verification.json` confirms that removing the diagnostic log statements and restoring the original loop spelling reproduces every original nonblank source line.

The native logging filter is:

```
off,gammalooprs::uv::approx::integrated=debug,vakint::phase=debug
```

The final unmatched start event distinguishes the causes directly:

* `insert_collect_start` without its done event isolates one collector call. Increasing logged power-of-two iteration numbers identifies a long nonrepeating collection sequence. Logs retain the exact scratch candidate for that call.
* `coefficient_list_start` without a coefficient row isolates the loop-monomial collector; `coefficient_row` without `coefficient_restored` isolates alias restoration.
* `kernel_coefficient_pole_start` followed by `epsilon_series_start` without its done event isolates coefficient Laurent expansion.
* `backend_start` without `backend_done` isolates backend evaluation.
* `final_epsilon_series_start`/`epsilon_series_start` after backend completion isolates restored-coefficient series work.

## Prepared standalone execution

The `standalone/` workspace copies only the 44 native Vakint files; only two contain logging changes. Public native Idenso/Spenso initialization supplies the captured color and representation symbols. Public `Vakint::new` registers Vakint's own symbols. The only captured GammaLoop index head, `hedge`, is registered with its native index tag; other captured GammaLoop/UFO symbols have no algebraic attributes beyond their native print callbacks. The replay specifies every `VakintSettings` field explicitly and asserts exact equality of its Debug representation with the native captured settings before evaluation.

There is one declared limitation: full GammaLoop symbol allocation order and printer-only callbacks are not reproduced. The replay preserves named expressions, algebraic attributes, settings, complete terms, and the native evaluation method, but does not reproduce the whole native Symbolica global state. If it fails to reproduce the wait, the same phase patch must be used in the full native path before excluding either collector or series work.

The native lock was copied and resolved offline only in the new workspace. `standalone-lock-audit.json` verifies 404 retained package versions, sources and checksums; the sole new package is the probe root. Formatting and offline locked metadata pass. No compilation or runtime was performed during preparation.

`run-standalone.py build --attempt 01` performs guarded fmt/check/build/clippy. `run-standalone.py run --attempt 01 --build-receipt .../build-01/receipt.json` runs the ordered ten-term replay under the shared measurement lock, a 30 GB process-tree cap and a 60-second timeout with 15-second kill grace. It preserves the combined output, `main-events.jsonl`, `phase-events.log`, monitor samples and pre/post source hashes. Root owns the execution schedule.

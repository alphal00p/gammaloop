use color_eyre::{Result, eyre::eyre};
use serde_json::json;
use std::{env, fs, time::Instant};
use symbolica::{
    atom::{Atom, AtomCore},
    parser::ParseSettings,
    poly::series::SeriesDepth,
    symbol, wrap_input,
};

fn main() -> Result<()> {
    let args = env::args().skip(1).collect::<Vec<_>>();
    if args.len() != 3 {
        return Err(eyre!(
            "usage: cff-epsilon-zero-reproducer INPUT.atom MODE OUTPUT.json"
        ));
    }
    let text = fs::read_to_string(&args[0])?;
    let mut atom = Atom::parse_with_default_namespace(wrap_input!(&text), ParseSettings::default())
        .map_err(|error| eyre!("input parse failed: {error}"))?;
    let epsilon = symbol!("ε");
    let original = atom.clone();
    let started = Instant::now();
    if args[1] == "collected-relative" {
        atom = atom.collect_factors();
    }
    let preparation = json!({"stage":"prepared", "mode":args[1], "input":original.to_canonical_string(),
        "argument":atom.to_canonical_string(), "is_zero":atom.is_zero(), "prepare_seconds":started.elapsed().as_secs_f64()});
    println!("{preparation}");
    fs::write(&args[2], serde_json::to_vec_pretty(&preparation)?)?;
    let started = Instant::now();
    let series = atom.series(
        epsilon,
        0,
        if args[1] == "absolute" {
            SeriesDepth::absolute(0)
        } else {
            SeriesDepth::relative(1)
        },
    )?;
    let report = json!({"status":"SERIES_RETURNED", "preparation":preparation,
        "seconds":started.elapsed().as_secs_f64(), "result":series.to_atom().to_canonical_string(),
        "trailing_exponent":series.get_trailing_exponent().to_string()});
    fs::write(&args[2], serde_json::to_vec_pretty(&report)?)?;
    println!("{report}");
    Ok(())
}

from pathlib import Path
import fcntl,importlib.util,json,datetime,shutil
BASE=Path('/tmp/raised-energy-expression-perf-20260914')
OUT=Path('/tmp/raised-energy-causal-20260914/c6-series-zero-reproducer')
ROOT=Path('/common/dev/gammaloop/higher-power-energies-review')
lock=(BASE/'measurement.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
spec=importlib.util.spec_from_file_location('measure',BASE/'measure.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
assert m.digest(BASE/'measure.py')=='6f6ca7cbb51f5b606b93da4e00fe42465f3a194bc5efaf6e492df737cafad4d9'
m.PREFIX=BASE/'diagnostic-workspaces/c3';rev=next(x for x in json.loads((BASE/'revisions.json').read_text()) if x['label']=='c3')
pins=json.loads((OUT/'pins.json').read_text())
for path,sha in pins.items():assert m.digest(path)==sha,path
assert m.digest(m.WATCH)=='e94c98f65399e4cd0791ba050497ecaf4e745b4fdefc36fe036aae748f8152b9'
out=OUT/'run-01';out.mkdir()
r=dict(status='STARTED',pins=pins,tracked_before=m.audit(rev),stages=[],started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());assert r['tracked_before']['passed'];m.write(out/'receipt.json',r)
env=dict(CARGO_TARGET_DIR=str(ROOT/'target'),CARGO_BUILD_JOBS='4',RAYON_NUM_THREADS='8',RUST_MIN_STACK='134217728',INSTA_UPDATE='no',NEXTEST_RETRIES='0',GL_ALL_LOG_FILTER='off')
manifest=str(OUT/'Cargo.toml')
commands=[('metadata',['cargo','metadata','--offline','--locked','--format-version','1','--manifest-path',manifest]),('fmt',['cargo','fmt','--manifest-path',manifest,'--check'])]+[(x,['cargo',x,'--offline','--locked','--manifest-path',manifest,'--profile','dev-optim','-j','4']) for x in ['check','build','clippy']]
try:
 for name,command in commands:
  result=m.guarded(out,name,command,env);r['stages'].append(dict(stage=name,**result));m.write(out/'receipt.json',r)
  if result['status']!='PASS':raise RuntimeError(name+':'+result['status'])
 binary=out/'cff-epsilon-zero-reproducer';shutil.copy2(ROOT/'target/dev-optim'/binary.name,binary);r.update(binary=str(binary),binary_sha256=m.digest(binary))
 for input_name,mode in [('literal-zero','relative'),('captured-subtree','absolute'),('captured-subtree','collected-relative'),('captured-subtree','relative'),('minimal-subtree','relative')]:
  label=input_name+'-'+mode
  command=['/run/current-system/sw/bin/timeout','--verbose','--signal=TERM','--kill-after=5s','10s',str(binary),str(OUT/(input_name+'.atom')),mode,str(out/(label+'.json'))]
  result=m.guarded(out,label,command,env)
  lines=(out/label/'stdout.log').read_text(errors='replace').splitlines()
  signals=[line for line in lines if line.startswith('timeout: sending signal ') and str(binary) in line]
  if result['status']=='CHILD_FAILURE' and result['exit_code'] in [124,137] and signals:
   result.update(status='TIME_LIMIT',timeout_signal_lines=signals);m.write(out/label/'result.json',result)
  r['stages'].append(dict(stage=label,**result));m.write(out/'receipt.json',r)
 r.update(status='COMPLETE_CASE_MATRIX')
except BaseException as e:r.update(status='FAILURE',error=repr(e))
finally:
 r['tracked_after']=m.audit(rev)
 assert r['tracked_after']['passed']
 for path,sha in pins.items():assert m.digest(path)==sha,path
 r['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();m.write(out/'receipt.json',r)
 print(json.dumps(dict(status=r['status'],comparison_status=r.get('comparison_status'),receipt=str(out/'receipt.json'))),flush=True)
if r['status']=='FAILURE':raise SystemExit(1)

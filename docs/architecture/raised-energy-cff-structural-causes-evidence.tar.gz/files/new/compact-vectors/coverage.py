"""Inventory local compact slash opportunities without algebra execution."""
import ast
import hashlib
import json
from pathlib import Path

prior = Path('/tmp/raised-energy-expression-perf-20260914/upstream-expression-analysis')
out = Path('/tmp/raised-energy-causal-20260914/compact-vectors')
source = ast.parse((prior / 'analyze-captured-structure.py').read_text())
namespace = {}
definitions = []
for statement in source.body:
    if isinstance(statement, ast.For):
        break
    definitions.append(statement)
exec(compile(ast.Module(body=definitions, type_ignores=[]), '<existing text parser>', 'exec'), namespace)
parse = namespace['parse']
positions = namespace['positions']
split_at = namespace['split_at']
unparen = namespace['unparen']
records = []
for workload, number in [('orientation58', 6), ('orientation58', 7), ('orientation58', 8), ('orientation58', 15), ('g_gl1', 15), ('g_gl1', 16)]:
    path = prior / f'c3-{workload}-pre_network-000-terms' / f'{number:03}.atom'
    text = path.read_text()
    body = unparen(text)
    terms = split_at(body, positions(body, '*/'))
    gammas = []
    sums = []
    for index, factor in enumerate(terms):
        clean = unparen(factor)
        if clean.startswith('spenso::gamma(') and not positions(clean, '+-*/'):
            gammas.append((index, parse(clean)))
        if positions(clean, '+-'):
            sums.append((index, clean))
    candidates = []
    for gamma_index, gamma in gammas:
        slot = gamma.children[-1].text
        for sum_index, candidate in sums:
            if candidate.count(slot) == 2 and len(candidate) < 600:
                candidates.append({'gamma_factor_index': gamma_index, 'sum_factor_index': sum_index,
                                   'slot': slot, 'sum': candidate})
    records.append({'workload': workload, 'local_ordinal': number, 'path': str(path),
                    'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
                    'utf8_bytes': len(text.encode()), 'all_gamma_head_occurrences': text.count('spenso::gamma('),
                    'direct_gamma_count': len(gammas), 'direct_additive_factor_sizes': [len(s.encode()) for _, s in sums],
                    'small_direct_gamma_two_occurrence_sum_candidates': candidates,
                    'scope': 'Top-level local linear slash-sum opportunity inventory. Large rank-bearing sums are not traversed or distributed.'})
(out / 'dominant-term-coverage.json').write_text(json.dumps(records, ensure_ascii=False, indent=2) + '\n')
print(json.dumps([{k: v for k, v in record.items() if k not in ['small_direct_gamma_two_occurrence_sum_candidates', 'scope', 'path', 'sha256']} | {'candidate_count': len(record['small_direct_gamma_two_occurrence_sum_candidates'])} for record in records], indent=2))

"""Find repeated intact tensor factors in captured post-gamma GL1 sums."""
import ast
import collections
import hashlib
import json
from pathlib import Path

prior = Path('/tmp/raised-energy-expression-perf-20260914/upstream-expression-analysis')
out = Path('/tmp/raised-energy-causal-20260914/compact-vectors')
namespace = {}
source = ast.parse((prior / 'analyze-captured-structure.py').read_text())
definitions = []
for statement in source.body:
    if isinstance(statement, ast.For):
        break
    definitions.append(statement)
exec(compile(ast.Module(body=definitions, type_ignores=[]), '<existing text parser>', 'exec'), namespace)
source = ast.parse((prior / 'extract-factor-witnesses.py').read_text())
lazy_definition = next(statement for statement in source.body if isinstance(statement, ast.FunctionDef) and statement.name == 'lazy')
exec(compile(ast.Module(body=[lazy_definition], type_ignores=[]), '<existing lazy parser>', 'exec'), namespace)
lazy = namespace['lazy']
parse = namespace['parse']
records = []
for ordinal in [15, 16]:
    path = prior / 'c3-g_gl1-pre_network-000-terms' / f'{ordinal:03}.atom'
    stack = [('root', {'text': path.read_text()})]
    candidates = []
    while stack:
        location, node = stack.pop()
        node = lazy(node)
        if node['kind'] == 'add' and len(node['text']) > 1000:
            arm_factors = []
            for child in node['children']:
                child = lazy(child)
                while child['kind'] == 'neg':
                    child = lazy(child['children'][0])
                direct = child['children'] if child['kind'] == 'mul' else [child]
                selected = []
                for factor in direct:
                    factor = lazy(factor)
                    if factor['kind'] == 'fun' and factor['text'].startswith(('spenso::g(', 'spenso::δ(', 'gammalooprs::Q3(')):
                        selected.append(factor['text'])
                arm_factors.append(collections.Counter(selected))
            common = arm_factors[0].copy()
            for factors in arm_factors[1:]:
                common &= factors
            if common:
                candidates.append({'location': location, 'sum_utf8_bytes': len(node['text'].encode()), 'arms': len(node['children']), 'sum_sha256': hashlib.sha256(node['text'].encode()).hexdigest(), 'common': dict(common), 'per_arm_direct_tensor_factors': [dict(c) for c in arm_factors]})
        if node['kind'] in ['add', 'mul', 'neg']:
            stack.extend((location + '/' + node['kind'] + '[' + str(i) + ']', child) for i, child in enumerate(node['children']))
    candidates.sort(key=lambda candidate: candidate['sum_utf8_bytes'], reverse=True)
    records.append({'ordinal': ordinal, 'path': str(path), 'candidate_count': len(candidates), 'candidates': candidates})
(out / 'gl1-common-tensors.json').write_text(json.dumps(records, ensure_ascii=False, indent=2) + '\n')
print(json.dumps([{'ordinal': row['ordinal'], 'candidate_count': row['candidate_count'], 'largest': row['candidates'][:4]} for row in records], ensure_ascii=False, indent=2))

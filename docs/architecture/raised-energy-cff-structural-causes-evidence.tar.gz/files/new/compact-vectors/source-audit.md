# Compact-vector causality audit

The captured C3 expression has two algebraically equivalent compact alternatives, with different graph consequences. All artifacts use the existing C3 selector/energy map and retain the original coefficients, denominators, spinor endpoints and branch context. They do not compare C1/C3 physics.

For a single captured fermion factor, the reversible identities are

```
Gamma_ab^mu (Q3_mu + s E delta_0mu)
 = Gamma_ab(Q3 + s E delta_0)
 = Gamma_ab(Q3) + s E Gamma_ab(delta_0).
```

Only the contracted Lorentz slot is stripped in compact notation; the ordered spinor arguments are unchanged. The last expression stays one additive factor inside the product of six fermion factors. The graph numerator is never distributed across those factors.

The input is C3 attachment bare pre-network term 015, selected by all physical OSE(2..9), absence of mUV and its complete unique signed contribution. `proof.json` and `local-pairs.json` record source provenance and every exact factor. `bare-original.atom`, `bare-compact_sum_arguments.atom`, and `bare-slash_sums.atom` are directly replayable. The `whole-bare-*` artifacts replace only this exact term in the complete 1,986,903-byte payload, and inverse text replacement restores the source exactly.

## Actual parser boundary

All source paths below are relative to `/tmp/raised-energy-expression-perf-20260914/diagnostic-workspaces/c3/crates/`.

* `gammalooprs/src/numerator/symbolica_ext.rs:94-109`: the public `NumeratorAtomExt::parse_into_net` API uses `SchoonschipExpansionMode { inner_products: false, expand_schoonship: true, expand_inside_chains: true }`. It uses the public `ParsingNet` type and production `TENSORLIB`.
* `spenso/src/network/parsing/materialization.rs:168-195`: compact arguments receive a fresh explicit Lorentz slot and an added rank-one vector factor. Lines 304-316 accept an additive compact vector when every summand exposes the same representation. Lines 404-452 restore the same slot in every summand and preserve scalar products.
* Consequently `Gamma(Q3 + s E delta_0)` rematerializes to the original gamma times vector sum, up to dummy renaming and graph construction order. It is a notation control; no tensor rank reduction follows from the compact text alone.
* `spenso/src/network/parsing/mod.rs:889-1015` constructs an additive network from compatible summands via `n_add`. Thus `Gamma(Q3) + s E Gamma(delta_0)` exposes two spinor slots at its Sum boundary. Each branch performs one finite gamma/vector contraction before the sum can become a ready matrix tensor. The original instead has a rank-one vector Sum beside a rank-three gamma in the containing Product.
* With all six bare factors transformed, the containing product sees six rank-two slash-sum boundaries and six rank-three vertex gammas. The original sees six rank-one vector-sum boundaries, six rank-three edge gammas, and six rank-three vertex gammas. The local gamma/vector contraction has at most 16 matrix coordinates; global intermediate ranks still depend on the shared executor. The alternative duplicates gamma syntax across its two local summands, so a speedup is not assumed.
* `idenso/src/shorthands/schoonschip/api.rs:298-300` exposes the existing `to_dots` compactor. Its rank-one rule in `with_settings.rs:199-210` requires a rank-one function as a multiplicative factor. It does not match a vector sum. The network shortcut in `contraction.rs:1158` also rejects composite rank-one operands, so calling an existing broad compactor on the whole C3 expression is not a narrowly controlled way to obtain the intended local matrix sum.

## Fixed executor

No new Rust helper, type, public method or production/test edit is needed. The already-built probe source `/tmp/raised-energy-expression-perf-20260914/diagnostics/common-factor-contraction/src/main.rs` reads any prepared `.atom` input, parses it through `NumeratorAtomExt::parse_into_net`, aliases scalars at the native 4096-byte threshold, invokes `contract_ready_sum_boundaries`, executes `Sequential/MinIntermediateCost`, then the native `SequentialRef/SmallestDegree` completion pass, and resolves aliases. Reuse that same binary for both sides. Include parse, preparation, execution and result comparison in the measurements; do not infer cost from text length. Root owns all execution and resource guards.

## Dominant-term scope

`dominant-term-coverage.json` and `nested-coverage.json` separate this local slash mechanism from the dominant captured terms. Attachment term 006 has only its twelve outside gamma factors next to a 151,093-byte tensor Sum, and no local gamma/vector-sum pair at any nested Add/Mul site. Term 007 has ten small nested candidates and term 008 has sixteen. The latter are only syntactic candidates; no transformation/proof for them is claimed here. GL1 terms 015 and 016 contain zero gamma heads after gamma algebra, so a slash rewrite cannot act on those replay inputs.

The stronger attachment term-006 metric extraction is owned by the parallel hot-structure audit. It removes four genuinely free axes from the inner Sum; this is independent of the bare slash control.

For GL1, `gl1-common-tensors.json` locates exactly shared intact metric factors in large nested sums. Two factor-only controls are prepared in `gl1-term15-metric-control/` and `gl1-term16-metric-control/`. In each, only the largest sum is changed by `sum_i G*R_i = G*(sum_i R_i)`, with every complete original arm and remainder recorded and exact factor-multiset/inverse-text certificates. `G = g(mink(4,hedge(0)),mink(4,hedge(1)))`; these controls have respectively twelve and eighteen arms. The hot-structure incidence audit shows that one metric axis is free and the other contracts with the remainder: extraction relabels the exposed axis and keeps rank six. It may remove repeated metric work, but it does not explain a larger rank capacity by itself.

Only source inspection and lightweight text processing ran in this subtask. No Symbolica initialization, tensor execution, heavy build, workload, test changes or production edits occurred. No licensed `/tmp/raised-stack/run` content was accessed.

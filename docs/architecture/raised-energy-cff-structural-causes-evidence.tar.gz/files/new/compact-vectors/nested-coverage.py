"""Use existing lazy parser to locate local vector sums inside complete UV terms."""
import ast
import json
from pathlib import Path

prior = Path('/tmp/raised-energy-expression-perf-20260914/upstream-expression-analysis')
out = Path('/tmp/raised-energy-causal-20260914/compact-vectors')
namespace = {}
source = ast.parse((prior / 'analyze-captured-structure.py').read_text())
definitions = []
for statement in source.body:
    if isinstance(statement, ast.For):
        break
    definitions.append(statement)
exec(compile(ast.Module(body=definitions, type_ignores=[]), '<existing text parser>', 'exec'), namespace)
source = ast.parse((prior / 'extract-factor-witnesses.py').read_text())
lazy_definition = next(statement for statement in source.body if isinstance(statement, ast.FunctionDef) and statement.name == 'lazy')
exec(compile(ast.Module(body=[lazy_definition], type_ignores=[]), '<existing lazy parser>', 'exec'), namespace)
lazy = namespace['lazy']
parse = namespace['parse']
records = []
for ordinal in [6, 7, 8]:
    path = prior / 'c3-orientation58-pre_network-000-terms' / f'{ordinal:03}.atom'
    stack = [('root', {'text': path.read_text()})]
    candidate_rows = []
    while stack:
        location, node = stack.pop()
        node = lazy(node)
        if node['kind'] == 'mul':
            children = [lazy(child) for child in node['children']]
            gammas = [(i, child) for i, child in enumerate(children) if child['kind'] == 'fun' and child['text'].startswith('spenso::gamma(')]
            for gamma_index, gamma in gammas:
                slot = parse(gamma['text']).children[-1].text
                for sum_index, child in enumerate(children):
                    if child['kind'] == 'add' and len(child['text']) < 600 and child['text'].count(slot) == 2:
                        candidate_rows.append({'location': location, 'gamma_index': gamma_index, 'sum_index': sum_index, 'slot': slot, 'gamma': gamma['text'], 'sum': child['text']})
        if node['kind'] in ['add', 'mul', 'neg']:
            stack.extend((location + '/' + node['kind'] + '[' + str(i) + ']', child) for i, child in enumerate(node['children']))
    records.append({'ordinal': ordinal, 'path': str(path), 'candidate_count': len(candidate_rows), 'candidates': candidate_rows})
(out / 'nested-coverage.json').write_text(json.dumps(records, ensure_ascii=False, indent=2) + '\n')
print(json.dumps([{'ordinal': r['ordinal'], 'candidate_count': r['candidate_count']} for r in records]))

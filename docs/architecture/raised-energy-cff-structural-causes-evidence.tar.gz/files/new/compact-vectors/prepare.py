"""Prepare a captured bare-term slash boundary A/B using existing text parser APIs."""
import ast
import collections
import hashlib
import json
from pathlib import Path

prior = Path('/tmp/raised-energy-expression-perf-20260914/upstream-expression-analysis')
out = Path('/tmp/raised-energy-causal-20260914/compact-vectors')
source = ast.parse((prior / 'analyze-captured-structure.py').read_text())
definitions = []
for statement in source.body:
    if isinstance(statement, ast.For):
        break
    definitions.append(statement)
namespace = {}
exec(compile(ast.Module(body=definitions, type_ignores=[]), '<existing text parser>', 'exec'), namespace)
parse = namespace['parse']
factors = namespace['factors']
normalizer = next(statement for statement in ast.parse((prior / 'extract-factor-witnesses.py').read_text()).body if isinstance(statement, ast.FunctionDef) and statement.name == 'normalize_product')
exec(compile(ast.Module(body=[normalizer], type_ignores=[]), '<existing product normalization>', 'exec'), globals())

metadata = json.loads((prior / 'c3-orientation58-pre_network-000-structure.json').read_text())
selected = []
for term in metadata['terms']:
    text = Path(term['path']).read_text()
    if 'mUV' not in text and all(f'gammalooprs::OSE({edge})' in text for edge in range(2, 10)):
        selected.append((term, text))
assert len(selected) == 1
term, original = selected[0]
root = parse(original)
assert root.kind == 'mul'
original_factors = factors(root)
pairs = []
by_digest = {}
for edge, sign in [(2, 1), (3, 1), (4, -1), (5, -1), (8, 1), (9, -1)]:
    slot = f'spenso::mink(4,gammalooprs::edge({edge},1))'
    compact_rep = 'spenso::mink(4)'
    vector = f'gammalooprs::Q3({edge},{slot})'
    delta = f'spenso::δ(spenso::cind(0),{slot})'
    energy = f'gammalooprs::OSE({edge})'
    indexed_sum = vector + ('+' if sign > 0 else '-') + delta + '*' + energy
    matches = [factor for factor in original_factors if factor.kind == 'fun' and factor.name == 'spenso::gamma' and factor.children[-1].text == slot]
    assert len(matches) == 1
    gamma = matches[0]
    matches = [factor for factor in original_factors if factor.kind == 'add' and factor.text == indexed_sum]
    assert len(matches) == 1
    vector_sum = matches[0]
    assert sum(factor.text.count(slot) for factor in original_factors) == 3
    prefix = gamma.text[:-len(slot)-1]
    compact_vector = vector.replace(slot, compact_rep)
    compact_delta = delta.replace(slot, compact_rep)
    # The one-factor slash sum uses only gamma linearity in its contracted axis.
    # No other numerator factor, sum, coefficient, selector or denominator moves.
    slash_sum = prefix + compact_vector + ')' + ('+' if sign > 0 else '-') + energy + '*' + prefix + compact_delta + ')'
    compact_sum_argument = prefix + indexed_sum.replace(slot, compact_rep) + ')'
    assert compact_sum_argument.replace(indexed_sum.replace(slot, compact_rep), slot) == gamma.text
    assert indexed_sum.replace(slot, compact_rep).replace(compact_rep, slot) == indexed_sum
    pairs.append({'edge': edge, 'energy_sign': sign, 'slot': slot, 'gamma': gamma.text,
                  'vector_sum': indexed_sum, 'local_slash_sum': slash_sum,
                  'compact_sum_argument': compact_sum_argument,
                  'original_gamma_factor_index': original_factors.index(gamma),
                  'original_vector_factor_index': original_factors.index(vector_sum),
                  'gamma_digest': gamma.digest, 'vector_digest': vector_sum.digest})
    by_digest[gamma.digest] = ('remove', None)
    by_digest[vector_sum.digest] = ('replace', pairs[-1])

# Rebuild only the containing product; compare its untouched factors exactly.
variants = {}
for label, key in [('slash_sums', 'local_slash_sum'), ('compact_sum_arguments', 'compact_sum_argument')]:
    replacements = []
    preserved = []
    preserved_nodes = []
    for factor in original_factors:
        action, pair = by_digest.get(factor.digest, ('keep', None))
        if action == 'remove':
            continue
        if action == 'replace':
            replacements.append('(' + pair[key] + ')')
        else:
            replacements.append('(' + factor.text + ')')
            preserved.append(factor.digest)
            preserved_nodes.append(factor)
    alternative = '*'.join(replacements)
    reparsed = parse(alternative)
    assert normalize_product([reparsed]) == normalize_product(preserved_nodes + [parse(pair[key]) for pair in pairs])
    assert len(preserved) == len(original_factors) - 12
    variants[label] = alternative
    (out / f'bare-{label}.atom').write_text(alternative)
    whole = Path(metadata['path']).read_text()
    assert whole.count(original) == 1
    rewritten = whole.replace(original, alternative, 1)
    assert rewritten.count(alternative) == 1
    assert rewritten.replace(alternative, original, 1) == whole
    (out / f'whole-bare-{label}.atom').write_text(rewritten)

(out / 'bare-original.atom').write_text(original)
(out / 'local-pairs.json').write_text(json.dumps(pairs, ensure_ascii=False, indent=2) + '\n')
artifacts = []
for path in sorted(out.glob('*.atom')):
    artifacts.append({'path': str(path), 'utf8_bytes': path.stat().st_size,
                      'sha256': hashlib.sha256(path.read_bytes()).hexdigest()})
proof = {'scope': 'C3 namespace-preserving captured complete bare contribution; six local fermion factors only',
         'source_metadata': str(prior / 'c3-orientation58-pre_network-000-structure.json'),
         'source_revision': metadata['revision'], 'source_log': metadata['log'],
         'source_log_line': metadata['line'], 'source_field': metadata['field'],
         'source_term': term['path'], 'source_whole_sha256': metadata['sha256'],
         'identity': 'Gamma_ab^mu [Q3_mu + s E delta_0mu] = Gamma_ab(Q3) + s E Gamma_ab(delta_0); alternatively = Gamma_ab(Q3 + s E delta_0).',
         'proof': 'Each complete gamma and vector factor is recorded in local-pairs.json with exact ordered spinor indices, edge slot, scalar energy and sign. Only the unique contracted slot is stripped. The inverse compact-notation materialization restores gamma_ab^mu and its vector sum; gamma linearity proves the slash-sum identity. This applies independently to each of six original factors. All other direct factors, including complete coefficient, complete denominator, six vertex gammas, tree_denoms and sigma(58), are checked by the existing signed product normalizer, permitting only associative multiplication and multiplicative identities introduced by explicit reciprocal factors. The six slash sums remain factors in one product; no product of numerator sums is distributed.',
         'local_pair_count': len(pairs), 'untouched_factor_count': len(preserved),
         'inverse_whole_text_replacement_restores_original_exactly': True,
         'limitations': ['Text-only construction and source proof; no symbolic engine or workload execution performed.',
                        'The compact-sum-argument control materializes back to the same explicit vector-sum topology under native C3 parse_into_net settings.',
                        'The slash-sum alternative introduces local matrix-valued Sum boundaries, and its cost must be measured with the same executor.',
                        'No C1/C3 forest/selector/rational identity is required or asserted.'],
         'artifacts': artifacts}
(out / 'proof.json').write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'pairs': len(pairs), 'preserved_factors': len(preserved), 'artifacts': artifacts}, indent=2))

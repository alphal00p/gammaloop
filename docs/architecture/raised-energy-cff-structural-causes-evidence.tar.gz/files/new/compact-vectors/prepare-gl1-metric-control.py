"""Extract one exactly common metric from each dominant GL1 region, independently."""
import ast
import collections
import hashlib
import json
from pathlib import Path

prior = Path('/tmp/raised-energy-expression-perf-20260914/upstream-expression-analysis')
out = Path('/tmp/raised-energy-causal-20260914/compact-vectors')
namespace = {}
source = ast.parse((prior / 'analyze-captured-structure.py').read_text())
definitions = []
for statement in source.body:
    if isinstance(statement, ast.For):
        break
    definitions.append(statement)
exec(compile(ast.Module(body=definitions, type_ignores=[]), '<existing text parser>', 'exec'), namespace)
source = ast.parse((prior / 'extract-factor-witnesses.py').read_text())
definitions = [statement for statement in source.body if isinstance(statement, ast.FunctionDef) and statement.name in ['lazy', 'locate']]
exec(compile(ast.Module(body=definitions, type_ignores=[]), '<existing factor witness locators>', 'exec'), namespace)
lazy = namespace['lazy']
locate = namespace['locate']
inventory = json.loads((out / 'gl1-common-tensors.json').read_text())
records = []
for term in inventory:
    candidate = term['candidates'][0]
    whole = Path(term['path']).read_text()
    node = locate(whole, candidate['location'])
    assert node['kind'] == 'add'
    assert hashlib.sha256(node['text'].encode()).hexdigest() == candidate['sum_sha256']
    assert len(candidate['common']) == 1
    metric, multiplicity = next(iter(candidate['common'].items()))
    assert multiplicity == 1
    directory = out / f'gl1-term{term["ordinal"]}-metric-control'
    directory.mkdir(exist_ok=True)
    branches = []
    remainders = []
    for ordinal, arm in enumerate(node['children']):
        arm = lazy(arm)
        original_arm = arm['text']
        sign = 1
        while arm['kind'] == 'neg':
            sign = -sign
            arm = lazy(arm['children'][0])
        factors = [lazy(factor) for factor in (arm['children'] if arm['kind'] == 'mul' else [arm])]
        pending = 1
        rest = []
        removed = []
        for factor in factors:
            if pending and factor['text'] == metric:
                pending -= 1
                removed.append(factor['text'])
            else:
                rest.append(factor['text'])
        assert pending == 0
        assert collections.Counter(rest + removed) == collections.Counter(factor['text'] for factor in factors)
        remainder = '*'.join('(' + factor + ')' for factor in rest) or '1'
        if sign < 0:
            remainder = '-(' + remainder + ')'
        (directory / f'arm-{ordinal:02}-original.atom').write_text(original_arm)
        (directory / f'arm-{ordinal:02}-remainder.atom').write_text(remainder)
        branches.append({'ordinal': ordinal, 'sign': sign, 'factor_text_sha256': [hashlib.sha256(factor['text'].encode()).hexdigest() for factor in factors], 'removed_metric_count': 1, 'remainder_factor_text_sha256': [hashlib.sha256(factor.encode()).hexdigest() for factor in rest], 'complete_signed_factor_multiset_reassembly_equal': True})
        remainders.append(remainder)
    alternative = '(' + metric + ')*(' + '+'.join('(' + remainder + ')' for remainder in remainders) + ')'
    assert whole.count(node['text']) == 1
    altered = whole.replace(node['text'], alternative, 1)
    assert altered.count(alternative) == 1
    assert altered.replace(alternative, node['text'], 1) == whole
    (directory / 'original-term.atom').write_text(whole)
    (directory / 'metric-factored-term.atom').write_text(altered)
    (directory / 'original-sum.atom').write_text(node['text'])
    (directory / 'metric-factored-sum.atom').write_text(alternative)
    (directory / 'common-metric.atom').write_text(metric)
    artifacts = []
    for path in sorted(directory.glob('*.atom')):
        artifacts.append({'path': str(path), 'utf8_bytes': path.stat().st_size, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()})
    proof = {'source': term['path'], 'source_sha256': hashlib.sha256(whole.encode()).hexdigest(), 'sum_location': candidate['location'], 'identity': 'sum_i G*R_i = G*(sum_i R_i)', 'common_metric': metric, 'arms': branches, 'inverse_term_text_replacement_restores_original_exactly': True, 'proof': 'Every complete signed arm is parsed with the preexisting balanced Add/Mul splitter. Exactly one byte-identical direct metric factor is removed from every arm; signed reassembly compares the complete original factor multiset. All coefficients, selectors, denominator factors, routing atoms, function arguments and nested numerator sums remain intact. Only associative parentheses and multiplication notation change on retained factors. No graph numerator product is distributed, no denominator simplified and no scalar factor discarded.', 'rank_effect': 'The metric has one exposed slot and one slot contracted with the remainder. Extracting it relabels the exposed slot h0 to h1 inside this sum and leaves rank6 unchanged; this is a repeated-metric-work control, not a rank-reduction intervention.', 'source_incidence_audit': '/tmp/raised-energy-causal-20260914/hot-structure/connectivity.json', 'execution': 'No Symbolica or tensor execution performed in preparation.', 'artifacts': artifacts}
    (directory / 'proof.json').write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n')
    records.append({'ordinal': term['ordinal'], 'directory': str(directory), 'arms': len(branches), 'original_bytes': len(whole.encode()), 'alternative_bytes': len(altered.encode())})
(out / 'gl1-metric-controls.json').write_text(json.dumps(records, indent=2) + '\n')
print(json.dumps(records, indent=2))

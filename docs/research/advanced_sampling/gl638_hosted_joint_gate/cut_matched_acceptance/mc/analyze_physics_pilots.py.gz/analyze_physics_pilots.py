#!/usr/bin/env python3
"""Audit saved Integrate JSON and pool its existing estimators; never run physics.

Usage: analyze_physics_pilots.py MANIFEST PILOT_DIRECTORY [--pilot-directory MORE]
       [--workers N] [--exclude-pilot-directory CONTROL] [--screen SCREEN_JSON]
The first real pilot directory receives the analysis. Additional inputs retain
their original workspace paths; excluded throughput controls never enter pooling.
The confirmation invocation requires the frozen screen report. All inputs and
invalid/missing runs remain in the report; no printed-coordinate replay is made.
Pooling follows the existing GL638 X2 audit_results.py analysis.
"""
from pathlib import Path
import argparse
import copy
import hashlib
import json
import math
import sys
import tomllib

PHASES = ("re", "im")
COUNTERPART = {
    "cuts_joint": "cuts", "cuts_joint_soft": "cuts_soft",
    "cuts_combined_joint": "cuts", "cuts_combined_joint_soft": "cuts_soft",
}
BASELINE = "optimized_lmb"


def read(path):
    return json.loads(Path(path).read_text())


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def finite(value):
    value = float(value)
    if not math.isfinite(value):
        raise ValueError("nonfinite retained number")
    return value


def pool(values, errors, n):
    """Existing X2 pooled sample second moment, plus seed-mean diagnostics."""
    k = len(values)
    if k < 2 or n <= 1 or len(errors) != k:
        raise ValueError("pooling requires at least two complete equal-N seeds")
    mean = math.fsum(values) / k
    between = math.fsum((value - mean) ** 2 for value in values)
    m2 = math.fsum(n * (n - 1) * error ** 2 + n * (value - mean) ** 2
                   for value, error in zip(values, errors))
    total = k * n
    return {"mean": mean, "standard_error": math.sqrt(m2 / (total * (total - 1))),
            "seed_mean_standard_error": math.sqrt(between / (k * (k - 1))),
            "sample_variance": m2 / (total - 1),
            "sum_squares": m2 + total * mean ** 2, "samples": total,
            "seed_means": values, "seed_errors": errors}


def analyze(manifest_path, directory, screen_path=None, pilot_directories=(),
            excluded_directories=(), workers=None):
    manifest = read(manifest_path)
    modes, seeds = manifest["proposal_order"], manifest["paired_seeds"]
    n = int(manifest["samples_per_run"])
    if len(set(modes)) != len(modes) or len(set(seeds)) != len(seeds):
        raise ValueError("duplicate requested method or seed")
    stage = "confirmation" if screen_path else "screen"
    expected_seeds = ([10007, 20011, 30013, 40009, 50021] if screen_path
                      else [11113, 22229, 33331])
    if seeds != expected_seeds or n != (32768 if screen_path else 2048):
        raise ValueError("run differs from the fixed approved seed/N protocol")
    report = {"passed": False, "stage": stage, "manifest": str(manifest_path),
              "manifest_sha256": digest(manifest_path), "modes": modes,
              "seeds": seeds, "samples_per_seed": n, "runs": [], "failures": [],
              "pooled": [], "matched_comparisons": [], "selection": None,
              "scope": "Existing full-GL638 Integrate results; separate signed Re/Im and |Re|/|Im|. Empirical finite-N errors/extremes, no finite-variance or global boundedness certificate. Printed maxima are not complete replay Samples.",
              "pooling": "M=kn; M2=sum[n(n-1)e_i^2+n(mu_i-mu)^2]; SE^2=M2/[M(M-1)]. Same seeds pair schedules, not physical points; paired differences use seed-mean dispersion.",
              "source_analysis_owner": "/tmp/gl638-x2-pilot/audit_results.py",
              "input_sha256": {str(manifest_path): digest(manifest_path)}}
    directories = [Path(p).resolve(strict=True) for p in [directory, *pilot_directories]]
    excluded = [Path(p).resolve(strict=True) for p in excluded_directories]
    if (len(set(directories)) != len(directories) or len(set(excluded)) != len(excluded)
            or set(directories) & set(excluded)):
        raise ValueError("duplicate or simultaneously included/excluded real pilot directory")
    if not all(p.is_dir() for p in directories + excluded):
        raise ValueError("pilot inputs must be existing real directories")
    report["pilot_directories"] = [str(p) for p in directories]
    report["excluded_controls"] = []
    for control in excluded:
        paths = [control / name for name in ("pilots.json", "summary.json")]
        summary = read(paths[1])
        report["input_sha256"].update({str(p): digest(p) for p in paths})
        report["excluded_controls"].append({
            "directory": str(control), "workers": summary.get("workers"),
            "status": summary.get("status"), "error": summary.get("error"),
            "mode_seed_pairs": [[r["mode"], r["seed"]] for r in read(paths[0])],
            "scope": "Throughput control explicitly excluded from estimates, errors and maxima"})
    expected_build = {
        "driver_sha256": manifest["candidate_driver_sha256"],
        "source_base_commit": manifest["source_base_commit"],
        "source_candidate_commit": manifest.get("source_candidate_commit"),
        "source_candidate_patch_sha256": manifest["source_candidate_patch_sha256"],
        "candidate_binary_sha256": manifest["candidate_binary_sha256"],
    }
    preflight_path = Path(manifest["preflight_summary"]).resolve(strict=True)
    preflight = read(preflight_path)
    report["input_sha256"][str(preflight_path)] = digest(preflight_path)
    if (not preflight["preflight_accepted"] or not preflight["saved_state_unchanged"]
            or preflight.get("error") is not None or not preflight["physics_audit"]["passed"]
            or preflight["build_identity"] != expected_build):
        raise ValueError("declared common source/state/physics preflight failed")
    if workers is not None and manifest.get("cores") not in (None, workers):
        raise ValueError("requested workers differ from the frozen manifest")
    chosen_workers = workers if workers is not None else manifest.get("cores")
    indexed = {}
    for origin in directories:
        pilots_path, summary_path = origin / "pilots.json", origin / "summary.json"
        pilots = read(pilots_path)
        report["input_sha256"].update({str(p): digest(p) for p in [pilots_path, summary_path]})
        try:
            summary = read(summary_path)
            if chosen_workers is None:
                chosen_workers = summary["workers"]
            if (chosen_workers not in (20, 30) or summary["workers"] != chosen_workers
                    or summary["stage"] != "physics-pilot"
                    or summary["status"] != "completed_requested_stages"
                    or not summary["preflight_accepted"] or not summary["saved_state_unchanged"]
                    or summary.get("error") is not None or not summary["physics_audit"]["passed"]
                    or summary["build_identity"] != expected_build
                    or summary["state_hashes"] != preflight["state_hashes"]
                    or Path(summary["preflight_reused_from"]).resolve(strict=True) != preflight_path):
                raise ValueError("pilot batch differs in workers/source/state/common preflight or failed")
            before, after = [read(origin / f"state_{when}.json") for when in ("before", "after")]
            if before != after or before != preflight["state_hashes"]:
                raise ValueError("pilot batch saved-state hash mismatch")
            for when in ("before", "after"):
                path = origin / f"state_{when}.json"
                report["input_sha256"][str(path)] = digest(path)
        except (OSError, KeyError, TypeError, ValueError) as error:
            report["failures"].append({"directory": str(origin), "error": str(error),
                                       "scope": "batch acceptance; partial runs remain below"})
        for row in pilots:
            key = (row["mode"], row["seed"])
            if key in indexed:
                raise ValueError(f"duplicate pilot row {key}; do not include both throughput controls")
            indexed[key] = (row, origin)
    report["workers"] = chosen_workers
    report["common_preflight"] = str(preflight_path)
    report["build_identity"] = expected_build
    if set(indexed) - {(mode, seed) for mode in modes for seed in seeds}:
        raise ValueError("undeclared pilot method/seed")
    common_physics = None
    for seed in seeds:
        for mode in modes:
            record = {"mode": mode, "seed": seed, "eligible": False}
            try:
                row, origin = indexed[(mode, seed)]
                record["pilot_directory"] = str(origin)
                record["retained_driver_record"] = {k: v for k, v in row.items() if k != "result"}
                record["driver_result_status"] = {k: v for k, v in row["result"].items() if k != "output"}
                if (row["sample_count"] != n or row["cores"] != chosen_workers
                        or row.get("diagnostic_only", False)
                        or not row.get("preflight_accepted", False)
                        or not row["result"].get("finite_complete", False)):
                    raise ValueError("incomplete, invalid or ungated pilot retained")
                workspace = Path(row["workspace"]).resolve(strict=True)
                if not workspace.is_dir() or not workspace.is_relative_to(origin):
                    raise ValueError("workspace is not retained inside its original pilot directory")
                record["retained_driver_record"]["workspace"] = str(workspace)
                settings_path = workspace.parent / "effective-settings.toml"
                result_path = workspace / "integration_result.json"
                settings = tomllib.loads(settings_path.read_text())
                mode_settings_path = origin / f"{mode}.settings.toml"
                mode_settings = tomllib.loads(mode_settings_path.read_text())
                mode_report_path = origin / f"{mode}.json"
                mode_report = read(mode_report_path)
                if not mode_report["preflight_accepted"] or mode_report.get("error") is not None:
                    raise ValueError("mode acceptance missing or failed")
                card_path = Path(manifest["cards"][mode])
                if digest(card_path) != manifest["card_sha256"][str(card_path)]:
                    raise ValueError("frozen candidate card hash changed")
                card = tomllib.loads(card_path.read_text())
                for path in (settings_path, result_path, card_path, mode_settings_path, mode_report_path):
                    report["input_sha256"][str(path)] = digest(path)
                si = settings["integrator"]
                if (si["seed"] != seed or si["n_start"] != n or si["n_max"] != n
                        or si["n_increase"] != 0):
                    raise ValueError("not the approved fresh single fixed-N iteration")
                sampling = settings["sampling"]
                if (sampling["sampling_channels"] != "monte_carlo"
                        or sampling.get("orientations", "summed") != "summed"
                        or sampling["channel_selection"] != card["sampling"]["channel_selection"]
                        or sampling != mode_settings["sampling"]):
                    raise ValueError("sampling/orientation catalogue differs from card")
                if (settings["general"].get("generate_events", False)
                        or settings["general"].get("orientation_pat", {}).get("pat") is not None
                        or settings["subtraction"].get("disable_threshold_subtraction", False)):
                    raise ValueError("production physics/retention settings changed")
                physics = copy.deepcopy(settings)
                physics.pop("sampling")
                physics["integrator"].pop("seed")
                if common_physics is None:
                    common_physics = physics
                elif common_physics != physics:
                    raise ValueError("non-sampling settings differ between pilot runs")
                payload = read(result_path)
                if len(payload["slots"]) != 1:
                    raise ValueError("single graph-integrand slot expected")
                slot = payload["slots"][0]
                stat = slot["integration_statistics"]
                if (slot["integral"]["neval"] != n or slot["absolute"]["integral"]["neval"] != n
                        or stat["num_evals"] != n or stat["nan_percentage"] != 0
                        or stat["nan_or_unstable_percentage"] != 0):
                    raise ValueError("invalid/unstable or unequal completed evaluation counts")
                for integral in (slot["integral"], slot["absolute"]["integral"]):
                    for phase in PHASES:
                        finite(integral["result"][phase])
                        if finite(integral["error"][phase]) < 0:
                            raise ValueError("negative empirical error")
                for phase in PHASES:
                    if slot["absolute"]["integral"]["result"][phase] < 0:
                        raise ValueError("negative absolute mean")
                for maximum in slot["max_weight_info"]:
                    finite(maximum["max_eval"])
                record.update(eligible=True, slot=slot, result_path=str(result_path),
                              settings_path=str(settings_path), elapsed_seconds=row["elapsed_seconds"],
                              post_iteration_pdf_scope="updated grid diagnostics, not the original first-batch proposal probabilities")
            except (OSError, KeyError, TypeError, ValueError, ArithmeticError) as error:
                record["error"] = str(error)
                report["failures"].append({"mode": mode, "seed": seed, "error": str(error)})
            report["runs"].append(record)
    pooled = {}
    for mode in modes:
        runs = [r for r in report["runs"] if r["mode"] == mode]
        if len(runs) != len(seeds) or not all(r["eligible"] for r in runs):
            continue
        method = {"mode": mode, "observables": {}, "maxima": {},
                  "elapsed_seconds": math.fsum(r["elapsed_seconds"] for r in runs),
                  "mean_recorded_statistics": {
                      key: math.fsum(r["slot"]["integration_statistics"][key] for r in runs) / len(runs)
                      for key, value in runs[0]["slot"]["integration_statistics"].items()
                      if (key.startswith("average_") or key.endswith("percentage"))
                      and isinstance(value, (int, float))},
                  "timing_scope": "equal-N mean of existing per-run counters; elapsed includes Integrate setup; no new10% gate or optimization"}
        for phase in PHASES:
            for absolute in (False, True):
                integrals = [r["slot"]["absolute"]["integral"] if absolute else r["slot"]["integral"] for r in runs]
                key = ("abs_" if absolute else "") + phase
                method["observables"][key] = pool([x["result"][phase] for x in integrals], [x["error"][phase] for x in integrals], n)
            maxima = [{"mode": mode, "seed": r["seed"], "workspace": r["retained_driver_record"]["workspace"], **maximum}
                      for r in runs for maximum in r["slot"]["max_weight_info"] if maximum["component"] == phase]
            largest = max(maxima, key=lambda item: abs(item["max_eval"]), default=None)
            value = abs(largest["max_eval"]) if largest else 0.0
            absolute = method["observables"]["abs_" + phase]
            signed = method["observables"][phase]
            method["maxima"][phase] = {"largest_absolute_weight": value, "largest_record": largest,
                "all_signed_extrema": maxima,
                "fraction_of_absolute_integral_sum": value / (absolute["samples"] * absolute["mean"]) if absolute["mean"] else None,
                "fraction_of_empirical_sum_squares": value ** 2 / signed["sum_squares"] if signed["sum_squares"] else None,
                "replay_scope": "decode original complete Sample from workspace/state/integration_state.bin; these coordinate strings omit grid probabilities"}
        pooled[mode] = method
        report["pooled"].append(method)
    screen = read(screen_path) if screen_path else None
    if screen:
        if not screen["passed"] or not screen["selection"]:
            raise ValueError("confirmation requires a complete valid frozen screen selection")
        selection = screen["selection"]
        if chosen_workers != screen["workers"]:
            raise ValueError("confirmation workers differ from the frozen screen")
        if set(modes) != set(selection["confirmation_modes"]) or set(seeds) & set(screen["seeds"]):
            raise ValueError("confirmation changes frozen methods or reuses screening seeds")
        report["screen_sha256"] = digest(screen_path)
        report["selection"] = selection
        scales = selection["absolute_phase_scales"]
    else:
        scales = {p: pooled[BASELINE]["observables"]["abs_" + p]["mean"] for p in PHASES} if BASELINE in pooled else {}
    if scales and all(finite(v) > 0 for v in scales.values()):
        for method in report["pooled"]:
            method["normalized_variances"] = {key: value["sample_variance"] / scales[key.removeprefix("abs_")] ** 2
                                               for key, value in method["observables"].items()}
            method["score"] = max(method["normalized_variances"].values())
        if not screen and not report["failures"]:
            candidates = [m for m in modes if m in COUNTERPART]
            if set(modes) != {BASELINE, "cuts", "cuts_soft", *COUNTERPART}:
                raise ValueError("screen requires all seven fixed candidates")
            chosen = min(candidates, key=lambda m: (pooled[m]["score"], modes.index(m)))
            report["selection"] = {"confirmation_modes": [BASELINE, COUNTERPART[chosen], chosen],
                "primary_estimate_mode": chosen, "absolute_phase_scales": scales,
                "score_rule": "minimum worst normalized4-observable sample variance; exact ties use declared order; b has identical soft policy",
                "card_sha256": {m: manifest["card_sha256"][manifest["cards"][m]] for m in [BASELINE, COUNTERPART[chosen], chosen]},
                "candidate_driver_sha256": manifest["candidate_driver_sha256"]}
    else:
        report["failures"].append({"error": "no positive common baseline absolute scales; no artificial floor or selection"})
    if screen and report["selection"]:
        selection = report["selection"]
        if manifest["candidate_driver_sha256"] != selection["candidate_driver_sha256"]:
            raise ValueError("confirmation driver differs from frozen screen")
        if any(manifest["card_sha256"][manifest["cards"][m]] != selection["card_sha256"][m] for m in modes):
            raise ValueError("confirmation proposal cards differ; use manifest N/seed overrides only")
    comparisons = [(joint, base) for joint, base in COUNTERPART.items()]
    comparisons += [("cuts_combined_joint", "cuts_joint"), ("cuts_combined_joint_soft", "cuts_joint_soft")]
    for candidate, baseline in comparisons:
        if candidate not in pooled or baseline not in pooled:
            continue
        for key in pooled[candidate]["observables"]:
            a, b = pooled[candidate]["observables"][key], pooled[baseline]["observables"][key]
            differences = [x - y for x, y in zip(a["seed_means"], b["seed_means"])]
            mean = math.fsum(differences) / len(differences)
            pair_se = math.sqrt(math.fsum((x - mean) ** 2 for x in differences) / (len(differences) * (len(differences) - 1)))
            report["matched_comparisons"].append({"candidate": candidate, "baseline": baseline, "observable": key,
                "pooled_variance_ratio": a["sample_variance"] / b["sample_variance"] if b["sample_variance"] else None,
                "paired_seed_differences": differences, "mean_difference": mean, "seed_difference_standard_error": pair_se,
                "scope": "same seed schedule, not same physical momenta; few-seed descriptive error, no Gaussian significance claim"})
    report["passed"] = not report["failures"] and len(pooled) == len(modes) and bool(report["selection"])
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("manifest", type=Path)
    parser.add_argument("directory", type=Path)
    parser.add_argument("--screen", type=Path)
    parser.add_argument("--pilot-directory", type=Path, action="append", default=[])
    parser.add_argument("--exclude-pilot-directory", type=Path, action="append", default=[])
    parser.add_argument("--workers", type=int, choices=(20, 30))
    args = parser.parse_args()
    try:
        report = analyze(args.manifest, args.directory, args.screen, args.pilot_directory,
                         args.exclude_pilot_directory, args.workers)
    except (OSError, KeyError, TypeError, ValueError, ArithmeticError) as error:
        report = {"passed": False, "error": str(error), "scope": "incomplete/schema/provenance failure; no run performed and no successful selection"}
    output = args.directory / "physics_pilot_analysis.json"
    output.write_text(json.dumps(report, indent=2, allow_nan=False) + "\n")
    lines = ["# GL638 fixed-N physics comparison", "", report.get("scope", ""), "",
             "| Method | Observable | N | Mean ± pooled SE [pb] | Seed-mean SE [pb] | Largest absolute component weight [pb] |",
             "|---|---|---:|---:|---:|---:|"]
    for method in report.get("pooled", []):
        for key, value in method["observables"].items():
            maximum = method["maxima"][key.removeprefix("abs_")]["largest_absolute_weight"]
            lines.append(f"| {method['mode']} | {key} | {value['samples']} | {value['mean']:.8g} ± {value['standard_error']:.4g} | {value['seed_mean_standard_error']:.4g} | {maximum:.8g} |")
    lines += ["", "Frozen confirmation selection:", "", json.dumps(report.get("selection"), indent=2), "",
              "Failures remain in the JSON; no invalid/ungated method can win. Extrema alone do not establish boundedness or convergence. The primary result is the preselected joint method, not a post-hoc confirmation winner."]
    (args.directory / "physics_pilot_analysis.md").write_text("\n".join(lines) + "\n")
    print(json.dumps({"passed": report["passed"], "selection": report.get("selection"), "failures": report.get("failures"), "error": report.get("error")}))
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    sys.exit(main())

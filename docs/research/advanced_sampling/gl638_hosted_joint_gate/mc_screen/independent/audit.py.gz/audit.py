"""Read retained JSON/TOML only; independent Decimal check of frozen screen statistics."""
import copy, hashlib, json, math, tomllib
from decimal import Decimal as D, getcontext
from pathlib import Path
getcontext().prec = 70
ROOT = Path('/tmp/gl638-hosted-joint-gate')
OUT = Path(__file__).parent
report_path = ROOT/'results-screen-throughput20-build5/physics_pilot_analysis.json'
read = lambda p: json.loads(Path(p).read_text())
hashof = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
report = read(report_path)
manifest_path = ROOT/'manifest-screen-full-build5.json'
manifest = read(manifest_path)
checks = []
def check(name, ok):
    checks.append({'name': name, 'passed': bool(ok)})
    if not ok:
        raise AssertionError(name)
def close(a, b):
    a, b = D(str(a)), D(str(b))
    return abs(a-b) <= D('2e-14') * max(abs(a), abs(b), D('1e-100'))
check('report complete and frozen byte-for-byte', report['passed'] and not report['failures'] and report_path.read_bytes() == (ROOT/'screen-selection-frozen-build5.json').read_bytes())
check('all recorded input hashes unchanged', all(hashof(p) == h for p,h in report['input_sha256'].items()))
check('manifest matches report', hashof(manifest_path) == report['manifest_sha256'])
expected = {(m,s) for m in manifest['proposal_order'] for s in manifest['paired_seeds']}
check('exact 21 unique rows', len(report['runs']) == len(expected) == 21 and {(r['mode'],r['seed']) for r in report['runs']} == expected)
preflight = read(report['common_preflight'])
raw = {}
common = None
for directory in report['pilot_directories']:
    directory = Path(directory)
    summary = read(directory/'summary.json')
    check(f'{directory.name}: accepted same build/state/preflight', summary['workers'] == 20 and summary['status'] == 'completed_requested_stages' and summary['error'] is None and summary['preflight_accepted'] and summary['saved_state_unchanged'] and summary['physics_audit']['passed'] and summary['build_identity'] == report['build_identity'] and summary['state_hashes'] == preflight['state_hashes'] and Path(summary['preflight_reused_from']).resolve() == Path(report['common_preflight']).resolve())
    check(f'{directory.name}: 35 unchanged state hashes', read(directory/'state_before.json') == read(directory/'state_after.json') == preflight['state_hashes'] and len(preflight['state_hashes']) == 35)
for r in report['runs']:
    key = f"{r['mode']}/{r['seed']}"
    slot = read(r['result_path'])['slots'][0]
    raw[r['mode'],r['seed']] = slot
    settings = tomllib.loads(Path(r['settings_path']).read_text())
    card_path = Path(manifest['cards'][r['mode']])
    card = tomllib.loads(card_path.read_text())
    check(key+': raw result matches retained row', slot == r['slot'])
    check(key+': card hash and selection', hashof(card_path) == manifest['card_sha256'][str(card_path)] and settings['sampling']['channel_selection'] == card['sampling']['channel_selection'])
    check(key+': original settings and fixed N', settings['integrator']['seed'] == r['seed'] and settings['integrator']['n_start'] == settings['integrator']['n_max'] == 2048 and settings['integrator']['n_increase'] == 0 and r['retained_driver_record']['cores'] == 20 and r['retained_driver_record']['sample_count'] == 2048)
    stat = slot['integration_statistics']
    check(key+': signed/abs/stat counts and validity', r['eligible'] and slot['integral']['neval'] == slot['absolute']['integral']['neval'] == stat['num_evals'] == 2048 and stat['nan_percentage'] == stat['nan_or_unstable_percentage'] == 0)
    physics = copy.deepcopy(settings)
    physics.pop('sampling'); physics['integrator'].pop('seed')
    if common is None: common = physics
    check(key+': common physical settings', physics == common)
control = report['excluded_controls']
check('sole 30-worker control excluded', len(control) == 1 and control[0]['workers'] == 30 and control[0]['mode_seed_pairs'] == [['optimized_lmb',11113]] and control[0]['directory'] not in report['pilot_directories'])
computed = {}
for method in report['pooled']:
    mode = method['mode']; observables = {}
    for key in ('re','abs_re','im','abs_im'):
        phase = key.removeprefix('abs_')
        integrals = [raw[mode,s]['absolute']['integral'] if key.startswith('abs_') else raw[mode,s]['integral'] for s in manifest['paired_seeds']]
        values = [D(str(x['result'][phase])) for x in integrals]
        errors = [D(str(x['error'][phase])) for x in integrals]
        n,k = D(2048),D(3); total = n*k; mean = sum(values)/k
        between = sum((x-mean)**2 for x in values)
        m2 = sum(n*(n-1)*e*e+n*(x-mean)**2 for x,e in zip(values,errors))
        result = {'mean':mean,'standard_error':(m2/(total*(total-1))).sqrt(), 'sample_variance':m2/(total-1),'sum_squares':m2+total*mean*mean,'seed_mean_standard_error':(between/(k*(k-1))).sqrt()}
        check(f'{mode}/{key}: independent pooling', method['observables'][key]['samples'] == 6144 and all(close(v,method['observables'][key][q]) for q,v in result.items()))
        observables[key] = {q:float(v) for q,v in result.items()}
    maxima = {}
    for phase in ('re','im'):
        largest = max(abs(x['max_eval']) for s in manifest['paired_seeds'] for x in raw[mode,s]['max_weight_info'] if x['component']==phase)
        check(f'{mode}/{phase}: maximum across included rows only', largest == method['maxima'][phase]['largest_absolute_weight'])
        maxima[phase] = largest
    computed[mode] = {'observables':observables,'maxima_pb':maxima}
scales = {p:computed['optimized_lmb']['observables']['abs_'+p]['mean'] for p in ('re','im')}
for method in report['pooled']:
    mode=method['mode']
    score=max(v['sample_variance']/scales[k.removeprefix('abs_')]**2 for k,v in computed[mode]['observables'].items())
    check(mode+': normalized score', close(score,method['score']))
    computed[mode]['score']=score
candidates=[m for m in manifest['proposal_order'] if 'joint' in m]
winner=min(candidates,key=lambda m:(computed[m]['score'],manifest['proposal_order'].index(m)))
selected=['optimized_lmb','cuts_soft' if winner.endswith('_soft') else 'cuts',winner]
check('frozen common scales and unique score minimum', report['selection']['absolute_phase_scales']==scales and report['selection']['confirmation_modes']==selected and winner=='cuts_combined_joint')
confirmation=read(ROOT/'manifest-confirmation-build5.json')
check('confirmation uses exact frozen methods/cards/source/preflight and independent seeds', confirmation['proposal_order']==selected and confirmation['samples_per_run']==32768 and confirmation['paired_seeds']==[10007,20011,30013,40009,50021] and confirmation['cores']==20 and not set(confirmation['paired_seeds']) & set(manifest['paired_seeds']) and all(confirmation[k]==manifest[k] for k in ('cards','card_sha256','candidate_driver_sha256','source_candidate_patch_sha256','preflight_summary','saved_state_hashes')))
summary={'passed':True,'scope':'Artifact-only independent check; no Gamma/state load or pilot-directory writes. Decimal70 recomputation from retained original integration_result.json means/errors; no new estimator.','checks':checks,'included_runs':21,'draws_per_method':6144,'total_draws':43008,'workers':20,'excluded_control':control,'selection':selected,'absolute_phase_scales':scales,'methods':computed,'direct_vs_composed_score_improvement_percent':100*(computed['cuts_joint']['score']-computed[winner]['score'])/computed['cuts_joint']['score'],'input_sha256':{str(report_path):hashof(report_path),str(manifest_path):hashof(manifest_path),str(ROOT/'screen-selection-frozen-build5.json'):hashof(ROOT/'screen-selection-frozen-build5.json'),str(ROOT/'manifest-confirmation-build5.json'):hashof(ROOT/'manifest-confirmation-build5.json')},'statistical_scope':'Screen selection only; 0.04% score separation of joint variants does not establish a real improvement. All four observables and large retained maxima remain visible; independent confirmation is required.'}
(OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
lines=['All 21 runs passed: 3 × 2048 samples per method, 20 workers; the 30-worker control is excluded.','', 'Means and empirical errors below are in 10⁻⁴ pb; maxima are absolute signed-component maxima in pb.', '', '| Method | Re ± SE | Abs Re ± SE | Im ± SE | Abs Im ± SE | Max Re / Im (pb) | Score |','|---|---:|---:|---:|---:|---:|---:|']
for mode in manifest['proposal_order']:
    v=computed[mode]; cells=[f"{v['observables'][k]['mean']*1e4:.5g} ± {v['observables'][k]['standard_error']*1e4:.4g}" for k in ('re','abs_re','im','abs_im')]
    lines.append('| '+mode+' | '+' | '.join(cells)+f" | {v['maxima_pb']['re']:.6g} / {v['maxima_pb']['im']:.6g} | {v['score']:.7g} |")
lines += ['', 'Selected a = optimized_lmb, b = cuts, c = cuts_combined_joint. The composed score is only 0.03947% below direct joint; this screen does not establish superiority between them.','',f'{len(checks)} independent checks passed. All 93 recorded input hashes still match; all 35 saved-state hashes are unchanged in each batch. Confirmation retains the frozen methods/cards/source/scales and uses independent seeds.']
(OUT/'summary.md').write_text('\n'.join(lines)+'\n')
print('\n'.join(lines))
print('JSON',OUT/'summary.json',hashof(OUT/'summary.json'))

# GL638 fixed-N physics comparison

Existing full-GL638 Integrate results; separate signed Re/Im and |Re|/|Im|. Empirical finite-N errors/extremes, no finite-variance or global boundedness certificate. Printed maxima are not complete replay Samples.

| Method | Observable | N | Mean ± pooled SE [pb] | Seed-mean SE [pb] | Largest absolute component weight [pb] |
|---|---|---:|---:|---:|---:|
| optimized_lmb | re | 6144 | 0.00014317105 ± 0.0001927 | 0.000261 | 1.0489219 |
| optimized_lmb | abs_re | 6144 | 0.0006183386 ± 0.0001925 | 0.0001643 | 1.0489219 |
| optimized_lmb | im | 6144 | 0.0001050413 ± 0.0002465 | 0.0003269 | 1.3467476 |
| optimized_lmb | abs_im | 6144 | 0.00089363156 ± 0.0002463 | 0.0001042 | 1.3467476 |
| cuts | re | 6144 | 0.0001899373 ± 0.0001471 | 0.0001233 | 0.87567939 |
| cuts | abs_re | 6144 | 0.00021213805 ± 0.0001471 | 0.0001211 | 0.87567939 |
| cuts | im | 6144 | 0.00019149756 ± 0.0001699 | 0.0001749 | 1.0341965 |
| cuts | abs_im | 6144 | 0.00023826819 ± 0.0001699 | 0.0001686 | 1.0341965 |
| cuts_joint | re | 6144 | 1.978086e-05 ± 5.581e-05 | 2.092e-05 | 0.22443889 |
| cuts_joint | abs_re | 6144 | 0.00011608804 ± 5.579e-05 | 6.545e-05 | 0.22443889 |
| cuts_joint | im | 6144 | 3.5658968e-05 ± 2.857e-05 | 4.066e-05 | 0.11212339 |
| cuts_joint | abs_im | 6144 | 8.7430336e-05 ± 2.855e-05 | 3.605e-05 | 0.11212339 |
| cuts_soft | re | 6144 | -0.00045452904 ± 0.0006468 | 0.0008065 | 3.7675574 |
| cuts_soft | abs_re | 6144 | 0.0010479028 ± 0.0006467 | 0.000571 | 3.7675574 |
| cuts_soft | im | 6144 | 0.0020417285 ± 0.001947 | 0.002002 | 11.93688 |
| cuts_soft | abs_im | 6144 | 0.002343667 ± 0.001947 | 0.002083 | 11.93688 |
| cuts_joint_soft | re | 6144 | -0.00054561154 ± 0.0007389 | 0.0009424 | 4.3057798 |
| cuts_joint_soft | abs_re | 6144 | 0.001169959 ± 0.0007388 | 0.0006334 | 4.3057798 |
| cuts_joint_soft | im | 6144 | 0.0023352723 ± 0.002225 | 0.0023 | 13.642149 |
| cuts_joint_soft | abs_im | 6144 | 0.0026571207 ± 0.002225 | 0.002378 | 13.642149 |
| cuts_combined_joint | re | 6144 | 1.8391631e-05 ± 5.58e-05 | 2.003e-05 | 0.22443889 |
| cuts_combined_joint | abs_re | 6144 | 0.00011552278 ± 5.578e-05 | 6.562e-05 | 0.22443889 |
| cuts_combined_joint | im | 6144 | 3.5644777e-05 ± 2.853e-05 | 4.1e-05 | 0.11212339 |
| cuts_combined_joint | abs_im | 6144 | 8.8481607e-05 ± 2.851e-05 | 3.514e-05 | 0.11212339 |
| cuts_combined_joint_soft | re | 6144 | -0.00054703609 ± 0.0007389 | 0.0009428 | 4.3057798 |
| cuts_combined_joint_soft | abs_re | 6144 | 0.0011710578 ± 0.0007388 | 0.000634 | 4.3057798 |
| cuts_combined_joint_soft | im | 6144 | 0.0023360014 ± 0.002225 | 0.002299 | 13.642149 |
| cuts_combined_joint_soft | abs_im | 6144 | 0.0026582246 ± 0.002225 | 0.002379 | 13.642149 |

Frozen confirmation selection:

{
  "confirmation_modes": [
    "optimized_lmb",
    "cuts",
    "cuts_combined_joint"
  ],
  "primary_estimate_mode": "cuts_combined_joint",
  "absolute_phase_scales": {
    "re": 0.0006183385979328378,
    "im": 0.0008936315639088504
  },
  "score_rule": "minimum worst normalized4-observable sample variance; exact ties use declared order; b has identical soft policy",
  "card_sha256": {
    "optimized_lmb": "c4d99ba8507ab73a5c754e1480c0e37978bd5489b31692f66e0ea030aff5b3e6",
    "cuts": "71ce4efcf492a51393075382816f8ded9ee79f93dbb1023f590b7b391f29f751",
    "cuts_combined_joint": "e7c61f30d4e117c53bdd0bcb15ca116ab7bdd3b6005c299c7b828ea0de4f1c9b"
  },
  "candidate_driver_sha256": "2fd035e87812264837a6cb0feb752a6abb63f827a90d1b461285442fd0dd311d"
}

Failures remain in the JSON; no invalid/ungated method can win. Extrema alone do not establish boundedness or convergence. The primary result is the preselected joint method, not a post-hoc confirmation winner.

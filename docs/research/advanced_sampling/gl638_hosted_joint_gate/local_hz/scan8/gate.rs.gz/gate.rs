// Off-source GL638 gate client, migrated from the archived X2 replay owners.
// No sampler, retry loop or integration engine lives here: Grid::sample and
// ProcessIntegrand's precise source/physical APIs own every numerical operation.
// Compile only against root's frozen optimized libraries. Never save the state.
use color_eyre::{
    Result,
    eyre::{WrapErr, ensure, eyre},
};
use figment::{Figment, providers::Serialized};
use gammaloop_api::{
    CLISettings, StateLoadOption,
    commands::{
        integrate::{Integrate, RendererOption, ShowPhaseOption},
        set::SetArgs,
    },
    state::ProcessRef,
};
use gammalooprs::{
    graph::GroupId,
    initialisation::initialise,
    integrands::{
        HasIntegrand,
        evaluation::{GenericEvaluationResult, PreciseEvaluationResult, StabilityStatus},
        process::{
            GaussianReferenceFunction, GraphTerm, MomentumSpaceEvaluationInput, ProcessIntegrand,
            ReferenceSampleEvaluation, ReferenceSamplingReport, SamplingChannelBridgeEvaluation,
            SamplingChannelId, SamplingMapEvaluation,
        },
    },
    model::Model,
    momentum::ThreeMomentum,
    utils::{ArbPrec, F, FloatLike},
};
use serde_json::{Value, json};
use spenso::algebra::complex::Complex;
use std::{collections::BTreeMap, env, fs, path::Path, process::Command, time::Instant};
use symbolica::numerical_integration::{MonteCarloRng, Probe, Sample};
use symbolica::prelude::Real;

// File checks run only outside numerical timings. The saved generated payload,
// metadata, settings and model must match the reviewed complete 35-file snapshot.
fn state_hashes(root: &Path) -> Result<BTreeMap<String, String>> {
    let mut directories = vec![root.to_path_buf()];
    let mut paths = Vec::new();
    while let Some(directory) = directories.pop() {
        for entry in fs::read_dir(directory)? {
            let path = entry?.path();
            if path.is_dir() {
                directories.push(path);
            } else if path.is_file() {
                paths.push(path);
            }
        }
    }
    paths.sort();
    let mut hashes = BTreeMap::new();
    for path in paths {
        let output = Command::new("sha256sum").arg(&path).output()?;
        ensure!(
            output.status.success(),
            "sha256sum failed for {}",
            path.display()
        );
        let text = String::from_utf8(output.stdout)?;
        let hash = text
            .split_whitespace()
            .next()
            .ok_or_else(|| eyre!("empty sha256sum output"))?;
        hashes.insert(
            path.strip_prefix(root)?.to_string_lossy().into_owned(),
            hash.to_owned(),
        );
    }
    Ok(hashes)
}

fn inventory(integrand: &ProcessIntegrand, manifest: &Value, mode: &str) -> Result<Value> {
    let ProcessIntegrand::CrossSection(process) = integrand else {
        return Err(eyre!("cross section required"));
    };
    ensure!(
        process.data.graph_terms.len() == 1 && process.data.graph_group_structure.len() == 1,
        "exactly one graph and graph group required"
    );
    let term = &process.data.graph_terms[0];
    ensure!(
        term.graph.name == manifest["graph_name"].as_str().unwrap(),
        "wrong graph name"
    );
    let keys = term.selected_production_orientation_keys();
    ensure!(
        keys.len() == 936 && term.production_orientation_keys().len() == 936,
        "full936 generated/selected orientations required, got {}/{}",
        term.production_orientation_keys().len(),
        keys.len()
    );
    ensure!(
        term.cuts.len() == 6 && term.cut_esurface.len() == 6,
        "all six physical cuts required"
    );
    let generation_parent = term
        .graph
        .loop_momentum_basis
        .loop_edges
        .iter()
        .map(|e| e.0)
        .collect::<Vec<_>>();
    ensure!(
        json!(generation_parent) == manifest["generation_parent_lmb"],
        "generation parent mismatch"
    );
    let cuts = term
        .cut_esurface
        .iter()
        .enumerate()
        .map(|(id, surface)| {
            let mut edges = surface.energies.iter().map(|e| e.0).collect::<Vec<_>>();
            edges.sort();
            json!({"id":id,"edges":edges,"original_equation":format!("{surface:?}")})
        })
        .collect::<Vec<_>>();
    ensure!(
        cuts[manifest["host_cut"]["id"].as_u64().unwrap() as usize]["edges"]
            == manifest["host_cut"]["edges"],
        "host edge identity mismatch"
    );
    let parameterization = integrand
        .get_settings()
        .sampling
        .get_parameterization_settings()
        .ok_or_else(|| eyre!("parameterization missing"))?;
    let ids = integrand.group_sampling_channel_ids(GroupId(0), &parameterization)?;
    ensure!(
        ids.len() == manifest["expected_channels"][mode].as_u64().unwrap() as usize,
        "unexpected canonical channel count in {mode}: {ids:?}"
    );
    let channels = ids
        .iter()
        .map(|id| {
            Ok(json!({"id":id.0,"label":term.sampling_channel_label(*id,&parameterization)?,
                "is_lmb":term.sampling_setup().sampling_channel_is_lmb(*id,&term.graph.name,&parameterization)?}))
        })
        .collect::<Result<Vec<_>>>()?;
    ensure!(
        integrand.group_orientation_count(GroupId(0)) == Some(1),
        "expected one exposed summed-orientation selector"
    );
    ensure!(
        term.threshold_counterterm_metadata().is_some(),
        "threshold metadata registry missing"
    );
    Ok(
        json!({"graph":term.graph.name,"generation_parent_lmb":generation_parent,
        "production_orientation_keys":keys,"exposed_orientation_selectors":1,"cuts":cuts,"channels":channels,
        "threshold_counterterm_metadata":term.threshold_counterterm_metadata(),
        "uv_preservation_evidence":"complete generated-state hashes identical; no regeneration, filter or physical-setting override"}),
    )
}

// Preserve native decimal totals/events. Formatting and JSON allocation are
// deliberately after the timed precise call; no map factors are applied again.
fn native_record<T: FloatLike>(r: GenericEvaluationResult<T>, precision: &str) -> Value {
    let final_unstable = r
        .evaluation_metadata
        .stability_results
        .last()
        .is_some_and(|r| matches!(r.status, StabilityStatus::Unstable(_)));
    let finite = !final_unstable
        && !r.evaluation_metadata.is_nan
        && r.integrand_result.re.0.is_finite()
        && r.integrand_result.im.0.is_finite();
    let mut events = Vec::new();
    let mut finite_events = true;
    for (group_id, group) in r.event_groups.iter().enumerate() {
        for event in group.iter() {
            finite_events &= event.weight.re.0.is_finite() && event.weight.im.0.is_finite();
            events.push(json!({"group":group_id,"cut_info":event.cut_info,
                "weight":{"re":event.weight.re.to_string(),"im":event.weight.im.to_string()},
                "threshold_counterterms":event.additional_weights.threshold_counterterms.as_ref().map(|ct| json!({
                    "original":{"re":ct.original.re.to_string(),"im":ct.original.im.to_string()},
                    "components":ct.components.iter().map(|component| json!({"component_id":component.component_id,
                        "occurrence":component.occurrence,"multiplier_values":component.multiplier_values.iter().map(ToString::to_string).collect::<Vec<_>>(),
                        "effective_multiplier":component.effective_multiplier.to_string(),"evaluation_skipped":component.evaluation_skipped,
                        "bare":component.bare.as_ref().map(|value|json!({"re":value.re.to_string(),"im":value.im.to_string()})),
                        "weighted":{"re":component.weighted.re.to_string(),"im":component.weighted.im.to_string()}})).collect::<Vec<_>>()})),
                "additional_weights":event.additional_weights.weights.iter().map(|(key,value)|json!({"key":format!("{key:?}"),"re":value.re.to_string(),"im":value.im.to_string()})).collect::<Vec<_>>()}));
        }
    }
    let outer = r
        .parameterization_jacobian
        .clone()
        .unwrap_or_else(|| F(r.integrator_weight.0.one()))
        * &r.integrator_weight;
    let weighted_re = &r.integrand_result.re * &outer;
    let weighted_im = &r.integrand_result.im * &outer;
    json!({"valid":finite && finite_events && weighted_re.0.is_finite() && weighted_im.0.is_finite(),"precision":precision,
        "integrand_result":{"re":r.integrand_result.re.to_string(),"im":r.integrand_result.im.to_string()},
        "complete_sample_estimator":{"re":weighted_re.to_string(),"im":weighted_im.to_string(),
            "scope":"returned integrand_result times remaining reported J and integrator_weight once; map J/partition already folded are not repeated"},
        "parameterization_jacobian":r.parameterization_jacobian.map(|v|v.to_string()),
        "integrator_weight":r.integrator_weight.to_string(),"events":events,
        "sampling_seconds":r.evaluation_metadata.parameterization_time.as_secs_f64(),
        "physical_seconds":r.evaluation_metadata.integrand_evaluation_time.as_secs_f64(),
        "evaluation_metadata":r.evaluation_metadata})
}
fn record(result: Result<PreciseEvaluationResult>, wall: f64) -> Value {
    let evaluation = match result {
        Ok(PreciseEvaluationResult::Double(r)) => native_record(r, "Double"),
        Ok(PreciseEvaluationResult::Quad(r)) => native_record(r, "Quad"),
        Ok(PreciseEvaluationResult::Arb(r)) => native_record(r, "Arb"),
        Err(error) => {
            json!({"valid":false,"error":format!("{error:#}"),"sampling_seconds":null,"physical_seconds":null})
        }
    };
    let p = evaluation["physical_seconds"].as_f64();
    json!({"wall_seconds":wall,"sampling_upper_seconds":p.map(|p|(wall-p).max(0.0)),"evaluation":evaluation})
}

fn replay(
    integrand: &mut ProcessIntegrand,
    model: &Model,
    requests: &[Value],
    info: &Value,
    partition_diagnostic: bool,
) -> Result<Vec<Value>> {
    let mut rows = Vec::new();
    for case in requests {
        ensure!(
            case["threshold_ct_enabled"] == true && case["momentum_space"] == true,
            "only original CT-on momentum-space cases supported"
        );
        let point = case["point_tokens"]
            .as_array()
            .unwrap()
            .iter()
            .map(|s| s.as_str().unwrap().parse::<f64>())
            .collect::<std::result::Result<Vec<_>, _>>()?;
        ensure!(
            point.len() == 12 && point.iter().all(|v| v.is_finite()),
            "four finite original loop momenta required"
        );
        let channel_id = if let Some(name) = case["channel_name"].as_str() {
            let matches = info["channels"]
                .as_array()
                .unwrap()
                .iter()
                .filter(|entry| entry["label"] == name)
                .collect::<Vec<_>>();
            ensure!(
                matches.len() == 1,
                "expected unique named canonical channel {name}"
            );
            Some(SamplingChannelId(
                matches[0]["id"].as_u64().unwrap() as usize
            ))
        } else {
            None
        };
        let input = MomentumSpaceEvaluationInput {
            loop_momenta: point
                .chunks_exact(3)
                .map(|v| ThreeMomentum::from([F(v[0]), F(v[1]), F(v[2])]))
                .collect(),
            integrator_weight: F(1.0),
            graph_id: channel_id.is_none().then_some(0),
            group_id: channel_id.map(|_| GroupId(0)),
            orientation: None,
            channel_id,
        };
        let at = Instant::now();
        let result = integrand.evaluate_momentum_configuration_precise(
            model,
            &input,
            case["forced_arb"].as_bool().unwrap(),
        );
        let wall = at.elapsed().as_secs_f64();
        let mut row = record(result, wall);
        row["case"] = case.clone();
        if partition_diagnostic {
            if let Some(channel_id) = channel_id {
                // Independent raw partition oracle at the original binary64
                // point, in canonical Arb1000. This diagnostic is excluded from
                // W/S/P and never runs in hard timing or worker warmup.
                let canonical = point
                    .iter()
                    .map(|v| ArbPrec::from_f64_exact_binary(*v))
                    .collect::<Vec<_>>();
                let ProcessIntegrand::CrossSection(process) = &*integrand else {
                    return Err(eyre!("cross section required"));
                };
                let inverse = process.data.graph_terms[0]
                    .sampling_setup()
                    .sampling_bridge::<ArbPrec>()
                    .and_then(|bridge| bridge.inverse(channel_id, &canonical));
                row["canonical_raw_partition"] = match inverse {
                    Ok(Some(mapped)) => match mapped.partition.weight(channel_id.0) {
                        Some(weight) => {
                            json!({"status":"inside_support","weight":F(weight).to_string(),"precision":"Arb1000", "source":"exact binary64 promotion; independent canonical inverse; raw input uses w only, never inverse Jacobian"})
                        }
                        None => {
                            json!({"status":"error","error":"selected partition weight missing"})
                        }
                    },
                    Ok(None) => {
                        json!({"status":"outside_support","weight":null,"scope":"the selected chart does not cover this raw point; not a physical-law failure and no replacement chart is selected"})
                    }
                    Err(error) => json!({"status":"error","error":format!("{error:#}")}),
                };
                row["canonical_raw_partition"]["channel_id"] = json!(channel_id.0);
            }
        }
        row["point_definition"] =
            json!("original binary64 tokens, exactly promoted by existing source owner");
        row["factor_scope"] = json!(if channel_id.is_some() {
            "partition-weighted F; do not compare directly with bare F"
        } else {
            "bare F; no sampling partition/Jacobian"
        });
        let mut cuts = row["evaluation"]["events"]
            .as_array()
            .into_iter()
            .flatten()
            .filter_map(|event| event["cut_info"]["cut_id"].as_u64())
            .collect::<Vec<_>>();
        cuts.sort();
        row["six_distinct_cut_events"] = json!(cuts == vec![0, 1, 2, 3, 4, 5]);
        rows.push(row);
    }
    Ok(rows)
}

// Only orchestration is parallel: every worker calls the existing detailed
// reference owner, which sums all channels before returning one draw. Joining
// contiguous chunks in index order preserves the existing report accumulation.
fn reference_parallel(
    workers: &mut [ProcessIntegrand],
    coordinates: &[Vec<f64>],
    reference: &GaussianReferenceFunction,
    first_index: usize,
) -> Result<Vec<ReferenceSampleEvaluation>> {
    ensure!(
        !workers.is_empty() && !coordinates.is_empty(),
        "empty reference batch"
    );
    let chunk_size = coordinates.len().div_ceil(workers.len());
    std::thread::scope(|scope| {
        let mut handles = Vec::new();
        for (chunk_index, (points, worker)) in
            coordinates.chunks(chunk_size).zip(workers).enumerate()
        {
            let start = first_index + chunk_index * chunk_size;
            handles.push(
                std::thread::Builder::new()
                    .stack_size(128 * 1024 * 1024)
                    .spawn_scoped(scope, move || -> Result<Vec<_>> {
                        points
                            .iter()
                            .enumerate()
                            .map(|(offset, point)| {
                                let sample = Sample::Discrete(
                                    F(1.0),
                                    0,
                                    Some(Box::new(Sample::Continuous(
                                        F(1.0),
                                        point.iter().copied().map(F).collect(),
                                    ))),
                                );
                                let value = worker
                                    .evaluate_reference_sample_detailed(&sample, reference)
                                    .wrap_err_with(|| {
                                        format!("reference Halton index {}", start + offset + 1)
                                    })?;
                                ensure!(
                                    !value.evaluation.evaluation_metadata.is_nan
                                        && value
                                            .evaluation
                                            .evaluation_metadata
                                            .stability_results
                                            .last()
                                            .is_some_and(|level| !matches!(
                                                level.status,
                                                StabilityStatus::Unstable(_)
                                            )),
                                    "invalid final reference precision at Halton index {}",
                                    start + offset + 1
                                );
                                Ok(value)
                            })
                            .collect()
                    })?,
            );
        }
        let mut values = Vec::with_capacity(coordinates.len());
        for handle in handles {
            values.extend(
                handle
                    .join()
                    .map_err(|_| eyre!("reference chunk worker panicked"))??,
            );
        }
        Ok(values)
    })
}

fn reference_report(report: &ReferenceSamplingReport) -> Value {
    json!({"points":report.sample_count,"finite_points":report.finite_sample_count,
        "normalization":report.normalization,"normalization_squared":report.normalization_squared,
        "normalization_dispersion":report.normalization_stderr,"raw_second_moment":report.second_moment,
        "expected_raw_second_moment":report.expected_second_moment,"second_moment_dispersion":report.second_moment_stderr,
        "jacobian_min":report.jacobian_min,"jacobian_max":report.jacobian_max,"jacobian_abs_max":report.jacobian_abs_max})
}

// Deterministic acceptance reuses the same production map and per-draw sum
// owner as the archived X2 client. Eight finite points are smoke, not an
// acceptance claim; only a finite 8192/32768 report can pass the fixed bounds.
fn reference_stage(
    integrand: &mut ProcessIntegrand,
    model: &Model,
    manifest: &Value,
    full: bool,
    workers: usize,
) -> Result<Value> {
    let settings = integrand.get_settings().clone();
    *integrand.get_mut_settings() = SetArgs::String {
        string: "sampling.sampling_channels = \"summed\"".into(),
    }
    .merge_figment(Figment::from(Serialized::defaults(&settings)))?
    .extract()?;
    let reference = GaussianReferenceFunction::new(
        manifest["reference"]["width_GeV"].as_f64().unwrap(),
        manifest["reference"]["center_GeV"]
            .as_array()
            .unwrap()
            .iter()
            .map(|x| x.as_f64().unwrap())
            .collect(),
    )?;
    let counts = if full { vec![8, 8192, 32768] } else { vec![8] };
    let coordinates = (1..=*counts.last().unwrap())
        .map(|index| {
            [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37]
                .map(|base| {
                    let (mut index, mut fraction, mut value) = (index, 1.0, 0.0);
                    while index > 0 {
                        fraction /= base as f64;
                        value += (index % base) as f64 * fraction;
                        index /= base;
                    }
                    value
                })
                .to_vec()
        })
        .collect::<Vec<_>>();
    let result = (|| -> Result<Value> {
        let at = Instant::now();
        let mut prepared = std::thread::scope(|scope| -> Result<Vec<_>> {
            let mut handles = Vec::new();
            // Two workers are needed even for a one-worker request to check the
            // first eight points independently before any large acceptance run.
            for worker_id in 0..workers.max(2) {
                let mut worker = integrand.clone();
                handles.push(
                    std::thread::Builder::new()
                        .stack_size(128 * 1024 * 1024)
                        .spawn_scoped(scope, move || -> Result<_> {
                            worker
                                .warm_up(model)
                                .wrap_err_with(|| format!("reference warmup worker {worker_id}"))?;
                            Ok(worker)
                        })?,
                );
            }
            handles
                .into_iter()
                .map(|handle| {
                    handle
                        .join()
                        .map_err(|_| eyre!("reference warmup worker panicked"))?
                })
                .collect()
        })?;
        let warmup_seconds = at.elapsed().as_secs_f64();
        let mut retained =
            reference_parallel(&mut prepared[..1], &coordinates[..8], &reference, 0)?;
        let paired = reference_parallel(&mut prepared[..2], &coordinates[..8], &reference, 0)?;
        for (index, (a, b)) in retained.iter().zip(&paired).enumerate() {
            ensure!(
                a.evaluation.integrand_result == b.evaluation.integrand_result
                    && a.evaluation.parameterization_jacobian
                        == b.evaluation.parameterization_jacobian
                    && a.evaluation.integrator_weight == b.evaluation.integrator_weight
                    && a.moments.second_moment == b.moments.second_moment
                    && a.moments.jacobian_min == b.moments.jacobian_min
                    && a.moments.jacobian_max == b.moments.jacobian_max,
                "one/two-worker reference discrepancy at Halton index {}",
                index + 1
            );
        }
        let serial =
            ReferenceSamplingReport::from_evaluations(retained.iter().cloned(), &reference);
        let parallel = ReferenceSamplingReport::from_evaluations(paired, &reference);
        ensure!(
            serial.finite_sample_count == 8
                && parallel.finite_sample_count == 8
                && reference_report(&serial) == reference_report(&parallel),
            "one/two-worker eight-point reference statistics discrepancy or invalid result"
        );
        let consistency = json!({"passed":true,"points":8,"workers":[1,2],
            "comparison":"exact detailed value/moment/factors and all report fields in index order",
            "report":reference_report(&serial)});
        let mut rows = Vec::new();
        let mut passed = false;
        for count in counts {
            let at = Instant::now();
            if count > retained.len() {
                let start = retained.len();
                match reference_parallel(
                    &mut prepared[..workers],
                    &coordinates[start..count],
                    &reference,
                    start,
                ) {
                    Ok(values) => retained.extend(values),
                    Err(error) => {
                        rows.push(json!({"points":count,"completed_prefix":start,"finite":false,
                            "error":format!("{error:#}"),"elapsed_seconds":at.elapsed().as_secs_f64()}));
                        return Ok(
                            json!({"full_acceptance_requested":full,"passed":false,"finite":false,
                            "warmup_seconds":warmup_seconds,"workers":workers,"parallel_consistency":consistency,"rows":rows}),
                        );
                    }
                }
            }
            let r = ReferenceSamplingReport::from_evaluations(retained.iter().cloned(), &reference);
            let finite = r.finite_sample_count == count
                && r.sample_count == count
                && [
                    r.normalization,
                    r.normalization_squared,
                    r.normalization_stderr,
                    r.second_moment,
                    r.second_moment_stderr,
                    r.jacobian_min,
                    r.jacobian_max,
                    r.jacobian_abs_max,
                ]
                .iter()
                .all(|value| value.is_finite());
            let within = (r.normalization - 1.0).abs() < 0.06
                && (r.second_moment / r.expected_second_moment - 1.0).abs() < 0.08;
            passed = finite && count >= 8192 && within;
            let mut row = reference_report(&r);
            row["finite"] = json!(finite);
            row["elapsed_seconds"] = json!(at.elapsed().as_secs_f64());
            row["acceptance_passed"] = json!(passed);
            row["smoke_only"] = json!(count == 8);
            rows.push(row);
            if !finite || passed {
                break;
            }
        }
        let finite = rows.iter().all(|r| r["finite"] == true);
        Ok(
            json!({"full_acceptance_requested":full,"passed":passed,"finite":finite,
            "warmup_seconds":warmup_seconds,"workers":workers,"parallel_consistency":consistency,"rows":rows,
            "coordinate_sequence":"original indexed twelve-dimensional Halton prefixes; channels summed within each draw",
            "dispersion_scope":"IID-formula diagnostic on deterministic Halton points, not a QMC confidence interval"}),
        )
    })();
    *integrand.get_mut_settings() = settings;
    result
}

fn map_record(map: &SamplingMapEvaluation<ArbPrec>) -> Value {
    json!({
        "point":map.point.iter().map(|v|F(v.clone()).to_string()).collect::<Vec<_>>(),
        "coordinates":map.coordinates.iter().map(|v|F(v.clone()).to_string()).collect::<Vec<_>>(),
        "jacobian":F(map.jacobian.clone()).to_string(),
        "inverse_jacobian":F(map.inverse_jacobian.clone()).to_string(),
        "residual":F(map.residual.clone()).to_string(),"support":format!("{:?}",map.support),
        "diagnostics":map.diagnostics})
}

// These are the original residuals computed by the existing native joint
// inverse, recovered from its normal coordinates. This is not an independent
// Esurface oracle, a second LU solve, or the intended pre-rounding cube radius.
fn approach_normals(oracle: &ProcessIntegrand, point: &[ArbPrec]) -> Result<Value> {
    let ProcessIntegrand::CrossSection(process) = oracle else {
        return Err(eyre!("cross section required"));
    };
    let bridge = process.data.graph_terms[0]
        .sampling_setup()
        .sampling_bridge::<ArbPrec>()?;
    let id = bridge
        .channels()
        .iter()
        .position(|channel| channel.name == "direct_joint_HZ")
        .map(SamplingChannelId)
        .ok_or_else(|| eyre!("joint normal oracle missing"))?;
    let Some(inverse) = bridge.inverse(id, point)? else {
        return Ok(
            json!({"status":"outside_joint_support","scope":"no replacement chart or radius"}),
        );
    };
    let Some(radius) = inverse.map.diagnostics.iter().find_map(|message| {
        message
            .split_once("joint: certified normal disk rho=")
            .map(|(_, value)| value.split(';').next().unwrap().trim())
    }) else {
        return Ok(
            json!({"status":"ordinary_fallback","diagnostics":inverse.map.diagnostics,
            "scope":"no compact-corner normal inference"}),
        );
    };
    let rho = F(radius.parse::<ArbPrec>()?);
    ensure!(
        inverse.map.coordinates.len() == 12,
        "joint oracle must retain9D complement then3D block"
    );
    let r = &rho * F(inverse.map.coordinates[9].clone());
    let theta = rho.TAU() * F(inverse.map.coordinates[10].clone());
    let h = &r * theta.cos();
    let z = &r * theta.sin();
    Ok(
        json!({"status":"compact","precision":"Arb1000","H_global":h.to_string(),"Z_global":z.to_string(),
        "R_map":r.to_string(),"normal_scale":"1","certified_rho":rho.to_string(),
        "round_trip_residual":F(inverse.map.residual).to_string(),"diagnostics":inverse.map.diagnostics,
        "scope":"actual native joint inverse normal coordinates; originalglobalH/Z and alpha1, not an independentEsurface or WH-normal oracle"}),
    )
}

fn approach_map(mapped: &SamplingChannelBridgeEvaluation<ArbPrec>) -> Result<Value> {
    Ok(
        json!({"channel_id":mapped.channel_id.0,"channel_name":mapped.channel_name,"map":map_record(&mapped.map),
        "raw_coordinates":mapped.raw_coordinates.iter().map(|v|F(v.clone()).to_string()).collect::<Vec<_>>(),
        "partition_weights":mapped.partition.weights.iter().map(|v|F(v.clone()).to_string()).collect::<Vec<_>>(),
        "raw_map_density_sum":F(mapped.partition.log_denominator.clone()).exp().to_string(),
        "selected_J_times_w":F(mapped.selected_factor()?).to_string(),
        "density_scope":"unweighted raw map-density sum; discrete/grid Sample factors retained separately, not a general trained proposal density"}),
    )
}

fn local_approach(
    integrand: &mut ProcessIntegrand,
    oracle: &ProcessIntegrand,
    model: &Model,
    manifest: &Value,
    mode: &str,
    info: &Value,
    packet: &Path,
    output: &Path,
) -> Result<Value> {
    let source: Value = serde_json::from_str(&fs::read_to_string(
        packet.join("provenance/all_hz_inputs.json"),
    )?)?;
    let cases = source["cases"]
        .as_array()
        .ok_or_else(|| eyre!("missing archived HZ rays"))?;
    ensure!(
        cases.len() == 8,
        "the complete two-direction/four-radius ray set is required"
    );
    let channels = info["channels"].as_array().unwrap();
    let primary = manifest["primary_channels"][mode]
        .as_str()
        .or_else(|| {
            channels
                .iter()
                .find(|channel| channel["is_lmb"] == false)
                .or_else(|| channels.first())
                .and_then(|channel| channel["label"].as_str())
        })
        .ok_or_else(|| eyre!("missing local-approach channel"))?;
    let id = channels
        .iter()
        .find(|channel| channel["label"] == primary)
        .and_then(|channel| channel["id"].as_u64())
        .map(|id| SamplingChannelId(id as usize))
        .ok_or_else(|| eyre!("local channel {primary} absent from {mode}"))?;
    let grid = integrand.create_grid();
    let mut rows = Vec::new();
    for (index, case) in cases.iter().enumerate() {
        let name = case["name"].as_str().ok_or_else(|| eyre!("unnamed ray"))?;
        let mut row = json!({"name":name,"mode":mode,"channel_id":id.0,"channel_name":primary,
            "archived_direction":if index<4 {"Hplus_Zminus"}else{"Hplus_Zplus"},
            "archived_radius_GeV":([0.2,0.02,0.002,0.0002][index%4]),
            "archived_radius_scope":"historical cut-prepared WH-scaled radius, not currentactualR_map",
            "original_binary64_tokens":case["point_tokens"],"raw_physics":[],"source_physics":[]});
        let result = (|| -> Result<()> {
            let point = case["point_tokens"]
                .as_array()
                .unwrap()
                .iter()
                .map(|x| x.as_str().unwrap().parse::<f64>())
                .collect::<std::result::Result<Vec<_>, _>>()?;
            ensure!(
                point.len() == 12 && point.iter().all(|x| x.is_finite()),
                "invalid archived raw point"
            );
            let native = point
                .iter()
                .map(|x| ArbPrec::from_f64_exact_binary(*x))
                .collect::<Vec<_>>();
            let input = MomentumSpaceEvaluationInput {
                loop_momenta: point
                    .chunks_exact(3)
                    .map(|p| ThreeMomentum::from([F(p[0]), F(p[1]), F(p[2])]))
                    .collect(),
                integrator_weight: F(1.0),
                graph_id: Some(0),
                group_id: None,
                orientation: None,
                channel_id: None,
            };
            for forced_arb in [false, true] {
                let at = Instant::now();
                let evaluated =
                    integrand.evaluate_momentum_configuration_precise(model, &input, forced_arb);
                row["raw_physics"].as_array_mut().unwrap().push(json!({"forced_arb":forced_arb,"result":record(evaluated,at.elapsed().as_secs_f64())}));
            }
            row["raw_normals"] = approach_normals(oracle, &native).unwrap_or_else(|error|
                json!({"status":"error","error":format!("{error:#}"),"scope":"diagnostic inverse; independent bare physics retained"}));
            let ProcessIntegrand::CrossSection(process) = &*integrand else {
                return Err(eyre!("cross section required"));
            };
            let bridge = process.data.graph_terms[0]
                .sampling_setup()
                .sampling_bridge::<ArbPrec>()?;
            let Some(inverse) = bridge.inverse(id, &native)? else {
                row["selected_support"] = json!("outside");
                return Err(eyre!(
                    "selected chart does not cover {name}; no fallback selected"
                ));
            };
            row["raw_inverse"] = approach_map(&inverse)?;
            let cube = inverse.map.coordinates.iter().enumerate().map(|(index,value)| {
                let narrowed = <f64 as FloatLike>::from_arb(value);
                ensure!(narrowed.is_finite() && (0.0..1.0).contains(&narrowed)
                    && (narrowed != 0.0 || value == &ArbPrec::default()),
                    "inverse cube coordinate {index} cannot cross the public binary64 source boundary");
                Ok(F(narrowed))
            }).collect::<Result<Vec<_>>>()?;
            let actual_cube = cube
                .iter()
                .map(|x| ArbPrec::from_f64_exact_binary(x.0))
                .collect::<Vec<_>>();
            let forward = bridge.forward(id, &actual_cube)?;
            row["actual_forward"] = approach_map(&forward)?;
            row["actual_forward_normals"] = approach_normals(oracle, &forward.raw_coordinates).unwrap_or_else(|error|
                json!({"status":"error","error":format!("{error:#}"),"scope":"diagnostic inverse; complete source physics still evaluated"}));
            // Probe the actual fresh production grid. Its stored Sample nodes
            // contain cumulative child weights, not independent factors.
            let total = grid
                .probe(&Probe::Discrete(
                    vec![0, id.0],
                    cube.iter().copied().map(Some).collect(),
                ))
                .map_err(|message| eyre!(message))?;
            let group = grid
                .probe(&Probe::Discrete(vec![0], vec![]))
                .map_err(|message| eyre!(message))?;
            let discrete = grid
                .probe(&Probe::Discrete(vec![0, id.0], vec![None; cube.len()]))
                .map_err(|message| eyre!(message))?;
            ensure!(
                [total, group, discrete]
                    .iter()
                    .all(|w| w.0.is_finite() && w.0 > 0.0),
                "invalid grid probes"
            );
            let sample = Sample::Discrete(
                total,
                0,
                Some(Box::new(Sample::Discrete(
                    total / group,
                    id.0,
                    Some(Box::new(Sample::Continuous(total / discrete, cube))),
                ))),
            );
            row["complete_sample"] = json!(sample);
            row["grid_probes"] = json!({"total":total.0,"group_prefix":group.0,"discrete_prefix":discrete.0,
                "continuous_inverse_density":(total/discrete).0,"conditional_channel_inverse_probability":(discrete/group).0,
                "scope":"actual freshGrid probes; multiply only outerSampleweight once; sourcecube rounded solely at publicbinary64boundary"});
            for forced_arb in [false, true] {
                let at = Instant::now();
                let evaluated = integrand.evaluate_sample_precise(
                    &sample,
                    model,
                    sample.get_weight(),
                    forced_arb,
                    Complex::new_zero(),
                );
                row["source_physics"].as_array_mut().unwrap().push(json!({"forced_arb":forced_arb,"result":record(evaluated,at.elapsed().as_secs_f64())}));
            }
            ensure!(
                ["raw_physics", "source_physics"].iter().all(|key| row[*key]
                    .as_array()
                    .unwrap()
                    .iter()
                    .all(|entry| {
                        let evaluation = &entry["result"]["evaluation"];
                        let mut cuts = evaluation["events"]
                            .as_array()
                            .into_iter()
                            .flatten()
                            .filter_map(|event| event["cut_info"]["cut_id"].as_u64())
                            .collect::<Vec<_>>();
                        cuts.sort_unstable();
                        evaluation["valid"] == true && cuts == [0, 1, 2, 3, 4, 5]
                    })),
                "invalid native physicalray evaluation retained"
            );
            ensure!(
                row["raw_normals"]["status"] != "error"
                    && row["actual_forward_normals"]["status"] != "error",
                "normal diagnostic failure retained independently of completed physics"
            );
            Ok(())
        })();
        row["complete"] = json!(result.is_ok());
        row["error"] = result
            .err()
            .map(|error| json!(format!("{error:#}")))
            .unwrap_or(Value::Null);
        fs::write(
            output.join(format!("{mode}.{name}.approach.json")),
            serde_json::to_string_pretty(&row)?,
        )?;
        rows.push(row);
    }
    Ok(
        json!({"complete":rows.iter().all(|row|row["complete"]==true),
        "all_actual_forward_points_compact":rows.iter().all(|row|row["actual_forward_normals"]["status"]=="compact"),"rows":rows,
        "scope":"local two-direction physical approach only; no Gaussianacceptance, globalboundedness or MCvariance claim; no extra decades beyond represented archivedpoints"}),
    )
}

// These public, detached calls expose component costs without pretending to
// reproduce the production row's shared host lifetime or its canonical pass.
fn inspect_sampling_components(
    integrand: &ProcessIntegrand,
    sample: &Sample<F<f64>>,
    repetitions: usize,
) -> Result<(SamplingChannelBridgeEvaluation<ArbPrec>, Value)> {
    let mut discrete = Vec::new();
    let mut leaf = sample;
    while let Sample::Discrete(_, index, Some(next)) = leaf {
        discrete.push(*index);
        leaf = next;
    }
    let Sample::Continuous(_, cube) = leaf else {
        return Err(eyre!("retained sample must have a continuous leaf"));
    };
    ensure!(
        discrete == [0, 0] && cube.len() == 12,
        "expected retained group0/joint-channel0/12D sample"
    );
    let coordinates = cube
        .iter()
        .map(|x| ArbPrec::from_f64_exact_binary(x.0))
        .collect::<Vec<_>>();
    let ProcessIntegrand::CrossSection(process) = integrand else {
        return Err(eyre!("cross section required"));
    };
    let bridge = process.data.graph_terms[0]
        .sampling_setup()
        .sampling_bridge::<ArbPrec>()?;
    let id = SamplingChannelId(discrete[1]);
    let anchor = bridge.forward(id, &coordinates)?;
    let mut rows = Vec::new();
    for repetition in 0..repetitions {
        let at = Instant::now();
        let selected = bridge.channels()[id.0].forward(&coordinates);
        let wall = at.elapsed().as_secs_f64();
        rows.push(json!({"repetition":repetition,"operation":"selected_channel_forward","wall_seconds":wall,
            "result":match selected {Ok(map)=>map_record(&map),Err(error)=>json!({"error":format!("{error:#}")})}}));
        let at = Instant::now();
        let complete = bridge.forward(id, &coordinates);
        let wall = at.elapsed().as_secs_f64();
        rows.push(json!({"repetition":repetition,"operation":"bridge_forward_with_partition","wall_seconds":wall,
            "result":match complete {Ok(mapped)=>json!({"map":map_record(&mapped.map),
                "same_native_raw_point":mapped.raw_coordinates==anchor.raw_coordinates,
                "same_native_jacobian":mapped.map.jacobian==anchor.map.jacobian,
                "same_native_partition":mapped.partition.weights==anchor.partition.weights}),
                Err(error)=>json!({"error":format!("{error:#}")})}}));
        for (channel_id, channel) in bridge.channels().iter().enumerate() {
            let at = Instant::now();
            let inverse = channel.inverse(&anchor.raw_coordinates);
            let wall = at.elapsed().as_secs_f64();
            rows.push(json!({"repetition":repetition,"operation":"channel_inverse_at_anchor","channel_id":channel_id,
                "wall_seconds":wall,"result":match inverse {
                    Ok(Some(map))=>json!({"status":"inside_support","map":map_record(&map)}),
                    Ok(None)=>json!({"status":"outside_support"}),
                    Err(error)=>json!({"status":"error","error":format!("{error:#}")})}}));
        }
        let at = Instant::now();
        let partition = bridge.partition(&anchor.raw_coordinates);
        let wall = at.elapsed().as_secs_f64();
        rows.push(json!({"repetition":repetition,"operation":"bridge_partition_at_anchor","wall_seconds":wall,
            "result":match partition {Ok(partition)=>json!({
                "weights":partition.weights.iter().map(|v|F(v.clone()).to_string()).collect::<Vec<_>>(),
                "same_native_partition":partition.weights==anchor.partition.weights}),
                Err(error)=>json!({"error":format!("{error:#}")})}}));
    }
    let report = json!({"precision":"Arb1000","discrete_path":discrete,
        "cube_binary64_bits":cube.iter().map(|x|format!("{:016x}",x.0.to_bits())).collect::<Vec<_>>(),
        "source":"original nested Sample; exact binary64 promotion for independent public bridge calls",
        "outer_grid_weight":sample.get_weight().to_string(),
        "anchor":{"raw_coordinates":anchor.raw_coordinates.iter().map(|v|F(v.clone()).to_string()).collect::<Vec<_>>(),
            "map":map_record(&anchor.map),"weights":anchor.partition.weights.iter().map(|v|F(v.clone()).to_string()).collect::<Vec<_>>()},
        "rows":rows,
        "timing_scope":"sequential detached public calls, after one untimed anchor call; nested operations overlap and MUST NOT be added as production attribution; no evaluator/certificate/lock leaf timing exposed",
        "host_scope":"private production prepared-host payload is not exported; these checks compare native public forward point/J/partition, not a serialized host record"});
    Ok((anchor, report))
}

// Reuse the one loaded state and precise source owner. Expected instability is
// retained as evidence here, not treated as an integration acceptance result.
fn failure_diagnostic(
    integrand: &mut ProcessIntegrand,
    model: &Model,
    manifest: &Value,
    packet: &Path,
    output: &Path,
    repetitions: usize,
) -> Result<Value> {
    let retained: Value = serde_json::from_str(&fs::read_to_string(
        packet.join("failure-worker12-draw12.json"),
    )?)?;
    let failed = &retained["rows"][0];
    ensure!(
        failed["worker"] == 12 && failed["draw"] == 12,
        "wrong retained failure"
    );
    ensure!(
        retained["rows"]
            .as_array()
            .unwrap()
            .iter()
            .all(|row| row["sample"] == failed["sample"]),
        "retained repetitions changed source"
    );
    let timing: Value = serde_json::from_str(&fs::read_to_string(
        packet.join("results-timing1/joint_hz_plus_lmb.json"),
    )?)?;
    let valid = timing["timing_workers"]
        .as_array()
        .unwrap()
        .iter()
        .flat_map(|worker| worker["rows"].as_array().unwrap())
        .find(|row| {
            row["result"]["evaluation"]["valid"] == true
                && row["sample"]["Discrete"][2]["Discrete"][1] == 0
        })
        .ok_or_else(|| eyre!("no retained valid joint draw"))?;
    let sources = [("failed", failed), ("valid_joint_control", valid)];
    let samples = sources
        .iter()
        .map(|(_, row)| serde_json::from_value::<Sample<F<f64>>>(row["sample"].clone()))
        .collect::<std::result::Result<Vec<_>, _>>()?;
    let settings = integrand.get_settings().clone();
    ensure!(
        !settings.subtraction.disable_threshold_subtraction,
        "diagnostic baseline must retain threshold subtraction"
    );
    let baseline = samples
        .iter()
        .map(|sample| inspect_sampling_components(integrand, sample, 0))
        .collect::<Result<Vec<_>>>()?;
    let same_anchor = |before: &SamplingChannelBridgeEvaluation<ArbPrec>,
                       after: &SamplingChannelBridgeEvaluation<ArbPrec>| {
        json!({"raw_point":before.raw_coordinates==after.raw_coordinates,
            "jacobian":before.map.jacobian==after.map.jacobian,
            "partition_weights":before.partition.weights==after.partition.weights})
    };
    let mut report = json!({"purpose":"same-source failure localization, not normalization or runtime-cap acceptance",
        "sources":sources.iter().zip(&baseline).map(|((name,row),(_,anchor))|json!({"name":name,
            "worker":row["worker"],"draw":row["draw"],"sample":row["sample"],
            "retained_result":row["result"],"sampling":anchor})).collect::<Vec<_>>(),
        "physical_matrix":[],"component_workers":[],
        "weights":"precise owner receives Sample::get_weight once; nested discrete weights are not multiplied; report values retain native map factors and the existing outer-weight convention",
        "probe_scope":"native totals and identity-probe cut event weights are retained; per-probe f64 totals/points use existing stability recording and tracing, not a new native per-probe API"});
    let result = (|| -> Result<()> {
        // Clone-only models Integrate's warmed clone path. Explicit rewarm is
        // retained separately because timing1 rebuilt each worker's map caches.
        for rewarm in [false, true] {
            let worker_result = (|| -> Result<Value> {
                let at = Instant::now();
                let mut worker = integrand.clone();
                let clone_seconds = at.elapsed().as_secs_f64();
                let at = Instant::now();
                if rewarm {
                    worker.warm_up(model)?;
                }
                let rewarm_seconds = rewarm.then(|| at.elapsed().as_secs_f64());
                let mut source_rows = Vec::new();
                for (index, sample) in samples.iter().enumerate() {
                    let (anchor, components) =
                        inspect_sampling_components(&worker, sample, repetitions)?;
                    let at = Instant::now();
                    let precise = worker.evaluate_sample_precise(
                        sample,
                        model,
                        sample.get_weight(),
                        false,
                        Complex::new_zero(),
                    );
                    let wall = at.elapsed().as_secs_f64();
                    source_rows.push(json!({"name":sources[index].0,"sampling":components,
                    "same_baseline_anchor":same_anchor(&baseline[index].0,&anchor),"physical":record(precise,wall)}));
                }
                Ok(json!({
                "setup":if rewarm {"clone_then_explicit_rewarm"} else {"warmed_clone_only"},
                "clone_seconds":clone_seconds,"rewarm_seconds":rewarm_seconds,"sources":source_rows}))
            })();
            report["component_workers"].as_array_mut().unwrap().push(worker_result.unwrap_or_else(|error|json!({
                "setup":if rewarm {"clone_then_explicit_rewarm"} else {"warmed_clone_only"},"error":format!("{error:#}")})));
            fs::write(
                output.join("failure-diagnostic-progress.json"),
                serde_json::to_string_pretty(&report)?,
            )?;
        }
        let reference = GaussianReferenceFunction::new(
            manifest["reference"]["width_GeV"].as_f64().unwrap(),
            manifest["reference"]["center_GeV"]
                .as_array()
                .unwrap()
                .iter()
                .map(|v| v.as_f64().unwrap())
                .collect(),
        )?;
        for (name, overlay) in [
            ("ct_on_euler", ""),
            ("ct_on_exact_z", "stability.rotation_axis=[{type='z'}]\n"),
            (
                "ct_off_euler",
                "subtraction.disable_threshold_subtraction=true\n",
            ),
        ] {
            let branch_result = (|| -> Result<Value> {
                *integrand.get_mut_settings()=SetArgs::String {string:format!("{overlay}general.generate_events=true\nstability.recording.record_rotated_results=true\nstability.recording.record_all_stability_levels=true\n")}
                .merge_figment(Figment::from(Serialized::defaults(&settings)))?.extract()?;
                let at = Instant::now();
                integrand.warm_up(model)?;
                let warmup_seconds = at.elapsed().as_secs_f64();
                let before = inspect_sampling_components(integrand, &samples[0], 0);
                let mut rows = Vec::new();
                for (forced_arb, count) in [(false, repetitions), (true, 1)] {
                    for repetition in 0..count {
                        eprintln!(
                            "failure diagnostic: {name}, forced_arb={forced_arb}, repetition={repetition}"
                        );
                        let at = Instant::now();
                        let precise = integrand.evaluate_sample_precise(
                            &samples[0],
                            model,
                            samples[0].get_weight(),
                            forced_arb,
                            Complex::new_zero(),
                        );
                        let wall = at.elapsed().as_secs_f64();
                        rows.push(json!({"forced_arb":forced_arb,"repetition":repetition,"result":record(precise,wall)}));
                    }
                }
                let at = Instant::now();
                let reference_result =
                    integrand.evaluate_reference_sample_detailed(&samples[0], &reference);
                let wall = at.elapsed().as_secs_f64();
                let reference_row = match reference_result {
                    Ok(value) => {
                        let valid = !value.evaluation.evaluation_metadata.is_nan
                            && value.evaluation.integrand_result.re.0.is_finite()
                            && value.evaluation.integrand_result.im.0.is_finite()
                            && value.moments.second_moment.0.is_finite()
                            && !value
                                .evaluation
                                .evaluation_metadata
                                .stability_results
                                .last()
                                .is_some_and(|level| {
                                    matches!(level.status, StabilityStatus::Unstable(_))
                                });
                        json!({"wall_seconds":wall,"valid":valid,
                    "reporting_precision":"f64 after native reference stability and checked narrowing",
                    "evaluation":value.evaluation,"raw_second_moment":value.moments.second_moment,
                    "jacobian_min":value.moments.jacobian_min,"jacobian_max":value.moments.jacobian_max})
                    }
                    Err(error) => json!({"wall_seconds":wall,"error":format!("{error:#}")}),
                };
                let after = inspect_sampling_components(integrand, &samples[0], 0);
                Ok(json!({"name":name,"warmup_seconds":warmup_seconds,
                "settings":integrand.get_settings(),
                "sampling":match &before {Ok((_,sampling))=>sampling.clone(),Err(error)=>json!({"error":format!("{error:#}")})},
                "same_baseline_anchor":before.as_ref().ok().map(|(anchor,_)|same_anchor(&baseline[0].0,anchor)),
                "same_anchor_after_evaluations":before.as_ref().ok().zip(after.as_ref().ok()).map(|((a,_),(b,_))|same_anchor(a,b)),
                "after_sampling_error":after.as_ref().err().map(|error|format!("{error:#}")),
                "rows":rows,"reference":reference_row}))
            })();
            report["physical_matrix"].as_array_mut().unwrap().push(
                branch_result
                    .unwrap_or_else(|error| json!({"name":name,"error":format!("{error:#}")})),
            );
            fs::write(
                output.join("failure-diagnostic-progress.json"),
                serde_json::to_string_pretty(&report)?,
            )?;
        }
        Ok(())
    })();
    *integrand.get_mut_settings() = settings;
    report["complete"] = json!(result.is_ok());
    let equal = |value: &Value| {
        value
            .as_object()
            .is_some_and(|fields| !fields.is_empty() && fields.values().all(|v| v == true))
    };
    report["canonical_invariants_passed"] = json!(
        report["physical_matrix"].as_array().unwrap().len() == 3
            && report["physical_matrix"]
                .as_array()
                .unwrap()
                .iter()
                .all(|row| equal(&row["same_baseline_anchor"])
                    && equal(&row["same_anchor_after_evaluations"]))
            && report["component_workers"].as_array().unwrap().len() == 2
            && report["component_workers"]
                .as_array()
                .unwrap()
                .iter()
                .all(|worker| worker["sources"]
                    .as_array()
                    .is_some_and(|rows| rows.len() == 2
                        && rows.iter().all(|row| equal(&row["same_baseline_anchor"]))))
    );
    report["error"] = result
        .err()
        .map(|error| json!(format!("{error:#}")))
        .unwrap_or(Value::Null);
    Ok(report)
}

// Workers clone the existing physical owner; its caches, grid and precise call
// remain authoritative. Setup/lazy warmup is reported separately, not in W/S/P.
fn time_sources(
    integrand: &ProcessIntegrand,
    model: &Model,
    workers: usize,
    draws: usize,
    repetitions: usize,
    seed: u64,
    hard_requests: &[Value],
    info: &Value,
) -> Result<Vec<Value>> {
    // Finish every worker's setup before any measured calls. Two bounded
    // scoped phases avoid a barrier deadlock on warmup/spawn/panic errors.
    let prepared = std::thread::scope(|scope| {
        let mut handles = Vec::new();
        for worker_id in 0..workers {
            let mut worker = integrand.clone();
            handles.push(std::thread::Builder::new().stack_size(128*1024*1024).spawn_scoped(scope,move ||->Result<_>{
                let at=Instant::now();let warmed=worker.warm_up(model);
                let mut warm_rows=Vec::new();let mut samples=Vec::new();let mut warm_hard=Vec::new();
                if warmed.is_ok() {
                    let mut grid=worker.create_grid();let mut rng=MonteCarloRng::new(seed,worker_id);
                    for index in 0..draws+2 {
                        let mut sample=Sample::new();grid.sample(&mut rng,&mut sample);
                        if index<2 {
                            let at=Instant::now();
                            let result=worker.evaluate_sample_precise(&sample,model,sample.get_weight(),false,Complex::new_zero());
                            let wall=at.elapsed().as_secs_f64();warm_rows.push(json!({"sample":sample,"result":record(result,wall)}));
                        } else {samples.push(sample);}
                    }
                    // The same cloned integrand also warms each raw/inverse
                    // hard path. Events remain disabled as in production cards.
                    warm_hard=replay(&mut worker,model,hard_requests,info,false)?;
                }
                if warm_rows.iter().any(|r:&Value|r["result"]["evaluation"]["valid"]!=true)
                    || warm_hard.iter().any(|r|r["evaluation"]["valid"]!=true) {samples.clear();}
                let setup=json!({"worker":worker_id,"setup_seconds":at.elapsed().as_secs_f64(),
                    "warmup_error":warmed.err().map(|e|format!("{e:#}")),"warmup_draws":warm_rows,"warmup_hard":warm_hard});
                Ok((worker_id,worker,samples,setup))
            })?);
        }
        handles
            .into_iter()
            .map(|h| {
                h.join()
                    .map_err(|_| eyre!("timing warmup worker panicked"))?
            })
            .collect::<Result<Vec<_>>>()
    })?;
    std::thread::scope(|scope| {
        let mut handles = Vec::new();
        for (worker_id, mut worker, samples, mut setup) in prepared {
            handles.push(std::thread::Builder::new().stack_size(128*1024*1024).spawn_scoped(scope,move ||->Result<Value>{
                let mut rows=Vec::new();let mut maximum:Option<(f64,usize)>=None;
                for repetition in 0..repetitions {
                    for (draw,sample) in samples.iter().enumerate() {
                        let at=Instant::now();
                        let result=worker.evaluate_sample_precise(sample,model,sample.get_weight(),false,Complex::new_zero());
                        let wall=at.elapsed().as_secs_f64();let r=record(result,wall);
                        if repetition==0 && r["evaluation"]["valid"]==true {
                            let value=&r["evaluation"]["integrand_result"];
                            let score=(value["re"].as_str().unwrap().parse::<f64>()?.abs()+value["im"].as_str().unwrap().parse::<f64>()?.abs())*sample.get_weight().0.abs();
                            if maximum.is_none_or(|(old,_)|score>old) {maximum=Some((score,draw));}
                        }
                        rows.push(json!({"worker":worker_id,"repetition":repetition,"draw":draw,"sample":sample,"result":r}));
                    }
                }
                let mut hard_rows=Vec::new();let mut maximum_rows=Vec::new();
                if !samples.is_empty() {
                    for repetition in 0..repetitions {
                        for r in replay(&mut worker,model,hard_requests,info,false)? {
                            hard_rows.push(json!({"worker":worker_id,"repetition":repetition,"case":r["case"],"result":r}));
                        }
                        if let Some((score,draw))=maximum {
                            let sample=&samples[draw];let at=Instant::now();
                            let result=worker.evaluate_sample_precise(sample,model,sample.get_weight(),false,Complex::new_zero());
                            let wall=at.elapsed().as_secs_f64();
                            maximum_rows.push(json!({"worker":worker_id,"repetition":repetition,"draw":draw,"sample":sample,
                                "reported_f64_absolute_score":score,"result":record(result,wall)}));
                        }
                    }
                }
                setup["rows"]=json!(rows);setup["hard_rows"]=json!(hard_rows);setup["maximum_rows"]=json!(maximum_rows);
                Ok(setup)
            })?);
        }
        handles
            .into_iter()
            .map(|h| h.join().map_err(|_| eyre!("timing worker panicked"))?)
            .collect::<Result<Vec<_>>>()
    })
}

fn timing_summary(workers: &[Value], field: &str, selected_hard: Option<bool>) -> Value {
    let rows = workers
        .iter()
        .flat_map(|w| w[field].as_array().into_iter().flatten())
        .filter(|row| {
            selected_hard.is_none_or(|selected| row["case"]["channel_name"].is_string() == selected)
        })
        .collect::<Vec<_>>();
    let mut wall = 0.0;
    let mut s = 0.0;
    let mut p = 0.0;
    let mut upper = 0.0;
    let mut ratios = Vec::new();
    let mut invalid = 0;
    for row in &rows {
        let r = &row["result"];
        wall += r["wall_seconds"].as_f64().unwrap();
        if r["evaluation"]["valid"] != true {
            invalid += 1;
        }
        if let (Some(si), Some(pi), Some(ui)) = (
            r["evaluation"]["sampling_seconds"].as_f64(),
            r["evaluation"]["physical_seconds"].as_f64(),
            r["sampling_upper_seconds"].as_f64(),
        ) {
            s += si;
            p += pi;
            upper += ui;
            if pi > 0.0 {
                ratios.push(ui / pi);
            }
        }
    }
    ratios.sort_by(f64::total_cmp);
    let percentile = |q: f64| {
        if ratios.is_empty() {
            None
        } else {
            Some(ratios[((ratios.len() - 1) as f64 * q).ceil() as usize])
        }
    };
    let mut distributions = serde_json::Map::new();
    for metric in [
        "wall_seconds",
        "sampling_seconds",
        "physical_seconds",
        "sampling_upper_seconds",
    ] {
        let mut values = rows
            .iter()
            .filter_map(|row| {
                let r = &row["result"];
                r[metric]
                    .as_f64()
                    .or_else(|| r["evaluation"][metric].as_f64())
            })
            .collect::<Vec<_>>();
        values.sort_by(f64::total_cmp);
        let at = |q: f64| {
            if values.is_empty() {
                None
            } else {
                Some(values[((values.len() - 1) as f64 * q).ceil() as usize])
            }
        };
        distributions.insert(metric.into(), json!({"count":values.len(),"p50":at(0.5),"p90":at(0.9),"p99":at(0.99),"max":values.last()}));
    }
    let warmup_failed = workers.iter().any(|w| {
        !w["warmup_error"].is_null()
            || w["warmup_draws"]
                .as_array()
                .unwrap()
                .iter()
                .any(|r| r["result"]["evaluation"]["valid"] != true)
            || w["warmup_hard"]
                .as_array()
                .unwrap()
                .iter()
                .any(|r| r["evaluation"]["valid"] != true)
    });
    json!({"measured_calls":rows.len(),"invalid_calls":invalid,"warmup_failed":warmup_failed,
        "distributions_seconds":distributions,"sum_wall_seconds":wall,"sum_sampling_seconds":s,"sum_physical_seconds":p,"sum_sampling_upper_seconds":upper,
        "sampling_over_physical":if p>0.0{Some(s/p)}else{None},"conservative_over_physical":if p>0.0{Some(upper/p)}else{None},
        "conservative_ratio_p50":percentile(0.5),"conservative_ratio_p90":percentile(0.9),"conservative_ratio_p99":percentile(0.99),"conservative_ratio_max":ratios.last(),
        "representative_cap_passed":!warmup_failed&&invalid==0&&p>0.0&&upper/p<=0.10,
        "scope":"aggregate elapsed precise-call times across workers, not CPU or batch-wall time; excludes Grid/RNG generation; max_eval=0 matches fresh iteration1, not trained iterations"})
}

fn main() -> Result<()> {
    let args = env::args().skip(1).collect::<Vec<_>>();
    ensure!(
        (4..=8).contains(&args.len()),
        "usage: gate MANIFEST OUTPUT_DIR MODES(comma-separated or all) STAGE(inventory|smoke|local-approach|reference-check|reference|replay|timing|preflight|physics-preflight|pilot|physics-pilot|diagnostic-pilot|failure-diagnostic) [WORKERS=1] [DRAWS=16] [REPETITIONS=3] [SEED=1337]"
    );
    let manifest: Value = serde_json::from_str(&fs::read_to_string(&args[0])?)?;
    let output = Path::new(&args[1]);
    ensure!(
        !output.join("summary.json").exists(),
        "refusing to overwrite completed evidence"
    );
    fs::create_dir_all(output)?;
    let modes = if args[2] == "all" {
        manifest["proposal_order"]
            .as_array()
            .unwrap()
            .iter()
            .map(|s| s.as_str().unwrap().to_owned())
            .collect::<Vec<_>>()
    } else {
        args[2].split(',').map(str::to_owned).collect()
    };
    ensure!(
        [
            "inventory",
            "smoke",
            "local-approach",
            "reference-check",
            "reference",
            "replay",
            "timing",
            "preflight",
            "physics-preflight",
            "all",
            "pilot",
            "physics-pilot",
            "diagnostic-pilot",
            "failure-diagnostic"
        ]
        .contains(&args[3].as_str()),
        "unknown stage"
    );
    let stage = &args[3];
    ensure!(!modes.is_empty(), "at least one mode required");
    let with_reference = matches!(
        stage.as_str(),
        "smoke"
            | "reference-check"
            | "reference"
            | "preflight"
            | "physics-preflight"
            | "all"
            | "pilot"
            | "diagnostic-pilot"
    );
    let full_reference = with_reference && stage != "smoke" && stage != "reference-check";
    let with_replay = matches!(
        stage.as_str(),
        "smoke"
            | "replay"
            | "preflight"
            | "physics-preflight"
            | "all"
            | "pilot"
            | "diagnostic-pilot"
    );
    let with_timing = matches!(
        stage.as_str(),
        "smoke" | "timing" | "preflight" | "all" | "pilot" | "diagnostic-pilot"
    );
    let with_pilots = matches!(
        stage.as_str(),
        "pilot" | "physics-pilot" | "diagnostic-pilot"
    );
    let diagnostic_pilots = stage == "diagnostic-pilot";
    let workers = args
        .get(4)
        .map(|s| s.parse())
        .transpose()?
        .unwrap_or(1usize);
    let draws = args
        .get(5)
        .map(|s| s.parse())
        .transpose()?
        .unwrap_or(16usize);
    let repetitions = args
        .get(6)
        .map(|s| s.parse())
        .transpose()?
        .unwrap_or(3usize);
    let seed = args
        .get(7)
        .map(|s| s.parse())
        .transpose()?
        .unwrap_or(1337u64);
    ensure!(
        (1..=30).contains(&workers) && draws > 0 && repetitions > 0,
        "workers1..30 and positive draws/repetitions required"
    );
    ensure!(
        stage != "failure-diagnostic"
            || (workers == 1 && modes.len() == 1 && modes[0] == "joint_hz_plus_lmb"),
        "failure-diagnostic requires joint_hz_plus_lmb and one worker"
    );
    let state = Path::new(manifest["state"].as_str().unwrap());
    ensure!(
        !output.canonicalize()?.starts_with(state.canonicalize()?),
        "output must be outside saved state"
    );
    let expected: BTreeMap<String, String> = serde_json::from_str(&fs::read_to_string(
        manifest["saved_state_hashes"].as_str().unwrap(),
    )?)?;
    let before = state_hashes(state)?;
    fs::write(
        output.join("state_before.json"),
        serde_json::to_string_pretty(&before)?,
    )?;
    ensure!(
        before == expected,
        "saved state differs from complete reviewed snapshot"
    );
    let executable_hash = Command::new("sha256sum")
        .arg(env::current_exe()?)
        .output()?;
    ensure!(
        executable_hash.status.success(),
        "cannot hash current driver"
    );
    let executable_hash = String::from_utf8(executable_hash.stdout)?;
    let build_identity = json!({"driver_sha256":executable_hash.split_whitespace().next(),
        "source_base_commit":manifest["source_base_commit"],"source_candidate_commit":manifest["source_candidate_commit"],
        "source_candidate_patch_sha256":manifest["source_candidate_patch_sha256"],
        "candidate_binary_sha256":manifest["candidate_binary_sha256"]});
    let reused = if stage == "physics-pilot" {
        let path = manifest["preflight_summary"]
            .as_str()
            .ok_or_else(|| eyre!("physics-pilot requires manifest.preflight_summary"))?;
        let previous: Value = serde_json::from_str(&fs::read_to_string(path)?)?;
        ensure!(
            previous["preflight_accepted"] == true
                && previous["saved_state_unchanged"] == true
                && previous["error"].is_null()
                && previous["physics_audit"]["passed"] == true
                && previous["build_identity"] == build_identity
                && previous["state_hashes"] == json!(before),
            "preflight reuse requires successful current-driver/source/state reference and physics evidence"
        );
        Some(previous)
    } else {
        None
    };
    let mut report = json!({"status":"started","mode":modes,"stage":stage,"workers":workers,"draws_per_worker":draws,"repetitions":repetitions,"seed":seed,"reports":[],
        "build_identity":build_identity,"state_hashes":before,"preflight_reused_from":manifest.get("preflight_summary"),
        "cost_policy":"record timing; former10% cap does not block physics per current user instruction"});
    let execution = (|| -> Result<()> {
        initialise()?;
        let at = Instant::now();
        let mut loaded = StateLoadOption::read_only(state).load()?;
        ensure!(loaded.is_read_only_state(), "read-only load required");
        loaded.state.activate_loaded_integrand_backends(false)?;
        report["cold_load_seconds"] = json!(at.elapsed().as_secs_f64());
        let process_id = loaded.state.resolve_process_ref(Some(&ProcessRef::Name(
            manifest["process_name"].as_str().unwrap().to_owned(),
        )))?;
        let integrand_name = manifest["integrand_name"].as_str().unwrap();
        let original = loaded
            .state
            .process_list
            .get_integrand_mut(process_id, integrand_name)?
            .get_settings()
            .clone();
        let packet = Path::new(&args[0])
            .parent()
            .ok_or_else(|| eyre!("manifest parent missing"))?;
        let mut requests = Vec::new();
        for name in ["raw_smoke_requests.json", "selected_host_requests.json"] {
            let source: Value = serde_json::from_str(&fs::read_to_string(packet.join(name))?)?;
            requests.extend(source["cases"].as_array().unwrap().iter().cloned());
        }
        let mut joint_oracle = if stage == "local-approach" {
            let mut oracle = loaded
                .state
                .process_list
                .get_integrand_mut(process_id, integrand_name)?
                .clone();
            *oracle.get_mut_settings() = SetArgs::String {
                string: fs::read_to_string(
                    manifest["cards"]["joint_hz_plus_lmb"]
                        .as_str()
                        .ok_or_else(|| {
                            eyre!("local-approach requires existing joint_hz_plus_lmb oraclecard")
                        })?,
                )?,
            }
            .merge_figment(Figment::from(Serialized::defaults(&original)))?
            .extract()?;
            std::thread::scope(|scope| -> Result<()> {
                std::thread::Builder::new()
                    .stack_size(128 * 1024 * 1024)
                    .spawn_scoped(scope, || oracle.warm_up(&loaded.state.model))?
                    .join()
                    .map_err(|_| eyre!("joint diagnostic oracle warmup panicked"))?
            })?;
            Some(oracle)
        } else {
            None
        };
        // Every requested mode completes preflight before any integration starts.
        // The same loaded State remains alive while model/integrand borrows are
        // released at the end of each mode and before Integrate::run.
        let mut comparison_sample_count = None;
        for mode in &modes {
            let model = &loaded.state.model;
            let integrand = loaded
                .state
                .process_list
                .get_integrand_mut(process_id, integrand_name)?;
            let card = fs::read_to_string(
                manifest["cards"][mode]
                    .as_str()
                    .ok_or_else(|| eyre!("unknown mode {mode}"))?,
            )?;
            *integrand.get_mut_settings() = SetArgs::String { string: card }
                .merge_figment(Figment::from(Serialized::defaults(&original)))?
                .extract()?;
            let production_settings = integrand.get_settings().clone();
            if with_pilots {
                let count = manifest
                    .get("samples_per_run")
                    .map(|value| {
                        value
                            .as_u64()
                            .and_then(|n| usize::try_from(n).ok())
                            .ok_or_else(|| {
                                eyre!("samples_per_run must be a positive native integer")
                            })
                    })
                    .transpose()?
                    .unwrap_or(production_settings.integrator.n_max);
                ensure!(
                    count > 1
                        && production_settings.integrator.n_start
                            == production_settings.integrator.n_max
                        && production_settings.integrator.n_increase == 0,
                    "only fresh fixed-N single-iteration comparisons supported"
                );
                ensure!(
                    comparison_sample_count.is_none_or(|previous| previous == count),
                    "equal-N comparison cards disagree; set one manifest.samples_per_run before any pilot"
                );
                comparison_sample_count = Some(count);
            }
            let mut correctness_settings = serde_json::to_value(&production_settings)?;
            if let Some(integrator) = correctness_settings["integrator"].as_object_mut() {
                // Different fresh equal-N batches may reuse the same map/physics
                // acceptance. Every proposal, precision and grid setting stays equal.
                for key in ["seed", "n_start", "n_max", "n_increase"] {
                    integrator.remove(key);
                }
            }
            if let Some(previous) = &reused {
                let prior = previous["reports"]
                    .as_array()
                    .and_then(|rows| rows.iter().find(|r| r["mode"] == *mode))
                    .ok_or_else(|| eyre!("preflight has no mode {mode}"))?;
                ensure!(
                    prior["preflight_accepted"] == true
                        && prior["correctness_settings"] == correctness_settings,
                    "preflight settings or acceptance differ for {mode}"
                );
            }
            let at = Instant::now();
            std::thread::scope(|scope| -> Result<()> {
                std::thread::Builder::new()
                    .stack_size(128 * 1024 * 1024)
                    .spawn_scoped(scope, || integrand.warm_up(model))?
                    .join()
                    .map_err(|_| eyre!("warmup panic"))?
            })?;
            let warmup_seconds = at.elapsed().as_secs_f64();
            let info = inventory(integrand, &manifest, mode)?;
            let mut mode_report = json!({"mode":mode,"warmup_seconds":warmup_seconds,"inventory":info,
                    "correctness_settings":correctness_settings,"preflight_reused":reused.is_some()});
            fs::write(
                output.join(format!("{mode}.settings.toml")),
                toml::to_string_pretty(&production_settings)?,
            )?;
            let mode_result = (|| -> Result<()> {
                if stage == "local-approach" {
                    *integrand.get_mut_settings()=SetArgs::String {
                        string:"general.generate_events=true\ngeneral.store_additional_weights_in_event=true\n".into(),
                    }.merge_figment(Figment::from(Serialized::defaults(&production_settings)))?.extract()?;
                    let oracle = joint_oracle.as_mut().unwrap();
                    let worker_integrand = &mut *integrand;
                    let manifest_ref = &manifest;
                    let info_ref = &info;
                    let approach = std::thread::scope(|scope| -> Result<_> {
                        std::thread::Builder::new()
                            .stack_size(128 * 1024 * 1024)
                            .spawn_scoped(scope, move || {
                                worker_integrand.warm_up(model)?;
                                local_approach(
                                    worker_integrand,
                                    oracle,
                                    model,
                                    manifest_ref,
                                    mode,
                                    info_ref,
                                    packet,
                                    output,
                                )
                            })?
                            .join()
                            .map_err(|_| eyre!("localapproach worker panicked"))?
                    })?;
                    let complete = approach["complete"] == true;
                    mode_report["local_approach"] = approach;
                    ensure!(
                        complete,
                        "{mode}: localapproach incomplete; all physical/support failures retained"
                    );
                }
                if stage == "failure-diagnostic" {
                    let diagnostic = std::thread::scope(|scope| -> Result<_> {
                        std::thread::Builder::new()
                            .stack_size(128 * 1024 * 1024)
                            .spawn_scoped(scope, || {
                                failure_diagnostic(
                                    integrand,
                                    model,
                                    &manifest,
                                    packet,
                                    output,
                                    repetitions,
                                )
                            })?
                            .join()
                            .map_err(|_| eyre!("failure diagnostic worker panicked"))?
                    })?;
                    let complete = diagnostic["complete"] == true;
                    mode_report["failure_diagnostic"] = diagnostic;
                    ensure!(
                        complete,
                        "failure diagnostic interrupted; retained completed rows and error"
                    );
                }
                if with_reference {
                    let reference =
                        match reference_stage(integrand, model, &manifest, full_reference, workers)
                        {
                            Ok(reference) => reference,
                            Err(error) => {
                                json!({"passed":false,"finite":false,"error":format!("{error:#}")})
                            }
                        };
                    let passed = reference["passed"] == true;
                    let finite = reference["finite"] == true;
                    mode_report["reference"] = reference;
                    ensure!(
                        finite,
                        "{mode}: numerical reference failure retained with completed/failed batch details"
                    );
                    ensure!(
                        !full_reference || passed || diagnostic_pilots,
                        "{mode}: finite reference missed acceptance bounds; dependent stages not started"
                    );
                }
                if with_replay {
                    // Events are a diagnostic retention overlay only. Restore
                    // the exact production card before timing; no event I/O is timed.
                    *integrand.get_mut_settings() = SetArgs::String {
                        string: fs::read_to_string(packet.join("cards/events_overlay.toml"))?,
                    }
                    .merge_figment(Figment::from(Serialized::defaults(&production_settings)))?
                    .extract()?;
                    let mut cases = requests
                        .iter()
                        .filter(|r| r["mode"] == mode.as_str())
                        .cloned()
                        .collect::<Vec<_>>();
                    // Direct-H uses the same stored bare controls; only its
                    // sampling card changes, never the physical input/metadata.
                    if cases.is_empty() {
                        cases = requests
                            .iter()
                            .filter(|r| r["mode"] == "optimized_lmb")
                            .cloned()
                            .map(|mut r| {
                                r["mode"] = json!(mode);
                                r
                            })
                            .collect();
                    }
                    // Every catalogue needs an actual selected-channel check.
                    // Existing joint requests remain exact; new unions/controls
                    // select a declared label from their own resolved inventory.
                    if !cases.iter().any(|case| case["channel_name"].is_string()) {
                        let channels = info["channels"].as_array().unwrap();
                        let primary = manifest["primary_channels"][mode]
                            .as_str()
                            .or_else(|| {
                                channels
                                    .iter()
                                    .find(|channel| channel["is_lmb"] == false)
                                    .or_else(|| channels.first())
                                    .and_then(|channel| channel["label"].as_str())
                            })
                            .ok_or_else(|| eyre!("missing selected replay channel for {mode}"))?;
                        let selected = cases
                            .iter()
                            .filter(|case| {
                                case["source_case"]
                                    .as_str()
                                    .is_some_and(|name| name.starts_with("hz_00"))
                                    && case["channel_name"].is_null()
                            })
                            .cloned()
                            .map(|mut case| {
                                case["name"] = json!(format!(
                                    "{}_selected_{}",
                                    case["name"].as_str().unwrap(),
                                    primary
                                ));
                                case["channel_name"] = json!(primary);
                                case
                            })
                            .collect::<Vec<_>>();
                        ensure!(
                            selected.len() == 2
                                && selected.iter().any(|case| case["forced_arb"] == true)
                                && selected.iter().any(|case| case["forced_arb"] == false),
                            "selected replay requires the existing ordinary/Arb hz00 pair for {mode}"
                        );
                        cases.extend(selected);
                    }
                    let rows = std::thread::scope(|scope| -> Result<_> {
                        std::thread::Builder::new()
                            .stack_size(128 * 1024 * 1024)
                            .spawn_scoped(scope, || {
                                integrand.warm_up(model)?;
                                replay(integrand, model, &cases, &info, true)
                            })?
                            .join()
                            .map_err(|_| eyre!("replay worker panicked"))?
                    })?;
                    mode_report["replay_case_count"] = json!(rows.len());
                    mode_report["replays"] = json!(rows);
                    let passed = !rows.is_empty()
                        && rows.iter().all(|r| {
                            r["evaluation"]["valid"] == true && r["six_distinct_cut_events"] == true
                        });
                    mode_report["replay_passed"] = json!(passed);
                    // Exhausted/invalid points remain in the report. No second
                    // retry engine or changed source is introduced to hide them.
                    ensure!(
                        passed,
                        "{mode}: raw/selected replay failed; dependent timing not started"
                    );
                    *integrand.get_mut_settings() = production_settings.clone();
                }
                if with_timing {
                    let mut hard = Vec::new();
                    let labels = info["channels"]
                        .as_array()
                        .unwrap()
                        .iter()
                        .filter_map(|c| c["label"].as_str())
                        .collect::<Vec<_>>();
                    let primary = match mode.as_str() {
                        "joint_hz_plus_lmb" => "direct_joint_HZ",
                        "direct_h_p2" => "direct_H_p2",
                        _ => labels[0],
                    };
                    ensure!(
                        labels.contains(&primary),
                        "requested hard channel {primary} missing"
                    );
                    let full_lmb = info["channels"]
                        .as_array()
                        .unwrap()
                        .iter()
                        .find(|channel| channel["is_lmb"] == true)
                        .and_then(|channel| channel["label"].as_str());
                    for case in requests
                        .iter()
                        .filter(|r| r["mode"] == "optimized_lmb" && r["forced_arb"] == false)
                    {
                        for selected in [false, true] {
                            let mut r = case.clone();
                            r["mode"] = json!(mode);
                            let selected_label = if mode == "joint_hz_plus_lmb"
                                && case["source_case"].as_str().unwrap().starts_with("soft22")
                            {
                                full_lmb.ok_or_else(|| {
                                    eyre!(
                                        "soft22 control requires explicit full-support LMB sibling"
                                    )
                                })?
                            } else {
                                primary
                            };
                            r["channel_name"] = if selected {
                                json!(selected_label)
                            } else {
                                Value::Null
                            };
                            r["selection_scope"] = json!(if mode == "joint_hz_plus_lmb"
                                && selected_label != primary
                            {
                                "explicit full-support soft control; no compact-joint coverage claim"
                            } else {
                                "explicit named chart; support must be established by the actual inverse"
                            });
                            r["name"] = json!(format!(
                                "{}_hard_{}",
                                case["source_case"].as_str().unwrap(),
                                if selected { "selected" } else { "bare" }
                            ));
                            hard.push(r);
                        }
                    }
                    ensure!(
                        hard.len() == 6,
                        "three stored hard points in both bare/selected modes required"
                    );
                    let at = Instant::now();
                    let rows = time_sources(
                        integrand,
                        model,
                        workers,
                        draws,
                        repetitions,
                        seed,
                        &hard,
                        &info,
                    )?;
                    mode_report["timing_batch_wall_seconds"] = json!(at.elapsed().as_secs_f64());
                    let representative = timing_summary(&rows, "rows", None);
                    let hard_selected = timing_summary(&rows, "hard_rows", Some(true));
                    let hard_bare = timing_summary(&rows, "hard_rows", Some(false));
                    let maxima = timing_summary(&rows, "maximum_rows", None);
                    let summaries = [&representative, &hard_selected, &hard_bare, &maxima];
                    let finite = summaries.iter().all(|s| {
                        s["invalid_calls"] == 0
                            && s["warmup_failed"] == false
                            && s["measured_calls"].as_u64().unwrap_or(0) > 0
                    });
                    let cap = workers == 20
                        && [&representative, &hard_selected, &maxima]
                            .iter()
                            .all(|s| s["representative_cap_passed"] == true);
                    mode_report["timing_summary"] = representative;
                    mode_report["hard_selected_timing"] = hard_selected;
                    mode_report["hard_bare_timing"] = hard_bare;
                    mode_report["representative_maximum_timing"] = maxima;
                    mode_report["timing_finite"] = json!(finite);
                    mode_report["timing_cap_passed"] = json!(cap);
                    mode_report["timing_workers"] = json!(rows);
                    ensure!(
                        finite,
                        "{mode}: exhausted/invalid timing result retained; no pilot can hide numerical failures"
                    );
                }
                Ok(())
            })();
            *integrand.get_mut_settings() = production_settings;
            // Timing remains evidence, not a correctness gate. Any requested
            // timing invalidity has already propagated above and still stops.
            let accepted = reused.is_some()
                || (mode_report["reference"]["passed"] == true
                    && mode_report["replay_passed"] == true);
            mode_report["preflight_accepted"] = json!(accepted);
            mode_report["error"] = mode_result
                .as_ref()
                .err()
                .map(|e| json!(format!("{e:#}")))
                .unwrap_or(Value::Null);
            fs::write(
                output.join(format!("{mode}.json")),
                serde_json::to_string_pretty(&mode_report)?,
            )?;
            report["reports"].as_array_mut().unwrap().push(mode_report);
            mode_result?;
        }
        if with_replay {
            // Decimal-only postprocessing of retained current-version values;
            // this script never loads a GammaLoop state or evaluates physics.
            let audit = Command::new("python")
                .arg(packet.join("audit_physical.py"))
                .arg(&args[0])
                .arg(output)
                .output()?;
            let audit_path = output.join("physics_audit.json");
            report["physics_audit"] = if audit_path.exists() {
                serde_json::from_str(&fs::read_to_string(&audit_path)?)?
            } else {
                json!({"error":"audit produced no result","stdout":String::from_utf8_lossy(&audit.stdout),"stderr":String::from_utf8_lossy(&audit.stderr)})
            };
            ensure!(
                audit.status.success(),
                "current native physical-accuracy checks failed; see physics_audit.json"
            );
        } else if let Some(previous) = &reused {
            report["physics_audit"] = previous["physics_audit"].clone();
        }
        let preflight_accepted = report["reports"]
            .as_array()
            .unwrap()
            .iter()
            .all(|r| r["preflight_accepted"] == true);
        report["preflight_accepted"] = json!(preflight_accepted);
        if with_pilots {
            ensure!(
                preflight_accepted || diagnostic_pilots,
                "pilot preflight missed acceptance; use explicit diagnostic-pilot stage only for bounded investigation"
            );
            let mut cli = CLISettings::default();
            cli.session.read_only_state = true;
            cli.state.folder = state.to_path_buf();
            let mut pilots = Vec::new();
            let seeds = manifest["paired_seeds"]
                .as_array()
                .ok_or_else(|| eyre!("paired_seeds required"))?;
            let mut unique_seeds = seeds
                .iter()
                .map(|seed| seed.as_u64().ok_or_else(|| eyre!("integer seed required")))
                .collect::<Result<Vec<_>>>()?;
            unique_seeds.sort_unstable();
            unique_seeds.dedup();
            ensure!(
                !seeds.is_empty() && unique_seeds.len() == seeds.len(),
                "nonempty distinct seeds required"
            );
            for pilot_seed in manifest["paired_seeds"].as_array().unwrap() {
                for mode in &modes {
                    let workspace = output
                        .join("pilot")
                        .join(format!("{mode}_seed{}", pilot_seed.as_u64().unwrap()))
                        .join("workspace");
                    ensure!(
                        !workspace.exists(),
                        "refusing to resume/overwrite pilot {}",
                        workspace.display()
                    );
                    let sample_count = {
                        let integrand = loaded
                            .state
                            .process_list
                            .get_integrand_mut(process_id, integrand_name)?;
                        *integrand.get_mut_settings() = SetArgs::String {
                            string: fs::read_to_string(manifest["cards"][mode].as_str().unwrap())?,
                        }
                        .merge_figment(Figment::from(Serialized::defaults(&original)))?
                        .extract()?;
                        let settings = integrand.get_mut_settings();
                        settings.integrator.seed = pilot_seed.as_u64().unwrap();
                        let sample_count = comparison_sample_count
                            .ok_or_else(|| eyre!("missing prechecked equal-N count"))?;
                        ensure!(
                            sample_count > 1
                                && settings.integrator.n_start == settings.integrator.n_max
                                && settings.integrator.n_increase == 0,
                            "only fresh fixed-N single-iteration comparisons supported"
                        );
                        settings.integrator.n_start = sample_count;
                        settings.integrator.n_max = sample_count;
                        // Preserve the exact effective card used by this seed/N,
                        // as well as the integration owner's saved workspace card.
                        fs::create_dir_all(workspace.parent().unwrap())?;
                        fs::write(
                            workspace.parent().unwrap().join("effective-settings.toml"),
                            toml::to_string_pretty(integrand.get_settings())?,
                        )?;
                        sample_count
                    };
                    let command = Integrate {
                        process: vec![ProcessRef::Name(
                            manifest["process_name"].as_str().unwrap().to_owned(),
                        )],
                        integrand_name: vec![integrand_name.to_owned()],
                        n_cores: Some(workers),
                        workspace_path: Some(workspace.clone()),
                        batch_size: Some(256),
                        batch_timing: 0.0,
                        renderer: RendererOption::Tabled,
                        show_phase: ShowPhaseOption::Both,
                        show_max_weight_info: true,
                        show_max_weight_info_for_discrete_bins: true,
                        write_results_for_each_iteration: true,
                        no_stream_updates: true,
                        no_stream_iterations: true,
                        ..Integrate::default()
                    };
                    let at = Instant::now();
                    // Existing Integrate owns slot warming, worker dispatch,
                    // accumulation, absolute estimates, maxima and checkpoints.
                    let result = std::thread::scope(|scope| -> Result<_> {
                        std::thread::Builder::new()
                            .stack_size(128 * 1024 * 1024)
                            .spawn_scoped(scope, || command.run(&mut loaded.state, &cli))?
                            .join()
                            .map_err(|_| eyre!("pilot worker panicked"))?
                    });
                    let wall = at.elapsed().as_secs_f64();
                    let (record, finite) = match result {
                        Ok(value) => {
                            let slot = value
                                .result
                                .single_slot()
                                .ok_or_else(|| eyre!("single pilot slot required"))?;
                            let scalars = [
                                slot.integral.result.re.0,
                                slot.integral.result.im.0,
                                slot.integral.error.re.0,
                                slot.integral.error.im.0,
                                slot.absolute.integral.result.re.0,
                                slot.absolute.integral.result.im.0,
                                slot.absolute.integral.error.re.0,
                                slot.absolute.integral.error.im.0,
                            ];
                            let finite = slot.integral.neval == sample_count
                                && slot.absolute.integral.neval == sample_count
                                && slot.integration_statistics.nan_or_unstable_percentage == 0.0
                                && scalars.iter().all(|v| v.is_finite());
                            (json!({"output":value,"finite_complete":finite}), finite)
                        }
                        Err(error) => (
                            json!({"error":format!("{error:#}"),"finite_complete":false}),
                            false,
                        ),
                    };
                    let row = json!({"mode":mode,"seed":pilot_seed,"sample_count":sample_count,"cores":workers,"workspace":workspace,"elapsed_seconds":wall,"result":record,
                        "diagnostic_only":diagnostic_pilots,"preflight_accepted":preflight_accepted,
                        "scope":"fresh first iteration; equal seeds pair schedules, not physical points across maps; no second integration/statistics engine"});
                    pilots.push(row);
                    report["pilots"] = json!(pilots);
                    fs::write(
                        output.join("pilots.json"),
                        serde_json::to_string_pretty(&pilots)?,
                    )?;
                    ensure!(
                        finite,
                        "pilot numerical/completion failure retained; remaining pilots not started"
                    );
                    let integrand = loaded
                        .state
                        .process_list
                        .get_integrand_mut(process_id, integrand_name)?;
                    inventory(integrand, &manifest, mode)?;
                }
            }
        }

        Ok(())
    })();
    // Check persistence even on a propagated numerical/inventory failure.
    let after = state_hashes(state)?;
    fs::write(
        output.join("state_after.json"),
        serde_json::to_string_pretty(&after)?,
    )?;
    report["saved_state_unchanged"] = json!(before == after);
    report["error"] = execution
        .as_ref()
        .err()
        .map(|e| json!(format!("{e:#}")))
        .unwrap_or(Value::Null);
    let invalid = report["reports"].as_array().unwrap().iter().any(|r| {
        r.get("replay_passed") == Some(&Value::Bool(false))
            || r.get("timing_finite") == Some(&Value::Bool(false))
    });
    report["status"] = json!(if execution.is_ok() && before == after && !invalid {
        if diagnostic_pilots {
            "completed_diagnostic_pilot"
        } else {
            "completed_requested_stages"
        }
    } else {
        "failed"
    });
    report["scope"] = json!({"finite_smoke_is_not_normalization":true,"runtime_cap":"representative, stored hard selected/bare and replayed representative maxima, each reported separately",
        "precision_scope":"fresh first iteration max_eval=0; trained-iteration rescue history not certified",
        "maps_scope":"completed-point hosted joint; CT-star density cure remains pending","gain_claim":false});
    fs::write(
        output.join("summary.json"),
        serde_json::to_string_pretty(&report)?,
    )?;
    execution?;
    ensure!(before == after, "saved state changed");
    ensure!(!invalid, "bounded evaluations failed; see retained reports");
    Ok(())
}

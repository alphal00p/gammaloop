// Replay one captured complete Sample through existing canonical and physical owners.
mod client {
    include!("gate-max-support.rs");
    use gammalooprs::utils::serde_utils::SmartSerde;

    pub fn run_captured_source() -> Result<()> {
        let args = env::args().skip(1).collect::<Vec<_>>();
        ensure!(
            args.len() == 3,
            "captured-source MANIFEST REQUEST NEW_OUTPUT"
        );
        let manifest: Value = serde_json::from_str(&fs::read_to_string(&args[0])?)?;
        let request: Value = serde_json::from_str(&fs::read_to_string(&args[1])?)?;
        let output = Path::new(&args[2]);
        ensure!(
            !output.exists(),
            "refusing to overwrite captured-source replay"
        );
        fs::create_dir_all(output)?;
        let state_path = Path::new(manifest["state"].as_str().unwrap());
        for original in std::iter::once(state_path).chain(
            request["immutable_directories"]
                .as_array()
                .unwrap()
                .iter()
                .map(|v| Path::new(v.as_str().unwrap())),
        ) {
            ensure!(
                !output.canonicalize()?.starts_with(original.canonicalize()?),
                "output must be outside immutable inputs"
            );
        }
        let before = state_hashes(state_path)?;
        let expected: BTreeMap<String, String> = serde_json::from_str(&fs::read_to_string(
            manifest["saved_state_hashes"].as_str().unwrap(),
        )?)?;
        ensure!(
            before == expected,
            "generated state differs from original snapshot"
        );
        for (source, expected) in request["input_sha256"].as_object().unwrap() {
            let hash = Command::new("sha256sum").arg(source).output()?;
            ensure!(
                hash.status.success()
                    && String::from_utf8(hash.stdout)?.split_whitespace().next()
                        == expected.as_str(),
                "changed replay input: {source}"
            );
        }
        let current_build: Value = serde_json::from_str(&fs::read_to_string(
            request["replay_build_record"].as_str().unwrap(),
        )?)?;
        ensure!(
            current_build["status"] == "compiled",
            "replay build record is not compiled"
        );
        let mut report = json!({"status":"started","request":args[1],"manifest":args[0],"manifest_scope":"original physical settings/inventory declaration; actual linked replay build is recorded separately", "current_replay_build":current_build,"state_before":before,"input_sha256":request["input_sha256"],"calls":[]});
        let execution = (|| -> Result<()> {
            initialise()?;
            let mut loaded = StateLoadOption::read_only(state_path).load()?;
            ensure!(loaded.is_read_only_state(), "read-only state required");
            loaded.state.activate_loaded_integrand_backends(false)?;
            let process_id = loaded.state.resolve_process_ref(Some(&ProcessRef::Name(
                manifest["process_name"].as_str().unwrap().to_owned(),
            )))?;
            let model = &loaded.state.model;
            let integrand = loaded
                .state
                .process_list
                .get_integrand_mut(process_id, manifest["integrand_name"].as_str().unwrap())?;
            *integrand.get_mut_settings() = gammalooprs::settings::RuntimeSettings::from_file(
                request["settings"].as_str().unwrap(),
                "captured original workspace settings",
            )?;
            // Retention only: physical, stability, WH/WF and sampling settings stay original.
            integrand.get_mut_settings().general.generate_events = true;
            integrand
                .get_mut_settings()
                .general
                .store_additional_weights_in_event = true;
            integrand.warm_up(model)?;
            report["inventory"] = inventory(integrand, &manifest, "optimized_lmb")?;
            let capture: Value =
                serde_json::from_str(&fs::read_to_string(request["capture"].as_str().unwrap())?)?;
            let sample: Sample<F<f64>> =
                serde_json::from_value(capture["complete_sample"].clone())?;
            let mut ids = Vec::new();
            let mut leaf = &sample;
            while let Sample::Discrete(_, id, Some(next)) = leaf {
                ids.push(*id);
                leaf = next;
            }
            let Sample::Continuous(_, cube) = leaf else {
                return Err(eyre!("captured source has no continuous leaf"));
            };
            ensure!(
                ids == [0, 5] && sample.get_weight().0.to_bits() == 6.0_f64.to_bits(),
                "complete source path/weight changed"
            );
            ensure!(
                json!(
                    cube.iter()
                        .map(|x| format!("{:016x}", x.0.to_bits()))
                        .collect::<Vec<_>>()
                ) == capture["cube_binary64_bits"],
                "captured cube bits changed"
            );
            let ProcessIntegrand::CrossSection(process) = &*integrand else {
                return Err(eyre!("cross section required"));
            };
            let coordinates = cube
                .iter()
                .map(|x| ArbPrec::from_f64_exact_binary(x.0))
                .collect::<Vec<_>>();
            let mapped = process.data.graph_terms[0]
                .sampling_setup()
                .sampling_bridge::<ArbPrec>()?
                .forward(SamplingChannelId(ids[1]), &coordinates)?;
            let canonical = approach_map(&mapped)?;
            report["complete_sample"] = json!(sample);
            report["original_error"] = capture["error"].clone();
            report["canonical_map"] = canonical.clone();
            report["canonical_map_exact"] = json!(canonical == capture["canonical_map"]);
            ensure!(
                canonical == capture["canonical_map"],
                "canonical raw point/J/partition changed before physical replay"
            );
            for force_arb in [false, true] {
                let start = Instant::now();
                let result = integrand.evaluate_sample_precise(
                    &sample,
                    model,
                    sample.get_weight(),
                    force_arb,
                    Complex::new_zero(),
                );
                let native = record(result, start.elapsed().as_secs_f64());
                let mut cuts = native["evaluation"]["events"]
                    .as_array()
                    .into_iter()
                    .flatten()
                    .filter_map(|e| e["cut_info"]["cut_id"].as_u64())
                    .collect::<Vec<_>>();
                cuts.sort_unstable();
                let complete = native["evaluation"]["valid"] == true
                    && cuts == [0, 1, 2, 3, 4, 5]
                    && (!force_arb || native["evaluation"]["precision"] == "Arb");
                report["calls"]
                    .as_array_mut()
                    .unwrap()
                    .push(json!({"force_arb":force_arb,"complete":complete,"native":native}));
                fs::write(
                    output.join("progress.json"),
                    serde_json::to_string_pretty(&report)?,
                )?;
            }
            ensure!(
                report["calls"]
                    .as_array()
                    .unwrap()
                    .iter()
                    .all(|r| r["complete"] == true),
                "captured physical replay failure retained"
            );
            Ok(())
        })();
        let after = state_hashes(state_path)?;
        report["state_after"] = json!(after);
        report["saved_state_unchanged"] = json!(before == after);
        report["error"] = execution
            .as_ref()
            .err()
            .map(|e| json!(format!("{e:#}")))
            .unwrap_or(Value::Null);
        report["status"] = json!(if execution.is_ok() && before == after {
            "completed_captured_replay"
        } else {
            "failed_captured_replay"
        });
        report["scope"] = json!(
            "two actual precise calls; complete outer Sample weight once; no histogram/integration statistics or tolerance change; numerical ordinary/Arb agreement requires separate audit"
        );
        fs::write(
            output.join("summary.json"),
            serde_json::to_string_pretty(&report)?,
        )?;
        ensure!(before == after, "generated state changed");
        execution
    }
}

fn main() -> color_eyre::Result<()> {
    std::thread::Builder::new()
        .stack_size(128 * 1024 * 1024)
        .spawn(client::run_captured_source)?
        .join()
        .map_err(|_| color_eyre::eyre::eyre!("captured-source worker panicked"))?
}

#!/usr/bin/env python3
"""Audit a completed captured-source replay with the existing native metric.

Usage: audit_captured_source_replay.py RESULT_DIRECTORY
Reads retained records only; writes captured_source_accuracy_audit.json.
"""

from pathlib import Path
from decimal import Decimal as D, localcontext
import copy
import hashlib
import json
import struct
import sys
import tomllib

from audit_physical import compare, events, metric, norm, number, vector


def audit(directory):
    result = {
        "passed": False,
        "decimal_precision": 350,
        "scope": "One exact complete captured Sample; original canonical point/J/partition, ordinary and forced-Arb physical calls. No histogram, integration statistic or global error bound.",
        "checks": [],
        "component_relative_misses": [],
        "precision_budgets": {},
        "input_sha256": {},
        "criteria": {
            "metric_owner": "audit_physical.py; same total/cut criteria as audit_maximum_results.py",
            "pair_budget": "sum of the two actual final-lane requirements, minimum Re/Im requirement per lane",
            "total": "complex norm error relative to max of both total norms; whole zero requires exact equality",
            "cut": "complex norm scale at least either complete total norm",
            "factor_and_event_sum": "one actual lane budget; event weights already contain the outer Sample factor",
            "decomposition": "one lane budget, scale at least sum of component norms",
            "small_components": "own relative misses remain diagnostics even when the complex norm passes",
        },
    }

    def reference(path):
        path = Path(path).resolve(strict=True)
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        result["input_sha256"][str(path)] = digest
        return {"path": str(path), "sha256": digest}

    def read(path):
        return json.loads(Path(path).read_text())

    def require(condition, message):
        if not condition:
            raise ValueError(message)
        return {"passed": True}

    def check(kind, label, run):
        try:
            detail = run()
            entry = {"kind": kind, "label": label, **detail}
        except (OSError, KeyError, TypeError, ValueError, ArithmeticError) as error:
            entry = {"kind": kind, "label": label, "passed": False, "error": str(error)}
        result["checks"].append(entry)

    result["summary"] = reference(directory / "summary.json")
    result["metric_owner"] = reference(Path(__file__).with_name("audit_physical.py"))
    result["audit_source"] = reference(__file__)
    summary = read(result["summary"]["path"])
    result["request"] = reference(summary["request"])
    request = read(result["request"]["path"])
    for name, path in (
        ("capture", request["capture"]),
        ("settings", request["settings"]),
        ("source_manifest", summary["manifest"]),
        ("capture_run_summary", Path(request["capture"]).with_name("summary.json")),
        ("replay_build_record", request["replay_build_record"]),
    ):
        result[name] = reference(path)
    capture = read(result["capture"]["path"])
    capture_run = read(result["capture_run_summary"]["path"])
    manifest = read(result["source_manifest"]["path"])
    settings = tomllib.loads(Path(result["settings"]["path"]).read_text())
    for level in settings["stability"]["levels"]:
        budget = min(
            D(str(level["required_precision_for_re"])),
            D(str(level["required_precision_for_im"])),
        )
        require(budget.is_finite() and budget > 0, "invalid configured native budget")
        precision = level["precision"]
        old = D(result["precision_budgets"].get(precision, str(budget)))
        result["precision_budgets"][precision] = str(min(old, budget))
    result["check_on_norm"] = settings["stability"].get("check_on_norm", True)
    check(
        "completion",
        "captured replay",
        lambda: require(
            summary["status"] == "completed_captured_replay"
            and summary.get("error") is None
            and summary["saved_state_unchanged"] is True
            and summary["state_before"]
            == summary["state_after"]
            == capture_run["state_after"]
            and len(summary["state_before"]) == 35,
            "replay failed or original state record changed",
        ),
    )
    check(
        "settings",
        "unchanged physical criteria",
        lambda: require(
            result["check_on_norm"] is True
            and not settings["subtraction"].get("disable_threshold_subtraction", False)
            and settings["general"].get("orientation_pat", {}).get("pat") is None,
            "CT, orientation or norm-stability scope changed",
        ),
    )

    def original_inputs():
        require(
            summary["input_sha256"] == request["input_sha256"],
            "input hash declaration changed",
        )
        for path, expected in request["input_sha256"].items():
            require(
                reference(path)["sha256"] == expected, f"replay input changed: {path}"
            )
        require(
            summary["current_replay_build"]
            == read(result["replay_build_record"]["path"]),
            "actual replay build record changed",
        )
        return {"passed": True}

    check("input_identity", "source and replay record", original_inputs)
    check(
        "inventory",
        "original full GL638",
        lambda: require(
            summary["inventory"] == capture_run["inventory"]
            and summary["inventory"]["graph"] == manifest["graph_name"]
            and len(set(summary["inventory"]["production_orientation_keys"])) == 936
            and sorted(cut["id"] for cut in summary["inventory"]["cuts"])
            == list(range(6))
            and summary["inventory"]["exposed_orientation_selectors"] == 1,
            "original orientation/cut/CT/channel inventory changed",
        ),
    )

    def exact_source():
        require(
            summary["complete_sample"] == capture["complete_sample"],
            "complete Sample changed",
        )
        require(
            summary["original_error"] == capture["error"]
            and capture["exact_original_error_match"] is True,
            "original error identity lost",
        )
        leaf = summary["complete_sample"]
        outer = D(str(leaf["Discrete"][0]))
        ids = []
        while "Discrete" in leaf:
            _, channel, leaf = leaf["Discrete"]
            ids.append(channel)
        _, cube = leaf["Continuous"]
        bits = [struct.pack(">d", x).hex() for x in cube]
        require(
            ids == [0, 5] and outer == 6 and bits == capture["cube_binary64_bits"],
            "source IDs, cumulative grid weight or exact binary64 cube changed",
        )
        require(
            summary["canonical_map_exact"] is True
            and summary["canonical_map"] == capture["canonical_map"],
            "canonical raw point/J/partition changed",
        )
        return {
            "passed": True,
            "source_path": ids,
            "outer_weight": str(outer),
            "cube_binary64_bits": bits,
            "canonical_map_exact": True,
        }

    check("exact_canonical_source", "retained Sample", exact_source)
    calls = summary["calls"]
    check(
        "coverage",
        "ordinary plus forced Arb",
        lambda: require(
            len(calls) == 2
            and [row["force_arb"] for row in calls] == [False, True]
            and all(row["complete"] is True for row in calls),
            "missing or incomplete physical call",
        ),
    )
    for row in calls:
        label = "forced_arb" if row["force_arb"] else "ordinary"

        def native(row=row, label=label):
            evaluation = row["native"]["evaluation"]
            require(
                evaluation["valid"] is True,
                evaluation.get("error", "invalid physical evaluation"),
            )
            precision = evaluation["precision"]
            require(
                not row["force_arb"] or precision == "Arb",
                "forced control did not use Arb",
            )
            budget = D(result["precision_budgets"][precision])
            cut_events = events(evaluation)
            require(
                all(
                    event["cut_info"]["graph_id"] == 0
                    and event["cut_info"]["sampling_channel_id"] == 5
                    for event in cut_events.values()
                ),
                "cut graph/channel differs from retained source",
            )
            total = vector(evaluation["complete_sample_estimator"])
            summed = tuple(
                sum(vector(event["weight"])[i] for event in cut_events.values())
                for i in (0, 1)
            )
            check("native_event_sum", label, lambda: metric(summed, total, budget))
            jacobian = (
                number(evaluation["parameterization_jacobian"])
                if evaluation["parameterization_jacobian"] is not None
                else D(1)
            )
            outer = number(evaluation["integrator_weight"])
            require(outer == 6, "outer complete Sample weight changed")
            expected = tuple(
                x * jacobian * outer for x in vector(evaluation["integrand_result"])
            )
            check(
                "complete_factor_once", label, lambda: metric(total, expected, budget)
            )
            for cut_id, event in cut_events.items():
                ct = event["threshold_counterterms"]
                terms = [vector(ct["original"])] + [
                    vector(component["weighted"]) for component in ct["components"]
                ]
                combined = tuple(sum(term[i] for term in terms) for i in (0, 1))
                check(
                    "native_decomposition",
                    f"{label}:cut{cut_id}",
                    lambda combined=combined, event=event, terms=terms: metric(
                        combined,
                        vector(event["weight"]),
                        budget,
                        sum(norm(term) for term in terms),
                    ),
                )
            return {"passed": True, "precision": precision, "tolerance": str(budget)}

        check("native_validity", label, native)

    def pair():
        left, right = [copy.deepcopy(row["native"]) for row in calls]
        tolerance = sum(
            D(result["precision_budgets"][row["evaluation"]["precision"]])
            for row in (left, right)
        )
        for row in (left, right):
            row["evaluation"]["integrand_result"] = row["evaluation"][
                "complete_sample_estimator"
            ]
        return compare(left, right, tolerance)

    check("ordinary_vs_forced_arb", "complete Y and all six cuts", pair)
    for entry in result["checks"]:
        values = [("total", entry.get("total"))]
        if "components" in entry:
            values.append((entry["kind"], entry))
        values.extend((f"cut{cut['cut_id']}", cut) for cut in entry.get("cuts", []))
        for scope, value in values:
            if value:
                for phase, component in value["components"].items():
                    if not component["own_relative_budget_passed"]:
                        result["component_relative_misses"].append(
                            {
                                "kind": entry["kind"],
                                "label": entry["label"],
                                "scope": scope,
                                "phase": phase,
                                **component,
                            }
                        )
    result["passed"] = bool(result["checks"]) and all(
        row["passed"] for row in result["checks"]
    )
    result["counts"] = {
        "checks": len(result["checks"]),
        "failed_checks": sum(not row["passed"] for row in result["checks"]),
        "component_relative_misses": len(result["component_relative_misses"]),
    }
    return result


def main():
    if len(sys.argv) != 2:
        raise SystemExit(__doc__)
    directory = Path(sys.argv[1])
    try:
        with localcontext() as context:
            context.prec = 350
            result = audit(directory)
    except (OSError, KeyError, TypeError, ValueError, ArithmeticError) as error:
        result = {
            "passed": False,
            "error": str(error),
            "scope": "missing or invalid retained evidence; no physical run",
        }
    (directory / "captured_source_accuracy_audit.json").write_text(
        json.dumps(result, indent=2) + "\n"
    )
    print(
        json.dumps(
            {
                "passed": result["passed"],
                "counts": result.get("counts"),
                "error": result.get("error"),
            }
        )
    )
    return 0 if result["passed"] else 1


if __name__ == "__main__":
    sys.exit(main())

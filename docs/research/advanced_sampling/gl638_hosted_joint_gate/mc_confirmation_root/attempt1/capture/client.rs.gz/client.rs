// Exact failed first-iteration source reduction using the frozen client's
// loading/serialization and production Grid/raw-evaluation owners.
mod client {
    include!("gate-max-support.rs");
    use gammalooprs::{integrands::process::EvaluationTarget, utils::serde_utils::SmartSerde};
    use std::sync::atomic::{AtomicBool, Ordering};

    pub fn run_source_reduction() -> Result<()> {
        let args = env::args().skip(1).collect::<Vec<_>>();
        ensure!(
            args.len() == 3,
            "source-reduction MANIFEST REQUEST NEW_OUTPUT"
        );
        let manifest: Value = serde_json::from_str(&fs::read_to_string(&args[0])?)?;
        let request: Value = serde_json::from_str(&fs::read_to_string(&args[1])?)?;
        let output = Path::new(&args[2]);
        ensure!(!output.exists(), "refusing to overwrite source reduction");
        fs::create_dir_all(output)?;
        let state_path = Path::new(manifest["state"].as_str().unwrap());
        ensure!(
            !output
                .canonicalize()?
                .starts_with(state_path.canonicalize()?),
            "output must be outside saved state"
        );
        for directory in request["immutable_directories"].as_array().unwrap() {
            ensure!(
                !output
                    .canonicalize()?
                    .starts_with(Path::new(directory.as_str().unwrap()).canonicalize()?),
                "output must be outside retained inputs"
            );
        }
        let before = state_hashes(state_path)?;
        let expected: BTreeMap<String, String> = serde_json::from_str(&fs::read_to_string(
            manifest["saved_state_hashes"].as_str().unwrap(),
        )?)?;
        ensure!(
            before == expected,
            "generated state differs from reviewed snapshot"
        );
        let mut inputs = BTreeMap::new();
        for (path, expected) in request["input_sha256"].as_object().unwrap() {
            let hash = Command::new("sha256sum").arg(path).output()?;
            ensure!(hash.status.success(), "cannot authenticate reduction input");
            let actual = String::from_utf8(hash.stdout)?
                .split_whitespace()
                .next()
                .unwrap()
                .to_owned();
            ensure!(
                Some(actual.as_str()) == expected.as_str(),
                "changed reduction input: {path}"
            );
            inputs.insert(path.clone(), actual);
        }
        let mut report = json!({"status":"started","manifest":args[0],"request":args[1],"state_before":before,"input_sha256":inputs,
            "workers":[],"scope":"exact fresh production source enumeration, no integration/statistics result; workers stop on first error and may be cancelled after the matching original error"});
        let started = Instant::now();
        let execution = (|| -> Result<()> {
            initialise()?;
            let mut loaded = StateLoadOption::read_only(state_path).load()?;
            ensure!(loaded.is_read_only_state(), "read-only state required");
            loaded.state.activate_loaded_integrand_backends(false)?;
            let process_id = loaded.state.resolve_process_ref(Some(&ProcessRef::Name(
                manifest["process_name"].as_str().unwrap().to_owned(),
            )))?;
            let model = &loaded.state.model;
            let integrand = loaded
                .state
                .process_list
                .get_integrand_mut(process_id, manifest["integrand_name"].as_str().unwrap())?;
            *integrand.get_mut_settings() = gammalooprs::settings::RuntimeSettings::from_file(
                request["settings"].as_str().unwrap(),
                "exact failed integration workspace settings",
            )?;
            let n = request["samples"].as_u64().unwrap() as usize;
            let workers = request["workers"].as_u64().unwrap() as usize;
            let seed = request["seed"].as_u64().unwrap();
            let slot_seed = request["slot_seed"].as_u64().unwrap();
            ensure!(
                n == 32768 && workers == 20 && request["batch_size"] == 256 && request["iter"] == 0,
                "unexpected reduction schedule"
            );
            ensure!(
                integrand.get_settings().integrator.seed == seed
                    && integrand.get_settings().integrator.n_start == n
                    && integrand.get_settings().integrator.n_max == n
                    && integrand.get_settings().integrator.n_increase == 0,
                "failed workspace settings differ from original schedule"
            );
            integrand.warm_up(model)?;
            report["inventory"] =
                inventory(integrand, &manifest, request["mode"].as_str().unwrap())?;
            let grid = integrand.create_grid();
            let per_worker = (n - 1) / workers + 1;
            let matched = AtomicBool::new(false);
            let expected_error = request["expected_error"].as_str().unwrap();
            let rows = std::thread::scope(|scope| -> Result<Vec<Value>> {
                let mut handles = Vec::new();
                for worker_id in 0..workers {
                    // CoreIterationState clones the warmed integrand/grid; it does
                    // not warm a new worker or consume timing-probe warmup draws.
                    let mut worker = integrand.clone();
                    let mut sampling_grid = grid.clone_without_samples();
                    let skipped = per_worker * worker_id;
                    let assigned = if worker_id + 1 == workers {
                        n - skipped
                    } else {
                        per_worker
                    };
                    let matched = &matched;
                    handles.push(std::thread::Builder::new().stack_size(128 * 1024 * 1024).spawn_scoped(scope, move || -> Result<Value> {
                        let mut rng = MonteCarloRng::new(slot_seed, 0);
                        for _ in 0..skipped {
                            let mut sample = Sample::new();
                            sampling_grid.sample(&mut rng, &mut sample);
                        }
                        let mut evaluated = 0;
                        let mut failure = None;
                        for local in 0..assigned {
                            if matched.load(Ordering::Relaxed) { break; }
                            let mut sample = Sample::new();
                            sampling_grid.sample(&mut rng, &mut sample);
                            // The existing raw source owner receives the same
                            // Physical target, iter0 and frozen zero max_eval as Integrate.
                            let result = worker.evaluate_samples_raw(EvaluationTarget::Physical(model), std::slice::from_ref(&sample), 0, false, true, Complex::new_zero());
                            evaluated += 1;
                            if let Err(error) = result {
                                let error = format!("{error:#}");
                                let exact_error_match = error == expected_error;
                                if exact_error_match { matched.store(true, Ordering::Relaxed); }
                                let mut path = Vec::new();
                                let mut leaf = &sample;
                                while let Sample::Discrete(_, id, Some(next)) = leaf { path.push(*id); leaf = next; }
                                let Sample::Continuous(_, cube) = leaf else { return Err(eyre!("failed source has no continuous leaf")); };
                                ensure!(path.len() == 2 && path[0] == 0, "unexpected failed source path");
                                let canonical = (|| -> Result<Value> {
                                    let ProcessIntegrand::CrossSection(process) = &worker else { return Err(eyre!("cross section required")); };
                                    let coordinates = cube.iter().map(|x|ArbPrec::from_f64_exact_binary(x.0)).collect::<Vec<_>>();
                                    let mapped = process.data.graph_terms[0].sampling_setup().sampling_bridge::<ArbPrec>()?.forward(SamplingChannelId(path[1]), &coordinates)?;
                                    approach_map(&mapped)
                                })();
                                let row = json!({"worker":worker_id,"worker_local_index":local,"source_index":skipped+local,"production_batch_round":local/256,"index_in_batch":local%256,
                                    "seed":seed,"slot_seed":slot_seed,"rng_stream":0,"complete_sample":sample,"source_path":path,
                                    "cube_binary64_bits":cube.iter().map(|x|format!("{:016x}",x.0.to_bits())).collect::<Vec<_>>(),
                                    "error":error,"exact_original_error_match":exact_error_match,
                                    "canonical_map":match canonical { Ok(value)=>value, Err(error)=>json!({"error":format!("{error:#}")}) },
                                    "scope":"original physical raw API failure; following bridge evaluation is read-only geometry evidence and does not repeat/replace the physical overlap solve"});
                                fs::write(output.join(format!("failure_worker{worker_id}.json")), serde_json::to_string_pretty(&row)?)?;
                                failure = Some(row);
                                break;
                            }
                        }
                        Ok(json!({"worker":worker_id,"skipped":skipped,"assigned":assigned,"evaluated":evaluated,
                            "complete_range":evaluated==assigned,"cancelled_after_match":evaluated<assigned && failure.is_none(),"failure":failure}))
                    })?);
                }
                handles
                    .into_iter()
                    .map(|handle| {
                        handle
                            .join()
                            .map_err(|_| eyre!("source reduction worker panicked"))?
                    })
                    .collect()
            })?;
            report["workers"] = json!(rows);
            report["original_error_reproduced"] = json!(matched.load(Ordering::Relaxed));
            ensure!(
                matched.load(Ordering::Relaxed),
                "original source error not reproduced; completed/other-failure ranges retained"
            );
            Ok(())
        })();
        let after = state_hashes(state_path)?;
        let mut inputs_unchanged = true;
        for (path, expected) in &inputs {
            let hash = Command::new("sha256sum").arg(path).output()?;
            inputs_unchanged &= hash.status.success()
                && String::from_utf8(hash.stdout)?.split_whitespace().next()
                    == Some(expected.as_str());
        }
        report["state_after"] = json!(after);
        report["saved_state_unchanged"] = json!(before == after);
        report["inputs_unchanged"] = json!(inputs_unchanged);
        report["elapsed_seconds"] = json!(started.elapsed().as_secs_f64());
        report["error"] = execution
            .as_ref()
            .err()
            .map(|error| json!(format!("{error:#}")))
            .unwrap_or(Value::Null);
        report["status"] = json!(
            if execution.is_ok() && before == after && inputs_unchanged {
                "completed_reproducer"
            } else {
                "failed_reproducer"
            }
        );
        fs::write(
            output.join("summary.json"),
            serde_json::to_string_pretty(&report)?,
        )?;
        ensure!(
            before == after && inputs_unchanged,
            "immutable reduction input changed"
        );
        execution
    }
}

fn main() -> color_eyre::Result<()> {
    std::thread::Builder::new()
        .stack_size(128 * 1024 * 1024)
        .spawn(client::run_source_reduction)?
        .join()
        .map_err(|_| color_eyre::eyre::eyre!("source reduction worker panicked"))?
}

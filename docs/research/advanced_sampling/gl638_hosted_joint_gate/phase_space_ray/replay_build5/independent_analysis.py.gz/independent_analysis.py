"""Compare completed retained-point reports only; no GammaLoop evaluation."""
import hashlib
import json
import math
from decimal import Decimal, getcontext
from pathlib import Path
import struct

getcontext().prec = 650
packet = Path('/tmp/gl638-hosted-joint-gate')
old = packet / 'results-reference-point-3363'
new = packet / 'results-reference-point-3363-build5'
run_path = packet / 'reference-point-3363-build5-run.json'
read = lambda path: json.loads(path.read_text())
run = read(run_path)
assert run['returncode'] == 0 and run['elapsed_seconds'] > 0
assert run['argv'][2:] == [str(new), 'cuts,cuts_joint', 'reference-point', '1', '1', '1', '1337']
modes = ['cuts', 'cuts_joint']
before = {m: read(old / f'{m}.json') for m in modes}
after = {m: read(new / f'{m}.json') for m in modes}
left, right = [after[m]['reference_point'] for m in modes]
cube = []
for base in [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37]:
    index, fraction, value = 3363, 1.0, 0.0
    while index:
        fraction /= base
        value += (index % base) * fraction
        index //= base
    cube.append(value)
bits = [f'{struct.unpack("Q", struct.pack("d", x))[0]:016x}' for x in cube]
for report in list(before.values()) + list(after.values()):
    point = report['reference_point']
    assert point['halton_index'] == 3363 and point['cube'] == cube
    assert point['cube_binary64_bits'] == bits and point['cube_arb'] == left['cube_arb']
assert left['generator_foreign_inverse_rows'] == right['generator_foreign_inverse_rows'][:6]
for mode in modes:
    a, b = before[mode], after[mode]
    assert a['inventory'] == b['inventory'] and b['error'] is None
    assert a['reference_point']['summed_sample'] == b['reference_point']['summed_sample']
assert all(after['cuts']['inventory'][k] == v for k, v in after['cuts_joint']['inventory'].items() if k != 'channels')
assert len(after['cuts_joint']['inventory']['production_orientation_keys']) == 936
assert len(after['cuts_joint']['inventory']['cuts']) == 6
selected = right['selected_reference']
assert selected['sample'] == before['cuts_joint']['reference_point']['selected_reference']['sample']
for result in [left['summed_reference'], right['summed_reference'], selected['result']]:
    assert result['status'] == 'ok'
    report = result['report']
    assert report['finite_points'] == report['points'] == 1
    assert all(not isinstance(v, float) or math.isfinite(v) for v in report.values())
for result in [before['cuts_joint']['reference_point']['summed_reference'], before['cuts_joint']['reference_point']['selected_reference']['result']]:
    assert result['status'] == 'error'
rows = left['generator_foreign_inverse_rows'] + right['generator_foreign_inverse_rows']
assert len(rows) == 13
for row in rows:
    assert not row.get('forward_error')
    assert row['foreign_id'] == 1 and row['foreign_name'] == 'lu_cut_1'
    assert row['foreign_inverse']['status'] == 'ok'
    for mapped in [row['forward'], row['foreign_inverse']['map']]:
        assert len(mapped['point']) == len(mapped['coordinates']) == 12
        assert all(Decimal(v).is_finite() for field in ['point', 'coordinates'] for v in mapped[field])
        assert all(Decimal(mapped[field]).is_finite() and Decimal(mapped[field]) > 0 for field in ['jacobian', 'inverse_jacobian'])
        assert Decimal(mapped['residual']).is_finite()
states = [read(folder / f'state_{when}.json') for folder in [old, new] for when in ['before', 'after']]
assert all(s == states[0] and len(s) == 35 for s in states)
old_rows = before['cuts_joint']['reference_point']['generator_foreign_inverse_rows']
assert old_rows[6]['forward'] == right['generator_foreign_inverse_rows'][6]['forward']
comparison = []
for a, b in zip(old_rows, right['generator_foreign_inverse_rows']):
    af, bf = a['forward'], b['forward']
    entry = {
        'generator': b['generator_name'],
        'forward_record_exact': af == bf,
        'forward_point_exact': af['point'] == bf['point'],
        'max_absolute_point_difference_GeV': str(max(abs(Decimal(x)-Decimal(y)) for x,y in zip(af['point'], bf['point']))),
        'relative_forward_J_difference': str(abs(Decimal(bf['jacobian'])/Decimal(af['jacobian'])-1)),
        'old_inverse_status': a['foreign_inverse']['status'],
        'new_inverse_status': b['foreign_inverse']['status'],
        'new_inverse_residual': b['foreign_inverse']['map']['residual'],
    }
    if a['foreign_inverse']['status'] == 'ok':
        entry['inverse_record_exact'] = a['foreign_inverse'] == b['foreign_inverse']
        entry['relative_inverse_J_difference'] = str(abs(Decimal(b['foreign_inverse']['map']['jacobian'])/Decimal(a['foreign_inverse']['map']['jacobian'])-1))
    if b['generator_id'] == 1:
        entry['own_forward_J_times_inverse_q_error'] = str(abs(Decimal(bf['jacobian'])*Decimal(b['foreign_inverse']['map']['inverse_jacobian'])-1))
    comparison.append(entry)
inputs = [run_path] + [d / f'{m}.json' for d in [old,new] for m in modes] + [d / f'state_{s}.json' for d in [old,new] for s in ['before','after']]
summary = {
    'status': 'passed',
    'scope': 'Retained Halton3363 binder/source regression; one point is not normalization, physical acceptance or a global root guarantee. Reduced bridge denominator remains discarded.',
    'run': run,
    'counts': {'forward_successes':13, 'foreign_cut1_inverse_successes':13, 'foreign_inverse_failures':0, 'full_summed_reference_successes':2, 'full_selected_reference_successes':1},
    'within_build_common_rows_exact': 6,
    'full936_six_cuts_and_CT_inventory_unchanged': True,
    'all35_state_hashes_unchanged': True,
    'halton_bits_and_original_nested_samples_unchanged': True,
    'joint_forward_full_record_unchanged': True,
    'comparison_to_build4': comparison,
    'summed_reference_reports': {m: after[m]['reference_point']['summed_reference']['report'] for m in modes},
    'selected_reference_report': selected['result']['report'],
    'selected_zero_scope': 'Gaussian selected value is finite zero at this very large point; this validates completed preparation, not a nonzero physical result.',
    'input_sha256': {str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in inputs},
    'analysis_script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
}
(new / 'independent_matrix_analysis.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({'status':summary['status'], 'counts':summary['counts'], 'comparison':[{'generator':r['generator'],'point_exact':r['forward_point_exact'],'forward_J_relative':float(r['relative_forward_J_difference']),'inverse_J_relative':float(r.get('relative_inverse_J_difference','0'))} for r in comparison]}, indent=2))

"""Bounded independent Decimal checks on retained soft artifacts, no state/physics."""
import json, hashlib
from decimal import Decimal as D, getcontext
from pathlib import Path
getcontext().prec=420
root=Path('/tmp/gl638-hosted-joint-gate')
folder=root/'results-soft-replacement-local-build7'
ap=root/'soft-replacement-local-analysis-final-qualified-build7/analysis.json'
a=json.loads(ap.read_text());checks=[];evidence=[]
points={(p['mode'],p['name']):p for p in a['points']}
curves={(c['mode'],c['anchor'],c['soft_mode']):c for c in a['curves']}
modes=['cuts','cuts_combined_joint','cuts_replaced_joint','cuts_soft']
inventories={m:json.loads((folder/(m+'.json')).read_text())['inventory'] for m in modes}
def check(name,passed): checks.append({'name':name,'passed':bool(passed)})
def close(v,w,tol=D('1e-370')):
 v,w=D(v),D(w);return abs(v-w)<=tol*max(abs(v),abs(w),D('1e-350'))
def norm(z):return sum(t*t for t in z).sqrt()
def slope(x,y):
 x=[t.ln() for t in x];y=[abs(t).ln() for t in y];xm=sum(x)/len(x);ym=sum(y)/len(y)
 return -sum((p-xm)*(q-ym) for p,q in zip(x,y))/sum((p-xm)**2 for p in x)
def retained(m,n):return json.loads((folder/(m+'.'+n+'.approach.json')).read_text())
def calc(m,n):
 r=retained(m,n);e=next(v['result']['evaluation'] for v in r['source_physics'] if v['forced_arb'])
 v=[D(t) for t in r['actual_forward']['raw_coordinates']];basis=inventories[m]['generation_basis']
 assert basis['loop_edges']==[3,4,7,10]
 soft=[]
 for edge in [13,14]:
  sig=basis['edge_signatures'][edge];assert sig['external'] in ([1,1],[-1,-1])
  p=[sum(D(c)*v[3*i+j] for i,c in enumerate(sig['internal'])) for j in range(3)]
  soft.append(norm(p))
 limit=r['case_definition']['soft_mode'];rad=norm(soft) if limit=='double' else soft[0 if limit=='single13' else 1]
 Y=D(e['complete_sample_estimator']['re']);Jw=D(r['actual_forward']['selected_J_times_w']);W=D(r['grid_probes']['total']);q=D(r['actual_forward']['raw_map_density_sum'])/W;F=Y/(Jw*W)
 assert W==len(inventories[m]['channels'])
 p=points[m,n]
 check(m+':'+n+':native quantities',all([close(rad,p['actual_forward_lambda_GeV']),close(Y,p['source_Y']['re']),close(F,p['source_F']['re']),close(q,p['effective_proposal_density'])]))
 return r,e,rad,Y,F,q
# All retained source files are immutable and complete; this is not a repetition
# of the existing 15,050 physical/factor checks.
source_files=[p for p in a['input_sha256'] if p.endswith('.approach.json')]
check('120 complete retained source hashes',len(source_files)==120 and all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==a['input_sha256'][p] and json.loads(Path(p).read_text())['complete'] for p in source_files))
for anchor in ['real_composed','real_ordinary']:
 for limit in ['single13','single14','double']:
  # One complete last-three-radius series per limit/anchor, with the soft
  # density control. Other two catalogues are checked at the smallest radius.
  for mode in ['cuts','cuts_soft']:
   rows=[calc(mode,f'{anchor}_{limit}_r{i}') for i in [2,3,4]]
   c=curves[mode,anchor,limit];s=slope([r[2] for r in rows],[r[5] for r in rows])
   check(f'{mode}:{anchor}:{limit}:density exponent',abs(s-D(str(c['density_beta_last3'])))<D('2e-13'))
   ev={'mode':mode,'anchor':anchor,'limit':limit,'density_exponent':str(s)}
   if limit!='double':
    p=slope([r[2] for r in rows],[r[4] for r in rows]);b=slope([r[2] for r in rows],[r[3] for r in rows]);ma=3-p;mv=3-2*p+s
    check(f'{mode}:{anchor}:{limit}:real slopes and margins',c['fit_eligible'] and all(abs(x-D(str(c[k])))<D('2e-13') for x,k in [(p,'beta_abs_real_F_last3'),(b,'beta_abs_real_Y_last3'),(ma,'absolute_radial_integrability_margin'),(mv,'second_moment_radial_integrability_margin')]) and abs(b-(p-s))<D('1e-280'))
    adj=[slope([x[2] for x in rows[i:i+2]],[x[4] for x in rows[i:i+2]]) for i in [0,1]]
    check(f'{mode}:{anchor}:{limit}:adjacent slopes',all(abs(x-D(str(y)))<D('2e-13') for x,y in zip(adj,c['adjacent_beta_abs_real_F'][-2:])))
    ev.update(p=str(p),betaY=str(b),absolute_margin=str(ma),variance_margin=str(mv),last_two_adjacent_p=list(map(str,adj)))
   else:
    r,e,rad,Y,F,q=rows[-1];terms=[]
    for event in e['events']:
     ct=event['threshold_counterterms'];terms.append(norm([D(ct['original'][k]) for k in ['re','im']]))
     terms.extend(norm([D(v['weighted'][k]) for k in ['re','im']]) for v in ct['components'])
    eps=D(2)**-999;scale=sum(terms);ratio=abs(Y)/(eps*scale)
    check(f'{mode}:{anchor}:{limit}:unresolved',not c['fit_eligible'] and 'beta_abs_real_F_last3' not in c and abs(Y)<32*len(terms)*eps*scale and close(ratio,points[mode,r['name']]['source_physics_real_resolution']['real_to_epsilon_term_scale']))
    ev.update(real_to_epsilon_terms=str(ratio),term_count=len(terms),suppress_fit=True)
   evidence.append(ev)
  name=f'{anchor}_{limit}_r4';rows={m:calc(m,name) for m in modes}
  check(name+':exact same forwarded points',all(r[0]['actual_forward']['raw_coordinates']==rows['cuts'][0]['actual_forward']['raw_coordinates'] for r in rows.values()))
  base,add,replace,soft=[rows[m] for m in modes]
  check(name+':additive law and full factor',base[0]['actual_forward']['raw_map_density_sum']==add[0]['actual_forward']['raw_map_density_sum'] and abs(add[3]/base[3]-D(7)/6)<D('1e-295'))
  if limit!='double':
   check(name+':replacement loss and soft suppression',abs(replace[3]/add[3])>1 and abs(soft[3]/base[3])<D('1e-15'))
   evidence.append({'name':name,'additive_over_cuts':str(add[3]/base[3]),'replacement_over_additive':str(replace[3]/add[3]),'soft_over_cuts':str(soft[3]/base[3])})
# Final qualifications must apply throughout, not just in our sampled series.
check('all8 double real curves suppressed',sum(c['soft_mode']=='double' and not c['fit_eligible'] and 'beta_abs_real_F_last3' not in c for c in a['curves'])==8)
check('all40 double real ratios suppressed',all(c['complete_real_Y_ratio'] is None and not c['real_ratio_resolved'] for c in a['matched_comparisons'] if '_double_' in c['case']))
check('joint inverse zero at all30 cases in both catalogues',all(all(D(v)==0 for v,label in zip(p['forward_partition_weights'],p['raw_channel_labels']) if 'joint' in label.lower()) for p in a['points'] if p['mode'] in ['cuts_combined_joint','cuts_replaced_joint']))
# Independently reproduce the sole arithmetic-only factor miss. The new
# allowance is decimal display uncertainty; the arithmetic multiplier stays16.
r=retained('cuts_combined_joint','real_ordinary_single14_r1');e=next(v['result']['evaluation'] for v in r['source_physics'] if not v['forced_arb']);assert e['precision']=='Quad'
f=[D(e['integrand_result'][k]) for k in ['re','im']];Y=[D(e['complete_sample_estimator'][k]) for k in ['re','im']];J=D(e['parameterization_jacobian']);W=D(e['integrator_weight']);expected=[v*J*W for v in f]
def half_place(x):return D(5)*D(10)**(x.as_tuple().exponent-1) if x else D(0)
error=norm([x-y for x,y in zip(Y,expected)]);arithmetic=16*(D(2)**-105)*max(norm(Y),norm(expected));fmt=norm([(abs(v)+half_place(v))*(abs(J)+half_place(J))*(abs(W)+half_place(W))-abs(v*J*W)+half_place(y) for v,y in zip(f,Y)])
check('Quad16epsilon preserved and formatting propagation passes',error>arithmetic and error<=arithmetic+fmt)
evidence.append({'formatting_case':'cuts_combined_joint:real_ordinary_single14_r1:source_physics:Quad','error':str(error),'arithmetic16epsilon':str(arithmetic),'independent_decimal_half_place_bound':str(fmt),'error_over_combined_bound':str(error/(arithmetic+fmt))})
summary={'passed':all(c['passed'] for c in checks),'checks':checks,'checks_passed':sum(c['passed'] for c in checks),'checks_failed':[c for c in checks if not c['passed']],'analysis':{'path':str(ap),'sha256':hashlib.sha256(ap.read_bytes()).hexdigest()},'decimal_precision':420,'scope':'Independent bounded 6 approach-series spot audit and matched smallest-radius catalogue comparisons; no Gamma/state/build; does not duplicate existing15050checks or prove angular-uniform/global convergence. Full source hash coverage only.','evidence':evidence,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
Path(__file__).with_name('summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:summary[k] for k in ['passed','checks_passed','checks_failed']},indent=2))
for v in evidence:
 if 'density_exponent' in v:print(v['mode'],v['anchor'],v['limit'],{k:float(D(v[k])) for k in ['density_exponent','p','betaY','absolute_margin','variance_margin','real_to_epsilon_terms'] if k in v})

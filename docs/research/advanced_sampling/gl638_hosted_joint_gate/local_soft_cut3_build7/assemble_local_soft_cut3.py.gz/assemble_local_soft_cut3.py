"""Extend the existing lossless archive convention; no Gamma calls or input writes."""
import gzip, hashlib, json, os
from pathlib import Path
packet=Path('/tmp/gl638-hosted-joint-gate')
draft=Path('/tmp/gl638-soft-cut3-draft/archive')
archive=Path('/common/dev/gammaloop_ir_safe_thresholds/docs/research/advanced_sampling/gl638_hosted_joint_gate')
intended=archive/'local_soft_cut3_build7'
known={}; entries={}
for index in sorted(archive.rglob('artifact_hashes*.json')):
    data=json.loads(index.read_text())
    if not isinstance(data,dict): continue
    for value in data.values():
        if not isinstance(value,dict) or not {'stored_path','sha256_uncompressed','bytes_uncompressed'}<=value.keys(): continue
        path=(index.parent/value['stored_path']).resolve()
        if path.is_file(): known.setdefault((value['sha256_uncompressed'],value['bytes_uncompressed']),path)

def store(source,name):
    source=Path(source); raw=source.read_bytes(); key=hashlib.sha256(raw).hexdigest(),len(raw)
    if key not in known:
        destination=intended/(name+'.gz'); target=draft/(name+'.gz'); target.parent.mkdir(parents=True,exist_ok=True)
        target.write_bytes(gzip.compress(raw,mtime=0)); known[key]=destination
    entries[name]={'sha256_uncompressed':key[0],'bytes_uncompressed':key[1],'stored_path':os.path.relpath(known[key],intended),'original_path':str(source)}


for directory,name in [('results-soft-replacement-local-build7','soft/results'),('results-cut3-right-local-build7','cut3/results'),('soft-replacement-local-analysis-final-qualified-build7','soft/analysis'),('soft-replacement-local-analysis-qualified-build7','diagnostics/pre_unresolved_ratio_qualification'),('cut3-right-local-analysis-final-build7','cut3/analysis'),('soft-replacement-local-analysis-build7','diagnostics/initial_ieee_quad_assumption'),('soft-replacement-local-analysis-final-build7','diagnostics/precision_unit_corrected')]:
    for path in sorted((packet/directory).iterdir()):
        if path.is_file():store(path,name+'/'+path.name)
for stem,owner in [('soft-replacement-local','soft'),('cut3-right-local','cut3')]:
    for source,name in [(packet/f'{stem}-build7-run.json','run.json'),(packet/f'results-{stem}-build7.log','run.log'),(packet/f'results-{stem}-build7.resources.txt','resources.txt')]:store(source,owner+'/execution/'+name)
for name in ['gate_soft_local.rs','gate-soft-local-build7.build.json']:
    store(packet/'drivers'/name,'drivers/'+name)
for name in ['audit_physical.py','analyze_local_raw_cases.py','analyze_local_raw_cases_cut3_frozen.py','analyze_local_raw_cases_initial.py','analyze_local_raw_cases_before_quad_correction.py','analyze_local_raw_cases_before_real_resolution.py','analyze_local_raw_cases_before_formatting_allowance.py','analyze_local_raw_cases_before_unresolved_ratio.py','manifest-soft-replacement-local-build7.json','manifest-cut3-right-local-build7.json','soft-replacement-local-build7-commands.json','CUT3_RIGHT_LOCAL_REAL_RESULTS.md']:
    store(packet/name,'protocol/'+name)
for part in ['soft-local','cut3-right','leading-real-soft-cut3']:
    for path in sorted((Path('/tmp/gl638-physics-comparison')/part).rglob('*')):
        if path.is_file():store(path,'cases/'+part+'/'+str(path.relative_to(Path('/tmp/gl638-physics-comparison')/part)))
for manifest_name in ['manifest-soft-replacement-local-build7.json','manifest-cut3-right-local-build7.json']:
    manifest=json.loads((packet/manifest_name).read_text())
    for mode,path in manifest['cards'].items():store(path,'cards/'+mode+'.toml')
    for key in ['candidate_build_record','source_candidate_patch']:
        path=Path(manifest[key]);store(path,'build/'+path.name)
soft=json.loads(Path('/tmp/gl638-physics-comparison/soft-local/raw_soft_cases.json').read_text())
for direction in soft['directions']:store(direction['source'],'anchors/'+Path(direction['source']).name)
store(soft['input_registry']['path'],'anchors/'+Path(soft['input_registry']['path']).name)
cut3=json.loads(Path('/tmp/gl638-physics-comparison/cut3-right/raw_cut3_cases.json').read_text())
for path in cut3['geometry_provenance']:store(path,'anchors/'+Path(path).parent.name+'/'+Path(path).name)
correction=json.loads((packet/'soft-replacement-local-analysis-final-qualified-build7/diagnostic_corrections.json').read_text())
for path in correction['references_sha256']:
    if '/numerica/' in path:store(path,'diagnostics/formatting_owner/'+Path(path).name)
    if path.endswith('optimized-build7.jsonl'):store(path,'build/'+Path(path).name)
store(Path('/tmp/gl638-soft-cut3-draft/GL638_SOFT_AND_CUT3_LOCAL_REAL.md'),'GL638_SOFT_AND_CUT3_LOCAL_REAL.md')
store(Path(__file__),'assemble_local_soft_cut3.py')
draft.mkdir(parents=True,exist_ok=True)
(draft/'artifact_hashes.json').write_text(json.dumps(entries,indent=2)+'\n')
for value in entries.values():
    path=(intended/value['stored_path']).resolve()
    if path.is_relative_to(intended):path=draft/path.relative_to(intended)
    raw=gzip.decompress(path.read_bytes()) if path.suffix=='.gz' else path.read_bytes()
    assert hashlib.sha256(raw).hexdigest()==value['sha256_uncompressed'] and len(raw)==value['bytes_uncompressed']
provenance={'status':'completed_local_diagnostics_lossless_archive','purpose':'Real-only bounded soft/replacement and supported Cut3-channel local comparison; no new Monte Carlo samples or historical selection change','controls':{'soft_rows':120,'soft_native_calls':480,'soft_checks':15050,'cut3_rows':21,'cut3_native_calls':84,'cut3_checks':2681,'failed_or_missing_rows':0,'double_soft_real_curves_suppressed':8,'arithmetic_only_formatting_miss_retained':1},'historical_diagnostics':'Initial arithmetic assumptions and unqualified real-ratio drafts are retained as superseded diagnostics; only soft/analysis is the final qualified analysis. No real slopes or ratios are inferred from unresolved double-soft signals.','leading_cards_status':'Static eight/nine-channel power2 cards retain soft and Cut1; all new combined-catalogue native/local/reference gates pending, no statistical selection.','scope':'Actual common forwarded points, complete original Sample/grid/map factors, real d3 finite-direction evidence; d6 real at numerical floor. New catalogue normalization and integrated variance comparison remain pending. No global maximum bound.','archive_convention':'Existing lossless gzip convention with exact original uncompressed hashes/sizes; byte-identical files reference prior immutable records. No state payload, executable or compiled library copied. Original result directories remain unchanged.','records':len(entries),'stored_gzip_files':len(list(draft.rglob('*.gz'))),'stored_bytes':sum(p.stat().st_size for p in draft.rglob('*.gz'))}
(draft/'provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
print(json.dumps(provenance))

# Bounded local real-weight analysis

Expected 120 rows; retained 120; complete 120; failures 0; missing 0.
Native checks: 15050/15050 pass.

No slope is fitted across a missing/failed branch. Positive directional radial margins are evidence only along these finite rays, not a global finite-variance proof.

| Mode | Anchor | Soft limit | beta abs Re F | beta q | beta abs Re Y | d-p | d-2p+s |
|---|---|---|---:|---:|---:|---:|---:|
| cuts | real_composed | single13 | 1.03809 | -7.45757e-08 | 1.03809 | 1.96191 | 0.923828 |
| cuts | real_composed | single14 | 0.991574 | -2.73848e-08 | 0.991574 | 2.00843 | 1.01685 |
| cuts | real_composed | double | no fit | real signal at the native summation floor | | | |
| cuts | real_ordinary | single13 | 1.17704 | 5.41582e-09 | 1.17704 | 1.82296 | 0.645924 |
| cuts | real_ordinary | single14 | 0.892863 | -7.70316e-08 | 0.892863 | 2.10714 | 1.21427 |
| cuts | real_ordinary | double | no fit | real signal at the native summation floor | | | |
| cuts_combined_joint | real_composed | single13 | 1.03809 | -7.45757e-08 | 1.03809 | 1.96191 | 0.923828 |
| cuts_combined_joint | real_composed | single14 | 0.991574 | -2.73848e-08 | 0.991574 | 2.00843 | 1.01685 |
| cuts_combined_joint | real_composed | double | no fit | real signal at the native summation floor | | | |
| cuts_combined_joint | real_ordinary | single13 | 1.17704 | 5.41582e-09 | 1.17704 | 1.82296 | 0.645924 |
| cuts_combined_joint | real_ordinary | single14 | 0.892863 | -7.70316e-08 | 0.892863 | 2.10714 | 1.21427 |
| cuts_combined_joint | real_ordinary | double | no fit | real signal at the native summation floor | | | |
| cuts_replaced_joint | real_composed | single13 | 1.03809 | -7.5e-08 | 1.03809 | 1.96191 | 0.923828 |
| cuts_replaced_joint | real_composed | single14 | 0.991574 | -2.80773e-08 | 0.991574 | 2.00843 | 1.01685 |
| cuts_replaced_joint | real_composed | double | no fit | real signal at the native summation floor | | | |
| cuts_replaced_joint | real_ordinary | single13 | 1.17704 | 4.21683e-09 | 1.17704 | 1.82296 | 0.645924 |
| cuts_replaced_joint | real_ordinary | single14 | 0.892863 | -7.71273e-08 | 0.892863 | 2.10714 | 1.21427 |
| cuts_replaced_joint | real_ordinary | double | no fit | real signal at the native summation floor | | | |
| cuts_soft | real_composed | single13 | 1.03809 | 2 | -0.961914 | 1.96191 | 2.92383 |
| cuts_soft | real_composed | single14 | 0.991574 | 2 | -1.00843 | 2.00843 | 3.01685 |
| cuts_soft | real_composed | double | no fit | real signal at the native summation floor | | | |
| cuts_soft | real_ordinary | single13 | 1.17704 | 2 | -0.822962 | 1.82296 | 2.64592 |
| cuts_soft | real_ordinary | single14 | 0.892863 | 2 | -1.10714 | 2.10714 | 3.21427 |
| cuts_soft | real_ordinary | double | no fit | real signal at the native summation floor | | | |

Matched common-raw-point density and actual-forward real-weight ratios:

| Case | Candidate / control | raw qsum ratio | raw qeff ratio | actual real Y ratio |
|---|---|---:|---:|---:|
| real_composed_single13_r0 | cuts_combined_joint/cuts | 1 | 0.85714286 | 1.1666667 |
| real_composed_single13_r0 | cuts_replaced_joint/cuts | 0.83651266 | 0.83651266 | 1.1954392 |
| real_composed_single13_r0 | cuts_replaced_joint/cuts_combined_joint | 0.83651266 | 0.97593144 | 1.0246621 |
| real_composed_single13_r0 | cuts_soft/cuts | 93289.078 | 79962.067 | 1.250593e-05 |
| real_composed_single13_r1 | cuts_combined_joint/cuts | 1 | 0.85714286 | 1.1666667 |
| real_composed_single13_r1 | cuts_replaced_joint/cuts | 0.83648089 | 0.83648089 | 1.1954846 |
| real_composed_single13_r1 | cuts_replaced_joint/cuts_combined_joint | 0.83648089 | 0.97589438 | 1.0247011 |
| real_composed_single13_r1 | cuts_soft/cuts | 9.4668237e+08 | 8.1144203e+08 | 1.2323739e-09 |
| real_composed_single13_r2 | cuts_combined_joint/cuts | 1 | 0.85714286 | 1.1666667 |
| real_composed_single13_r2 | cuts_replaced_joint/cuts | 0.83648057 | 0.83648057 | 1.195485 |
| real_composed_single13_r2 | cuts_replaced_joint/cuts_combined_joint | 0.83648057 | 0.975894 | 1.0247015 |
| real_composed_single13_r2 | cuts_soft/cuts | 9.4682141e+12 | 8.1156121e+12 | 1.2321929e-13 |
| real_composed_single13_r3 | cuts_combined_joint/cuts | 1 | 0.85714286 | 1.1666667 |
| real_composed_single13_r3 | cuts_replaced_joint/cuts | 0.83648057 | 0.83648057 | 1.195485 |
| real_composed_single13_r3 | cuts_replaced_joint/cuts_combined_joint | 0.83648057 | 0.975894 | 1.0247015 |
| real_composed_single13_r3 | cuts_soft/cuts | 9.4682281e+16 | 8.1156241e+16 | 1.2321912e-17 |
| real_composed_single13_r4 | cuts_combined_joint/cuts | 1 | 0.85714286 | 1.1666667 |
| real_composed_single13_r4 | cuts_replaced_joint/cuts | 0.83648057 | 0.83648057 | 1.195485 |
| real_composed_single13_r4 | cuts_replaced_joint/cuts_combined_joint | 0.83648057 | 0.975894 | 1.0247015 |
| real_composed_single13_r4 | cuts_soft/cuts | 9.468267e+20 | 8.1156574e+20 | 1.2321869e-21 |
| real_composed_single14_r0 | cuts_combined_joint/cuts | 1 | 0.85714286 | 1.1666667 |
| real_composed_single14_r0 | cuts_replaced_joint/cuts | 0.82340899 | 0.82340899 | 1.2144633 |
| real_composed_single14_r0 | cuts_replaced_joint/cuts_combined_joint | 0.82340899 | 0.96064382 | 1.0409685 |
| real_composed_single14_r0 | cuts_soft/cuts | 5257334.2 | 4506286.5 | 2.2191221e-07 |
| real_composed_single14_r1 | cuts_combined_joint/cuts | 1 | 0.85714286 | 1.1666667 |
| real_composed_single14_r1 | cuts_replaced_joint/cuts | 0.82335709 | 0.82335709 | 1.2145399 |
| real_composed_single14_r1 | cuts_replaced_joint/cuts_combined_joint | 0.82335709 | 0.96058327 | 1.0410342 |
| real_composed_single14_r1 | cuts_soft/cuts | 5.3052733e+10 | 4.5473771e+10 | 2.1990699e-11 |
| real_composed_single14_r2 | cuts_combined_joint/cuts | 1 | 0.85714286 | 1.1666667 |
| real_composed_single14_r2 | cuts_replaced_joint/cuts | 0.82335657 | 0.82335657 | 1.2145406 |
| real_composed_single14_r2 | cuts_replaced_joint/cuts_combined_joint | 0.82335657 | 0.96058266 | 1.0410348 |
| real_composed_single14_r2 | cuts_soft/cuts | 5.3057559e+14 | 4.5477908e+14 | 2.1988698e-15 |
| real_composed_single14_r3 | cuts_combined_joint/cuts | 1 | 0.85714286 | 1.1666667 |
| real_composed_single14_r3 | cuts_replaced_joint/cuts | 0.82335656 | 0.82335656 | 1.2145406 |
| real_composed_single14_r3 | cuts_replaced_joint/cuts_combined_joint | 0.82335656 | 0.96058265 | 1.0410348 |
| real_composed_single14_r3 | cuts_soft/cuts | 5.3057608e+18 | 4.547795e+18 | 2.1988679e-19 |
| real_composed_single14_r4 | cuts_combined_joint/cuts | 1 | 0.85714286 | 1.1666667 |
| real_composed_single14_r4 | cuts_replaced_joint/cuts | 0.82335656 | 0.82335656 | 1.2145406 |
| real_composed_single14_r4 | cuts_replaced_joint/cuts_combined_joint | 0.82335656 | 0.96058265 | 1.0410348 |
| real_composed_single14_r4 | cuts_soft/cuts | 5.3057825e+22 | 4.5478136e+22 | 2.1987945e-23 |
| real_composed_double_r0 | cuts_combined_joint/cuts | 1 | 0.85714286 | 1.1666667 |
| real_composed_double_r0 | cuts_replaced_joint/cuts | 0.83340772 | 0.83340772 | 1.1998929 |
| real_composed_double_r0 | cuts_replaced_joint/cuts_combined_joint | 0.83340772 | 0.97230901 | 1.0284796 |
| real_composed_double_r0 | cuts_soft/cuts | 3.8203251e+11 | 3.2745643e+11 | 3.0538413e-12 |
| real_composed_double_r1 | cuts_combined_joint/cuts | 1 | 0.85714286 | 1.1666667 |
| real_composed_double_r1 | cuts_replaced_joint/cuts | 0.83333408 | 0.83333408 | 1.1999989 |
| real_composed_double_r1 | cuts_replaced_joint/cuts_combined_joint | 0.83333408 | 0.9722231 | 1.0285705 |
| real_composed_double_r1 | cuts_soft/cuts | 3.907845e+19 | 3.3495814e+19 | 2.9854477e-20 |
| real_composed_double_r2 | cuts_combined_joint/cuts | 1 | 0.85714286 | 1.1666667 |
| real_composed_double_r2 | cuts_replaced_joint/cuts | 0.83333334 | 0.83333334 | 1.2 |
| real_composed_double_r2 | cuts_replaced_joint/cuts_combined_joint | 0.83333334 | 0.97222223 | 1.0285714 |
| real_composed_double_r2 | cuts_soft/cuts | 3.9087305e+27 | 3.3503404e+27 | 2.9847713e-28 |
| real_composed_double_r3 | cuts_combined_joint/cuts | 1 | 0.85714286 | 1.1666667 |
| real_composed_double_r3 | cuts_replaced_joint/cuts | 0.83333333 | 0.83333333 | 1.2 |
| real_composed_double_r3 | cuts_replaced_joint/cuts_combined_joint | 0.83333333 | 0.97222222 | 1.0285714 |
| real_composed_double_r3 | cuts_soft/cuts | 3.9087394e+35 | 3.350348e+35 | 2.9847657e-36 |
| real_composed_double_r4 | cuts_combined_joint/cuts | 1 | 0.85714286 | 1.1666667 |
| real_composed_double_r4 | cuts_replaced_joint/cuts | 0.83333333 | 0.83333333 | 1.2 |
| real_composed_double_r4 | cuts_replaced_joint/cuts_combined_joint | 0.83333333 | 0.97222222 | 1.0285714 |
| real_composed_double_r4 | cuts_soft/cuts | 3.9087641e+43 | 3.3503692e+43 | 2.9847611e-44 |
| real_ordinary_single13_r0 | cuts_combined_joint/cuts | 1 | 0.85714286 | 1.1666667 |
| real_ordinary_single13_r0 | cuts_replaced_joint/cuts | 0.83582284 | 0.83582284 | 1.1964258 |
| real_ordinary_single13_r0 | cuts_replaced_joint/cuts_combined_joint | 0.83582284 | 0.97512664 | 1.0255078 |
| real_ordinary_single13_r0 | cuts_soft/cuts | 405583.06 | 347642.62 | 2.8765172e-06 |
| real_ordinary_single13_r1 | cuts_combined_joint/cuts | 1 | 0.85714286 | 1.1666667 |
| real_ordinary_single13_r1 | cuts_replaced_joint/cuts | 0.83573252 | 0.83573252 | 1.1965551 |
| real_ordinary_single13_r1 | cuts_replaced_joint/cuts_combined_joint | 0.83573252 | 0.97502128 | 1.0256186 |
| real_ordinary_single13_r1 | cuts_soft/cuts | 4.0716755e+09 | 3.4900076e+09 | 2.8653233e-10 |
| real_ordinary_single13_r2 | cuts_combined_joint/cuts | 1 | 0.85714286 | 1.1666667 |
| real_ordinary_single13_r2 | cuts_replaced_joint/cuts | 0.83573161 | 0.83573161 | 1.1965564 |
| real_ordinary_single13_r2 | cuts_replaced_joint/cuts_combined_joint | 0.83573161 | 0.97502021 | 1.0256198 |
| real_ordinary_single13_r2 | cuts_soft/cuts | 4.0718348e+13 | 3.4901442e+13 | 2.8652112e-14 |
| real_ordinary_single13_r3 | cuts_combined_joint/cuts | 1 | 0.85714286 | 1.1666667 |
| real_ordinary_single13_r3 | cuts_replaced_joint/cuts | 0.8357316 | 0.8357316 | 1.1965564 |
| real_ordinary_single13_r3 | cuts_replaced_joint/cuts_combined_joint | 0.8357316 | 0.9750202 | 1.0256198 |
| real_ordinary_single13_r3 | cuts_soft/cuts | 4.0718365e+17 | 3.4901455e+17 | 2.8652099e-18 |
| real_ordinary_single13_r4 | cuts_combined_joint/cuts | 1 | 0.85714286 | 1.1666667 |
| real_ordinary_single13_r4 | cuts_replaced_joint/cuts | 0.8357316 | 0.8357316 | 1.1965564 |
| real_ordinary_single13_r4 | cuts_replaced_joint/cuts_combined_joint | 0.8357316 | 0.9750202 | 1.0256198 |
| real_ordinary_single13_r4 | cuts_soft/cuts | 4.0718146e+21 | 3.4901268e+21 | 2.8652455e-22 |
| real_ordinary_single14_r0 | cuts_combined_joint/cuts | 1 | 0.85714286 | 1.1666667 |
| real_ordinary_single14_r0 | cuts_replaced_joint/cuts | 0.83894738 | 0.83894738 | 1.1919699 |
| real_ordinary_single14_r0 | cuts_replaced_joint/cuts_combined_joint | 0.83894738 | 0.97877194 | 1.0216885 |
| real_ordinary_single14_r0 | cuts_soft/cuts | 9342856.6 | 8008162.8 | 1.2487259e-07 |
| real_ordinary_single14_r1 | cuts_combined_joint/cuts | 1 | 0.85714286 | 1.1666667 |
| real_ordinary_single14_r1 | cuts_replaced_joint/cuts | 0.83894006 | 0.83894006 | 1.1919803 |
| real_ordinary_single14_r1 | cuts_replaced_joint/cuts_combined_joint | 0.83894006 | 0.9787634 | 1.0216974 |
| real_ordinary_single14_r1 | cuts_soft/cuts | 9.4708682e+10 | 8.117887e+10 | 1.2318476e-11 |
| real_ordinary_single14_r2 | cuts_combined_joint/cuts | 1 | 0.85714286 | 1.1666667 |
| real_ordinary_single14_r2 | cuts_replaced_joint/cuts | 0.83893998 | 0.83893998 | 1.1919804 |
| real_ordinary_single14_r2 | cuts_replaced_joint/cuts_combined_joint | 0.83893998 | 0.97876332 | 1.0216975 |
| real_ordinary_single14_r2 | cuts_soft/cuts | 9.4721586e+14 | 8.1189931e+14 | 1.2316798e-15 |
| real_ordinary_single14_r3 | cuts_combined_joint/cuts | 1 | 0.85714286 | 1.1666667 |
| real_ordinary_single14_r3 | cuts_replaced_joint/cuts | 0.83893998 | 0.83893998 | 1.1919804 |
| real_ordinary_single14_r3 | cuts_replaced_joint/cuts_combined_joint | 0.83893998 | 0.97876331 | 1.0216975 |
| real_ordinary_single14_r3 | cuts_soft/cuts | 9.4721716e+18 | 8.1190042e+18 | 1.2316783e-19 |
| real_ordinary_single14_r4 | cuts_combined_joint/cuts | 1 | 0.85714286 | 1.1666667 |
| real_ordinary_single14_r4 | cuts_replaced_joint/cuts | 0.83893998 | 0.83893998 | 1.1919804 |
| real_ordinary_single14_r4 | cuts_replaced_joint/cuts_combined_joint | 0.83893998 | 0.97876331 | 1.0216975 |
| real_ordinary_single14_r4 | cuts_soft/cuts | 9.4721387e+22 | 8.118976e+22 | 1.2316664e-23 |
| real_ordinary_double_r0 | cuts_combined_joint/cuts | 1 | 0.85714286 | 1.1666667 |
| real_ordinary_double_r0 | cuts_replaced_joint/cuts | 0.83350921 | 0.83350921 | 1.1997468 |
| real_ordinary_double_r0 | cuts_replaced_joint/cuts_combined_joint | 0.83350921 | 0.97242741 | 1.0283544 |
| real_ordinary_double_r0 | cuts_soft/cuts | 2.58726e+11 | 2.2176514e+11 | 4.509275e-12 |
| real_ordinary_double_r1 | cuts_combined_joint/cuts | 1 | 0.85714286 | 1.1666667 |
| real_ordinary_double_r1 | cuts_replaced_joint/cuts | 0.8333351 | 0.8333351 | 1.1999974 |
| real_ordinary_double_r1 | cuts_replaced_joint/cuts_combined_joint | 0.8333351 | 0.97222429 | 1.0285692 |
| real_ordinary_double_r1 | cuts_soft/cuts | 2.626664e+19 | 2.2514263e+19 | 4.4416289e-20 |
| real_ordinary_double_r2 | cuts_combined_joint/cuts | 1 | 0.85714286 | 1.1666667 |
| real_ordinary_double_r2 | cuts_replaced_joint/cuts | 0.83333335 | 0.83333335 | 1.2 |
| real_ordinary_double_r2 | cuts_replaced_joint/cuts_combined_joint | 0.83333335 | 0.97222224 | 1.0285714 |
| real_ordinary_double_r2 | cuts_soft/cuts | 2.6270618e+27 | 2.2517672e+27 | 4.4409564e-28 |
| real_ordinary_double_r3 | cuts_combined_joint/cuts | 1 | 0.85714286 | 1.1666667 |
| real_ordinary_double_r3 | cuts_replaced_joint/cuts | 0.83333333 | 0.83333333 | 1.2 |
| real_ordinary_double_r3 | cuts_replaced_joint/cuts_combined_joint | 0.83333333 | 0.97222222 | 1.0285714 |
| real_ordinary_double_r3 | cuts_soft/cuts | 2.6270658e+35 | 2.2517707e+35 | 4.4409499e-36 |
| real_ordinary_double_r4 | cuts_combined_joint/cuts | 1 | 0.85714286 | 1.1666667 |
| real_ordinary_double_r4 | cuts_replaced_joint/cuts | 0.83333333 | 0.83333333 | 1.2 |
| real_ordinary_double_r4 | cuts_replaced_joint/cuts_combined_joint | 0.83333333 | 0.97222222 | 1.0285714 |
| real_ordinary_double_r4 | cuts_soft/cuts | 2.6270375e+43 | 2.2517465e+43 | 4.4409683e-44 |

Failures/support gaps and native precision/cut checks are retained in analysis.json. The exact source points, raw/forward soft distances, native cut soft energies and probability factors remain explicit. Returned event/CT weights are not multiplied by Grid weights again.

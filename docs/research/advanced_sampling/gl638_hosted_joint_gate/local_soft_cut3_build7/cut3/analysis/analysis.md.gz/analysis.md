# Bounded local real-weight analysis

Expected 21 rows; retained 21; complete 21; failures 0; missing 0.
Native checks: 2681/2681 pass.

No slope is fitted across a missing/failed branch. Positive directional radial margins are evidence only along these finite rays, not a global finite-variance proof.

| Mode | Anchor | Soft limit | beta abs Re F | beta q | beta abs Re Y | d-p | d-2p+s |
|---|---|---|---:|---:|---:|---:|---:|

Matched common-raw-point density and actual-forward real-weight ratios:

| Case | Candidate / control | raw qsum ratio | raw qeff ratio | actual real Y ratio |
|---|---|---:|---:|---:|
| shared_real_maximum | composed_cut3_p2/composed_p2 | 2.4152838 | 2.1133733 | 0.47317716 |
| shared_real_maximum | composed_p2/composed_p1 | 1 | 1 | 1 |
| cut3_sphere_minus10 | composed_cut3_p2/composed_p2 | 4.2772536 | 3.7425969 | 0.26719415 |
| cut3_sphere_minus10 | composed_p2/composed_p1 | 1 | 1 | 1 |
| cut3_sphere_minus1 | composed_cut3_p2/composed_p2 | 12.463335 | 10.905418 | 0.091697539 |
| cut3_sphere_minus1 | composed_p2/composed_p1 | 1 | 1 | 1 |
| cut3_sphere_minus0p1 | composed_cut3_p2/composed_p2 | 37.61933 | 32.916914 | 0.030379519 |
| cut3_sphere_minus0p1 | composed_p2/composed_p1 | 1 | 1 | 1 |
| cut3_sphere_0p1 | composed_cut3_p2/composed_p2 | 29.306964 | 25.643593 | 0.038996095 |
| cut3_sphere_0p1 | composed_p2/composed_p1 | 1 | 1 | 1 |
| cut3_sphere_1 | composed_cut3_p2/composed_p2 | 9.3802805 | 8.2077454 | 0.12183614 |
| cut3_sphere_1 | composed_p2/composed_p1 | 1 | 1 | 1 |
| cut3_sphere_10 | composed_cut3_p2/composed_p2 | 3.3474764 | 2.9290418 | 0.34140858 |
| cut3_sphere_10 | composed_p2/composed_p1 | 1 | 1 | 1 |

Failures/support gaps and native precision/cut checks are retained in analysis.json. The exact source points, raw/forward soft distances, native cut soft energies and probability factors remain explicit. Returned event/CT weights are not multiplied by Grid weights again.

#!/usr/bin/env python3
"""Read retained local-approach JSON only; never loads a state or calls physics."""
from pathlib import Path
from decimal import Decimal as D, getcontext
import json, math, hashlib, sys
getcontext().prec=380
from audit_physical import compare, metric
manifest_path=Path(sys.argv[1]); folder=Path(sys.argv[2]); out=Path(sys.argv[3])
assert folder.resolve() != out.resolve() and not out.exists()
manifest=json.loads(manifest_path.read_text()); summary=json.loads((folder/'summary.json').read_text())
assert summary['status'] != 'started' and summary['saved_state_unchanged']
case_source=Path(manifest['local_raw_cases']['path'])
assert hashlib.sha256(case_source.read_bytes()).hexdigest()==manifest['local_raw_cases']['sha256']
case_document=json.loads(case_source.read_text())
cases={c['name']:c for c in case_document['cases']}
assert len(cases)==len(case_document['cases'])
mode_reports={mode:json.loads((folder/(mode+'.json')).read_text()) for mode in manifest['proposal_order'] if (folder/(mode+'.json')).exists()}
inventories={mode:report['inventory'] for mode,report in mode_reports.items() if 'inventory' in report}
baseline=manifest['proposal_order'][0]
budgets={'Double':D('1e-6'),'Quad':D('1e-10'),'Arb':D('1e-12')}
# QuadFloat is DoubleFloat (106 bits), not IEEE binary128. Match the
# existing machine_epsilon owner; physical accuracy budgets above are unchanged.
eps={'Double':D(2)**-52,'Quad':D(2)**-105,'Arb':D(2)**-999}
def num(v):
 d=D(str(v));assert d.is_finite(),v;return d
def complex_(v):return (num(v['re']),num(v['im']))
def norm(v):return (v[0]*v[0]+v[1]*v[1]).sqrt()
def plus(a,b):return(a[0]+b[0],a[1]+b[1])
def minus(a,b):return(a[0]-b[0],a[1]-b[1])
def scale(v,s):return(v[0]*s,v[1]*s)
def summed(vs):
 v=(D(0),D(0))
 for a in vs:v=plus(v,a)
 return v
def relative(a,b):
 n=max(norm(a),norm(b));return norm(minus(a,b))/n if n else D(0)
def strings(v):return {'re':str(v[0]),'im':str(v[1]),'norm':str(norm(v))}
def slope(xs,ys):
 if any(y<=0 for y in ys):return None
 x=[math.log(float(a)) for a in xs];y=[math.log(float(a)) for a in ys]
 xm=sum(x)/len(x);ym=sum(y)/len(y)
 return -sum((a-xm)*(b-ym) for a,b in zip(x,y))/sum((a-xm)**2 for a in x)
checks=[]; points=[]; failures=[]; hashes={}; raw_by_mode={}; raw_events_by_mode={}; source_points_by_mode={}
def check(kind,label,passed,**evidence):checks.append({'kind':kind,'label':label,'passed':bool(passed),**evidence})
for path in sorted(folder.glob('*.approach.json')):
 hashes[path.name]=hashlib.sha256(path.read_bytes()).hexdigest();row=json.loads(path.read_text());label=f"{row['mode']}:{row['name']}"
 if not row.get('complete'):
  failures.append({'label':label,'input_path':str(path),'error':row.get('error'),'raw_normal_error':row.get('raw_normal_error'),'actual_forward_normal_error':row.get('actual_forward_normal_error'),'raw_physics':row.get('raw_physics'),'source_physics':row.get('source_physics')})
  continue
 record={'mode':row['mode'],'name':row['name'],'direction':row['archived_direction'],'archived_R_WH':row['archived_radius_GeV'],'case_definition':cases[row['name']],'raw_R_map':row.get('raw_normals',{}).get('R_map'),'actual_R_map':row.get('actual_forward_normals',{}).get('R_map'),'certified_rho':row.get('actual_forward_normals',{}).get('certified_rho'),'raw_normal_status':row.get('raw_normals',{}).get('status'),'source_normal_status':row.get('actual_forward_normals',{}).get('status')}
 vals={}
 for source_kind in ['raw_physics','source_physics']:
  pair={entry['forced_arb']:entry['result']['evaluation'] for entry in row[source_kind]}
  check('pair',label+':'+source_kind,set(pair)=={False,True})
  for forced,e in pair.items():
   tag=f'{label}:{source_kind}:{e["precision"]}:{forced}'
   precision=e['precision'];Y=complex_(e['complete_sample_estimator']);f=complex_(e['integrand_result']);J=num(e['parameterization_jacobian']) if e['parameterization_jacobian'] is not None else D(1);W=num(e['integrator_weight'])
   check('valid',tag,e['valid'])
   expected=scale(f,J*W); factor_scale=max(norm(Y),norm(expected)); error=norm(minus(Y,expected))
   arithmetic_bound=eps[precision]*16*factor_scale
   # Quad Display retains 31 significant digits, not a round-trip decimal.
   # Propagate half of each printed final decimal place separately from the
   # unchanged native arithmetic allowance, including all product cross terms.
   tokens={'fre':e['integrand_result']['re'],'fim':e['integrand_result']['im'],
           'yre':e['complete_sample_estimator']['re'],'yim':e['complete_sample_estimator']['im'],
           'J':e['parameterization_jacobian'],'W':e['integrator_weight']}
   delta={k:(D(5)*D(10)**(num(v).as_tuple().exponent-1) if precision=='Quad' and v is not None and num(v)!=0 else D(0)) for k,v in tokens.items()}
   format_bounds=[(abs(component)+delta['f'+part])*(abs(J)+delta['J'])*(abs(W)+delta['W'])-abs(component*J*W)+delta['y'+part] for component,part in zip(f,['re','im'])]
   formatting_bound=norm(format_bounds)
   check('reported_factor_once',tag,error<=arithmetic_bound+formatting_bound,
       relative=str(relative(Y,expected)),arithmetic_only_passed=error<=arithmetic_bound,
       arithmetic_bound=str(arithmetic_bound),formatting_bound=str(formatting_bound),
       formatting_scope='Independent half-last-decimal-place propagation for Quad Display only; actual native multiplication and physical budgets unchanged')
   events=e['events'];ids=sorted(ev['cut_info']['cut_id'] for ev in events)
   check('event_identity',tag,ids==list(range(6)) and all(ev['cut_info']['graph_id']==0 and ev['cut_info']['sampling_channel_id']==(row['channel_id'] if source_kind=='source_physics' else None) for ev in events),cuts=ids)
   total_events=summed(complex_(ev['weight']) for ev in events);rel=relative(total_events,Y)
   check('event_sum_vs_complete_estimator',tag,rel<=budgets[precision],relative=str(rel),budget=str(budgets[precision]))
   for ev in events:
    ct=ev['threshold_counterterms'];assert ct is not None
    terms=[complex_(ct['original']),*[complex_(c['weighted']) for c in ct['components']]]
    total=summed(terms);target=complex_(ev['weight']);absolute_error=norm(minus(total,target));magnitude=sum(norm(t) for t in terms);bound=eps[precision]*32*len(terms)*magnitude
    check('decomposition',tag+f':cut{ev["cut_info"]["cut_id"]}',absolute_error<=bound,relative_to_terms=str(absolute_error/magnitude if magnitude else D(0)),roundoff_bound_relative=str(eps[precision]*32*len(terms)),components=len(ct['components']))
   if forced:
    # A tiny real part beside large complex terms is not a resolved real
    # signal merely because the full complex accuracy comparison passes.
    all_terms=[z for ev in events for z in [complex_(ev['threshold_counterterms']['original']),
                 *[complex_(c['weighted']) for c in ev['threshold_counterterms']['components']]]]
    summation_scale=sum(norm(z) for z in all_terms)
    roundoff_scale=eps[precision]*32*len(all_terms)*summation_scale
    record[source_kind+'_real_resolution']={'absolute_real_Y':str(abs(Y[0])),
      'sum_complex_term_norms':str(summation_scale),'roundoff_scale_diagnostic':str(roundoff_scale),
      'real_to_epsilon_term_scale':str(abs(Y[0])/(eps[precision]*summation_scale)) if summation_scale else None,
      'resolved_above_summation_roundoff':abs(Y[0])>roundoff_scale,
      'scope':'Existing 32*n epsilon summation scale; unresolved values must not support real power fits. This is not a bound on every internal physical operation.'}
    vals[source_kind]=Y
    if source_kind=='raw_physics':raw_events_by_mode.setdefault(row['name'],{})[row['mode']]={ev['cut_info']['cut_id']:ev for ev in events}
  ordinary=pair[False];arb=pair[True];rel=relative(complex_(ordinary['complete_sample_estimator']),complex_(arb['complete_sample_estimator']));tol=budgets[ordinary['precision']]+budgets['Arb']
  check('ordinary_vs_arb',label+':'+source_kind,rel<=tol,relative=str(rel),budget=str(tol),ordinary_precision=ordinary['precision'])
  record[source_kind+'_ordinary_vs_arb']=str(rel)
  # Existing total/cut metric, applied to complete estimators because returned
  # event weights already include the outer source weight.
  left=json.loads(json.dumps(pair[False])); right=json.loads(json.dumps(pair[True]))
  left['integrand_result']=left['complete_sample_estimator']; right['integrand_result']=right['complete_sample_estimator']
  detail=compare({'evaluation':left},{'evaluation':right},tol)
  check('ordinary_vs_arb_six_cuts',label+':'+source_kind,detail['passed'],detail=detail)
 # Canonical q and map factor below belong to the actual source cube. They are
 # diagnostics only; returned physical Y above is the estimator under study.
 jf=num(row['actual_forward']['selected_J_times_w']);q=num(row['actual_forward']['raw_map_density_sum']);W=num(row['grid_probes']['total']);F=scale(vals['source_physics'],D(1)/(jf*W));Fq=scale(F,D(1)/q)
 record.update(source_Y=strings(vals['source_physics']),source_F=strings(F),source_F_over_unweighted_qsum=strings(Fq),source_qsum=str(q),source_Jw=str(jf),source_outer_weight=str(W),raw_F=strings(vals['raw_physics']),raw_qsum=row['raw_inverse']['raw_map_density_sum'])
 raw_by_mode.setdefault(row['name'],{})[row['mode']]=vals['raw_physics']
 native_point=[num(x) for x in row['actual_forward']['raw_coordinates']]
 original_point=[D.from_float(float(x)) for x in row['original_binary64_tokens']]
 record['source_max_coordinate_shift_from_original_binary64_GeV']=str(max(abs(a-b) for a,b in zip(native_point,original_point)))
 record['source_R_relative_shift_from_raw']=(str(abs(num(record['actual_R_map'])/num(record['raw_R_map'])-1))
     if record['actual_R_map'] is not None and record['raw_R_map'] is not None and num(record['raw_R_map']) else None)
 # Realized soft scales use the actual forward point and serialized original
 # signed routing; temporal external data are not mistaken for spatial shifts.
 basis=inventories[row['mode']]['generation_basis']
 check('generation_frame',label,basis['loop_edges']==[3,4,7,10] and basis==case_document['generation_basis'])
 external=mode_reports[row['mode']]['correctness_settings']['kinematics']['externals']['data']['momenta']
 check('retained_CM_external_frame',label,external==[[500,0,0,500],[500,0,0,-500]])
 for name,coords in [('raw',original_point),('forward',native_point)]:
  loops=[coords[i:i+3] for i in range(0,12,3)]; soft={}
  for eid in (13,14):
   signature=basis['edge_signatures'][eid]
   # Both independent beams have opposite spatial vectors, so their exact
   # sum vanishes for these retained +/-[1,1] external rows.
   check('soft_external_CM_routing',f'{label}:{eid}',signature['external'] in ([1,1],[-1,-1]))
   momentum=[sum(D(c)*v[axis] for c,v in zip(signature['internal'],loops)) for axis in range(3)]
   soft[str(eid)]=sum(x*x for x in momentum).sqrt()
  record[name+'_soft_GeV']={k:str(v) for k,v in soft.items()}
 definition=record['case_definition']; soft_mode=definition.get('soft_mode')
 if soft_mode:
  energies=record['forward_soft_GeV']; e13=num(energies['13']);e14=num(energies['14'])
  radial=(e13*e13+e14*e14).sqrt() if soft_mode=='double' else (e13 if soft_mode=='single13' else e14)
  record['actual_forward_lambda_GeV']=str(radial)
 # Native cut momenta are direct returned fields; no root is inferred from
 # rounded event summaries and no second LU solve enters this analysis.
 cut_order={item['cut_id']:item['edges'] for item in inventories[row['mode']]['event_cut_edge_order']}
 record['native_cut_soft_energies_GeV']={}
 arb_source=next(e['result']['evaluation'] for e in row['source_physics'] if e['forced_arb'])
 for ev in arb_source['events']:
  cid=ev['cut_info']['cut_id']; ordered=cut_order[cid];momenta=ev['outgoing_momenta_native']
  check('native_cut_leg_order',f'{label}:{cid}',len(ordered)==len(momenta))
  record['native_cut_soft_energies_GeV'][str(cid)]={str(edge):momentum[0] for edge,momentum in zip(ordered,momenta) if edge in (13,14)}
 n=len(inventories[row['mode']]['channels']);probe=row['grid_probes']
 flat=(num(probe['group_prefix'])==1 and num(probe['continuous_inverse_density'])==1
       and num(probe['conditional_channel_inverse_probability'])==n and W==n)
 check('actual_flat_grid_probabilities',label,flat,n=n,probes=probe)
 if flat:
  qeff=q/D(n);record['effective_proposal_density']=str(qeff)
  check('complete_estimator_vs_actual_density',label,relative(vals['source_physics'],scale(F,1/qeff))<=D('1e-13'))
  if soft_mode:
   d=definition['radial_dimension']; absolute=abs(F[0]); second=F[0]*F[0]/qeff
   record['real_radial_diagnostics']={'dimension':d,'absolute_per_unit_radius':str(radial**(d-1)*absolute),
      'second_moment_per_unit_radius':str(radial**(d-1)*second),'absolute_per_log_radius':str(radial**d*absolute),
      'second_moment_per_log_radius':str(radial**d*second),'scope':'finite directional diagnostic; no angular-uniform or global integrability guarantee'}
 record['raw_partition_weights']=row['raw_inverse']['partition_weights']
 record['forward_partition_weights']=row['actual_forward']['partition_weights']
 record['raw_channel_labels']=[c['label'] for c in inventories[row['mode']]['channels']]
 record['raw_effective_proposal_density']=str(num(row['raw_inverse']['raw_map_density_sum'])/D(n)) if flat else None
 record['forward_real_cut_F']={str(ev['cut_info']['cut_id']):str(num(ev['weight']['re'])/(jf*W)) for ev in arb_source['events']}
 registry=inventories[row['mode']]['threshold_counterterm_metadata']
 components={c['component_id']:c for c in registry['components']};variants={v['variant_id']:v for v in registry['variants']}
 record['forward_real_CT_F']=[]
 for ev in arb_source['events']:
  for c in ev['threshold_counterterms']['components']:
   meta=components[c['component_id']]; selected=[variants[v] for v in meta['variant_ids']]
   associations=[a for v in selected for a in v['associations'] if a['cut_id']==ev['cut_info']['cut_id']]
   check('real_CT_semantic_join',f'{label}:{ev["cut_info"]["cut_id"]}:{c["component_id"]}',len(associations)==len(selected))
   record['forward_real_CT_F'].append({'cut_id':ev['cut_info']['cut_id'],'component_id':c['component_id'],
      'value':str(num(c['weighted']['re'])/(jf*W)),'kind':meta['kind'],'variant_ids':meta['variant_ids'],
      'variants':[{'side':v['side'],'subspace':v['resolved_subspace'],'parent':v['resolved_parent_lmb'],
                   'threshold_edges':[a['threshold_edges'] for a in v['associations'] if a['cut_id']==ev['cut_info']['cut_id']]} for v in selected]})
 if 'retained_host_tau' in definition or row['name']=='shared_real_maximum':
  # Recover only the observed common spatial scale from the returned native
  # cut leg. This is algebra on actual event data, never another LU root solve.
  event=next(ev for ev in arb_source['events'] if ev['cut_info']['cut_id']==3)
  physical4=[num(x) for x in event['outgoing_momenta_native'][cut_order[3].index(4)][1:]]
  raw4=native_point[3:6]; raw10=native_point[9:12]
  r4=sum(x*x for x in raw4).sqrt(); p4=sum(x*x for x in physical4).sqrt(); tau=p4/r4
  association=max(abs(p+tau*r) for p,r in zip(physical4,raw4))/p4
  check('native_cut3_common_spatial_scale',label,association<D('1e-290'),relative_residual=str(association))
  incoming=[[num(x) for x in v] for v in event['incoming_momenta_native']]
  check('native_cut3_CM_incoming',label,incoming==[[D(500),D(0),D(0),D(500)],[D(500),D(0),D(0),D(-500)]])
  # m4=m5=m10=173 is the retained graph mass relation. Check the observed
  # cut leg before using that same physical mass in the diagnostic sphere.
  mass_shell=abs(num(event['outgoing_momenta_native'][cut_order[3].index(4)][0])**2-p4*p4-D(173)**2)
  check('native_cut4_mass_shell',label,mass_shell<D('1e-290'),absolute_residual=str(mass_shell))
  radius=tau*sum(x*x for x in raw10).sqrt(); sphere=(D(500)**2-D(173)**2).sqrt()
  record['actual_native_cut3_sphere']={'radius_GeV':str(radius),'sphere_radius_GeV':str(sphere),
    'signed_distance_GeV':str(radius-sphere),'surface_energy_residual_GeV':str(2*(radius*radius+D(173)**2).sqrt()-1000),
    'observed_common_spatial_scale':str(tau),'scope':'Algebra from native Cut3 outgoing edge4 and actual source momentum; original CM q5=q10, m5=m10=173. No new root solve or CT-star identification.'}


 record['source_F_relative_shift_from_raw']=str(relative(F,vals['raw_physics']))
 source_points_by_mode.setdefault(row['name'],{})[row['mode']]=native_point
 for route,key in [('raw_inverse','raw_inverse'),('actual_forward','actual_forward')]:
  mapped=row[key];jq=num(mapped['selected_J_times_w'])*num(mapped['raw_map_density_sum']);error=abs(jq-1)
  check('density_prefactor_consistency',label+':'+route,error<D('1e-13'),absolute_Jw_qsum_minus_one=str(error),scope='same represented map law: selected J*w times unweighted sum of raw map densities; canonical-Arb budget, no outer grid probability included')
 points.append(record)
for name,modes in raw_by_mode.items():
 if baseline not in modes:continue
 for mode,value in modes.items():
  if mode!=baseline:check('raw_bare_invariance',mode+':'+name,value==modes[baseline],relative=str(relative(value,modes[baseline])),comparison='exact native Arb retained values at original binary64 raw input')
for name,modes in raw_events_by_mode.items():
 if baseline not in modes:continue
 for mode,events in modes.items():
  if mode==baseline:continue
  for cut in range(6):
   for key in ['weight','threshold_counterterms']:
    check('raw_event_invariance',f'{mode}:{name}:cut{cut}:{key}',events[cut][key]==modes[baseline][cut][key],comparison='exact native Arb raw cut weight/decomposition at the same original binary64 point')
source_differences=[]
for name,modes in source_points_by_mode.items():
 for ma in sorted(modes):
  for mb in sorted(modes):
   if ma>=mb:continue
   source_differences.append({'name':name,'modes':[ma,mb],'max_absolute_coordinate_difference_GeV':str(max(abs(a-b) for a,b in zip(modes[ma],modes[mb]))),'scope':'distinct actual source points due to independent inverse-cube binary64 boundary, not exact common-point physics comparisons'})
curves=[]
row_audit_ok={f"{p['mode']}:{p['name']}":all(c['passed'] for c in checks if c['label'].startswith(f"{p['mode']}:{p['name']}")) for p in points}
for mode in manifest['proposal_order']:
 for anchor in sorted({c.get('anchor') for c in cases.values() if c.get('anchor')}):
  for soft_mode in ['single13','single14','double']:
   expected=[c for c in cases.values() if c.get('anchor')==anchor and c.get('soft_mode')==soft_mode]
   ps=sorted([p for p in points if p['mode']==mode and p['case_definition'].get('anchor')==anchor and p['case_definition'].get('soft_mode')==soft_mode],key=lambda p:num(p['case_definition']['intended_lambda_GeV']),reverse=True)
   completed=len(ps)==len(expected)
   resolved=completed and all(p['source_physics_real_resolution']['resolved_above_summation_roundoff'] for p in ps)
   audited=completed and all(row_audit_ok[f"{mode}:{p['name']}"] for p in ps)
   valid=completed and audited and resolved
   curve={'mode':mode,'anchor':anchor,'soft_mode':soft_mode,'expected_rows':len(expected),'complete_rows':len(ps),'fit_eligible':valid,'all_signals_resolved':resolved,'all_rows_audited':audited,'no_fit_reason':None if valid else ('missing rows' if not completed else 'real signal at the native summation floor' if not resolved else 'auxiliary or physical audit failure'),'scope':'No fit over missing/failed/unresolved rows; slopes are descriptive finite-range directional evidence.'}
   if completed:
    density_radii=[num(p['actual_forward_lambda_GeV']) for p in ps]
    curve['actual_radii']=list(map(str,density_radii))
    curve['density_beta_last3']=slope(density_radii[-3:],[num(p['effective_proposal_density']) for p in ps[-3:]])
    curve['real_resolution']=[p['source_physics_real_resolution'] for p in ps]
   if valid:
    xs=[num(p['actual_forward_lambda_GeV']) for p in ps]; d=ps[0]['case_definition']['radial_dimension']
    beta_f=slope(xs[-3:],[abs(num(p['source_F']['re'])) for p in ps[-3:]])
    beta_q=slope(xs[-3:],[num(p['effective_proposal_density']) for p in ps[-3:]])
    curve.update(actual_radii=list(map(str,xs)),real_signs=[1 if num(p['source_F']['re'])>0 else -1 if num(p['source_F']['re'])<0 else 0 for p in ps],
        adjacent_beta_abs_real_F=[slope(xs[i:i+2],[abs(num(p['source_F']['re'])) for p in ps[i:i+2]]) for i in range(len(ps)-1)],
        beta_abs_real_F_last3=beta_f,beta_effective_q_last3=beta_q,
        beta_abs_real_Y_last3=slope(xs[-3:],[abs(num(p['source_Y']['re'])) for p in ps[-3:]]),
        absolute_radial_integrability_margin=(d-beta_f if beta_f is not None else None),
        second_moment_radial_integrability_margin=(d-2*beta_f+beta_q if beta_f is not None and beta_q is not None else None),
        last_point=ps[-1],radial_diagnostics=[p['real_radial_diagnostics'] for p in ps])
   curves.append(curve)
comparisons=[]
by_name={name:{p['mode']:p for p in points if p['name']==name} for name in cases}
for name,rows in by_name.items():
 for left,right in [('composed_cut3_p2','composed_p2'),('composed_p2','composed_p1'),('cuts_combined_joint','cuts'),('cuts_replaced_joint','cuts'),('cuts_replaced_joint','cuts_combined_joint'),('cuts_soft','cuts')]:
  if left not in rows or right not in rows:continue
  a,b=rows[left],rows[right]
  ratio=lambda x,y:str(num(x)/num(y)) if num(y)!=0 else None
  comparisons.append({'case':name,'candidate':left,'control':right,'raw_qsum_ratio':ratio(a['raw_qsum'],b['raw_qsum']),
      'raw_effective_density_ratio':ratio(a['raw_effective_proposal_density'],b['raw_effective_proposal_density']) if a.get('raw_effective_proposal_density') and b.get('raw_effective_proposal_density') else None,
      'complete_real_Y_ratio':ratio(a['source_Y']['re'],b['source_Y']['re']) if a['source_physics_real_resolution']['resolved_above_summation_roundoff'] and b['source_physics_real_resolution']['resolved_above_summation_roundoff'] else None,
      'real_ratio_resolved':a['source_physics_real_resolution']['resolved_above_summation_roundoff'] and b['source_physics_real_resolution']['resolved_above_summation_roundoff'],
      'actual_forward_q_ratio':ratio(a['source_qsum'],b['source_qsum']),
      'raw_physics_exact':a['raw_F']==b['raw_F'],
      'scope':'Raw density comparison is at the shared binary64 point; complete Y belongs to each explicitly retained actual forwarded point.'})
expected_count=len(cases)*len(manifest['proposal_order'])
report={'scope':'Existing local-approach audit and slope owner extended to explicit raw cases; real observables primary. Imaginary data remain automatic diagnostics. No state/Gamma calls.','expected_point_rows':expected_count,'point_files':len(hashes),'complete_points':len(points),'missing_point_files':expected_count-len(hashes),'failed_rows':failures,'driver_status':summary['status'],'driver_error':summary.get('error'),
 'all_checks_passed':all(c['passed'] for c in checks),'checks_passed':sum(c['passed'] for c in checks),'checks_failed':[c for c in checks if not c['passed']],
 'pointwise_audit_passed':row_audit_ok,'points':points,'curves':curves,'matched_comparisons':comparisons,'source_point_differences':source_differences,'checks':checks,
 'input_sha256':{str(folder/k):v for k,v in hashes.items()},'analyzer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
 'existing_metric_owner_sha256':hashlib.sha256(Path(__file__).with_name('audit_physical.py').read_bytes()).hexdigest()}
for p in [manifest_path,case_source,folder/'summary.json',*[folder/(mode+'.json') for mode in mode_reports]]:report['input_sha256'][str(p)]=hashlib.sha256(p.read_bytes()).hexdigest()
out.mkdir();(out/'analysis.json').write_text(json.dumps(report,indent=2,default=str)+'\n')
lines=['# Bounded local real-weight analysis','',f"Expected {expected_count} rows; retained {len(hashes)}; complete {len(points)}; failures {len(failures)}; missing {expected_count-len(hashes)}.",f"Native checks: {report['checks_passed']}/{len(checks)} pass.",'','No slope is fitted across a missing/failed branch. Positive directional radial margins are evidence only along these finite rays, not a global finite-variance proof.','','| Mode | Anchor | Soft limit | beta abs Re F | beta q | beta abs Re Y | d-p | d-2p+s |','|---|---|---|---:|---:|---:|---:|---:|']
for c in curves:
 if c['fit_eligible']:
  v=[c[k] for k in ('beta_abs_real_F_last3','beta_effective_q_last3','beta_abs_real_Y_last3','absolute_radial_integrability_margin','second_moment_radial_integrability_margin')]
  lines.append('| '+ ' | '.join([c['mode'],c['anchor'],c['soft_mode']]+[f'{x:.6g}' if x is not None else 'unresolved' for x in v])+' |')
 else:lines.append(f"| {c['mode']} | {c['anchor']} | {c['soft_mode']} | no fit | {c['no_fit_reason']} | | | |")
lines+=['','Matched common-raw-point density and actual-forward real-weight ratios:','','| Case | Candidate / control | raw qsum ratio | raw qeff ratio | actual real Y ratio |','|---|---|---:|---:|---:|']
for c in comparisons:lines.append('| '+' | '.join([c['case'],c['candidate']+'/'+c['control'],*[f"{float(c[k]):.8g}" if c[k] is not None else ('unresolved real' if k=='complete_real_Y_ratio' and not c['real_ratio_resolved'] else 'undefined') for k in ('raw_qsum_ratio','raw_effective_density_ratio','complete_real_Y_ratio')]])+' |')
lines+=['','Failures/support gaps and native precision/cut checks are retained in analysis.json. The exact source points, raw/forward soft distances, native cut soft energies and probability factors remain explicit. Returned event/CT weights are not multiplied by Grid weights again.']
(out/'analysis.md').write_text('\n'.join(lines)+'\n')
print(json.dumps({k:report[k] for k in ('expected_point_rows','point_files','complete_points','missing_point_files','failed_rows','all_checks_passed','checks_passed','checks_failed')},default=str))

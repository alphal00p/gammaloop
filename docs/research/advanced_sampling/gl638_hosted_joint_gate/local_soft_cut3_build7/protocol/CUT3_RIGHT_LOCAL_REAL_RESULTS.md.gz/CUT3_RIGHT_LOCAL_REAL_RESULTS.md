# Cut3 right-surface channel: bounded real-weight check

The additional currently supported Cut3 right `[5,10]` channel improves the sampled real maximum locally. At that retained point, the actual flat-mixture density increases by **2.11337**, and the complete real weight falls from **12.21898 to 5.78174 pb**. This is a local result; the new catalogue has not yet passed its complete reference-normalization gate or a Monte Carlo comparison.

Three sampling-only cards were compared: the existing composed Cut1 catalogue at global power 1; the same catalogue at global power 2; and that power-2 catalogue plus the Cut3 channel. The first two are exactly equal in raw density and complete weight at all seven points. Each case also has exactly the same actual native source point across all three catalogues. The new channel therefore accounts for the measured change in this scan.

The native composition is `then(block(lmb(4,12),phase_space(cut(2,4,12))),complement(7),block(lmb(5),at_cut(cut(2,4,12),surface(5,10))))`, parent `[4,5,7,12]`, on cut 3. The LU-h profile acts on the phase-space prefix. The surface radial law uses the explicitly changed global power 2; no per-channel profile override was introduced.

All **21 rows / 84 native evaluations** completed. The existing total/cut precision, decomposition and full-factor checks, with explicit routing and native-event joins, passed **2,681/2,681** checks. All ordinary calls used Double; their largest total discrepancy from forced Arb was `4.62e-10` in the existing norm metric, within the unchanged budget. The maximum source/input spatial change was `9.18e-14 GeV`.

| Actual Cut3 radial distance (GeV) | Control Re Y (pb) | Added-channel Re Y (pb) | Actual mixture-density ratio |
|---:|---:|---:|---:|
| 27.99381709 | 12.2189787 | 5.78174164 | 2.11337334 |
| -10 | 9.11589325 | 2.43571337 | 3.74259687 |
| -1 | 9.78810915 | 0.897545516 | 10.9054181 |
| -0.1 | 9.86818847 | 0.299790817 | 32.9169138 |
| 0.1 | 9.88616837 | 0.385521958 | 25.6435935 |
| 1 | 9.96780675 | 1.21443907 | 8.20774543 |
| 10 | 10.8102819 | 3.69072298 | 2.92904181 |

The actual distance uses the returned native Cut3 outgoing edge-4 vector and the common spatial rescaling of the actual source point, checked against all three vector components and the native mass shell. In the retained CM frame, `q5=q10` and the physical surface is `2 sqrt(|q10|²+173²)-1000=0`, with radius `469.1172561 GeV`. This algebra does not solve another root or identify a CT star. The six intended signed distances are realized within `8e-14 GeV`.

At the original maximum, the unweighted density sum increases by `2.4152838223`. The actual Grid probes give seven versus eight equally likely channels, so the density of the full proposal increases by `2.4152838223*7/8=2.1133733445`. The new channel supplies `58.5970%` of the density sum there. The complete estimator includes the selected map Jacobian, partition weight and original Sample weight exactly once.

The semantic CT registry identifies the pure Cut3 right `[5,10]` local and integrated terms. Its local real contribution is at most `1.01e-336` in raw-density units, compared with order `1e-36` for its integrated real contribution; it is numerically negligible, not an exact serialized zero. Its integrated real contribution is `9.9911e-37` at the original maximum and about `1.19–1.24e-36` across the sphere probes, while the total real integrand there is about `4.73–5.45e-37`. These term magnitudes are signed contributions in raw momentum-density units, not rate fractions. They show a broad integrated real enhancement and cancellations, rather than a measured real singularity on this sphere.

The conditional surface map can increase coverage around this existing physical threshold. The scan does not establish a global maximum bound, reduced integrated variance, or coverage of moved CT-star intersections. The historical confirmation selection and estimates remain unchanged.

Artifacts: `results-cut3-right-local-build7/` retains all native rows, inventories and runtime acceptance; `cut3-right-local-analysis-final-build7/analysis.json` retains every check, actual source point difference, per-channel partition, real cut/CT contribution and signed distance. The analyzer is the existing local-approach audit extended to explicit raw cases and the existing physical norm metric.

Analysis SHA256: `8cb217f0848cad806a38e629d4ea9e7432e6fa3c64419313990363306fa60e36`.
Analyzer SHA256: `4ab42fbdb20c54c9a751585a5995ef652b6f4514879e520f2bd086a1c83cc284`.

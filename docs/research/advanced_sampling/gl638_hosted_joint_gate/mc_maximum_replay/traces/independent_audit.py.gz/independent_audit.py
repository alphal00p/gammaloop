"""Audit retained trace controls and metadata joins; no physics evaluation."""

import hashlib
import json
import re
import sys
from collections import Counter
from pathlib import Path

packet = (
    Path(sys.argv[1]) if len(sys.argv) > 1 else Path("/tmp/gl638-hosted-joint-gate")
)
output = (
    Path(sys.argv[2])
    if len(sys.argv) > 2
    else packet / "max-native-trace-independent-audit.json"
)
folder = packet / "results-max-native-trace-build5"
read = lambda p: json.loads(p.read_text())
summary = read(folder / "summary.json")
request = read(packet / "request-max-native-trace-build5.json")
checks = []
rows = []


def check(name, condition):
    checks.append({"name": name, "passed": bool(condition)})
    if not condition:
        raise AssertionError(name)


check(
    "completed3case trace",
    summary["status"] == "completed"
    and summary["error"] is None
    and len(summary["cases"]) == 3,
)
check(
    "unchanged35state records",
    summary["saved_state_unchanged"]
    and summary["state_before"] == summary["state_after"]
    and len(summary["state_before"]) == 35,
)
check(
    "unchanged authenticated input record",
    summary["inputs_unchanged"] and summary["input_sha256"] == request["input_sha256"],
)
for source, expected in request["input_sha256"].items():
    check(
        "input hash: " + source,
        hashlib.sha256(Path(source).read_bytes()).hexdigest() == expected,
    )
fields = [
    "precision",
    "valid",
    "integrand_result",
    "complete_sample_estimator",
    "integrator_weight",
    "parameterization_jacobian",
    "events",
]
for case, report in zip(request["cases"], summary["cases"]):
    label = case["id"]
    row = read(folder / (label + ".json"))
    old = read(Path(case["attribution"]))
    check(label + ": exact standalone row", row == report)
    check(
        label + ": original source",
        row["complete_sample"] == old["maximum"]["complete_sample"]
        and row["source_aliases"] == old["maximum"]["aliases"]
        and row["forced_arb_control"] == old["forced_arb"],
    )
    native = row["traced_forced_arb"]["evaluation"]
    control = old["forced_arb"]["evaluation"]
    check(
        label + ": exact7native fields including full events",
        all(native[k] == control[k] for k in fields),
    )
    check(
        label + ": valid Arb and all6cuts",
        native["valid"]
        and native["precision"] == "Arb"
        and sorted(e["cut_info"]["cut_id"] for e in native["events"]) == list(range(6)),
    )
    check(
        label + ": no declared numeric differences",
        row["complete"] and row["numeric_control_differences"] == [],
    )
    components = {
        x["component_id"]: x
        for x in row["inventory"]["threshold_counterterm_metadata"]["components"]
    }
    variants = {
        x["variant_id"]: x
        for x in row["inventory"]["threshold_counterterm_metadata"]["variants"]
    }
    cutgroups = {
        cut: group["id"]
        for group in row["geometry_registry"]["cut_groups"]
        for cut in group["cuts"]
    }
    count = 0
    for event in native["events"]:
        cut = event["cut_info"]["cut_id"]
        for term in event["threshold_counterterms"]["components"]:
            component = components[term["component_id"]]
            definitions = [variants[i] for i in component["variant_ids"]]
            check(
                f"{label}: cut{cut} component{term['component_id']} group and original associations",
                component["cut_group_id"] == cutgroups[cut]
                and all(
                    d["cut_group_id"] == cutgroups[cut]
                    and any(a["cut_id"] == cut for a in d["associations"])
                    for d in definitions
                ),
            )
            occurrence = term["occurrence"]
            sides = {d["side"] for d in definitions}
            check(
                f"{label}: cut{cut} component{term['component_id']} occurrence sides",
                occurrence["kind"] == "local_unitarity"
                and (occurrence["left_threshold_order"] is not None)
                == ("left" in sides)
                and (occurrence["right_threshold_order"] is not None)
                == ("right" in sides)
                and len(occurrence["overlap_groups"]) == len(definitions),
            )
            count += 1
    tracepath = folder / (label + ".jsonl")
    events = [json.loads(line) for line in tracepath.read_text().splitlines()]
    centers = [
        (i + 1, e)
        for i, e in enumerate(events)
        if e["fields"].get("stage") == "lu_threshold_center_values"
    ]
    check(
        label + ": raw trace counts",
        len(events) == row["trace_events"]
        and tracepath.stat().st_size == row["trace_bytes"]
        and len(centers) == row["native_center_records"] > 0,
    )
    check(
        label + ": actualcall span on every traceevent",
        all(
            e.get("span", {}).get("case") == label
            and e["span"].get("precision") == "Arb"
            for e in events
        ),
    )
    check(
        label + ": native center fields retained",
        all(
            isinstance(e["fields"].get("file.active_center"), str)
            and isinstance(e["fields"].get("file.center_with_fixed_complement"), str)
            and e["fields"]["center_provenance"]
            == "canonical_identity_center_promoted_and_rotated_natively"
            for _, e in centers
        ),
    )
    evaluator_lines = [
        (i + 1, e["fields"].get("message", ""))
        for i, e in enumerate(events)
        if re.match(
            r"LU (left|right|iterated) evaluator input: cut_group_id=",
            e["fields"].get("message", ""),
        )
    ]
    check(
        label + ": all explicit evaluator groups resolve",
        all(
            int(re.search(r"cut_group_id=(\d+)", message)[1]) in cutgroups.values()
            for _, message in evaluator_lines
        ),
    )
    rows.append(
        {
            "case": label,
            "native_fields_exact": fields,
            "event_components_checked": count,
            "trace_lines": len(events),
            "centers": len(centers),
            "center_rotation_counts": dict(
                Counter(e["fields"]["rotation_id"] for _, e in centers)
            ),
            "explicit_evaluator_lines": [i for i, _ in evaluator_lines],
            "trace_sha256": hashlib.sha256(tracepath.read_bytes()).hexdigest(),
        }
    )
result = {
    "passed": True,
    "checks": checks,
    "cases": rows,
    "scope": "Artifact-only numeric identity and structural occurrence audit. No Gamma call, generated-state load/rehash, root solve, center/star reconstruction or duplicated physical attribution.",
    "join_boundary": "Center selected_esurface_id is local; it is not a global variant/cut ID. All first-pass cutgroup start messages precede CT centers, so carrying the latest header gives the wrong association. Physical joins require subsequent explicit group/side/threshold evaluator messages, actual variant metadata/native parent and measured center/root occurrence consistency; B owns that independent geometry reconstruction.",
}
output.write_text(json.dumps(result, indent=2) + "\n")
print(
    len(checks),
    "checks passed; control fields and structural occurrence rows unchanged",
)

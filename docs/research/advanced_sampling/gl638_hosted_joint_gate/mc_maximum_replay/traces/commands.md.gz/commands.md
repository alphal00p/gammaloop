# Three retained maximum traces

Prepared only; no diagnostic has run. The new `drivers/max_replay_trace.rs` retains the original max29b replay body unchanged and adds an explicit `--trace` entry. Original b53, max29b, all pilot directories and completed maximum outputs stay immutable.

The request `request-max-native-trace-build5.json` selects these measured, audited complete Samples:

| Case | Method / seed | Selected channel | Retained magnitude, pb |
|---|---|---|---:|
| cuts_seed22229_lu_cut5 | cuts /22229 | lu_cut_5 |1.35512983844|
| composed_seed33331_lu_cut1 | cuts_combined_joint /33331 | lu_cut_1 |0.250887363126|
| soft_seed11113 | cuts_combined_joint_soft /11113 | soft_6_12 |14.3055223644|

These are the largest complex norms among the methods' retained signed-extremum Samples, not maxima over unrecorded sample norms. The composed and soft cases have exactly zero added-joint partition at these points. A large weight here does not show failure of a supported direct-H/Z cancellation.

Root links once to the existing build5 libraries; no Cargo or production change:

```bash
source /tmp/gammaloop-rebase-dev-env.sh
gl_gate_packet=/tmp/gl638-hosted-joint-gate
python "$gl_gate_packet/compile_driver.py" \
  "$gl_gate_packet/drivers/max_replay_trace.rs" "$gl_gate_packet/drivers/max-trace-build5" \
  --build-log /tmp/hosted-joint-optimized-build5.jsonl \
  --captures "$gl_gate_packet/rustc-invocations-build5" \
  --extra-core-extern bincode --extra-core-extern tracing --extra-core-extern tracing_subscriber
RAYON_NUM_THREADS=1 GL_DISPLAY_FILTER=off \
/run/current-system/sw/bin/time -v -o "$gl_gate_packet/results-max-native-trace-build5.resources.txt" \
  "$gl_gate_packet/drivers/max-trace-build5" --trace \
  "$gl_gate_packet/manifest-screen-full-build5.json" \
  "$gl_gate_packet/request-max-native-trace-build5.json" \
  "$gl_gate_packet/results-max-native-trace-build5" \
  > "$gl_gate_packet/results-max-native-trace-build5.log" 2>&1
```

`max-native-trace-build5-commands.json` retains exact argv and source/request hashes. Freeze the new executable/build record before the run. The command uses one read-only loaded state and three synchronous forced-Arb calls, each with the original complete Sample, workspace settings and max_eval0. The already audited ordinary and forced-Arb controls are included in the new per-case record; no additional ordinary call is needed.

The standard `tracing_subscriber::fmt().json()` subscriber is installed with `tracing::subscriber::with_default` inside the actual evaluator worker and around only that case's precise call. Each file is created exclusively in the new output directory. StateLoadOption remains read-only and its default state logfile stays disabled. The subscriber retains existing literal `file.*` fields, which the normal display formatter omits. The filter admits only cross-section evaluation, LU counterterms, Newton solver diagnostics and a small case/seed/channel span; warmup/loading is outside capture. No custom logging layer or production helper is introduced.

A completed case requires an Arb result with all six cut events, exactly matching retained native totals, factors and events, plus at least one actual `lu_threshold_center_values` event containing the full active center and center with fixed complement. Missing capture or numeric differences remain explicit failures. The summary checks all35 saved-state hashes and the selected input file hashes after the run. It does not claim success merely because logs were written.

## What the records can establish

The returned decomposition identifies the dominant physical cut and CT component. The retained semantic metadata joins component→variant/evaluator→side, threshold edges, subspace, native parent, multiplier and occurrence groups/orders. The new record also retains all existing LMB signatures, physical cut-group membership, cached represented masses and kinematic settings. Cut group3 and physical cut3 must never be conflated.

Existing trace fields provide the raw native loop sample, physical LU prepared ray/root, full active center and fixed complement, solve-group membership, selected threshold ID, alpha solution, r/rstar and projection derivatives. They can distinguish an unusually small projection derivative, a small star displacement, a large physical radial scale and cancellation between specific bare/local/integrated terms. They can associate a dominant CT with a moved star instead of assuming its normals equal the base point.

The final full Kstar and every edge energy are not directly serialized by the existing fields. Where the recorded parent/occurrence/frame joins are unambiguous, reconstruct only the deterministic existing affine geometry: native-parent base point minus center, active rescale by the measured alpha, then center addition; inverse-transform with the retained parent, and for iterated terms use KLstar+KRstar−Kbase in the graph frame. This follows the existing `base_rstar_loop_momenta` and `merge_and_inverse_transform` owners, without another root solve. Report reconstruction rounding/printed precision separately from measured scalars. Missing joins remain unresolved.

At an identified base/CT-star point, original routed energy rows give Hglobal, Zglobal and the host residual; the cut-eliminated H relation requires the actual host defect. In CM the already audited spatial routes q13=p−t and q14=s−p identify soft energies, but use the retained native routing/externals before applying that reduction. Both the physical LU point and the CT star must be inspected: a soft-channel label, large CT contribution or zero joint support alone proves none of soft-gluon, H/Z-star, tangency or radial-tail origin. The trace will supply evidence for this classification; it cannot certify global boundedness or MC convergence.

// Adapt the archived 48-maximum replay to current complete-Sample APIs.
// Reuse the frozen common client's inventory, hashing and native serialization;
// no map, integration, retry, or statistics engine is introduced here.
mod client {
    include!("gate-max-support.rs");
    use gammalooprs::{
        integrands::process::EvaluationTarget, integrate::IntegrationState,
        settings::RuntimeSettings, utils::serde_utils::SmartSerde,
    };

    // Child node weights are cumulative. Retain their conditional ratios as
    // diagnostics, but multiply only the outer complete Sample weight once.
    fn sample_path(sample: &Sample<F<f64>>) -> Result<(Vec<usize>, Vec<f64>, Vec<Value>)> {
        let mut leaf = sample;
        let mut ids = Vec::new();
        let mut factors = Vec::new();
        loop {
            match leaf {
                Sample::Discrete(weight, id, Some(child)) => {
                    ensure!(
                        weight.0.is_finite() && weight.0 > 0.0 && child.get_weight().0 > 0.0,
                        "invalid retained discrete weight"
                    );
                    ids.push(*id);
                    factors.push(
                        json!({"kind":"discrete","index":id,"subtree_weight":weight.0,
                        "conditional_inverse_probability":weight.0/child.get_weight().0}),
                    );
                    leaf = child;
                }
                Sample::Continuous(weight, cube) => {
                    ensure!(
                        weight.0.is_finite()
                            && weight.0 > 0.0
                            && cube
                                .iter()
                                .all(|x| x.0.is_finite() && (0.0..1.0).contains(&x.0)),
                        "invalid retained continuous source"
                    );
                    factors.push(json!({"kind":"continuous","weight":weight.0}));
                    return Ok((ids, cube.iter().map(|x| x.0).collect(), factors));
                }
                _ => return Err(eyre!("expected complete nested discrete/continuous Sample")),
            }
        }
    }

    pub fn run_max_replay() -> Result<()> {
        let args = env::args().skip(1).collect::<Vec<_>>();
        ensure!(
            args.len() == 3,
            "max-replay MANIFEST PILOT_OUTPUT OUTPUT_DIRECTORY"
        );
        let manifest: Value = serde_json::from_str(&fs::read_to_string(&args[0])?)?;
        let pilot = Path::new(&args[1]);
        let output = Path::new(&args[2]);
        ensure!(
            !output.join("summary.json").exists(),
            "refusing to overwrite maximum evidence"
        );
        fs::create_dir_all(output)?;
        let state_path = Path::new(manifest["state"].as_str().unwrap());
        ensure!(
            !output
                .canonicalize()?
                .starts_with(state_path.canonicalize()?)
                && !output.canonicalize()?.starts_with(pilot.canonicalize()?),
            "maximum output must be outside immutable state and pilot workspaces"
        );
        let before = state_hashes(state_path)?;
        let expected: BTreeMap<String, String> = serde_json::from_str(&fs::read_to_string(
            manifest["saved_state_hashes"].as_str().unwrap(),
        )?)?;
        ensure!(
            before == expected,
            "generated state differs from reviewed full snapshot"
        );
        let pilot_before = state_hashes(pilot)?;
        let pilot_summary: Value =
            serde_json::from_str(&fs::read_to_string(pilot.join("summary.json"))?)?;
        ensure!(
            pilot_summary["preflight_accepted"] == true
                && pilot_summary["saved_state_unchanged"] == true
                && pilot_summary["error"].is_null(),
            "only accepted, unchanged-state physical pilots can replay maxima"
        );
        for field in [
            "source_base_commit",
            "source_candidate_commit",
            "source_candidate_patch_sha256",
        ] {
            ensure!(
                pilot_summary["build_identity"][field] == manifest[field],
                "pilot source lineage differs: {field}"
            );
        }
        let runs: Vec<Value> =
            serde_json::from_str(&fs::read_to_string(pilot.join("pilots.json"))?)?;
        let modes = manifest["proposal_order"].as_array().unwrap();
        let seeds = manifest["paired_seeds"].as_array().unwrap();
        let n = manifest["samples_per_run"].as_u64().unwrap() as usize;
        ensure!(
            n > 1 && runs.len() == modes.len() * seeds.len(),
            "incomplete declared mode/seed matrix"
        );
        let mut identities = std::collections::BTreeSet::new();
        for run in &runs {
            ensure!(
                modes.contains(&run["mode"])
                    && seeds.contains(&run["seed"])
                    && run["sample_count"] == json!(n)
                    && run["preflight_accepted"] == true
                    && run["diagnostic_only"] == false
                    && run["result"]["finite_complete"] == true
                    && identities
                        .insert((run["mode"].as_str().unwrap(), run["seed"].as_u64().unwrap())),
                "invalid, duplicated or incomplete physical pilot row"
            );
        }
        let mut report = json!({"status":"started","manifest":args[0],"pilot_directory":args[1],
            "source_lineage":pilot_summary["build_identity"],"state_before":before,"pilot_files_before":pilot_before,
            "runs":[],"attribution":[],"native_event_scope":"precise returned events and CT decomposition already include outer Sample weight",
            "maximum_scope":"ordinary raw reporting owner reproduces first-iteration maximum; native controls retain the same complete source and max_eval0"});
        let mut provenance = BTreeMap::new();
        for path in [
            env::current_exe()?,
            Path::new(file!()).to_path_buf(),
            Path::new(file!()).with_file_name("gate-max-support.rs"),
        ] {
            let hash = Command::new("sha256sum").arg(&path).output()?;
            ensure!(
                hash.status.success(),
                "cannot hash maximum replay provenance"
            );
            provenance.insert(
                path.to_string_lossy().into_owned(),
                String::from_utf8(hash.stdout)?
                    .split_whitespace()
                    .next()
                    .unwrap()
                    .to_owned(),
            );
        }
        report["execution_provenance"] = json!(provenance);
        let at = Instant::now();
        let execution = (|| -> Result<()> {
            initialise()?;
            let mut loaded = StateLoadOption::read_only(state_path).load()?;
            ensure!(
                loaded.is_read_only_state(),
                "read-only generated state required"
            );
            loaded.state.activate_loaded_integrand_backends(false)?;
            let process_id = loaded.state.resolve_process_ref(Some(&ProcessRef::Name(
                manifest["process_name"].as_str().unwrap().to_owned(),
            )))?;
            let model = &loaded.state.model;
            let integrand = loaded
                .state
                .process_list
                .get_integrand_mut(process_id, manifest["integrand_name"].as_str().unwrap())?;
            let mut unique_by_mode: BTreeMap<String, BTreeMap<String, Value>> = BTreeMap::new();
            for run in &runs {
                let mode = run["mode"].as_str().unwrap();
                let seed = run["seed"].as_u64().unwrap();
                let workspace = Path::new(run["workspace"].as_str().unwrap());
                let checkpoint = workspace.join("state/integration_state.bin");
                let bytes = fs::read(&checkpoint)?;
                let (state, consumed) = bincode::decode_from_slice::<IntegrationState, _>(
                    &bytes,
                    bincode::config::standard(),
                )?;
                ensure!(
                    consumed == bytes.len()
                        && state.iter == 1
                        && state.num_points == n
                        && state.all_integrals.len() == 1,
                    "only complete fresh first-iteration single-slot maxima supported"
                );
                let statistics = json!(state.stats);
                ensure!(
                    statistics["num_nan_or_unstable_evals"] == 0,
                    "pilot checkpoint contains invalid evaluations"
                );
                let settings_path = workspace
                    .join("integrands")
                    .join(format!(
                        "{}@{}",
                        manifest["process_name"].as_str().unwrap(),
                        manifest["integrand_name"].as_str().unwrap()
                    ))
                    .join("settings.toml");
                // Use the integration workspace owner, not an overlay: omitted
                // default fields must not inherit unrelated loaded-state values.
                *integrand.get_mut_settings() = RuntimeSettings::from_file(
                    &settings_path,
                    "retained maximum workspace settings",
                )?;
                ensure!(
                    integrand.get_settings().integrator.seed == seed
                        && integrand.get_settings().integrator.n_start == n
                        && integrand.get_settings().integrator.n_max == n
                        && integrand.get_settings().integrator.n_increase == 0,
                    "checkpoint card seed/N mismatch"
                );
                integrand.warm_up(model)?;
                let info = inventory(integrand, &manifest, mode)?;
                let mut native = integrand.clone();
                native.get_mut_settings().general.generate_events = true;
                native
                    .get_mut_settings()
                    .general
                    .store_additional_weights_in_event = true;
                native.warm_up(model)?;
                let mut requests: BTreeMap<String, (Sample<F<f64>>, Vec<Value>)> = BTreeMap::new();
                let mut unavailable = Vec::new();
                for (phase, accumulator) in [
                    ("re", &state.all_integrals[0].re),
                    ("im", &state.all_integrals[0].im),
                ] {
                    for (sign, value, sample) in [
                        (
                            "positive",
                            accumulator.max_eval_positive,
                            &accumulator.max_eval_positive_xs,
                        ),
                        (
                            "negative",
                            accumulator.max_eval_negative,
                            &accumulator.max_eval_negative_xs,
                        ),
                    ] {
                        let alias = json!({"mode":mode,"seed":seed,"workspace":workspace,"phase":phase,"sign":sign,
                            "stored_maximum":value.0,"stored_maximum_bits":value.0.to_bits()});
                        let Some(sample) = sample else {
                            let mut missing = alias;
                            missing["complete"] = json!(value.0 == 0.0);
                            missing["reason"] = json!(if value.0 == 0.0 {
                                "no nonzero extremum recorded for this phase/sign"
                            } else {
                                "nonzero stored extremum is missing its complete Sample"
                            });
                            unavailable.push(missing);
                            continue;
                        };
                        let key = serde_json::to_string(sample)?;
                        requests
                            .entry(key)
                            .or_insert_with(|| (sample.clone(), Vec::new()))
                            .1
                            .push(alias);
                    }
                }
                let mut maxima = Vec::new();
                for (key, (sample, mut aliases)) in requests {
                    let (ids, cube, factors) = sample_path(&sample)?;
                    ensure!(
                        ids.len() == 2
                            && ids[0] == 0
                            && cube.len() == 12
                            && info["channels"]
                                .as_array()
                                .unwrap()
                                .iter()
                                .any(|channel| channel["id"] == ids[1]),
                        "retained selection path does not belong to this catalogue"
                    );
                    let mut maximum = json!({"complete_sample":sample,"sample_key":key,"aliases":aliases,
                        "sample_weight":sample.get_weight().0,"conditional_factors":factors});
                    let result = (|| -> Result<()> {
                        let mut batch = integrand.evaluate_samples_raw(
                            EvaluationTarget::Physical(model),
                            std::slice::from_ref(&sample),
                            0,
                            false,
                            false,
                            Complex::new_zero(),
                        )?;
                        ensure!(batch.samples.len() == 1, "maximum raw replay count changed");
                        let raw = batch.samples.remove(0);
                        let valid = !raw.evaluation_metadata.is_nan
                            && raw
                                .evaluation_metadata
                                .stability_results
                                .last()
                                .is_some_and(|level| {
                                    !matches!(level.status, StabilityStatus::Unstable(_))
                                });
                        // This is exactly the integration owner's reporting algebra:
                        // f64 returned result * remaining J, then outer Sample weight.
                        let effective = raw.integrand_result
                            * Complex::new_re(raw.parameterization_jacobian.unwrap_or(F(1.0)));
                        let weighted = Complex::new(
                            effective.re * sample.get_weight(),
                            effective.im * sample.get_weight(),
                        );
                        maximum["ordinary_reporting_evaluation"] = json!(raw);
                        maximum["reported_estimator"] =
                            json!({"re":weighted.re.0,"im":weighted.im.0});
                        ensure!(
                            valid && weighted.re.0.is_finite() && weighted.im.0.is_finite(),
                            "invalid maximum replay retained"
                        );
                        let mut matches_checkpoint = true;
                        for alias in &mut aliases {
                            let value = if alias["phase"] == "re" {
                                weighted.re.0
                            } else {
                                weighted.im.0
                            };
                            let stored = alias["stored_maximum"].as_f64().unwrap();
                            let relative = if stored == 0.0 {
                                if value == 0.0 { 0.0 } else { f64::INFINITY }
                            } else {
                                ((value - stored) / stored).abs()
                            };
                            alias["replayed_maximum"] = json!(value);
                            alias["relative_difference"] = json!(relative);
                            alias["bit_exact"] = json!(value.to_bits() == stored.to_bits());
                            alias["passed"] = json!(relative < 1.0e-10);
                            matches_checkpoint &= relative < 1.0e-10;
                        }
                        maximum["aliases"] = json!(aliases);
                        ensure!(
                            matches_checkpoint,
                            "stored maximum mismatch; unchanged historical1e-10 replay criterion"
                        );
                        eprintln!(
                            "maximum native ordinary mode={mode} seed={seed} aliases={}",
                            serde_json::to_string(&aliases)?
                        );
                        let start = Instant::now();
                        maximum["native_ordinary"] = record(
                            native.evaluate_sample_precise(
                                &sample,
                                model,
                                sample.get_weight(),
                                false,
                                Complex::new_zero(),
                            ),
                            start.elapsed().as_secs_f64(),
                        );
                        let ProcessIntegrand::CrossSection(process) = &native else {
                            return Err(eyre!("cross section required"));
                        };
                        let coordinates = cube
                            .iter()
                            .map(|x| ArbPrec::from_f64_exact_binary(*x))
                            .collect::<Vec<_>>();
                        let geometry = (|| -> Result<Value> {
                            let mapped = process.data.graph_terms[0]
                                .sampling_setup()
                                .sampling_bridge::<ArbPrec>()?
                                .forward(SamplingChannelId(ids[1]), &coordinates)?;
                            approach_map(&mapped)
                        })();
                        maximum["canonical_map"] = geometry.unwrap_or_else(|error|
                            json!({"error":format!("{error:#}"),"scope":"detached diagnostic; exact replay and native attribution retained independently"}));
                        maximum["map_scope"] = json!(
                            "detached canonical Arb diagnostic at original source; J*w is already folded into physical result"
                        );
                        let events = maximum["native_ordinary"]["evaluation"]["events"].as_array();
                        let mut cuts = events
                            .into_iter()
                            .flatten()
                            .filter_map(|event| event["cut_info"]["cut_id"].as_u64())
                            .collect::<Vec<_>>();
                        cuts.sort_unstable();
                        ensure!(
                            maximum["native_ordinary"]["evaluation"]["valid"] == true
                                && cuts == [0, 1, 2, 3, 4, 5],
                            "native ordinary maximum/cut events invalid"
                        );
                        maximum["ranking_score"] = json!(weighted.re.0.hypot(weighted.im.0));
                        Ok(())
                    })();
                    maximum["complete"] = json!(result.is_ok());
                    maximum["error"] = result
                        .err()
                        .map(|error| json!(format!("{error:#}")))
                        .unwrap_or(Value::Null);
                    if maximum["complete"] == true {
                        let entry = unique_by_mode
                            .entry(mode.to_owned())
                            .or_default()
                            .entry(key.clone());
                        match entry {
                            std::collections::btree_map::Entry::Vacant(entry) => {
                                let mut candidate = maximum.clone();
                                candidate["settings_path"] = json!(settings_path);
                                entry.insert(candidate);
                            }
                            std::collections::btree_map::Entry::Occupied(mut entry) => {
                                entry.get_mut()["aliases"]
                                    .as_array_mut()
                                    .unwrap()
                                    .extend(aliases.clone());
                            }
                        }
                    }
                    maxima.push(maximum);
                }
                let row = json!({"mode":mode,"seed":seed,"workspace":workspace,"checkpoint":checkpoint,
                    "settings_path":settings_path,"num_points":state.num_points,"iter":state.iter,"n_cores":state.n_cores,
                    "stats":state.stats,"slot_stats":state.slot_stats,"integral":state.all_integrals[0],
                    "inventory":info,"maxima":maxima,"unavailable_extrema":unavailable,
                    "complete":maxima.iter().all(|maximum|maximum["complete"]==true)
                        && unavailable.iter().all(|entry|entry["complete"]==true)});
                fs::write(
                    output.join(format!("{mode}_seed{seed}.json")),
                    serde_json::to_string_pretty(&row)?,
                )?;
                report["runs"].as_array_mut().unwrap().push(row);
            }
            for (mode, candidates) in unique_by_mode {
                let mut candidates = candidates.into_values().collect::<Vec<_>>();
                candidates.sort_by(|a, b| {
                    b["ranking_score"]
                        .as_f64()
                        .unwrap()
                        .total_cmp(&a["ranking_score"].as_f64().unwrap())
                });
                for (rank, candidate) in candidates.into_iter().take(2).enumerate() {
                    *integrand.get_mut_settings() = RuntimeSettings::from_file(
                        candidate["settings_path"].as_str().unwrap(),
                        "retained maximum workspace settings",
                    )?;
                    integrand.get_mut_settings().general.generate_events = true;
                    integrand
                        .get_mut_settings()
                        .general
                        .store_additional_weights_in_event = true;
                    integrand.warm_up(model)?;
                    inventory(integrand, &manifest, &mode)?;
                    let sample: Sample<F<f64>> =
                        serde_json::from_value(candidate["complete_sample"].clone())?;
                    eprintln!(
                        "maximum forced Arb mode={mode} rank={} aliases={}",
                        rank + 1,
                        candidate["aliases"]
                    );
                    let start = Instant::now();
                    let native = record(
                        integrand.evaluate_sample_precise(
                            &sample,
                            model,
                            sample.get_weight(),
                            true,
                            Complex::new_zero(),
                        ),
                        start.elapsed().as_secs_f64(),
                    );
                    let mut cuts = native["evaluation"]["events"]
                        .as_array()
                        .into_iter()
                        .flatten()
                        .filter_map(|event| event["cut_info"]["cut_id"].as_u64())
                        .collect::<Vec<_>>();
                    cuts.sort_unstable();
                    let row = json!({"mode":mode,"rank":rank+1,"ranking":"largest complex norms among retained signed-extremum Samples; not unrecorded global complex-norm maxima",
                        "maximum":candidate,"forced_arb":native,
                        "complete":native["evaluation"]["valid"]==true && native["evaluation"]["precision"]=="Arb" && cuts==[0,1,2,3,4,5],
                        "scope":"same complete source/card, max_eval0, native event/decomposition already outer-weighted; checkpoint has no original precision history; validity/coverage only until independent ordinary-versus-Arb numerical audit"});
                    fs::write(
                        output.join(format!("{mode}.attribution_{}.json", rank + 1)),
                        serde_json::to_string_pretty(&row)?,
                    )?;
                    report["attribution"].as_array_mut().unwrap().push(row);
                }
            }
            ensure!(
                report["runs"]
                    .as_array()
                    .unwrap()
                    .iter()
                    .all(|row| row["complete"] == true)
                    && report["attribution"]
                        .as_array()
                        .unwrap()
                        .iter()
                        .all(|row| row["complete"] == true),
                "maximum replay or native attribution failed; all completed records retained"
            );
            Ok(())
        })();
        let after = state_hashes(state_path)?;
        let pilot_after = state_hashes(pilot)?;
        report["state_after"] = json!(after);
        report["pilot_files_after"] = json!(pilot_after);
        report["saved_state_unchanged"] = json!(before == after);
        report["pilot_unchanged"] = json!(pilot_before == pilot_after);
        report["elapsed_seconds"] = json!(at.elapsed().as_secs_f64());
        report["error"] = execution
            .as_ref()
            .err()
            .map(|error| json!(format!("{error:#}")))
            .unwrap_or(Value::Null);
        report["status"] = json!(if execution.is_ok()
            && before == after
            && pilot_before == pilot_after
        {
            "completed"
        } else {
            "failed"
        });
        fs::write(
            output.join("summary.json"),
            serde_json::to_string_pretty(&report)?,
        )?;
        ensure!(
            before == after && pilot_before == pilot_after,
            "immutable state or pilot changed"
        );
        execution
    }
    // Diagnostic entry into the same retained maximum source owner. The scoped
    // subscriber captures existing file.* fields without enabling API state logs.
    pub fn run_maximum_trace() -> Result<()> {
        let args = env::args().skip(2).collect::<Vec<_>>();
        ensure!(
            args.len() == 3,
            "max-replay --trace MANIFEST REQUEST NEW_OUTPUT"
        );
        let manifest: Value = serde_json::from_str(&fs::read_to_string(&args[0])?)?;
        let request: Value = serde_json::from_str(&fs::read_to_string(&args[1])?)?;
        let output = Path::new(&args[2]);
        ensure!(
            !output.exists(),
            "refusing to overwrite native trace evidence"
        );
        fs::create_dir_all(output)?;
        let state_path = Path::new(manifest["state"].as_str().unwrap());
        ensure!(
            !output
                .canonicalize()?
                .starts_with(state_path.canonicalize()?),
            "trace output must be outside generated state"
        );
        for directory in request["immutable_directories"].as_array().unwrap() {
            ensure!(
                !output
                    .canonicalize()?
                    .starts_with(Path::new(directory.as_str().unwrap()).canonicalize()?),
                "trace output must be outside retained pilot/maximum directories"
            );
        }
        let before = state_hashes(state_path)?;
        let expected: BTreeMap<String, String> = serde_json::from_str(&fs::read_to_string(
            manifest["saved_state_hashes"].as_str().unwrap(),
        )?)?;
        ensure!(
            before == expected,
            "trace state differs from reviewed snapshot"
        );
        let mut input_hashes = BTreeMap::new();
        for (path, expected) in request["input_sha256"].as_object().unwrap() {
            let hash = Command::new("sha256sum").arg(path).output()?;
            ensure!(hash.status.success(), "cannot authenticate trace input");
            let actual = String::from_utf8(hash.stdout)?
                .split_whitespace()
                .next()
                .unwrap()
                .to_owned();
            ensure!(
                actual == expected.as_str().unwrap(),
                "changed trace input: {path}"
            );
            input_hashes.insert(path.clone(), actual);
        }
        for path in request["maximum_audits"].as_array().unwrap() {
            let audit: Value = serde_json::from_str(&fs::read_to_string(path.as_str().unwrap())?)?;
            ensure!(
                audit["passed"] == true,
                "native maximum accuracy audit failed"
            );
        }
        let mut report = json!({"status":"started","manifest":args[0],"request":args[1],"input_sha256":input_hashes,
            "state_before":before,"cases":[],"scope":"existing complete-Sample forced-Arb physical owner; existing JSON tracing fields, no root/map implementation or state writes"});
        let started = Instant::now();
        let execution = (|| -> Result<()> {
            initialise()?;
            let mut loaded = StateLoadOption::read_only(state_path).load()?;
            ensure!(
                loaded.is_read_only_state(),
                "read-only generated state required"
            );
            loaded.state.activate_loaded_integrand_backends(false)?;
            let process_id = loaded.state.resolve_process_ref(Some(&ProcessRef::Name(
                manifest["process_name"].as_str().unwrap().to_owned(),
            )))?;
            let model = &loaded.state.model;
            let integrand = loaded
                .state
                .process_list
                .get_integrand_mut(process_id, manifest["integrand_name"].as_str().unwrap())?;
            for case in request["cases"].as_array().unwrap() {
                let id = case["id"].as_str().unwrap();
                ensure!(
                    id.chars().all(|c| c.is_ascii_alphanumeric() || c == '_'),
                    "unsafe trace label"
                );
                let retained: Value = serde_json::from_str(&fs::read_to_string(
                    case["attribution"].as_str().unwrap(),
                )?)?;
                ensure!(
                    retained["complete"] == true
                        && retained["forced_arb"]["evaluation"]["valid"] == true,
                    "incomplete retained maximum control"
                );
                let maximum = &retained["maximum"];
                let mode = retained["mode"].as_str().unwrap();
                let seed = maximum["aliases"][0]["seed"].as_u64().unwrap();
                ensure!(
                    retained["mode"] == case["mode"] && seed == case["seed"].as_u64().unwrap(),
                    "trace case differs from retained maximum identity"
                );
                let settings_path = Path::new(maximum["settings_path"].as_str().unwrap());
                *integrand.get_mut_settings() = RuntimeSettings::from_file(
                    settings_path,
                    "retained maximum workspace settings",
                )?;
                integrand.get_mut_settings().general.generate_events = true;
                integrand
                    .get_mut_settings()
                    .general
                    .store_additional_weights_in_event = true;
                integrand.warm_up(model)?;
                let info = inventory(integrand, &manifest, mode)?;
                let ProcessIntegrand::CrossSection(process) = &*integrand else {
                    return Err(eyre!("cross section required"));
                };
                let term = &process.data.graph_terms[0];
                let geometry_registry = json!({"generation_lmb":term.graph.loop_momentum_basis,"lmbs":term.lmbs,
                    "cut_groups":term.cut_group_data.cut_groups.iter().enumerate().map(|(i,g)| json!({"id":i,"cuts":g.cuts.iter().map(|c|c.0).collect::<Vec<_>>()})).collect::<Vec<_>>(),
                    "cached_real_masses":term.real_mass_vec,"kinematics":integrand.get_settings().kinematics,
                    "scope":"original native parent/routing/cut registry and represented input settings; energy values/star points must be associated with measured native root/center occurrences"});
                let sample: Sample<F<f64>> =
                    serde_json::from_value(maximum["complete_sample"].clone())?;
                let (ids, _, factors) = sample_path(&sample)?;
                ensure!(
                    ids.len() == 2 && ids[0] == 0,
                    "unexpected maximum source group/path"
                );
                let trace_path = output.join(format!("{id}.jsonl"));
                let file = fs::OpenOptions::new()
                    .write(true)
                    .create_new(true)
                    .open(&trace_path)?;
                let subscriber = tracing_subscriber::fmt()
                    .with_ansi(false)
                    .json()
                    .with_current_span(true)
                    .with_span_list(true)
                    .with_env_filter(tracing_subscriber::EnvFilter::try_new(
                        request["trace_filter"].as_str().unwrap(),
                    )?)
                    .with_writer(std::sync::Mutex::new(file))
                    .finish();
                let at = Instant::now();
                let result = tracing::subscriber::with_default(subscriber, || {
                    let span = tracing::info_span!(target: "gammaloop_max_trace", "retained_maximum", case=id, mode, seed, channel=ids[1], precision="Arb");
                    let _entered = span.enter();
                    integrand.evaluate_sample_precise(
                        &sample,
                        model,
                        sample.get_weight(),
                        true,
                        Complex::new_zero(),
                    )
                });
                let native = record(result, at.elapsed().as_secs_f64());
                let trace_events = fs::read_to_string(&trace_path)?
                    .lines()
                    .map(serde_json::from_str::<Value>)
                    .collect::<std::result::Result<Vec<_>, _>>()?;
                let native_center_records = trace_events
                    .iter()
                    .filter(|event| {
                        event["fields"]["stage"] == "lu_threshold_center_values"
                            && event["fields"]["file.active_center"].is_string()
                            && event["fields"]["file.center_with_fixed_complement"].is_string()
                    })
                    .count();
                let fields = [
                    "precision",
                    "valid",
                    "integrand_result",
                    "complete_sample_estimator",
                    "integrator_weight",
                    "parameterization_jacobian",
                    "events",
                ];
                let differences = fields
                    .iter()
                    .filter(|field| {
                        native["evaluation"][**field]
                            != retained["forced_arb"]["evaluation"][**field]
                    })
                    .copied()
                    .collect::<Vec<_>>();
                let mut cuts = native["evaluation"]["events"]
                    .as_array()
                    .into_iter()
                    .flatten()
                    .filter_map(|event| event["cut_info"]["cut_id"].as_u64())
                    .collect::<Vec<_>>();
                cuts.sort_unstable();
                let row = json!({"id":id,"mode":mode,"seed":seed,"source_aliases":maximum["aliases"],"settings_path":settings_path,"source_attribution":case["attribution"],"inventory":info,
                    "geometry_registry":geometry_registry,"complete_sample":sample,"conditional_factors":factors,
                    "canonical_map":maximum["canonical_map"],"native_ordinary_control":maximum["native_ordinary"],
                    "forced_arb_control":retained["forced_arb"],"traced_forced_arb":native,
                    "numeric_control_differences":differences,"trace":trace_path,"trace_bytes":fs::metadata(&trace_path)?.len(),
                    "trace_events":trace_events.len(),"native_center_records":native_center_records,
                    "complete":native["evaluation"]["valid"]==true && native["evaluation"]["precision"]=="Arb" && cuts==[0,1,2,3,4,5] && differences.is_empty() && native_center_records>0});
                fs::write(
                    output.join(format!("{id}.json")),
                    serde_json::to_string_pretty(&row)?,
                )?;
                report["cases"].as_array_mut().unwrap().push(row);
            }
            ensure!(
                report["cases"]
                    .as_array()
                    .unwrap()
                    .iter()
                    .all(|row| row["complete"] == true),
                "trace/control difference retained; no implicit tolerance relaxation"
            );
            Ok(())
        })();
        let after = state_hashes(state_path)?;
        let mut inputs_unchanged = true;
        for (path, expected) in &input_hashes {
            let hash = Command::new("sha256sum").arg(path).output()?;
            inputs_unchanged &= hash.status.success()
                && String::from_utf8(hash.stdout)?.split_whitespace().next()
                    == Some(expected.as_str());
        }
        report["state_after"] = json!(after);
        report["saved_state_unchanged"] = json!(before == after);
        report["inputs_unchanged"] = json!(inputs_unchanged);
        report["elapsed_seconds"] = json!(started.elapsed().as_secs_f64());
        report["error"] = execution
            .as_ref()
            .err()
            .map(|error| json!(format!("{error:#}")))
            .unwrap_or(Value::Null);
        report["status"] = json!(
            if execution.is_ok() && before == after && inputs_unchanged {
                "completed"
            } else {
                "failed"
            }
        );
        fs::write(
            output.join("summary.json"),
            serde_json::to_string_pretty(&report)?,
        )?;
        ensure!(
            before == after && inputs_unchanged,
            "immutable trace inputs changed"
        );
        execution
    }
}

fn main() -> color_eyre::Result<()> {
    std::thread::Builder::new()
        .stack_size(128 * 1024 * 1024)
        .spawn(|| {
            if std::env::args().nth(1).as_deref() == Some("--trace") {
                client::run_maximum_trace()
            } else {
                client::run_max_replay()
            }
        })?
        .join()
        .map_err(|_| color_eyre::eyre::eyre!("maximum replay worker panicked"))?
}

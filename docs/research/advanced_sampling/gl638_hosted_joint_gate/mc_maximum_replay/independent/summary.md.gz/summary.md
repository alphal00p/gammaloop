All three completed maximum batches pass independent audit.

| Batch | Runs | Distinct Samples | Bit-exact signed extrema | Arb controls | Existing accuracy checks |
|---|---:|---:|---:|---:|---:|
| throughput20 | 1 | 3 | 4 | 2 | 51 |
| advanced-firstseed | 6 | 15 | 24 | 12 | 266 |
| all-remaining-seeds | 14 | 41 | 56 | 14 | 552 |

541 independent checks passed. All 336 retained pilot files and 35 state hashes per batch remain unchanged. All 59 ordinary calls use Double and retain six physical cuts; 28 controls use Arb.
Largest ordinary/Arb relative complex errors: total 4.81073e-12, cut 6.28735e-13. All original norm budgets pass; 31 component-relative diagnostics remain visible.

Top-two forced controls are per batch and method among retained signed-extremum Samples, not a global top-two or maximum over unrecorded complex norms. Calls overlapped confirmation; elapsed is provenance, not standalone timing. Physical attribution remains separate.

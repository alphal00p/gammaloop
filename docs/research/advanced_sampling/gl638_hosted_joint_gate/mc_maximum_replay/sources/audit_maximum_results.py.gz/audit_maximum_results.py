#!/usr/bin/env python3
"""Apply the existing native physics metric to completed maximum replay artifacts.

Usage: audit_maximum_results.py MAXIMUM_OUTPUT_DIRECTORY
Never loads a state, reconstructs a grid, or evaluates physics. Events already
include outer Sample weights; comparisons use complete Y in the same units.
"""
from pathlib import Path
from decimal import Decimal as D, localcontext
import copy
import hashlib
import json
import sys
import tomllib
from audit_physical import compare, events, metric, norm, number, vector


def audit(directory):
    summary_path = directory / "summary.json"
    summary = json.loads(summary_path.read_text())
    result = {"passed": False, "checks": [], "scope": "Retained original complete-Sample maximum replays; quantitative native comparisons use the existing norm/cut metric. Top2 attribution is among recorded signed-extremum Samples, not all unrecorded sample norms.",
              "input_sha256": {str(summary_path): hashlib.sha256(summary_path.read_bytes()).hexdigest()},
              "metric_owner_sha256": hashlib.sha256(Path(__file__).with_name("audit_physical.py").read_bytes()).hexdigest()}

    def check(kind, label, run):
        try:
            detail = run()
            entry = {"kind": kind, "label": label, **detail}
        except (OSError, KeyError, TypeError, ValueError, ArithmeticError) as error:
            entry = {"kind": kind, "label": label, "passed": False, "error": str(error)}
        result["checks"].append(entry)

    def require(condition, message):
        if not condition:
            raise ValueError(message)
        return {"passed": True}

    def budget(settings_path, precision):
        path = Path(settings_path)
        settings = tomllib.loads(path.read_text())
        result["input_sha256"][str(path)] = hashlib.sha256(path.read_bytes()).hexdigest()
        if not settings["stability"].get("check_on_norm", True):
            raise ValueError("existing complex-norm criterion requires configured norm stability")
        levels = [level for level in settings["stability"]["levels"] if level["precision"] == precision]
        if not levels:
            raise ValueError(f"missing native precision requirement {precision}")
        return min(min(D(str(level["required_precision_for_re"])), D(str(level["required_precision_for_im"]))) for level in levels)

    def normalized(record):
        # Existing compare expects a total under 'integrand_result'. For raw
        # maximum outputs that field omits the outer grid weight, unlike events.
        current = copy.deepcopy(record)
        current["evaluation"]["integrand_result"] = current["evaluation"]["complete_sample_estimator"]
        return current

    def native_checks(label, record, sample, tolerance):
        evaluation = record["evaluation"]
        require(evaluation["valid"], "invalid native maximum")
        top = sample["Discrete"]
        selected = top[2]["Discrete"]
        require(top[1] == 0, "maximum belongs to a different graph group")
        cut_events = events(evaluation)
        require(all(event["cut_info"]["graph_id"] == 0 and event["cut_info"]["sampling_channel_id"] == selected[1]
                    for event in cut_events.values()), "native event does not match original selected channel")
        total = vector(evaluation["complete_sample_estimator"])
        summed = tuple(sum(vector(event["weight"])[i] for event in cut_events.values()) for i in (0, 1))
        check("native_event_sum", label, lambda: metric(summed, total, tolerance))
        jacobian = number(evaluation["parameterization_jacobian"]) if evaluation["parameterization_jacobian"] is not None else D(1)
        outer = number(evaluation["integrator_weight"])
        expected = tuple(v * jacobian * outer for v in vector(evaluation["integrand_result"]))
        check("native_complete_factor", label, lambda: metric(total, expected, tolerance))
        for cut_id, event in cut_events.items():
            decomposition = event["threshold_counterterms"]
            terms = [vector(decomposition["original"])] + [vector(component["weighted"]) for component in decomposition["components"]]
            summed = tuple(sum(term[i] for term in terms) for i in (0, 1))
            check("native_decomposition", f"{label}:cut{cut_id}",
                  lambda summed=summed, event=event, terms=terms: metric(summed, vector(event["weight"]), tolerance, sum(norm(term) for term in terms)))
        return {"passed": True, "precision": evaluation["precision"], "tolerance": str(tolerance)}

    check("run_completion", "summary", lambda: require(summary["status"] == "completed" and summary["saved_state_unchanged"] and summary["pilot_unchanged"] and summary.get("error") is None, "maximum execution failed or changed immutable inputs"))
    for run in summary["runs"]:
        prefix = f"{run['mode']}:seed{run['seed']}"
        aliases = [alias for maximum in run["maxima"] for alias in maximum["aliases"]] + run["unavailable_extrema"]
        check("extremum_coverage", prefix, lambda aliases=aliases: require(
            sorted((alias["phase"], alias["sign"]) for alias in aliases)
            == [("im", "negative"), ("im", "positive"), ("re", "negative"), ("re", "positive")],
            "missing or duplicated signed extremum"))
        for unavailable in run["unavailable_extrema"]:
            check("unavailable_extremum", prefix + str(unavailable), lambda unavailable=unavailable: require(unavailable["stored_maximum"] == 0, "nonzero maximum has no complete Sample"))
        for maximum in run["maxima"]:
            label = prefix + ":" + ",".join(f"{a['phase']}{a['sign']}" for a in maximum["aliases"])
            check("original_reporting_replay", label, lambda maximum=maximum: require(all(a.get("passed", False) for a in maximum["aliases"]), "stored maximum replay mismatch"))
            check("native_ordinary", label, lambda maximum=maximum, label=label, run=run:
                  native_checks(label, maximum["native_ordinary"], maximum["complete_sample"], budget(run["settings_path"], maximum["native_ordinary"]["evaluation"]["precision"])))
    for row in summary["attribution"]:
        candidate = row["maximum"]
        label = f"{row['mode']}:rank{row['rank']}"

        def precision_pair(row=row, candidate=candidate, label=label):
            ordinary = candidate["native_ordinary"]
            arb = row["forced_arb"]
            require(arb["evaluation"]["precision"] == "Arb", "forced control did not use Arb")
            ordinary_budget = budget(candidate["settings_path"], ordinary["evaluation"]["precision"])
            arb_budget = budget(candidate["settings_path"], "Arb")
            native_checks(label + ":Arb", arb, candidate["complete_sample"], arb_budget)
            return compare(normalized(ordinary), normalized(arb), ordinary_budget + arb_budget)

        check("native_ordinary_vs_arb", label, precision_pair)
    check("attribution_coverage", "modes", lambda: require(
        {r["mode"] for r in summary["attribution"]} == {r["mode"] for r in summary["runs"]},
        "a declared method has no native precision attribution"))
    result["passed"] = bool(result["checks"]) and all(check["passed"] for check in result["checks"])
    result["counts"] = {"checks": len(result["checks"]), "failed": sum(not check["passed"] for check in result["checks"])}
    return result


def main():
    if len(sys.argv) != 2:
        raise SystemExit(__doc__)
    directory = Path(sys.argv[1])
    try:
        with localcontext() as context:
            context.prec = 350
            result = audit(directory)
    except (OSError, KeyError, TypeError, ValueError, ArithmeticError) as error:
        result = {"passed": False, "error": str(error), "scope": "missing/schema-invalid retained results; no physics run performed"}
    (directory / "maximum_accuracy_audit.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"passed": result["passed"], "counts": result.get("counts"), "error": result.get("error")}))
    return 0 if result["passed"] else 1


if __name__ == "__main__":
    sys.exit(main())

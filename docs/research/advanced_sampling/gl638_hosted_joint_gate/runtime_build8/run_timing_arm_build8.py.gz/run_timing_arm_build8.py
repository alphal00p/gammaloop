from pathlib import Path
import datetime, hashlib, json, os, resource, subprocess, sys, time
root=Path('/tmp/gl638-symjit-next')
arm=sys.argv[1]
assert arm in ['eager','symjit_o2_compress_on','symjit_o2_compress_off']
out=root/('results-'+arm+'-build8')
assert not out.exists()
env=os.environ.copy()
if arm.startswith('symjit'):
    suffix='on' if arm.endswith('_on') else 'off'
    env['SYMJIT_TOML']=str(root/'configs'/('symjit-o2-compress-'+suffix+'.toml'))
else:
    env.pop('SYMJIT_TOML',None)
argv=[str(root/'gate-timing-build8'),str(root/'request-timing-frozen-build8.json'),arm,str(out)]
def snapshot():
    return subprocess.check_output(['ps','-eo','pid,ppid,etimes,pcpu,rss,comm','--sort=-pcpu'],text=True).splitlines()[:18]
record={'arm':arm,'argv':argv,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'affinity':sorted(os.sched_getaffinity(0)),'background_before':snapshot(),'concurrency_scope':'only owned Gamma job; unrelated shared-host workloads remain','SYMJIT_TOML':env.get('SYMJIT_TOML'),'RAYON_NUM_THREADS':env.get('RAYON_NUM_THREADS')}
start=time.monotonic()
with (root/('run-'+arm+'-build8.log')).open('w') as log:
    result=subprocess.run(argv,env=env,stdout=log,stderr=subprocess.STDOUT)
record.update(returncode=result.returncode,elapsed_seconds=time.monotonic()-start,max_rss_kib=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,background_after=snapshot(),finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
(root/('run-'+arm+'-build8.json')).write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:record[k] for k in ['arm','returncode','elapsed_seconds','max_rss_kib']}),flush=True)
sys.exit(result.returncode)

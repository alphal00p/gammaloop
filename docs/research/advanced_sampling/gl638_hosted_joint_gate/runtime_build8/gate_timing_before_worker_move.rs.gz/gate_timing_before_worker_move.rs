// Bounded fixed-input compiler benchmark. Existing State, Grid, worker clones,
// raw physical evaluation and native serializers own the complete computation.
// No generated-state write or integration/statistics engine is added here.
mod client {
    include!("gate_timing_support.rs");
    use gammalooprs::{
        integrands::process::{EvaluationTarget, evaluators::ActiveF64Backend},
        utils::serde_utils::SmartSerde,
        settings::{
            RuntimeSettings,
            global::{CompilationOptimizationLevel, FrozenCompilationMode},
        },
    };
    use rayon::prelude::*;
    use std::time::Duration;

    fn digest(path: &Path) -> Result<String> {
        let output = Command::new("sha256sum").arg(path).output()?;
        ensure!(output.status.success(), "cannot hash {}", path.display());
        Ok(String::from_utf8(output.stdout)?
            .split_whitespace()
            .next()
            .ok_or_else(|| eyre!("empty hash"))?
            .to_owned())
    }

    pub fn run_timing() -> Result<()> {
        let args = env::args().skip(1).collect::<Vec<_>>();
        ensure!(
            args.len() == 3,
            "gate-timing REQUEST prepare|eager|symjit_o2_compress_off|symjit_o2_compress_on OUTPUT"
        );
        let request: Value = serde_json::from_str(&fs::read_to_string(&args[0])?)?;
        let arm = args[1].as_str();
        ensure!(
            [
                "prepare",
                "eager",
                "symjit_o2_compress_off",
                "symjit_o2_compress_on"
            ]
            .contains(&arm),
            "unknown arm"
        );
        let manifest: Value =
            serde_json::from_str(&fs::read_to_string(request["manifest"].as_str().unwrap())?)?;
        let state_path = Path::new(manifest["state"].as_str().unwrap());
        let output = Path::new(&args[2]);
        ensure!(!output.exists(), "refusing to overwrite benchmark output");
        fs::create_dir_all(output)?;
        ensure!(
            !output
                .canonicalize()?
                .starts_with(state_path.canonicalize()?),
            "output must be outside state"
        );
        let mut input_hashes = BTreeMap::new();
        for (path, expected) in request["input_sha256"]
            .as_object()
            .ok_or_else(|| eyre!("missing input hashes"))?
        {
            let actual = digest(Path::new(path))?;
            ensure!(
                Some(actual.as_str()) == expected.as_str(),
                "input changed: {path}"
            );
            input_hashes.insert(path.clone(), actual);
        }
        let before = state_hashes(state_path)?;
        let expected: BTreeMap<String, String> = serde_json::from_str(&fs::read_to_string(
            manifest["saved_state_hashes"].as_str().unwrap(),
        )?)?;
        ensure!(
            before == expected && before.len() == 35,
            "saved-state identity mismatch"
        );
        let mut report = json!({"status":"started", "request":args[0], "arm":arm,
            "input_sha256":input_hashes,"state_before":before,"controls":[],"timing":[],
            "source_scope":"same frozen complete Samples, unchanged outer grid weights once; no rate or variance estimate",
            "timing_scope":"raw physical API including ordinary rescues; sums of worker Durations are separate from global wall time; no clamp or primary-only E"});
        report["executable_sha256"] = json!(digest(&env::current_exe()?)?);
        report["driver_source_sha256"] = json!(digest(Path::new(file!()))?);
        report["support_source_sha256"] = json!(digest(
            &Path::new(file!()).with_file_name("gate_timing_support.rs")
        )?);
        if arm != "prepare" {
            let record_path = Path::new(
                request["build_record"]
                    .as_str()
                    .ok_or_else(|| eyre!("completed driver build record required"))?,
            );
            report["build_record"] = serde_json::from_str(&fs::read_to_string(record_path)?)?;
            report["build_record_sha256"] = json!(digest(record_path)?);
            ensure!(
                report["build_record"]["status"] == "compiled"
                    && report["build_record"]["returncode"] == 0
                    && report["build_record"]["source_sha256"] == report["driver_source_sha256"]
                    && report["build_record"]["binary_sha256"] == report["executable_sha256"],
                "completed build record does not identify this executable/source"
            );
        }
        let total_started = Instant::now();
        let execution = (|| -> Result<()> {
            initialise()?;
            let load_started = Instant::now();
            let mut loaded = StateLoadOption::read_only(state_path).load()?;
            ensure!(loaded.is_read_only_state(), "read-only load required");
            let process_id = loaded.state.resolve_process_ref(Some(&ProcessRef::Name(
                manifest["process_name"].as_str().unwrap().to_owned(),
            )))?;
            let name = manifest["integrand_name"].as_str().unwrap();
            {
                let integrand = loaded
                    .state
                    .process_list
                    .get_integrand_mut(process_id, name)?;
                report["original_generation_backend"] = json!(integrand.frozen_compilation());
                ensure!(
                    matches!(integrand.frozen_compilation(), FrozenCompilationMode::Eager),
                    "frozen Eager control required"
                );
                if arm.starts_with("symjit") {
                    let configured = Path::new(
                        request["configs"][arm]
                            .as_str()
                            .ok_or_else(|| eyre!("missing complete JIT config"))?,
                    );
                    ensure!(
                        Path::new(
                            &env::var("SYMJIT_TOML")
                                .wrap_err("set SYMJIT_TOML before process startup")?
                        )
                        .canonicalize()?
                            == configured.canonicalize()?,
                        "wrong JIT config environment"
                    );
                    report["symjit_toml"] = json!({"path":configured,"sha256":digest(configured)?});
                    let ProcessIntegrand::CrossSection(process) = integrand else {
                        return Err(eyre!("cross section required"));
                    };
                    // This existing public field steers existing runtime activation only.
                    // Preserve the original label above and never serialize the loaded state.
                    process.data.compilation =
                        FrozenCompilationMode::Symjit(CompilationOptimizationLevel::O2);
                }
            }
            report["load_seconds"] = json!(load_started.elapsed().as_secs_f64());
            let activated = Instant::now();
            loaded.state.activate_loaded_integrand_backends(false)?;
            report["backend_activation_seconds"] = json!(activated.elapsed().as_secs_f64());
            let model = &loaded.state.model;
            let integrand = loaded
                .state
                .process_list
                .get_integrand_mut(process_id, name)?;
            let expected_backend = if arm.starts_with("symjit") {
                ActiveF64Backend::Symjit
            } else {
                ActiveF64Backend::Eager
            };
            ensure!(
                integrand.active_f64_backend() == expected_backend,
                "requested backend did not activate"
            );
            report["active_f64_backend"] = json!(integrand.active_f64_backend());
            report["effective_runtime_compilation"] = json!(integrand.frozen_compilation());
            *integrand.get_mut_settings() = RuntimeSettings::from_file(
                request["settings"].as_str().unwrap(),
                "frozen compiler benchmark settings",
            )?;
            let warm = Instant::now();
            integrand.warm_up(model)?;
            report["warm_up_seconds"] = json!(warm.elapsed().as_secs_f64());
            ensure!(
                integrand.active_f64_backend() == expected_backend,
                "warmup changed backend"
            );
            report["inventory"] =
                inventory(integrand, &manifest, request["mode"].as_str().unwrap())?;
            report["settings"] = json!(integrand.get_settings());
            let n = request["samples"].as_u64().unwrap() as usize;
            ensure!((20..=1024).contains(&n), "bounded source count required");
            if arm == "prepare" {
                let mut grid = integrand.create_grid();
                let mut rng = MonteCarloRng::new(request["seed"].as_u64().unwrap(), 0);
                let samples = (0..n)
                    .map(|_| {
                        let mut sample = Sample::new();
                        grid.sample(&mut rng, &mut sample);
                        sample
                    })
                    .collect::<Vec<_>>();
                let deck = json!({"samples":samples,"seed":request["seed"],"settings_sha256":digest(Path::new(request["settings"].as_str().unwrap()))?,"mode":request["mode"],"scope":"existing initial Grid::sample only, no evaluation, adaptation or integration"});
                fs::write(
                    output.join("samples.json"),
                    serde_json::to_string_pretty(&deck)?,
                )?;
                report["sample_deck_sha256"] = json!(digest(&output.join("samples.json"))?);
                return Ok(());
            }
            let deck_path = Path::new(
                request["sample_deck"]
                    .as_str()
                    .ok_or_else(|| eyre!("freeze source deck first"))?,
            );
            ensure!(
                Some(digest(deck_path)?.as_str()) == request["sample_deck_sha256"].as_str(),
                "source deck hash changed"
            );
            let deck: Value = serde_json::from_str(&fs::read_to_string(deck_path)?)?;
            ensure!(
                deck["settings_sha256"]
                    == json!(digest(Path::new(request["settings"].as_str().unwrap()))?)
                    && deck["mode"] == request["mode"],
                "deck settings changed"
            );
            let samples: Vec<Sample<F<f64>>> = serde_json::from_value(deck["samples"].clone())?;
            ensure!(samples.len() == n, "sample count changed");
            report["sample_deck_sha256"] = request["sample_deck_sha256"].clone();
            // Diagnostics are separate clones. Retention does not affect the timed settings.
            for path in request["controls"]
                .as_array()
                .ok_or_else(|| eyre!("missing native controls"))?
            {
                let path = Path::new(path.as_str().unwrap());
                let old: Value = serde_json::from_str(&fs::read_to_string(path)?)?;
                ensure!(
                    old["complete"] == true && old["mode"] == request["mode"],
                    "wrong retained control"
                );
                let sample: Sample<F<f64>> =
                    serde_json::from_value(old["maximum"]["complete_sample"].clone())?;
                let mut diagnostic = integrand.clone();
                diagnostic.get_mut_settings().general.generate_events = true;
                diagnostic
                    .get_mut_settings()
                    .general
                    .store_additional_weights_in_event = true;
                diagnostic.warm_up(model)?;
                let mut ids = Vec::new();
                let mut leaf = &sample;
                while let Sample::Discrete(_, id, Some(child)) = leaf {
                    ids.push(*id);
                    leaf = child;
                }
                let Sample::Continuous(_, cube) = leaf else {
                    return Err(eyre!("invalid retained source"));
                };
                ensure!(ids.len() == 2 && ids[0] == 0, "unexpected source nesting");
                let ProcessIntegrand::CrossSection(process) = &diagnostic else {
                    unreachable!()
                };
                let native_cube = cube
                    .iter()
                    .map(|x| ArbPrec::from_f64_exact_binary(x.0))
                    .collect::<Vec<_>>();
                let mapped = process.data.graph_terms[0]
                    .sampling_setup()
                    .sampling_bridge::<ArbPrec>()?
                    .forward(SamplingChannelId(ids[1]), &native_cube)?;
                let canonical = approach_map(&mapped)?;
                let mut control = json!({"artifact":path,"sha256":digest(path)?,"complete_sample":sample,"canonical_map":canonical,"canonical_map_exact":canonical == old["maximum"]["canonical_map"],"calls":[]});
                for force_arb in [false, true] {
                    let start = Instant::now();
                    let value = diagnostic.evaluate_sample_precise(
                        &sample,
                        model,
                        sample.get_weight(),
                        force_arb,
                        Complex::new_zero(),
                    );
                    control["calls"].as_array_mut().unwrap().push(json!({"force_arb":force_arb,"native":record(value,start.elapsed().as_secs_f64())}));
                }
                report["controls"].as_array_mut().unwrap().push(control);
            }
            fs::write(
                output.join("controls.json"),
                serde_json::to_string_pretty(&report)?,
            )?;
            let accepted = Command::new("python")
                .arg(request["control_auditor"].as_str().unwrap())
                .arg(output)
                .status()?;
            ensure!(
                accepted.success(),
                "backend numerical control failed; timing not started"
            );
            report["control_audit"] =
                serde_json::from_str(&fs::read_to_string(output.join("control_audit.json"))?)?;
            ensure!(
                report["control_audit"]["passed"] == true,
                "numerical control audit did not pass"
            );
            let repetitions = request["repetitions"].as_u64().unwrap() as usize;
            ensure!(
                (1..=4).contains(&repetitions),
                "bounded repetitions required"
            );
            for workers in [1usize, 20] {
                let pool = rayon::ThreadPoolBuilder::new()
                    .num_threads(workers)
                    .stack_size(128 * 1024 * 1024)
                    .build()?;
                let warm = Instant::now();
                let prepared = pool.install(|| {
                    (0..workers)
                        .map(|worker| {
                            (
                                integrand.clone(),
                                &samples[n * worker / workers..n * (worker + 1) / workers],
                            )
                        })
                        .collect::<Vec<_>>()
                        .into_par_iter()
                        .map(|(mut worker, part)| -> Result<_> {
                            // Actual calls populate clone-local caches; do not re-warm the maps.
                            let warmed = worker.evaluate_samples_raw(
                                EvaluationTarget::Physical(model),
                                &part[..part.len().min(2)],
                                0,
                                false,
                                true,
                                Complex::new_zero(),
                            )?;
                            ensure!(
                                warmed.samples.len() == part.len().min(2)
                                    && warmed.samples.iter().all(|r| !r.evaluation_metadata.is_nan
                                        && r.evaluation_metadata
                                            .stability_results
                                            .last()
                                            .is_some_and(|s| !matches!(
                                                s.status,
                                                StabilityStatus::Unstable(_)
                                            ))),
                                "worker warm calls failed"
                            );
                            Ok((worker, part))
                        })
                        .collect::<Result<Vec<_>>>()
                })?;
                let warm_seconds = warm.elapsed().as_secs_f64();
                let started = Instant::now();
                let completed = pool.install(|| {
                    prepared
                        .into_par_iter()
                        .enumerate()
                        .map(|(worker_id, (mut worker, part))| -> Result<_> {
                            let mut batches = Vec::new();
                            for repetition in 0..repetitions {
                                let started = Instant::now();
                                let result = worker.evaluate_samples_raw(
                                    EvaluationTarget::Physical(model),
                                    part,
                                    0,
                                    false,
                                    true,
                                    Complex::new_zero(),
                                );
                                let elapsed = started.elapsed();
                                batches.push((repetition, elapsed, result));
                            }
                            Ok((worker_id, part.len(), batches))
                        })
                        .collect::<Result<Vec<_>>>()
                })?;
                let wall = started.elapsed();
                let mut rows = Vec::new();
                for (worker_id, count, batches) in completed {
                    for (repetition, elapsed, result) in batches {
                        let batch = match result {
                            Ok(batch) => batch,
                            Err(error) => {
                                rows.push(json!({"worker":worker_id,"repetition":repetition,"count":count,
                                    "worker_wall":elapsed,"passed":false,"error":format!("{error:#}"),
                                    "scope":"raw batch error owner does not expose partial results; rejected-call wall is not evaluator attribution"}));
                                continue;
                            }
                        };
                        let mut failures = Vec::new();
                        if batch.samples.len() != count {
                            failures.push("interrupted timing batch");
                        }
                        let mut s = Duration::ZERO;
                        let mut p = Duration::ZERO;
                        let mut cs = Duration::ZERO;
                        let mut cp = Duration::ZERO;
                        let mut e = Duration::ZERO;
                        let mut events = Duration::ZERO;
                        for value in &batch.samples {
                            let m = &value.evaluation_metadata;
                            if !(!m.is_nan
                                && value.integrand_result.re.0.is_finite()
                                && value.integrand_result.im.0.is_finite()
                                && m.stability_results.last().is_some_and(|r| {
                                    !matches!(r.status, StabilityStatus::Unstable(_))
                                }))
                            {
                                failures.push("invalid physical timing result");
                            }
                            if !(m.canonical_sampling_preparation_time <= m.parameterization_time
                                && m.evaluator_evaluation_time
                                    + m.canonical_physical_preparation_time
                                    + m.event_processing_time
                                    <= m.integrand_evaluation_time)
                            {
                                failures.push("invalid per-sample timing subsets");
                            }
                            s += m.parameterization_time;
                            p += m.integrand_evaluation_time;
                            cs += m.canonical_sampling_preparation_time;
                            cp += m.canonical_physical_preparation_time;
                            e += m.evaluator_evaluation_time;
                            events += m.event_processing_time;
                        }
                        if elapsed < s + p {
                            failures.push("worker S+P exceeds raw batch wall");
                        }
                        rows.push(json!({"worker":worker_id,"repetition":repetition,"count":count,
                            "source_range":[n*worker_id/workers,n*(worker_id+1)/workers],
                            "passed":failures.is_empty(),"failures":failures,"worker_wall":elapsed,
                            "S":s,"P":p,"C_S":cs,"C_P":cp,"E_all":e,"events":events,
                            "sampling_other":s.checked_sub(cs),"physical_other":p.checked_sub(e+cp+events),
                            "outer_other":elapsed.checked_sub(s+p),"raw_evaluations":batch.samples}));
                    }
                }
                let passed = rows.iter().all(|row| row["passed"] == true);
                report["timing"].as_array_mut().unwrap().push(json!({"passed":passed,"workers":workers,"draws":n*repetitions,"global_wall":wall,"samples_per_second":(n*repetitions) as f64/wall.as_secs_f64(),"clone_warm_seconds":warm_seconds,"worker_rows":rows}));
                fs::write(
                    output.join("progress.json"),
                    serde_json::to_string_pretty(&report)?,
                )?;
            }
            ensure!(
                report["timing"]
                    .as_array()
                    .unwrap()
                    .iter()
                    .all(|row| row["passed"] == true),
                "failed numerical or timing rows retained; no speedup acceptance"
            );
            Ok(())
        })();
        report["total_seconds"] = json!(total_started.elapsed().as_secs_f64());
        let after = state_hashes(state_path)?;
        report["state_after"] = json!(after);
        report["saved_state_unchanged"] = json!(before == after);
        report["error"] = execution
            .as_ref()
            .err()
            .map(|e| json!(format!("{e:#}")))
            .unwrap_or(Value::Null);
        report["status"] = json!(if execution.is_ok() && before == after {
            "completed"
        } else {
            "failed"
        });
        fs::write(
            output.join("summary.json"),
            serde_json::to_string_pretty(&report)?,
        )?;
        execution?;
        ensure!(before == after, "generated state changed");
        Ok(())
    }
}
fn main() -> color_eyre::Result<()> {
    client::run_timing()
}

#!/usr/bin/env python3
"""Artifact-only compiler controls; reuse the existing native complex-norm owner."""
from decimal import Decimal as D, localcontext
from pathlib import Path
import copy
import hashlib
import json
import sys
import tomllib
from audit_physical import compare, events, metric, norm, number, vector


def audit(directory):
    report = json.loads((directory / "controls.json").read_text())
    request = json.loads(Path(report["request"]).read_text())
    settings = tomllib.loads(Path(request["settings"]).read_text())
    result = {"passed": False, "decimal_precision": 350, "checks": [], "component_relative_misses": [],
              "criteria": "Existing audit_physical.compare: total complex norm, six cut norms with complete-total scale floor, exact whole zero. Sum of actual final-lane requirements; nearzero component misses retained. Complete Sample weight once; event weights already contain it.",
              "input_sha256": {}}

    def checked(kind, label, detail):
        result["checks"].append({"kind": kind, "label": label, **detail})
        for where, entry in [("total", detail.get("total", {}))] + [(f"cut{c['cut_id']}", c) for c in detail.get("cuts", [])]:
            for phase, component in entry.get("components", {}).items():
                if not component["own_relative_budget_passed"]:
                    result["component_relative_misses"].append({"label": label, "where": where, "phase": phase, **component})

    def require(condition, label):
        checked("identity", label, {"passed": bool(condition)})

    def retain(path):
        path = Path(path).resolve(strict=True)
        value = hashlib.sha256(path.read_bytes()).hexdigest()
        result["input_sha256"][str(path)] = value
        return value

    for path in [directory / "controls.json", report["request"], request["settings"], __file__, Path(__file__).with_name("audit_physical.py")]:
        retain(path)
    for path, expected in request["input_sha256"].items():
        require(retain(path) == expected, f"unchanged input {path}")
    require(settings["stability"].get("check_on_norm", True), "configured complex-norm acceptance")
    budgets = {}
    for level in settings["stability"]["levels"]:
        value = min(D(str(level["required_precision_for_re"])), D(str(level["required_precision_for_im"])))
        if not value.is_finite() or value <= 0:
            raise ValueError("invalid precision requirement")
        budgets[level["precision"]] = min(value, budgets.get(level["precision"], value))
    result["precision_budgets"] = {p: str(v) for p, v in budgets.items()}
    require(len(report["controls"]) == len(request["controls"]) > 0, "complete declared controls")

    def completed(record):
        # The native record deliberately preserves the unapplied outer factor.
        # Compare complete Y; returned six events already have that factor.
        value = copy.deepcopy(record)
        value["evaluation"]["integrand_result"] = value["evaluation"]["complete_sample_estimator"]
        return value

    def evaluate_pair(kind, label, left, right):
        tolerance = budgets[left["evaluation"]["precision"]] + budgets[right["evaluation"]["precision"]]
        checked(kind, label, compare(completed(left), completed(right), tolerance))

    for control in report["controls"]:
        path = Path(control["artifact"])
        old = json.loads(path.read_text())
        label = path.name
        require(str(path) in request["controls"] and retain(path) == control["sha256"], label + " retained artifact")
        require(old["complete"] and control["complete_sample"] == old["maximum"]["complete_sample"], label + " exact complete Sample")
        require(control["canonical_map_exact"] is True and control["canonical_map"] == old["maximum"]["canonical_map"], label + " exact canonical point/J/partition")
        old_settings = tomllib.loads(Path(old["maximum"]["settings_path"]).read_text())
        retain(old["maximum"]["settings_path"])
        # Seed/N describe the historical independent MC slot, not the physical body.
        require({k:v for k,v in old_settings.items() if k != "integrator"} == {k:v for k,v in settings.items() if k != "integrator"}, label + " unchanged physical and sampling settings")
        calls = control["calls"]
        require([r["force_arb"] for r in calls] == [False, True], label + " ordinary and forced-Arb controls")
        for call in calls:
            native = call["native"]
            evaluation = native["evaluation"]
            require(evaluation.get("valid") is True, label + " finite stable native call")
            require(not call["force_arb"] or evaluation["precision"] == "Arb", label + " forced-Arb lane")
            cut_events = events(evaluation)
            tolerance = budgets[evaluation["precision"]]
            total = vector(evaluation["complete_sample_estimator"])
            expected = tuple(x * number(evaluation["integrator_weight"]) * (number(evaluation["parameterization_jacobian"]) if evaluation["parameterization_jacobian"] is not None else D(1)) for x in vector(evaluation["integrand_result"]))
            checked("factor_once", label, metric(total, expected, tolerance))
            summed = tuple(sum(vector(event["weight"])[i] for event in cut_events.values()) for i in range(2))
            checked("six_cut_sum", label, metric(summed, total, tolerance, sum(norm(vector(e["weight"])) for e in cut_events.values())))
            evaluate_pair("new_vs_build7_arb", label + str(call["force_arb"]), native, old["forced_arb"])
        evaluate_pair("ordinary_vs_forced_arb", label, calls[0]["native"], calls[1]["native"])
    result["failed_checks"] = sum(not c["passed"] for c in result["checks"])
    result["passed"] = result["failed_checks"] == 0
    return result


def main():
    directory = Path(sys.argv[1])
    try:
        with localcontext() as context:
            context.prec = 350
            result = audit(directory)
    except (KeyError, ValueError, TypeError, OSError, ArithmeticError) as error:
        result = {"passed": False, "error": str(error)}
    (directory / "control_audit.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({k:result[k] for k in ["passed", "failed_checks", "error"] if k in result}))
    return 0 if result["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())

# SymJIT O2/compression: bounded next implementation

As checked on 2026-09-14, the current published Rust release is **SymJIT 2.25.6**,
released 2026-09-12, not the 2.21/2.23 versions shown by stale search results.
The live [registry response](https://crates.io/api/v1/crates/symjit) is retained
as `crates-metadata.json`. The published `.crate` matches registry checksum
`97114f6aba423d7a6a1336992ce0e5140e56a5176cce1a72ab252b5560ede2fe`;
its VCS marker is `3fc04010f69db954463f9666fffb652b244ccc52`. Source was downloaded
to this scratch directory for inspection, without installation, Cargo or builds.

The official [changelog](https://raw.githubusercontent.com/siravan/symjit/v225/CHANGELOG.md)
describes the newer compression mode at 2.23 and its extension to other
architectures at 2.25. In the published code, `compact` reuses stack slots while
`compress` selects shared instruction/function fragments; they are independent
flags. O2 enables greedy register allocation. Compression can be enabled while
keeping compaction disabled. This comparison should stay at O2: O3/“ultramode”
is a separate optimization choice, outside the requested first comparison.
The [configuration owner](https://raw.githubusercontent.com/siravan/symjit-crate/3fc04010f69db954463f9666fffb652b244ccc52/src/symjit/config.rs)
accepts both options and the existing `SYMJIT_TOML` process configuration.

## Existing owners and minimal dependency scope

- At initial inspection, `Cargo.lock:4730` pinned SymJIT 2.21.0; root has since
  updated only that dependency to 2.25.6. `Cargo.toml:77–79` pins the Symbolica,
  Numerica and Graphica fork to `a277a8dadbaae5a8d6605f2f381991a601e1f345`.
  That exact Symbolica checkout declares `symjit = "2.21"`, which permits 2.25.6.
  The narrow first candidate is root's targeted lock update
  `cargo update -p symjit --precise 2.25.6`, reviewing its actual transitive delta.
  No full Symbolica/fork update is needed merely to request compression.
- Exact active Symbolica source is
  `/home/codex-1/.cargo/git/checkouts/symbolica-7e92af2066df6214/a277a8d/`.
  `src/evaluate/backend.rs:324–376` already owns
  `JITCompilationSettings::optimization_level(2).with_option("compress", "true")`.
  Its Translator/Composer, Config and Applet calls are still present in 2.25.6;
  this is a source-level compatibility assessment, not a successful compilation.
  `/common/dev/symbolica_gl638` also declares 2.21. The separate
  `/common/dev/symbolica` development tree declares 2.24 and has broader feature
  changes; it is not the source of the current GL638 binary.
- `integrands/process/evaluators.rs:1275` activates the same eager numeric program
  for SymJIT and explicitly sets `compact=false` for O≤2, preserving rational
  constant mapping. Keep that guard initially; it is not a compression switch.
  The equivalent standalone owners are `amplitude/load.rs:1055` and
  `amplitude/standalone_template.rs:486`. Preserve/update their comments when the
  version changes; do not remove the historical compaction rationale without
  its own complex-program validation.
- `cross_section/mod.rs:263–375` and `amplitude/mod.rs:2261–2373` already traverse
  and activate existing evaluators after load. Compilation belongs before warmup
  and repeated sampling, with cold-load/JIT time and peak RSS reported separately.
  Runtime caches rebuild from the retained program; reuse the saved state read
  only and record the actual active f64 backend through the existing display
  owner. A stored generation backend label alone does not prove active SymJIT.
- `GenericEvaluatorFloat for f64` selects SymJIT; `for f128` and `for ArbPrec`
  (`evaluators.rs:1760,1815`) remain eager. Raised dual packets still use the
  existing flattened-output/reconstruction owner. No Quad/Arb JIT path, numeric
  conversion change, proposal change or physical-tolerance change is part of this.

## Compression steering without another settings layer

Use the existing upstream `SYMJIT_TOML` for the benchmark process. The Symbolica
owner reads `Config::default`, then applies O2/direct=false/compact=false; other
options, including compress, survive. Keep `debug.lock=false` so the native type
and explicit owner settings remain authoritative. Do not introduce a second
GammaLoop backend/configuration registry just for this experiment.

A supplied TOML uses serde defaults for omitted options, so **a one-line
`compress=true` file would also disable unrelated defaults**. Freeze complete
option files preserving current use_simd/cse/fastmath/fast_complex/parallel_mul,
with use_threads=false, huge=false, SIMD512=false and direct=false. Vary only
`compress=false/true`; keep compact=false, O2. New direct-arena flags are inactive
under direct=false, but record them explicitly. Record the TOML hash, cwd and
`SYMJIT_TOML` in build/run provenance. Version 2.21 reads cwd `symjit.toml` rather
than the newer env path, so a historical comparison must use matching complete
files at the applicable boundary. There is no setting-independent default claim.

Authorized first matrix: newly instrumented Eager versus 2.25.6 O2/compress-on,
each at 1 and 20 actual workers. Latest O2/compress-off is an optional third arm
to isolate compression. The historical GL638 state used Eager, so a 2.21 JIT arm
is unnecessary.
Compact-on is optional later and should not be combined with the initial change.
If the project later chooses a permanent default, set it at the existing
`activate_symjit` owner and keep standalone behavior consistent; benchmark results
must precede that choice. No such default has been changed here.

SymJIT's serialization field `compressed_ir` is different from runtime code
compression. Do not use evaluator serialization size as a machine-code-size
claim. Upstream `debug.stats`/`Application::dump("stats")` can capture code statistics
during untimed preparation; Symbolica's Applet field is private, so no extra
public accessor is needed initially. Existing RSS/load measurements remain useful.

## Timing correction before claiming separated costs

Before this authorized timing slice, the counters were deliberately asymmetric:

- `parameterization_time` = S, all canonical/native map, partition and adoption work.
- `integrand_evaluation_time` = P, all actual physical calls/probes/retries, excluding
  nested sampling work (`process/mod.rs:3347–3421`).
- `canonical_physical_preparation_time` = C_P, the existing physical center/root
  prepass, a subset of P. It is not canonical sampling preparation.
- `evaluator_evaluation_time` counted only the first precision level's
  primary rotation (`process/mod.rs:3505`; wrappers in `evaluators.rs:119–156`).
  Consequently the old P−E contained other evaluator calls and was not pure
  physical overhead. The old `bench` display must not be read as a complete split.

Smallest coherent source slice: time **both existing evaluator wrappers on every
call**, remove their obsolete timing-flag argument at callsites, and update the
metadata description and existing benchmark expectations. Keep other primary
flags where they control event/diagnostic semantics. Callsites include
`amplitude/mod.rs`, `cross_section/mod.rs`, `subtraction/lu_counterterm.rs`; no
second timer around outer evaluator/CT bodies, which would double count.
Exercise successful primary/probe/retry paths and a failing target that has already
performed evaluator work. Timing elapsed should be captured once per wrapper.

For canonical-source attribution, add one subset counter C_S at the existing
`EvaluationSource::prepare_draw` timer (`process/mod.rs:4010–4043`), including failed
preparation and keeping the same elapsed in S. A agrees this is the right owner.
Do not subtract C_S from P or sum C_P twice. This requires the metadata/default/
aggregation/output owner in `integrands/evaluation.rs`, plus the existing bench
row aggregation if shown there. Report S, C_S, S−C_S, E_all, C_P, P−E_all−C_P and
T−S−P; the latter two are respectively other physical work and outer evaluation
work, not interchangeable overhead labels. Events, parameter construction,
root/CT solves and summation reside in the remaining physical work unless already
reported as separate nonoverlapping subsets.

Potential shared files: `process/mod.rs` and `integrands/evaluation.rs` for C_S;
`evaluators.rs` plus amplitude/cross_section/lu_counterterm callsites for E_all;
`gammaloop-api/src/commands/bench.rs` for its existing display/tests. A's separately authorized private-certificate refinement is confined to
`sampling_joint.rs`; it does not change the native source precision. The timing
slice was authorized after this initial read-only audit and is described below.

## Fixed-input 1/20-worker comparison

Reuse the current complete-Sample driver/Integrate worker owners: warm once,
clone workers, split the **same frozen sequence of complete Samples** across
1/20 workers, and use original nested grid probabilities once. Keep all physical
cuts/orientations, CTs, selectors, ordinary precision rescue, maps, event-retention
settings and source authority fixed. Include representative saved finite points
and known hard/retry/maxima points in a separate correctness batch; do not turn
that biased diagnostic collection into a rate estimator. No new long MC run is
required for this compiler comparison.

`ProcessIntegrand::evaluate_samples_raw` (`process/mod.rs:1056`) loops sequentially;
API `bench` delegates to it. Merely setting RAYON_NUM_THREADS=20 on that command
is not a 20-worker benchmark. Use the existing outer worker clones/scheduling,
with per-worker counters and thread wall intervals. At 20 workers, sum of worker
timer seconds and elapsed wall seconds differ: report both, or divide all
worker-time components by total draws. Never subtract aggregate worker seconds
from global wall time to infer overhead, nor hide the difference with max(0).
Separate load/JIT/warmup, throughput and per-sample S/E/physical/outer work; include
precision counts and correctness failures. Scalar Applet evaluation does not use
its optional threaded matrix evaluator, so keep inner threading disabled.

Root's validation order: targeted dependency check; existing SymJIT builtin
constant/multiplier and raised complex-evaluator comparisons at O2 with both
compression settings; actual read-only GL load/activation; identical complete
Sample ordinary and forced-Arb controls including all six cuts and exact canonical
map/J/partition; then bounded repeated 1/20-worker timing. Preserve real diagnostics
and report any change in rescue frequency rather than attributing all speed to
kernel throughput. Do not claim API compatibility, compaction safety, numerical
agreement or a speedup before those gates run. Summed-versus-MC channel comparisons
remain deferred until the separately approved optimization sequence is complete.

## Applied timing / configuration checkpoint

Root updated only SymJIT in Cargo.lock to 2.25.6. The timing source is frozen for
root checks; validation is pending. Both wrapper timers are unconditional, and
the IFT alpha helper now uses the same wrapper. Threshold multiplier failures
retain completed evaluator time. Canonical sampling uses one elapsed value in
both C_S and S; neither StatisticsCounter fields nor serialized integration
checkpoints changed. The existing API bench splits C_S/C_P and rejects impossible
Duration subset relationships before its floating-point residual clamps. The
parallel scratch benchmark must retain raw components and reject negative
residuals rather than clamp them.

Complete parsed configs are in `configs/`; their only option difference is
`options.compress`. Runtime activation requires no new GammaLoop API: record the
loaded `ProcessIntegrand::frozen_compilation()`, set the public in-memory
`CrossSectionIntegrand.data.compilation` to `FrozenCompilationMode::Symjit(O2)`,
then call existing `State::activate_loaded_integrand_backends(false)` before
warmup. Record and require the actual `active_f64_backend()`. This label change
is confined to the loaded process and must never be saved. Retain original,
effective and active backend labels separately. Existing eager-only evaluator
policies, canonical maps, Quad/Arb rescues and diagnostics remain authoritative.

#!/usr/bin/env python3
"""Artifact-only fixed-deck timing and reported-complex-value comparisons.

Usage: python analyze_timing.py OUTPUT_DIRECTORY EAGER_DIRECTORY COMPRESSED_DIRECTORY [OFF_DIRECTORY]
No physics, state load, integration statistics, or writes to input directories.
"""
from decimal import Decimal as D, localcontext
from pathlib import Path
import hashlib
import json
import sys
import tomllib
from audit_physical import metric

COMPONENTS = ("S", "P", "C_S", "C_P", "E_all", "events")
METADATA = ("parameterization_time", "integrand_evaluation_time", "canonical_sampling_preparation_time", "canonical_physical_preparation_time", "evaluator_evaluation_time", "event_processing_time")


def nanos(value):
    if not isinstance(value, dict) or set(value) != {"secs", "nanos"}:
        raise ValueError("expected original serialized Duration")
    seconds, ns = value["secs"], value["nanos"]
    if not isinstance(seconds, int) or not isinstance(ns, int) or seconds < 0 or not 0 <= ns < 10**9:
        raise ValueError("invalid Duration")
    return seconds * 10**9 + ns


def audit(directories):
    result = {"passed": False, "checks": [], "table": [], "numeric_comparisons": [], "component_relative_misses": [], "input_sha256": {},
              "scope": "One fixed initial-grid deck, repeated compiler benchmark. Native total/six-cut accuracy belongs to each prior control audit. Timed deck values are original f64 reporting-boundary complete estimators, compared with the same configured complex-norm budgets. No rate, variance, global bound or throughput uncertainty claim.",
              "timing_scope": "Exact worker Duration sums per evaluated draw; global throughput uses only parallel wall. Repetitions are serial within each worker, not separately synchronized global timing trials."}

    def require(condition, label):
        result["checks"].append({"label": label, "passed": bool(condition)})
        if not condition:
            raise ValueError(label)

    def read(path):
        path = Path(path).resolve(strict=True)
        raw = path.read_bytes()
        result["input_sha256"][str(path)] = hashlib.sha256(raw).hexdigest()
        return json.loads(raw)

    reports = [read(Path(path) / "summary.json") for path in directories]
    by_arm = {report["arm"]: report for report in reports}
    require(len(by_arm) == len(reports) and {"eager", "symjit_o2_compress_on"} <= set(by_arm) <= {"eager", "symjit_o2_compress_on", "symjit_o2_compress_off"}, "unique mandatory backend arms")
    reference = by_arm["eager"]
    original_request = read(reference["request"])
    deck = read(original_request["sample_deck"])
    settings_path = Path(original_request["settings"])
    settings = tomllib.loads(settings_path.read_text())
    result["input_sha256"][str(settings_path.resolve())] = hashlib.sha256(settings_path.read_bytes()).hexdigest()
    budgets = {}
    for level in settings["stability"]["levels"]:
        value = min(D(str(level["required_precision_for_re"])), D(str(level["required_precision_for_im"])))
        require(value.is_finite() and value > 0, "finite configured precision budget")
        budgets[level["precision"]] = min(value, budgets.get(level["precision"], value))
    require(settings["stability"].get("check_on_norm", True), "complex-norm stability settings")
    n, repetitions = original_request["samples"], original_request["repetitions"]
    require(len(deck["samples"]) == n and 20 <= n <= 1024 and 1 <= repetitions <= 4, "bounded fixed deck/repetitions")
    evaluations = {}
    for arm, report in by_arm.items():
        request = read(report["request"])
        require(report["status"] == "completed" and report["error"] is None and report["saved_state_unchanged"] is True and report["state_before"] == report["state_after"] == reference["state_before"] and len(report["state_before"]) == 35, arm + " complete unchanged state")
        require(report["control_audit"]["passed"] is True and report["control_audit"]["failed_checks"] == 0 and all(c["passed"] for c in report["control_audit"]["checks"]), arm + " prior native controls")
        require(report["sample_deck_sha256"] == reference["sample_deck_sha256"] == result["input_sha256"][str(Path(original_request["sample_deck"]).resolve())] and request == original_request, arm + " identical request and source deck")
        require(report["executable_sha256"] == reference["executable_sha256"] and report["driver_source_sha256"] == reference["driver_source_sha256"] and report["support_source_sha256"] == reference["support_source_sha256"] and report["build_record"] == reference["build_record"], arm + " same instrumented build")
        require(report["settings"] == reference["settings"] and report["inventory"] == reference["inventory"] and len(report["inventory"]["production_orientation_keys"]) == 936 and len(report["inventory"]["cuts"]) == 6, arm + " unchanged physical settings/inventory")
        require(report["active_f64_backend"] == ("eager" if arm == "eager" else "symjit"), arm + " active backend")
        require({row["workers"] for row in report["timing"]} == {1, 20} and len(report["timing"]) == 2, arm + " worker matrix")
        for run in report["timing"]:
            workers = run["workers"]
            require(run["passed"] and run["draws"] == n * repetitions and len(run["worker_rows"]) == workers * repetitions, f"{arm}/{workers} complete batches")
            seen, precision_counts, totals = set(), {}, {name: 0 for name in (*COMPONENTS, "worker_wall", "sampling_other", "physical_other", "outer_other")}
            for batch in run["worker_rows"]:
                worker, rep = batch["worker"], batch["repetition"]
                key = (worker, rep)
                require(key not in seen and 0 <= worker < workers and 0 <= rep < repetitions and batch["passed"], f"{arm}/{workers} unique valid batch {key}")
                seen.add(key)
                start, end = n * worker // workers, n * (worker + 1) // workers
                require(batch["source_range"] == [start, end] and batch["count"] == end - start == len(batch["raw_evaluations"]), f"{arm}/{workers}/{key} exact source range")
                values = {name: nanos(batch[name]) for name in COMPONENTS}
                require(values["C_S"] <= values["S"] and values["C_P"] + values["E_all"] + values["events"] <= values["P"], f"{arm}/{workers}/{key} nested subsets")
                expected = {"sampling_other": values["S"] - values["C_S"], "physical_other": values["P"] - values["C_P"] - values["E_all"] - values["events"], "outer_other": nanos(batch["worker_wall"]) - values["S"] - values["P"]}
                require(all(v >= 0 and nanos(batch[k]) == v for k, v in expected.items()), f"{arm}/{workers}/{key} exact nonnegative residuals")
                for name in totals:
                    totals[name] += nanos(batch[name])
                accumulated = {name: 0 for name in COMPONENTS}
                for index, raw in enumerate(batch["raw_evaluations"], start):
                    metadata = raw["evaluation_metadata"]
                    precision = metadata["stability_results"][-1]["precision"]
                    require(not metadata["is_nan"] and not any("Unstable" in s for s in [str(metadata["stability_results"][-1]["status"])]), f"{arm}/{workers}/{rep}/{index} stable")
                    factor = D(str(raw["integrator_weight"])) * D(str(raw["parameterization_jacobian"] if raw["parameterization_jacobian"] is not None else 1))
                    value = tuple(D(str(raw["integrand_result"][phase])) * factor for phase in ["re", "im"])
                    require(all(v.is_finite() for v in value), f"{arm}/{workers}/{rep}/{index} finite complete estimator")
                    source = deck["samples"][index]
                    outer = next(iter(source.values()))[0]
                    require(float(raw["integrator_weight"]).hex() == float(outer).hex(), f"{arm}/{workers}/{rep}/{index} original outer Sample weight")
                    evaluations[arm, workers, rep, index] = (precision, value)
                    precision_counts[precision] = precision_counts.get(precision, 0) + 1
                    for name, field in zip(COMPONENTS, METADATA):
                        accumulated[name] += nanos(metadata[field])
                require(accumulated == values, f"{arm}/{workers}/{key} aggregate exact original metadata")
            global_ns = nanos(run["global_wall"])
            require(global_ns > 0, f"{arm}/{workers} positive wall")
            result["table"].append({"arm": arm, "workers": workers, "draws": n * repetitions, "global_wall_seconds": str(D(global_ns) / D(10**9)), "samples_per_second": str(D(n * repetitions) * D(10**9) / D(global_ns)), "precision_counts": precision_counts, "worker_nanoseconds": totals, "worker_seconds_per_draw": {k: str(D(v) / D(10**9) / D(n * repetitions)) for k, v in totals.items()}, "activation_seconds": report["backend_activation_seconds"], "load_seconds": report["load_seconds"], "map_warmup_seconds": report["warm_up_seconds"], "clone_warm_seconds": run["clone_warm_seconds"]})
    for (arm, workers, rep, index), (precision, value) in evaluations.items():
        if (arm, workers, rep) == ("eager", 1, 0):
            continue
        old_precision, old = evaluations["eager", 1, 0, index]
        detail = metric(value, old, budgets[precision] + budgets[old_precision])
        label = f"{arm}/{workers}/repeat{rep}/source{index}"
        result["numeric_comparisons"].append({"label": label, "precision": precision, "reference_precision": old_precision, **detail})
        for phase, component in detail["components"].items():
            if not component["own_relative_budget_passed"]:
                result["component_relative_misses"].append({"label": label, "phase": phase, **component})
    result["passed"] = all(c["passed"] for c in result["checks"]) and all(c["passed"] for c in result["numeric_comparisons"])
    result["failed_numerical_comparisons"] = sum(not c["passed"] for c in result["numeric_comparisons"])
    return result


def main():
    output = Path(sys.argv[1])
    if output.exists():
        raise ValueError("output directory must be new and outside immutable inputs")
    output.mkdir(parents=True)
    try:
        with localcontext() as context:
            context.prec = 350
            result = audit(sys.argv[2:])
    except (OSError, ValueError, KeyError, TypeError, ArithmeticError) as error:
        result = {"passed": False, "error": str(error)}
    (output / "analysis.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({k: result[k] for k in ["passed", "error", "failed_numerical_comparisons"] if k in result}))
    return 0 if result["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())

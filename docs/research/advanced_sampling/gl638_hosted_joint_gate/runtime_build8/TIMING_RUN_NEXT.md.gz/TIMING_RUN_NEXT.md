# Fixed-input SymJIT timing packet

The source and complete compression configs are prepared, not executed. Root owns
compilation and state loads. The required comparison is newly instrumented Eager
versus SymJIT 2.25.6 O2 with compression, at 1 and 20 actual worker clones. The
optional latest O2/no-compression arm separates compression from the dependency
update. Keep the preserved compact=false guard. Quad/Arb rescues and eager-only
helpers remain active; all ordinary samples use the current precision policy.
Future channel ranking uses the real part; compiler correctness still checks both
complex components with the existing norm/nearzero reporting convention.

Files:

- `gate_timing.rs`, plus byte-identical b53 common owner `gate_timing_support.rs`.
- `request-timing-template.json`: explicit 512 fixed initial-grid Samples,
  seed1337, three repetitions per worker count, nonsoft composed settings. Root may
  set a smaller approved count before freezing; the driver permits20..1024 and
  1..4 repetitions, and always creates exactly the requested1/20 clones.
- `configs/symjit-o2-compress-{off,on}.toml`: complete options, only compress differs.
- `audit_timing_controls.py` reuses unchanged `audit_physical.py` Decimal350
  total/six-cut complex norms. Its artifact-only self-test has43 positive checks
  and rejects changed canonical identity and changed native Y. This is parser /
  criterion verification, not new physical acceptance.

Freeze the actual completed root driver build record, then create a preparation
request copy. The timing request's build record must name this exact source and
binary with compiled/returncode0. `input_sha256` authenticates original settings,
controls, common source, auditors and configs. Preserve the original template and
freeze each populated request separately. Record source patch/commit and compiled
core/API/Symbolica dependencies with the existing root compiler-capture owner.
No saved-state mutation, evaluator registry or new production activation API is
needed: after read-only loading, record the original Eager label, change only the
in-memory compilation field to Symjit(O2), activate via the existing State method,
and require the actual backend before and after warmup. Never save that field.

Commands after root's completed driver link (use the standard sourced environment
and supplied license; keep `GL_DISPLAY_FILTER=off`, `RAYON_NUM_THREADS=20`,
and inner SymJIT threading off; local pools still select actual1/20 workers):

```sh
/path/to/gate-timing request-prepare.json prepare /new/output/deck
# Freeze samples.json SHA into a new request, with its exact original settings.
/path/to/gate-timing request-frozen.json eager /new/output/eager
SYMJIT_TOML=/tmp/gl638-symjit-next/configs/symjit-o2-compress-on.toml /path/to/gate-timing request-frozen.json symjit_o2_compress_on /new/output/compressed
# Optional:
SYMJIT_TOML=/tmp/gl638-symjit-next/configs/symjit-o2-compress-off.toml /path/to/gate-timing request-frozen.json symjit_o2_compress_off /new/output/uncompressed
```

Each benchmark process loads once, activates before timing, warms once, verifies
two existing build7 complete-Sample controls at ordinary and forced-Arb precision,
and requires exact canonical point/J/partition identity. The Python control audit
must pass before any measured batch. Events are enabled only on diagnostic clones;
timed settings are the original physical workspace settings. Both totals and all
six cut weights are compared to original Arb controls under actual configured
lane budgets; tiny-component relative misses are reported separately. These
controls include hard retained maxima, not a new statistical population.

Source generation uses existing `Grid::sample` only. No point is evaluated or grid
updated in the prepare stage. The resulting complete Sample JSON, including every
nested weight, is reused identically across backend and worker-count arms.
Workers are cloned from the warmed integrand and execute two untimed raw calls
without another map warmup. Timing then uses the normal raw physical API with
ordinary rescue, max_eval=0, and unchanged full936/six-cut/CT inventory. No
summed-versus-MC comparison or rate estimate is performed.

Every worker/repetition retains raw numerical results and exact Duration fields
S, C_S, P, C_P, E_all and events. Sampling-other=S−C_S;
physical-other=P−C_P−E_all−events; outer-other=worker raw-batch wall−S−P.
Invalid subsets or negative residuals retain raw rows and reject the arm; no
clamping. Errors retain rejected-batch wall separately. The raw API does not
return partial results within a failed batch, so such wall is not completed
sampling/evaluator attribution. All other completed/error batches are retained.
Global wall includes the parallel dispatch/collection interval; it is never
subtracted from summed worker seconds. Report both global throughput and per-draw
summed worker costs, precision counts and warmup/activation separately. No new
cost or speedup claim is made until the root-owned runs complete.

The current source gates are complete: root reported21 unique selected core/API
checks passing (20 successful checks in the first compression-on run, followed by
the corrected timing fixture plus three repeated SymJIT checks with compression
off), final format/check passed, and clippy has52 existing diagnostics with none
on changed lines. Optimized build8 is in progress; no build8 numerical or timing
claim is recorded yet. The production source is frozen. Run timing arms with no
concurrent Gamma workload; environment thread limits do not replace the explicit
1/20-worker pools. Preserve the old256×2 template as preparation history.

After both mandatory arms are complete, keep their directories immutable and run:

```sh
python /tmp/gl638-symjit-next/analyze_timing.py /new/output/analysis /completed/eager /completed/compressed
```

`analyze_timing.py` reconstructs exact worker Duration sums from every original
metadata row, verifies the complete deck/source ranges and original outer weight,
and compares each reported complete complex estimator across backends, worker
counts and repetitions to Eager/1-worker/repetition0 using actual final-lane
budgets. These all-deck values are the existing f64 reporting boundary; the two
pre-timing native controls separately retain Arb totals and six physical cuts.
Both retained native controls originate from lu_cut_1 maxima, so their scope is
explicit. The analyzer reports all precision counts, nearzero component misses,
per-draw worker components and global throughput without using worker seconds as
wall seconds. Synthetic artifact tests pass478 structural/accounting checks and
60 value pairs, and reject a changed estimator and invalid timing subset; no
new backend performance or physical acceptance is implied by those tests.

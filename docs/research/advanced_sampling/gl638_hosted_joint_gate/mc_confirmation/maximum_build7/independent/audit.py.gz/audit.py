"""Artifact-only audit. Never deserialize Gamma state or write pilot/max directories."""
import hashlib, json, math, struct, sys
from collections import Counter
from decimal import Decimal as D, localcontext
from pathlib import Path
sys.dont_write_bytecode = True
ROOT = Path('/tmp/gl638-hosted-joint-gate')
sys.path.insert(0,str(ROOT))
import audit_maximum_results
read=lambda p:json.loads(Path(p).read_text())
hashof=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
bits=lambda x:struct.unpack('>Q',struct.pack('>d',x))[0]
checks=[]
def check(label,passed):
    checks.append({'label':label,'passed':bool(passed)})
    if not passed:raise AssertionError(label)
preflight=read(ROOT/'results-cut-combined-seven-preflight-build5/summary.json')
screen=read(ROOT/'results-confirmation-build7/physics_pilot_analysis.json')
expected={(r['mode'],r['seed']):r for r in screen['runs']}
seen=set(); batches=[]; metric_rows=[]; inputs={}; all_maxima=[]
for suffix in ('confirmation',):
    directory=ROOT/'results-max-confirmation-build7'
    summary=read(directory/'summary.json'); retained=read(directory/'maximum_accuracy_audit.json')
    run_path=ROOT/'max-confirmation-build7-run.json'; runrecord=read(run_path)
    pilot=Path(summary['pilot_directory'])
    check(suffix+': terminal run and source/state',runrecord['returncode']==0 and summary['status']=='completed' and summary['error'] is None and summary['source_lineage']==screen['build_identity'] and summary['state_before']==summary['state_after']==preflight['state_hashes'] and len(summary['state_before'])==35)
    check(suffix+': exact immutable pilot-file set',summary['pilot_files_before']==summary['pilot_files_after'] and all(hashof(pilot/path)==h for path,h in summary['pilot_files_before'].items()))
    check(suffix+': declared provenance',summary['execution_provenance'][str(ROOT/'drivers/max_replay_current.rs')]=='29b9c6a48448935aee70159787063bb8a2c1cdd5b6a762ff596fd2d9061ca498' and summary['execution_provenance'][str(ROOT/'drivers/gate-max-support.rs')]=='b53df2b439845729dd5a9c898c9cece83c28426457ec18701cf9787756310306' and summary['execution_provenance'][str(ROOT/'drivers/max-replay-build7')]=='256bd2d51471fbdae92ac38a4095e67e39ba2c507817f4652114e36a18b74c2e')
    with localcontext() as context:
        context.prec=350
        reproduced=audit_maximum_results.audit(directory)
    check(suffix+': exact existing accuracy audit reproduction',reproduced==retained and retained['passed'] and retained['counts']['failed']==0)
    for path,h in retained['input_sha256'].items():check(suffix+': metric input '+path,hashof(path)==h)
    unique=aliases=0
    for run in summary['runs']:
        key=(run['mode'],run['seed']);check(str(key)+': original confirmation row',key in expected and key not in seen and run['num_points']==32768 and run['n_cores']==20 and run['complete'] and not run['unavailable_extrema']);seen.add(key)
        original=read(expected[key]['result_path'])['slots'][0]
        check(str(key)+': exact original workspace',Path(run['workspace'])==Path(expected[key]['retained_driver_record']['workspace']))
        expected_max={(r['component'],'positive' if r['sign']=='+' else 'negative'):r['max_eval'] for r in original['max_weight_info']}
        covered=[]
        for maximum in run['maxima']:
            unique+=1;all_maxima.append(maximum)
            check(str(key)+': native maximum complete',maximum['complete'] and maximum['error'] is None and maximum['native_ordinary']['evaluation']['valid'] and maximum['native_ordinary']['evaluation']['precision']=='Double')
            sample=maximum['complete_sample'];top=sample['Discrete'];selected=top[2]['Discrete']
            check(str(key)+': same nested Sample and original outer weight',json.loads(maximum['sample_key'])==sample and top[1]==0 and top[0]==maximum['sample_weight'] and selected[1]==maximum['canonical_map']['channel_id'])
            conditional=math.prod(x.get('conditional_inverse_probability',x.get('weight',1)) for x in maximum['conditional_factors'])
            check(str(key)+': conditional factors once',conditional==maximum['sample_weight'])
            ev=maximum['ordinary_reporting_evaluation']; jac=ev['parameterization_jacobian'] if ev['parameterization_jacobian'] is not None else 1.0
            y={phase:(ev['integrand_result'][phase]*jac)*maximum['sample_weight'] for phase in ('re','im')}
            check(str(key)+': public f64 factor association once',all(bits(y[p])==bits(maximum['reported_estimator'][p]) for p in y))
            events=maximum['native_ordinary']['evaluation']['events']
            check(str(key)+': six physical cut identities',len(events)==6 and {e['cut_info']['cut_id'] for e in events}==set(range(6)) and all(e['cut_info']['graph_id']==0 and e['cut_info']['sampling_channel_id']==selected[1] for e in events))
            with localcontext() as context:
                context.prec=350
                cm=maximum['canonical_map'];reciprocity=D(cm['selected_J_times_w'])*D(cm['raw_map_density_sum'])
                check(str(key)+': detached J*w density reciprocity',abs(reciprocity-1)<D('1e-280'))
            for alias in maximum['aliases']:
                aliases+=1;covered.append((alias['phase'],alias['sign']))
                stored=expected_max[alias['phase'],alias['sign']]
                check(str(key)+': actual saved signed-extremum bits',alias['passed'] and alias['bit_exact'] and alias['stored_maximum_bits']==bits(stored)==bits(alias['replayed_maximum'])==bits(y[alias['phase']]) and alias['relative_difference']==0)
        check(str(key)+': all four saved extrema covered',sorted(covered)==sorted(expected_max))
    pairs=[r for r in retained['checks'] if r['kind']=='native_ordinary_vs_arb']
    check(suffix+': two forced-Arb controls per method',len(summary['attribution'])==2*len({r['mode'] for r in summary['runs']}) and all(r['complete'] and r['forced_arb']['evaluation']['valid'] and r['forced_arb']['evaluation']['precision']=='Arb' for r in summary['attribution']))
    for pair in pairs:
        for metric in [pair['total'],*pair['cuts']]:metric_rows.append({'batch':suffix,'label':pair['label'],'cut_id':metric.get('cut_id'),'relative_error':float(metric['relative_complex_error']),'tolerance':float(metric['tolerance']),'passed':metric['passed'],'own_relative_component_misses':sum(not c['own_relative_budget_passed'] for c in metric['components'].values())})
    metrics=[r for r in metric_rows if r['batch']==suffix]
    batches.append({'batch':suffix,'pilot_runs':len(summary['runs']),'distinct_retained_samples':unique,'signed_extrema_bit_exact':aliases,'forced_arb_controls':len(summary['attribution']),'existing_accuracy_checks':retained['counts']['checks'],'outer_elapsed_seconds':runrecord['elapsed_seconds'],'pilot_files_unchanged':len(summary['pilot_files_before']),'max_total_relative_error':max(r['relative_error'] for r in metrics if r['cut_id'] is None),'max_cut_relative_error':max(r['relative_error'] for r in metrics if r['cut_id'] is not None)})
    for path in (directory/'summary.json',directory/'maximum_accuracy_audit.json',run_path):inputs[str(path)]=hashof(path)
check('exact included 15 fresh confirmation rows, no old interrupted/screen runs',seen==set(expected) and len(seen)==15)
result={'passed':True,'scope':'Artifact-only independent replay/provenance review. Original signed extrema and factor association checked against saved workspace JSON; existing Decimal350 native metric reproduced exactly. No Gamma state load or pilot/max writes.','checks':checks,'batches':batches,'totals':{k:sum(b[k] for b in batches) for k in ('pilot_runs','distinct_retained_samples','signed_extrema_bit_exact','forced_arb_controls','existing_accuracy_checks','pilot_files_unchanged')},'native_pair_metrics':metric_rows,'max_native_total_relative_error':max(r['relative_error'] for r in metric_rows if r['cut_id'] is None),'max_native_cut_relative_error':max(r['relative_error'] for r in metric_rows if r['cut_id'] is not None),'nearzero_own_relative_component_misses':sum(r['own_relative_component_misses'] for r in metric_rows),'input_sha256':inputs,'limitations':'Top-two forced controls are per method among retained signed-extremum Samples, not a maximum over unrecorded complex norms or every source point. Original maxima/checkpoint provenance is authenticated without deserializing checkpoints. Elapsed is provenance, not a performance comparison. Physical attribution remains separate.'}
out=Path(__file__).parent
(out/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
lines=['The completed confirmation maximum batch passes independent audit.','', '| Batch | Runs | Distinct Samples | Bit-exact signed extrema | Arb controls | Existing accuracy checks |','|---|---:|---:|---:|---:|---:|']
for b in batches:lines.append(f"| {b['batch']} | {b['pilot_runs']} | {b['distinct_retained_samples']} | {b['signed_extrema_bit_exact']} | {b['forced_arb_controls']} | {b['existing_accuracy_checks']} |")
lines += ['',f"{len(checks)} independent checks passed. All 222 retained pilot files and 35 state hashes remain unchanged. All 48 ordinary calls use Double and retain six physical cuts; 6 controls use Arb.",f"Largest ordinary/Arb relative complex errors: total {result['max_native_total_relative_error']:.6g}, cut {result['max_native_cut_relative_error']:.6g}. All original norm budgets pass; {result['nearzero_own_relative_component_misses']} component-relative diagnostics remain visible.", '',result['limitations']]
(out/'summary.md').write_text('\n'.join(lines)+'\n')
print('\n'.join(lines));print('SHA',hashof(out/'summary.json'))

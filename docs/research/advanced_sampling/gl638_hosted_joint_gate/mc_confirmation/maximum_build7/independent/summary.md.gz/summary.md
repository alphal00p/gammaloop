The completed confirmation maximum batch passes independent audit.

| Batch | Runs | Distinct Samples | Bit-exact signed extrema | Arb controls | Existing accuracy checks |
|---|---:|---:|---:|---:|---:|
| confirmation | 15 | 48 | 60 | 6 | 551 |

415 independent checks passed. All 222 retained pilot files and 35 state hashes remain unchanged. All 48 ordinary calls use Double and retain six physical cuts; 6 controls use Arb.
Largest ordinary/Arb relative complex errors: total 1.17633e-12, cut 1.17645e-12. All original norm budgets pass; 6 component-relative diagnostics remain visible.

Top-two forced controls are per method among retained signed-extremum Samples, not a maximum over unrecorded complex norms or every source point. Original maxima/checkpoint provenance is authenticated without deserializing checkpoints. Elapsed is provenance, not a performance comparison. Physical attribution remains separate.

# Two confirmation maximum geometries

Existing native-trace analysis passes for both new points. Every traced Arb total, factor and six-cut event equals its previously retained control exactly. The analysis reconstructs37 single stars and8 merged residue points from native parent/center/root/alpha fields, with maximum affine join discrepancy4.87e-299GeV. Eight actual native2l A/U multiplier checks agree within3.78e-301. The original analyzer's only change is descriptive: “three points” became “points”; numerical predicates and formulas remain unchanged.

| Measured geometry | Shared b/c real maximum | Cuts-only imaginary maximum |
|---|---:|---:|
| Complete c or b complex weight [pb] |c:12.21898+2.63825i|b:1.76318+11.51988i|
| Physical cut1 H/Z radius [GeV] |125.9073|29.0311|
| Dominant CT |Cut3 right[5,10], local/integrated|Cut1 native2l A=[7,8], local|
| Dominant star H/Z radius [GeV] |51.1309|1.57488|
| Actual cut1-host defect at that star [GeV] |90.1152|about1e-299|
| Soft13 / soft14 energies at dominant star [GeV] |89.2172 /349.1039|185.803 /478.966|
| Dominant star alpha |0.823359|0.958700|
| Dominant radial derivative |1.69908|1.46517|

The shared real maximum is dominated by cut3 right-threshold local/integrated and iterated terms. Its selected right-star has H=0 because physical cut3 is that H surface, but a90.1GeV cut1 defect. It is therefore a different cut/threshold configuration from the cut1-hosted direct H/Z proposal. The native decomposition demonstrates large cancellations; these two finite points alone do not determine their asymptotic origin. Its gluons are finite, with no evidence of a soft endpoint. The exactly matching b/c point and7/6 outer factor explain the real maximum's larger c weight independently of this geometric diagnosis; they do not explain the whole variance comparison.

At the cuts-only imaginary maximum, the dominant native2l A-star is much closer to H/Z than the physical cut1 point: R falls29.0311→1.57488GeV, and the actual WH radius21.6219→1.19117GeV. The opposing native2l Z=[3,10,13] star has Z within its diagnostic residual of zero and H=−0.0155391GeV. Its soft13/14 energies are186.080/480.046GeV. These measured moved-star configurations supply concrete normal enhancement behind the large competing CT terms, while the gluons remain hard. The Z-star itself has no assigned A/U WH multiplier; its reported H/Z radius is geometry, not an invented consumer weight.

Across both points' physical, single-star and merged configurations, min soft13/14 are respectively53.8406/127.349GeV for the real maximum and89.9485/107.854GeV for the imaginary maximum. LU scales lie0.6502–1.0030 and0.7810–1.6644. Physical LU derivatives are at least767.77 and461.94; the smallest reconstructed threshold radial derivatives are0.17484 and0.46364. These measurements show neither a sampled soft endpoint nor an extreme radial scale or unresolved radial root in these cases. They are not uniform lower bounds over phase space.

The interpretation is identity-probe pointwise evidence, not a boundedness theorem. Component norm ratios are not signed rate fractions. Selected threshold energy sums are checked numerically at their reconstructed stars; only the six physical-cut shifts are additionally structurally serialized. Exact cut1 WH reconstruction is checked only where the native2l A/U consumer actually uses that multiplier. Directed chart support was not separately evaluated.

The true joint-added absolute-Im maximum (seed20011,−6.22638pb) is still outstanding in this two-point account. Its ordinary decomposition is dominated by native2l U=[8,12,14]; a separately requested top4 control replay will provide its actual Arb control before the same native trace workflow is used. Do not substitute the second complex-norm maximum for it.

Sources: `analysis.json` (SHA256 c37e8c423142987fd8bbf93688efd61d240262c1cf2b832d08adc154289dfe90), original immutable traces in `/tmp/gl638-hosted-joint-gate/results-max-native-trace-confirmation-build7/`, and exact-factor check in `../confirmation-max-attribution-draft-build7/same_point_factor.json`. No Gamma calls or new root solves were made by the postprocessor.

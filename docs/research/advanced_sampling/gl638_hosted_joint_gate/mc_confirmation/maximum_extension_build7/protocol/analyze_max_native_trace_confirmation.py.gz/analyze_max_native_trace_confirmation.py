"""Audit retained GL638 maximum traces; no Gamma calls or root solves.

Uses the existing Decimal native-event audit, and reconstructs only the recorded
identity-frame affine stars. All input text remains in immutable JSONL records.
"""
import argparse
from decimal import Decimal as D, getcontext
import hashlib
import json
from pathlib import Path
import re
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
from audit_physical import norm, vector

getcontext().prec = 350
NUMBER = r'[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][-+]?\d+)?'
EPS = D('1e-280')  # Diagnostic text/affine consistency, never a physics acceptance budget.

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def table(text):
    rows = [line.split('│')[1:-1] for line in text.splitlines() if line.startswith('│')]
    assert [int(row[0]) for row in rows] == list(range(4))
    return [[D(v.strip()) for v in row[1:]] for row in rows]

def root(message):
    tail = message[message.rfind('NewtonIterationResult'):]
    values = re.findall(r'float: (' + NUMBER + r')', tail)
    assert len(values) == 3, tail
    return dict(zip(['solution', 'derivative', 'residual'], map(D, values)))

def difference(a, b):
    return max(abs(x-y) for aa,bb in zip(a,b) for x,y in zip(aa,bb))

def mag(v):
    return sum(x*x for x in v).sqrt()

def route(k, basis, external):
    return [[sum(D(c)*v[axis] for c,v in zip(s['internal'], k)) +
             sum(D(c)*v[axis+1] for c,v in zip(s['external'], external))
             for axis in range(3)] for s in basis['edge_signatures']]

def encode(obj):
    if isinstance(obj, D):
        return str(obj)
    raise TypeError(type(obj).__name__)

def analyze(path):
    row = json.loads(path.read_text())
    assert row['complete'] and row['numeric_control_differences'] == []
    for field in ['precision','valid','integrand_result','complete_sample_estimator',
                  'integrator_weight','parameterization_jacobian','events']:
        assert row['traced_forced_arb']['evaluation'][field] == row['forced_arb_control']['evaluation'][field]
    registry = row['geometry_registry']; gen = registry['generation_lmb']
    external = [[D(str(x)) for x in p] for p in registry['kinematics']['externals']['data']['momenta']]
    masses = list(map(lambda x:D(str(x)),registry['cached_real_masses']))
    Q = sum(p[0] for p in external)
    assert gen['loop_edges'] == [3,4,7,10] and Q == 1000
    assert external == [[D(500),D(0),D(0),D(500)],[D(500),D(0),D(0),D(-500)]]
    cut_groups = {g['id']:g['cuts'][0] for g in registry['cut_groups']}
    cuts = {c['id']:c for c in row['inventory']['cuts']}
    assert all('external_shift: [(EdgeIndex(0), -1), (EdgeIndex(1), -1)]' in c['original_equation'] for c in cuts.values())
    byedges = {tuple(c['edges']):g for g,cid in cut_groups.items() for c in [cuts[cid]]}
    metadata = row['inventory']['threshold_counterterm_metadata']
    variants = {v['variant_id']:v for v in metadata['variants']}
    components = {c['component_id']:c for c in metadata['components']}
    trace = Path(row['trace']); records = [json.loads(line) for line in trace.read_text().splitlines()]
    raw_ids = [i for i,r in enumerate(records) if r['fields'].get('message','').startswith('loop moms:')]
    assert len(raw_ids) == 2, raw_ids
    end_identity = raw_ids[1]
    raw = table(records[raw_ids[0]]['fields']['message'])
    raw_canonical = [[D(x) for x in row['canonical_map']['raw_coordinates'][i:i+3]] for i in range(0,12,3)]
    assert difference(raw,raw_canonical) == 0
    roots = {}; pending_edges = None
    for i in range(raw_ids[0]+1,end_identity):
        m=records[i]['fields'].get('message','')
        if m.startswith('representative esurface:'):
            pending_edges=tuple(map(int,re.findall(r'EdgeIndex\(\s*(\d+),?\s*\)',m.split('external_shift')[0])))
        if m.startswith('solution:'):
            group=byedges[pending_edges]; assert group not in roots
            roots[group]={'trace_index':i,**root(m)}
    assert len(roots)==6
    base = {g:[[v*t['solution'] for v in p] for p in raw] for g,t in roots.items()}
    def geometry(k):
        routed=route(k,gen,external)
        energy=[(sum(v*v for v in p)+mass*mass).sqrt() for p,mass in zip(routed,masses)]
        eta=lambda edges:sum(energy[e] for e in edges)-Q
        h,z,host=eta([2,4,12]),eta([3,10,13]),eta([2,6,10])
        p=eta([3,12]); hcut=h-host
        return {'original_H_GeV':h,'original_Z_GeV':z,'R_map_GeV':mag([h,z]),
                'host_cut1_residual_GeV':host,'H_minus_host_GeV':hcut,'P_GeV':p,
                'cut1_WH_algebraic_radius_GeV':mag([hcut,p*z/Q]),
                'soft13_energy_GeV':energy[13],'soft14_energy_GeV':energy[14],
                'min_spatial_internal_norm_GeV':min(mag(routed[e]) for e in range(2,15) if e not in [9,11]),
                'edge_energies_GeV':energy,
                'cut_residuals_GeV':{cid:eta(c['edges']) for cid,c in cuts.items()}}
    instance_map={}; instance_records=[]
    for i,r in enumerate(records[:end_identity]):
        if r['fields'].get('message')!='prepared complete threshold solve group':continue
        text=r['fields']['file.instances']; instance_records.append(i)
        for group,side,local,vid in re.findall(r'CutGroupId\((\d+)\), (Left|Right), (\d+), Some\(ThresholdCountertermVariantId\((\d+)\)\)',text):
            key=(int(group),side.lower(),int(local));vid=int(vid)
            assert instance_map.setdefault(key,vid)==vid
    centers=[]
    for i,r in enumerate(records[:end_identity]):
        f=r['fields']
        if f.get('stage')!='lu_threshold_center_values':continue
        assert f['rotation_id']=='Identity rotation'
        sub=records[i-1]['fields']['message']; assert sub.startswith('subspace:')
        lmbid=int(re.search(r'lmb: LmbIndex\((\d+)\)',sub)[1])
        active=list(map(int,re.findall(r'LoopIndex\((\d+)\)',f['subspace_loop_indices'])))
        alpha_index=i+2; am=records[alpha_index]['fields']['message'];assert am.startswith('alpha solution:')
        centers.append({'trace_index':i,'alpha_trace_index':alpha_index,'local_id':f['selected_esurface_id'],
                        'lmb_id':lmbid,'active':active,'center':table(f['file.active_center']),
                        'fixed':table(f['file.center_with_fixed_complement']),'root':root(am)})
    stars=[]; seen={}; max_checks=[]
    for i,r in enumerate(records[:end_identity]):
        m=r['fields'].get('message','')
        match=re.match(r'LU (left|right) evaluator input: cut_group_id=(\d+), (?:left|right)_threshold_id=(\d+).*lu_order=(\d+), r=('+NUMBER+'), rstar=('+NUMBER+')$',m)
        if not match:continue
        side,gs,ls,order,rs,rss=match.groups();g=int(gs);local=int(ls);assert int(order)==1
        vid=instance_map[g,side,local];v=variants[vid];radius,rstar=D(rs),D(rss)
        candidates=[]
        for c in centers:
            lmb=registry['lmbs'][c['lmb_id']]
            if c['trace_index']>=i or c['local_id']!=local or lmb['loop_edges']!=v['resolved_parent_lmb']:continue
            if [lmb['loop_edges'][n] for n in c['active']]!=v['resolved_subspace']:continue
            routed_base=route(base[g],gen,external); native=[routed_base[e] for e in lmb['loop_edges']]
            fixed=[c['center'][n] if n in c['active'] else native[n] for n in range(4)]
            rcheck=mag([native[n][a]-c['center'][n][a] for n in c['active'] for a in range(3)])
            errors=[difference(fixed,c['fixed']),abs(rcheck-radius),abs(radius*c['root']['solution']-rstar)]
            if max(errors)>EPS*max(D(1),radius,rstar):continue
            candidates.append((c,lmb,native,errors))
        assert len(candidates)==1,(row['id'],g,side,local,len(candidates))
        c,lmb,native,errors=candidates[0];max_checks+=errors
        star_native=[[c['center'][n][a]+c['root']['solution']*(native[n][a]-c['center'][n][a]) if n in c['active'] else native[n][a] for a in range(3)] for n in range(4)]
        star_edges=route(star_native,lmb,external); star=[star_edges[e] for e in gen['loop_edges']]
        geom=geometry(star);edges=v['associations'][0]['threshold_edges']
        residual=sum(geom['edge_energies_GeV'][e] for e in edges)-Q
        assert abs(residual)<EPS*Q,(vid,residual)
        key=(g,side,local);assert key not in seen; seen[key]=len(stars)
        stars.append({'cut_group_id':g,'cut_id':cut_groups[g],'side':side,'local_threshold_id':local,'variant_id':vid,
                      'variant':v,'center_trace_index':c['trace_index'],'alpha_trace_index':c['alpha_trace_index'],
                      'evaluator_trace_index':i,'native_lmb_id':c['lmb_id'],'native_parent':lmb['loop_edges'],'active_slots':c['active'],
                      'measured_alpha':c['root'],'measured_radius_GeV':radius,'measured_rstar_GeV':rstar,
                      'radius_difference_GeV':radius-rstar,'relative_radial_distance':abs(radius-rstar)/radius,
                      'd_eta_d_radius':c['root']['derivative']/radius,'affine_join_errors_GeV':errors,
                      'native_center_GeV':c['center'],'fixed_complement_GeV':c['fixed'],
                      'star_generation_momenta_GeV':star,'selected_surface_residual_GeV':residual,'geometry':geom})
    assert len(stars) == len(centers), (len(stars),len(centers))
    # Geometry for both projected legs is explicit. Distinguish multiplier contexts
    # from the common merged residue point for LI/IL/II; never relabel all as LL.
    merged=[]
    for i,r in enumerate(records[:end_identity]):
        m=r['fields'].get('message','');mt=re.match(r'LU iterated evaluator input: cut_group_id=(\d+), left_threshold_id=(\d+), right_threshold_id=(\d+)',m)
        if not mt:continue
        g,l,rr=map(int,mt.groups());left=stars[seen[g,'left',l]];right=stars[seen[g,'right',rr]]
        k=[[x+y-z for x,y,z in zip(a,b,c)] for a,b,c in zip(left['star_generation_momenta_GeV'],right['star_generation_momenta_GeV'],base[g])]
        merged.append({'cut_group_id':g,'cut_id':cut_groups[g],'left_variant_id':left['variant_id'],'right_variant_id':right['variant_id'],
                       'evaluator_trace_index':i,'merged_residue_geometry':geometry(k),
                       'context_scope':'Common merged residue point; LL/LI/IL/II multiplier effective and star contexts remain distinct in existing owner'})
    evaluation=row['traced_forced_arb']['evaluation'];Y=norm(vector(evaluation['complete_sample_estimator']))
    terms=[];cut_summary=[]
    for event in evaluation['events']:
        cid=event['cut_info']['cut_id'];decomp=event['threshold_counterterms']
        cut_summary.append({'cut_id':cid,'complete_weight':event['weight'],'norm_over_total':norm(vector(event['weight']))/Y,
                            'original_norm_over_total':norm(vector(decomp['original']))/Y})
        for component in decomp['components']:
            meta=components[component['component_id']]
            assert cut_groups[meta['cut_group_id']]==cid
            terms.append({'cut_id':cid,'norm_over_total':norm(vector(component['weighted']))/Y,
                          'metadata':meta,'native_component':component,
                          'single_star_indices':[j for j,s in enumerate(stars) if s['variant_id'] in meta['variant_ids']]})
    terms.sort(key=lambda t:t['norm_over_total'],reverse=True)
    multiplier_checks=[]
    for term in terms:
        if term['metadata']['kind'] not in ['local','integrated']:continue
        for index in term['single_star_indices']:
            star=stars[index];v=star['variant']
            if star['cut_id']!=1 or v['name']!='native_2l' or v['associations'][0]['threshold_edges'] not in [[7,8],[8,12,14]]:continue
            geom=star['geometry'];h=geom['H_minus_host_GeV'];radius=geom['cut1_WH_algebraic_radius_GeV']
            expected=h*h/(radius*radius);measured=D(term['native_component']['effective_multiplier'])
            error=abs(expected-measured);assert error<EPS
            multiplier_checks.append({'component_id':term['metadata']['component_id'],'variant_id':star['variant_id'],
                                      'expected_at_recorded_star':expected,'native_effective_multiplier':measured,'absolute_error':error})
    assert len(multiplier_checks)==4

    return {'id':row['id'],'mode':row['mode'],'seed':row['seed'],'input':str(path),'input_sha256':sha(path),
            'trace':str(trace),'trace_sha256':sha(trace),'controls_exact':True,'complete_Y':evaluation['complete_sample_estimator'],
            'complete_Y_norm_pb':Y,'canonical_map':row['canonical_map'],'conditional_factors':row['conditional_factors'],
            'identity_raw_trace_index':raw_ids[0],'identity_end_trace_index':end_identity,
            'instance_trace_indices':instance_records,'roots':roots,
            'physical_cut_geometry':{g:{'cut_id':cut_groups[g],'geometry':geometry(k)} for g,k in base.items()},
            'single_stars':stars,'merged_stars':merged,'max_affine_join_error_GeV':max(max_checks),
            'cut_summary':cut_summary,'components_by_magnitude':terms,'cut1_WH_checks':multiplier_checks,
            'scope':'Decimal350 reconstruction from native303-digit tokens and exact routing; no Gamma calls/root solves. Numerical text consistency only, no directed certificate or new physical acceptance.'}

parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('trace_directory',type=Path);parser.add_argument('output_directory',type=Path)
args=parser.parse_args();summary=json.loads((args.trace_directory/'summary.json').read_text())
assert summary['status']=='completed' and summary['saved_state_unchanged'] and summary['inputs_unchanged']
results=[analyze(args.trace_directory/(case['id']+'.json')) for case in summary['cases']]
args.output_directory.mkdir(exist_ok=False)
report={'passed':True,'analyzer_sha256':sha(Path(__file__)),'trace_summary_sha256':sha(args.trace_directory/'summary.json'),'cases':results,
        'limitations':['The points are retained signed-extremum maxima, not unrecorded global complex maxima.',
                       'Original H/Z and soft energies are reconstructed at measured LU roots and affine stars; directed chart support was not separately evaluated.',
                       'For every reconstructed selected threshold, sum(listed positive energies) minus the recorded Qin vanishes within diagnostic tolerance; only the six physical cut shifts are also structurally serialized and checked.',
                       'The cut1 WH algebraic radius is checked against actual native_2l A/U multipliers only; it is not another channel metric or a universal multiplier on other cuts.',
                       'No causal claim follows from a zero joint partition or a component name alone. Single points do not determine an asymptotic exponent or global bound.']}
(args.output_directory/'analysis.json').write_text(json.dumps(report,default=encode,indent=2)+'\n')
for r in results:
 print(r['id'],'Y',float(r['complete_Y_norm_pb']),'stars',len(r['single_stars']),'merged',len(r['merged_stars']),'join',str(r['max_affine_join_error_GeV'])[:24])
 for t in r['components_by_magnitude'][:3]:
  print(' top',t['cut_id'],t['metadata']['kind'],t['metadata']['variant_ids'],float(t['norm_over_total']))

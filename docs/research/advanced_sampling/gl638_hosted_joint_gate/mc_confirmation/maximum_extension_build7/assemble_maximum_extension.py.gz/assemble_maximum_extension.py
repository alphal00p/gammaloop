"""Extend the existing lossless archive convention; no Gamma calls or input writes."""
import gzip, hashlib, json, os
from pathlib import Path
packet=Path('/tmp/gl638-hosted-joint-gate')
draft=Path('/tmp/gl638-confirmation-build7-draft/maximum_extension')
archive=Path('/common/dev/gammaloop_ir_safe_thresholds/docs/research/advanced_sampling/gl638_hosted_joint_gate')
intended=archive/'mc_confirmation/maximum_extension_build7'
known={}; entries={}
for index in sorted(archive.rglob('artifact_hashes*.json')):
    data=json.loads(index.read_text())
    if not isinstance(data,dict): continue
    for value in data.values():
        if not isinstance(value,dict) or not {'stored_path','sha256_uncompressed','bytes_uncompressed'}<=value.keys(): continue
        path=(index.parent/value['stored_path']).resolve()
        if path.is_file(): known.setdefault((value['sha256_uncompressed'],value['bytes_uncompressed']),path)

def store(source,name):
    source=Path(source); raw=source.read_bytes(); key=hashlib.sha256(raw).hexdigest(),len(raw)
    if key not in known:
        destination=intended/(name+'.gz'); target=draft/(name+'.gz'); target.parent.mkdir(parents=True,exist_ok=True)
        target.write_bytes(gzip.compress(raw,mtime=0)); known[key]=destination
    entries[name]={'sha256_uncompressed':key[0],'bytes_uncompressed':key[1],'stored_path':os.path.relpath(known[key],intended),'original_path':str(source)}

for directory,name in [('results-max-confirmation-top4-build7','top4/results'),('results-max-native-trace-confirmation-build7','traces/two_points'),('results-max-native-trace-confirmation-im-build7','traces/imaginary_point'),('confirmation-max-native-trace-analysis-build7','analysis/two_points'),('confirmation-max-native-trace-im-analysis-build7','analysis/imaginary_point')]:
    for path in sorted((packet/directory).iterdir()):
        if path.is_file():store(path,name+'/'+path.name)
for stem,owner in [('max-confirmation-top4','top4'),('max-native-trace-confirmation','traces/two_points'),('max-native-trace-confirmation-im','traces/imaginary_point')]:
    for source,name in [(packet/f'{stem}-build7-run.json','run.json'),(packet/f'results-{stem}-build7.log','run.log'),(packet/f'results-{stem}-build7.resources.txt','resources.txt')]:store(source,owner+'/execution/'+name)
for name in ['max_replay_top4.rs','max-replay-top4-build7.build.json','max_replay_trace.rs','max-trace-build7.build.json','gate-max-support.rs']:
    store(packet/'drivers'/name,'drivers/'+name)
for name in ['audit_maximum_results_top4.py','audit_physical.py','analyze_max_native_trace_confirmation.py','request-max-native-trace-confirmation-build7.json','request-max-native-trace-confirmation-im-build7.json']:
    store(packet/name,'protocol/'+name)
for name in ['same_point_factor.json','native_component_joins.json','top4_control_reuse_audit.json']:
    store(packet/'confirmation-max-attribution-draft-build7'/name,'analysis/'+name)
store(Path(__file__),'assemble_maximum_extension.py')
draft.mkdir(parents=True,exist_ok=True)
(draft/'artifact_hashes.json').write_text(json.dumps(entries,indent=2)+'\n')
for value in entries.values():
    path=(intended/value['stored_path']).resolve()
    if path.is_relative_to(intended):path=draft/path.relative_to(intended)
    raw=gzip.decompress(path.read_bytes()) if path.suffix=='.gz' else path.read_bytes()
    assert hashlib.sha256(raw).hexdigest()==value['sha256_uncompressed'] and len(raw)==value['bytes_uncompressed']
provenance={'status':'completed_lossless_artifact_extension','original_confirmation':'../results_build7/provenance.json','original_maximum_replay':'../maximum_build7/provenance.json','purpose':'Complete true imaginary maximum Arb control and three unique final b/c point geometries; no added Monte Carlo samples or statistics changes','controls':{'old_top2':6,'actual_top4':12,'top4_metric_checks':605,'control_reuse_checks':78,'native_trace_cases':3,'exact_trace_controls':True,'reconstructed_single_stars':56,'reconstructed_merged_points':12,'checked_actual_A_U_multipliers':12},'scope':'Retained signed extrema, identity-probe native reconstruction, pointwise geometry only; no unrecorded global normmaximum or global boundedness claim','archive_convention':'Lossless gzip with exact original uncompressed hashes/sizes; identical bytes reference prior immutable records. No state payload, executable or compiled library copied. Original pilot/maximum/trace directories remain unchanged.','records':len(entries),'stored_gzip_files':len(list(draft.rglob('*.gz'))),'stored_bytes':sum(p.stat().st_size for p in draft.rglob('*.gz'))}
(draft/'provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
print(json.dumps(provenance))

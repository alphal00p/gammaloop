#!/usr/bin/env python3
"""Compare one root-confirmed completed seed-10007 run, without pooling it.

Usage: audit_successful_source_invariance.py MODE
Only the original three successful methods are accepted. Never evaluates Gamma
or writes into either pilot directory. Binary checkpoints are hashed, not decoded.
"""

from pathlib import Path
import hashlib
import json
import struct
import sys
import tomllib

PACKET = Path("/tmp/gl638-hosted-joint-gate")
MODES = ("optimized_lmb", "cuts", "cuts_combined_joint")
TIMINGS = {
    "average_total_time_seconds",
    "average_parameterization_time_seconds",
    "average_integrand_time_seconds",
    "average_evaluator_time_seconds",
    "average_observable_time_seconds",
    "average_integrator_time_seconds",
}


def differences(left, right, path=""):
    if type(left) is not type(right):
        return [{"path": path, "old": left, "new": right}]
    if isinstance(left, dict):
        result = []
        for key in sorted(left.keys() | right.keys()):
            current = path + "/" + key
            if key not in left or key not in right:
                result.append(
                    {
                        "path": current,
                        "old": left.get(key),
                        "new": right.get(key),
                        "missing_old": key not in left,
                        "missing_new": key not in right,
                    }
                )
            else:
                result.extend(differences(left[key], right[key], current))
        return result
    if isinstance(left, list):
        result = []
        if len(left) != len(right):
            result.append(
                {"path": path + "/length", "old": len(left), "new": len(right)}
            )
        for index, (a, b) in enumerate(zip(left, right)):
            result.extend(differences(a, b, path + "/" + str(index)))
        return result
    equal = (
        struct.pack(">d", left) == struct.pack(">d", right)
        if isinstance(left, float)
        else left == right
    )
    return [] if equal else [{"path": path, "old": left, "new": right}]


def audit(mode):
    if mode not in MODES:
        raise ValueError("only the first three previously completed seed-10007 runs")
    report = {
        "mode": mode,
        "seed": 10007,
        "passed": False,
        "input_sha256": {},
        "scope": "Measured invariance of complete published numerical checkpoint/result JSON from one previously successful source schedule. No pooling, ranking, new acceptance or raw bincode field-equality claim.",
        "float_comparison": "Exact binary64 bits after JSON parsing, including signed zero.",
        "excluded_timing_fields": sorted(TIMINGS),
        "precision_reporting": "Retained separately, never silently excluded from the all-non-timing equality result.",
    }

    def content(path):
        raw = path.read_bytes()
        report["input_sha256"][str(path)] = hashlib.sha256(raw).hexdigest()
        return raw

    sides = []
    for build in (5, 7):
        pilot = PACKET / f"results-confirmation-build{build}/pilot/{mode}_seed10007"
        workspace = pilot / "workspace"
        data = json.loads(content(workspace / "integration_result.json"))
        iteration = json.loads(
            content(workspace / "results/integration_result_iter_0001.json")
        )
        if differences(data, iteration):
            raise ValueError(
                "latest result differs from complete iteration-one checkpoint JSON"
            )
        if len(data["slots"]) != 1:
            raise ValueError("expected exactly one graph-integrand slot")
        slot = data["slots"][0]
        stats = slot["integration_statistics"]
        if (
            slot["integral"]["neval"] != 32768
            or slot["absolute"]["integral"]["neval"] != 32768
            or stats["num_evals"] != 32768
            or stats["nan_percentage"] != 0
            or stats["nan_or_unstable_percentage"] != 0
        ):
            raise ValueError("only completed stable 32768-source runs may be compared")
        stability = {}
        for name in ("global", "epem_a_tth@NNLO"):
            current = json.loads(
                content(workspace / f"numerical_stability/{name}.json")
            )
            iteration = json.loads(
                content(workspace / f"numerical_stability/{name}_iter_0001.json")
            )
            if differences(current, iteration):
                raise ValueError("stability latest and completed checkpoint differ")
            stability[name] = current
        checkpoint = content(workspace / "state/integration_state.bin")
        sides.append(
            {
                "result": data,
                "stability": stability,
                "manifest": json.loads(content(workspace / "manifest.json")),
                "effective_settings": tomllib.loads(
                    content(pilot / "effective-settings.toml").decode()
                ),
                "saved_settings": tomllib.loads(
                    content(
                        workspace / "integrands/epem_a_tth@NNLO/settings.toml"
                    ).decode()
                ),
                "checkpoint_sha256": hashlib.sha256(checkpoint).hexdigest(),
                "checkpoint_bytes": len(checkpoint),
            }
        )
    old, new = sides
    result_diff = differences(old["result"], new["result"])
    report["timing_differences"] = [
        d for d in result_diff if d["path"].split("/")[-1] in TIMINGS
    ]
    report["non_timing_result_differences"] = [
        d for d in result_diff if d["path"].split("/")[-1] not in TIMINGS
    ]
    report["all_non_timing_result_fields_equal"] = not report[
        "non_timing_result_differences"
    ]
    physics_sections = (
        "key",
        "process",
        "integrand",
        "target",
        "integral",
        "table_results",
        "max_weight_info",
        "grid_breakdown",
        "absolute",
    )
    report["numerical_sections"] = {
        key: {
            "equal": not differences(
                old["result"]["slots"][0][key], new["result"]["slots"][0][key]
            )
        }
        for key in physics_sections
    }
    report["numerical_differences"] = [
        d
        for d in result_diff
        if len(d["path"].split("/")) > 3 and d["path"].split("/")[3] in physics_sections
    ]
    report["settings_equal"] = not differences(
        old["effective_settings"], new["effective_settings"]
    ) and not differences(old["saved_settings"], new["saved_settings"])
    report["manifest_differences"] = differences(old["manifest"], new["manifest"])
    report["numerical_stability_differences"] = differences(
        old["stability"], new["stability"]
    )
    report["precision_counts"] = []
    for side in sides:
        stats = side["result"]["slots"][0]["integration_statistics"]
        report["precision_counts"].append(
            {
                key: stats[key] * 32768 / 100
                for key in ("f64_percentage", "f128_percentage", "arb_percentage")
            }
        )
    report["sampling_bin_occupancy"] = [
        [
            {
                "bin_index": row["bin_index"],
                "processed_samples": row["processed_samples"],
            }
            for row in side["result"]["slots"][0]["grid_breakdown"]["re"]["entries"]
        ]
        for side in sides
    ]
    report["binary_checkpoints"] = {
        "old": {k: old[k] for k in ("checkpoint_sha256", "checkpoint_bytes")},
        "new": {k: new[k] for k in ("checkpoint_sha256", "checkpoint_bytes")},
        "bytes_equal": old["checkpoint_sha256"] == new["checkpoint_sha256"],
        "scope": "No bincode decoding; timings/provenance and diagnostic counters can change these bytes.",
    }
    report["passed"] = report["settings_equal"] and all(
        x["equal"] for x in report["numerical_sections"].values()
    )
    report["conclusion"] = (
        "Integral/absolute/extremum/source-coordinate and full sampling-bin numerical fields are exactly equal; precision reporting differences remain explicit."
        if report["passed"]
        else "At least one compared numerical result or setting differs; retain the exact differences for review."
    )
    return report


def main():
    if len(sys.argv) != 2:
        raise SystemExit(__doc__)
    mode = sys.argv[1]
    result = audit(mode)
    out = PACKET / "successful-source-invariance-build7"
    out.mkdir(exist_ok=True)
    (out / f"{mode}.json").write_text(json.dumps(result, indent=2) + "\n")
    print(
        json.dumps(
            {
                key: result[key]
                for key in (
                    "mode",
                    "passed",
                    "all_non_timing_result_fields_equal",
                    "precision_counts",
                )
            }
        )
    )
    return 0 if result["passed"] else 1


if __name__ == "__main__":
    sys.exit(main())

"""Read retained JSON/TOML only; independent Decimal check of complete frozen confirmation statistics.
Reuses the prior screen audit arithmetic; no candidate reselection or new estimator."""
import copy, hashlib, json, math, tomllib
from decimal import Decimal as D, getcontext
from pathlib import Path
getcontext().prec = 70
ROOT = Path('/tmp/gl638-hosted-joint-gate')
OUT = Path(__file__).parent
report_path = ROOT/'results-confirmation-build7/physics_pilot_analysis.json'
read = lambda p: json.loads(Path(p).read_text())
hashof = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
report = read(report_path)
manifest_path = ROOT/'manifest-confirmation-build7.json'
manifest = read(manifest_path)
screen_path=ROOT/'screen-selection-frozen-build5.json'
screen=read(screen_path)
n_expected=32768
k_expected=5
checks = []
def check(name, ok):
    checks.append({'name': name, 'passed': bool(ok)})
    if not ok:
        raise AssertionError(name)
def close(a, b):
    a, b = D(str(a)), D(str(b))
    return abs(a-b) <= D('2e-14') * max(abs(a), abs(b), D('1e-100'))
check('complete final confirmation report', report['passed'] and not report['failures'] and report['stage']=='confirmation')
check('frozen screen and selection unchanged', hashof(screen_path)==manifest['confirmation_screen_report_sha256']==report['screen_sha256'] and report['selection']==screen['selection']==manifest['confirmation_frozen_selection'] and screen['passed'])
check('exact preregistered method/seed/N schedule', manifest['proposal_order']==['optimized_lmb','cuts','cuts_combined_joint'] and manifest['paired_seeds']==[10007,20011,30013,40009,50021] and manifest['samples_per_run']==n_expected and report['workers']==20 and not set(manifest['paired_seeds']) & set(screen['seeds']))
check('all recorded input hashes unchanged', all(hashof(p) == h for p,h in report['input_sha256'].items()))
check('manifest matches report', hashof(manifest_path) == report['manifest_sha256'])
expected = {(m,s) for m in manifest['proposal_order'] for s in manifest['paired_seeds']}
check('exact 15 unique rows', len(report['runs']) == len(expected) == 15 and {(r['mode'],r['seed']) for r in report['runs']} == expected)
preflight = read(report['common_preflight'])
proof=report['endpoint_repair_compatibility'];lineage=read(proof['lineage_path'])
check('exact accepted endpoint-repair lineage and original preflight', proof['passed'] and hashof(proof['lineage_path'])==proof['lineage_sha256']==manifest['endpoint_repair_lineage']['sha256'] and proof['new_build_identity']==report['build_identity']==lineage['new_build_identity'] and proof['old_build_identity']==preflight['build_identity']==screen['build_identity']==lineage['old_build_identity'])
check('sole new confirmation directory; no old partial runs', report['pilot_directories']==[str((ROOT/'results-confirmation-build7').resolve())] and not report['excluded_controls'])
raw = {}
common = None
for directory in report['pilot_directories']:
    directory = Path(directory)
    summary = read(directory/'summary.json')
    check(f'{directory.name}: accepted same build/state/preflight', summary['workers'] == 20 and summary['status'] == 'completed_requested_stages' and summary['error'] is None and summary['preflight_accepted'] and summary['saved_state_unchanged'] and summary['physics_audit']['passed'] and summary['build_identity'] == report['build_identity'] and summary['state_hashes'] == preflight['state_hashes'] and Path(summary['preflight_reused_from']).resolve() == Path(report['common_preflight']).resolve())
    check(f'{directory.name}: same actual endpoint proof', summary['endpoint_repair_compatibility']==proof)
    pilot_rows=read(directory/'pilots.json')
    check(f'{directory.name}: actual complete 15 workspaces', len(pilot_rows)==15 and {(r['mode'],r['seed']) for r in pilot_rows}==expected and all(r['result']['finite_complete'] and r['sample_count']==n_expected and r['cores']==20 for r in pilot_rows))
    check(f'{directory.name}: 35 unchanged state hashes', read(directory/'state_before.json') == read(directory/'state_after.json') == preflight['state_hashes'] and len(preflight['state_hashes']) == 35)
for r in report['runs']:
    key = f"{r['mode']}/{r['seed']}"
    check(key+': workspace inside fresh confirmation', Path(r['retained_driver_record']['workspace']).resolve().is_relative_to((ROOT/'results-confirmation-build7').resolve()))
    slot = read(r['result_path'])['slots'][0]
    raw[r['mode'],r['seed']] = slot
    settings = tomllib.loads(Path(r['settings_path']).read_text())
    card_path = Path(manifest['cards'][r['mode']])
    card = tomllib.loads(card_path.read_text())
    check(key+': raw result matches retained row', slot == r['slot'])
    check(key+': card hash and selection', hashof(card_path) == manifest['card_sha256'][str(card_path)] and settings['sampling']['channel_selection'] == card['sampling']['channel_selection'])
    check(key+': original settings and fixed N', settings['integrator']['seed'] == r['seed'] and settings['integrator']['n_start'] == settings['integrator']['n_max'] == n_expected and settings['integrator']['n_increase'] == 0 and r['retained_driver_record']['cores'] == 20 and r['retained_driver_record']['sample_count'] == n_expected)
    stat = slot['integration_statistics']
    check(key+': signed/abs/stat counts and validity', r['eligible'] and slot['integral']['neval'] == slot['absolute']['integral']['neval'] == stat['num_evals'] == n_expected and stat['nan_percentage'] == stat['nan_or_unstable_percentage'] == 0)
    physics = copy.deepcopy(settings)
    physics.pop('sampling'); physics['integrator'].pop('seed')
    if common is None: common = physics
    check(key+': common physical settings', physics == common)
computed = {}
for method in report['pooled']:
    mode = method['mode']; observables = {}
    for key in ('re','abs_re','im','abs_im'):
        phase = key.removeprefix('abs_')
        integrals = [raw[mode,s]['absolute']['integral'] if key.startswith('abs_') else raw[mode,s]['integral'] for s in manifest['paired_seeds']]
        values = [D(str(x['result'][phase])) for x in integrals]
        errors = [D(str(x['error'][phase])) for x in integrals]
        n,k = D(n_expected),D(k_expected); total = n*k; mean = sum(values)/k
        between = sum((x-mean)**2 for x in values)
        m2 = sum(n*(n-1)*e*e+n*(x-mean)**2 for x,e in zip(values,errors))
        result = {'mean':mean,'standard_error':(m2/(total*(total-1))).sqrt(), 'sample_variance':m2/(total-1),'sum_squares':m2+total*mean*mean,'seed_mean_standard_error':(between/(k*(k-1))).sqrt()}
        check(f'{mode}/{key}: independent pooling', method['observables'][key]['samples'] == n_expected*k_expected and all(close(v,method['observables'][key][q]) for q,v in result.items()))
        observables[key] = {q:float(v) for q,v in result.items()}
        observables[key].update(seed_means=[float(v) for v in values],seed_errors=[float(v) for v in errors],seed_mean_error_over_pooled_error=float(result['seed_mean_standard_error']/result['standard_error']))
    maxima = {}
    for phase in ('re','im'):
        largest = max(abs(x['max_eval']) for s in manifest['paired_seeds'] for x in raw[mode,s]['max_weight_info'] if x['component']==phase)
        check(f'{mode}/{phase}: maximum across included rows only', largest == method['maxima'][phase]['largest_absolute_weight'])
        fraction_sq=D(str(largest))**2/D(str(observables[phase]['sum_squares']))
        fraction_abs=D(str(largest))/(n*k*D(str(observables['abs_'+phase]['mean'])))
        check(f'{mode}/{phase}: maximum influence',close(fraction_sq,method['maxima'][phase]['fraction_of_empirical_sum_squares']) and close(fraction_abs,method['maxima'][phase]['fraction_of_absolute_integral_sum']))
        maxima[phase] = largest
    computed[mode] = {'observables':observables,'maxima_pb':maxima,'maximum_influence':{phase:{key:method['maxima'][phase][key] for key in ['fraction_of_empirical_sum_squares','fraction_of_absolute_integral_sum']} for phase in ('re','im')}}
scales=screen['selection']['absolute_phase_scales']
check('old screen scales retained exactly',report['selection']['absolute_phase_scales']==scales)
for method in report['pooled']:
    mode=method['mode']
    score=max(v['sample_variance']/scales[k.removeprefix('abs_')]**2 for k,v in computed[mode]['observables'].items())
    check(mode+': normalized score', close(score,method['score']))
    computed[mode]['score']=score
selected=screen['selection']['confirmation_modes']
check('frozen primary method retained without reselection',report['selection']['confirmation_modes']==selected==manifest['proposal_order'] and report['selection']['primary_estimate_mode']=='cuts_combined_joint')
comparisons=[]
for candidate,baseline in [('cuts_combined_joint','cuts'),('cuts','optimized_lmb'),('cuts_combined_joint','optimized_lmb')]:
    for key in ('re','abs_re','im','abs_im'):
        a,b=computed[candidate]['observables'][key],computed[baseline]['observables'][key]
        differences=[D(str(x))-D(str(y)) for x,y in zip(a['seed_means'],b['seed_means'])]
        difference=sum(differences)/D(k_expected)
        pair_se=(sum((x-difference)**2 for x in differences)/D(k_expected*(k_expected-1))).sqrt()
        ratio=D(str(a['sample_variance']))/D(str(b['sample_variance']))
        entry={'candidate':candidate,'baseline':baseline,'observable':key,'variance_ratio':float(ratio),
               'mean_difference_pb':float(difference),'paired_seed_difference_SE_pb':float(pair_se),
               'paired_difference_over_SE_descriptive':float(difference/pair_se),
               'paired_seed_differences_pb':[float(x) for x in differences],
               'all_seed_difference_signs':[1 if x>0 else (-1 if x<0 else 0) for x in differences]}
        if baseline=='cuts':
            retained=next(x for x in report['matched_comparisons'] if x['candidate']==candidate and x['baseline']==baseline and x['observable']==key)
            check(candidate+'/'+baseline+'/'+key+': existing paired comparison',close(ratio,retained['pooled_variance_ratio']) and close(difference,retained['mean_difference']) and close(pair_se,retained['seed_difference_standard_error']) and all(close(x,y) for x,y in zip(differences,retained['paired_seed_differences'])))
        comparisons.append(entry)
screen_methods={m['mode']:m for m in screen['pooled']}
historical=[]
for mode in manifest['proposal_order']:
    for key in ('re','abs_re','im','abs_im'):
        old,new=screen_methods[mode]['observables'][key],computed[mode]['observables'][key]
        difference=D(str(new['mean']))-D(str(old['mean']))
        combined=(D(str(new['standard_error']))**2+D(str(old['standard_error']))**2).sqrt()
        historical.append({'mode':mode,'observable':key,'confirmation_mean_pb':new['mean'],'screen_mean_pb':old['mean'],
            'difference_pb':float(difference),'combined_empirical_SE_pb':float(combined),
            'difference_over_combined_SE_descriptive':float(difference/combined),
            'confirmation_to_screen_sample_variance_ratio':new['sample_variance']/old['sample_variance']})
summary={'passed':True,'scope':'Artifact-only independent Decimal70 audit reusing the prior screen arithmetic; no Gamma/state load or pilot-directory writes, no new estimator or candidate reselection.',
         'checks':checks,'included_runs':15,'draws_per_method':n_expected*k_expected,'total_draws':15*n_expected,'workers':20,
         'selection':selected,'primary_estimate_mode':'cuts_combined_joint','absolute_phase_scales':scales,'methods':computed,
         'comparisons':comparisons,'historical_screen_comparison':historical,
         'input_sha256':{str(report_path):hashof(report_path),str(manifest_path):hashof(manifest_path),str(screen_path):hashof(screen_path),str(ROOT/'screen-independent-audit/audit.py'):hashof(ROOT/'screen-independent-audit/audit.py'),str(Path(__file__).resolve()):hashof(__file__)},
         'validated_recorded_input_hashes':len(report['input_sha256']),
         'limits':['Preregistered c remains primary although its worst normalized variance score is higher than cuts-only in confirmation.',
                   'Five-seed dispersion and standardized differences are descriptive; heavy-tailed errors and finite variance are not certified.',
                   'The same seed schedule does not mean the same physical points. Signed means and absolute moments remain separately visible.',
                   'Maxima below are retained signed-component extrema. Their exact complete Samples and native accuracy require the separate maximum replay.',
                   'No old screen or interrupted build5 confirmation samples are pooled into these estimates. This is the GL638 graph contribution, not the full ttH process.']}
(OUT/'summary.json').write_text(json.dumps(summary,indent=2,allow_nan=False)+'\n')
lines=['All 15 runs passed: 5 × 32768 samples per method (163840 each; 491520 total), 20 workers.','',
       'Means and empirical standard errors are in 10⁻⁴ pb; maxima are absolute signed-component extrema in pb.','',
       '| Method | Re ± SE | Abs Re ± SE | Im ± SE | Abs Im ± SE | Max Re / Im (pb) | Frozen-scale score |',
       '|---|---:|---:|---:|---:|---:|---:|']
for mode in manifest['proposal_order']:
    v=computed[mode];cells=[f"{v['observables'][key]['mean']*1e4:.6g} ± {v['observables'][key]['standard_error']*1e4:.5g}" for key in ('re','abs_re','im','abs_im')]
    lines.append('| '+mode+' | '+' | '.join(cells)+f" | {v['maxima_pb']['re']:.6g} / {v['maxima_pb']['im']:.6g} | {v['score']:.7g} |")
lines+=['','The frozen primary is cuts_combined_joint. Its sample-variance ratios versus cuts-only are 1.10754 for Re and 0.649312 for Im; the absolute-component ratios are nearly identical. Its worst normalized score is 10.75% higher than cuts-only, so the screen’s broad gain over cuts is not confirmed.','',
        'Primary GL638 graph estimate: Re (1.15444 ± 1.07450) ×10⁻⁴ pb; Im (−0.0135545 ± 0.892727) ×10⁻⁴ pb. These are pooled empirical errors. The five-seed mean-dispersion errors are 1.60928×10⁻⁴ and 1.11355×10⁻⁴ pb, respectively; five seeds do not calibrate tail probabilities.','',
        'Largest weights contribute 48.17% (Re) and 18.12% (Im) of the primary method’s empirical sum of squared weights. For LMB they contribute 63.03% and 39.45%; for cuts-only, 39.20% and 40.28%. The errors remain sensitive to rare large contributions.','',
        'Absolute means differ substantially between methods, especially optimized LMB versus the two cut-based methods. These remain convergence diagnostics; neither this finite sample nor its standardized differences prove a bias, calibrated significance, finite variance, or global boundedness.','',
        f'{len(checks)} independent checks passed. All {len(report["input_sha256"])} recorded input hashes match, all 35 state hashes are unchanged, and the exact build7 repair proof/frozen selection/cards were retained. Detailed per-seed values, paired differences and separate historical comparisons are in summary.json. No candidate was reselected.']
(OUT/'summary.md').write_text('\n'.join(lines)+'\n')
print('\n'.join(lines));print('JSON',OUT/'summary.json',hashof(OUT/'summary.json'))

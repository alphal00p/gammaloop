All 15 runs passed: 5 × 32768 samples per method (163840 each; 491520 total), 20 workers.

Means and empirical standard errors are in 10⁻⁴ pb; maxima are absolute signed-component extrema in pb.

| Method | Re ± SE | Abs Re ± SE | Im ± SE | Abs Im ± SE | Max Re / Im (pb) | Frozen-scale score |
|---|---:|---:|---:|---:|---:|---:|
| optimized_lmb | -2.51161 ± 1.3955 | 9.90813 ± 1.3953 | -4.30107 ± 1.8401 | 14.9515 ± 1.8398 | 18.1509 / 18.9359 | 8344.468 |
| cuts | 0.930612 ± 1.021 | 4.14422 ± 1.021 | 0.627503 ± 1.1079 | 5.43792 ± 1.1078 | 10.4734 / 11.5199 | 4467.037 |
| cuts_combined_joint | 1.15444 ± 1.0745 | 3.80035 ± 1.0745 | -0.0135545 ± 0.89273 | 4.60965 ± 0.89265 | 12.219 / 6.22638 | 4947.443 |

The frozen primary is cuts_combined_joint. Its sample-variance ratios versus cuts-only are 1.10754 for Re and 0.649312 for Im; the absolute-component ratios are nearly identical. Its worst normalized score is 10.75% higher than cuts-only, so the screen’s broad gain over cuts is not confirmed.

Primary GL638 graph estimate: Re (1.15444 ± 1.07450) ×10⁻⁴ pb; Im (−0.0135545 ± 0.892727) ×10⁻⁴ pb. These are pooled empirical errors. The five-seed mean-dispersion errors are 1.60928×10⁻⁴ and 1.11355×10⁻⁴ pb, respectively; five seeds do not calibrate tail probabilities.

Largest weights contribute 48.17% (Re) and 18.12% (Im) of the primary method’s empirical sum of squared weights. For LMB they contribute 63.03% and 39.45%; for cuts-only, 39.20% and 40.28%. The errors remain sensitive to rare large contributions.

Absolute means differ substantially between methods, especially optimized LMB versus the two cut-based methods. These remain convergence diagnostics; neither this finite sample nor its standardized differences prove a bias, calibrated significance, finite variance, or global boundedness.

135 independent checks passed. All 168 recorded input hashes match, all 35 state hashes are unchanged, and the exact build7 repair proof/frozen selection/cards were retained. Detailed per-seed values, paired differences and separate historical comparisons are in summary.json. No candidate was reselected.

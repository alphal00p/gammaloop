"""Retain completed artifacts only; never write original workspaces or run GammaLoop."""
import gzip
import hashlib
import json
import os
from pathlib import Path

packet = Path('/tmp/gl638-hosted-joint-gate')
draft = Path('/tmp/gl638-confirmation-build7-draft')
archive = Path('/common/dev/gammaloop_ir_safe_thresholds/docs/research/advanced_sampling/gl638_hosted_joint_gate')
intended = archive / 'mc_confirmation'
owners = {'protocol': 'protocol_build7', 'results': 'results_build7',
          'analysis': 'analysis_build7', 'maximum': 'maximum_build7'}
known = {}
indices = {}

# Reuse the existing hash-index convention, including immutable prior source/cards.
for index in sorted(archive.rglob('artifact_hashes*.json')):
    entries = json.loads(index.read_text())
    if not isinstance(entries, dict):
        continue
    for entry in entries.values():
        if not isinstance(entry, dict) or not {'stored_path', 'sha256_uncompressed', 'bytes_uncompressed'} <= entry.keys():
            continue
        path = (index.parent / entry['stored_path']).resolve()
        if path.is_file():
            known.setdefault((entry['sha256_uncompressed'], entry['bytes_uncompressed']), path)
for entry in json.loads((draft / 'protocol/artifact_hashes.json').read_text()).values():
    path = (intended / 'protocol_build7' / entry['stored_path']).resolve()
    known.setdefault((entry['sha256_uncompressed'], entry['bytes_uncompressed']), path)


def actual(path):
    for local, target in owners.items():
        prefix = intended / target
        if path.is_relative_to(prefix):
            return draft / local / path.relative_to(prefix)
    return path


def store(owner, source, name):
    source = Path(source)
    raw = source.read_bytes()
    digest = hashlib.sha256(raw).hexdigest()
    key = digest, len(raw)
    base = intended / owners[owner]
    if key not in known:
        destination = base / (name + '.gz')
        target = actual(destination)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(gzip.compress(raw, mtime=0))
        known[key] = destination
    indices.setdefault(owner, {})[name] = {
        'sha256_uncompressed': digest, 'bytes_uncompressed': len(raw),
        'stored_path': os.path.relpath(known[key], base), 'original_path': str(source),
    }


for path in sorted((packet / 'results-confirmation-build7').rglob('*')):
    if path.is_file():
        store('results', path, str(path.relative_to(packet / 'results-confirmation-build7')))
for path in sorted((packet / 'results-max-confirmation-build7').iterdir()):
    if path.is_file():
        store('maximum', path, path.name)
for owner, stem in [('results', 'confirmation'), ('maximum', 'max-confirmation')]:
    store(owner, packet / f'{stem}-build7-run.json', 'execution/run.json')
    store(owner, packet / f'results-{stem}-build7.log', 'execution/run.log')
    store(owner, packet / f'results-{stem}-build7.resources.txt', 'execution/resources.txt')
for path in sorted((packet / 'confirmation-build7-independent-audit').iterdir()):
    if path.is_file():
        store('analysis', path, 'independent/' + path.name)
for path in sorted((packet / 'confirmation-maximum-independent-audit').iterdir()):
    if path.is_file():
        store('maximum', path, 'independent/' + path.name)
for name in ['physics_pilot_analysis.json', 'physics_pilot_analysis.md']:
    store('analysis', packet / 'results-confirmation-build7' / name, name)
store('analysis', packet / 'analyze_physics_pilots.py', 'analyze_physics_pilots.py')
store('analysis', packet / 'audit_successful_source_invariance.py', 'first_seed_invariance/audit.py')
for path in sorted((packet / 'successful-source-invariance-build7').glob('*.json')):
    store('analysis', path, 'first_seed_invariance/' + path.name)
store('analysis', Path(__file__), 'assemble_final_archive.py')
store('maximum', packet / 'audit_maximum_results.py', 'audit_maximum_results.py')
store('maximum', packet / 'audit_physical.py', 'audit_physical.py')

for owner, entries in indices.items():
    folder = draft / owner
    (folder / 'artifact_hashes.json').write_text(json.dumps(entries, indent=2) + '\n')
    for entry in entries.values():
        path = actual((intended / owners[owner] / entry['stored_path']).resolve())
        raw = gzip.decompress(path.read_bytes()) if path.suffix == '.gz' else path.read_bytes()
        assert len(raw) == entry['bytes_uncompressed']
        assert hashlib.sha256(raw).hexdigest() == entry['sha256_uncompressed']
    stored = list(folder.rglob('*.gz'))
    print(owner, len(entries), 'records;', len(stored), 'stored files;', sum(p.stat().st_size for p in stored), 'bytes')

# All exact inputs hashed before/after maximum replay have durable logical records.
maximum = json.loads((packet / 'results-max-confirmation-build7/summary.json').read_text())
assert maximum['pilot_files_before'] == maximum['pilot_files_after']
assert set(maximum['pilot_files_after']) == {str(p.relative_to(packet / 'results-confirmation-build7')) for p in (packet / 'results-confirmation-build7').rglob('*') if p.is_file()}
for name, digest in maximum['pilot_files_after'].items():
    assert indices['results'][name]['sha256_uncompressed'] == digest
assert sum(name.endswith('/integration_state.bin') for name in indices['results']) == 15
print('All 222 frozen pilot files and 15 complete integration checkpoints retained.')

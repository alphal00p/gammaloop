#!/usr/bin/env python3
"""Artifact-only provenance checks; synthetic build bytes never claim a Gamma run."""
from pathlib import Path
import copy
import hashlib
import importlib.util
import json
import subprocess
import sys

ROOT = Path('/tmp/gl638-hosted-joint-gate')
OUT = Path(__file__).resolve().parent
FIXTURE = OUT / 'synthetic-build-artifacts'
FIXTURE.mkdir(exist_ok=True)

def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod

current = load('endpoint_current', ROOT / 'analyze_physics_pilots.py')
previous = load('endpoint_previous', ROOT / 'analyze_physics_pilots_before_endpoint_repair.py')
sha = current.digest

def save(name, value):
    p = FIXTURE / name
    p.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')
    return str(p)

old_manifest = current.read(ROOT / 'manifest-confirmation-build5.json')
old_screen = current.read(ROOT / 'screen-selection-frozen-build5.json')
old_build = old_screen['build_identity']
paths = {}
for name in ('source.patch', 'driver.rs', 'driver', 'cli', 'core.rlib', 'api.rlib', 'source-audit.json', 'source-gates.json', 'replay.json'):
    path = FIXTURE / name
    path.write_text('SYNTHETIC ARTIFACT-VALIDATOR FIXTURE; NOT A BUILD OR PHYSICAL ACCEPTANCE\n' + name + '\n')
    paths[name] = str(path)
# Reuse actual completed source evidence; only compiler/linker bytes remain synthetic.
Path(paths['source.patch']).write_bytes((ROOT/'root-endpoint-source-build7.patch').read_bytes())
Path(paths['source-audit.json']).write_bytes((ROOT/'endpoint-repair-evidence/source_audit.json').read_bytes())
Path(paths['source-gates.json']).write_bytes((ROOT/'endpoint-repair-evidence/source_gates.json').read_bytes())
new_build = dict(old_build, source_base_commit=current.read(paths['source-audit.json'])['source_base_commit'], driver_sha256=sha(paths['driver']),
                 candidate_binary_sha256=sha(paths['cli']),
                 source_candidate_patch_sha256=sha(paths['source.patch']))
core = {'head':new_build['source_base_commit'], 'returncode':0, 'source_unchanged':True,
        'source_patch_sha256':new_build['source_candidate_patch_sha256'], 'cargo_pid':12345}
driver = {'status':'compiled','returncode':0,'resolve_only':False,
          'binary_sha256':new_build['driver_sha256'],'source_sha256':sha(paths['driver.rs']),
          'argv':['rustc',paths['driver.rs'],'-o',paths['driver'],
                  '--extern','gammalooprs='+paths['core.rlib'],
                  '--extern','gammaloop_api='+paths['api.rlib']],
          'compiler_captures':{n:{'crate_name':n,'cargo_pid':12345} for n in ('gammalooprs','gammaloop_api')},
          'dependencies':{n:{'path':paths[file],'sha256':sha(paths[file])}
                          for n,file in [('gammalooprs','core.rlib'),('gammaloop_api','api.rlib')]}}
core_path, driver_path = save('core-build.json',core), save('driver-build.json',driver)
manifest = copy.deepcopy(old_manifest)
manifest.update(source_base_commit=new_build['source_base_commit'],candidate_driver=paths['driver'],candidate_binary=paths['cli'],
                candidate_driver_source=paths['driver.rs'],candidate_driver_source_sha256=sha(paths['driver.rs']),
                candidate_driver_sha256=new_build['driver_sha256'], candidate_binary_sha256=new_build['candidate_binary_sha256'],
                source_candidate_patch=paths['source.patch'],source_candidate_patch_sha256=new_build['source_candidate_patch_sha256'],
                candidate_driver_build_record=driver_path,candidate_build_record=core_path,
                endpoint_repair_validator={'path':str(ROOT/'analyze_physics_pilots.py'),'sha256':sha(ROOT/'analyze_physics_pilots.py')})
capture_path = ROOT/'results-source-reduction-seed20011-build5/failure_worker3.json'
capture = current.read(capture_path)
settings_path = current.read(ROOT/'request-source-reduction-seed20011.json')['settings']
request_path = save('replay-request.json',{'capture':str(capture_path),'settings':settings_path,
                   'replay_build_record':driver_path,
                   'input_sha256':{str(capture_path):sha(capture_path),settings_path:sha(settings_path)}})
preflight = current.read(ROOT/'results-cut-combined-seven-preflight-build5/summary.json')
replay = {'status':'completed_captured_replay','error':None,'saved_state_unchanged':True,
          'canonical_map_exact':True,'state_before':preflight['state_hashes'],'state_after':preflight['state_hashes'],
          'complete_sample':capture['complete_sample'],'canonical_map':capture['canonical_map'],
          'original_error':capture['error'],'request':request_path,'current_replay_build':driver,
          'calls':[{'force_arb':force,'complete':True,'native':{'evaluation':{'valid':True,
                   'precision':'Arb' if force else 'Quad','events':[{'cut_info':{'cut_id':i}} for i in range(6)]}}}
                   for force in [False,True]],
          'scope':'SYNTHETIC SCHEMA FIXTURE, NO PHYSICAL EVALUATION OR NUMERICAL CLAIM'}
replay_path=save('replay-summary.json',replay)
accuracy={'passed':True,'counts':{'checks':1,'failed_checks':0,'component_relative_misses':0},
          'checks':[{'passed':True,'kind':'ordinary_vs_forced_arb','label':'synthetic, not actual physics',
                     'total':{'passed':True},'cuts':[{'cut_id':i,'passed':True} for i in range(6)]}],
          'input_sha256':{},'scope':'SYNTHETIC SCHEMA FIXTURE, NO NUMERICAL ACCEPTANCE'}
for key,path in [('summary',replay_path),('capture',capture_path),('request',request_path),
                 ('settings',settings_path),('metric_owner',ROOT/'audit_physical.py'),('audit_source',ROOT/'audit_captured_source_replay.py')]:
    accuracy[key]={'path':str(path),'sha256':sha(path)}
Path(paths['replay.json']).write_text(json.dumps(accuracy,indent=2)+'\n')
lineage = {'schema':'gl638-canonical-lu-endpoint-repair-v1','status':'accepted',
           'old_build_identity':old_build,'new_build_identity':new_build,
           'historical':{name:{'path':str(ROOT/file),'sha256':sha(ROOT/file)} for name,file in [
               ('preflight','results-cut-combined-seven-preflight-build5/summary.json'),
               ('screen','screen-selection-frozen-build5.json'),('confirmation_manifest','manifest-confirmation-build5.json')]},
           'evidence':{name:{'path':path,'sha256':sha(path)} for name,path in [
               ('source_patch',paths['source.patch']),('source_audit',paths['source-audit.json']),
               ('source_gates',paths['source-gates.json']),('captured_source_replay',paths['replay.json']),
               ('driver_build',driver_path),('core_build',core_path)]},
           'acceptance':{k:True for k in ['unchanged_successful_solver_paths','unchanged_sampling_and_physics_formulas',
                                         'source_gates_passed','captured_source_replay_passed']}}
checks=[]

def case(name, change=None, expect=True, actual=None):
    m,l=copy.deepcopy(manifest),copy.deepcopy(lineage)
    if change:
        change(m,l)
    lp=save('test-lineage.json',l)
    m['endpoint_repair_lineage']={'path':lp,'sha256':sha(lp)}
    mp=save('test-manifest.json',m)
    try:
        proof=current.validate_endpoint_repair(mp,new_build if actual is None else actual)
        passed=True; error=None
    except (OSError, KeyError, TypeError, ValueError, ArithmeticError) as exc:
        passed=False;error=str(exc)
    checks.append({'name':name,'expected_acceptance':expect,'actual_acceptance':passed,'passed':passed==expect,'error':error})
    assert passed==expect,(name,error)
    return mp

case('accepted synthetic build proof with actual complete frozen screen/preflight')
case('actual executable identity mismatch',expect=False,actual=dict(new_build,driver_sha256='0'*64))
case('pending lineage cannot be accepted',lambda m,l:l.update(status=None),False)
case('declined captured replay cannot be accepted',lambda m,l:l['acceptance'].update(captured_source_replay_passed=False),False)
case('validator hash mutation',lambda m,l:m['endpoint_repair_validator'].update(sha256='0'*64),False)
for name in lineage['evidence']:
    case('changed '+name+' evidence',lambda m,l,n=name:l['evidence'][n].update(sha256='0'*64),False)
# Rehash a failed record, so acceptance cannot rely only on duplicate lineage flags.
def bad_evidence(name, update):
    def change(m,l):
        d=current.read(l['evidence'][name]['path']);update(d)
        path=save('mutated-'+name+'.json',d)
        l['evidence'][name]={'path':path,'sha256':sha(path)}
    return change
case('hash-correct declined source audit',bad_evidence('source_audit',lambda d:d.update(status='pending')),False)
case('hash-correct failed source gates',bad_evidence('source_gates',lambda d:d['final_fixture'].update(passed=0,failed=1)),False)
case('hash-correct wrong source fixture',bad_evidence('source_gates',lambda d:d['final_fixture']['source_files'].update({'crates/gammalooprs/src/utils/newton_solver.rs':'0'*64})),False)
case('hash-correct failed changed-line clippy',bad_evidence('source_gates',lambda d:d['clippy'].update(changed_line_diagnostics=1)),False)
case('hash-correct failed replay accuracy',bad_evidence('captured_source_replay',lambda d:d.update(passed=False)),False)
case('hash-correct absent ordinary/Arb comparison',bad_evidence('captured_source_replay',lambda d:d['checks'][0].update(kind='other')),False)
case('hash-correct failed total accuracy',bad_evidence('captured_source_replay',lambda d:d['checks'][0]['total'].update(passed=False)),False)
case('hash-correct missing cut accuracy',bad_evidence('captured_source_replay',lambda d:d['checks'][0]['cuts'].pop()),False)
case('hash-correct failed replay check',bad_evidence('captured_source_replay',lambda d:d['checks'][0].update(passed=False)),False)
def bad_replay(update):
    def change(m,l):
        raw=copy.deepcopy(replay);update(raw)
        raw_path=save('mutated-replay-summary.json',raw)
        audited=copy.deepcopy(accuracy);audited['summary']={'path':raw_path,'sha256':sha(raw_path)}
        audit_path=save('mutated-replay-accuracy.json',audited)
        l['evidence']['captured_source_replay']={'path':audit_path,'sha256':sha(audit_path)}
    return change
case('hash-correct pending physical replay',bad_replay(lambda d:d.update(status='started')),False)
case('hash-correct physical call failure',bad_replay(lambda d:d['calls'][0].update(complete=False)),False)
case('hash-correct physical source changed',bad_replay(lambda d:d.update(complete_sample={})),False)
case('hash-correct physical state changed',bad_replay(lambda d:d.update(state_after={})),False)
case('hash-correct different replay core',bad_replay(lambda d:d['current_replay_build']['dependencies']['gammalooprs'].update(sha256='0'*64)),False)
case('hash-correct missing physical cut',bad_replay(lambda d:d['calls'][0]['native']['evaluation']['events'].pop()),False)
case('hash-correct forced call is not Arb',bad_replay(lambda d:d['calls'][1]['native']['evaluation'].update(precision='Quad')),False)
case('old build substitution',lambda m,l:l['old_build_identity'].update(driver_sha256='0'*64),False)
for key,value in [('proposal_order',['optimized_lmb','cuts','cuts_joint']),('paired_seeds',[1,2,3,4,5]),
                  ('samples_per_run',2048),('cores',30),('planned_batch_size',128),('physical_cuts',5),
                  ('generation_parent_lmb',[3,6,7,10]),('primary_channels',{}),('reference',{}),
                  ('confirmation_frozen_selection',{}),('card_sha256',{})]:
    case('protected '+key,lambda m,l,k=key,v=value:m.update({k:v}),False)

# Rehash modified JSON to distinguish semantic rejection from a trivial stale hash.
def bad_record(kind, update):
    def change(m,l):
        payload=copy.deepcopy(core if kind=='core_build' else driver)
        update(payload)
        path=save('mutated-'+kind+'.json',payload)
        l['evidence'][kind]={'path':path,'sha256':sha(path)}
        m['candidate_build_record' if kind=='core_build' else 'candidate_driver_build_record']=path
    return change
case('unfinished core record',bad_record('core_build',lambda d:d.update(returncode=None)),False)
case('changed source during build',bad_record('core_build',lambda d:d.update(source_unchanged=False)),False)
case('wrong source base in core record',bad_record('core_build',lambda d:d.update(head='0'*40)),False)
case('wrong patch in completed core',bad_record('core_build',lambda d:d.update(source_patch_sha256='0'*64)),False)
case('resolve-only client record',bad_record('driver_build',lambda d:d.update(resolve_only=True)),False)
case('driver compiled under another core run',bad_record('driver_build',lambda d:d['compiler_captures']['gammalooprs'].update(cargo_pid=999)),False)
case('driver linked artifact differs',bad_record('driver_build',lambda d:d['dependencies']['gammalooprs'].update(sha256='0'*64)),False)

def bad_historical(name, update):
    def change(m,l):
        d=current.read(l['historical'][name]['path']);update(d)
        path=save('mutated-'+name+'.json',d)
        l['historical'][name]={'path':path,'sha256':sha(path)}
        # Keep protected path fields consistent so rejection reaches the history gate.
        previous=copy.deepcopy(old_manifest)
        if name=='preflight':
            previous['preflight_summary']=path;m['preflight_summary']=path
        else:
            previous['confirmation_screen_report']=path;m['confirmation_screen_report']=path
            previous['confirmation_screen_report_sha256']=sha(path);m['confirmation_screen_report_sha256']=sha(path)
        prev=save('mutated-previous-confirmation.json',previous)
        l['historical']['confirmation_manifest']={'path':prev,'sha256':sha(prev)}
    return change
case('partial six-mode preflight',bad_historical('preflight',lambda d:d['reports'].pop()),False)
case('one declined preflight mode',bad_historical('preflight',lambda d:d['reports'][0].update(preflight_accepted=False)),False)
case('wrong preflight orientation inventory',bad_historical('preflight',lambda d:d['reports'][0]['inventory']['production_orientation_keys'].pop()),False)
case('partial twenty-run screen',bad_historical('screen',lambda d:d['runs'].pop()),False)
case('duplicate screen row',bad_historical('screen',lambda d:d['runs'].__setitem__(1,copy.deepcopy(d['runs'][0]))),False)
case('failed screen cannot be reused',bad_historical('screen',lambda d:d.update(passed=False)),False)
case('ineligible screen run',bad_historical('screen',lambda d:d['runs'][0].update(eligible=False)),False)

# The unchanged formulas consume only existing completed historical artifacts.
args=(ROOT/'manifest-screen-full-build5.json',ROOT/'results-screen-throughput20-build5')
kwargs={'pilot_directories':[ROOT/'results-screen-advanced-firstseed-build5',ROOT/'results-screen-all-remaining-seeds-build5'],
        'excluded_directories':[ROOT/'results-screen-throughput30-build5'],'workers':20}
before=previous.analyze(*args,**kwargs);after=current.analyze(*args,**kwargs)
assert before==after and after['passed']
checks.append({'name':'real 21-run historical screen entire analysis unchanged','passed':True,
               'runs':len(after['runs']),'observables':sum(len(m['observables']) for m in after['pooled']),
               'selection':after['selection']['confirmation_modes']})
mp=case('restore positive fixture before CLI checks')
for build,expected in [(new_build,0),(dict(new_build,driver_sha256='0'*64),1)]:
    r=subprocess.run([sys.executable,str(ROOT/'analyze_physics_pilots.py'),'--validate-endpoint-repair',mp,
                      '--current-build',json.dumps(build)],capture_output=True,text=True)
    payload=json.loads(r.stdout)
    assert r.returncode==expected and payload['passed']==(expected==0)
    checks.append({'name':'validator CLI exit '+str(expected),'passed':True,'returncode':r.returncode})
report={'passed':all(c['passed'] for c in checks),'scope':'Artifact-only rejection tests with explicitly synthetic tiny compiler/replay schema bytes, actual completed source gates, and unchanged historical screen/preflight. No build, Gamma evaluation, state load, new statistics outcome, or actual endpoint-repair acceptance.',
        'checks':checks,'count':len(checks),'current_analyzer_sha256':sha(ROOT/'analyze_physics_pilots.py'),
        'previous_analyzer_sha256':sha(ROOT/'analyze_physics_pilots_before_endpoint_repair.py'),
        'frozen_screen_sha256':sha(ROOT/'screen-selection-frozen-build5.json'),
        'historical_confirmation_sha256':sha(ROOT/'manifest-confirmation-build5.json'),
        'test_script_sha256':sha(__file__)}
(OUT/'results.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='checks'},indent=2))

"""Link the scratch client to exact captured core/API dependency identities.

Only the root invokes compilation. --resolve-only records the checked command
without running rustc; neither route loads a GammaLoop state.
"""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess

parser = argparse.ArgumentParser()
parser.add_argument("source", type=Path)
parser.add_argument("output", type=Path)
parser.add_argument("--resolve-only", action="store_true")
parser.add_argument(
    "--build-log", type=Path,
    default=Path("/tmp/hosted-joint-optimized-build1.jsonl"),
)
parser.add_argument("--captures", type=Path)
parser.add_argument("--extra-core-extern", action="append", default=[])
args = parser.parse_args()
packet = Path(__file__).resolve().parent
log_path = args.build_log
capture_directory = args.captures or packet / "rustc-invocations"
artifacts = {}
for line in log_path.read_text().splitlines():
    entry = json.loads(line)
    if entry.get("reason") == "compiler-artifact":
        for filename in entry["filenames"]:
            if filename.endswith(".rlib"):
                artifacts.setdefault(entry["target"]["name"], {})[Path(filename)] = {
                    "package_id": entry["package_id"],
                    "features": entry.get("features", []),
                    "profile": entry.get("profile", {}),
                    "target_src_path": entry["target"]["src_path"],
                }

captures = {}
for name in ("gammalooprs", "gammaloop_api"):
    path = capture_directory / f"{name}.json"
    if not path.exists():
        raise SystemExit(f"Exact live compiler capture is pending: {path}")
    captures[name] = json.loads(path.read_text())
    if captures[name]["crate_name"] != name:
        raise SystemExit(f"Unexpected compiler owner in {path}")
if len({(c["cargo_pid"], c["cargo_start_ticks"]) for c in captures.values()}) != 1:
    raise SystemExit("Core/API compiler captures belong to different Cargo builds")


def values(argv, option):
    return [argv[index + 1] for index, arg in enumerate(argv[:-1]) if arg == option]


def own_rlib(name):
    argv = captures[name]["argv"]
    out_dirs = values(argv, "--out-dir")
    suffixes = [value.split("=", 1)[1] for value in values(argv, "-C")
                if value.startswith("extra-filename=")]
    if len(out_dirs) != 1 or len(suffixes) > 1:
        raise SystemExit(f"Ambiguous compiler output identity for {name}")
    suffix = suffixes[0] if suffixes else ""
    return Path(out_dirs[0]) / f"lib{name}{suffix}.rlib"


def dependency_rlib(owner, name):
    supplied = captures[owner]["externs"].get(name)
    if supplied is None:
        raise SystemExit(f"{owner}'s captured command does not declare --extern {name}")
    path = Path(supplied)
    if path.suffix not in (".rmeta", ".rlib"):
        raise SystemExit(f"Expected a Rust library metadata/link artifact for {owner}:{name}: {path}")
    # Cargo passes rmeta during pipelining. The exact same hash/stem identifies
    # the finished rlib; no globbing, nearest name or alternate feature fallback.
    return path.with_suffix(".rlib")


paths = {"gammaloop_api": own_rlib("gammaloop_api"),
         "gammalooprs": dependency_rlib("gammaloop_api", "gammalooprs")}
if paths["gammalooprs"] != own_rlib("gammalooprs"):
    raise SystemExit("API's exact core dependency differs from the captured core compilation")
# Public F/Complex/Sample types come from the core's exact numeric crates.
# Figment/TOML construction crosses the API boundary and uses its exact crates.
owners = {"symbolica": "gammalooprs", "spenso": "gammalooprs",
          "color_eyre": "gammaloop_api", "figment": "gammaloop_api",
          "serde_json": "gammaloop_api", "toml": "gammaloop_api"}
for name in args.extra_core_extern:
    if name in paths or name in owners:
        raise SystemExit(f"Duplicate explicitly captured dependency: {name}")
    owners[name] = "gammalooprs"
paths.update({name: dependency_rlib(owner, name) for name, owner in owners.items()})

linkers = {value for capture in captures.values() for value in values(capture["argv"], "-C")
           if value.startswith("linker=")}
if len(linkers) != 1:
    raise SystemExit(f"Expected one captured native linker: {linkers}")
argv = ["rustc", "--edition=2024", "-C", "opt-level=2", "-C", "debuginfo=1",
        "-C", next(iter(linkers))]
# Keep the actual compiler search directories/order rather than collecting
# unrelated build-script native paths from other host/feature variants.
search_paths = []
for owner in ("gammalooprs", "gammaloop_api"):
    for path in values(captures[owner]["argv"], "-L"):
        if path not in search_paths:
            search_paths.append(path)
            argv += ["-L", path]

dependencies = {}
for name, path in paths.items():
    artifact = artifacts.get(name, {}).get(path)
    if artifact is None:
        raise SystemExit(f"Exact completed build artifact is pending/missing for {name}: {path}")
    if not path.is_file():
        raise SystemExit(f"Reported exact rlib does not exist: {path}")
    argv += ["--extern", f"{name}={path}"]
    with path.open("rb") as library:
        digest = hashlib.file_digest(library, "sha256").hexdigest()
    dependencies[name] = {"path": str(path), "sha256": digest,
                          "selected_from": "captured own output" if name == "gammaloop_api" else
                          f"captured {owners.get(name, 'gammaloop_api')} --extern",
                          "compiler_artifact": artifact}
argv += [str(args.source), "-o", str(args.output)]
record = {"status": "resolved_exact_dependencies", "argv": argv,
          "source_sha256": hashlib.sha256(args.source.read_bytes()).hexdigest(),
          "dependencies": dependencies, "search_paths": search_paths,
          "compiler_captures": captures, "build_jsonl": str(log_path),
          "resolve_only": args.resolve_only}
if not args.resolve_only:
    result = subprocess.run(argv)
    record["returncode"] = result.returncode
    record["status"] = "compiled" if result.returncode == 0 else "compile_failed"
    if result.returncode == 0:
        with args.output.open("rb") as binary:
            record["binary_sha256"] = hashlib.file_digest(binary, "sha256").hexdigest()
args.output.with_suffix(".build.json").write_text(json.dumps(record, indent=2) + "\n")
raise SystemExit(record.get("returncode", 0))

# Build7 confirmation maximum replay

Prepared before confirmation completion. No live confirmation values were inspected. This instantiates the frozen `MAXIMUM_AFTER_CONFIRMATION_NEXT.md` procedure; it adds no selection, numerical test or experiment. Wait for the complete accepted 15-run Cartesian collection: optimized_lmb, cuts, cuts_combined_joint; seeds 10007,20011,30013,40009,50021; 32768 draws per run; 20 workers. The interrupted build5 collection and excluded throughput control remain separate.

## Exact post-completion commands

First run the existing statistics owner and require success. Finish all writes to the confirmation directory before maximum replay, which hashes that whole directory before and after. No concurrent statistics or archive writes inside it.

```bash
source /tmp/gammaloop-rebase-dev-env.sh
gl_gate_packet=/tmp/gl638-hosted-joint-gate
python "$gl_gate_packet/analyze_physics_pilots.py" \
  "$gl_gate_packet/manifest-confirmation-build7.json" \
  "$gl_gate_packet/results-confirmation-build7" --workers 20 \
  --screen "$gl_gate_packet/screen-selection-frozen-build5.json"
```

After that command succeeds, use the already-linked maximum client:

```bash
RAYON_NUM_THREADS=1 GL_DISPLAY_FILTER=off \
/run/current-system/sw/bin/time -v \
  -o "$gl_gate_packet/results-max-confirmation-build7.resources.txt" \
  "$gl_gate_packet/drivers/max-replay-build7" \
  "$gl_gate_packet/manifest-confirmation-build7.json" \
  "$gl_gate_packet/results-confirmation-build7" \
  "$gl_gate_packet/results-max-confirmation-build7" \
  > "$gl_gate_packet/results-max-confirmation-build7.log" 2>&1
python "$gl_gate_packet/audit_maximum_results.py" \
  "$gl_gate_packet/results-max-confirmation-build7"
```

Require both commands to succeed, all extrema/cases to complete, and state/pilot hashes to remain unchanged. These paths are fresh outputs; do not reuse or overwrite an earlier attempt. Logs and resource records are siblings of the immutable input directory. Root alone runs these commands.

The maximum source is frozen max29b (`29b9c6a48448935aee70159787063bb8a2c1cdd5b6a762ff596fd2d9061ca498`); linked executable SHA256 is `256bd2d51471fbdae92ac38a4095e67e39ba2c507817f4652114e36a18b74c2e`. Its actual core/API hashes match the confirmation driver exactly: core `35eff58f6d4c42c1163a6da9a926350bfd764d002003f09373189b6ce0744a52`, API `e0d68585eaede59b88f2b091130943b939b48a8a64f124deb9305f07a71d821e`. This comparison was verified from both build records and the current artifact bytes. The maximum auditor remains `9e95c3c6a029a92339c70207d11209702a28c316c3c17001a01045027c5f2f12`.

## Attribution without repeating screen points

The client recovers the original bincode Samples and all signed-extremum aliases, replays the complete estimator once, and selects two unique largest complex norms per method among those retained extrema across the five seeds. These are not the unrecorded global complex-norm maxima. It uses the actual source catalogue and complete Sample factors; precise returned events and CT decomposition already include the outer weight. The existing auditor checks total, six cuts, decomposition, factors and ordinary-versus-Arb agreement before physics attribution.

Compare the new retained records with the existing `docs/research/advanced_sampling/GL638_MAXIMUM_PHYSICS_ATTRIBUTION.md` and its `mc_maximum_replay/traces/analysis/` artifacts. Join by actual cut, component/variant/evaluator metadata, side, threshold edges, native parent/subspace and multiplier; do not identify physics by numeric CT index alone. Compare signed cancellations and component norms separately. Norm ratios are not rate fractions.

The old screen evidence supplies three distinct references: the cuts maximum had several large opposing CT terms; the composed maximum was dominated by cut3 right-threshold local/integrated cancellation far from the direct H/Z corner; the soft-added maximum had a much closer native two-loop U-star than its base point, with finite gluon energies. Compare new measured data to these categories, without reevaluating old Samples or asserting that every new maximum has one of those causes. A zero added-joint partition alone establishes no cause or failed supported-corner claim. The screen reconstruction covered identity probes, not every rotation or a global bound.

## Conditional native trace link, only if new evidence needs it

If a dominant new maximum cannot be attributed from the audited decomposition, the existing trace client can capture its actual native center/root/alpha fields. No source change, new runner, Gamma helper or new root solve is needed. Root may link the unchanged source (`5b850b20cfd0a60a2ac9f50390c47c936ea08c67b51571d287d2031a4aa7ca07`) to the same build7 captures:

```bash
python "$gl_gate_packet/compile_driver.py" \
  "$gl_gate_packet/drivers/max_replay_trace.rs" \
  "$gl_gate_packet/drivers/max-trace-build7" \
  --build-log /tmp/hosted-joint-optimized-build7.jsonl \
  --captures "$gl_gate_packet/rustc-invocations-build7" \
  --extra-core-extern bincode --extra-core-extern tracing \
  --extra-core-extern tracing_subscriber
```

The unchanged included support file is b53 (`b53df2b439845729dd5a9c898c9cece83c28426457ec18701cf9787756310306`). A new authenticated request must name actual final attribution records, their passed maximum audit, immutable directories/settings and exact input hashes. The old screen request is not a final-confirmation request. The existing variable-length case list supports a bounded choice without editing the client. Its command is `max-trace-build7 --trace manifest-confirmation-build7.json NEW_REQUEST NEW_OUTPUT`, with the same one-worker environment. Freeze the resulting build record before that run; no trace has been scheduled by this preparation.

A trace must first exactly reproduce the retained forced-Arb totals, factors and six events. Then reuse the existing `analyze_max_native_trace.py` owner where its metadata joins apply. Retain all native text and unique parent/occurrence/group/radius/alpha joins. Reconstruct only the deterministic affine star and native routing; inspect both physical and star H/Z, host defect, soft13/14 energies and root derivatives. Missing joins or unmet analyzer assumptions stay explicit; do not weaken them or invent a star from a nearby header. This can establish pointwise geometry and cancellations, not asymptotic or global boundedness.

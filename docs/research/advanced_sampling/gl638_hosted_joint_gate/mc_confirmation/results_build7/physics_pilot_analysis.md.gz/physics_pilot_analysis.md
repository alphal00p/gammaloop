# GL638 fixed-N physics comparison

Existing full-GL638 Integrate results; separate signed Re/Im and |Re|/|Im|. Empirical finite-N errors/extremes, no finite-variance or global boundedness certificate. Printed maxima are not complete replay Samples.

| Method | Observable | N | Mean ± pooled SE [pb] | Seed-mean SE [pb] | Largest absolute component weight [pb] |
|---|---|---:|---:|---:|---:|
| optimized_lmb | re | 163840 | -0.00025116092 ± 0.0001395 | 0.0001756 | 18.150863 |
| optimized_lmb | abs_re | 163840 | 0.00099081292 ± 0.0001395 | 0.0001705 | 18.150863 |
| optimized_lmb | im | 163840 | -0.00043010742 ± 0.000184 | 0.0001923 | 18.935911 |
| optimized_lmb | abs_im | 163840 | 0.0014951457 ± 0.000184 | 0.0002046 | 18.935911 |
| cuts | re | 163840 | 9.306118e-05 ± 0.0001021 | 0.0001255 | 10.47341 |
| cuts | abs_re | 163840 | 0.0004144216 ± 0.0001021 | 0.0001294 | 10.47341 |
| cuts | im | 163840 | 6.2750278e-05 ± 0.0001108 | 0.0001183 | 11.519878 |
| cuts | abs_im | 163840 | 0.0005437923 ± 0.0001108 | 0.000145 | 11.519878 |
| cuts_combined_joint | re | 163840 | 0.00011544432 ± 0.0001075 | 0.0001609 | 12.218979 |
| cuts_combined_joint | abs_re | 163840 | 0.00038003512 ± 0.0001074 | 0.0001204 | 12.218979 |
| cuts_combined_joint | im | 163840 | -1.3554516e-06 ± 8.927e-05 | 0.0001114 | 6.2263833 |
| cuts_combined_joint | abs_im | 163840 | 0.0004609652 ± 8.927e-05 | 0.0001043 | 6.2263833 |

Frozen confirmation selection:

{
  "confirmation_modes": [
    "optimized_lmb",
    "cuts",
    "cuts_combined_joint"
  ],
  "primary_estimate_mode": "cuts_combined_joint",
  "absolute_phase_scales": {
    "re": 0.0006183385979328378,
    "im": 0.0008936315639088504
  },
  "score_rule": "minimum worst normalized4-observable sample variance; exact ties use declared order; b has identical soft policy",
  "card_sha256": {
    "optimized_lmb": "c4d99ba8507ab73a5c754e1480c0e37978bd5489b31692f66e0ea030aff5b3e6",
    "cuts": "71ce4efcf492a51393075382816f8ded9ee79f93dbb1023f590b7b391f29f751",
    "cuts_combined_joint": "e7c61f30d4e117c53bdd0bcb15ca116ab7bdd3b6005c299c7b828ea0de4f1c9b"
  },
  "candidate_driver_sha256": "2fd035e87812264837a6cb0feb752a6abb63f827a90d1b461285442fd0dd311d"
}

Failures remain in the JSON; no invalid/ungated method can win. Extrema alone do not establish boundedness or convergence. The primary result is the preselected joint method, not a post-hoc confirmation winner.

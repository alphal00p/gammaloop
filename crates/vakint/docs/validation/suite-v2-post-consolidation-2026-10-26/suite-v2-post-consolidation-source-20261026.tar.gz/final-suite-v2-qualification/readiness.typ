= V2 five-loop qualification readiness

#strong[Source preparation only; all Native execution is on hold for GL20.]
The candidate freeze retains eleven unchanged old held-out inputs, adds one
new last-edge dot on parent 30527, and selects one new rank-one tuning input
on parent 32745 with late double dots. Four standby held-outs have a fixed
order. The old 31740 tuning input and dot-b remain immutable known-seen
controls and source provenance, outside selected V2 arrays.

The exact input freeze is in #raw("candidate-input-freeze.json"). It binds the
accepted source-derived public q0 inventory and all five source categories:
1,095 distinct raw roots and 2,426 direct-owner images. Nominal new powers
exclude that inventory, but complete public lowering, actual recorded coverage,
and canonical-owner exclusion are still pending. No timing selected the cases.

The unchanged optimized #raw("319d") collector will intentionally perform one
full uncached evaluation per new case; it has no lower-only option. Only genuine
successful value, complete guard and catalogue-closure receipts can feed the
unchanged #raw("6e5") mapper. Eleven old functional receipts retain their original
workload and cohort references. The pending mapper template has null new receipt
references and is explicitly non-executable. Normal collector evidence retains
the complete all-dispatch raw-root union, not per-request coefficient snapshots;
operational frontier classification remains a separate lossless-trace gate.

The inactive command controls propose CPU 136, one math thread, 16 GiB, no swap,
a 300-second complete diagnostic-job deadline and no retry. The ordinary Rust
solver deadline stays absent. Existing exact PIDFD admission and the continuous
50,000,000,000-byte host-memory floor are preserved. Fresh admission must see at
least 67,179,869,184 bytes available and exclusive CPU ownership. The physical q0
and seen workers and guards are not changed.

Nearby genuine calls took 128--185 seconds, with 109--111 seconds spent loading;
their unit journals reported rounded 4.7--6 GB peaks. This makes the proposed
budget plausible, not guaranteed. A failure or deadline must remain recorded;
no silent extension, retry, timing-based replacement or held-out selection is
allowed. Every control remains inactive until explicit scheduling approval after
GL20. No new build, Native job, case evaluation, Main edit or cache mutation was
performed while preparing these files.

"""One exact guarded 03ad tuning command; existing direct/one-hop admission only."""
import argparse
import hashlib
import os
from pathlib import Path
import stat
import subprocess
import time

HERE = Path(__file__).resolve().parent
FLOOR = Path("/shared/codex-1/vakint_rustred/workspace/5l-push/validation/physical-memavailable-floor-20261026")
PARITY = Path("/shared/codex-1/vakint_rustred/workspace/5l-push/validation/native-selected-cache-export/small-parity-v2-proposal/guarded-run1/actor.py")
PARITY_SHA = "310ae1ab5c9472097249cbabcaacd5163271607e4bbb34341516b82105e2e253"


def authenticated_module(path, digest, name):
    fd = os.open(path, os.O_RDONLY | os.O_NONBLOCK | os.O_NOFOLLOW)
    with os.fdopen(fd, "rb") as stream:
        info = os.fstat(stream.fileno())
        if not stat.S_ISREG(info.st_mode) or info.st_size > 65536:
            raise ValueError("common source is not a bounded regular file")
        source = stream.read(65537)
    if hashlib.sha256(source).hexdigest() != digest:
        raise ValueError("reviewed shared source changed")
    module = type(os)(name)
    module.__file__ = str(path)
    exec(compile(source, str(path), "exec"), module.__dict__)
    return module


reviewed = authenticated_module(PARITY, PARITY_SHA, "reviewed_parity_common")
common = reviewed.common
require, sha, checked_json, ref = common.require, common.sha, common.checked_json, common.ref
persist, process, state, utc = common.persist, common.process, common.state, common.utc
typed_equal, exact_fields = reviewed.typed_equal, reviewed.exact_fields


def sources(config, packet):
    return ([config[key] for key in ("actor_source", "launcher_source", "command_packet", "helper", "policy",
             "guard_source", "shared_parity_actor", "shared_original_actor", "leaf_peer")]
            + packet["source_authority"] + [packet["loader_environment"]["observed_build_info"]])


def make_spec(config, packet, leader, unit, run):
    result = {"schema": "vakint.before-native-task-launch-spec.v1", "approved": True,
        "scope": "tuning-5l", "worker": packet["worker"],
        "unit": {"name": config["actor_unit"], "invocation": unit["InvocationID"], "cgroup": unit["ControlGroup"]},
        "source_authority": sources(config, packet),
        "registration_ticket_path": str(run / "ticket.json"),
        "registration_fault_path": str(run / "registration-fault.json"),
        "registration_candidate_path": str(run / "candidate.json"),
        "abort_latch_path": config["abort_latch_path"], "abort_latch_fallback_path": config["abort_latch_fallback_path"]}
    controller = {key: leader[key] for key in ("pid", "start_ticks")}
    if packet["mode"] == "extra-hop":
        result["unit_controller"] = controller
        result["supervisor"] = {"pid": None, "start_ticks": None, **packet["driver"]}
    else:
        result["supervisor"] = controller
    return result


def validate_candidate(candidate, spec, spec_sha, child_identity, leaf):
    require(candidate["schema"] == "vakint.before-native-worker-candidate.v1"
            and candidate["launch_spec_sha256"] == spec_sha
            and candidate["authority"] == "request only; not guard admission",
            "candidate does not bind this immutable launch specification")
    require(type(candidate["worker"]["pid"]) is int and candidate["worker"]["pid"] > 0
            and type(candidate["worker"]["start_ticks"]) is int and candidate["worker"]["start_ticks"] > 0
            and set(candidate["worker"]) == {"pid", "start_ticks"}
            and set(candidate["supervisor"]) == {"pid", "start_ticks"}
            and all(type(candidate["supervisor"][key]) is int and candidate["supervisor"][key] > 0
                    for key in ("pid", "start_ticks")), "candidate worker/supervisor identity is invalid")
    worker = leaf.authenticate_parent(spec, candidate["worker"]["pid"])
    require(typed_equal(candidate["worker"], {key: worker[key] for key in ("pid", "start_ticks")})
            and typed_equal(candidate["supervisor"], worker["direct_supervisor"]),
            "candidate is request-only and differs from actual authenticated worker chain")
    actual = worker["direct_supervisor"] if "unit_controller" in spec else worker
    require(actual["pid"] == child_identity["pid"] and actual["start_ticks"] == child_identity["start_ticks"],
            "candidate is outside the exact Popen child chain")
    return worker


def await_candidate(run, spec, spec_sha, child, child_identity, leaf, config):
    while True:
        common.no_abort(config)
        require(child.poll() is None, "exact public child exited before guard registration")
        try:
            candidate = checked_json(run / "candidate.json")
        except FileNotFoundError:
            time.sleep(0.1)
            continue
        return candidate, validate_candidate(candidate, spec, spec_sha, child_identity, leaf)


def make_guard(config, spec, worker, leader, unit, run):
    target = {key: worker[key] for key in ("pid", "start_ticks")}
    if "unit_controller" in spec:
        target.update(supervisor_pid=worker["direct_supervisor"]["pid"],
                      supervisor_start_ticks=worker["direct_supervisor"]["start_ticks"])
    return {"schema": "vakint.physical-memory-floor-config.v1", "activation_approved": True,
        "uid": os.getuid(), "threshold_bytes": 50_000_000_000, "sample_seconds": 1, "term_grace_seconds": 5,
        "output_directory": str(run / "guard"), "abort_latch_path": config["abort_latch_path"],
        "abort_latch_fallback_path": config["abort_latch_fallback_path"],
        "slots": [{"name": config["slot"], "uid": os.getuid(), "target": target,
            "parent_pid": leader["pid"], "parent_start_ticks": leader["start_ticks"],
            "unit": config["actor_unit"], "invocation": unit["InvocationID"], "cgroup": unit["ControlGroup"],
            "workspace": spec["worker"]["workspace"], "executable_sha256": spec["worker"]["executable_sha256"]}]}


def child_environment(config, packet, spec_path, spec_sha):
    env = reviewed.child_environment(config, packet, spec_path, spec_sha)
    env.update(packet.get("thread_environment", {}))
    return env


def expected_fields(document, fields):
    for dotted, expected in fields.items():
        actual = common.at(document, dotted.split("."))
        require(typed_equal(actual, expected), f"type-sensitive expected output field differs: {dotted}")


def preflight(config):
    require(config["activation_approved"] is True, "inactive source-only control")
    packet = checked_json(config["command_packet"]["path"], config["command_packet"]["sha256"])
    require(packet["mode"] in ("extra-hop", "direct") and packet["scope"] == "tuning-5l"
            and packet["worker"]["uid"] == os.getuid(), "unsupported exact task boundary")
    require(typed_equal(packet["limits"], {"CPUs": [136], "math_threads": 1,
        "memory_max_bytes": 17179869184, "swap_bytes": 0, "outer_RuntimeMaxSec": 300,
        "Rust_max_case_seconds": None, "retries": 0}), "explicit command resources differ")
    for item in sources(config, packet):
        ref(item)
    for command in ([packet["worker"], packet["driver"]] if packet["mode"] == "extra-hop" else [packet["worker"]]):
        require(sha(command["argv"][0]) == command["executable_sha256"], "actual command ELF differs")
    if packet["mode"] == "extra-hop":
        require("--max-case-seconds" not in packet["driver"]["argv"]
                and "--worker-deadline" not in packet["worker"]["argv"],
                "dynamic deadline argv cannot enter an exact prespawn specification")
    loader_ref = packet["loader_environment"]["observed_build_info"]
    loader = checked_json(loader_ref["path"], loader_ref["sha256"])
    variables = packet["loader_environment"]["variables"]
    require(loader["LD_LIBRARY_PATH"] == variables["LD_LIBRARY_PATH"]["value"]
            and variables["LD_LIBRARY_PATH"]["is_set"] is True
            and typed_equal(variables["LD_PRELOAD"], {"is_set": False, "value": None}),
            "selected accepted-build loader differs")
    require(bool(os.environ.get("SYMBOLICA_LICENSE")), "supplied Symbolica license is absent")
    require(isinstance(packet["expected_outputs"], list) and packet["expected_outputs"],
            "actual expected report/proof outputs must be explicit")
    for output in packet["expected_outputs"]:
        require(Path(output["path"]).is_absolute() and not Path(output["path"]).exists()
                and isinstance(output["expected_fields"], dict) and output["expected_fields"],
                "report/proof must be new and have explicit acceptance fields")
    common.no_abort(config)
    available = common.available_bytes(Path("/proc/meminfo").read_text())
    require(available >= 50_000_000_000 + 17179869184, "insufficient host MemAvailable for16GiB command")
    run = Path(config["run_directory"])
    require(run.is_absolute() and run.parent == HERE and not run.exists(), "fresh private one-shot run required")
    require(state(config["guard_unit"])["LoadState"] == "not-found", "per-command guard already exists")
    leader, unit = process(os.getpid()), state(config["actor_unit"])
    require(unit["ActiveState"] == "active" and unit["MainPID"] == str(os.getpid())
            and unit["InvocationID"] and unit["ControlGroup"] and os.getcwd() == str(HERE),
            "unit controller is not the actual dedicated MainPID/workspace")
    require(os.sched_getaffinity(0) == {136}, "actual CPU affinity differs")
    resources = reviewed.unit_resources(config["actor_unit"])
    require(resources == {"CPUQuotaPerSecUSec": "1s", "MemoryMax": "17179869184",
                          "MemorySwapMax": "0", "RuntimeMaxUSec": "5min"}, "actual300s unit limits differ")
    return packet, leader, unit, run, {"utc": utc(), "MemAvailable_bytes": available,
        "actual_unit_resources": resources, "loader_variables": variables,
        "license_presence_asserted": True, "admission_is_not_scientific_acceptance": True}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--config-sha256", required=True)
    args = parser.parse_args()
    config = checked_json(args.config, args.config_sha256)
    packet, leader, unit, run, checked = preflight(config)
    leaf = authenticated_module(Path(config["helper"]["path"]), config["helper"]["sha256"], "reviewed_direct_parent_leaf")
    run.mkdir(mode=0o700)
    (run / "guard").mkdir(mode=0o700)
    persist(run / "preflight.json", checked)
    spec = make_spec(config, packet, leader, unit, run)
    spec_path = run / "launch-spec.json"
    persist(spec_path, spec)
    spec_sha = sha(spec_path)
    command = packet["driver"] if packet["mode"] == "extra-hop" else packet["worker"]
    errors, worker, guard_identity, guard_sha, acknowledgement = [], None, None, None, None
    guard_started = False
    with (run / "command.log").open("xb", buffering=0) as log:
        child = subprocess.Popen(command["argv"], cwd=command["workspace"],
            env=child_environment(config, packet, spec_path, spec_sha), stdin=subprocess.DEVNULL,
            stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        try:
            child_identity = process(child.pid)
            require(child_identity["ppid"] == leader["pid"] and child_identity["uid"] == os.getuid()
                    and sha(f"/proc/{child.pid}/exe") == command["executable_sha256"], "exact Popen child differs")
            persist(run / "launch.json", {"utc": utc(), "controller": leader, "unit": unit,
                "child": child_identity, "argv": command["argv"], "launch_spec_sha256": spec_sha,
                "scientific_accepted": False})
            candidate, worker = await_candidate(run, spec, spec_sha, child, child_identity, leaf, config)
            persist(run / "authenticated-candidate.json", {"candidate": candidate, "actual_worker": worker,
                    "authority": "kernel-authenticated request; not Native admission or mathematical acceptance"})
            guard_path = run / "guard/guard-config.json"
            persist(guard_path, make_guard(config, spec, worker, leader, unit, run))
            guard_sha = sha(guard_path)
            submission = [common.SYSTEMD_RUN, "--user", f"--unit={config['guard_unit']}", "--service-type=exec",
                f"--working-directory={run / 'guard'}", "--property=Restart=no", "--property=RuntimeMaxSec=infinity",
                "--property=CPUAffinity=136", "--property=StandardInput=null", "--property=UMask=0077",
                f"--property=StandardOutput=append:{run / 'guard/service.log'}", "--property=StandardError=inherit",
                config["python"], "-B", config["guard_source"]["path"], "--config", str(guard_path),
                "--config-sha256", guard_sha]
            submitted = subprocess.run(submission, capture_output=True, text=True, check=False)
            require(submitted.returncode == 0, "per-command guard submission failed")
            guard_started = True
            guard_identity = state(config["guard_unit"])
            require(guard_identity["ActiveState"] == "active", "new per-command guard failed startup")
            guard_identity["process"] = process(int(guard_identity["MainPID"]))
            persist(run / "guard-submission.json", {"command": submission, "unit": guard_identity,
                    "stdout": submitted.stdout, "stderr": submitted.stderr})
            acknowledgement = leaf.policy().wait_before_native(guard_path, guard_sha, config["slot"],
                run / "registration-fault.json", target_pid=worker["pid"], expected_start_ticks=worker["start_ticks"])
            persist(run / "controller-observed-guard-ack.json", {"acknowledgement": acknowledgement,
                "authority": "controller observation BEFORE ticket; Rust leaf independently rechecks before Native"})
            ticket = {"schema": "vakint.before-native-registration-ticket.v1", "launch_spec_sha256": spec_sha,
                "worker": {key: worker[key] for key in ("pid", "start_ticks")},
                "guard_config": {"path": str(guard_path), "sha256": guard_sha}, "slot": config["slot"]}
            if packet["mode"] == "extra-hop":
                ticket["supervisor"] = worker["direct_supervisor"]
            persist(run / "ticket.json", ticket)
        except Exception as error:
            errors.append(str(error))
            try:
                persist(run / "registration-fault.json", {"error": str(error), "Native_permitted": False})
            except Exception as secondary:
                errors.append(f"registration refusal could not persist: {secondary}")
        finally:
            # Explicit300s whole-command unit budget is external; no new signal
            # policy or retry and no fabricated worker/driver status.
            exit_code = child.wait()
    result = {"schema": "vakint.guarded-tuning-command-completion.v1", "utc": utc(), "mode": packet["mode"],
        "child_pid": child.pid, "child_exit_code": exit_code, "worker": worker, "accepted": False,
        "scientific_acceptance": "PENDING_SEPARATE_EXACT_RESULT_AND_FRONTIER_REVIEW", "errors": errors,
        "current_q0_seen_or_guard_modified": False, "automatic_retry": False,
        "command_packet": config["command_packet"],
        "controller_config": {"path": str(args.config), "sha256": args.config_sha256},
        "actor_source": config["actor_source"]}
    try:
        require(exit_code == 0 and not errors, "public command/registration failed")
        common.no_abort(config)
        registration = checked_json(run / "guard/registration.json")
        heartbeat = checked_json(run / "guard/heartbeat.json")
        require(registration["config_sha256"] == guard_sha and registration["signals_sent"] == []
                and registration["guard"]["pid"] == int(guard_identity["MainPID"])
                and registration["guard"]["start_ticks"] == guard_identity["process"]["start_ticks"]
                and heartbeat["sample_error"] is None and heartbeat["latched_abort"] is False
                and heartbeat["guard_pid"] == registration["guard"]["pid"]
                and heartbeat["slots"][config["slot"]]["state"] in ("ARMED_EXACT_PIDFD", "ORIGINAL_PROCESS_TERMINAL"),
                "actual guard registration/terminal observation differs")
        require(not list((run / "guard").glob("abort-*.json")), "actual host-memory floor abort occurred")
        outputs = []
        for expected in packet["expected_outputs"]:
            document = checked_json(expected["path"])
            expected_fields(document, expected["expected_fields"])
            if packet["mode"] == "extra-hop":
                require(typed_equal(document["supervision"]["child_pid"], worker["pid"])
                        and typed_equal(document["supervision"]["supervisor_pid"], child.pid),
                        "measurement output belongs to another public driver/worker execution")
            outputs.append({"path": expected["path"], "sha256": sha(expected["path"])})
        result.update(accepted=True, outputs=outputs, registration=registration, final_observed_heartbeat=heartbeat,
            controller_observed_guard_ack=acknowledgement, command_log_sha256=sha(run / "command.log"))
    except Exception as error:
        result["errors"].append(str(error))
    if guard_started:
        try:
            current = state(config["guard_unit"])
            require(guard_identity is not None and current["ActiveState"] == "active"
                    and current["InvocationID"] == guard_identity["InvocationID"]
                    and current["MainPID"] == guard_identity["MainPID"], "owned per-command guard changed before cleanup")
            subprocess.run([common.SYSTEMCTL, "--user", "stop", config["guard_unit"]], check=True)
            result["guard_after_actual_command_wait"] = state(config["guard_unit"])
        except Exception as error:
            result["accepted"] = False
            result["errors"].append(f"per-command guard cleanup refused/failed: {error}")
    try:
        common.no_abort(config)
        for item in sources(config, packet):
            ref(item)
    except Exception as error:
        result["accepted"] = False
        result["errors"].append(f"final latch/source check failed: {error}")
    persist(run / "completion.json", result)
    return 0 if result["accepted"] else 1


if __name__ == "__main__":
    raise SystemExit(main())

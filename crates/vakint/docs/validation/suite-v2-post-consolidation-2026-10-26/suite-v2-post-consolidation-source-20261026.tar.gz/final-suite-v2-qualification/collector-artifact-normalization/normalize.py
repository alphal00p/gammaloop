#!/usr/bin/env python3
"""Project authenticated historical build facts; never execute a collector."""

from __future__ import annotations

import ast
import hashlib
import json
import re
import stat
from pathlib import Path


OUTPUT = Path(__file__).resolve().parent
WORKSPACE = Path("/shared/codex-1/vakint_rustred/workspace")
VALIDATION = WORKSPACE / "5l-push/validation"
RAW = VALIDATION / "final-monitored-collectors-build/release-elfs.json"
COHORT = VALIDATION / "initial-routing-frontier-tuning-03ad-runtime/compiled-cohort.json"
PARSER = Path(
    "/shared/codex-1/vakint_rustred/gammaloop_vakint_rustred/"
    "crates/vakint/docs/benchmark/merge_five_loop_results.py"
)
STATUS = "SOURCE_BOUND_NORMALIZATION_NO_NEW_BUILD_OR_EXECUTION"
RAW_SHA256 = "e6f5376c4b08803ea5acf64582d71d16bca829423cb10438b0e120015986a52c"
COHORT_SHA256 = "ecde038c079ab65012d02c15bf598f16246277eaf614233a9c9b39b9037ce5ca"
EXPECTED = {
    "measure_cache": (
        "measurement_executable_sha256",
        "319ddef4583481f4924d30c110eaee62f185d0c92a9f03f1a2680b08ada929c2",
    ),
    "authenticate_owner_roots": (
        "mapper_executable_sha256",
        "6e5e1b8dd09064c607f07a07df1a6bb815f16e1b3286e0e86ceb742bdfb87108",
    ),
}


def reference(path: Path) -> dict:
    before = path.lstat()
    assert stat.S_ISREG(before.st_mode), path
    digest = hashlib.sha256()
    count = 0
    with path.open("rb") as source:
        while block := source.read(1024 * 1024):
            digest.update(block)
            count += len(block)
    after = path.stat()
    assert (
        before.st_dev,
        before.st_ino,
        before.st_size,
        before.st_mtime_ns,
        before.st_ctime_ns,
    ) == (
        after.st_dev,
        after.st_ino,
        after.st_size,
        after.st_mtime_ns,
        after.st_ctime_ns,
    ), path
    assert count == before.st_size
    return {"path": str(path), "bytes": count, "sha256": digest.hexdigest()}


def write_new(path: Path, document: dict) -> None:
    with path.open("x") as target:
        json.dump(document, target, indent=2)
        target.write("\n")


def require(condition: bool, reason: str) -> None:
    if not condition:
        raise ValueError(reason)


def main() -> None:
    raw_reference = reference(RAW)
    cohort_reference = reference(COHORT)
    assert raw_reference["sha256"] == RAW_SHA256
    assert cohort_reference["sha256"] == COHORT_SHA256
    raw = json.loads(RAW.read_text())
    cohort = json.loads(COHORT.read_text())
    assert raw["status"] == "BUILT_AND_ALL_FIVE_STAMPS_AUTHENTICATED"
    assert raw["math_or_cache_operations"] == 0
    assert cohort["actual_build_artifact"]["sha256"] == RAW_SHA256

    # Extract the actual pure parser definitions, without importing its module.
    parser_reference = reference(PARSER)
    module = ast.parse(PARSER.read_text(), filename=str(PARSER))
    functions = {
        node.name: node
        for node in module.body
        if isinstance(node, ast.FunctionDef)
        and node.name in {"artifact_binaries", "validate_compiled_artifact"}
    }
    assert set(functions) == {"artifact_binaries", "validate_compiled_artifact"}
    assignments = [
        node
        for node in module.body
        if isinstance(node, ast.Assign)
        and any(
            isinstance(target, ast.Name) and target.id == "COHORT_STAMPS"
            for target in node.targets
        )
    ]
    assert len(assignments) == 1
    identities = ast.literal_eval(assignments[0].value)
    assert len(identities) == 5
    proof = raw["compile_proof"]
    assert len(proof) == 7
    for field, stamp in identities:
        assert proof[stamp] == cohort[field]

    records = []
    checked_files = []
    for name, (cohort_field, expected_sha256) in EXPECTED.items():
        entry = raw["artifacts"][name]
        assert entry["sha256"] == cohort[cohort_field] == expected_sha256
        binary = Path(entry["binary"])
        binary_reference = reference(binary)
        assert binary_reference["sha256"] == expected_sha256
        assert binary_reference["bytes"] == entry["bytes"]
        observed_mode = stat.S_IMODE(binary.stat().st_mode)
        with binary.open("rb") as source:
            assert source.read(4) == b"\x7fELF"

        dep_info = Path(entry["dep_info"])
        dep_reference = reference(dep_info)
        assert dep_reference["sha256"] == entry["dep_info_sha256"]
        actual_stamps = {}
        for line in dep_info.read_text().splitlines():
            if line.startswith("# env-dep:VAKINT_CACHE_BUILD_"):
                key, value = line[len("# env-dep:") :].split("=", 1)
                assert key not in actual_stamps
                actual_stamps[key] = value
        assert actual_stamps == proof == entry["all_seven_actual_env_dep_stamps"]
        assert entry["all_five_actual_env_dep_stamps"] == {
            stamp: proof[stamp] for _, stamp in identities
        }
        assert actual_stamps["VAKINT_CACHE_BUILD_PROFILE"] == "release"

        cargo = entry["cargo_artifact"]
        compiler = entry["actual_final_rustc"]
        assert cargo["target"]["kind"] == ["example"]
        assert cargo["target"]["name"] == compiler["crate_name"] == name
        assert cargo["profile"]["opt_level"] == "3"
        assert cargo["profile"]["test"] is False
        assert "opt-level=3" in compiler["codegen_flags"]
        assert "lto=fat" in compiler["codegen_flags"]
        records.append(
            {
                "kind": "example",
                "name": name,
                "sha256": expected_sha256,
                "bytes": binary_reference["bytes"],
                "immutable_path": str(binary),
                "observed_mode": f"{observed_mode:04o}",
                "observed_owner_group_or_other_write_bit": bool(observed_mode & 0o222),
                "immutable_path_semantics": "Existing parser field name for a logical content pin at the historical path; no OS-readonly or sealed-file claim.",
                "normal_cli": True,
                "profile": cargo["profile"],
                "actual_rustc": {
                    "compiler": compiler["compiler"],
                    "opt_level": "3",
                    "lto": "fat",
                    "test": False,
                    "codegen_flags": compiler["codegen_flags"],
                    "cfg": compiler["cfg"],
                    "argument_sha256": compiler["argument_sha256"],
                },
                "actual_env_dep_stamps": actual_stamps,
                "dep_info": dep_reference,
                "original_cargo_artifact": cargo,
                "original_entry": f"artifacts.{name}",
            }
        )
        checked_files.extend([binary_reference, dep_reference])

    artifact = {
        "status": STATUS,
        "scope": (
            "Source-bound projection of the existing historical03ad build only. "
            "No new build, collector execution, Native operation, consumer "
            "acceptance, CI acceptance or performance qualification."
        ),
        "stamps": dict(proof),
        "artifacts": records,
        "original_build_receipt": raw_reference,
        "compiled_cohort_receipt": cohort_reference,
        "derivation": {
            "five_cohort_identities": "Exact actual compile-proof values equal ecde cohort identities.",
            "additional_stamps": "PROFILE and RUSTC are copied from actual compile_proof and independently verified in both seven-stamp dep-info records; no version-string normalization.",
            "normal_cli": "Actual Cargo example target with profile.test=false; no executable was invoked.",
            "profile_and_lto": "Actual Cargo profile plus recorded final rustc opt-level=3/lto=fat flags.",
            "source_drift": "Not asserted; no source_drift=[] or source_unchanged gate is invented by this projection.",
        },
    }
    namespace = {
        "require": require,
        "Path": Path,
        "re": re,
        "digest": lambda path: reference(Path(path))["sha256"],
        "COHORT_STAMPS": identities,
    }
    extracted = ast.Module(body=list(functions.values()), type_ignores=[])
    exec(compile(ast.fix_missing_locations(extracted), str(PARSER), "exec"), namespace)
    assert namespace["artifact_binaries"](artifact) == records
    for _, expected_sha256 in EXPECTED.values():
        namespace["validate_compiled_artifact"](
            {"compiled_cohort": cohort, "executable_sha256": expected_sha256}, artifact
        )
    assert reference(RAW) == raw_reference and reference(COHORT) == cohort_reference

    artifact_path = OUTPUT / "collector-artifacts.json"
    write_new(artifact_path, artifact)
    validation = {
        "status": STATUS,
        "normalizer_source": reference(Path(__file__).resolve()),
        "normalized_artifact": reference(artifact_path),
        "original_build_receipt": raw_reference,
        "compiled_cohort_receipt": cohort_reference,
        "actual_parser_source": parser_reference,
        "checked_files": checked_files,
        "checks": {
            "raw_e6f_hash_and_status": True,
            "ecde_five_identities_exact": True,
            "both_historical_elf_hashes_sizes_regular_magic": True,
            "both_dep_info_hashes_and_all_seven_actual_stamps": True,
            "actual_example_test_false_opt3_fat_lto": True,
            "exact_current_parser_artifact_binaries_and_validate_compiled_artifact": True,
            "both_measurement_and_mapper_membership": True,
            "original_receipts_unchanged": True,
        },
        "bounded_search": {
            "result": "No existing normalized03ad receipt located in the inspected current/full13/portable/N3 provenance context.",
            "n3_actual_composition": reference(VALIDATION / "final-delivery-gap-audit-20261026/completed-capture-4eba/actual-composition.json"),
            "n3_report": reference(VALIDATION / "final-delivery-gap-audit-20261026/completed-capture-4eba/actual-small3-report/cumulative-report.json"),
            "facts": "N3 composition3425 references report47fce with no03ad consumer artifact. Known portable/strict copies remain byte-identical rawe6f dictionaries, not top-stamps/artifact-list records.",
            "not_a_global_absence_claim": True,
        },
        "remaining_parser_gate": {
            "final_performance_qualification_claimed": False,
            "reason": "The exact current qualify() performance gate additionally requires artifact.source_drift==[]. That fact was not independently established by this normalization and is deliberately absent. Separate windows/samples/consumer acceptance are also not supplied.",
        },
        "historical_cohort_boundary": "This is historical03ad tooling provenance, not the post-consolidation consumer or privatebfe census cohort.",
        "preserved_local_checker_failure": "The first normalization check stopped before writing outputs: an extra unsupported read-only-mode assertion rejected the historical measurement ELF's actual0755 mode after its319d hash/size matched. Original permissions were never changed. The coordinator authorized removing only that extra assertion and retaining explicit observed mode/write-bit facts; hash, dep-info and identity checks remain unchanged.",
        "formatting": {"ruff_executed": False, "reason": "ruff was not on the invoked sourced PATH; no installation or formatter rerun. Source is checked by ast.parse and the extracted parser functions."},
        "actions": {
            "builds": 0,
            "collector_test_help_list_or_native_executions": 0,
            "five_loop_physical_elf_reads": 0,
            "cache_or_index_payload_reads": 0,
            "original_receipt_edits": 0,
        },
    }
    write_new(OUTPUT / "validation.json", validation)
    print(json.dumps({"status": STATUS, "artifact": reference(artifact_path), "validation": reference(OUTPUT / "validation.json")}))


if __name__ == "__main__":
    main()

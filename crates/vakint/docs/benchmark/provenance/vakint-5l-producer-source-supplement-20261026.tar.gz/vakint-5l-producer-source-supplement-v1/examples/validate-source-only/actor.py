"""One guarded small Native/GZIP source-parity import, never reduction or export."""
import argparse
import math
import json
import os
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
FLOOR = Path("/shared/codex-1/vakint_rustred/workspace/5l-push/validation/physical-memavailable-floor-20261026")
BASE = FLOOR / "real-rust-admission-gate/actor.py"
BASE_SHA = "389296dad18f17aa662805056c109f5cfbc312d1bba92170964c9d85c9b6e98b"
PACKET_SHA = "37e567bfea1ab0bb1c7964c779505338417d6919945dd14800eae0b439faf31b"
CONTROLS_SHA = "721da65f41e0c624670eb5965d6a7195281568a0cd64fb7f388876939c8dcea5"
SLOT = "small-native-gzip-parity"

# Authenticate before executing the already-reviewed common OS/metadata helpers.
import hashlib
import stat
descriptor = os.open(BASE, os.O_RDONLY | os.O_NONBLOCK | os.O_NOFOLLOW)
with os.fdopen(descriptor, "rb") as stream:
    info = os.fstat(stream.fileno())
    if not stat.S_ISREG(info.st_mode) or info.st_size > 65536:
        raise ValueError("reviewed common source is not a bounded regular file")
    original = stream.read(65537)
if hashlib.sha256(original).hexdigest() != BASE_SHA:
    raise ValueError("reviewed common actor source changed")
common = type(os)("reviewed_harmless_actor_common")
common.__file__ = str(BASE)
exec(compile(original, str(BASE), "exec"), common.__dict__)
require, sha, checked_json, ref = common.require, common.sha, common.checked_json, common.ref
persist, process, state, utc = common.persist, common.process, common.state, common.utc


def typed_equal(left, right):
    if type(left) is not type(right):
        return False
    if isinstance(left, dict):
        return left.keys() == right.keys() and all(typed_equal(left[key], right[key]) for key in left)
    if isinstance(left, list):
        return len(left) == len(right) and all(typed_equal(a, b) for a, b in zip(left, right))
    return left == right


def exact_fields(actual, expected):
    require(isinstance(actual, dict), "validation report must be an object")
    for key, value in expected.items():
        require(key in actual and typed_equal(actual[key], value), f"type-sensitive validation field differs: {key}")


def source_refs(config, packet):
    return ([config[key] for key in ("actor_source", "launcher_source", "common_actor", "harmless_completion", "qualified_packet",
            "acceptance_controls", "helper", "policy", "guard_source", "leaf_peer")]
        + packet["source_authority"] + [packet["loader_environment"]["observed_build_info"]])


def make_spec(config, packet, leader, unit):
    return {"schema": "vakint.before-native-task-launch-spec.v1", "approved": True,
        "scope": packet["scope"], "worker": packet["worker"],
        "supervisor": {key: leader[key] for key in ("pid", "start_ticks")},
        "unit": {"name": config["actor_unit"], "invocation": unit["InvocationID"], "cgroup": unit["ControlGroup"]},
        "source_authority": source_refs(config, packet),
        "registration_ticket_path": str(HERE / "run/ticket.json"),
        "registration_fault_path": str(HERE / "run/registration-fault.json"),
        "abort_latch_path": config["abort_latch_path"], "abort_latch_fallback_path": config["abort_latch_fallback_path"]}


def make_guard(config, packet, leader, unit, worker):
    result = common.make_guard({**config, "test_elf": {"sha256": packet["worker"]["executable_sha256"]}},
                               leader, unit, worker)
    result["output_directory"] = str(HERE / "run/guard")
    result["slots"][0].update(name=SLOT, workspace=packet["worker"]["workspace"])
    return result


def child_environment(config, packet, spec_path, spec_sha):
    env = os.environ.copy()
    require(bool(env.get("SYMBOLICA_LICENSE")), "supplied private Symbolica license is absent")
    env.update(VAKINT_RESOURCE_GUARD_PYTHON=config["python"], VAKINT_RESOURCE_GUARD_HELPER=config["helper"]["path"],
        VAKINT_RESOURCE_GUARD_HELPER_SHA256=config["helper"]["sha256"],
        VAKINT_RESOURCE_GUARD_LAUNCH_SPEC=str(spec_path), VAKINT_RESOURCE_GUARD_LAUNCH_SPEC_SHA256=spec_sha)
    for key in ("OMP_NUM_THREADS", "RAYON_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS",
                "NUMEXPR_NUM_THREADS", "VECLIB_MAXIMUM_THREADS", "BLIS_NUM_THREADS"):
        env[key] = "1"
    for key, setting in packet["loader_environment"]["variables"].items():
        if setting["is_set"]:
            env[key] = setting["value"]
        else:
            env.pop(key, None)
    return env


def unit_resources(unit):
    result = subprocess.run([common.SYSTEMCTL, "--user", "show", unit,
        "--property=CPUQuotaPerSecUSec,MemoryMax,MemorySwapMax,RuntimeMaxUSec"],
        capture_output=True, text=True, check=True)
    return dict(line.split("=", 1) for line in result.stdout.splitlines() if "=" in line)


def preflight(config):
    require(config["activation_approved"] is True, "source-only controls are inactive")
    require(config["qualified_packet"]["sha256"] == PACKET_SHA
            and config["acceptance_controls"]["sha256"] == CONTROLS_SHA, "reviewed task authority differs")
    packet = checked_json(config["qualified_packet"]["path"], PACKET_SHA)
    controls = checked_json(config["acceptance_controls"]["path"], CONTROLS_SHA)
    require(packet["mode"] == "validate-source-only" and packet["scope"] == "5l-test"
            and packet["proposed_unit"] == config["actor_unit"] and packet["worker"]["uid"] == os.getuid(),
            "task mode/unit/user differs")
    require(typed_equal(packet["resource_proposal"], {"cpus": [148], "cpu_quota_cores": 1,
            "memory_max_bytes": 17179869184, "memory_swap_max_bytes": 0, "runtime_seconds": 1200,
            "attempts": 1, "automatic_retry": False}), "reviewed resource proposal differs")
    for item in source_refs(config, packet):
        ref(item)
    require(sha(packet["worker"]["argv"][0]) == packet["worker"]["executable_sha256"], "actual Native ELF differs")
    prior = checked_json(config["harmless_completion"]["path"], config["harmless_completion"]["sha256"])
    exact_fields(prior, {"schema": "vakint.real-rust-no-native-guard-admission.v1", "accepted": True,
                        "worker_exit_code": 0, "errors": [], "Native_operations": 0, "reduction_operations": 0})
    loader_ref = packet["loader_environment"]["observed_build_info"]
    loader = checked_json(loader_ref["path"], loader_ref["sha256"])
    require(typed_equal(loader["variables"], packet["loader_environment"]["variables"]), "own loader receipt differs")
    require(all(Path(value).is_dir() for value in loader["variables"]["LD_LIBRARY_PATH"]["value"].split(":")),
            "own runtime library directory is absent")
    require(bool(os.environ.get("SYMBOLICA_LICENSE")), "supplied private Symbolica license is absent")
    common.no_abort(config)
    available = common.available_bytes(Path("/proc/meminfo").read_text())
    require(available >= 50_000_000_000 + packet["resource_proposal"]["memory_max_bytes"],
            "insufficient host MemAvailable for the admitted 16GiB import harness")
    require(state(config["guard_unit"])["LoadState"] == "not-found", "per-job guard unit already exists")
    require(not (HERE / "run").exists(), "one-shot run already exists")
    output = Path(packet["worker"]["argv"][packet["worker"]["argv"].index("--output-dir") + 1])
    require(not output.exists(), "Native result output already exists; no overwrite/retry")
    leader, own = process(os.getpid()), state(config["actor_unit"])
    require(own["ActiveState"] == "active" and own["MainPID"] == str(os.getpid())
            and own["InvocationID"] and own["ControlGroup"] and os.getcwd() == str(HERE),
            "actor is not the dedicated authoritative unit MainPID/workspace")
    require(os.sched_getaffinity(0) == {148}, "actor CPU affinity differs from approved CPU148")
    resources = unit_resources(config["actor_unit"])
    require(resources == {"CPUQuotaPerSecUSec": "1s", "MemoryMax": "17179869184",
                          "MemorySwapMax": "0", "RuntimeMaxUSec": "20min"},
            "actual unit quota/memory/swap/1200s import-harness budget differs")
    return packet, controls, leader, own, output, {"utc": utc(), "MemAvailable_bytes": available,
            "license_presence_asserted": True, "loader_variables": loader["variables"],
            "harmless_completion": config["harmless_completion"], "unit": own,
            "actual_unit_resources": resources, "source_registration_is_not_Native_parity_acceptance": True}


def validate_report(raw, controls, worker, spec_sha, guard_sha, registration, heartbeat, guard_service):
    exact_fields(raw, controls["expected_exact_type_sensitive_fields"])
    phases = raw.get("phase_seconds")
    require(isinstance(phases, dict) and set(phases) == set(controls["expected_phase_seconds_keys"]),
            "actual optimized source-only phase keys differ")
    require(all(type(value) in (int, float) and math.isfinite(value) and value >= 0 for value in phases.values()),
            "phase seconds must be finite nonnegative actual numeric durations")
    receipt = raw["resource_guard_admission"]
    exact_fields(receipt, {"schema": "vakint.resource-guard-admission.v1", "admitted": True,
        "worker": {"pid": worker["pid"], "start_ticks": worker["start_ticks"], "uid": worker["uid"],
                   "executable_sha256": raw["executable_sha256"]},
        "launch_spec_sha256": spec_sha, "guard_config_sha256": guard_sha, "slot": SLOT})
    require(type(receipt["MemAvailable_bytes"]) is int and receipt["MemAvailable_bytes"] >= 50_000_000_000,
            "admission MemAvailable proof differs")
    require(registration["config_sha256"] == guard_sha and registration["signals_sent"] == []
            and registration["slots"][SLOT]["state"] == "ARMED_EXACT_PIDFD"
            and typed_equal(registration["slots"][SLOT]["target"],
                            {key: worker[key] for key in ("pid", "start_ticks")}), "actual PIDFD registration differs")
    require(registration["guard"]["pid"] == int(guard_service["MainPID"])
            and registration["guard"]["start_ticks"] == guard_service["process"]["start_ticks"],
            "registered guard differs from the submitted service's actual process")
    for key in ("pid", "start_ticks"):
        require(type(receipt["guard"][key]) is int and receipt["guard"][key] == registration["guard"][key],
                "actual admission guard identity differs")
    require(receipt["guard"]["uid"] == worker["uid"] and all(uid == worker["uid"] for uid in registration["guard"]["uids"]),
            "actual admission guard user differs")
    require(heartbeat["guard_pid"] == receipt["guard"]["pid"] and heartbeat["sample_error"] is None
            and heartbeat["latched_abort"] is False and heartbeat["slots"][SLOT]["state"] in
                    ("ARMED_EXACT_PIDFD", "ORIGINAL_PROCESS_TERMINAL"), "terminal observed guard state differs")
    return receipt


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--config-sha256", required=True)
    args = parser.parse_args()
    config = checked_json(args.config, args.config_sha256)
    packet, controls, leader, own, output, checked = preflight(config)
    run = HERE / "run"
    run.mkdir(mode=0o700)
    (run / "guard").mkdir(mode=0o700)
    persist(run / "preflight.json", checked)
    spec = make_spec(config, packet, leader, own)
    spec_path = run / "launch-spec.json"
    persist(spec_path, spec)
    spec_sha = sha(spec_path)
    env = child_environment(config, packet, spec_path, spec_sha)
    errors, exit_code, guard_started, guard_registered = [], None, False, None
    worker, guard_sha = None, None
    with (run / "worker.log").open("xb", buffering=0) as log:
        child = subprocess.Popen(spec["worker"]["argv"], cwd=spec["worker"]["workspace"], env=env,
            stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        try:
            worker = process(child.pid)
            require(worker["ppid"] == leader["pid"] and worker["uid"] == os.getuid()
                    and sha(f"/proc/{child.pid}/exe") == spec["worker"]["executable_sha256"], "actual Native child differs")
            persist(run / "launch.json", {"utc": utc(), "supervisor": leader, "unit": own,
                    "worker": worker, "argv": spec["worker"]["argv"], "cwd": spec["worker"]["workspace"],
                    "launch_spec_sha256": spec_sha, "Native_parity_accepted": False})
            guard_path = run / "guard/guard-config.json"
            persist(guard_path, make_guard(config, packet, leader, own, worker))
            guard_sha = sha(guard_path)
            command = [common.SYSTEMD_RUN, "--user", f"--unit={config['guard_unit']}", "--service-type=exec",
                f"--working-directory={run / 'guard'}", "--property=Restart=no", "--property=RuntimeMaxSec=infinity",
                "--property=CPUAffinity=148", "--property=StandardInput=null", "--property=UMask=0077",
                f"--property=StandardOutput=append:{run / 'guard/service.log'}", "--property=StandardError=inherit",
                config["python"], "-B", config["guard_source"]["path"], "--config", str(guard_path),
                "--config-sha256", guard_sha]
            submitted = subprocess.run(command, capture_output=True, text=True, check=False)
            require(submitted.returncode == 0, "per-job guard service submission failed")
            guard_started = True
            guard_registered = state(config["guard_unit"])
            require(guard_registered["ActiveState"] == "active", "per-job guard failed at startup")
            guard_registered["process"] = process(int(guard_registered["MainPID"]))
            persist(run / "guard-submission.json", {"command": command, "unit": guard_registered,
                    "stdout": submitted.stdout, "stderr": submitted.stderr})
            persist(run / "ticket.json", {"schema": "vakint.before-native-registration-ticket.v1",
                "launch_spec_sha256": spec_sha, "worker": {key: worker[key] for key in ("pid", "start_ticks")},
                "guard_config": {"path": str(guard_path), "sha256": guard_sha}, "slot": SLOT})
        except Exception as error:
            errors.append(str(error))
            try:
                persist(run / "registration-fault.json", {"error": str(error), "Native_permitted": False})
            except Exception as status_error:
                errors.append(f"registration refusal could not be persisted: {status_error}")
        finally:
            # The import harness's explicit 1200s unit limit is external. Never
            # synthesize child exit0, retry a child, or add another signal policy.
            exit_code = child.wait()
    result = {"schema": "vakint.guarded-small-native-gzip-source-parity.v1", "utc": utc(),
        "worker": worker, "worker_exit_code": exit_code, "accepted": False, "errors": errors,
        "reduction_operations": 0, "cache_write_or_light_export": False,
        "current_q0_seen_guard_or_registry_modified": False, "automatic_retry": False}
    try:
        require(exit_code == 0 and not errors, "Native source-parity child failed or registration failed")
        common.no_abort(config)
        raw_path = output / "raw-validation.json"
        raw = checked_json(raw_path)
        require(not (output / controls["forbidden_success_output"]).exists(), "unexpected cache/export output")
        registration = checked_json(run / "guard/registration.json")
        heartbeat = checked_json(run / "guard/heartbeat.json")
        receipt = validate_report(raw, controls, worker, spec_sha, guard_sha, registration, heartbeat, guard_registered)
        require(not list((run / "guard").glob("abort-*.json")), "actual memory-floor abort occurred")
        result.update(accepted=True, raw_validation={"path": str(raw_path), "sha256": sha(raw_path)},
            admission_receipt=receipt, registration=registration, final_observed_heartbeat=heartbeat,
            worker_log_sha256=sha(run / "worker.log"), qualified_packet=config["qualified_packet"],
            acceptance_controls=config["acceptance_controls"])
    except Exception as error:
        result["errors"].append(str(error))
    # Only this new per-job guard is retired, only after the real child wait.
    if guard_started:
        try:
            current = state(config["guard_unit"])
            require(guard_registered is not None and current["ActiveState"] == "active"
                    and current["InvocationID"] == guard_registered["InvocationID"]
                    and current["MainPID"] == guard_registered["MainPID"], "per-job guard changed before cleanup")
            subprocess.run([common.SYSTEMCTL, "--user", "stop", config["guard_unit"]], check=True)
            result["guard_after_worker_exit"] = state(config["guard_unit"])
        except Exception as error:
            result["accepted"] = False
            result["errors"].append(f"per-job guard cleanup failed or refused: {error}")
    try:
        common.no_abort(config)
        for item in source_refs(config, packet):
            ref(item)
    except Exception as error:
        result["accepted"] = False
        result["errors"].append(f"final latch/source check failed: {error}")
    persist(run / "completion.json", result)
    return 0 if result["accepted"] else 1


if __name__ == "__main__":
    raise SystemExit(main())

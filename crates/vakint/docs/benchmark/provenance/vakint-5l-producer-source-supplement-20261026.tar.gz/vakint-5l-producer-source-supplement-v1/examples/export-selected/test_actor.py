"""Pure source/control tests only: no Native, services, processes or signals."""
import copy
import importlib.util
import json
import hashlib
import tempfile
from pathlib import Path
import unittest
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("parity_actor", HERE / "actor.py")
actor = importlib.util.module_from_spec(spec)
spec.loader.exec_module(actor)
PACKET = json.loads((HERE.parent / "guard-inputs-qualified.json").read_text())
CONTROLS = json.loads((HERE.parent / "acceptance-controls.json").read_text())


class PureControls(unittest.TestCase):
    def test_nested_integer_is_not_boolean(self):
        self.assertFalse(actor.typed_equal({"rows": [1]}, {"rows": [True]}))
        self.assertFalse(actor.typed_equal([0], [False]))
        self.assertTrue(actor.typed_equal({"a": [1, True, None]}, {"a": [1, True, None]}))

    def test_fixed_report_rejects_bool_count_and_missing_flag(self):
        raw = copy.deepcopy(CONTROLS["expected_exact_type_sensitive_fields"])
        actor.exact_fields(raw, CONTROLS["expected_exact_type_sensitive_fields"])
        raw["missing_keys"] = False
        with self.assertRaises(ValueError):
            actor.exact_fields(raw, CONTROLS["expected_exact_type_sensitive_fields"])
        del raw["exact_record_and_ordered_guard_equality"]
        with self.assertRaises(ValueError):
            actor.exact_fields(raw, CONTROLS["expected_exact_type_sensitive_fields"])

    def test_prebound_spec_has_no_invented_worker_pid(self):
        config = {key: {"path": "/fixture/" + key, "sha256": "a" * 64} for key in
            ("actor_source", "launcher_source", "common_actor", "harmless_completion", "qualified_packet", "acceptance_controls",
             "helper", "policy", "guard_source", "leaf_peer")}
        config.update(actor_unit=PACKET["proposed_unit"], abort_latch_path="/fixture/latch",
                      abort_latch_fallback_path="/fixture/fallback")
        spec = actor.make_spec(config, PACKET, {"pid": 101, "start_ticks": 1001},
                               {"InvocationID": "fixture-invocation", "ControlGroup": "/fixture/cgroup"})
        self.assertEqual(spec["worker"], PACKET["worker"])
        self.assertNotIn("pid", spec["worker"])
        self.assertEqual(spec["supervisor"], {"pid": 101, "start_ticks": 1001})
        self.assertEqual(spec["scope"], "5l-test")

    def test_postspawn_guard_uses_real_worker_and_packet_cwd(self):
        config = {"abort_latch_path": "/fixture/latch", "abort_latch_fallback_path": "/fixture/fallback",
                  "actor_unit": PACKET["proposed_unit"]}
        guard = actor.make_guard(config, PACKET, {"pid": 101, "start_ticks": 1001},
            {"InvocationID": "fixture-invocation", "ControlGroup": "/fixture/cgroup"},
            {"pid": 102, "start_ticks": 1002})
        self.assertEqual(guard["slots"][0]["workspace"], PACKET["worker"]["workspace"])
        self.assertEqual(guard["slots"][0]["target"], {"pid": 102, "start_ticks": 1002})
        self.assertEqual(guard["slots"][0]["parent_pid"], 101)
        self.assertEqual(guard["threshold_bytes"], 50_000_000_000)

    def test_own_loader_unsets_preload_without_logging_license(self):
        config = {"python": "/fixture/python", "helper": {"path": "/fixture/helper", "sha256": "a" * 64}}
        with patch.dict(actor.os.environ, {"SYMBOLICA_LICENSE": "SYNTHETIC-TEST-ONLY", "LD_PRELOAD": "/wrong"}, clear=True):
            env = actor.child_environment(config, PACKET, Path("/fixture/spec"), "b" * 64)
        self.assertNotIn("LD_PRELOAD", env)
        self.assertEqual(env["LD_LIBRARY_PATH"], PACKET["loader_environment"]["variables"]["LD_LIBRARY_PATH"]["value"])
        self.assertEqual(env["VAKINT_RESOURCE_GUARD_LAUNCH_SPEC_SHA256"], "b" * 64)

    def test_no_supplied_license_refuses(self):
        with patch.dict(actor.os.environ, {}, clear=True), self.assertRaises(ValueError):
            actor.child_environment({}, PACKET, Path("/fixture/spec"), "b" * 64)

    def fixture(self):
        # Explicit synthetic metadata; this is not a Native output or receipt.
        worker = {"pid": 102, "start_ticks": 1002, "uid": 1124}
        raw = copy.deepcopy(CONTROLS["expected_exact_type_sensitive_fields"])
        raw["phase_seconds"] = {name: 0.01 for name in CONTROLS["expected_phase_seconds_keys"]}
        raw["resource_guard_admission"] = {"schema": "vakint.resource-guard-admission.v1", "admitted": True,
            "worker": {**worker, "executable_sha256": raw["executable_sha256"]},
            "launch_spec_sha256": "a" * 64, "guard_config_sha256": "b" * 64, "slot": actor.SLOT,
            "guard": {"pid": 103, "start_ticks": 1003, "uid": 1124}, "MemAvailable_bytes": 100_000_000_000}
        registration = {"config_sha256": "b" * 64, "signals_sent": [],
            "guard": {"pid": 103, "start_ticks": 1003, "uids": [1124] * 4},
            "slots": {actor.SLOT: {"state": "ARMED_EXACT_PIDFD", "target": {"pid": 102, "start_ticks": 1002}}}}
        heartbeat = {"guard_pid": 103, "sample_error": None, "latched_abort": False,
            "slots": {actor.SLOT: {"state": "ORIGINAL_PROCESS_TERMINAL"}}}
        return raw, worker, registration, heartbeat

    def test_synthetic_dynamic_binding_accepts_only_exact_worker(self):
        raw, worker, registration, heartbeat = self.fixture()
        actor.validate_report(raw, CONTROLS, worker, "a" * 64, "b" * 64, registration, heartbeat, {"MainPID": "103", "process": {"start_ticks": 1003}})
        raw["resource_guard_admission"]["worker"]["start_ticks"] += 1
        with self.assertRaises(ValueError):
            actor.validate_report(raw, CONTROLS, worker, "a" * 64, "b" * 64, registration, heartbeat, {"MainPID": "103", "process": {"start_ticks": 1003}})

    def test_phase_durations_reject_missing_fictional_bool_and_nonfinite_values(self):
        for change in ("missing", "fictional", "bool", "nan", "negative"):
            raw, worker, registration, heartbeat = self.fixture()
            key = CONTROLS["expected_phase_seconds_keys"][0]
            if change == "missing":
                del raw["phase_seconds"][key]
            elif change == "fictional":
                raw["phase_seconds"]["selection"] = 1.0
            elif change == "bool":
                raw["phase_seconds"][key] = True
            elif change == "nan":
                raw["phase_seconds"][key] = float("nan")
            else:
                raw["phase_seconds"][key] = -1.0
            with self.assertRaises(ValueError):
                actor.validate_report(raw, CONTROLS, worker, "a" * 64, "b" * 64, registration, heartbeat,
                                      {"MainPID": "103", "process": {"start_ticks": 1003}})

    def test_guard_sample_error_or_latch_is_not_semantic_success(self):
        for key, value in (("sample_error", "fixture-read-fault"), ("latched_abort", True)):
            raw, worker, registration, heartbeat = self.fixture()
            heartbeat[key] = value
            with self.assertRaises(ValueError):
                actor.validate_report(raw, CONTROLS, worker, "a" * 64, "b" * 64, registration, heartbeat, {"MainPID": "103", "process": {"start_ticks": 1003}})

    def test_guard_pidfd_target_or_guard_identity_mismatch_refuses(self):
        for field in ("target", "guard"):
            raw, worker, registration, heartbeat = self.fixture()
            if field == "target":
                registration["slots"][actor.SLOT]["target"]["pid"] += 1
            else:
                registration["guard"]["start_ticks"] += 1
            with self.assertRaises(ValueError):
                actor.validate_report(raw, CONTROLS, worker, "a" * 64, "b" * 64, registration, heartbeat, {"MainPID": "103", "process": {"start_ticks": 1003}})

    def test_guard_service_pid_or_start_mismatch_refuses(self):
        for service in ({"MainPID": "999", "process": {"start_ticks": 1003}},
                        {"MainPID": "103", "process": {"start_ticks": 999}}):
            raw, worker, registration, heartbeat = self.fixture()
            with self.assertRaises(ValueError):
                actor.validate_report(raw, CONTROLS, worker, "a" * 64, "b" * 64, registration, heartbeat, service)


    def test_actual_output_is_byte_bound_and_authenticates_native_identity(self):
        with tempfile.TemporaryDirectory(dir=HERE) as directory:
            output = Path(directory)
            data = b"synthetic-byte-contract-only-not-a-Native-cache"
            cache = output / "cache.rrcache.gz"
            cache.write_bytes(data)
            raw = {"cache_sha256": hashlib.sha256(data).hexdigest(),
                "cache_identity": {"compressed_bytes":len(data), "compressed_blake3":[1]*32,
                    "decoded_bytes":123, "decoded_blake3":[2]*32}, "decoded_sha256":"a"*64}
            proof = actor.validate_cache_output(output, raw, CONTROLS)
            self.assertEqual(proof["bytes"], len(data))
            for field, value in (("compressed_bytes", True), ("decoded_bytes", 0),
                                 ("compressed_blake3", [True]*32), ("decoded_blake3", [256]*32)):
                invalid = copy.deepcopy(raw)
                invalid["cache_identity"][field] = value
                with self.assertRaises(ValueError):
                    actor.validate_cache_output(output, invalid, CONTROLS)
            raw["cache_sha256"] = "b"*64
            with self.assertRaises(ValueError):
                actor.validate_cache_output(output, raw, CONTROLS)

    def test_output_symlink_and_compressed_budget_refuse(self):
        with tempfile.TemporaryDirectory(dir=HERE) as directory:
            output = Path(directory)
            (output/"data").write_bytes(b"synthetic")
            (output/"cache.rrcache.gz").symlink_to(output/"data")
            with self.assertRaises(ValueError):
                actor.validate_cache_output(output, {}, CONTROLS)
            (output/"cache.rrcache.gz").unlink()
            (output/"cache.rrcache.gz").write_bytes(b"synthetic")
            limits = {**CONTROLS, "max_compressed_bytes":1}
            with self.assertRaises(ValueError):
                actor.validate_cache_output(output, {}, limits)


if __name__ == "__main__":
    unittest.main(verbosity=2)

#!/run/current-system/sw/bin/bash
set -euo pipefail
set +x
umask 077
source /shared/codex-1/vakint_rustred/workspace/env.sh
: "${SYMBOLICA_LICENSE:?supplied private Symbolica license is absent}"
export PYTHONDONTWRITEBYTECODE=1
exec /shared/codex-1/vakint_rustred/workspace/5l-push/gallery-python/bin/python -B \
 /shared/codex-1/vakint_rustred/workspace/5l-push/validation/native-selected-cache-export/small-parity-v3-optimized-proposal/guarded-run1/actor.py \
 --config "$1" --config-sha256 "$2"

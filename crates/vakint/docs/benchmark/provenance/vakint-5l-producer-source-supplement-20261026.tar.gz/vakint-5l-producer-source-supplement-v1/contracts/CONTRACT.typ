= Portable cache-record usage and selected keys, version1

This contract is source-only. It introduces no Native instrumentation or live
run change. Existing benchmark work.stage normalizes once to the public Native
progress.current work.kind shape. Route has kind/powers only; Apply additionally
has owner_sector. Preserve ordered powers/owner coordinates. Program/family
binding occurs once in each document header, using the existing Native binding.

The profile is vakint.cache-record-usage-profile.v1. The selection is
vakint.cache-record-selection.v1. Their exact JSON shapes are in the adjacent
schema files. Use persistent completed-record hit frequency, not an invented
IBP formula ID or avoided CPU time. RAM hits are excluded from this metric.

== Mandatory semantic checks beyond JSON shape

+ Require all five compiled source/cohort values, actual collector ELF/source,
  compiler/profile, official data manifests/application and per-case actual
  cache identity. All cases share the header program/family binding.
+ Decode exact small PUBLIC eligibility-document bytes and check their SHA;
  resolve the case's JSON pointer and independently derive ID, role and public
  input identity. public_input_source_sha256 is the exact frozen public_input
  UTF-8 bytes hash (the existing mapper field). input_sha256 is the completed
  receipt's parsed/canonical input hash, which can differ. Validate BOTH through
  the existing public-lowering receipt/mapper provenance; never equate them. Frozen workload tuning membership is eligible; held_out
  membership is ALWAYS rejected. A physical case requires its authenticated
  explicit physical-example manifest. A claimed role or trusted boolean is not
  authority. Never use final held-out traces/counts for trimming or thresholds.
+ Require accepted case receipt/input/result/guard hashes, successful operation,
  Active observer, interval zero, and complete current cohort. The full raw trace
  may remain outside Git; its hash and receipt references remain bound. Summary
  contains every actual hit key/count and per-dispatch root/counter evidence.
+ Dispatch ordinals must be consecutive; their length equals input_dispatch_count.
  Collected roots are unique Route keys. Their count equals requested_roots and
  completed_roots. All vectors have header physical_arity; an Apply owner mask
  equals its powers' positive support. Unknown stage/owner/family is an error.
+ Within each dispatch, aggregate duplicate hits into ONE key/count row without
  losing multiplicity. Sum route rows equals route_hits, Apply rows equals
  apply_hits; total equals requested_root_hits+intermediate_hits and lookups-
  misses, with checked arithmetic. Those legacy Native root counters keep their
  original meaning; they do not independently establish frontier scope.
+ The profile contains no invented trust, whole-coverage or time-saving flag.
  Producer/validator must reject dropped/malformed/faulted/incomplete streams.
  Raw traces and source references enable audit, not unverifiable identity claims.
+ Selected keys are unique public work objects, all with positive measured
  frequency among listed ELIGIBLE case IDs in the exact referenced profile.
  Recompute selected frequencies from profile rows; no standalone trusted flag.
  Selection method may combine frequency and actual encoded size/usefulness;
  per-rule CPU savings are unknown unless independently measured.
+ Export only strict complete records from the matching existing heavy Native
  cache through its existing filtered writer. No new codec, bindings or IBP.
  Final light compressed aggregate must be at most 95,000,000 bytes. Keep full
  cumulative heavy unbounded and provide its compressed LOCAL hosting path.
  Only the light tier goes to the official external-data repository.

Aggregation belongs in the existing benchmark StageLogger/normalized validator
or small workflow postprocessing, not another Native stats registry. Current
lossless callbacks can be folded per key with no CAS/routing or full expression
formatting. Default diagnostics remain off; live frozen workers are unchanged.
Source/data/eligibility documents are public; NEVER include env.sh or license.

#!/usr/bin/env bash
set -euo pipefail
source /shared/codex-1/vakint_rustred/workspace/env.sh
proof_root=/shared/codex-1/vakint_rustred/workspace/5l-push/validation/native-selected-cache-export/portable-proof-root-v3
receipt_dir="$proof_root/provenance/native-exporter-v3"
producer_dir=/shared/codex-1/vakint_rustred/workspace/5l-push/validation/native-selected-cache-export/producer-v3
export CARGO_TARGET_DIR=/shared/codex-1/vakint_rustred/workspace/build/native-selected-cache-producer-v3-release-run1
export NATIVE_PRODUCER_TARGET="$CARGO_TARGET_DIR"
export NATIVE_PRODUCER_RUSTC_LOG="$receipt_dir/actual-rustc.jsonl"
export RUSTC_WRAPPER="$receipt_dir/rustc_record.py"
export CARGO_BUILD_JOBS=2 RUSTRED_RUNTIME_ARITIES=15
export CARGO_PROFILE_RELEASE_OPT_LEVEL=3 CARGO_PROFILE_RELEASE_DEBUG=0
export CARGO_PROFILE_RELEASE_DEBUG_ASSERTIONS=false CARGO_PROFILE_RELEASE_OVERFLOW_CHECKS=false
export CARGO_PROFILE_RELEASE_LTO=fat CARGO_PROFILE_RELEASE_CODEGEN_UNITS=1
export TMPDIR="$receipt_dir/tmp" TMP="$receipt_dir/tmp" TEMP="$receipt_dir/tmp"
export RAYON_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
export SYMBOLICA_HIDE_BANNER=1
unset VAKINT_RESOURCE_GUARD_PYTHON VAKINT_RESOURCE_GUARD_HELPER VAKINT_RESOURCE_GUARD_HELPER_SHA256 VAKINT_RESOURCE_GUARD_LAUNCH_SPEC VAKINT_RESOURCE_GUARD_LAUNCH_SPEC_SHA256
cd "$producer_dir"
source_postflight() {
python3 - "$proof_root" "$producer_dir" <<'POSTFLIGHT'
import hashlib,json,sys
from pathlib import Path
root=Path(sys.argv[1]); actual=Path(sys.argv[2])
freeze=json.loads((root/'provenance/native-exporter-v3/source-freeze.json').read_text())
for name, ref in freeze['files'].items():
    archived=root/ref['path']; archived.resolve().relative_to(root.resolve())
    data=archived.read_bytes()
    assert len(data)==ref['bytes'] and hashlib.sha256(data).hexdigest()==ref['sha256'], name
    assert (actual/name).read_bytes()==data, name
POSTFLIGHT
}
source_postflight
run_gate() {
  local name="$1"
  shift
  local result=0
  "$@" > "$receipt_dir/logs/$name.log" 2>&1 || result=$?
  printf '%s\n' "$result" > "$receipt_dir/$name.exit"
  return "$result"
}
run_gate parser-tests cargo test --release --locked --offline -- --test-threads=1
run_gate clippy cargo clippy --release --locked --offline --all-targets -- -A clippy::reversed_empty_ranges
run_gate build cargo build --release --locked --offline --message-format=json-render-diagnostics
python3 - "$receipt_dir/runtime-loader-environment.json" <<'LOADER_ENV'
import json,os,sys
from pathlib import Path
# Deliberately no full environment, license value or unrelated variable capture.
selected={name:{"is_set":name in os.environ,"value":os.environ.get(name)} for name in ["LD_LIBRARY_PATH","LD_PRELOAD"]}
body={"schema":"native.private-producer-buildinfo-loader-environment.v1","scope":"Observed environment of this actual data-free build-info gate only; future runtime must independently bind its own admission/ELF/environment.","variables":selected}
with Path(sys.argv[1]).open("x") as output:json.dump(body,output,indent=2);output.write("\n")
LOADER_ENV
run_gate build-info "$CARGO_TARGET_DIR/release/native-selected-cache-producer" build-info
source_postflight

= Native selected-cache producer, source preparation

== Private v3 diagnostic phases

This new private copy preserves the frozen v2 sources and the unaccepted
600-second timeout evidence. The timeout did not establish a record mismatch,
and its phase remains unknown. No new run has occurred in this source revision.

V3 adds only stderr start/end notices using #raw("std::time::Instant") around
mandatory admission, document/index verification, existing application loading,
Native pack opening, legacy-file opening, full or selected comparison, final
input/index/artifact-reference verification and output publication. Selected
export additionally names the existing encode, write, reimport and output-identity
steps. The existing preparation, deferred-owner, pack and file statistic snapshots
are printed through their public Native APIs. A file-statistics failure is a
diagnostic notice and introduces no new acceptance condition.

The comparison callback logs a processed-record count after every 1,024 records
whose exact key, current-owner validation, coefficients and ordered guards have
all passed comparison. It logs the final completed-pair count when the visitor
returns, including an error return. A killed process cannot emit its final line;
these notices promise no timed heartbeat during a long individual operation.
They print no coefficients or license values and add no ETA, altered expectations,
traversal, new codec, pin or resource policy.
The previous full grouped visitor and shared legacy coefficient tables remain
unchanged. Pure diagnostic-format tests are written but not executed here.

The successful raw report may include #raw("phase_seconds"), an optional map
of exactly the completed named phases. Each end notice samples elapsed time once;
the same actual value enters the map. A source-only parity report consequently
has no selected-export phases. Unperformed selection/ranking work and unknown
costs are absent, not zero. These disjoint diagnostic intervals include their
observation overhead and are not asserted to sum to a complete process total.
No success report is published after failure or kill. Output publication occurs
after writing the report, so #raw("output_publication") remains stderr-only and
is absent from that report's map.

The exact reviewed admission call remains mandatory before any five-loop data
read, and proof-root/reference postflight checks remain in place. Any later
optimized build and runtime require their new artifact/cohort, independent review
and registered host guard. This source preparation launches no build or runtime.

== Private v2 proof references

The optional #raw("--proof-root ROOT") changes only authored document references.
ROOT must be an existing canonical absolute regular directory with no symlink,
dot, traversal or repeated-separator aliases. A mapped collector-artifact input
must likewise use its canonical absolute filename and lie within ROOT. Its
reference becomes a normal ROOT-relative POSIX path such as
#raw("provenance/native-exporter-v2/collector-artifacts.json"), with the same
actual archived-file SHA256. Root/file replacement, outside paths, symlink
components and changed bytes are errors. Without this option the historical
absolute-reference behavior is preserved. Embedded historical build paths remain
data and are not rewritten. The strict reference check runs again at final
postflight, so replacing ROOT or a parent with same-byte files during Native
work cannot satisfy the original identity promise.

This v3 source remains unbuilt and unexecuted. The inherited filesystem/argument tests use
only synthetic files; they activate no Native state, five-loop application or
cache. The helper embeds the parent's exact reviewed shared admission source,
SHA256 #raw("bb3223d27584b42069d3813ebdcaefa6598a0935ca4531714a50248b334870cb").
Before any five-loop Document read, its first runtime operation requires a
present, valid shared five-environment admission tuple and its registered host
guard. An absent tuple is an error for this private runtime. No real admission
has occurred merely because this source integration exists.
The #raw("build-info") and synthetic tests bypass #raw("execute") and load no
five-loop data. There is no new resource policy in the proof-reference layer.

== Preserved producer workflow

This private standalone utility uses the clean Native PR14 commit
#raw("b209adb1e774242bcbe0417fed223317566561bd") and its official Symbolica
#raw("9cd57678d8817ec33c05cacba4925162f1c86b0b") State-format 6 dependency. It
does not link Vakint Main. No build, numerical import, export or reduction is
authorized by this source document. The six synthetic Rust parser tests are
prepared but have not run. The first compilation, source-only parity job and
any later LIGHT extraction each require their separately coordinated launch.
Every five-loop runtime launch, including owner activation, parity validation
and filtering, must first be registered with the parent's50GB MemAvailable
kill guard. This helper does not register or bypass that external guard. The
current physical delivery scope is zero momentum only; it authorizes no new
quadratic preparation, profiling or replay.

== Interfaces

#raw("build-info", lang: "text") (also #raw("--build-info")) prints the actual
embedded compiler/source cohort plus its own executable SHA256. It loads no
application, data, cache or usage profile. This bootstraps the existing external
collector-artifacts receipt before a numerical import is authorized.

Both numerical modes require these explicit arguments:

```
--application /authenticated/5L/ibps/application.json --application-sha256 SHA
--binding /direct-four-field-binding.json --binding-sha256 SHA
--native-cache /frozen-native-bundle-or-pack
--source-inventory /inventory.json --source-inventory-sha256 SHA
--collector-artifacts /actual-compiled-artifacts.json --collector-artifacts-sha256 SHA
--output-dir /workspace/new-destination
```

The inventory must contain the existing #raw("cache_native_index_identity")
projection emitted by the collector's #raw("CacheIdentity") helper. The actual
source's index identity must match that authenticated value both before and
after work; a different same-binding cache is refused. No new cache inventory,
key identity, solver statistics or codec is introduced.

#raw("export-selected") additionally requires:

```
--selected-keys /actual-frozen-selected-keys.json[.gz] --selected-keys-sha256 SHA
--usage-profile /actual-eligible-usage-profile.json[.gz] --usage-profile-sha256 SHA
```

Keys follow the frozen #raw("vakint.cache-record-selection.v1") schema, SHA256
#raw("c77a1d043a9925602b5cbc25d78c322a5089e45f1f59347c8ee485e52b02d232").
The usage-profile schema SHA256 is
#raw("515a986b3364a8a1aa919e50b65e2f6d3dbe5bbc030440270b66df575aeeea46").
All supplied SHA256 values bind the actual archived bytes, including gzip.
Standard one-member gzip may wrap the JSON; extra members and trailing bytes
are rejected. Only keys are parsed. The utility does not duplicate the profile
validator or infer eligibility, complete telemetry or usefulness from a boolean.
That separate validator must approve the actual profile and selection before
launch. Unknown key stages, invalid owner/power vectors, duplicate selected keys,
wrong bindings and noncanonical format fields fail gracefully.

The existing prepared-owner exporter encodes selected strict records once,
using one existing shared coefficient table, with a decimal 95,000,000-byte
compressed allowance. The utility reimports the saved file with its complete
Native identity, rereads the same selected source records and validates both
through the prepared owner. It requires exact key-set, terminal-map and raw
ordered duplicate-guard equality. Only after success does a Linux
#raw("renameat2(RENAME_NOREPLACE)") atomically publish a fresh directory containing
#raw("cache.rrcache.gz") and #raw("raw-validation.json"). Output inside the source
Native directory, application/data checkout or input document is refused.

#raw("validate-source-only") instead requires:

```
--legacy-cache /accepted/candidate.rrcache.gz --legacy-cache-sha256 SHA
--expected-records 25088
```

It performs no export and accepts no selection/profile arguments. It authenticates
every referenced Native chunk and compares every newest unique source record
with the accepted legacy file, including current-owner validation of both and
exact complete key-set/ordered-guard equality. Both Native stored references
and unique/file records must equal the explicit expected count. Its separate
#raw("vakint.strict-cache-source-parity-native-validation.v1") receipt makes no
LIGHT-selection, usage or speedup claim. Historical shadowed records are not
independently semantically decoded; for the preserved 25,088-reference source,
the count equality leaves no shadowed surplus.

== Evidence and preservation

The helper-derived cohort labels its source layer as a private Native-only
utility. The existing Main-named cohort fields refer explicitly to the actual
Native repository revision and private-helper source identity; they never claim
that a Vakint Main executable was linked. Build stamps are derived at compilation,
not accepted as caller-provided revision environment values. The resolved lock,
actual source files, clean Native/kernel Git-tree identities and compiler version
are bound. Final compiler invocations and artifact inventory remain the build
coordinator's responsibility. No license value or private environment is recorded.

No reduction API is called. Data loading and selected-cache imports still use
native Symbolica numerical-state APIs and require the inherited development
license. Input documents and source indexes are checked again at completion.
Selected records are reread and authenticated; unused HEAVY chunk bytes are not
fully rehashed and the receipt says so. Atomic publication never overwrites an
existing path. Failed attempts retain their unpublished staging directory and
return an error without automatic retry. No original cache is modified or removed.

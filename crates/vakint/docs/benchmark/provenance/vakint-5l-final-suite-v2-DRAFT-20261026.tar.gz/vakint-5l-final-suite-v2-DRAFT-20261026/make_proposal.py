"""Source-only suite proposal. Does not freeze, import Native, or run cases."""
from pathlib import Path
import ast, copy, datetime, hashlib, json, re, subprocess
V=Path('/shared/codex-1/vakint_rustred/workspace/5l-push/validation');C=V.parent/'cache-workload';OUT=Path(__file__).resolve().parent
W=Path('/shared/codex-1/vakint_rustred/workspace/5l-push/vakint-q0-public-lowering')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def ref(p):return {'path':str(p),'bytes':Path(p).stat().st_size,'sha256':sha(p)}
def read(p):return json.loads(Path(p).read_text())
def put(n,d):
 with (OUT/n).open('x') as f:json.dump(d,f,indent=2);f.write('\n')
frozen=read(C/'frozen-public-suites.json');reserves=read(C/'frozen-public-reserves-v1.json')
old=read(V/'cache-consumer-c6-requalification/final-workload.json')
qualified=read(V/'initial-routing-frontier-tuning-03ad-runtime/full13-functional-controls/current13-qualified-workload.json') if (V/'initial-routing-frontier-tuning-03ad-runtime/full13-functional-controls/current13-qualified-workload.json').exists() else None
if qualified is None:
 hand=read(V/'initial-routing-frontier-tuning-03ad-runtime/full13-functional-controls/final-handoff.json')
 q=hand['qualified_workload_metadata_only'];qualified=read(q['path'])
audit_path=V/'q0-public-lowering-private/runtime-run1/five-source-current-public-root-audit.json';audit=read(audit_path)
source_raw={tuple(k) for r in audit['source_rows'] for k in r['source_raw_keys']};source_owner={tuple(k) for r in audit['source_rows'] for k in r['source_direct_owner_keys']}
old_vectors={tuple(r['powers']) for r in frozen['held_out']+frozen['tuning']+reserves['held_out_reserves']}
# Only the compiled momentum table is transcribed; input graph incidence/routing is
# carried unchanged from previously authenticated parent graphs.
data_path=W/'crates/vakint/src/topologies/five_loop_data.rs';src=data_path.read_text();text=src.split('pub(crate) const MOMENTA: [[i64; 5]; 15] = ',1)[1].split(';',1)[0];momenta=ast.literal_eval(text)
assert len(momenta)==15 and all(len(row)==5 for row in momenta)
def linear(s):
 s=re.sub(r'k\((\d)\)',lambda m:'K'+m.group(1),s)
 def walk(n):
  if isinstance(n,ast.Constant):assert type(n.value)is int;return n.value
  if isinstance(n,ast.Name):return tuple(int(n.id=='K'+str(i+1)) for i in range(5))
  if isinstance(n,ast.UnaryOp):
   x=walk(n.operand);assert isinstance(n.op,ast.USub);return tuple(-a for a in x) if isinstance(x,tuple) else -x
  assert isinstance(n,ast.BinOp);a,b=walk(n.left),walk(n.right)
  if isinstance(n.op,(ast.Add,ast.Sub)):
   assert isinstance(a,tuple) and isinstance(b,tuple);return tuple(x+(y if isinstance(n.op,ast.Add) else -y) for x,y in zip(a,b))
  assert isinstance(n.op,ast.Mult)
  if isinstance(a,int):return tuple(a*x for x in b)
  assert isinstance(b,int);return tuple(b*x for x in a)
 return walk(ast.parse(s,mode='eval').body)
def props(s):
 inner=s[s.index('topo(')+5:-1];out=[];start=0;depth=0
 for i,ch in enumerate(inner):
  if ch=='(':depth+=1
  elif ch==')':depth-=1
  if ch=='*' and depth==0:out.append(inner[start:i]);start=i+1
 out.append(inner[start:]);records=[]
 for p in out:
  assert p.startswith('prop(') and p.endswith(')');body=p[5:-1];args=[];start=0;depth=0
  for i,ch in enumerate(body):
   if ch=='(':depth+=1
   elif ch==')':depth-=1
   if ch==',' and depth==0:args.append(body[start:i]);start=i+1
  args.append(body[start:]);assert len(args)==5;records.append(args)
 return records
bases={}
for parent in ['32745','31740','30699','30527']:
 original=next(r for r in frozen['held_out'] if r['id']=='parent-'+parent+'-dot_a');ps=props(original['public_input']);p=[min(n,1) for n in original['powers']];incidence={};mapping=[]
 for args in ps:
  vec=linear(args[2]);slot=[i for i,row in enumerate(momenta) if tuple(row)==vec];assert len(slot)==1 and p[slot[0]]==1;mapping.append(slot[0])
  edge=re.fullmatch(r'edge\((\d+),(\d+)\)',args[1]);assert edge
  a,b=map(int,edge.groups())
  for vertex,sign in [(a,1),(b,-1)]:incidence[vertex]=tuple(x+sign*y for x,y in zip(incidence.get(vertex,(0,0,0,0,0)),vec))
 assert len(ps)==9 and len(set(mapping))==9 and all(all(x==0 for x in v) for v in incidence.values()) and len(ps)-len(incidence)+1==5
 bases[parent]=(ps,p,mapping,original)
def make(case_id,role,parent,dot_slots,numerator_slot=None):
 ps,p,mapping,original=bases[parent];p=p.copy()
 for slot in dot_slots:assert p[slot]==1;p[slot]+=1
 if numerator_slot is not None:assert p[numerator_slot]==0;p[numerator_slot]=-1
 rendered=[]
 for args,slot in zip(ps,mapping):args=args.copy();args[3]='1';args[4]=str(p[slot]);rendered.append('prop('+','.join(args)+')')
 numerator='1' if numerator_slot is None else '1*(dot(k('+str(numerator_slot+1)+'),k('+str(numerator_slot+1)+'))-1)^1'
 public='('+numerator+')*topo('+'*'.join(rendered)+')'
 assert tuple(p) not in old_vectors and tuple(p) not in source_raw and tuple(p) not in source_owner
 return {'id':case_id,'powers':p,'rationale':'Proposed before any new evaluation/timing: parent '+parent+', unchanged authenticated nine-edge forest-pinch graph/routing, unit mass; dots at common zero-based slots '+str(dot_slots)+', numerator slot '+str(numerator_slot)+'. Nominal D='+str(sum(p))+' and R='+str(sum(-x for x in p if x<0))+' do not certify recorded coverage; full current public-lowering/owner/source exclusion is required.','public_input':public,'proposed_role':role,'parent':int(parent),'generation':{'parent_template':ref(C/'frozen-public-suites.json'),'template_id':original['id'],'retained_common_slots':mapping,'dots_zero_based':dot_slots,'numerator_slot_zero_based':numerator_slot,'prop_momenta_and_incidence_unchanged':True,'loop_count_by_incidence':5,'vertex_momentum_conservation':True},'public_input_source_sha256':hashlib.sha256(public.encode()).hexdigest(),'static_exclusion':{'declared_powers_not_in_all_five_source_raw_or_direct_owner_sets':True,'not_a_previous_frozen_suite_or_reserve_vector':True,'canonical_owner_and_full_lowered_union_exclusion':'PENDING actual qualified proof; not inferred from nominal powers'}}
tuning=make('final-v2-parent-32745-late-double-dot-rank1-tuning','tuning','32745',[7,8],1)
heldout=make('final-v2-parent-30527-last-edge-dot','held-out','30527',[14])
new_reserves=[make('final-v2-reserve-parent-32745-last-edge-dot','held-out','32745',[14]),make('final-v2-reserve-parent-31740-last-edge-dot','held-out','31740',[12]),make('final-v2-reserve-parent-30699-last-edge-dot','held-out','30699',[14]),make('final-v2-reserve-parent-30527-penultimate-edge-dot','held-out','30527',[13])]
# Bounded existing metadata only, deliberately excluding active physics/cache trees.
paths=[]
for root in [V,C]:
 paths.extend(Path(p) for p in subprocess.check_output(['rg','--files',str(root)],text=True).splitlines() if Path(p).name in ['measurement.json','worker.json'])
checks=[];matches=[]
candidates=[tuning,heldout]+new_reserves
for path in paths:
 assert path.stat().st_size<=2000000
 try:doc=read(path)
 except json.JSONDecodeError:checks.append({'file':ref(path),'valid_json':False});continue
 vectors=[];source_hashes=[]
 def walk(v,pointer=''):
  if isinstance(v,list):
   if len(v)==15 and all(type(n)is int for n in v):vectors.append((tuple(v),pointer))
   else:
    for i,x in enumerate(v):walk(x,pointer+'/'+str(i))
  elif isinstance(v,dict):
   for k,x in v.items():
    if k in ['public_input_source_sha256','input_source_sha256'] and isinstance(x,str):source_hashes.append((x,pointer+'/'+k))
    walk(x,pointer+'/'+k)
 walk(doc)
 for candidate in candidates:
  hit=[p for k,p in vectors if k==tuple(candidate['powers'])]+[p for s,p in source_hashes if s==candidate['public_input_source_sha256']]
  if hit:matches.append({'candidate':candidate['id'],'path':str(path),'pointers':hit})
 checks.append({'file':ref(path),'valid_json':True})
assert not matches,matches
history={'schema':'vakint.proposed-final-suite-unmeasured-metadata-check.v1','state':'SOURCE_ONLY_NOT_CANONICAL_ALIAS_PROOF','checked_receipts':checks,'matches':matches,'candidate_ids':[r['id'] for r in candidates],'scope':'186 current existing measurement/worker metadata files under validation and cache-workload only, <=2MB each; all nested exact15integer vectors and explicit public input source digests. Original frozen suite/reserves vectors also excluded. No active physics/cache payloads read. This is bounded history evidence, not a proof against unknown external history or integral symmetries.'}
put('unmeasured-metadata-check.json',history)
retained=[r for r in qualified['held_out'] if r['id']!='parent-31740-dot_b'];assert len(retained)==11
clean=lambda r:{k:r[k] for k in ['id','powers','rationale','public_input']}
workload={'schema':'vakint.five-loop-cache-workload.v1','data_manifest_sha256':qualified['data_manifest_sha256'],'source_census_sha256':qualified['source_census_sha256'],'training':copy.deepcopy(qualified['training']),'tuning':[clean(tuning)],'held_out':copy.deepcopy(retained)+[clean(heldout)],'owner_proof':None}
proposal={'schema':'vakint.final-five-loop-suite-proposal.v2','state':'PROPOSAL_ONLY_AWAIT_ROOT_EQUIVALENCE_ACCEPTANCE_AND_CASE_APPROVAL','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'frozen':False,'runtime_executions':0,'selection_uses_timings':False,'new_case_policy':'New public expressions and declared15powers generated deterministically from four original physical parents; no old heldout is converted to tuning. Proposed cases are not accepted independent until actual complete public lowering/owner map/source exclusions prove them.','source_authority':{'common_momenta_and_parents':ref(data_path),'old_suite':ref(C/'frozen-public-suites.json'),'old_reserves':ref(C/'frozen-public-reserves-v1.json'),'old_protocol':ref(C/'frozen-auth-selection-protocol-v1.json'),'old_workload':ref(V/'cache-consumer-c6-requalification/final-workload.json'),'all_five_source_root_audit':ref(audit_path),'unmeasured_metadata_check':ref(OUT/'unmeasured-metadata-check.json')},'new_tuning':[tuning],'supplementary_held_out':[heldout],'reserves_in_fixed_order':new_reserves,'retained_independent_heldout_ids':[r['id'] for r in retained],'known_seen_immutable_control_refs':[{'case_id':'parent-31740-tuning','role':'known-seen tuning-origin control'},{'case_id':'parent-31740-dot_b','role':'known-seen heldout-origin control'}],'proposed_workload_body_same_existing_schema':workload,'future_freeze_outputs':['frozen-public-suites-v2.json (one new tuning +11unchangedoldheldouts+one new supplemental)','frozen-public-reserves-v2.json (four new ordered reserves; originalv1 retained and referenced)','frozen-auth-selection-protocol-v2.json (no frozen_utc until actualRootacceptance)','final-workload-v2-provisional.json -> qualified workload after actualownerproof'],'protocol_proposal':{'selection':'Keep11 disjoint oldfixedcontrols; supplement exactly proposed last-edge30527 case; new tuning late double dot32745. No timing or cache-hit statistic selects cases.','reserves':'Only predeclared failed source/owner-independence qualification may justify an explicit reviewed alternative before final measurement; record original failure. No silent post-timing replacement or retry.','ordinary_solver_deadline':None,'diagnostic_external_seconds_if_Root_admitted':1200,'retries':0,'final_heldout_trace_eligible_for_LIGHT':False,'known_seen_old_controls_never_claimed_independent':True,'exact_output_and_full_ordered_guard_parity':True},'validation_plan':['Root first accepts active490/private public1086 source/settings equivalence and this source-only case plan. No newfreeze/run beforehand.','Freeze exact new suite/reserve/protocol JSON identities and source-generation manifest; retain every oldfrozen file and old13 results.','Qualify newtuning+supplementarycase using existing319 public one-shot uncached evaluation and existing6e5 mapper with all5actual compile stamps/currentdata/registeredguard, fullvalue+orderedguards+catalogue closure. No coefficient substitution or capture in finalheldout runs.','Reuse11 old actual uncached receipts only for functional owner qualification, keeping each original workload/source hash. Existing mapper supports mixed case workload paths and maps new frozen inventories by exactid/role/publicinput/powers. Never relabel oldreceipts as newworkload observations.','Verify all NEW complete raw/nonzero-owner sets against every explicit root/directowner of allfive sources; also reject newtuning aliasing any oldheldout protected component or newheldout, and require12 distinct nonempty heldoutowner unions. If failure, preserve it and obtain explicit pre-timing scope decision; no performance-based fallback.','Pin new acceptedownerproof and exact lower/protected sets in samev1workload schema; retain original training3 rows as historical initial preparation selection, while full five-source cumulative provenance/exclusion remains separate authoritative inventory. Do not imply finite workload generated wholeHEAVY.','Existing319/6e5 dynamicJSON interfaces need no Rust collector edits: mapper frozen_suite/reserve/protocol inputs are hash-bound files, not compiledcase IDs. Final source-bound producer and newLIGHTprofile must use new eligible tuning inventory; pilot27profile remains pilot.','Finaltimings use three fresh processes percase pervariant, fixedworkers/limits, exactvalues/fullguards. One correctlybound baseline set may support both tiers through existingcached-only control pattern, but no old11 functional receipts are reclassified as three newtimings. Reporttiercacheloading/decompression/RSS/endtoend separately; use finaldata metadata bridge where required.'],'no_new_catalog_codec_runner_or_rust_source':True}
put('proposal.json',proposal)
print(json.dumps({'proposal':ref(OUT/'proposal.json'),'history':ref(OUT/'unmeasured-metadata-check.json'),'new_tuning':{'id':tuning['id'],'powers':tuning['powers'],'source_hash':tuning['public_input_source_sha256']},'new_heldout':{'id':heldout['id'],'powers':heldout['powers'],'source_hash':heldout['public_input_source_sha256']},'receipts_checked':len(checks),'history_matches':matches},indent=2))

"""Source-only handshake for reviewed future workers, before their first 5L call.

An authorized supervisor must arrange a durable guard using the existing guard
implementation and a launch-specific config. This helper does not discover,
register, signal, start, or restart any process itself.
"""
import datetime
import hashlib
import json
import os
from pathlib import Path
import time
import stat


def require(value, message):
    if not value:
        raise RuntimeError(message)


def sha(path):
    # Executable identity uses the proc magic link; metadata paths never do.
    fd = os.open(path, os.O_RDONLY | os.O_NONBLOCK)
    with os.fdopen(fd, "rb") as stream:
        info = os.fstat(stream.fileno())
        require(stat.S_ISREG(info.st_mode), "hash input is not a regular file")
        remaining = info.st_size
        digest = hashlib.sha256()
        while remaining:
            data = stream.read(min(65536, remaining))
            require(data, "hash input truncated")
            remaining -= len(data)
            digest.update(data)
        require(not stream.read(1), "hash input grew")
        return digest.hexdigest()


def read_owned_json(path, expected_sha256=None):
    path = Path(path)
    require(path.is_absolute(), "absolute metadata path required")
    fd = os.open(path, os.O_RDONLY | os.O_NONBLOCK | os.O_NOFOLLOW)
    with os.fdopen(fd, "rb") as stream:
        info = os.fstat(stream.fileno())
        require(stat.S_ISREG(info.st_mode) and info.st_uid == os.getuid()
                and not (info.st_mode & 0o022) and info.st_size <= 1024 * 1024,
                "metadata must be a bounded owned non-writable regular file")
        data = stream.read(1024 * 1024 + 1)
    require(len(data) <= 1024 * 1024, "metadata observation envelope exceeded")
    if expected_sha256 is not None:
        require(hashlib.sha256(data).hexdigest() == expected_sha256, "metadata digest differs")
    return json.loads(data)


def identity(pid):
    root = Path(f"/proc/{pid}")
    stat = (root / "stat").read_text().rsplit(")", 1)[1].split()
    return {"pid": pid, "start_ticks": int(stat[19]), "state": stat[0], "uid": root.stat().st_uid}


def no_latch(config):
    require(not any(Path(config[key]).exists() for key in
                    ("abort_latch_path", "abort_latch_fallback_path")),
            "Memory-floor abort latched: no automatic Native call, restart, or retry")


def wait_before_native(config_path, config_sha256, slot_name, fault_path, *, target_pid=None,
                       expected_start_ticks=None):
    """Call inside the worker before its first Native operation; no Native imports."""
    config_path = Path(config_path)
    config = read_owned_json(config_path, config_sha256)
    require(config["activation_approved"] is True and config["threshold_bytes"] == 50_000_000_000
            and config["sample_seconds"] == 1 and config["uid"] == os.getuid(),
            "unapproved guard policy")
    own = identity(os.getpid() if target_pid is None else target_pid)
    if expected_start_ticks is not None:
        require(own["start_ticks"] == expected_start_ticks, "worker identity changed before guard wait")
    require(own["state"] not in ("Z", "X"), "worker is terminal")
    slots = [slot for slot in config["slots"] if slot["name"] == slot_name]
    require(len(slots) == 1, "worker has no unique authorized guard slot")
    require(slots[0]["uid"] == os.getuid()
            and sha(f"/proc/{own['pid']}/exe") == slots[0]["executable_sha256"],
            "worker UID or actual executable differs from launch authority")
    output = Path(config["output_directory"])
    while True:
        no_latch(config)
        require(not Path(fault_path).exists(), "supervisor refused registration; do not execute Native")
        registration, heartbeat = output / "registration.json", output / "heartbeat.json"
        if registration.exists() and heartbeat.exists():
            reg = read_owned_json(registration)
            beat = read_owned_json(heartbeat)
            require(reg["config_sha256"] == config_sha256, "guard acknowledged a different launch config")
            guard = identity(reg["guard"]["pid"])
            require(guard["start_ticks"] == reg["guard"]["start_ticks"]
                    and guard["uid"] == os.getuid() and guard["state"] not in ("Z", "X"),
                    "registered guard disappeared or was replaced")
            require(beat["guard_pid"] == guard["pid"], "heartbeat belongs to a different guard")
            sampled = datetime.datetime.fromisoformat(beat["utc"]).timestamp()
            slot = beat["slots"].get(slot_name, {})
            if slot.get("state") == "ARMED_EXACT_PIDFD":
                require(slot["target"]["pid"] == own["pid"]
                        and slot["target"]["start_ticks"] == own["start_ticks"],
                        "guard armed a different process")
                require(0 <= time.time() - sampled <= 3 and beat["sample_error"] is None
                        and beat["MemAvailable_bytes"] >= config["threshold_bytes"]
                        and not beat["latched_abort"], "guard sample is stale, failed or below floor")
                read_owned_json(config_path, config_sha256)
                no_latch(config)
                require(identity(own["pid"])["start_ticks"] == own["start_ticks"],
                        "worker identity changed during guard wait")
                # Final OS-policy observation follows every potentially slow
                # identity/hash check. No stale earlier ACK can authorize work.
                last = read_owned_json(heartbeat)
                last_slot = last["slots"].get(slot_name, {})
                last_sample = datetime.datetime.fromisoformat(last["utc"]).timestamp()
                require(last["guard_pid"] == guard["pid"]
                        and last_slot.get("state") == "ARMED_EXACT_PIDFD"
                        and last_slot["target"]["pid"] == own["pid"]
                        and last_slot["target"]["start_ticks"] == own["start_ticks"]
                        and 0 <= time.time() - last_sample <= 3
                        and last["sample_error"] is None and not last["latched_abort"]
                        and last["MemAvailable_bytes"] >= config["threshold_bytes"],
                        "final guard acknowledgement is stale, mismatched or unsafe")
                require(not Path(fault_path).exists(), "supervisor refused final admission")
                no_latch(config)
                return {"worker": own, "guard": guard, "config_sha256": config_sha256,
                        "slot": slot_name, "MemAvailable_bytes": last["MemAvailable_bytes"],
                        "admission_utc": datetime.datetime.now(datetime.timezone.utc).isoformat()}
            require(slot.get("state") not in ("ABORT_LATCHED_USER_MEMORY_FLOOR", "ORIGINAL_PROCESS_TERMINAL"),
                    "guard refused this worker")
        # Registration wait only, no scientific call or elapsed-time hard cap.
        time.sleep(0.1)

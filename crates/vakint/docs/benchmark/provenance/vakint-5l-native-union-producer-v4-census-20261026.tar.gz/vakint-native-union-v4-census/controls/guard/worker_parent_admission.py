"""Explicit direct-parent adapter; no Native imports, signals, services or discovery."""
import argparse
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import stat
import subprocess
import sys
import time

POLICY_PATH = Path(__file__).with_name("worker_admission_v2.py")
POLICY_SHA256 = "37e6d93aadb5452fdf4c877d2ee62e0d8e562b153f750e02b8b0c1b7563830f9"


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    proc_executable = str(path).startswith("/proc/") and str(path).endswith("/exe")
    flags = os.O_RDONLY | os.O_NONBLOCK | (0 if proc_executable else os.O_NOFOLLOW)
    fd = os.open(path, flags)
    with os.fdopen(fd, "rb") as stream:
        info = os.fstat(stream.fileno())
        require(stat.S_ISREG(info.st_mode), "hash input must be a regular file")
        require(proc_executable or info.st_size <= 16 * 1024 * 1024,
                "source/metadata hash input exceeds observation envelope")
        remaining, digest = info.st_size, hashlib.sha256()
        while remaining:
            data = stream.read(min(65536, remaining))
            require(data, "hash input truncated")
            remaining -= len(data)
            digest.update(data)
        require(not stream.read(1), "hash input grew")
        return digest.hexdigest()


def read_owned_json(path, expected_sha256=None):
    return policy().read_owned_json(path, expected_sha256)


def proc(pid):
    root = Path(f"/proc/{pid}")
    fields = (root / "stat").read_text().rsplit(")", 1)[1].split()
    return {"pid": pid, "start_ticks": int(fields[19]), "ppid": int(fields[1]), "state": fields[0],
            "uid": root.stat().st_uid, "cwd": os.readlink(root / "cwd"),
            "cgroup": (root / "cgroup").read_text().strip(),
            "argv": [part.decode() for part in (root / "cmdline").read_bytes().split(b"\0") if part]}


def service(name):
    result = subprocess.run(["/run/current-system/sw/bin/systemctl", "--user", "show", name,
                             "--property=ActiveState,MainPID,InvocationID,ControlGroup"],
                            capture_output=True, text=True, check=True)
    return dict(line.split("=", 1) for line in result.stdout.splitlines() if "=" in line)


def authenticate_parent(spec, parent_pid, *, getproc=proc, hashfile=sha, unit=service):
    worker = getproc(parent_pid)
    expected = spec["worker"]
    supervisor = spec["supervisor"]
    require(spec["schema"] == "vakint.before-native-task-launch-spec.v1"
            and spec["approved"] is True and spec["scope"] in
            ("q0", "seen", "measure-cache-5l", "tuning-5l", "held-out-5l", "5l-test", "no-native-admission-test"),
            "task is outside explicitly approved 5L admission scope")
    require(worker["uid"] == os.getuid() == expected["uid"] and worker["state"] not in ("Z", "X"),
            "direct parent worker UID/state differs")
    require(worker["cwd"] == expected["workspace"] and worker["argv"] == expected["argv"],
            "worker launch identity differs")
    require(hashfile(f"/proc/{parent_pid}/exe") == expected["executable_sha256"],
            "direct Rust parent executable differs")
    parent = getproc(worker["ppid"])
    controller = spec.get("unit_controller", supervisor)
    if "unit_controller" in spec:
        # Exactly one declared Rust-supervisor hop, never a process scan or an
        # unbounded ancestry search. Its PID may be known only after spawn.
        require(parent["ppid"] == controller["pid"] and parent["uid"] == os.getuid()
                and parent["cwd"] == supervisor["workspace"] and parent["argv"] == supervisor["argv"]
                and hashfile(f"/proc/{parent['pid']}/exe") == supervisor["executable_sha256"],
                "declared direct Rust supervisor differs")
        if supervisor.get("pid") is not None:
            require(parent["pid"] == supervisor["pid"]
                    and parent["start_ticks"] == supervisor["start_ticks"],
                    "declared Rust supervisor was replaced")
    else:
        require(parent["pid"] == supervisor["pid"] and parent["start_ticks"] == supervisor["start_ticks"]
                and parent["uid"] == os.getuid(), "authoritative supervisor was replaced")
    leader = getproc(controller["pid"])
    require(leader["start_ticks"] == controller["start_ticks"] and leader["uid"] == os.getuid(),
            "unit controller was replaced")
    registered_unit = spec["unit"]
    state = unit(registered_unit["name"])
    require(state["ActiveState"] == "active" and state["MainPID"] == str(controller["pid"])
            and state["InvocationID"] == registered_unit["invocation"]
            and state["ControlGroup"] == registered_unit["cgroup"]
            and worker["cgroup"] == "0::" + registered_unit["cgroup"]
            and parent["cgroup"] == worker["cgroup"] and leader["cgroup"] == worker["cgroup"],
            "worker unit differs")
    require(spec["source_authority"], "source/launch authority is missing")
    for item in spec["source_authority"]:
        require(Path(item["path"]).is_absolute() and hashfile(item["path"]) == item["sha256"],
                "source or launch authority changed")
    return {**worker, "direct_supervisor": {"pid": parent["pid"], "start_ticks": parent["start_ticks"]}}


def policy():
    require(sha(POLICY_PATH) == POLICY_SHA256, "reused admission policy source changed")
    descriptor = importlib.util.spec_from_file_location("reviewed_worker_admission_policy", POLICY_PATH)
    module = importlib.util.module_from_spec(descriptor)
    descriptor.loader.exec_module(module)
    return module


def admit(spec_path, spec_sha256, *, parent_pid=None):
    spec = read_owned_json(spec_path, spec_sha256)
    target_pid = os.getppid()
    require(parent_pid is None or parent_pid == target_pid, "only the direct parent may be admitted")
    worker = authenticate_parent(spec, target_pid)
    reused = policy()
    ticket_path = Path(spec["registration_ticket_path"])
    fault_path = Path(spec["registration_fault_path"])
    require(ticket_path.is_absolute() and fault_path.is_absolute(), "absolute private ticket paths required")
    for key in ("abort_latch_path", "abort_latch_fallback_path"):
        require(not Path(spec[key]).exists(), "global memory-floor abort is latched")
    if spec.get("registration_candidate_path"):
        candidate_path = Path(spec["registration_candidate_path"])
        require(candidate_path.is_absolute(), "absolute private candidate path required")
        candidate = {"schema": "vakint.before-native-worker-candidate.v1", "launch_spec_sha256": spec_sha256,
                     "worker": {"pid": target_pid, "start_ticks": worker["start_ticks"]},
                     "supervisor": worker["direct_supervisor"], "authority": "request only; not guard admission"}
        temporary = candidate_path.with_name(candidate_path.name + f".pending-{os.getpid()}")
        with temporary.open("x") as stream:
            json.dump(candidate, stream)
            stream.write("\n")
            stream.flush()
            os.fsync(stream.fileno())
        os.link(temporary, candidate_path)  # Atomic publication, never replace an existing request.
        temporary.unlink()
        descriptor = os.open(candidate_path.parent, os.O_RDONLY | os.O_DIRECTORY)
        try:
            os.fsync(descriptor)
        finally:
            os.close(descriptor)
    while not ticket_path.exists():
        for key in ("abort_latch_path", "abort_latch_fallback_path"):
            require(not Path(spec[key]).exists(), "global memory-floor abort is latched")
        require(not fault_path.exists(), "supervisor refused registration")
        require(os.getppid() == target_pid and proc(target_pid)["start_ticks"] == worker["start_ticks"],
                "direct parent changed while waiting")
        time.sleep(0.1)
    ticket = read_owned_json(ticket_path)
    require(ticket["schema"] == "vakint.before-native-registration-ticket.v1"
            and ticket["launch_spec_sha256"] == spec_sha256
            and ticket["worker"] == {"pid": target_pid, "start_ticks": worker["start_ticks"]},
            "postspawn ticket does not bind this exact worker and immutable launch spec")
    if "unit_controller" in spec:
        require(ticket["supervisor"] == worker["direct_supervisor"], "ticket binds another Rust supervisor")
    config_path = Path(ticket["guard_config"]["path"])
    config = read_owned_json(config_path, ticket["guard_config"]["sha256"])
    require(all(config[key] == spec[key] for key in ("abort_latch_path", "abort_latch_fallback_path")),
            "ticket changed global abort latch paths")
    slots = [slot for slot in config["slots"] if slot["name"] == ticket["slot"]]
    expected_target = dict(ticket["worker"])
    controller = spec.get("unit_controller", spec["supervisor"])
    if "unit_controller" in spec:
        expected_target.update(supervisor_pid=worker["direct_supervisor"]["pid"],
                               supervisor_start_ticks=worker["direct_supervisor"]["start_ticks"])
    require(len(slots) == 1 and slots[0]["target"] == expected_target
            and slots[0]["uid"] == worker["uid"]
            and slots[0]["executable_sha256"] == spec["worker"]["executable_sha256"]
            and slots[0]["workspace"] == spec["worker"]["workspace"]
            and slots[0]["parent_pid"] == controller["pid"]
            and slots[0]["parent_start_ticks"] == controller["start_ticks"]
            and slots[0]["unit"] == spec["unit"]["name"]
            and slots[0]["invocation"] == spec["unit"]["invocation"]
            and slots[0]["cgroup"] == spec["unit"]["cgroup"],
            "ticket guard slot differs from the approved authoritative launch")
    reused.wait_before_native(config_path, ticket["guard_config"]["sha256"], ticket["slot"],
                             fault_path, target_pid=target_pid, expected_start_ticks=worker["start_ticks"])
    final = authenticate_parent(spec, target_pid)
    require(os.getppid() == target_pid and final["start_ticks"] == worker["start_ticks"]
            and final["direct_supervisor"] == worker["direct_supervisor"],
            "direct parent changed during admission")
    read_owned_json(spec_path, spec_sha256)
    # Reuse the same final ACK/latch/fault policy after all slow parent, source,
    # executable and unit authentication, rather than returning the first ACK.
    result = reused.wait_before_native(config_path, ticket["guard_config"]["sha256"], ticket["slot"],
                                      fault_path, target_pid=target_pid,
                                      expected_start_ticks=worker["start_ticks"])
    return {"schema": "vakint.resource-guard-admission.v1", "admitted": True,
            "worker": {"pid": target_pid, "start_ticks": worker["start_ticks"], "uid": worker["uid"],
                       "executable_sha256": spec["worker"]["executable_sha256"]},
            "guard": result["guard"], "launch_spec_sha256": spec_sha256,
            "guard_config_sha256": ticket["guard_config"]["sha256"], "slot": ticket["slot"],
            "MemAvailable_bytes": result["MemAvailable_bytes"], "admission_utc": result["admission_utc"]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--direct-parent", action="store_true", required=True)
    parser.add_argument("--launch-spec", type=Path, required=True)
    parser.add_argument("--launch-spec-sha256", required=True)
    args = parser.parse_args()
    require(args.direct_parent, "direct-parent mode is required")
    print(json.dumps(admit(args.launch_spec, args.launch_spec_sha256)), flush=True)


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        print(json.dumps({"schema": "vakint.resource-guard-admission.v1", "admitted": False,
                          "error": str(error)}), file=sys.stderr, flush=True)
        raise SystemExit(1)

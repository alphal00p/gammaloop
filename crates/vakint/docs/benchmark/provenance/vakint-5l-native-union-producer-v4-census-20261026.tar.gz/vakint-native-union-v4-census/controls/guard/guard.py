"""Explicit user-authorized OS memory-floor guard for registered physical workers."""
import argparse
import datetime
import fcntl
import hashlib
import json
import os
from pathlib import Path
import select
import signal
import subprocess
import time


def require(value, message):
    if not value:
        raise ValueError(message)


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def atomic(path, value):
    temporary = path.with_name(path.name + ".pending")
    with temporary.open("w") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())
    temporary.replace(path)
    fd = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def persist(path, value):
    try:
        atomic(path, value)
        return True
    except Exception:
        # A full logging filesystem must not disable the authorized memory guard.
        return False


def parse_available(text):
    rows = [line.split() for line in text.splitlines() if line.startswith("MemAvailable:")]
    require(len(rows) == 1 and len(rows[0]) == 3 and rows[0][2] == "kB", "invalid MemAvailable field")
    require(rows[0][1].isdigit(), "invalid MemAvailable value")
    return int(rows[0][1]) * 1024


def breached(available, threshold):
    return available < threshold  # Equality does not trigger the user floor.


def should_attempt_abort(state, available, threshold):
    return state in ("ARMED_EXACT_PIDFD", "ABORT_AUTHENTICATION_OR_SIGNAL_ERROR") \
        and available is not None and breached(available, threshold)


def process(pid):
    root = Path(f"/proc/{pid}")
    fields = (root / "stat").read_text().rsplit(")", 1)[1].split()
    status = dict(line.split(":", 1) for line in (root / "status").read_text().splitlines() if ":" in line)
    return {"pid": pid, "start_ticks": int(fields[19]), "ppid": int(fields[1]), "state": fields[0],
            "uids": list(map(int, status["Uid"].split())),
            "cwd": os.readlink(root / "cwd"), "cgroup": (root / "cgroup").read_text().strip()}


def unit(name):
    result = subprocess.run(["/run/current-system/sw/bin/systemctl", "--user", "show", name,
                             "--property=MainPID,InvocationID,ActiveState,ControlGroup"],
                            check=True, text=True, capture_output=True)
    return dict(line.split("=", 1) for line in result.stdout.splitlines() if "=" in line)


def authenticate(slot, target, verify_executable=True):
    actual = process(target["pid"])
    require(actual["start_ticks"] == target["start_ticks"] and actual["state"] not in ("Z", "X"),
            "registered process is absent, terminal or replaced")
    supervisor_pid = target.get("supervisor_pid", slot["parent_pid"])
    supervisor_start = target.get("supervisor_start_ticks", slot["parent_start_ticks"])
    require(actual["uids"] == [slot["uid"]] * 4 and actual["ppid"] == supervisor_pid,
            "worker UID or authoritative parent differs")
    parent = process(supervisor_pid)
    require(parent["start_ticks"] == supervisor_start and parent["uids"] == [slot["uid"]] * 4,
            "authoritative child supervisor was replaced")
    controller = process(slot["parent_pid"])
    require(controller["start_ticks"] == slot["parent_start_ticks"], "unit controller was replaced")
    if supervisor_pid != slot["parent_pid"]:
        require(parent["ppid"] == slot["parent_pid"] and parent["cgroup"] == "0::" + slot["cgroup"],
                "future supervisor is not the registered controller's child")
    require(actual["cwd"] == slot["workspace"], "worker workspace differs")
    require(actual["cgroup"] == "0::" + slot["cgroup"], "worker unit/cgroup differs")
    state = unit(slot["unit"])
    require(state["MainPID"] == str(slot["parent_pid"])
            and state["InvocationID"] == slot["invocation"] and state["ActiveState"] == "active"
            and state["ControlGroup"] == slot["cgroup"], "authoritative unit differs")
    if verify_executable:
        require(sha(f"/proc/{target['pid']}/exe") == slot["executable_sha256"], "worker executable differs")
    return actual


def target_from_slot(slot):
    if slot.get("target") is not None:
        return slot["target"]
    launch_path = Path(slot["future_launch_path"])
    if not launch_path.exists():
        return None
    launch = json.loads(launch_path.read_text())
    supervisor = process(launch["supervisor"]["pid"])
    require(supervisor["start_ticks"] == launch["supervisor"]["start_ticks"]
            and supervisor["ppid"] == slot["parent_pid"],
            "future launch supervisor is not the registered controller's exact child")
    config_path = Path(slot["future_config_path"])
    require(sha(config_path) == launch["config_sha256"], "future launch config differs")
    config = json.loads(config_path.read_text())
    require(config["validated_cohort"]["executable"]["sha256"] == slot["executable_sha256"]
            and config["job_id"] == "q0" and config["capture_only_producer"] is False,
            "unapproved future physical worker")
    require(launch["collector"]["start_ticks"] is not None, "future worker has no start ticks")
    return {**{key: launch["collector"][key] for key in ("pid", "start_ticks")},
            "supervisor_pid": launch["supervisor"]["pid"],
            "supervisor_start_ticks": launch["supervisor"]["start_ticks"]}


def ready(fd):
    poll = select.poll()
    poll.register(fd, select.POLLIN)
    return bool(poll.poll(0))


def abort_target(slot, target, fd, available, config, persist_fn=persist,
                 send_fn=signal.pidfd_send_signal, ready_fn=ready, clock=time.monotonic, sleep=time.sleep):
    require(breached(available, config["threshold_bytes"]), "no actual MemAvailable breach")
    authenticate(slot, target)
    event = {"schema": "vakint.physical-memory-floor-abort.v1", "utc": utc(),
             "MemAvailable_bytes": available, "threshold_bytes": config["threshold_bytes"],
             "target": target, "slot": slot["name"], "signals": [], "scientific_success": False}
    latch = Path(config["abort_latch_path"])
    if not latch.exists():
        latched = {**event, "latched": True, "automatic_restart_or_successor_launch_forbidden": True}
        saved = persist_fn(latch, latched)
        if not saved:
            event["primary_latch_write_failed"] = True
            event["fallback_latch_persisted"] = persist_fn(Path(config["abort_latch_fallback_path"]), latched)
    send_fn(fd, signal.SIGTERM, None, 0)
    event["signals"].append({"signal": "SIGTERM", "utc": utc()})
    persist_fn(Path(config["output_directory"]) / f"abort-{slot['name']}.json", event)
    deadline = clock() + config["term_grace_seconds"]
    while not ready_fn(fd) and clock() < deadline:
        sleep(min(0.1, max(0, deadline - clock())))
    if not ready_fn(fd):
        authenticate(slot, target)
        send_fn(fd, signal.SIGKILL, None, 0)
        event["signals"].append({"signal": "SIGKILL", "utc": utc()})
    event["pidfd_terminal_observed"] = ready_fn(fd)
    event["collector_exit_code"] = None  # Only its original parent owns wait().
    persist_fn(Path(config["output_directory"]) / f"abort-{slot['name']}.json", event)
    return event


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--config-sha256", required=True)
    args = parser.parse_args()
    require(sha(args.config) == args.config_sha256, "guard config authentication failed")
    config = json.loads(args.config.read_text())
    require(config["activation_approved"] is True
            and config["threshold_bytes"] == 50_000_000_000
            and config["sample_seconds"] == 1 and config["term_grace_seconds"] == 5,
            "guard policy differs from explicit user authorization")
    require(os.getuid() == config["uid"], "guard runs as a different user")
    output = Path(config["output_directory"])
    lock = (output / "guard.lock").open("a+")
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    require(not (output / "registration.json").exists(), "guard registration already exists; no automatic retry")
    handles, states = {}, {}
    for slot in config["slots"]:
        require(slot["uid"] == os.getuid(), "cross-user guard slot prohibited")
        target = target_from_slot(slot)
        if target is not None:
            authenticate(slot, target)
            fd = os.pidfd_open(target["pid"], 0)
            authenticate(slot, target)
            handles[slot["name"]] = (slot, target, fd)
            states[slot["name"]] = {"state": "ARMED_EXACT_PIDFD", "target": target}
        else:
            states[slot["name"]] = {"state": "WAITING_AUTHORIZED_FUTURE_LAUNCH"}
    atomic(output / "registration.json", {"schema": "vakint.physical-memory-floor-registration.v1",
           "utc": utc(), "guard": process(os.getpid()), "config_sha256": args.config_sha256,
           "threshold_bytes": config["threshold_bytes"], "sample_seconds": 1,
           "slots": states, "signals_sent": []})
    while True:
        started = time.monotonic()
        available, sample_error = None, None
        try:
            available = parse_available(Path("/proc/meminfo").read_text())
        except Exception as error:
            sample_error = str(error)
        if available is not None and breached(available, config["threshold_bytes"]):
            latch = {"schema": "vakint.physical-memory-floor-abort-latch.v1", "utc": utc(),
                     "MemAvailable_bytes": available, "threshold_bytes": config["threshold_bytes"],
                     "latched": True, "automatic_restart_or_successor_launch_forbidden": True}
            if not Path(config["abort_latch_path"]).exists():
                if not persist(Path(config["abort_latch_path"]), latch):
                    persist(Path(config["abort_latch_fallback_path"]), latch)
        for slot in config["slots"]:
            name = slot["name"]
            if name not in handles and states[name]["state"] == "WAITING_AUTHORIZED_FUTURE_LAUNCH":
                try:
                    target = target_from_slot(slot)
                    if target is not None:
                        authenticate(slot, target)
                        fd = os.pidfd_open(target["pid"], 0)
                        authenticate(slot, target)
                        handles[name] = (slot, target, fd)
                        states[name] = {"state": "ARMED_EXACT_PIDFD", "target": target}
                except Exception as error:
                    states[name] = {"state": "WAITING_AUTHORIZED_FUTURE_LAUNCH",
                                    "last_registration_error": str(error)}
            if name not in handles:
                continue
            _, target, fd = handles[name]
            if ready(fd):
                states[name] = {"state": "ORIGINAL_PROCESS_TERMINAL", "target": target,
                                "collector_exit_code": None}
                os.close(fd)
                del handles[name]
                continue
            if should_attempt_abort(states[name]["state"], available, config["threshold_bytes"]):
                try:
                    event = abort_target(slot, target, fd, available, config)
                    states[name] = {"state": "ABORT_LATCHED_USER_MEMORY_FLOOR", "event": event}
                except Exception as error:
                    states[name] = {"state": "ABORT_AUTHENTICATION_OR_SIGNAL_ERROR", "error": str(error)}
        persist(output / "heartbeat.json", {"schema": "vakint.physical-memavailable-guard.v1",
            "utc": utc(), "guard_pid": os.getpid(), "threshold_bytes": config["threshold_bytes"],
            "sample_seconds": 1, "MemAvailable_bytes": available, "sample_error": sample_error,
            "latched_abort": any(Path(config[key]).exists() for key in
                                 ("abort_latch_path", "abort_latch_fallback_path")), "slots": states,
            "scope": "Only explicitly registered exact 5L worker PIDFDs; no builds/apps/other users"})
        time.sleep(max(0, 1 - (time.monotonic() - started)))


if __name__ == "__main__":
    main()

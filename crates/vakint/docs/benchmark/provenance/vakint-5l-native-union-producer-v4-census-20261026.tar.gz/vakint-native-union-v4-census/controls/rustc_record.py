#!/usr/bin/env python3
"""Record actual selected compiler invocations, without recording the environment."""
import hashlib
import json
import os
from pathlib import Path
import sys

args = sys.argv[2:]


def value(name):
    try:
        return args[args.index(name) + 1]
    except (ValueError, IndexError):
        return None


name = value("--crate-name")
out = value("--out-dir")
if out is not None:
    target = Path(os.environ["NATIVE_PRODUCER_TARGET"]).resolve()
    if not Path(out).resolve().is_relative_to(target):
        raise RuntimeError("compiler output escaped the private target")
if name in {"native_selected_cache_producer", "rustred", "rustred_app", "symbolica", "numerica", "graphica"}:
    codegen = []
    cfg = []
    for number, arg in enumerate(args):
        if arg == "-C" and number + 1 < len(args):
            codegen.append(args[number + 1])
        elif arg.startswith("-C") and len(arg) > 2:
            codegen.append(arg[2:])
        elif arg == "--cfg" and number + 1 < len(args):
            cfg.append(args[number + 1])
    record = {
        "compiler": sys.argv[1],
        "crate_name": name,
        "codegen_flags": codegen,
        "cfg": cfg,
        "test_mode": "--test" in args,
        "out_dir": out,
        "argument_sha256": hashlib.sha256(b"\0".join(os.fsencode(x) for x in args)).hexdigest(),
    }
    descriptor = os.open(os.environ["NATIVE_PRODUCER_RUSTC_LOG"], os.O_WRONLY | os.O_APPEND | os.O_CREAT, 0o600)
    try:
        os.write(descriptor, (json.dumps(record, separators=(",", ":")) + "\n").encode())
    finally:
        os.close(descriptor)
os.execvp(sys.argv[1], sys.argv[1:])

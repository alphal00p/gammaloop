"""Build and inspect one deterministic source supplement; no Native execution."""

import argparse
import gzip
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path, PurePosixPath
import stat
import tarfile


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def regular_bytes(path):
    path = Path(path)
    if not path.is_absolute() or path.resolve() != path:
        raise ValueError("source must use its canonical absolute regular filename")
    fd = os.open(path, os.O_RDONLY | os.O_NONBLOCK | os.O_NOFOLLOW)
    with os.fdopen(fd, "rb") as stream:
        info = os.fstat(stream.fileno())
        if not stat.S_ISREG(info.st_mode) or info.st_size >= 100 * 1024 * 1024:
            raise ValueError("source must be a regular repository-sized file")
        raw = stream.read()
    if len(raw) != info.st_size:
        raise ValueError("source changed while reading")
    if any(
        marker in raw
        for marker in (b"S-" + b"130-", b"-----BEGIN " + b"PRIVATE KEY-----")
    ):
        raise ValueError("source supplement must not contain a credential")
    return raw


def safe_name(name):
    path = PurePosixPath(name)
    if (
        path.is_absolute()
        or not path.parts
        or "\\" in name
        or any(part in ("", ".", "..") for part in name.split("/"))
    ):
        raise ValueError("unsafe archive name")
    if path.name in {"env.sh", ".env", "mathpass", "credentials"}:
        raise ValueError("private environment or license configuration refused")


def content(config_path):
    config_raw = regular_bytes(config_path)
    config = json.loads(config_raw)
    files, rows = {}, []
    for row in config["sources"]:
        name = row["path"]
        safe_name(name)
        if name in files:
            raise ValueError("duplicate source member")
        raw = regular_bytes(row["source"])
        if sha(raw) != row["sha256"] or len(raw) != row["bytes"]:
            raise ValueError("source differs from its exact source list")
        files[name] = raw
        rows.append(dict(row))
    files["PACKAGING_INPUTS.json"] = config_raw
    manifest = {
        "schema": "vakint.producer-source-supplement.v1",
        "archive_root": config["archive_root"],
        "qualified_helper_executable_sha256": config[
            "qualified_helper_executable_sha256"
        ],
        "qualified_helper_source_sha256": config["qualified_helper_source_sha256"],
        "codec_state_format": config["codec_state_format"],
        "original_historical_archive": config["original_historical_archive"],
        "files": sorted(rows, key=lambda row: row["path"]),
        "packaging_inputs_sha256": sha(config_raw),
        "excluded": config["excluded"],
        "scope": config["scope"],
    }
    files["manifest.json"] = (
        json.dumps(manifest, sort_keys=True, indent=2) + "\n"
    ).encode()
    files["SHA256SUMS"] = "".join(
        f"{sha(raw)}  {name}\n" for name, raw in sorted(files.items())
    ).encode()
    return config, files


def header_helper(config):
    reference = config["archive_helper"]
    raw = regular_bytes(reference["source"])
    if sha(raw) != reference["sha256"]:
        raise ValueError("existing deterministic-header helper changed")
    spec = importlib.util.spec_from_file_location(
        "source_archive_header_owner", reference["source"]
    )
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module._header


def build(config_path, output):
    config, files = content(config_path)
    header = header_helper(config)
    safe_name(config["archive_root"])
    with (
        Path(output).open("xb") as stream,
        gzip.GzipFile(
            filename="", fileobj=stream, mode="wb", mtime=0, compresslevel=9
        ) as compressed,
        tarfile.open(
            fileobj=compressed, mode="w|", format=tarfile.USTAR_FORMAT
        ) as archive,
    ):
        for name, raw in sorted(files.items()):
            archive.addfile(
                header(config["archive_root"] + "/" + name, len(raw)), io.BytesIO(raw)
            )
    # Recheck all original sources after packaging, without decoding any data cache.
    if content(config_path)[1] != files:
        raise ValueError("source bytes changed during packaging")
    return inspect(config_path, output)


def inspect(config_path, output):
    config, expected = content(config_path)
    raw = regular_bytes(Path(output).absolute())
    if raw[:3] != b"\x1f\x8b\x08" or raw[3] != 0 or raw[4:8] != b"\0\0\0\0":
        raise ValueError("gzip timestamp/name metadata is not normalized")
    found = {}
    with tarfile.open(fileobj=io.BytesIO(raw), mode="r:gz") as archive:
        for member in archive:
            safe_name(member.name)
            if not member.isfile() or member.issym() or member.islnk():
                raise ValueError("archive must contain regular files only")
            if (
                member.uid,
                member.gid,
                member.mtime,
                member.mode,
                member.uname,
                member.gname,
            ) != (0, 0, 0, 0o644, "", "") or member.pax_headers:
                raise ValueError("tar metadata is not normalized")
            prefix = config["archive_root"] + "/"
            if not member.name.startswith(prefix):
                raise ValueError("member escaped the declared archive root")
            name = member.name.removeprefix(prefix)
            if name in found:
                raise ValueError("duplicate archive member")
            found[name] = archive.extractfile(member).read()
    if list(found) != sorted(expected) or found != expected:
        raise ValueError(
            "actual archive members/bytes/order differ from the source manifest"
        )
    return {
        "archive": str(Path(output).absolute()),
        "bytes": len(raw),
        "sha256": sha(raw),
        "members": len(found),
        "uncompressed_source_bytes": sum(map(len, found.values())),
        "all_member_bytes_and_source_hashes_equal": True,
        "safe_regular_files_only": True,
        "normalized_sorted_tar_and_zero_mtime_gzip": True,
        "manifest_sha256": sha(found["manifest.json"]),
        "sha256sums_sha256": sha(found["SHA256SUMS"]),
        "build_or_native_execution": False,
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-list", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    print(
        json.dumps(
            build(args.source_list.absolute(), args.output.absolute()), sort_keys=True
        )
    )

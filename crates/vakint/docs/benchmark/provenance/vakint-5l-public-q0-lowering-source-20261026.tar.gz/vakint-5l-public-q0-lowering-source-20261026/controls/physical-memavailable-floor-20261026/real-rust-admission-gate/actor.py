"""One reviewed harmless Rust admission test; no Native operation or test kill."""
import argparse
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import stat
import subprocess
import time

HERE = Path(__file__).resolve().parent
TEST = "resource_guard_admission::tests::real_guard_admission_returns_before_any_native_work"
SYSTEMCTL = "/run/current-system/sw/bin/systemctl"
SYSTEMD_RUN = "/run/current-system/sw/bin/systemd-run"


def require(value, message):
    if not value:
        raise ValueError(message)


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def sha(path):
    proc_exe = str(path).startswith("/proc/") and str(path).endswith("/exe")
    fd = os.open(path, os.O_RDONLY | os.O_NONBLOCK | (0 if proc_exe else os.O_NOFOLLOW))
    with os.fdopen(fd, "rb") as stream:
        info = os.fstat(stream.fileno())
        require(stat.S_ISREG(info.st_mode), "hash input must be regular")
        remaining, digest = info.st_size, hashlib.sha256()
        while remaining:
            data = stream.read(min(65536, remaining))
            require(data, "hash input truncated")
            remaining -= len(data)
            digest.update(data)
        require(not stream.read(1), "hash input grew")
        return digest.hexdigest()


def checked_json(path, digest=None):
    policy_path = HERE.parent / "worker_admission_v2.py"
    require(sha(policy_path) == "37e6d93aadb5452fdf4c877d2ee62e0d8e562b153f750e02b8b0c1b7563830f9",
            "reviewed shared metadata reader changed")
    descriptor = importlib.util.spec_from_file_location("reviewed_admission_metadata_reader", policy_path)
    policy = importlib.util.module_from_spec(descriptor)
    descriptor.loader.exec_module(policy)
    return policy.read_owned_json(path, digest)


def ref(item):
    require(isinstance(item, dict) and Path(item["path"]).is_absolute()
            and sha(item["path"]) == item["sha256"], "unresolved or changed authenticated artifact")
    return Path(item["path"])


def persist(path, document):
    pending = path.with_name(path.name + ".pending")
    with pending.open("x") as stream:
        json.dump(document, stream, indent=2)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())
    require(not path.exists(), "one-shot receipt already exists")
    os.link(pending, path)
    pending.unlink()
    fd = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def process(pid):
    root = Path(f"/proc/{pid}")
    fields = (root / "stat").read_text().rsplit(")", 1)[1].split()
    return {"pid": pid, "start_ticks": int(fields[19]), "ppid": int(fields[1]), "state": fields[0],
            "uid": root.stat().st_uid}


def state(unit):
    result = subprocess.run([SYSTEMCTL, "--user", "show", unit,
        "--property=LoadState,ActiveState,SubState,MainPID,InvocationID,ControlGroup,Result,ExecMainStatus,ExecMainPID,ExecMainStartTimestamp"],
        capture_output=True, text=True, check=True)
    return dict(line.split("=", 1) for line in result.stdout.splitlines() if "=" in line)


def at(document, path):
    for key in path:
        document = document[key]
    return document


def no_abort(config):
    require(not any(Path(config[key]).exists() for key in ("abort_latch_path", "abort_latch_fallback_path")),
            "global memory-floor abort is latched")


def available_bytes(text):
    rows = [line.split() for line in text.splitlines() if line.startswith("MemAvailable:")]
    require(len(rows) == 1 and rows[0][2] == "kB" and rows[0][1].isdigit(), "bad MemAvailable sample")
    return int(rows[0][1]) * 1024


def make_spec(config, leader, unit):
    return {"schema": "vakint.before-native-task-launch-spec.v1", "approved": True,
        "scope": "no-native-admission-test",
        "worker": {"uid": os.getuid(), "workspace": str(HERE),
                   "argv": [config["test_elf"]["path"], "--exact", TEST, "--ignored", "--nocapture", "--test-threads=1"],
                   "executable_sha256": config["test_elf"]["sha256"]},
        "supervisor": {key: leader[key] for key in ("pid", "start_ticks")},
        "unit": {"name": config["actor_unit"], "invocation": unit["InvocationID"], "cgroup": unit["ControlGroup"]},
        "source_authority": [config["actor_source"], config["seven_source_freeze"], config["ordinary_gate"]["completion_receipt"],
                             config["helper"], config["policy"], config["guard_source"], config["leaf_peer"],
                             config["runtime_loader_preflight"],
                             *config["ordinary_gate"]["historical_chain"].values()],
        "registration_ticket_path": str(HERE / "run/ticket.json"),
        "registration_fault_path": str(HERE / "run/registration-fault.json"),
        "abort_latch_path": config["abort_latch_path"], "abort_latch_fallback_path": config["abort_latch_fallback_path"]}


def make_guard(config, leader, unit, worker):
    return {"schema": "vakint.physical-memory-floor-config.v1", "activation_approved": True,
        "uid": os.getuid(), "threshold_bytes": 50_000_000_000, "sample_seconds": 1, "term_grace_seconds": 5,
        "output_directory": str(HERE / "run/guard"), "abort_latch_path": config["abort_latch_path"],
        "abort_latch_fallback_path": config["abort_latch_fallback_path"],
        "slots": [{"name": "harmless-rust-admission", "uid": os.getuid(),
                   "target": {key: worker[key] for key in ("pid", "start_ticks")},
                   "parent_pid": leader["pid"], "parent_start_ticks": leader["start_ticks"],
                   "unit": config["actor_unit"], "invocation": unit["InvocationID"], "cgroup": unit["ControlGroup"],
                   "workspace": str(HERE), "executable_sha256": config["test_elf"]["sha256"]}]}


def event_from_output(text):
    decoder, events = json.JSONDecoder(), []
    for offset, character in enumerate(text):
        if character != "{":
            continue
        try:
            value, _ = decoder.raw_decode(text[offset:])
        except ValueError:
            continue
        if isinstance(value, dict) and value.get("event") == "guard_admission_without_native":
            events.append(value)
    require(len(events) == 1, "expected exactly one real no-Native admission event")
    return events[0]


def child_environment(config, spec_path, spec_sha):
    env = os.environ.copy()
    env.update(VAKINT_RESOURCE_GUARD_PYTHON=config["python"], VAKINT_RESOURCE_GUARD_HELPER=config["helper"]["path"],
        VAKINT_RESOURCE_GUARD_HELPER_SHA256=config["helper"]["sha256"],
        VAKINT_RESOURCE_GUARD_LAUNCH_SPEC=str(spec_path), VAKINT_RESOURCE_GUARD_LAUNCH_SPEC_SHA256=spec_sha,
        RUST_TEST_THREADS="1", OMP_NUM_THREADS="1", RAYON_NUM_THREADS="1",
        LD_LIBRARY_PATH=config["selected_runtime_loader_path"])
    return env


def wait_without_test_signal(child, fault_path, budget_seconds, errors):
    """A harness budget releases a blocked helper by refusal, never a test kill."""
    try:
        return child.wait(timeout=budget_seconds)
    except subprocess.TimeoutExpired:
        message = "harmless registration harness budget expired; no process signal sent"
        errors.append(message)
        if not fault_path.exists():
            persist(fault_path, {"error": message, "Native_permitted": False})
    finally:
        # The Rust test/helper must observe its explicit refusal and finish.
        # A stuck harness is reported, never converted to a fabricated exit.
        status = child.wait()
    return status


def old_pid_identity(pid):
    try:
        return process(pid)
    except FileNotFoundError:
        return None


def old_cgroup_members(path):
    path = Path(path)
    if not path.exists():
        return None
    return (path / "cgroup.procs").read_text().split()


def validate_ordinary_chain(ordinary, seven_sha, records, digests, current, *,
                            pid_reader=old_pid_identity, cgroup_reader=old_cgroup_members):
    launch, result, completion, terminal = (records[name] for name in
                                          ("launch", "result", "completion", "terminal_acceptance"))
    properties = dict(line.split("=", 1) for line in launch["actual_properties"].splitlines() if "=" in line)
    old_pid, invocation = ordinary["main_pid"], ordinary["invocation"]
    require(launch["unit"] == ordinary["unit"]
            and properties["MainPID"] == str(old_pid) and properties["InvocationID"] == invocation
            and properties["ActiveState"] == "active"
            and result["pid"] == old_pid and result["invocation_id"] == invocation
            and result["status"] == "PASS_ORDINARY_MONITOR_AND_PURE_ADMISSION_ONLY_REAL_GUARD_AND_NATIVE_PENDING",
            "ordinary historical launch/result identity differs")
    require(completion["returncode"] == 0 and completion["result_sha256"] == digests["result"]
            and terminal["result_sha256"] == digests["result"]
            and terminal["completion_sha256"] == digests["completion"]
            and terminal["state"] == "PASS_81_ORDINARY_UNITS_CLIPPY_FMT_SOURCE_CONTROL_AND_DRAIN_ONLY"
            and terminal["passing_tests"] == 81 and terminal["source_files_unchanged"] is True
            and terminal["all_command_logs_match"] is True
            and all(command["returncode"] == 0 for command in result["commands"]),
            "ordinary completion/acceptance chain is not an actual passing execution")
    require(all(record["source_seal_sha256"] == seven_sha for record in (launch, result, terminal))
            and launch["controls_sha256"] == result["controls_sha256"] == terminal["controls_sha256"]
            and terminal["real_guard_admission_executed"] is False
            and terminal["Native5L_data_cache_or_physical_operations"] == 0,
            "ordinary historical source/control/scope differs")
    require(current["ActiveState"] == "inactive" and current["MainPID"] == "0"
            and current["Result"] == "success" and current["ExecMainStatus"] == "0"
            and current["ExecMainPID"] in ("0", str(old_pid))
            and current["InvocationID"] in ("", invocation)
            and current.get("ExecMainStartTimestamp", "") in ("", properties["ExecMainStartTimestamp"]),
            "ordinary unit is active, failed or belongs to another execution")
    old_ticks = int(result["proc_start_ticks"])
    live = pid_reader(old_pid)
    require(live is None or live["start_ticks"] != old_ticks or live["state"] in ("Z", "X"),
            "exact old ordinary controller is still live")
    expected_cgroup = "/sys/fs/cgroup/user.slice/user-" + str(os.getuid()) + ".slice/user@" \
        + str(os.getuid()) + ".service/app.slice/" + ordinary["unit"]
    require(result["memory"]["cgroup"] == expected_cgroup
            and terminal["memory"]["cgroup"] == expected_cgroup,
            "historical ordinary cgroup is not the exact dedicated unit")
    members = cgroup_reader(expected_cgroup)
    require(members in (None, []), "old ordinary cgroup still contains processes")
    return {"historical_pid": old_pid, "historical_start_ticks": old_ticks,
            "historical_invocation": invocation, "source_seal_sha256": seven_sha,
            "historical_receipts_sha256": digests, "current_unit": current,
            "old_pid_observation": live, "old_cgroup": expected_cgroup,
            "old_cgroup_members": members, "cleared_systemd_fields_accepted_only_with_exact_history": True}


def preflight(config):
    require(config["activation_approved"] is True, "source-only template is inactive")
    require(isinstance(config["registration_harness_seconds"], int)
            and config["registration_harness_seconds"] > 0, "explicit harmless harness budget required")
    for name in ("actor_source", "test_elf", "seven_source_freeze", "helper", "policy", "guard_source", "leaf_peer"):
        ref(config[name])
    loader_ref = config["runtime_loader_preflight"]
    loader = checked_json(loader_ref["path"], loader_ref["sha256"])
    selected_loader = config["selected_runtime_loader_path"]
    require(isinstance(selected_loader, str) and selected_loader
            and at(loader, config["runtime_loader_value_path"]) == selected_loader
            and all(Path(path).is_absolute() and Path(path).is_dir() for path in selected_loader.split(":")),
            "selected test runtime loader differs from the authenticated ordinary preflight")
    ordinary = config["ordinary_gate"]
    document = checked_json(ordinary["completion_receipt"]["path"], ordinary["completion_receipt"]["sha256"])
    require(ordinary["acceptance_checks"], "ordinary-gate receipt checks are unresolved")
    for check in ordinary["acceptance_checks"]:
        require(at(document, check["path"]) == check["equals"], "ordinary source/build/test gate did not pass")
    chain = ordinary["historical_chain"]
    require(set(chain) == {"launch", "result", "completion", "terminal_acceptance"},
            "the exact four historical ordinary receipts are required")
    records = {name: checked_json(item["path"], item["sha256"]) for name, item in chain.items()}
    drained = validate_ordinary_chain(ordinary, config["seven_source_freeze"]["sha256"], records,
                                     {name: item["sha256"] for name, item in chain.items()}, state(ordinary["unit"]))
    no_abort(config)
    available = available_bytes(Path("/proc/meminfo").read_text())
    require(available >= 50_000_000_000 + config["startup_reserve_bytes"], "insufficient available memory for harmless gate")
    require(state(config["guard_unit"])["LoadState"] == "not-found", "test guard unit already exists")
    require(not (HERE / "run").exists(), "one-shot run already exists")
    leader, own_unit = process(os.getpid()), state(config["actor_unit"])
    require(own_unit["ActiveState"] == "active" and own_unit["MainPID"] == str(os.getpid())
            and os.getcwd() == str(HERE), "actor is not the dedicated authoritative unit MainPID/workspace")
    return leader, own_unit, {"utc": utc(), "ordinary_drained": drained, "MemAvailable_bytes": available,
                              "runtime_loader_preflight": loader_ref,
                              "selected_runtime_loader_path": selected_loader}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--config-sha256", required=True)
    args = parser.parse_args()
    config = checked_json(args.config, args.config_sha256)
    leader, own_unit, checked = preflight(config)
    run = HERE / "run"
    run.mkdir(mode=0o700)
    (run / "guard").mkdir(mode=0o700)
    os.sched_setaffinity(0, set(config["cpus"]))
    persist(run / "preflight.json", checked)
    spec = make_spec(config, leader, own_unit)
    spec_path = run / "launch-spec.json"
    persist(spec_path, spec)
    spec_sha = sha(spec_path)
    env = child_environment(config, spec_path, spec_sha)
    guard_started, guard_registered = False, None
    errors, exit_code = [], None
    with (run / "worker.log").open("xb", buffering=0) as log:
        child = subprocess.Popen(spec["worker"]["argv"], env=env, stdin=subprocess.DEVNULL,
                                 stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        try:
            worker = process(child.pid)
            require(worker["ppid"] == leader["pid"] and worker["uid"] == os.getuid()
                    and sha(f"/proc/{child.pid}/exe") == config["test_elf"]["sha256"], "actual harmless child differs")
            persist(run / "launch.json", {"utc": utc(), "supervisor": leader, "unit": own_unit,
                    "worker": worker, "argv": spec["worker"]["argv"], "launch_spec_sha256": spec_sha})
            guard_config = make_guard(config, leader, own_unit, worker)
            guard_path = run / "guard/guard-config.json"
            persist(guard_path, guard_config)
            command = [SYSTEMD_RUN, "--user", f"--unit={config['guard_unit']}", "--service-type=exec",
                f"--working-directory={run / 'guard'}", "--property=Restart=no", "--property=RuntimeMaxSec=infinity",
                f"--property=CPUAffinity={config['guard_cpu']}", "--property=StandardInput=null", "--property=UMask=0077",
                f"--property=StandardOutput=append:{run / 'guard/service.log'}", "--property=StandardError=inherit",
                config["python"], "-B", config["guard_source"]["path"], "--config", str(guard_path),
                "--config-sha256", sha(guard_path)]
            submitted = subprocess.run(command, capture_output=True, text=True, check=False)
            require(submitted.returncode == 0, "test guard service submission failed")
            guard_started = True
            guard_registered = state(config["guard_unit"])
            require(guard_registered["ActiveState"] == "active", "test guard failed at startup")
            persist(run / "guard-submission.json", {"command": command, "unit": guard_registered,
                    "stdout": submitted.stdout, "stderr": submitted.stderr})
            persist(run / "ticket.json", {"schema": "vakint.before-native-registration-ticket.v1",
                    "launch_spec_sha256": spec_sha, "worker": {key: worker[key] for key in ("pid", "start_ticks")},
                    "guard_config": {"path": str(guard_path), "sha256": sha(guard_path)},
                    "slot": "harmless-rust-admission"})
        except Exception as error:
            errors.append(str(error))
            # Refusal lets the helper return without Native; never signal a test.
            persist(run / "registration-fault.json", {"error": str(error), "Native_permitted": False})
        finally:
            exit_code = wait_without_test_signal(child, run / "registration-fault.json",
                                                 config["registration_harness_seconds"], errors)
    # No file is read or hashed while the Rust test is still writing it.
    result = {"schema": "vakint.real-rust-no-native-guard-admission.v1", "utc": utc(),
              "worker_pid": child.pid, "worker_exit_code": exit_code, "accepted": False,
              "Native_operations": 0, "reduction_operations": 0, "test_kill_or_simulated_breach": False,
              "current_q0_guard_or_registry_modified": False, "errors": errors}
    try:
        require(exit_code == 0 and not errors, "harmless Rust test failed")
        no_abort(config)
        text = (run / "worker.log").read_text()
        require(len(text.encode()) <= 1024 * 1024, "test log exceeds receipt envelope")
        event = event_from_output(text)
        receipt = event["receipt"]
        require(receipt["admitted"] is True and receipt["worker"]["pid"] == child.pid
                and receipt["worker"]["start_ticks"] == worker["start_ticks"]
                and receipt["worker"]["executable_sha256"] == config["test_elf"]["sha256"]
                and receipt["launch_spec_sha256"] == spec_sha
                and receipt["guard_config_sha256"] == sha(guard_path), "actual admission receipt differs")
        registration = json.loads((run / "guard/registration.json").read_text())
        heartbeat = json.loads((run / "guard/heartbeat.json").read_text())
        require(registration["guard"]["pid"] == receipt["guard"]["pid"]
                and registration["guard"]["start_ticks"] == receipt["guard"]["start_ticks"]
                and heartbeat["sample_error"] is None and not heartbeat["latched_abort"]
                and heartbeat["slots"]["harmless-rust-admission"]["state"] in
                    ("ARMED_EXACT_PIDFD", "ORIGINAL_PROCESS_TERMINAL"), "actual guard registration/heartbeat differs")
        require(not list((run / "guard").glob("abort-*.json")), "unexpected real memory-floor abort during test")
        result.update(accepted=True, admission_receipt=receipt,
                      log_sha256=sha(run / "worker.log"), registration=registration, final_observed_heartbeat=heartbeat)
    except Exception as error:
        result["errors"].append(str(error))
    # The dedicated test guard is stopped only after the harmless worker's real wait.
    if guard_started:
        try:
            current = state(config["guard_unit"])
            require(current["InvocationID"] == guard_registered["InvocationID"]
                    and current["MainPID"] == guard_registered["MainPID"], "test guard changed before cleanup")
            subprocess.run([SYSTEMCTL, "--user", "stop", config["guard_unit"]], check=True)
            result["test_guard_after_worker_exit"] = state(config["guard_unit"])
        except Exception as error:
            result["accepted"] = False
            result["errors"].append(f"test guard cleanup refused or failed: {error}")
    persist(run / "completion.json", result)
    print(json.dumps(result), flush=True)
    return 0 if result["accepted"] else 1


if __name__ == "__main__":
    raise SystemExit(main())

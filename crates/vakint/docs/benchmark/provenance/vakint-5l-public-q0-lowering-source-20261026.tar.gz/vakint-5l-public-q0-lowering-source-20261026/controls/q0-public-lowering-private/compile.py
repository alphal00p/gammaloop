from pathlib import Path
import json,hashlib,os,subprocess,time,datetime,shutil
O=Path(__file__).resolve().parent
W=Path("/shared/codex-1/vakint_rustred/workspace/5l-push/vakint-q0-public-lowering")
T=Path("/shared/codex-1/vakint_rustred/workspace/build/vakint-q0-public-lowering-release")
TOOLS=Path("/nix/store/7m3ahrz00pis1dplzf8vwldriqlfc0d0-rust-stable-with-components-2026-09-03/bin")
GCC="/nix/store/z4c6k0mrlkwl3s4w9ysxc8vq1wylm3ms-gcc-wrapper-15.3.0/bin/gcc"
F="feynkit-ingress,experimental-rustred,weighted-lowering-diagnostics,symbolica_community_module,progress-tui"
TEST="rustred_evaluation::five_loop::qcd_diagnostics::prepared_ladder_selected_campaign_census_without_ibps"
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):
 h=hashlib.sha256()
 with Path(p).open("rb")as f:
  while d:=f.read(1048576):h.update(d)
 return h.hexdigest()
def ref(p):return {"path":str(p),"sha256":sha(p),"bytes":Path(p).stat().st_size}
def read(p):return json.loads(Path(p).read_text())
def put(name,d):
 with(O/name).open("x")as f:json.dump(d,f,indent=2);f.write("\n");f.flush();os.fsync(f.fileno())
def git(root,*args):return subprocess.check_output(["git","-C",str(root),*args],text=True).strip()
freeze=read(O/"source-freeze.json");stamps=read(O/"compile-proof-environment.json")
assert sha(O/"source-freeze.json")=="1f19093ab1ad59ae42a15196642c64e5285991d74658cba636d62bdc9010a2fa"
for k in ["source_snapshot","diagnostic","admission","patch","compile_proof","donor"]:assert sha(freeze[k]["path"])==freeze[k]["sha256"],k
assert read(O/"donor-copy-result.json")["status"]=="PASS_READ_ONLY_INDEPENDENT_INODE_COPY_NO_BUILD"
assert git(W,"rev-parse","HEAD")==stamps["VAKINT_Q0_CENSUS_BASE_MAIN_REVISION"]
assert git(W,"diff","--name-only").splitlines()==["crates/vakint/tests/fixtures/qcd_ladder/diagnostics.rs"]
assert git(W,"ls-files","--others","--exclude-standard").splitlines()==["crates/vakint/tests/fixtures/qcd_ladder/resource_guard_admission.rs"]
assert os.sched_getaffinity(0)=={136}
assert bool(os.environ.get("SYMBOLICA_LICENSE")),"suppliedlicensepresenceonly"
version=subprocess.check_output([str(TOOLS/"rustc"),"-Vv"],text=True)
assert version.splitlines()[0]==stamps["VAKINT_Q0_CENSUS_BUILD_RUSTC"]
(O/"rustc-version.log").write_text(version)
env=os.environ.copy()
for k in list(env):
 if k.startswith("CARGO_PROFILE_")or k in ["CARGO_ENCODED_RUSTFLAGS","RUSTC_WRAPPER","RUSTC_WORKSPACE_WRAPPER"]:env.pop(k,None)
env.update(stamps)
env.update({"CARGO_HOME":"/shared/codex-1/vakint_rustred/workspace/cargo","CARGO_TARGET_DIR":str(T),"CARGO_BUILD_JOBS":"1","RUSTC":str(TOOLS/"rustc"),"RUSTFLAGS":"-C linker="+GCC,"RUSTC_WRAPPER":str(O/"rustc_record.py"),"VAKINT_Q0_CENSUS_RUSTC_LOG":str(O/"actual-rustc.jsonl"),"TMPDIR":str(O/"tmp"),"TEMP":str(O/"tmp"),"TMP":str(O/"tmp"),"RAYON_NUM_THREADS":"1","RUST_TEST_THREADS":"1","OMP_NUM_THREADS":"1","MKL_NUM_THREADS":"1","OPENBLAS_NUM_THREADS":"1","SYMBOLICA_HIDE_BANNER":"1"})
(O/"tmp").mkdir(exist_ok=True)
# Other crate-internal historical diagnostics use the existing seven stamps.
# Here they describe the actual private libtest source, not an unchanged base build.
env.update({"VAKINT_CACHE_BUILD_GIT_REVISION":stamps["VAKINT_Q0_CENSUS_BASE_MAIN_REVISION"],"VAKINT_CACHE_BUILD_MAIN_SOURCE_SNAPSHOT_SHA256":stamps["VAKINT_Q0_CENSUS_PRIVATE_SOURCE_SNAPSHOT_SHA256"],"VAKINT_CACHE_BUILD_NATIVE_SOURCE_SNAPSHOT_SHA256":stamps["VAKINT_Q0_CENSUS_NATIVE_SOURCE_SNAPSHOT_SHA256"],"VAKINT_CACHE_BUILD_RUSTRED_REVISION":stamps["VAKINT_Q0_CENSUS_NATIVE_REVISION"],"VAKINT_CACHE_BUILD_SYMBOLICA_REVISION":stamps["VAKINT_Q0_CENSUS_KERNEL_REVISION"],"VAKINT_CACHE_BUILD_PROFILE":"release","VAKINT_CACHE_BUILD_RUSTC":version.splitlines()[0]})
metadata_command=[str(TOOLS/"cargo"),"metadata","--locked","--offline","--no-default-features","--features",F,"--manifest-path","crates/vakint/Cargo.toml","--format-version","1"]
with(O/"metadata.json").open("xb")as log:
 q=subprocess.run(metadata_command,cwd=W,env=env,stdout=log,stderr=subprocess.PIPE)
(O/"metadata.stderr.log").write_bytes(q.stderr);assert q.returncode==0,q.stderr.decode(errors="replace")
m=read(O/"metadata.json");pkgs={}
for name in ["rustred","rustred-app","rustred-order","symbolica","numerica","graphica"]:
 xs=[p for p in m["packages"]if p["name"]==name];assert len(xs)==1,(name,len(xs));p=xs[0]
 expected=stamps["VAKINT_Q0_CENSUS_NATIVE_REVISION"]if name.startswith("rustred")else stamps["VAKINT_Q0_CENSUS_KERNEL_REVISION"]
 assert expected in p["source"],(name,p["source"])
 pkgs[name]={k:p[k]for k in ["id","source","manifest_path"]}
put("resolved-dependencies.json",{"feature_union":F.split(","),"packages":pkgs,"metadata":ref(O/"metadata.json")})
command=[str(TOOLS/"cargo"),"test","--locked","--offline","--release","--no-default-features","--features",F,"--package","vakint","--lib",TEST,"--no-run","--message-format=json-render-diagnostics"]
plan={"schema":"vakint.private-q0-public-lowering-build.v1","state":"PRECOMMITTED_COMPILE_ONLY","utc":now(),"source_freeze":ref(O/"source-freeze.json"),"source_snapshot":freeze["source_snapshot"],"compile_proof":ref(O/"compile-proof-environment.json"),"resolved_dependencies":ref(O/"resolved-dependencies.json"),"command":command,"compiler_wrapper":ref(O/"rustc_record.py"),"launcher":ref(__file__),"profile":"release","profile_overrides":[],"rustflags":["-C","linker="+GCC],"rustc_vv":version,"resources":{"CPU":136,"cargo_jobs":1,"MemoryMax":17179869184,"MemorySwapMax":0,"external_setup_seconds":3600},"native_runtime_or_test_executions":0,"ordinary_compile_only_not_scientific_acceptance":True}
put("build-precommit.json",plan)
started=time.monotonic()
with(O/"cargo-build.log").open("xb")as log:
 p=subprocess.Popen(command,cwd=W,env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT)
 put("build-active.json",{"pid":p.pid,"controller_pid":os.getpid(),"utc":now(),"precommit":ref(O/"build-precommit.json")})
 code=p.wait()
res={"schema":"vakint.private-q0-public-lowering-build-result.v1","state":"COMPILATION_FAILED_NO_RUNTIME","exit_code":code,"utc":now(),"elapsed_seconds":time.monotonic()-started,"precommit":ref(O/"build-precommit.json"),"cargo_log":ref(O/"cargo-build.log"),"actual_rustc":ref(O/"actual-rustc.jsonl"),"native_executions":0}
for k in ["source_snapshot","diagnostic","admission","patch","compile_proof","donor"]:assert sha(freeze[k]["path"])==freeze[k]["sha256"],"sourcechanged"+k
if code==0:
 events=[]
 for line in(O/"cargo-build.log").read_text().splitlines():
  try:d=json.loads(line)
  except json.JSONDecodeError:continue
  if d.get("reason")=="compiler-artifact"and d.get("target",{}).get("name")=="vakint"and d.get("profile",{}).get("test")and d.get("executable"):events.append(d)
 assert len(events)==1,len(events)
 e=events[0];binary=Path(e["executable"]);dep=binary.with_suffix(".d");assert dep.is_file()
 actual={}
 for line in dep.read_text().splitlines():
  if line.startswith("# env-dep:"):
   k,v=line[len("# env-dep:"):].split("=",1);actual[k]=v
 assert all(actual.get(k)==v for k,v in stamps.items()),actual
 paths=O/"artifacts";paths.mkdir()
 sealed=paths/("q0-public-lowering-sha256-"+sha(binary))
 with binary.open("rb")as i,sealed.open("xb")as o:shutil.copyfileobj(i,o);o.flush();os.fsync(o.fileno())
 sealed.chmod(0o555);assert sha(sealed)==sha(binary)and sealed.stat().st_ino!=binary.stat().st_ino
 shutil.copyfile(dep,paths/"q0-public-lowering.d")
 res.update(state="SEALED_COMPILED_NOT_EXECUTED",binary=ref(sealed),actual_compiler_artifact=e,actual_dep_info=ref(paths/"q0-public-lowering.d"),actual_custom_eight_env_dep_stamps={k:actual[k]for k in stamps},source_snapshot=freeze["source_snapshot"],base_main_revision=stamps["VAKINT_Q0_CENSUS_BASE_MAIN_REVISION"],private_source_layer=True)
put("build-result.json",res)
print(json.dumps({"state":res["state"],"result":ref(O/"build-result.json"),"exit_code":code}),flush=True)
assert code==0,"compilefailed;preserved;noRuntime"

#!/usr/bin/env python3
import json,os,sys,hashlib
from pathlib import Path
compiler,*args=sys.argv[1:]
if "--crate-name" in args:
 name=args[args.index("--crate-name")+1]
 if name=="vakint":
  row={"compiler":compiler,"crate_name":name,"is_test":"--test"in args,"argv":args,"argument_sha256":hashlib.sha256("\0".join(args).encode()).hexdigest()}
  data=(json.dumps(row,separators=(",",":"))+"\n").encode()
  fd=os.open(os.environ["VAKINT_Q0_CENSUS_RUSTC_LOG"],os.O_WRONLY|os.O_CREAT|os.O_APPEND,0o600)
  try:os.write(fd,data)
  finally:os.close(fd)
os.execv(compiler,[compiler,*args])

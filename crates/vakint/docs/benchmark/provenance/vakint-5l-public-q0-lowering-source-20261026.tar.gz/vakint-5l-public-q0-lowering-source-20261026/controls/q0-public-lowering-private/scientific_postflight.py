"""One fixed-output, stdlib-only postflight; never imports a symbolic/Native kernel."""
from pathlib import Path
from fractions import Fraction
from collections import Counter, defaultdict
from functools import lru_cache
import ast, hashlib, json, os, re, subprocess, datetime
R=Path(__file__).resolve().parent; O=R.parent; V=O.parent
C=V/'initial-routing-frontier-tuning-03ad-runtime/control-q0-public-lowering-run1'
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  while b:=f.read(1048576):h.update(b)
 return h.hexdigest()
def ref(p):return {'path':str(p),'sha256':sha(p),'bytes':Path(p).stat().st_size}
def read(p):return json.loads(Path(p).read_text())
def add(a,b):
 r=dict(a)
 for k,v in b.items():
  r[k]=r.get(k,Fraction(0))+v
  if not r[k]:del r[k]
 return r
def mul(a,b):
 r={}
 for k,v in a.items():
  for l,w in b.items():r=add(r,{tuple(x+y for x,y in zip(k,l)):v*w})
 return r
def power(a,n):
 assert type(n) is int
 if n<0:
  assert len(a)==1, 'postflight only needs exact Laurent monomial division'
  k,v=next(iter(a.items()));return {tuple(x*n for x in k):v**n}
 r={(0,0,0):Fraction(1)}
 while n:
  if n&1:r=mul(r,a)
  a=mul(a,a);n//=2
 return r
def val(node):
 if isinstance(node,ast.Constant):
  assert type(node.value) is int;return {(0,0,0):Fraction(node.value)} if node.value else {}
 if isinstance(node,ast.Name):
  assert node.id in ['D','G','M'];return {tuple(int(x==node.id) for x in ['D','G','M']):Fraction(1)}
 if isinstance(node,ast.UnaryOp):
  a=val(node.operand)
  if isinstance(node.op,ast.USub):return {k:-v for k,v in a.items()}
  assert isinstance(node.op,ast.UAdd);return a
 assert isinstance(node,ast.BinOp),ast.dump(node)
 a,b=val(node.left),val(node.right)
 if isinstance(node.op,ast.Add):return add(a,b)
 if isinstance(node.op,ast.Sub):return add(a,{k:-v for k,v in b.items()})
 if isinstance(node.op,ast.Mult):return mul(a,b)
 if isinstance(node.op,ast.Div):return mul(a,power(b,-1))
 assert isinstance(node.op,ast.Pow)
 assert not b or set(b)=={(0,0,0)}
 n=b.get((0,0,0),Fraction(0));assert n.denominator==1
 return power(a,n.numerator)
@lru_cache(None)
def poly(s):
 for a,b in [('rustred::{}::d','D'),('UFO::{}::GC_11','G'),('vakint::{}::mUV','M')]:s=s.replace(a,b)
 return val(ast.parse(s.replace('^','**'),mode='eval').body)
def powers(row):
 k=tuple(row['powers']);assert len(k)==15 and all(type(n)is int for n in k);return k
summary=read(R/'evidence/campaign-census-summary.json');full=Path(summary['full_census']['path'])
assert ref(full)==summary['full_census'];d=read(full)
assert d['schema']=='vakint.qcd-ladder.campaign-census.v1' and summary['schema']=='vakint.qcd-ladder.campaign-census-summary.v1'
assert d['source_sha256']=='9814c3b49a1b486b9790bbe5458d8bc582c3fb3c299ba6a1a0362db8ba71cb16' and d['source_bytes']==380697
assert sha(d['source'])==d['source_sha256']
manifest=d['prepared_manifest'];assert sha(manifest['path'])==manifest['sha256']=='e8bd141e653944390fd48ba234f477173caa2f84089c7ca56ea9b39938f7b1f4'
assert read(manifest['path'])==manifest['contents']
assert d['projection']==manifest['contents']['projection']=='zero-momentum-metric' and d['engineering_degree_balance']==9
assert len(d['contributions'])==manifest['contents']['contributions']==summary['contribution_count']==1
build=read(O/'build-result.json');stamps=read(O/'compile-proof-environment.json');identity=d['source_identity']
assert identity['diagnostic_source_sha256']=='adbdbe03ae093ae63a3bf4ccc00b9658711385f1f7d7c02973707bacad05336b'
assert identity['admission_source_sha256']=='bb3223d27584b42069d3813ebdcaefa6598a0935ca4531714a50248b334870cb'
for name,env in [('base_main_revision','BASE_MAIN_REVISION'),('base_main_source_snapshot_sha256','BASE_MAIN_SOURCE_SNAPSHOT_SHA256'),('native_revision','NATIVE_REVISION'),('native_source_snapshot_sha256','NATIVE_SOURCE_SNAPSHOT_SHA256'),('kernel_revision','KERNEL_REVISION'),('private_source_snapshot_sha256','PRIVATE_SOURCE_SNAPSHOT_SHA256'),('rustc','BUILD_RUSTC'),('profile','BUILD_PROFILE')]:assert identity['compiled_identity'][name]==stamps['VAKINT_Q0_CENSUS_'+env]
cohort=read(V/'initial-routing-frontier-tuning-03ad-runtime/compiled-cohort.json');assert d['semantic_binding']==cohort['semantic_binding']
assert hashlib.sha256(d['family_fingerprint'].encode()).hexdigest()=='44b030daa664fca0c71f4bb930624b098348f6184bfe46ca3ad83b86ef71df3b'
assert d['data']['load_prepared_caches'] is False and [r['loop_count'] for r in d['data']['loops']]==[1,2,3,4,5]
assert all(r['cache_loaded'] is False for r in d['data']['loops'])
assert d['native_before']==d['native_after'] and d['native_work_unchanged'] is True
assert d['prepared_owner_count']==d['rule_applications']==0 and d['persistent_cache_attached'] is False and d['ibp_application'] is False
for key in ['preparation_attempts','prepared_owners','failed_owners','cache_hits','rule_applications','coalescing_additions','cached_integrals','cached_coefficient_terms','cached_coefficient_bytes','evicted_entries','evicted_coefficient_terms','evicted_coefficient_bytes','recomputed_nodes']:
 vals=re.findall(r'\b'+key+r': (\d+)',d['native_after']);assert vals and all(int(v)==0 for v in vals),(key,vals)
assert 'hits: 0, misses: 0' in d['witness_before'] and 'hits: 0, misses: 1' in d['witness_after']
assert d['producer_entry_coverage_policy']=='FollowUnresolvedPolicy' and d['diagnostic_entry_coverage_policy']=='Advisory'
assert d['settings_session']['engine_count']==1 and d['settings_session']['expected_five_loop_snapshot_preparations']==2
for field in ['loader_owner_statistics','loader_cache_statistics','loader_cache_work_statistics']:
 for key,num in re.findall(r'\b([a-z_]+): (\d+)',d['settings_session'][field]):assert key=='declared_owners' or int(num)==0,(field,key,num)
raw=defaultdict(list);owners=defaultdict(list);ordinals=[];batch_frontier=set();counts=Counter();mass_channels=[]
for ci,c in enumerate(d['contributions']):
 assert c['contribution']==ci and c['family_fingerprint']==d['family_fingerprint']
 assert read(R/'evidence'/('contribution-'+c['source_identity']+'.json'))==c
 assert c['binding']['input_sha256']==d['source_sha256'] and c['binding']['data_manifest_sha256']==cohort['data_manifest_sha256'] and c['binding']['application_manifest_sha256']==cohort['application_sha256']
 roots=c['roots'];seen=[];anchor=roots[0]['original_mass_exponent']
 for b in c['request_batches']:
  ordinal=b['ordinal'];ordinals.append(ordinal);assert b['contribution']==ci
  combined={};mass_channels.append((b['scalar_spectator'],b['integer_mass_exponent']))
  for t in b['terms']:
   ri=t['source_root_row'];seen.append(ri);r=roots[ri];k=powers(r)
   assert powers(t)==k and t['coefficient']==r['coefficient'] and r['request_ordinal']==ordinal
   assert r['original_mass_exponent']==-sum(k) and r['D_key']==sum(k) and r['r_idx']==sum(-n for n in k if n<0)
   assert r['omega_uv_at_d4_with_mass_fixed']==20-2*sum(k)
   assert b['integer_mass_exponent']==anchor
   assert mul(poly(r['scalar_spectator']),power(poly(c['mass_squared']),r['original_mass_exponent']-anchor))==poly(b['scalar_spectator'])
   assert mul(poly(r['coefficient']),poly(r['scalar_spectator']))==poly(r['weight'])
   raw[k].append((r,ci,ordinal));counts[(r['D_key'],r['r_idx'])]+=1
   for i in r['owner_route']['images']:
    ik=powers(i);transport=poly(i['transport_coefficient']);assert transport
    weighted=mul(poly(r['coefficient']),transport)
    assert weighted==poly(i['weighted_coefficient']) and mul(poly(r['weight']),transport)==poly(i['weight'])
    assert all(k[1:]==(0,0) for k in weighted),'Native coefficient must contain only d'
    combined[ik]=add(combined.get(ik,{}),weighted);owners[ik].append((i,ci,ordinal))
  combined={k:v for k,v in combined.items() if v}
  actual={powers(i):poly(i['coefficient']) for i in b['combined_owner_terms']}
  assert len(actual)==len(b['combined_owner_terms']) and all(i['stage']=='route' for i in b['combined_owner_terms'])
  assert actual==combined and all(actual.values())
  batch_frontier.update(actual)
 assert sorted(seen)==list(range(len(roots))) and len(set(seen))==len(seen)
assert sorted(ordinals)==list(range(d['request_batch_count'])) and len(ordinals)==summary['request_batch_count']
for name,observed in [('combined_roots',raw),('combined_owner_roots',owners)]:
 actual={powers(r):r for r in d[name]};assert len(actual)==len(d[name]) and set(actual)==set(observed)
 for k,rows in observed.items():
  r=actual[k];weight={}
  for i,ci,oi in rows:weight=add(weight,poly(i['weight']))
  assert poly(r['weight'])==weight and r['multiplicity']==len(rows)
  assert r['contributions']==sorted({ci for _,ci,_ in rows}) and r['request_ordinals']==sorted({oi for _,_,oi in rows})
  if name=='combined_roots':assert all(i['admitted']==r['admitted'] for i,_,_ in rows)
assert len(raw)==summary['raw_root_union_count'] and len(owners)==summary['direct_owner_union_count']
protected_path=V/'initial-routing-frontier-tuning-03ad-runtime/full13-functional-controls/protected-raw-owner-union-current13.json'
protected=read(protected_path);forbidden={tuple(k) for k in protected['forbidden_direct_target_or_owner_keys']};assert len(forbidden)==51
raw_overlap=set(raw)&forbidden;owner_overlap=set(owners)&forbidden;frontier_overlap=batch_frontier&forbidden
assert not raw_overlap and not owner_overlap and not frontier_overlap
historical=V.parent/'physics/modern-zero-momentum/census/census.json';h=read(historical);old={powers(r) for r in h['witnesses'][0]['roots']}
completion=read(C/'completion.json');assert completion['accepted'] is True and completion['child_exit_code']==0 and completion['errors']==[]
assert completion['outputs'][0]['sha256']==sha(R/'evidence/campaign-census-summary.json')
g=d['guard_admission'];assert g['admitted'] is True and g['worker']['pid']==completion['child_pid'] and g['worker']['executable_sha256']==build['binary']['sha256']
assert g['guard_config_sha256']==completion['registration']['config_sha256'] and completion['registration']['signals_sent']==[]
assert completion['final_observed_heartbeat']['latched_abort'] is False
assert all(not Path(p).exists() for p in read(R/'config.active.json')['abort_latch_path':'abort_latch_path']) if False else True
for k in ['abort_latch_path','abort_latch_fallback_path']:assert not Path(read(R/'config.active.json')[k]).exists()
for pid in [835456,835660,836187]:assert not Path('/proc',str(pid)).exists()
units={}
for unit in ['vakint-q0-public-lowering-census-run1.service','vakint-q0-public-lowering-census-memory-guard-run1.service']:
 s=subprocess.check_output(['systemctl','--user','show',unit,'--property=ActiveState,SubState,MainPID,Result,ExecMainStatus'],text=True);units[unit]=dict(l.split('=',1) for l in s.splitlines() if '=' in l)
 assert units[unit]['MainPID']=='0' and units[unit]['ActiveState']=='inactive'
receipt={'schema':'vakint.private-q0-public-lowering-scientific-postflight.v1','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'accepted':True,'scope':'Actual public-path lower-only diagnostic, complete request/weight/mass/owner inventory and protected51 comparison; no IBP/cache-selection/performance/fullreduction acceptance','census':ref(full),'summary':ref(R/'evidence/campaign-census-summary.json'),'completion':ref(C/'completion.json'),'build_result':ref(O/'build-result.json'),'artifact_peer':ref(O/'peer-review/independent-artifact-seal-review.json'),'postflight_source':ref(__file__),'source_boundary_audit':ref(V/'source-alias-03ad-readiness/q0-physical-public-lowering-readiness.json'),'checks':{'prepared_source_and_manifest':True,'private_eight_stamp_identity':True,'semantic_application_binding':True,'all_contributions_and_request_partitions':True,'exact_stdlib_fraction_polynomial_mass_channels':True,'exact_stdlib_fraction_polynomial_owner_coefficients':True,'exact_raw_and_owner_union_weights_and_multiplicities':True,'outside_coverage_preserved':True,'no_owner_or_cache_work':True,'no_prepared_caches_loaded_1Lthrough5L':True,'guard_registered_and_full_drain':True},'counts':{'contributions':len(d['contributions']),'request_batches':len(ordinals),'raw_roots':len(raw),'direct_owner_union':len(owners),'combined_route_frontier':len(batch_frontier),'raw_admitted':sum(r['admitted'] for r in d['combined_roots']),'raw_outside_recorded_predicate':sum(not r['admitted'] for r in d['combined_roots']),'protected51_raw_overlap':len(raw_overlap),'protected51_direct_owner_overlap':len(owner_overlap),'protected51_combined_frontier_overlap':len(frontier_overlap)},'mass_channels':mass_channels,'bare_key_D_rank_counts':{str(k):v for k,v in sorted(counts.items())},'historical_comparison':{'census':ref(historical),'old_raw_roots':len(old),'exact_raw_key_intersection':len(set(raw)&old),'actual_only':len(set(raw)-old),'historical_only':len(old-set(raw)),'same_witness_or_same_raw_inventory_claim':False},'native_before':d['native_before'],'native_after':d['native_after'],'private_source_identity':d['source_identity'],'protected_union':ref(protected_path),'units_after':units,'native_runtime_calls_by_postflight':0,'independent_native_owner_rerun':False,'mathematical_reduction_claim':False,'notes':['Coefficient and union equality checked using independent stdlib Fraction multivariate Laurent-polynomial arithmetic over d, GC_11 and mUV; no Symbolica/Native import or evaluation.','Expected two snapshot preparations remain an implementation expectation, not an observed import counter.','FollowUnresolvedPolicy production entry versus diagnostic Advisory is explicit. Matcher acceptance/original-predicate probe equivalence is source-bound; no coverage extension.','Actual1086 public roots differ from historical1659 explicit-witness roots. Neither prior owner qualification nor shared9814 alone proves active490 dispatch; source-bound public-sequence adaptation plus this census supplies the replay evidence for coordinator review.']}
with (R/'scientific-postflight.json').open('x') as f:json.dump(receipt,f,indent=2);f.write('\n')
print(json.dumps({'receipt':ref(R/'scientific-postflight.json'),'counts':receipt['counts'],'historical':receipt['historical_comparison']},indent=2))

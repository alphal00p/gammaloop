from pathlib import Path
import hashlib,json,os,subprocess,datetime,shutil,time
H=Path(__file__).resolve().parent
A=H.parent
read=lambda p:json.loads(Path(p).read_text())
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def ref(p):
 p=Path(p);h=hashlib.sha256();n=0
 with p.open("rb")as f:
  while b:=f.read(1048576):h.update(b);n+=len(b)
 return {"path":str(p),"bytes":n,"sha256":h.hexdigest()}
def write(n,d):
 with (H/n).open("x")as f:json.dump(d,f,indent=2);f.write("\n");f.flush();os.fsync(f.fileno())
audit=read(H/"link-artifact-audit.json"); readiness=read(A/"helper-linkage-readiness.json")
for name in ["compiler","linker"]:assert ref(audit[name]["path"])==audit[name]
for row in audit["selected_externs"]:
 for name in ["artifact","fingerprint","fingerprint_json"]:assert ref(row[name]["path"])==row[name]
for row in audit["native_files"]:assert ref(row["path"])==row
for row in audit["source_files"].values():assert ref(row["path"])==row
art=read(audit["collector_artifacts"]["path"]);assert ref(audit["collector_artifacts"]["path"])==audit["collector_artifacts"]
stamps=dict(art["compile_proof"])
stamps["VAKINT_OWNER_QUALIFIER_LINK_AUDIT_SHA256"]=ref(H/"link-artifact-audit.json")["sha256"]
assert len(stamps)==8
out=H/"qualify-source-candidate-owners.UNQUALIFIED"
command=[audit["compiler"]["path"],"--crate-name","candidate_owner_roots","--edition=2024","--crate-type","bin","--emit=link,dep-info="+str(H/"qualifier.d"),"-C","opt-level=3","-C","lto=fat","-C","linker="+audit["linker"]["path"],"-C","strip=debuginfo",str(H/"qualify_source_candidate_owners.rs"),"-o",str(out)]
for x in audit["dependency_and_native_searches"]:command += ["-L",x]
for row in audit["selected_externs"]:command += ["--extern",row["name"]+"="+row["artifact"]["path"]]
plan={"schema":"vakint.consumer-route-helper-build.v1","state":"PRECOMMITTED","utc":now(),"source_layer":"standalone-private-source-alias-helper","source_identity":ref(H/"source-identity.json"),"link_artifact_audit":ref(H/"link-artifact-audit.json"),"linked_consumer_cohort":audit["compiled_cohort"],"linked_library_compile_proof":stamps,"command":command,"launcher":ref(__file__),"resource_policy":{"cpu":136,"MemoryMax":17179869184,"MemorySwapMax":0,"external_seconds":1200},"native_activation":False,"cargo_invocations":0,"shared_target_mutations":False}
write("build-precommit.json",plan)
env=os.environ.copy();env.update(stamps);env.update({"TMPDIR":str(H/"tmp"),"OMP_NUM_THREADS":"1","MKL_NUM_THREADS":"1","RAYON_NUM_THREADS":"1","RUSTRED_PREPARATION_WORKERS":"1"});(H/"tmp").mkdir(exist_ok=True)
started=time.monotonic()
with (H/"compiler.log").open("xb")as log:
 process=subprocess.Popen(command,cwd=H,env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT)
 write("build-active.json",{"state":"COMPILING","pid":process.pid,"controller_pid":os.getpid(),"started_utc":now(),"precommit":ref(H/"build-precommit.json")})
 code=process.wait()
result={"schema":"vakint.consumer-route-helper-build-result.v1","state":"COMPILATION_FAILED_NOT_RETRIED","exit_code":code,"utc":now(),"elapsed_seconds":time.monotonic()-started,"precommit":ref(H/"build-precommit.json"),"compiler_log":ref(H/"compiler.log"),"native_executions":0}
changed=[]
for row in audit["selected_externs"]:
 for name in ["artifact","fingerprint","fingerprint_json"]:
  if ref(row[name]["path"])!=row[name]:changed.append(row[name]["path"])
for row in audit["native_files"]+list(audit["source_files"].values()):
 if ref(row["path"])!=row:changed.append(row["path"])
result["input_drift"]=changed
if code==0 and not changed:
 dep=(H/"qualifier.d").read_text();actual={}
 for line in dep.splitlines():
  if line.startswith("# env-dep:"):
   k,v=line[len("# env-dep:"):].split("=",1);actual[k]=v
 assert all(actual.get(k)==v for k,v in stamps.items()),(actual,stamps)
 hashed=ref(out);sealed=H/("qualify-source-candidate-owners-sha256-"+hashed["sha256"])
 with out.open("rb")as i,sealed.open("xb")as o:shutil.copyfileobj(i,o);o.flush();os.fsync(o.fileno())
 sealed.chmod(0o555);assert ref(sealed)["sha256"]==hashed["sha256"] and sealed.stat().st_ino!=out.stat().st_ino
 result.update(state="SEALED_NOT_EXECUTED",executable=ref(sealed),dep_info=ref(H/"qualifier.d"),actual_eight_env_dep_stamps=actual,source_identity=ref(H/"source-identity.json"),source=ref(H/"qualify_source_candidate_owners.rs"),admission=ref(H/"resource_guard_admission.rs"),linked_consumer_cohort=audit["compiled_cohort"],link_artifact_audit=ref(H/"link-artifact-audit.json"))
write("build-result.json",result)
print(json.dumps({"state":result["state"],"result":ref(H/"build-result.json"),"code":code}),flush=True)
assert code==0 and not changed

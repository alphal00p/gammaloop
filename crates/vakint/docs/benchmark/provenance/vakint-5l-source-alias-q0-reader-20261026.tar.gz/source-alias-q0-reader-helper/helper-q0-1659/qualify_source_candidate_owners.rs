//! Standalone current-library adaptation of the preserved route-only qualifier.
//! Consumer cohort stamps identify linked libraries; this private source has its own artifact identity.
//! It verifies owner transports without preparing formulas, reducing integrals or capturing cache records.
use eyre::{Result, ensure};
use rustred::{
    family::IntegralKey,
    solver::{CandidateCacheRepresentation, UnresolvedPolicy},
};
use rustred_app::{
    AppError, SavedApplicationEntryCoveragePolicy, SavedApplicationOptions, load_saved_application,
};
use serde_json::{Value, json};
use sha2::{Digest, Sha256};
use std::{
    collections::BTreeSet,
    error::Error,
    fs::{self, File},
    io::{Read, Write},
    path::Path,
    time::Duration,
};
use symbolica::{
    atom::AtomCore,
    utils::resources::{
        ResourceBudget, ResourceLimitError, ResourceLimits, check_allocation, checkpoint,
    },
};

#[path = "resource_guard_admission.rs"]
mod resource_guard_admission;

const COHORT_SHA: &str = "ecde038c079ab65012d02c15bf598f16246277eaf614233a9c9b39b9037ce5ca";
const CENSUS_SHA: &str = "59c3a6a3e0e8b96946fe74522f09085221bd48be14a63e9089208ff9cd44b5f6";
const ROOTS_SHA: &str = "eafd2550bc63351e985a2dc52d6a87f66118da971a2e85b4d82ff17c7b5e027f";
const DATA_FILES: &[(&str, &str)] = &[
    (
        "manifest.json",
        "794c0e4b44a1c6be1d78f8ebdbca188473678823ea1f3b821f70b63b2a6dd5a7",
    ),
    (
        "5L/manifest.json",
        "81ece536cd54781b98d039325a7d62a884ec958aca27c1f4d5adca734a0f4ccb",
    ),
    (
        "5L/ibps/application.json",
        "976d574c4ad8b4021ac7a1914c624095a77f5975b98e243c7a20a9396a86ff03",
    ),
    (
        "5L/terminal-definitions.json",
        "3510ceb7c1990a8e3197fc8f3e9df7869d91c78eb3fed76fcd671ca051c7c6d0",
    ),
];

fn hash(path: &Path) -> Result<String> {
    let mut file = File::open(path)?;
    let mut digest = Sha256::new();
    let mut block = [0; 65536];
    loop {
        checkpoint()?;
        let count = file.read(&mut block)?;
        if count == 0 {
            break;
        }
        digest.update(&block[..count]);
    }
    Ok(format!("{:x}", digest.finalize()))
}
fn text<'a>(value: &'a Value, key: &str) -> Result<&'a str> {
    value[key]
        .as_str()
        .filter(|s| !s.trim().is_empty())
        .ok_or_else(|| eyre::eyre!("missing nonempty string {key}"))
}
fn required_sha<'a>(value: &'a Value, key: &str) -> Result<&'a str> {
    let digest = text(value, key)?;
    ensure!(
        digest.len() == 64 && digest.bytes().all(|b| b.is_ascii_hexdigit()),
        "invalid {key}"
    );
    Ok(digest)
}
fn read_bytes(path: &Path) -> Result<Vec<u8>> {
    check_allocation(fs::metadata(path)?.len())?;
    let bytes = fs::read(path)?;
    checkpoint()?;
    Ok(bytes)
}
fn read(path: &Path) -> Result<Value> {
    Ok(serde_json::from_slice(&read_bytes(path)?)?)
}
fn verify(path: &Path, expected: &str) -> Result<()> {
    ensure!(
        hash(path)? == expected,
        "bound file changed: {}",
        path.display()
    );
    Ok(())
}
fn stamp(name: &str, value: Option<&'static str>) -> Result<&'static str> {
    value
        .filter(|s| !s.trim().is_empty())
        .ok_or_else(|| eyre::eyre!("missing compiled {name}"))
}
fn validate_cohort(cohort: &Value) -> Result<()> {
    for (field, name, actual) in [
        (
            "main_revision",
            "VAKINT_CACHE_BUILD_GIT_REVISION",
            option_env!("VAKINT_CACHE_BUILD_GIT_REVISION"),
        ),
        (
            "native_revision",
            "VAKINT_CACHE_BUILD_RUSTRED_REVISION",
            option_env!("VAKINT_CACHE_BUILD_RUSTRED_REVISION"),
        ),
        (
            "kernel_revision",
            "VAKINT_CACHE_BUILD_SYMBOLICA_REVISION",
            option_env!("VAKINT_CACHE_BUILD_SYMBOLICA_REVISION"),
        ),
        (
            "main_source_snapshot_sha256",
            "VAKINT_CACHE_BUILD_MAIN_SOURCE_SNAPSHOT_SHA256",
            option_env!("VAKINT_CACHE_BUILD_MAIN_SOURCE_SNAPSHOT_SHA256"),
        ),
        (
            "native_source_snapshot_sha256",
            "VAKINT_CACHE_BUILD_NATIVE_SOURCE_SNAPSHOT_SHA256",
            option_env!("VAKINT_CACHE_BUILD_NATIVE_SOURCE_SNAPSHOT_SHA256"),
        ),
    ] {
        ensure!(
            text(cohort, field)? == stamp(name, actual)?,
            "compiled {field} differs from sealed cohort"
        );
    }
    stamp(
        "VAKINT_CACHE_BUILD_RUSTC",
        option_env!("VAKINT_CACHE_BUILD_RUSTC"),
    )?;
    ensure!(
        stamp(
            "VAKINT_CACHE_BUILD_PROFILE",
            option_env!("VAKINT_CACHE_BUILD_PROFILE")
        )? == "release",
        "release library/toolchain plan required"
    );
    Ok(())
}
fn resource_cause<'a>(mut error: &'a (dyn Error + 'static)) -> Option<&'a ResourceLimitError> {
    loop {
        if let Some(resource) = error.downcast_ref::<ResourceLimitError>() {
            return Some(resource);
        }
        error = error
            .downcast_ref::<std::io::Error>()
            .and_then(std::io::Error::get_ref)
            .map(|inner| inner as &(dyn Error + 'static))
            .or_else(|| error.source())?;
    }
}
fn admission(result: std::result::Result<bool, AppError>) -> Result<Value> {
    match result {
        Ok(admitted) => Ok(json!({"admitted":admitted,"error":null})),
        Err(error) if resource_cause(&error).is_some() => Err(error.into()),
        Err(error) => Ok(
            json!({"admitted":null,"error":{"kind":error.kind().as_str(),"message":error.to_string()}}),
        ),
    }
}
fn optional_u64(value: &Value, key: &str) -> Result<Option<u64>> {
    if value[key].is_null() {
        return Ok(None);
    }
    Ok(Some(
        value[key]
            .as_u64()
            .ok_or_else(|| eyre::eyre!("invalid {key}"))?,
    ))
}

fn run(input_path: &Path, input: &Value, output: &Path, task_admission: &Value) -> Result<()> {
    ensure!(
        input["schema"] == "vakint.source-candidate-owner-qualification-request.v2",
        "wrong request schema"
    );
    ensure!(!output.exists(), "preserve existing output");
    let input_sha = hash(input_path)?;
    let source_sha = format!(
        "{:x}",
        Sha256::digest(include_bytes!("qualify_source_candidate_owners.rs"))
    );
    ensure!(
        required_sha(input, "helper_source_sha256")? == source_sha,
        "helper source binding differs"
    );
    let executable = std::env::current_exe()?;
    let executable_sha = hash(&executable)?;
    ensure!(
        required_sha(input, "helper_executable_sha256")? == executable_sha,
        "helper ELF binding differs"
    );
    let link_audit = Path::new(text(input, "link_artifact_audit_path")?);
    let link_sha = required_sha(input, "link_artifact_audit_sha256")?;
    ensure!(
        link_sha
            == stamp(
                "VAKINT_OWNER_QUALIFIER_LINK_AUDIT_SHA256",
                option_env!("VAKINT_OWNER_QUALIFIER_LINK_AUDIT_SHA256")
            )?,
        "compiled link artifact audit differs"
    );
    verify(link_audit, link_sha)?;
    let cohort_path = Path::new(text(input, "cohort_receipt_path")?);
    verify(cohort_path, COHORT_SHA)?;
    let cohort = read(cohort_path)?;
    validate_cohort(&cohort)?;
    let census_path = Path::new(text(input, "source_census_path")?);
    let roots_path = Path::new(text(input, "source_roots_path")?);
    verify(census_path, CENSUS_SHA)?;
    verify(roots_path, ROOTS_SHA)?;
    let census = read(census_path)?;
    ensure!(
        census["schema"] == "vakint.qcd-ladder.q0-native-census.v1",
        "wrong authenticated q0 census kind"
    );
    ensure!(
        census["input"]["sha256"]
            == "9814c3b49a1b486b9790bbe5458d8bc582c3fb3c299ba6a1a0362db8ba71cb16",
        "q0 source input differs"
    );
    ensure!(
        census["family_fingerprint"] == cohort["semantic_binding"]["family_fingerprint"],
        "historical q0 census family differs from current linked family"
    );
    let witnesses = census["witnesses"]
        .as_array()
        .ok_or_else(|| eyre::eyre!("missing q0 witness array"))?;
    ensure!(
        witnesses.len() == 1,
        "authenticated q0 input must have its one recorded witness"
    );
    let census_rows = witnesses[0]["roots"]
        .as_array()
        .ok_or_else(|| eyre::eyre!("missing q0 witness roots"))?;
    let source_roots = read(roots_path)?;
    let root_rows = source_roots
        .as_array()
        .ok_or_else(|| eyre::eyre!("recorded q0 roots must be the original array"))?;
    ensure!(
        !root_rows.is_empty() && root_rows.len() == census_rows.len(),
        "recorded q0 root inventory differs"
    );
    let mut observed = BTreeSet::new();
    for (index, row) in root_rows.iter().enumerate() {
        checkpoint()?;
        let powers = serde_json::from_value::<Vec<i64>>(row["powers"].clone())?;
        ensure!(
            powers.len() == 15 && observed.insert(powers),
            "malformed or duplicate q0 source root"
        );
        ensure!(
            row["powers"] == census_rows[index]["powers"],
            "q0 source-root order/powers differ from authenticated witness"
        );
    }
    let requested = input["source_row_indices"]
        .as_array()
        .ok_or_else(|| eyre::eyre!("Root must request all q0 source_row_indices"))?;
    ensure!(
        requested.len() == root_rows.len()
            && requested
                .iter()
                .enumerate()
                .all(|(index, value)| value.as_u64() == u64::try_from(index).ok()),
        "all q0 source rows must be requested in original order"
    );
    let data = Path::new(text(input, "data_path")?);
    for (relative, expected) in DATA_FILES {
        verify(&data.join(relative), expected)?;
    }
    let options = SavedApplicationOptions {
        unresolved_policy: UnresolvedPolicy::Preserve,
        entry_coverage_policy: SavedApplicationEntryCoveragePolicy::Advisory,
        preparation_workers: 1,
        cache_representation: CandidateCacheRepresentation::Sparse,
        ..Default::default()
    };
    checkpoint()?;
    let prepared = load_saved_application::<15>(&data.join("5L/ibps"), options)?;
    let digest: [u8; 32] =
        serde_json::from_value::<Vec<u8>>(cohort["semantic_binding"]["artifact_digest"].clone())?
            .try_into()
            .map_err(|_| eyre::eyre!("invalid actual program digest"))?;
    let binding = prepared.cache_binding(digest);
    let binding_json = json!({"artifact_digest":binding.artifact_digest,"family_fingerprint":binding.family_fingerprint,"physical_arity":binding.physical_arity,"layer":binding.layer});
    ensure!(
        binding_json == cohort["semantic_binding"],
        "native program binding differs from actual public cohort"
    );
    let before = (
        prepared.owner_preparation_statistics(),
        prepared.cache_statistics(),
        prepared.cache_work_statistics(),
    );
    ensure!(
        before.0.preparation_attempts == 0
            && before.0.prepared_owners == 0
            && before.1.rule_applications() == 0,
        "route-only load unexpectedly prepared/applied owner formulas"
    );
    let mut rows = Vec::new();
    for (index, source_row) in root_rows.iter().enumerate() {
        checkpoint()?;
        let powers = serde_json::from_value::<Vec<i64>>(source_row["powers"].clone())?;
        let key = IntegralKey::try_new(powers.clone())?;
        let raw_admission = admission(prepared.entry_is_admitted(&key))?;
        let mut row = json!({"source_row_index":index,"census_witness_index":0,"census_root_index":index,"source_root_row":source_row,"raw_powers":powers,"raw_recorded_coverage":raw_admission,"route_success":false,"route_error":null,"owner_endpoints":[],"nonzero_conditions":[],"eligible_for_training":false});
        match prepared.route_entry_to_owner(&key) {
            Ok(mapped) => {
                let mut endpoints = Vec::new();
                for (owner, coefficient) in mapped.terms() {
                    checkpoint()?;
                    if coefficient.is_zero() {
                        continue;
                    }
                    endpoints.push(json!({"powers":owner.powers(),"coefficient":coefficient.to_expression().to_canonical_string(),"recorded_coverage":admission(prepared.entry_is_admitted(owner))?}));
                }
                row["owner_endpoints"] = json!(endpoints);
                row["nonzero_conditions"] = json!(
                    mapped
                        .nonzero_conditions()
                        .iter()
                        .map(|guard| guard.to_expression().to_canonical_string())
                        .collect::<Vec<_>>()
                );
                row["native_route_statistics"] = json!(format!("{:?}", mapped.statistics()));
                row["route_success"] = json!(true);
            }
            Err(error) if resource_cause(&error).is_some() => return Err(error.into()),
            Err(error) => {
                row["route_error"] =
                    json!({"kind":error.kind().as_str(),"message":error.to_string()})
            }
        }
        rows.push(row);
    }
    let after = (
        prepared.owner_preparation_statistics(),
        prepared.cache_statistics(),
        prepared.cache_work_statistics(),
    );
    ensure!(
        before == after,
        "route scan unexpectedly changed formula/cache work statistics"
    );
    for (relative, expected) in DATA_FILES {
        verify(&data.join(relative), expected)?;
    }
    for (path, expected) in [
        (input_path, input_sha.as_str()),
        (cohort_path, COHORT_SHA),
        (census_path, CENSUS_SHA),
        (roots_path, ROOTS_SHA),
        (link_audit, link_sha),
        (executable.as_path(), executable_sha.as_str()),
    ] {
        verify(path, expected)?;
    }
    let result = json!({"schema":"vakint.source-candidate-owner-qualification.v2","selected_rows_complete":true,"all_routes_succeeded":rows.iter().all(|row| row["route_success"] == true),"scope":"Verified saved owner transport only; no formulas prepared, no IBP/reduction/capture, no training selection or performance/closure claim.","input_path":input_path,"input_sha256":input_sha,"helper_source_sha256":source_sha,"helper_executable_path":executable,"helper_executable_sha256":executable_sha,"helper_rustc":stamp("VAKINT_CACHE_BUILD_RUSTC",option_env!("VAKINT_CACHE_BUILD_RUSTC"))?,"compilation_kind":"standalone_direct_rustc_against_authenticated_current_release_rlibs","helper_source_layer":"private-source-alias-q0-current-library-adaptation","resource_guard_admission":task_admission,"helper_admission_source_sha256":format!("{:x}",Sha256::digest(include_bytes!("resource_guard_admission.rs"))),"link_artifact_audit_path":link_audit,"link_artifact_audit_sha256":link_sha,"cohort_receipt_path":cohort_path,"cohort_receipt_sha256":COHORT_SHA,"compiled_cohort":cohort,"semantic_binding":binding_json,"data_path":data,"data_files":DATA_FILES,"source_census_path":census_path,"source_census_sha256":CENSUS_SHA,"source_input_kind":"authenticated-q0-native-census-and-recorded-root-list","source_roots_path":roots_path,"source_roots_sha256":ROOTS_SHA,"source_stream_rows":root_rows.len(),"source_row_indices":requested,"native_options":format!("{options:?}"),"resources":input["resources"],"owner_and_cache_statistics_before":format!("{before:?}"),"owner_and_cache_statistics_after":format!("{after:?}"),"selection_performed":false,"incidental_descendants_observed":false,"rows":rows});
    let bytes = serde_json::to_vec_pretty(&result)?;
    let pending = output.with_extension(format!("pending-{}", std::process::id()));
    let mut file = fs::OpenOptions::new()
        .create_new(true)
        .write(true)
        .open(&pending)?;
    file.write_all(&bytes)?;
    file.sync_all()?;
    checkpoint()?; // Final resource checkpoint: no new ResourceError after publication.
    fs::hard_link(&pending, output)?; // Atomic create, preserving any existing output.
    fs::remove_file(&pending)?;
    File::open(output.parent().unwrap_or(Path::new(".")))?.sync_all()?;
    Ok(())
}
fn main() -> Result<()> {
    let args = std::env::args().collect::<Vec<_>>();
    ensure!(
        args.len() == 3,
        "usage: qualify_source_candidate_owners REQUEST.json OUTPUT.json"
    );
    // This task explicitly requires the existing PIDFD/floor admission boundary.
    // It precedes the first task/document read and all Native activation.
    let task_admission = resource_guard_admission::admit_from_task_env()?.ok_or_else(|| {
        eyre::eyre!("this private source-alias task requires resource-guard admission")
    })?;
    let path = Path::new(&args[1]);
    let input = read(path)?;
    let resources = &input["resources"];
    let elapsed = optional_u64(resources, "max_elapsed_seconds")?.map(Duration::from_secs);
    let budget = ResourceBudget::new(ResourceLimits {
        max_process_rss_bytes: optional_u64(resources, "max_process_rss_bytes")?,
        max_elapsed: elapsed,
    });
    // Ordinary lexical composition retains any genuine outer resource scope.
    // Native's real verification worker dispatch captures this context itself.
    budget.run(|| {
        checkpoint()?;
        run(path, &input, Path::new(&args[2]), &task_admission)
    })
}

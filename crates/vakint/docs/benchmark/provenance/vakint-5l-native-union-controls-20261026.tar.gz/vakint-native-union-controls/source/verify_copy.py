"""Bounded independent byte/inode postflight; no Native codec or math imports."""

import hashlib
import json
import os
from pathlib import Path
import re
import stat


def regular_files(root):
    if root.resolve(strict=True) != root:
        raise ValueError("canonical root required")
    files = []
    for directory, subdirs, names in os.walk(root, followlinks=False):
        for name in subdirs:
            if not stat.S_ISDIR((Path(directory) / name).lstat().st_mode):
                raise ValueError("non-directory/symlink in source tree")
        for name in sorted(names):
            path = Path(directory) / name
            info = path.lstat()
            if not stat.S_ISREG(info.st_mode):
                raise ValueError(f"nonregular file: {path}")
            files.append((path, info))
    return files


def digest(path, expected):
    descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    with os.fdopen(descriptor, "rb") as stream:
        opened = os.fstat(stream.fileno())
        if any(
            getattr(opened, key) != getattr(expected, key)
            for key in ["st_dev", "st_ino", "st_size", "st_mtime_ns", "st_ctime_ns"]
        ):
            raise ValueError("file changed before opening")
        value = hashlib.sha256()
        while block := stream.read(1024 * 1024):
            value.update(block)
        final = os.fstat(stream.fileno())
    # Access time may change on read; device/inode/length/mtime/ctime may not.
    for info in [final, path.lstat()]:
        if any(
            getattr(info, key) != getattr(expected, key)
            for key in ["st_dev", "st_ino", "st_size", "st_mtime_ns", "st_ctime_ns"]
        ):
            raise ValueError("file changed while reading")
    return value.hexdigest()


def main():
    here = Path(__file__).resolve().parent
    request_path = here / "request.json"
    request = json.loads(request_path.read_text())
    raw_path = here / "native-output/raw-validation.json"
    raw = json.loads(raw_path.read_text())
    completion_path = here / "guarded-run1/run/completion.json"
    completion = json.loads(completion_path.read_text())
    if completion.get("accepted") is not True or completion.get("errors") != []:
        raise ValueError("actual controller did not accept and drain its worker")
    if raw.get("success") is not True or raw["copy_statistics"]["copied_bases"] != 3:
        raise ValueError("actual Native union failed")
    if raw["request_sha256"] != hashlib.sha256(request_path.read_bytes()).hexdigest():
        raise ValueError("actual request identity differs")
    source_files = [
        entry
        for source in request["sources_newest_first"]
        for entry in regular_files(Path(source["directory"]))
    ]
    destination_files = regular_files(here / "native-output")
    source_inodes = {(s.st_dev, s.st_ino) for _, s in source_files}
    destination_inodes = [(s.st_dev, s.st_ino) for _, s in destination_files]
    if len(destination_inodes) != len(set(destination_inodes)):
        raise ValueError("destination hardlink alias")
    if source_inodes.intersection(destination_inodes):
        raise ValueError("destination aliases an original source inode")
    candidates = {}
    for path, info in source_files:
        if re.fullmatch(r"[a-f0-9]{64}\.rrchunk\.gz", path.name):
            candidates.setdefault(path.name, []).append((path, info))
    chunks = []
    for path, info in destination_files:
        if not re.fullmatch(r"[a-f0-9]{64}\.rrchunk\.gz", path.name):
            continue
        value = digest(path, info)
        sources = candidates.get(path.name, [])
        if not sources:
            raise ValueError("output chunk has no original source candidate")
        for source, before in sources:
            if before.st_size != info.st_size or digest(source, before) != value:
                raise ValueError("output/source compressed bytes differ")
        chunks.append(
            {
                "file": path.name,
                "bytes": info.st_size,
                "sha256": value,
                "source_candidates": [str(p) for p, _ in sources],
            }
        )
    statistics = raw["copy_statistics"]
    if (
        len(chunks) != statistics["unique_physical_chunks"]
        or sum(row["bytes"] for row in chunks)
        != statistics["physical_compressed_bytes"]
    ):
        raise ValueError("physical file census differs from Native copy result")
    result = {
        "schema": "vakint.independent-small3-opaque-copy-postflight.v1",
        "success": True,
        "verifier_source_sha256": hashlib.sha256(
            Path(__file__).read_bytes()
        ).hexdigest(),
        "raw_validation_sha256": hashlib.sha256(raw_path.read_bytes()).hexdigest(),
        "controller_completion_sha256": hashlib.sha256(
            completion_path.read_bytes()
        ).hexdigest(),
        "source_regular_files": len(source_files),
        "destination_regular_files": len(destination_files),
        "all_destination_inodes_independent_from_sources": True,
        "all_destination_inodes_distinct": True,
        "all_output_chunk_bytes_equal_each_original_candidate": True,
        "chunks": sorted(chunks, key=lambda item: item["file"]),
        "coefficient_decode_or_reduction": False,
        "scope": "Closed small N=3 opaque preservation pilot only; Native owns compressed framing/hash checks and count arithmetic. No unique-key, source-exposure, final cache, performance or scientific completion claim.",
    }
    output = here / "independent-copy-postflight.json"
    with output.open("x") as stream:
        json.dump(result, stream, indent=2)
        stream.write("\n")
    print(
        json.dumps(
            {
                "success": True,
                "chunks": len(chunks),
                "compressed_bytes": statistics["physical_compressed_bytes"],
                "postflight_sha256": hashlib.sha256(output.read_bytes()).hexdigest(),
            }
        )
    )


if __name__ == "__main__":
    main()

"""Data-free AST-function mocks: never import controllers or shared runtime modules."""
import ast
from copy import deepcopy
import json
from pathlib import Path, PurePosixPath
from types import SimpleNamespace
import unittest

HERE = Path(__file__).resolve().parent
SOURCE = HERE / "command_actor.py"


def require(value, message):
    if not value:
        raise ValueError(message)


def typed_equal(left, right):
    if type(left) is not type(right):
        return False
    if isinstance(left, dict):
        return left.keys() == right.keys() and all(typed_equal(left[k], right[k]) for k in left)
    if isinstance(left, list):
        return len(left) == len(right) and all(typed_equal(a, b) for a, b in zip(left, right))
    return left == right


def at(document, keys):
    for key in keys:
        document = document[key]
    return document


class InertPath(PurePosixPath):
    """All filesystem operations are synthetic; no service or data observation."""
    def exists(self):
        return False

    def read_text(self):
        return "MemAvailable: 100000000 kB\n"


def load_functions():
    tree = ast.parse(SOURCE.read_text(), filename=str(SOURCE))
    only_functions = ast.Module(body=[n for n in tree.body if isinstance(n, ast.FunctionDef)], type_ignores=[])
    namespace = {"Path": InertPath, "HERE": InertPath("/synthetic/control"),
        "require": require, "typed_equal": typed_equal,
        "common": SimpleNamespace(at=at), "os": SimpleNamespace(getuid=lambda: 1124)}
    exec(compile(only_functions, str(SOURCE), "exec"), namespace)
    return namespace


class Controls(unittest.TestCase):
    def setUp(self):
        self.n = load_functions()

    def test_syntax_only_for_actual_files(self):
        for name in ("command_actor.py", "test_source_controls.py"):
            compile((HERE / name).read_text(), str(HERE / name), "exec")

    def test_inactive_refuses_before_any_observation(self):
        self.n["checked_json"] = lambda *a: self.fail("inactive control read metadata")
        with self.assertRaisesRegex(ValueError, "inactive"):
            self.n["preflight"]({"activation_approved": False})

    def test_exact_field_validation_is_type_sensitive(self):
        self.n["expected_fields"]({"nested": {"x": 1}}, {"nested.x": 1})
        with self.assertRaises(ValueError):
            self.n["expected_fields"]({"nested": {"x": True}}, {"nested.x": 1})

    def test_spec_uses_only_actual_mock_runtime_identities(self):
        self.n["sources"] = lambda *a: [{"path": "/synthetic/source", "sha256": "a" * 64}]
        config = {"actor_unit": "synthetic.service", "abort_latch_path": "/synthetic/a",
                  "abort_latch_fallback_path": "/synthetic/b"}
        worker = {"argv": ["/synthetic/elf"], "uid": 1124, "workspace": "/synthetic/worker",
                  "executable_sha256": "b" * 64}
        spec = self.n["make_spec"](config, {"mode": "direct", "worker": worker},
            {"pid": 123, "start_ticks": 456}, {"InvocationID": "mock-invocation", "ControlGroup": "/mock"},
            InertPath("/synthetic/run"))
        self.assertEqual(spec["scope"], "5l-test")
        self.assertEqual(spec["worker"], worker)
        self.assertEqual(spec["supervisor"], {"pid": 123, "start_ticks": 456})
        self.assertNotIn("unit_controller", spec)
        self.assertEqual(spec["registration_candidate_path"], "/synthetic/run/candidate.json")

    def test_candidate_is_request_only_and_exact_direct_child(self):
        worker = {"pid": 7, "start_ticks": 8, "direct_supervisor": {"pid": 3, "start_ticks": 4}}
        candidate = {"schema": "vakint.before-native-worker-candidate.v1", "launch_spec_sha256": "x",
            "authority": "request only; not guard admission", "worker": {"pid": 7, "start_ticks": 8},
            "supervisor": {"pid": 3, "start_ticks": 4}}
        leaf = SimpleNamespace(authenticate_parent=lambda *a: deepcopy(worker))
        self.assertEqual(self.n["validate_candidate"](candidate, {}, "x", worker, leaf), worker)
        for change in ({"authority": "admitted"}, {"worker": {"pid": 7, "start_ticks": 9}}):
            with self.assertRaises(ValueError):
                self.n["validate_candidate"]({**candidate, **change}, {}, "x", worker, leaf)
        with self.assertRaises(ValueError):
            self.n["validate_candidate"](candidate, {}, "x", {"pid": 99, "start_ticks": 8}, leaf)

    def test_guard_is_exact_new_slot_and_direct_worker(self):
        config = {"slot": "synthetic-slot", "actor_unit": "synthetic.service",
            "abort_latch_path": "/synthetic/a", "abort_latch_fallback_path": "/synthetic/b"}
        spec = {"worker": {"workspace": "/synthetic/worker", "executable_sha256": "b" * 64}}
        value = self.n["make_guard"](config, spec, {"pid": 7, "start_ticks": 8},
            {"pid": 3, "start_ticks": 4}, {"InvocationID": "mock", "ControlGroup": "/mock"},
            InertPath("/synthetic/run"))
        self.assertEqual(value["threshold_bytes"], 50_000_000_000)
        self.assertEqual(value["slots"][0]["target"], {"pid": 7, "start_ticks": 8})
        self.assertEqual(value["slots"][0]["parent_pid"], 3)
        self.assertEqual(value["slots"][0]["name"], "synthetic-slot")

    def fixture(self):
        keys = ("generation", "runs", "chunk_references", "stored_record_references", "referenced_compressed_bytes", "manifest_bytes")
        censuses = [dict(zip(keys, row)) for row in ((3, 2, 2, 120, 30, 7), (19, 18, 18, 1089, 80, 9), (393, 388, 392, 25088, 100, 11))]
        request = {"semantic_binding": {"synthetic": True}, "limits": {"synthetic": True},
            "sources_newest_first": [{"id": f"synthetic-{i}", "expected": {k: (None if k == "runs" else v) for k, v in c.items()}} for i, c in enumerate(censuses)]}
        packet = {"request": {"path": "/synthetic/request", "sha256": "r"},
            "artifact": {"path": "/synthetic/artifact", "sha256": "a"},
            "worker": {"executable_sha256": "e"}}
        cohort = {"synthetic": "cohort"}
        totals = {key: sum(row[key] for row in censuses) for key in keys[1:-1]}
        raw = {"request_sha256": "r", "executable_sha256": "e", "collector_artifacts": {"sha256": "a"},
            "compiled_cohort": cohort, "semantic_binding": request["semantic_binding"], "limits": request["limits"],
            "sources_newest_first": request["sources_newest_first"], "source_censuses": censuses,
            "source_reference_totals": totals, "output_census": {"generation": 1, **totals, "manifest_bytes": 33},
            "copy_statistics": {"preserved_record_references": 26297, "unique_physical_chunks": 400,
                "physical_compressed_bytes": 200, "index_bytes": 33, "charged_disk_bytes": 233}}
        self.n["checked_json"] = lambda path, digest: {"/synthetic/request": request, "/synthetic/artifact": {"compiled_cohort": cohort}}[path]
        return packet, raw

    def test_full_counts_and_reference_vs_physical_dedup(self):
        packet, raw = self.fixture()
        self.n["validate_union_report"](raw, packet)
        self.assertEqual(raw["source_reference_totals"]["chunk_references"], 412)
        self.assertEqual(raw["copy_statistics"]["unique_physical_chunks"], 400)

    def test_source_order_and_exact_cohort_changes_refuse(self):
        for field, replacement in (("sources_newest_first", []), ("compiled_cohort", {}), ("request_sha256", "other")):
            packet, raw = self.fixture()
            raw[field] = replacement
            with self.assertRaises(ValueError):
                self.n["validate_union_report"](raw, packet)

    def test_null_prior_count_requires_full_actual_integer_census(self):
        packet, raw = self.fixture()
        for bad in (None, True, -1):
            changed = deepcopy(raw)
            changed["source_censuses"][0]["runs"] = bad
            with self.assertRaises(ValueError):
                self.n["validate_union_report"](changed, packet)

    def test_changed_generation_reference_sum_and_charge_refuse(self):
        packet, raw = self.fixture()
        for section, key, value in (("output_census", "generation", 2), ("output_census", "stored_record_references", 26296),
            ("source_reference_totals", "runs", 0), ("copy_statistics", "charged_disk_bytes", 232),
            ("copy_statistics", "physical_compressed_bytes", 211)):
            changed = deepcopy(raw)
            changed[section][key] = value
            with self.assertRaises(ValueError):
                self.n["validate_union_report"](changed, packet)

    def test_before_native_receipt_guard_worker_and_spec_are_exact(self):
        worker = {"pid": 7, "start_ticks": 8, "uid": 1124}
        guard = {"pid": 10, "start_ticks": 11, "uid": 1124}
        raw = {"executable_sha256": "e", "resource_guard_admission": {
            "schema": "vakint.resource-guard-admission.v1", "admitted": True,
            "worker": {**worker, "executable_sha256": "e"}, "guard": guard,
            "launch_spec_sha256": "s", "guard_config_sha256": "g", "slot": "synthetic-slot",
            "MemAvailable_bytes": 50_000_000_001}}
        registration = {"config_sha256": "g", "signals_sent": [],
            "slots": {"synthetic-slot": {"state": "ARMED_EXACT_PIDFD", "target": {"pid": 7, "start_ticks": 8}}},
            "guard": {"pid": 10, "start_ticks": 11, "uids": [1124]}}
        heartbeat = {"guard_pid": 10, "sample_error": None, "latched_abort": False,
            "slots": {"synthetic-slot": {"state": "ORIGINAL_PROCESS_TERMINAL"}}}
        service = {"MainPID": "10", "process": {"start_ticks": 11}}
        self.n["exact_fields"] = lambda actual, expected: require(all(k in actual and typed_equal(actual[k], v) for k, v in expected.items()), "receipt differs")
        f = self.n["validate_admission_report"]
        f(raw, {"slot": "synthetic-slot"}, worker, "s", "g", registration, heartbeat, service)
        for key, value in (("launch_spec_sha256", "other"), ("admitted", 1)):
            changed = deepcopy(raw)
            changed["resource_guard_admission"][key] = value
            with self.assertRaises(ValueError):
                f(changed, {"slot": "synthetic-slot"}, worker, "s", "g", registration, heartbeat, service)

    def mocked_preflight(self):
        resources = {"CPUs": [149], "math_threads": 1, "memory_max_bytes": 17179869184,
            "swap_bytes": 0, "outer_RuntimeMaxSec": 1200, "Rust_max_case_seconds": None, "retries": 0}
        variables = {"LD_LIBRARY_PATH": {"is_set": True, "value": "/synthetic/python:/synthetic/openssl"},
                     "LD_PRELOAD": {"is_set": False, "value": None}}
        packet = {"mode": "direct", "scope": "5l-test", "worker": {"uid": 1124, "argv": ["/synthetic/elf"], "executable_sha256": "e"},
            "limits": resources, "loader_environment": {"observed_build_info": {"path": "/synthetic/loader", "sha256": "l"}, "variables": variables},
            "expected_outputs": [{"path": "/synthetic/output/raw.json", "expected_fields": {"success": True}}], "output_directory": "/synthetic/output"}
        loader = {"schema": "native.private-producer-buildinfo-loader-environment.v1", "variables": deepcopy(variables)}
        config = {"activation_approved": True, "command_packet": {"path": "/synthetic/packet", "sha256": "p"},
            "run_directory": "/synthetic/control/run", "guard_unit": "synthetic-guard.service", "actor_unit": "synthetic.service"}
        state = {"ActiveState": "active", "MainPID": "42", "InvocationID": "mock", "ControlGroup": "/mock"}
        self.n.update(checked_json=lambda path, digest: {"/synthetic/packet": packet, "/synthetic/loader": loader}[path],
            sources=lambda *a: [], sha=lambda path: "e", process=lambda pid: {"pid": 42, "start_ticks": 43},
            state=lambda unit: {"LoadState": "not-found"} if unit == "synthetic-guard.service" else state,
            utc=lambda: "synthetic-not-observed-UTC",
            os=SimpleNamespace(getuid=lambda: 1124, getpid=lambda: 42, getcwd=lambda: "/synthetic/control",
                               sched_getaffinity=lambda pid: {149}, environ={"SYMBOLICA_LICENSE": "synthetic-test-only"}),
            common=SimpleNamespace(no_abort=lambda c: None, available_bytes=lambda text: 67179869184, at=at),
            reviewed=SimpleNamespace(unit_resources=lambda unit: {"CPUQuotaPerSecUSec": "1s", "MemoryMax": "17179869184", "MemorySwapMax": "0", "RuntimeMaxUSec": "20min"}))
        return config, packet, loader

    def test_actual_nested_loader_schema_and_cpu149_preflight_with_all_io_mocked(self):
        config, packet, loader = self.mocked_preflight()
        result = self.n["preflight"](config)
        self.assertEqual(result[0], packet)
        self.assertEqual(result[-1]["MemAvailable_bytes"], 67179869184)
        self.assertEqual(result[-1]["loader_variables"], loader["variables"])
        loader["variables"]["LD_PRELOAD"] = {"is_set": True, "value": "/synthetic/preload"}
        with self.assertRaises(ValueError):
            self.n["preflight"](config)

    def test_preflight_wrong_cpu_or_host_floor_refuses_with_all_io_mocked(self):
        for mutation in ("cpu", "floor"):
            config, _, _ = self.mocked_preflight()
            if mutation == "cpu":
                self.n["os"].sched_getaffinity = lambda pid: {136}
            else:
                self.n["common"].available_bytes = lambda text: 67179869183
            with self.assertRaises(ValueError):
                self.n["preflight"](config)

    def test_preflight_rejects_extra_hop_or_wrong_scope_with_all_io_mocked(self):
        for key, value in (("mode", "extra-hop"), ("scope", "tuning-5l")):
            config, packet, _ = self.mocked_preflight()
            packet[key] = value
            with self.assertRaises(ValueError):
                self.n["preflight"](config)

    def test_actual_documents_contain_no_fabricated_runtime_identities(self):
        config = json.loads((HERE / "config.conditional.json").read_text())
        packet = json.loads((HERE / "command-packet.json").read_text())
        unit = json.loads((HERE / "unit-submission-proposal.json").read_text())
        self.assertIs(config["activation_approved"], True)
        self.assertIn("CONDITIONAL", config["activation_state"])
        self.assertEqual(packet["limits"]["CPUs"], [149])
        self.assertEqual(packet["mode"], "direct")
        self.assertEqual(packet["scope"], "5l-test")
        self.assertTrue(all(v is None for v in unit["future_runtime_identity"].values()))
        self.assertIs(unit["launch_performed"], False)
        self.assertEqual(packet["loader_environment"]["variables"]["LD_PRELOAD"], {"is_set": False, "value": None})


if __name__ == "__main__":
    unittest.main()

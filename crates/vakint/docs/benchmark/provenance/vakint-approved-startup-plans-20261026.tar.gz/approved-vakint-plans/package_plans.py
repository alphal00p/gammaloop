"""Preserve approved startup inputs without creating maintained prose copies."""

import argparse
import gzip
import hashlib
import io
import json
import re
import tarfile
from pathlib import Path


def archive_bytes(source_root: Path) -> tuple[bytes, dict]:
    names = (
        "5L_PUSH_PLAN.md",
        "PRECISION_AND_INSPECTION_PLAN.md",
        "VAKINT_EXTERNAL_DATA_PLAN.md",
    )
    entries = {name: (source_root / name).read_bytes() for name in names}
    for body in entries.values():
        if re.search(rb"SYMBOLICA_LICENSE\s*=\s*[A-Za-z0-9\"']", body):
            raise ValueError("A plan contains a license assignment")
    entries["package_plans.py"] = Path(__file__).read_bytes()
    manifest = {
        "schema": "vakint.approved-startup-plan-inputs.v1",
        "scope": "Historical approved user inputs; original bytes, not a new completion claim or maintained plan copy.",
        "files": {
            name: {"bytes": len(body), "sha256": hashlib.sha256(body).hexdigest()}
            for name, body in sorted(entries.items())
        },
    }
    entries["manifest.json"] = (json.dumps(manifest, indent=2) + "\n").encode()
    raw = io.BytesIO()
    with tarfile.open(fileobj=raw, mode="w", format=tarfile.USTAR_FORMAT) as tar:
        for name, body in sorted(entries.items()):
            member = tarfile.TarInfo("approved-vakint-plans/" + name)
            member.size = len(body)
            member.mode = 0o644
            tar.addfile(member, io.BytesIO(body))
    return gzip.compress(raw.getvalue(), compresslevel=9, mtime=0), manifest


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source_root", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    body, manifest = archive_bytes(args.source_root)
    repeated, _ = archive_bytes(args.source_root)
    if body != repeated:
        raise ValueError("Archive build was not deterministic")
    args.output.write_bytes(body)
    print(
        json.dumps(
            {
                "bytes": len(body),
                "sha256": hashlib.sha256(body).hexdigest(),
                "manifest": manifest,
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()

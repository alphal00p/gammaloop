# Five-loop campaign integration, compact caching, and interactive HEPKit examples

**Goal:** Integrate the current 640-master five-loop campaign into Vakint; validate and benchmark the complete quadratic four-rung quark-loop UV fixture and independent pinch-closure tests; implement safe incomplete reductions and a useful, compact persistent 5L cache; align the Python APIs with Symbolica Community conventions; and deliver polished Marimo apps over the tailnet, with published data, reproducible measurements, and tested source changes.

## 1. Startup and parallel coordination

Upon starting implementation:

1. Write this complete approved Markdown plan verbatim, including the goal, startup instructions, and prompt appendix, but excluding the surrounding `<proposed_plan>` tags, to `/shared/codex-1/vakint_rustred/5L_PUSH_PLAN.md`.
2. Assign the **Goal** paragraph above using `create_goal`, without a token budget.
3. Read the applicable contribution instructions. Fetch and fast-forward `vakint_rustred` and external-data `main`, preserving unrelated work. Record all starting revisions.
4. Keep temporary files, additional checkouts, build outputs, pilot datasets, logs, and development configuration beneath `/shared/codex-1/vakint_rustred/workspace`. Use the existing Symbolica license through the environment.
5. Keep the parent agent primarily responsible for coordination, integration, review, and delivery. Assign independent agents to:
   - campaign loading and dependency compatibility;
   - the physical benchmark and exact reference checks;
   - closure tests and incomplete-reduction behavior;
   - native persistent-cache support;
   - cache workload selection and performance measurements;
   - Python API compliance and Marimo apps;
   - independent final review and release validation.

Give each track clear file ownership. Serialize shared dependency changes, release publication, and performance measurements. Publish intermediate findings and preserve resumable job identities.

Initial inspection found the compressed-data compatibility changes on `five-loop-640-loader-acceptance` at `6cdaa993…`, separate from `vakint_rustred`. Integrate those changes while preserving the delivered precision/inspection work; do not replace the branch with an older implementation. Reconcile shared FeynKit components with their maintained `feynkit` lineage and lock a coherent Symbolica/Numerica/Graphica/PyO3 dependency set.

## 2. Campaign integration and scientific validation

### Campaign loading

- Load the latest authenticated external-data checkout during development. Validate its 640 family-qualified catalogue entries, graphs, program objects, terminal substitutions, checksums, and compatibility bindings.
- Keep all 640 entries explicitly uncomputed, with no invented Laurent coefficients.
- Preserve lower-loop data and compatible caches. Revalidate native compatibility after coordinated dependency changes.
- Use the actual saved starting predicates as the coverage authority. The current metadata records rank six inclusive and \(D\leq10\) over particular domains; these maxima are not blanket coverage of every integral with those values.
- Confirm cumulative 1L–5L loading through both local-checkout and official-release APIs. Preserve transactional activation and offline reuse.

### Primary benchmark: complete quadratic fixture

Reuse the existing four-rung, single massless-quark-loop fixture as the primary case (b), preserving its original scientific definition:

- Generate and dress the graph through FeynKit’s native QCD APIs.
- Retain the complete quadratic Taylor coefficient of both numerator and propagators.
- Preserve the transverse contraction
  \[
  \frac{\delta_{ab}}{8(d-1)q^2}
  \left(g_{\mu\nu}-\frac{q_\mu q_\nu}{q^2}\right).
  \]
- Use efficient native color/Dirac/tensor contraction to dot products before unnecessary scalar expansion.
- Insert the common \(M_{\mathrm{UV}}\) only into vacuum denominators; keep slash numerators massless.
- Preserve all contributions. The physical groups have \((A,R)=(14,4),(15,5),(16,6)\), hence \(D=A-R=10\). Historical preparation produced 21 groups and 8,306 scalar terms; verify exact algebra rather than treating a printer-dependent term count as the scientific reference.
- Check graph incidence, routing, Jacobians, normalization, mass homogeneity, and the exact lowered input. Distinguish twelve vacuum incidence edges from nine distinct quadratic denominator forms after coalescing.
- Compare every fully mapped starting key against the authenticated campaign predicates.

If the primary fixture has a correctly mapped input outside recorded coverage, promptly return the offending identities, routing, mass factors, and failed predicates to the user. Allow a safe diagnostic reduction to proceed, but do not silently change the fixture, omit terms, widen certification, or repair the campaign. Unexpected undeclared terminals in this primary example must likewise be reported explicitly.

Keep the simpler zero-momentum contraction as an additional diagnostic: retain both current vertices, contract with unaveraged \(g_{\mu\nu}\delta_{ab}\), and preserve native diagram factors. It has numerator energy dimension ten, \(R=5,\ A=14,\ D=9\). It does not replace the quadratic benchmark.

### Closure tests

Construct independent numerator/pinch pairs satisfying
\[
\left(\prod_i D_i^{b_i}\right)I(a_1,\ldots,a_n)
=I(a_1-b_1,\ldots,a_n-b_n).
\]

Use independently constructed FeynKit graphs and actual propagator quadratics, including their mass terms. Cover:

- factorized controls and genuinely connected pinches across the physical parent families;
- single and multiple cancellations;
- partial cancellation of a dotted propagator and complete cancellation into a pinch;
- mixed remaining dots and multiple numerator factors;
- the two dotted rung-graph attachments and a gluon rung;
- repeated quadratic forms, alternative loop routings, and nonunit common mass;
- expanded and factored numerator representations.

Pilot candidates deterministically. Select cases whose complete comparison takes at most 240 seconds, with a 300-second hard test deadline and no retries. Replace slow candidates within the same coverage class; record excluded pilots rather than silently dropping the class. Keep the full physical benchmark outside this fast-test ceiling.

Require exact rational-expression agreement, correct mass/normalization factors, valid nonzero conditions, and catalogue closure for the supported controls. Identical execution paths must preserve guards exactly; independently routed paths may retain different sufficient guards, whose validity must be checked.

### Out-of-coverage behavior

- Separate verified kinematic matching from campaign membership. Prefer a covered routing witness, but retain a deterministic verified fallback when all candidates are outside coverage.
- Use RustRed’s existing `UnresolvedPolicy::Preserve` for ordinary 5L evaluation. Coverage failures produce an advisory warning and do not stop reduction.
- Preserve individual rule applicability, nonzero conditions, exact back-substitution, transport checks, cycle detection, and operational limits.
- After exact combination, classify surviving integrals against the active catalogue.
- In **Retain** mode, return the expression and emit one readable warning listing sorted, deduplicated unknown family-qualified symbols, data version, and parent-DOT references.
- With **Symbolic or Numerical master substitution**, return a graceful error identifying surviving unknown integrals or unavailable required coefficients.
- Declared but uncomputed catalogue masters are valid retained results and remain inspectable. Do not call them unknown masters.
- Canceled residuals must disappear from diagnostics.
- Corruption, unsafe algebra, invalid transports, and exhausted limits remain errors.

No new IBP generation or campaign repair is included.

## 3. Persistent 5L cache and reproducible benchmarks

### Native cache support

Extend the existing cache implementation instead of adding a parallel reduction/cache system.

- Add backing, completed-node capture, and export support for RustRed saved applications, reusing native `Route`/`Apply` records, exact coefficients, guards, and semantic bindings.
- Capture descendants only at completed native reduction nodes with their proper local conditions. Do not reconstruct rules from diagnostic traces.
- Keep cache preparation strict. Partial reductions must never enter distributed caches or satisfy strict lookups.
- Bind caches to the complete campaign, terminal substitutions, family, physical arity, codec, and solver layer.
- Extend Vakint’s existing `prepare_cache`, `load_cache`, `save_cache`, reports, and Python wrappers to 5L. Implement the requested `build_cache()` as the reproducible workload driver around this API.

Deliver **one gzip-compressed native binary cache file**, using the existing native chunk codec and one shared coefficient table. No multipart runtime format or tar archive of cache chunks.

Decompress once with a 1 GiB decoded-payload limit; authenticate compressed and decoded lengths/hashes, framing, and bindings. Import native symbolic state once and retain a bounded record index, avoiding a full coefficient-table copy/import on every hit. Reject corruption, excess output, trailing data, and extra gzip members. Temporary resumable preparation may use existing checkpoint machinery under `workspace`.

Submit focused dependency changes upstream and pin their validated commits.

### Workload selection and limits

- Extract canonical scalar roots from the **complete quadratic benchmark**, including multiplicities and native descendants.
- Freeze separate tuning and final held-out suites before cache selection.
- Start with a 15-minute pilot; expand to approximately one hour and then at most three cumulative pilot hours only while useful information or gains continue.
- Prioritize repeated benchmark subreductions, useful connected pinches, small dot changes, and numerator patterns by measured native work avoided per compressed byte.
- Avoid exhaustive Cartesian enumeration of all five-loop dots and pinches.
- Freeze the final selected workload. Its reproducible build has a **10-hour wall-clock maximum**, including compaction and finalization; plan nine hours for preparation and one hour of reserve. Pilot/tuning time is reported separately and is outside this limit.
- Publish only a completed selected workload. If a candidate exceeds a budget, retain the last complete validated selection rather than claiming interrupted preparation is complete.

Target a compressed file of **50 MiB or less**. Permit growth only when a larger candidate improves either the quadratic benchmark’s median IBP time or the tuning suite’s geometric-mean IBP time by at least **20%** relative to the best ≤50 MiB candidate. Choose the smallest candidate meeting that criterion; hard-cap the final file at **95 MiB**. Keep final held-out measurements out of this selection decision.

Report root counts, intermediate records, capture-budget exhaustion, skipped optional captures, preparation time, decoded size, compressed size, and selection rationale.

### Measurements

Use optimized builds, fixed worker counts/affinity, recorded revisions, identical limits, and retained-master mode.

Measure separately:

1. FeynKit graph/numerator preparation;
2. external-data loading and owner preparation;
3. routing and scalar lowering;
4. IBP reduction and terminal substitution;
5. cache loading/decompression;
6. end-to-end execution.

Compare fresh processes with no persistent cache against fresh processes loading the produced cache. Report warm in-process reuse separately. Use three measurements and median/range for final comparisons, with exact result and guard checks.

Freeze at least twelve held-out inputs across multiple parents, dot distributions, numerators, and pinches. They must not be explicitly selected training roots. Distinguish incidental root hits from intermediate-only benefits, and report regressions and negligible gains as well as speedups. Re-run the complete quadratic fixture and the simpler diagnostic with the final cache.

## 4. Python compliance and Marimo apps

Follow the pinned [Symbolica Community extension guide](https://github.com/symbolica-dev/symbolica-community/blob/cad32c8f589c8a29531414f94b3fbe58020e0308/docs/writing-extensions.md):

- Use canonical `symbolica.community.hepkit` APIs and actual shared FeynKit, tensor, and Symbolica wrappers.
- Build one native host with one Symbolica kernel and consistent shared dependency identities.
- Call component Rust APIs directly from bindings. Replace the identified Python import used to construct momentum replacements with native `PythonReplacement` construction.
- Preserve fallible diagram validation and shared wrapper identity.
- Regenerate stubs and test standalone and Community hosts with the same interoperability assertions.
- Submit owner fixes and any required small Community integration update.

Build four linked interactive Marimo apps, following the presentation and native tensor workflow of the [HEPKit four-loop numerator example](https://www.hepkit.org/gallery/notebooks/four_loop_numerator.py):

1. **Graphs and numerators:** model, topology, routing, native gamma/color contraction, dot products, and Vakint ingress.
2. **Constants and masters:** searchable native catalogues, `get_constant`, `get_master`, precision controls, formulas, coefficient tables, and interactive graphs.
3. **Five-loop UV reduction:** the complete quadratic fixture, the simpler diagnostic, campaign coverage, retained results, and measured cache comparisons.
4. **Pinch identities and caching:** interactive small closure examples, held-out results, cache size/provenance, and warning behavior.

Reuse existing rich representations and native graph rendering. Clearly label 5L entries as uncomputed and demonstrate the expected substitution error. Use computed lower-loop masters for numerical precision examples.

Default page opening must remain responsive. Display authenticated recorded results for expensive examples and require an explicit run action for heavy recomputation. Do not launch cache production from the apps or install a second Symbolica wheel implicitly.

Serve the tested apps through a dedicated persistent user service and a new **tailnet-only HTTPS endpoint** on `itphlies.tailb3264.ts.net`, preserving existing services. Use interactive app mode, not the editor. Keep service configuration and logs under `workspace`, and provide the URL plus restart/stop commands. Verify actual browser rendering, controls, formulas, graph interaction, websocket connectivity, and console errors.

## 5. Acceptance and delivery

- Independently review campaign bindings, physical conventions, exact closure, cache records, and Python type ownership.
- Test covered and uncovered reductions, successful reductions outside coverage, surviving/canceling unknown terminals, uncomputed declared masters, and strict-cache isolation.
- Test compressed-cache round trips, incompatibility, corruption, bounded decompression, repeated loading, and transactional replacement.
- Validate all 640 catalogue graphs through FeynKit/Vakint and retain lower-loop precision/evaluation regressions.
- Run relevant Rust/Python tests, Clippy, formatting, generated-stub checks, notebook execution, and repository-required full CI/upload gates.
- Refresh benchmark Typst/PDF/raw-data artifacts with measured results. Preserve historical measurements with their original provenance.
- Verify every new repository file is below 100 MiB, the cache is at most 95 MiB under the stated exception, and every release asset is below 2 GB.
- Publish the next unused immutable external-data patch release, then update `data-latest`. Verify actual published downloads, cache attachment, and subsequent offline reuse in a fresh directory.
- Push Vakint directly to `vakint_rustred`; push external data and submit focused dependency/owner PRs.
- Deliver source/release/PR links, the tailnet gallery URL, uncached/cached timings, cache-selection rationale, validation reports, and any precisely identified remaining limitation. Do not claim campaign coverage beyond its recorded predicates.

## 6. Recorded planning decisions

- Serve interactive apps inspired by the HEPKit gallery.
- The 10-hour allowance applies to the final cache build; pilots are additional.
- Target ≤50 MiB, allowing one file up to 95 MiB only for the measured improvement defined above.
- Do not repair or extend the IBP campaign.
- Attempt reductions outside recorded coverage and report surviving residuals according to master mode.
- Use the complete quadratic fixture as primary case (b), preserving its transverse normalization.
- Keep the simpler \(R=5,\ A=14,\ D=9\) contraction as an additional diagnostic, with unaveraged \(g_{\mu\nu}\delta_{ab}\) and both current vertices retained.
- If correctly mapped benchmark inputs violate the expected campaign scope, return the concrete evidence to the user instead of silently altering the benchmark.

## 7. Verbatim original user prompt

```text
I want you to do the following (with many parallel tracks to be covered by independent subagents, you'll be mostly a coordinator):\
\
a) Update your local repo \`vakint_rustred\` branch of this repo, as well as the vakint-external-data repository with the latest remote version which now has a new 5-loop catalogue of 640 master integrals (none of them computed yet) and parametric reduction plan/rules.\
\
b) Verify that you can reduce the 5-loop dotted single-scale UV vacuum single trace example (the four-gluon rug diagrams, using FeynKit for the efficient reduction of gamma traces to dot products) using this new campaign (it guarantees R<6 and D<=10 reduction, so it should work) and note the reduction time taken.\
\
c) Make sure the pyO3 python API of feynkit follows the guidelines gives in [https\://github.com/symbolica-dev/symbolica-community/blob/cad32c8f589c8a29531414f94b3fbe58020e0308/docs/writing-extensions.md]\(https\://github.com/symbolica-dev/symbolica-community/blob/cad32c8f589c8a29531414f94b3fbe58020e0308/docs/writing-extensions.md) and build very good looking marimo notebooks exemplifying the use of the API (i.e. including the get_master and get_constant), and serve these to an address "over the tailnet" that I can access from the outside.\
\
d) Run a battery of tests for the 5-loop reduction, using the closure test of verifying that an input with a numerator cancelling a denominator indeed reproduces he same reduction than directly calling the pinch topologies (do this with various combinations of (multiple) numerators with this property and dotted topologies). Be mindful of performances and select cases in your test suite that have good testing powers but still run somewhat fast (\~5 min max for each).\
\
e) Build an appropriate selection of reduction cases to perform in the build_cache() function in vakint, so that it creates many useful shortcuts (also for intermediate descendants) but still runs in like 10 hours max (but start smaller and expand it mindfully). Once complete, test how much the cache helps in many test cases outside of the one selected in build_cache() and report on that too. I particular, re-run case b) with the cache, and see how much it sped up this particular reduction. Also keep in mind that github release assets must remain below 2GB and individual files in the repo must be under 100 MiB (ideally under 50 MiB). You'll see modifications in latest vakint allowing for loading compressed reduction tables, but we need something similar for loading the cache. Unless proven necessary, let's try for now to keep the compressed version of the binary cache produced (that will then be pushed to github) for this 5L campaign to 50 MiB or less. And if really necessary, only then consider a split-files load (i.e. serialization/deserialization) approach, but I would prefer you don't do that. So for now try and keep this compressed cache to 50 MiB, and carefully choose the most useful reductions in \`build_cache()\`, i.e. those that would help case b) is a good guideline.\
\
f) Also make sure that if at any point the starting integral is outside of the scope of what is "officially" supported by the reduction table, then vakint still attempts the reduction but if it is left with a final reduced expression with any master outside of the catalogue then it emits a clean and elegant warning, enumerating clearly the list of symbols for the integrals left that are not masters. It should not immediately abort as it may well be that the reduction still succeeds even though it is outside of the bounds of what is officially supported by the reduction tables.\
\
Review carefully the plan above and ask questions for anything unclear. Add to the plan a goal statement, this prompt verbatim at the end, and also instructions to write, upon starting implementation of the plan, this plan verbatim as ./5L_PUSH_PLAN.md and assign it to yourself as a goal.\
```

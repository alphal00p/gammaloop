# Precision-aware evaluation and rich constant/master APIs

**Goal:** Implement precision-aware Laurent-series evaluation and integrated Rust/Python constant and master inspection APIs in Vakint, preserving achieved accuracy through symbolic conversion, reporting explicit precision limitations, providing at least 20,000 validated digits for the remaining finite primitive periods, returning faithful FeynKit master graphs, and offering polished terminal and notebook displays. Validate and deliver the coordinated dependency, external-data, and Vakint changes.

## 1. Startup instructions and evaluation contract

Upon starting implementation:

1. Write this approved plan’s complete Markdown body verbatim, including the goal, startup instructions, and prompt appendix, but excluding the surrounding `<proposed_plan>` tags, to `./PRECISION_AND_INSPECTION_PLAN.md`. The absolute destination is `/shared/codex-1/vakint_rustred/PRECISION_AND_INSPECTION_PLAN.md`.
2. Assign the **Goal** paragraph above to yourself using `create_goal`, without a token budget.
3. Read and follow the applicable repository contribution instructions. Fast-forward Vakint and external-data repositories to their latest branches, preserving unrelated work.
4. Keep development files, downloaded validation material, additional checkouts, license configuration, and build outputs under `/shared/codex-1/vakint_rustred/workspace`.
5. Use the supplied Symbolica license through the environment. Mathematica may assist development calculations; Vakint’s build, required user tests, and runtime must remain independent of it.

Evaluate complete Laurent coefficients using precision-tracking arithmetic, including cancellations between masters, masses, normalization factors, parameters, and momentum contractions.

- Perform **one evaluation** at the requested precision plus the existing fixed guard allowance. **No automatic retry.**
- Return achieved real and imaginary precision independently.
- Warn when a used source cannot support the requested precision or cancellation reduces final accuracy.
- Every warning names the problematic symbols/master coefficients, epsilon orders, requested precision, available or achieved precision, and data version.
- Missing coefficients, unsupported operations, and unresolved masters remain graceful errors.

Use Numerica’s arbitrary-precision `ComplexBall` arithmetic through a reusable Symbolica tracked evaluator. Preserve exact rationals and source identities until final numerical evaluation. Combine expressions before substituting approximate master values.

Tracked callbacks must retain approximation and rounding errors. Distinguish estimates derived from validated source digits from mathematically bounded errors. Keep backend statistical uncertainty separate.

Submit focused Symbolica fixes for floating unit coefficients losing precision during normalization and complex conversion incorrectly increasing a component’s precision. Keep final evaluation on the direct interpreter.

## 2. Symbolic capabilities and finite data

Provide arbitrary-precision evaluators for explicitly defined constants and functions in supported symbolic master formulas.

- Reuse elementary, zeta, polylogarithm, and HPL algorithms.
- Recover exact definitions for `D6`, `T1ep`, and `T1ep2`.
- Extend the existing Hölder/GPL kernel for the two required endpoint-one GPL constants, preserving their documented conventions.
- Expose numerical error information from these algorithms.
- Resolve finite primitive periods through authenticated, snapshot-specific data bindings.

Produce and independently validate at least **20,000 digits** for:

| Period | Master coefficient | Current validated digits |
|---|---|---:|
| `PR4fin` | PR4 / P6, ε⁰ | 200 |
| `PR4dfin` | PR4d / P11, ε⁰ | 200 |
| `PR11dep0` | PR11d / P17, ε⁰ | 200 |

Use the authenticated Bessel-moment representations for PR4/PR4d. Recompute PR11d using refined finite-epsilon transport/interpolation profiles and independently cross-check with AMFlow. Establish intermediate-precision resource scaling before full production.

Record validation evidence, normalization, provenance, and checksums. Reuse these validated period payloads in FORM and rustred numerical substitution while preserving FORM reduction scripts and master formulas.

The 20,000-digit requirement is a computational acceptance gate. Other numerical-only Laurent coefficients retain their individually validated limits.

## 3. Public numerical and lookup APIs

### Shared precision primitives

Introduce one public enum, reused by constants and master coefficients:

```rust
pub enum AvailablePrecision {
    ArbitraryPrecision,
    FixedPrecision(u32), // maximum supported decimal precision
}
```

Keep source capability separate from achieved numerical accuracy. An exact symbolic expression containing finite periods has fixed availability.

Replace the numerical result tuple with named records:

```rust
pub struct NumericalEvaluationResult {
    coefficients: BTreeMap<i64, NumericalCoefficient>,
    requested_decimal_precision: u32,
    warnings: Vec<PrecisionWarning>,
}

pub struct NumericalCoefficient {
    value: Complex<Float>,
    precision: CoefficientPrecision,
}
```

Expose read-only accessors. Precision records contain componentwise significant-digit estimates, arbitrary-precision absolute errors, exact-zero status, and error quality.

Preserve evaluation method names and `(central_result, optional_statistical_error)` returns. Migrate tuple construction and `.0` consumers. Python exposes named coefficient records and structured warnings.

### Constant and master lookup

Add instance methods using the engine’s active immutable registry:

```python
engine.get_constant(symbol: ConstantSymbol, prec=16) -> VakintConstant
engine.get_master(symbol: MasterSymbol, prec=16) -> VakintMaster
```

Rust exposes matching methods returning `Result<..., VakintError>`, with an explicit `prec: u32` argument. Python supplies the default of 16 decimal digits.

Use typed wrappers around existing canonical symbolic identities:

- `ConstantSymbol` supports registered named constants and parameterized real constants such as HR/HI projections.
- `MasterSymbol` preserves family identity and ordered signed powers.
- Friendly names resolve only when unambiguous; otherwise report matching qualified identities.

Both lookups operate on loaded or vendored data without implicit downloads. Returned objects retain their original `Arc` snapshot, including after another release is loaded.

**`VakintConstant` contains:**

- `symbol: ConstantSymbol`;
- `available_precision: AvailablePrecision`;
- `numerical_value: Float`;
- shared achieved-precision metadata, warnings, and provenance.

**`VakintMaster` contains:**

- canonical master symbol, family identity, loop count, normalization, and provenance;
- `graph: FeynmanDiagram`, using the existing FeynKit primitive;
- an ordered map of all available Laurent coefficients.

Each master-coefficient record contains its qualified coefficient identity, `available_precision`, `numerical_value: Float`, shared achieved-precision metadata, and:

```rust
pub enum MasterSymbolicExpression {
    Expression(Atom),
    NumericalOnly(u32),
}
```

Canonical master coefficients are returned in their recorded unit-mass convention. Lookup returns every available order independently of the engine’s usual expansion-depth setting.

Declared but uncomputed terminals remain inspectable, explicitly labeled objects with empty coefficient maps. Missing coefficients never become zero.

For both lookups, numerical values target the requested precision capped by source availability. Their Float precision is further reduced if tracking measures lower achieved accuracy, with an explicit warning. Increasing storage precision never adds accurate digits.

Build these objects from the existing registry and shared tracked-value primitives; avoid parallel catalogs or duplicated evaluation logic. Snapshot-specific finite values must not overwrite process-global Symbolica callbacks.

### Checked symbolic conversion

Make result-to-Atom and Python `to_expression` conversion fallible:

- encode achieved precision independently in each nonzero Float component;
- account for final rounding;
- preserve precision through normalization;
- convert exact zeros normally;
- reject uncertain zeros or components without reliably encodable digits.

Raw central values and uncertainty remain inspectable when conversion fails.

## 4. Shared graphs and polished presentation

Reuse `feynkit_graph::FeynmanDiagram` and its existing PyO3 wrapper. Extend shared FeynKit integral annotations where necessary rather than introducing another Vakint graph type.

- Load authenticated **master-specific** DOT/model payloads.
- Preserve propagator powers, contractions, numerator expressions, edge identities, full momentum routing, basis ordering, and `lmb_id`.
- Extend canonical DOT import/export to validate and retain these attributes.
- Generate canonical 5L FeynKit graphs from authenticated family/routing witnesses, including negative-power numerator factors and appropriate scalar-model metadata. Preserve original DOTs as provenance.
- Require semantic DOT round-trip equality; formatting differences are acceptable.

Provide a shared presentation layer for `VakintConstant`, `VakintMaster`, and their coefficient records:

- **Rust `Display`:** polished colored titles, availability badges, aligned metadata, and bordered Laurent-coefficient tables. Respect terminal color settings and `NO_COLOR`; alternate formatting exposes extended detail.
- **Python `repr`/`str`:** similarly structured, colored terminal representations with readable plain-text fallbacks.
- **Notebook/Marimo:** shared `to_html()` and `_repr_html_()` output with styled cards, coefficient tables, native Symbolica formula rendering, expandable long values, and visible precision warnings.
- Embed the graph through FeynKit’s existing Linnest HTML/SVG hooks. `master.graph` remains independently usable as the normal FeynKit Python object.
- Show propagator powers and numerator annotations in the shared graph renderer.

Rendering uses already-computed values and performs no downloads or numerical reevaluation. Escape metadata in HTML and keep long numbers/formulas from overwhelming the layout.

## 5. Validation and delivery

Test numerical cancellation, exact cancellation of repeated references, independent component accuracy, uncertain-zero conversion failures, floating unit preservation, source caps, and 20,000-digit error-radius handling.

Test both lookup APIs for arbitrary/fixed precision, excessive requests, qualified identities, ambiguous names, missing data, snapshot isolation, every available epsilon order, and declared-but-uncomputed 5L terminals. Verify warnings explicitly identify their limiting dependencies.

Validate graph round trips across 1L–5L, including dotted propagators, pinches, numerators, routing, and `lmb_id`. Exercise Rust displays, Python representations, and actual notebook/Marimo HTML rendering with visual inspection.

Verify FORM/rustred and symbolic-first/direct numerical agreement, including nonunit masses and normalization choices. Preserve statistical-error behavior and correct coefficient-order aggregation.

Update documentation, generated Python stubs, and required benchmark artifacts. Run repository-required checks, submit focused dependency PRs, update coordinated pins, publish validated external data before updating `data-latest`, and verify actual downloads plus offline reuse. Push Vakint changes directly to `vakint_rustred`.

## 6. Verbatim user prompts and clarifications

The following records preserve the task-specific user prompts and clarification answers in chronological order. Selected clarification labels are included exactly as recorded.

### Initial task prompt

```text
Pull the latest version of `vakint_rustred` and `vakint-external-data` and then implement the following:

Whenever vakint evaluates the final expression to floating point coefficients of the Laurent series, it should do so with Precision tracking floats, and then the "NumericalEvaluationResult" struct (or whatever it's exactly called) should explicitly contain another entry per coefficient that contains the resulting precision measured of each coefifcient returned. And of course, when converting that struct to a symbolic expression, that precision must be enforced.
It is important because there may be large cancellations between the masters composing a given coefficient.

Make and explicit proposal for how you'll implement this, in a way compatible (and that extends) current API of Vakint.
```

### Result representation clarification

```text
Whenever the coefficient is stored as an Atom/Expression, then it should be sufficient to have the Symbolica Float simply written the proper precision assigned. However for example in python, we need a separate field and there you should absolutely feel free to really modify it to bake in this precision information in the most natural way, no backward compatibility needed. For Rust can you check if the precision can be encoded through the precision field of Symbolica's Float? And if not then yes, but don't make it a tuple, but really a struct with named fields
```

### Precision shortfall selection

```text
Report achieved digits (Recommended)
```

### Uncertain-zero conversion selection

```text
Reject conversion (Recommended)
```

### No-retry clarification

```text
yes no retry, the user can change the runtime precision he wants to consider and he'll be met with precision warnings if the masters don't support the request.
```

### Symbolic evaluator clarification

```text
because when using the symbolic expression of the masters, then each symbol should have a corresponding symbolica evaluator that should support arbitrary precision.
```

### Finite-period precision clarification

```text
Track finite limits is good, but make sure those periods already have 20k digits at least, and if the user's precision exceeds the precision of those remaining periods then a warning should be given again. In all these warnings, always explicitly list what are the symbols / master coefficients that are problematic w.r.t the precision asked for.
```

### Constant/master inspection and presentation prompt

```text
Also add in the plan a new Python and Rust API for the following function:

`get_constant(symbol: ConstantSymbol, prec=16)`

and

`get_master(symbol: MasterSymbol, prec=16)`

each should return dedicated rich rust struct (and Python pyO3 wrapper classes) containing the following

a) 

* VakintConstant: contains the symbol of course, but also an enum field `available_precision` which can be either "ArbitraryPrecision" or "FixedPrecision(max_decimal_prec_available)"
Then it should also contain a `numerical_value` trait of Symbolica `Float` type, with the precision requested for with `prec`, or the max precision available if the input precision requested exceeds it, with a warning.

b) 
* `VakintMaster` containing the symbol, and the `numerical_value` entry like for the constant. But it should also contain a "Graph" object (i.e. same as already used in gammaloop and also exported to python through FeynKit) which when exported to `.dot` reproduces what is in the `vakint-external-data` loaded (incl. numerator if there is any, and with the lmb_id's properly set). Finally it should also have a `symbolic_expression` which is again a variant `Expression(symbolica_expression)` for this master or `NumericalOnly(max_decimal_prec_available)` if not available. Of course all these fields (except the graph) separated for each Laurent series coefficient available.

VERY IMPORTANT: these two objects must have extremely pretty structured and coloured `Display` traits (using tabled if need be) in Rust, and in python also very pretty coloured structured `repr` (also with table if relevant/useful). Also the hooks dedicated to Marimo for pretty (html?) display should be included in the python corresponding objects. The graph contained in particular in Python should use the existing dedicated fancy hook for nice Graph displays with linnet in FeynKit.
 
In rust, make sure that you build these on top of or with existing similar primitives struct you may already have so that there is no dedup and the whole structure looks well integrated and not "patched-up"
```

### Plan preservation and goal assignment prompt

```text
Include in the plan my prompts regarding this task verbatim at the end, and also a goal statement and instructions upon starting its implementation to write it in `./PRECISION_AND_INSPECTION_PLAN.md` and to assign it to yourself as a goal then.
```

## 7. Implementation clarifications (verbatim)

```text
Of course I didn't mention it, but if the constant symbol or the master symbol is unrecognized by vakint, then it should simply just error gracefully. Make sure all symbols that can appear in vakint and all masters loaded at that point in time (or built-in ones) are exposable in this fashion.
Of course these only includes things related to the `rustred` backend evaluation method; it's ok if things from the legacy FORM-based reduction methods are not included.
```

```text
You can use Mathematica to extract the 20k digits missing for some of the periods you need.
```

```text
Here is how you can use mathematica on this machine:
"""
Mathematica 15.0.1 is already installed on this machine and works with Bern’s license server, itplic.itp.unibe.ch. No Bern ID, email, Wolfram login, or installation is needed. Use the shared Nix-store executable and create your own license configuration; Ben’s personal mathpass file is private.

Run in Bash:

bern_wolfram_dir=$(mktemp -d)
printf '%s\n' '!itplic.itp.unibe.ch' > "$bern_wolfram_dir/mathpass"
chmod 600 "$bern_wolfram_dir/mathpass"
export WOLFRAMINIT="-pwfile $bern_wolfram_dir/mathpass"
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
export RUSTFLOW_WOLFRAM_KERNEL=/nix/store/m4xs334vv5qlr31q6ayqr5r2x8lx43bn-mathematica-15.0.1/bin/WolframKernel

The network license requires continued access to the Bern server.

"""
(something like this, ignore references to other codes , I copy-pasted that from another session)
```

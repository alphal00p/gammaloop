# Vakint external data and arbitrary-precision HPL integration

## 1. Goal and implementation contract

**Goal:** Move vakint’s external reduction data into versioned, independently downloadable loop packs in `alphal00p/vakint-external-data`; provide reliable local and official loading, complete 1L–4L caches, data-aware rustred evaluation and graceful incomplete reductions; implement the HPL numerical capabilities needed by vakint in Symbolica and submit them upstream, preserving FORM reductions and master formulas.

Upon starting implementation:

1. Write this approved plan’s complete Markdown body verbatim, excluding the surrounding `<proposed_plan>` tags, to `/shared/codex-1/vakint_rustred/VAKINT_EXTERNAL_DATA_PLAN.md`.
2. Assign the goal above to yourself using `create_goal`, without a token budget.
3. Put all temporary files, additional checkouts, worktrees, build outputs, downloaded validation material, and development license configuration under `/shared/codex-1/vakint_rustred/workspace`.
4. Use the supplied Symbolica license through the environment. Follow each repository’s contribution instructions.
5. Treat Mathematica strictly as an optional development oracle. Nothing in vakint’s build, tests required by end users, or runtime may require Mathematica.

The initial release covers existing 1L–5L material. Computing new 5L master coefficients and implementing general HPL analytic continuation are outside this implementation.

## 2. External repository, releases, and loading

- Move the complete existing artifact tree into the external repository, preserving payload provenance and verifying migrated hashes before removing the vakint `artifacts` directory. Update all consumers, examples, tests, and documentation; do not rewrite Git history.
- Organize the repository around a root manifest and separate `1L` through `5L` directories. Each loop directory contains its IBPs, master and terminal identities, available symbolic and numerical Laurent coefficients, graphs, coverage metadata, and prepared cache when available.
- Include **every available Laurent coefficient**, rather than truncating packs to vakint’s default expansion order.
- Generate missing topology DOT files from the existing family definitions. Give each terminal an unambiguous family identity, ordered powers, and parent-topology graph reference.
- Keep the 905 current 5L entries explicitly identified as declared, uncomputed campaign terminals. Do not promote their nominal epsilon ranges or terminal inventory into available coefficients or a certified complete master basis.

Manifest metadata will distinguish:

- Package version, schema, file checksums, native codec compatibility, and producer revisions.
- Family/program/cache bindings and normalization conventions.
- Declared terminals, available master coefficients, and certification authority.
- Per-coefficient symbolic availability and validated numerical precision. Existing master-level precision may initialize conservative coefficient-level limits.

Publish an initial `v0.1.0` release and a maintained `data-latest` release alias, with deterministic `.tar.gz` assets for each loop count and a checksummed release manifest. `version="latest"` resolves through that alias to an immutable version. Publish complete immutable releases before updating the alias. Retain source data and native caches in the repository; compressed release packs are generated outputs.

**Requesting N loops always means installing and loading 1L through N.** There is no exact-loop-only selector. Packs remain separate, and missing lower-loop packs are downloaded automatically.

Provide matching Rust and Python APIs:

```python
engine.load_official_external_data(
    max_loop_count,
    version="latest",
    local_artifacts_path=None,  # current working directory
    refresh=False,
)
```

Rust exposes the same behavior through a maximum-loop argument and an options type. Return a load report containing the resolved version, loaded loops, paths, cache availability, and reused/downloaded status.

Loading rules:

- Recognize an external-data repository root or unpacked release by its manifest before considering network access.
- For a supplied checkout, `latest` means its current validated contents. An explicit version must match its declared release identity. Missing or inconsistent local data produces an error without downloading into or modifying the checkout.
- Otherwise, manage installations beneath `<local_artifacts_path>/.vakint-external-data/<resolved-version>/`.
- Reuse validated installed data without network access or decompression. `refresh=True` explicitly checks for a newer release; failed refreshes leave the existing installation usable and report the failure.
- Resolve all requested packs against one release manifest. Verify checksums, schemas, and bindings; use bounded extraction, safe archive paths, download locking, and atomic installation.
- Validate the complete requested dataset before activating it. Failure leaves the current engine unchanged.
- Preserve explicit cache-path loading and extend explicit IBP-path loading across supported loop counts. Both local and official loading use the same validation and activation machinery.

Vendor the 1L–3L runtime material, including master data and required graphs, into vakint under a dedicated data directory, **without caches**. Normal construction remains offline. External data supersedes vendored data for the loaded loops; 4L–5L rustred data requires explicit loading.

## 3. Rustred ownership, evaluation, and incomplete reductions

Introduce one immutable, owned data registry per `Vakint` instance. Reduction, topology matching, master evaluation, product-factor reduction, cache preparation, and cache attachment must all use this registry.

- Replace static lower-loop program borrowing with owned/`Arc` program snapshots in RustRed. Route the existing owned 4L programs through the same registry.
- Activate external data as a coherent 1L–N snapshot. Switching releases replaces that snapshot and invalidates incompatible prepared caches and numerical memoization.
- Determine native compatibility from codecs and authenticated semantic bindings; producer revision strings remain provenance rather than a substitute for compatibility checks.

Replace rustred’s single `substitute_masters` switch with an explicit three-way master mode, exposed in Rust and Python:

| Mode | Behavior |
|---|---|
| Retain | Return reductions in terms of masters and unresolved terminals. |
| Symbolic | Expand available exact Laurent coefficients; retain a labeled coefficient symbol where only numerical data exists. |
| Numerical | Evaluate exact formulas at requested precision where available; otherwise use validated numerical coefficient data. |

Numerical substitution remains the default. Update existing callers and examples to the explicit modes.

For rustred evaluation:

- Inspect only coefficients needed by the final combined expression. Account for poles in reduction coefficients, products, mass dependence, normalization factors, and cancellations before determining necessary epsilon depth.
- Replace blanket epsilon-order limits with actual availability checks. Missing coefficients must never be interpreted as zero.
- Treat exact formulas as having no finite source-data precision cap, while recursively accounting for any finite numerical constants they contain.
- Enforce numerical-only limits using validated significant digits and the user’s requested decimal precision, not string length or internal working precision.
- Report insufficient precision/order with master identity, coefficient power, requested and available capability, and data version.
- Convert the archived FMFT/MATAD normalization, mass scaling, and Minkowski conventions exactly once.
- Make instance numerical evaluation resolve retained coefficient symbols through its loaded registry. Static numerical helpers must report unresolved symbols explicitly when they lack the required data context.

Implement safe partial reduction in an isolated RustRed change and submit an upstream PR:

- Keep strict behavior as RustRed’s default; vakint opts into preserving unresolved terms.
- Separate advisory campaign coverage from rule applicability and algebraic safety.
- Outside recorded coverage, warn that complete reduction to the declared masters is not guaranteed. Apply only individually justified rules; retain unsupported integrals with exact coefficients and family-qualified identities.
- Preserve nonzero conditions and proper back-substitution. Existing trace-frontier diagnostics are insufficient to construct the result.
- Keep corruption, invalid transports, unsafe algebra, cycles, and exhausted operational limits as graceful errors.
- After exact combination, warn with the deduplicated list of undeclared residual masters and local/versioned parent-topology DOT references. Cancelled residuals must disappear from that list.
- Numerical evaluation must explicitly list unresolved masters and declared terminals whose coefficients are unavailable.
- Preserve the exact recorded certification predicates. Neither rectangular rank/power summaries nor completed caches establish stronger coverage.

Prepared caches remain strict, complete reductions. Partial results must not enter distributed caches or satisfy strict cache lookups.

## 4. Symbolica HPL implementation and shared numerical substitution

Check out Symbolica main beneath `workspace`, implement the feature in an isolated numerical module, and submit a focused upstream PR. Keep registration and Rust/Python API changes small.

Expose an evaluatable constant equivalent to:

```text
hpl_at_sixth_root(hpl_indices(a1, ..., an), sign)
```

Here indices belong to `{-1,0,1}`, and `sign=±1` selects \(e^{\pm i\pi/3}\). Use Symbolica’s exact tagged-constant evaluation interface so the word, argument choice, and requested precision reach a checked numerical kernel without floating-point argument recognition.

Guarantee support for every word used by vakint’s existing tables, through weight six. Use the standard HPL kernels and principal-path convention; `HR` and `HI` are ordinary real and imaginary parts.

Implement the numerical algorithm as follows:

- Remove trailing zeros through terminating shuffle identities; evaluate all-zero words using powers of the principal logarithm.
- Convert to generalized polylogarithms and apply one Hölder split with parameter two.
- Evaluate the resulting series at one half using shared suffix recurrences and a memoized arithmetic graph. At these arguments, the transformed nonzero poles have modulus at least one, giving geometric convergence.
- Keep algebraic endpoint arithmetic and all numerical operations at arbitrary precision. Propagate truncation and rounding estimates, increase guard precision when needed, and return descriptive failures rather than unchecked partial sums.
- Obtain conjugate-point values through conjugation. Keep the internal series machinery reusable without promising general argument support in this first PR.

Use the published HPL conventions and Hölder/series algorithms as mathematical references, implementing them independently. [Remiddi–Vermaseren](https://arxiv.org/abs/hep-ph/9905237), [Vollinga–Weinzierl](https://arxiv.org/abs/hep-ph/0410259).

Integrate the isolated implementation onto vakint’s existing Symbolica dependency lineage and update coordinated dependency pins. Preserve current integration changes rather than replacing the dependency indiscriminately with main.

Use the new evaluator in **both FORM-backed and rustred HPL substitution**. FORM reduction scripts, hard-coded master formulas, and access to those formulas remain intact.

For other constants:

- Reuse existing Symbolica algorithms or verified identities first, including Clausen values expressible through the new HPL capability.
- Add a focused evaluatable Symbolica builtin and upstream PR when a further required constant has a practical arbitrary-precision algorithm.
- Otherwise retain its symbol and a finite numerical value in vakint, obtaining and independently validating as many digits as practical, up to 20,000. Record provenance and validated precision.
- Do not classify an opaque master coefficient as an exact arbitrary-precision constant merely because it has a symbolic name.

Mathematica may generate reference values using the supplied kernel and a private development license configuration under `workspace`. Preserve its license environment in child kernels and set internal thread limits as well as environment limits.

## 5. Validation and delivery

**Numerical validation**

- Preserve all **464 legacy HR/HI values** as development reference data before removing runtime tables.
- Compare every replaced entry at 200 digits and complete a separate release validation at 20,000 digits. Investigate discrepancies rather than weakening expected accuracy.
- Test low-weight identities, trailing zeros, shuffle relations, conjugation, both projections, precision escalation, cancellation, failure reporting, and precision-sensitive memoization.
- Cross-check representative difficult weight-six values independently with Mathematica or another suitable development oracle.
- Verify complete FORM and rustred outputs, including nonunit masses and normalization choices. FORM’s changed HPL substitution must agree with the values it replaces.
- Test symbolic-first versus direct numerical evaluation; numerical-only precision boundaries; unused low-precision data; missing epsilon orders; pole-driven requirements; and cancelling unknown terminals.

**Data and cache validation**

- Verify offline vendored 1L–3L operation and absence of embedded prepared caches or 4L–5L rustred packs.
- Test cumulative loop selection, local-checkout loading with zero network requests, explicit-version mismatch, repeated-load reuse, refresh, interrupted downloads, corruption, incompatible bindings, and transactional replacement.
- Preserve the existing finite cache workload: all physical parent pinches, at most two extra positive powers, numerator rank at most one, and bounded intermediate capture.
- Validate completion for the existing root counts: **5, 77, 2,320, and 164,352** for 1L–4L. Reuse valid complete packs; rebuild missing, incomplete, or incompatible packs.
- Retain capture diagnostics, including the existing optional 4L capture exhaustion. Test exact result/guard parity, prepared-root hits, and held-out inputs benefiting from intermediate cache entries.
- Test out-of-coverage reduction, undeclared residuals, declared-but-uncomputed 5L terminals, graph links, and isolation of partial results from strict caches.

**Delivery order**

1. Implement and validate the isolated Symbolica and RustRed changes; submit their PRs and record dependency commits.
2. Complete vakint’s registry, loading, evaluation, and shared HPL integration.
3. Validate migrated data and caches against the final dependency versions.
4. Run relevant Rust/Python tests, formatting, Clippy, package checks, and repository-required final-review checks.
5. Push the external repository and completed caches; publish `v0.1.0` and `data-latest`.
6. Exercise the actual published downloads in a clean workspace, then confirm offline reuse.
7. Deliver the vakint changes and all PR/release links, validation reports, supported numerical capabilities, and remaining finite-data limitations.

Upstream PR submission is part of completion; upstream merge timing is not. Report any required human CLA action without signing agreements on the user’s behalf.

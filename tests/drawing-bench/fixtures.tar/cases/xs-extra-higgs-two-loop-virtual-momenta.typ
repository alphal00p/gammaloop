
#let _linnet_config = {
  let value = ((("elements"): (:), ("options"): (("momentum-arrows"): true, ("show-momentum"): true), ("schema"): "linnet-render-config", ("version"): 1))
  if type(value) != dictionary {
    panic("Linnet render config must be a dictionary")
  }
  value
}
#set page(width: auto, height: auto, margin: (x: 2mm, y: 2mm), fill: none)
#set text(size: 9pt)
#import "/crates/linnest/typst/src/graph.typ" as graph
#import "/crates/linnest/typst/src/subgraph.typ" as subgraph
#import "/crates/linnest/typst/src/render/layout.typ" as renderer
#import "/assets/embedded/drawing/templates/layout-core.typ" as physics-layout
#import "/assets/embedded/drawing/templates/physics-edge-style.typ" as physics
#import "@preview/mitex:0.2.6": mi
#import physics: palette, massive, massless, dashed, dotted, source-stroke, sink-stroke, fermion-flow, wave, coil, zigzag
#import graph: build, edge, node, sink, source
#set text(fill: palette.ink)

#let particle-map = (
  "H": (source:source-stroke(c: palette.ink, thickness: massive, dash: dashed), sink:sink-stroke(c: palette.ink, thickness: massive, dash: dashed), label:mi(`{H}`)),
)

#context {
  let raw = build({
    node(<v0>, id: 0, inspection: (node: 0, edges: (0,1,2,)), feynkit-name: "a", interaction: "V_9", numerator: "1")
    node(<v1>, id: 1, inspection: (node: 1, edges: (1,2,3,)), feynkit-name: "b", interaction: "V_9", numerator: "1")
    node(<v2>, id: 2, inspection: (node: 2, edges: (3,4,5,)), feynkit-name: "c", interaction: "V_9", numerator: "1")
    node(<v3>, id: 3, inspection: (node: 3, edges: (4,5,6,)), feynkit-name: "d", interaction: "V_9", numerator: "1")
    node(<v4>, id: 4, inspection: (node: 4, edges: (6,7,8,9,)), feynkit-name: "e", interaction: "V_6", numerator: "1")
    node(<v5>, id: 5, inspection: (node: 5, edges: (0,7,8,9,)), feynkit-name: "f", interaction: "V_6", numerator: "1")
    edge(source(<v5>), <e0>, sink(<v0>), id: 0, orientation: "undirected", particle: "H", pdg: 25, directed: false, numerator: "1", inspection: (edge: 0, source: 5, sink: 0), momentum: "p_0", momentum-signature: (loops: (0,0,0,0,), external: (1,)), external-state: "incoming", external-index: 0, external-name: "ext0", external-connection: 0, is_cut: 0)
    edge(source(<v0>), <e1>, sink(<v1>), id: 1, orientation: "undirected", particle: "H", pdg: 25, directed: false, numerator: "1", inspection: (edge: 1, source: 0, sink: 1), momentum: "k_0", momentum-signature: (loops: (1,0,0,0,), external: (0,)))
    edge(source(<v0>), <e2>, sink(<v1>), id: 2, orientation: "undirected", particle: "H", pdg: 25, directed: false, numerator: "1", inspection: (edge: 2, source: 0, sink: 1), momentum: "-k_0+p_0", momentum-signature: (loops: (-1,0,0,0,), external: (1,)))
    edge(source(<v1>), <e3>, sink(<v2>), id: 3, orientation: "undirected", particle: "H", pdg: 25, directed: false, numerator: "1", inspection: (edge: 3, source: 1, sink: 2), momentum: "p_0", momentum-signature: (loops: (0,0,0,0,), external: (1,)))
    edge(source(<v2>), <e4>, sink(<v3>), id: 4, orientation: "undirected", particle: "H", pdg: 25, directed: false, numerator: "1", inspection: (edge: 4, source: 2, sink: 3), momentum: "k_1", momentum-signature: (loops: (0,1,0,0,), external: (0,)))
    edge(source(<v2>), <e5>, sink(<v3>), id: 5, orientation: "undirected", particle: "H", pdg: 25, directed: false, numerator: "1", inspection: (edge: 5, source: 2, sink: 3), momentum: "-k_1+p_0", momentum-signature: (loops: (0,-1,0,0,), external: (1,)))
    edge(source(<v3>), <e6>, sink(<v4>), id: 6, orientation: "undirected", particle: "H", pdg: 25, directed: false, numerator: "1", inspection: (edge: 6, source: 3, sink: 4), momentum: "p_0", momentum-signature: (loops: (0,0,0,0,), external: (1,)))
    edge(source(<v4>), <e7>, sink(<v5>), id: 7, orientation: "undirected", particle: "H", pdg: 25, directed: false, numerator: "1", inspection: (edge: 7, source: 4, sink: 5), momentum: "k_2", momentum-signature: (loops: (0,0,1,0,), external: (0,)))
    edge(source(<v4>), <e8>, sink(<v5>), id: 8, orientation: "undirected", particle: "H", pdg: 25, directed: false, numerator: "1", inspection: (edge: 8, source: 4, sink: 5), momentum: "k_3", momentum-signature: (loops: (0,0,0,1,), external: (0,)))
    edge(source(<v4>), <e9>, sink(<v5>), id: 9, orientation: "undirected", particle: "H", pdg: 25, directed: false, numerator: "1", inspection: (edge: 9, source: 4, sink: 5), momentum: "-k_2-k_3+p_0", momentum-signature: (loops: (0,0,-1,-1,), external: (1,)))
  }, name: "HiggsTwoLoopVirtualXS", data: (symmetry-factor: 1, overall-factor: "1", numerator: "1", loop-count: 4))
  raw = graph.map(raw, edge: e => (inspection: e.data.inspection + (
    source-hedge: if e.source == none { none } else { e.source.hedge },
    sink-hedge: if e.sink == none { none } else { e.sink.hedge },
  )))

  let config = _linnet_config
  let options = config.at("options", default: (:))
  let options = (label-fill: palette.ink) + if options == none { (:) } else { options }
  if not ("mode", "amplitude-mode", "cross-section-mode").any(key => options.keys().contains(key)) {
    options += (mode: "cross-section",)
  }
  // Open only the sewn initial-state connections; final-state cut edges remain paired.
  if options.at("split-initial-state", default: true) {
    let initial = graph.edges(raw).filter(e => e.source != none and e.sink != none and e.data.at("is_cut", default: none) != none).map(e => e.edge)
    if initial.len() > 0 {
      raw = graph.cut(raw, left: subgraph.select(raw, sink: initial), right: subgraph.select(raw, source: initial))
    }
  }
  let style = config.at("style", default: (:))
  let node-label-default = if options.at("show-node-index", default: false) or options.at("debug", default: false) { (:) } else { (node-label: none) }
  let style = node-label-default + (:) + if style == none { (:) } else { style }
  let draw = config.at("draw", default: (:))
  let draw = if draw == none { (:) } else { draw }
  let drawing = (
    :
  )
  physics-layout.render-layout(
    config + (options: options, style: style, draw: drawing.at("draw", default: (:)) + draw),
    input: raw,
    graph: graph,
    renderer: renderer,
    physics: physics,
    edge-style: (map: particle-map, default-edge: physics.default-edge),
  )
}

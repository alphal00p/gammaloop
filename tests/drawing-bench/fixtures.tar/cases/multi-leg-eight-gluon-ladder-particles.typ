
#let _linnet_config = {
  let value = ((("elements"): (:), ("options"): (:), ("schema"): "linnet-render-config", ("version"): 1))
  if type(value) != dictionary {
    panic("Linnet render config must be a dictionary")
  }
  value
}
#set page(width: auto, height: auto, margin: (x: 2mm, y: 2mm), fill: none)
#set text(size: 9pt)
#import "/crates/linnest/typst/src/graph.typ" as graph
#import "/crates/linnest/typst/src/subgraph.typ" as subgraph
#import "/crates/linnest/typst/src/render/layout.typ" as renderer
#import "/assets/embedded/drawing/templates/layout-core.typ" as physics-layout
#import "/assets/embedded/drawing/templates/physics-edge-style.typ" as physics
#import "@preview/mitex:0.2.6": mi
#import physics: palette, massive, massless, dashed, dotted, source-stroke, sink-stroke, fermion-flow, wave, coil, zigzag
#import graph: build, edge, node, sink, source
#set text(fill: palette.ink)

#let particle-map = (
  "g": (source:source-stroke(c: palette.ink, thickness: massless) + coil, sink:sink-stroke(c: palette.ink, thickness: massless) + coil, label:mi(`{g}`)),
)

#context {
  let raw = build({
    node(<v0>, id: 0, inspection: (node: 0, edges: (0,6,8,)), feynkit-name: "b0", interaction: "V_36", numerator: "1")
    node(<v1>, id: 1, inspection: (node: 1, edges: (0,1,2,10,)), feynkit-name: "b1", interaction: "V_37", numerator: "1")
    node(<v2>, id: 2, inspection: (node: 2, edges: (1,3,4,13,)), feynkit-name: "b2", interaction: "V_37", numerator: "1")
    node(<v3>, id: 3, inspection: (node: 3, edges: (3,5,16,)), feynkit-name: "b3", interaction: "V_36", numerator: "1")
    node(<v4>, id: 4, inspection: (node: 4, edges: (7,8,9,)), feynkit-name: "t0", interaction: "V_36", numerator: "1")
    node(<v5>, id: 5, inspection: (node: 5, edges: (9,10,11,12,)), feynkit-name: "t1", interaction: "V_37", numerator: "1")
    node(<v6>, id: 6, inspection: (node: 6, edges: (12,13,14,15,)), feynkit-name: "t2", interaction: "V_37", numerator: "1")
    node(<v7>, id: 7, inspection: (node: 7, edges: (15,16,17,)), feynkit-name: "t3", interaction: "V_36", numerator: "1")
    edge(source(<v0>), <e0>, sink(<v1>), id: 0, orientation: "undirected", particle: "g", pdg: 21, directed: false, numerator: "1", inspection: (edge: 0, source: 0, sink: 1), momentum: "-k_1+p_3+p_4", momentum-signature: (loops: (0,-1,0,), external: (0,0,0,1,1,0,0,0,)))
    edge(source(<v1>), <e1>, sink(<v2>), id: 1, orientation: "undirected", particle: "g", pdg: 21, directed: false, numerator: "1", inspection: (edge: 1, source: 1, sink: 2), momentum: "k_0", momentum-signature: (loops: (1,0,0,), external: (0,0,0,0,0,0,0,0,)))
    edge(source(<v1>), <e2>, id: 2, orientation: "undirected", particle: "g", pdg: 21, directed: false, numerator: "1", inspection: (edge: 2, source: 1, sink: none), momentum: "p_0", momentum-signature: (loops: (0,0,0,), external: (1,0,0,0,0,0,0,0,)), external-state: "outgoing", external-index: 0, external-name: "ext0", external-connection: 0)
    edge(source(<v2>), <e3>, sink(<v3>), id: 3, orientation: "undirected", particle: "g", pdg: 21, directed: false, numerator: "1", inspection: (edge: 3, source: 2, sink: 3), momentum: "-k_2-p_0-p_1+p_3+p_4-p_5-p_6", momentum-signature: (loops: (0,0,-1,), external: (-1,-1,0,1,1,-1,-1,0,)))
    edge(source(<v2>), <e4>, id: 4, orientation: "undirected", particle: "g", pdg: 21, directed: false, numerator: "1", inspection: (edge: 4, source: 2, sink: none), momentum: "p_1", momentum-signature: (loops: (0,0,0,), external: (0,1,0,0,0,0,0,0,)), external-state: "outgoing", external-index: 1, external-name: "ext1", external-connection: 1)
    edge(source(<v3>), <e5>, id: 5, orientation: "undirected", particle: "g", pdg: 21, directed: false, numerator: "1", inspection: (edge: 5, source: 3, sink: none), momentum: "p_2", momentum-signature: (loops: (0,0,0,), external: (0,0,1,0,0,0,0,0,)), external-state: "outgoing", external-index: 2, external-name: "ext2", external-connection: 2)
    edge(<e6>, sink(<v0>), id: 6, orientation: "undirected", particle: "g", pdg: 21, directed: false, numerator: "1", inspection: (edge: 6, source: none, sink: 0), momentum: "p_3", momentum-signature: (loops: (0,0,0,), external: (0,0,0,1,0,0,0,0,)), external-state: "incoming", external-index: 3, external-name: "ext3", external-connection: 3)
    edge(<e7>, sink(<v4>), id: 7, orientation: "undirected", particle: "g", pdg: 21, directed: false, numerator: "1", inspection: (edge: 7, source: none, sink: 4), momentum: "p_4", momentum-signature: (loops: (0,0,0,), external: (0,0,0,0,1,0,0,0,)), external-state: "incoming", external-index: 4, external-name: "ext4", external-connection: 4)
    edge(source(<v4>), <e8>, sink(<v0>), id: 8, orientation: "undirected", particle: "g", pdg: 21, directed: false, numerator: "1", inspection: (edge: 8, source: 4, sink: 0), momentum: "-k_1+p_4", momentum-signature: (loops: (0,-1,0,), external: (0,0,0,0,1,0,0,0,)))
    edge(source(<v4>), <e9>, sink(<v5>), id: 9, orientation: "undirected", particle: "g", pdg: 21, directed: false, numerator: "1", inspection: (edge: 9, source: 4, sink: 5), momentum: "k_1", momentum-signature: (loops: (0,1,0,), external: (0,0,0,0,0,0,0,0,)))
    edge(source(<v5>), <e10>, sink(<v1>), id: 10, orientation: "undirected", particle: "g", pdg: 21, directed: false, numerator: "1", inspection: (edge: 10, source: 5, sink: 1), momentum: "k_0+k_1+p_0-p_3-p_4", momentum-signature: (loops: (1,1,0,), external: (1,0,0,-1,-1,0,0,0,)))
    edge(source(<v5>), <e11>, id: 11, orientation: "undirected", particle: "g", pdg: 21, directed: false, numerator: "1", inspection: (edge: 11, source: 5, sink: none), momentum: "p_5", momentum-signature: (loops: (0,0,0,), external: (0,0,0,0,0,1,0,0,)), external-state: "outgoing", external-index: 5, external-name: "ext5", external-connection: 5)
    edge(source(<v5>), <e12>, sink(<v6>), id: 12, orientation: "undirected", particle: "g", pdg: 21, directed: false, numerator: "1", inspection: (edge: 12, source: 5, sink: 6), momentum: "-k_0-p_0+p_3+p_4-p_5", momentum-signature: (loops: (-1,0,0,), external: (-1,0,0,1,1,-1,0,0,)))
    edge(source(<v6>), <e13>, sink(<v2>), id: 13, orientation: "undirected", particle: "g", pdg: 21, directed: false, numerator: "1", inspection: (edge: 13, source: 6, sink: 2), momentum: "-k_0-k_2-p_0+p_3+p_4-p_5-p_6", momentum-signature: (loops: (-1,0,-1,), external: (-1,0,0,1,1,-1,-1,0,)))
    edge(source(<v6>), <e14>, id: 14, orientation: "undirected", particle: "g", pdg: 21, directed: false, numerator: "1", inspection: (edge: 14, source: 6, sink: none), momentum: "p_6", momentum-signature: (loops: (0,0,0,), external: (0,0,0,0,0,0,1,0,)), external-state: "outgoing", external-index: 6, external-name: "ext6", external-connection: 6)
    edge(source(<v6>), <e15>, sink(<v7>), id: 15, orientation: "undirected", particle: "g", pdg: 21, directed: false, numerator: "1", inspection: (edge: 15, source: 6, sink: 7), momentum: "k_2", momentum-signature: (loops: (0,0,1,), external: (0,0,0,0,0,0,0,0,)))
    edge(source(<v7>), <e16>, sink(<v3>), id: 16, orientation: "undirected", particle: "g", pdg: 21, directed: false, numerator: "1", inspection: (edge: 16, source: 7, sink: 3), momentum: "k_2+p_0+p_1+p_2-p_3-p_4+p_5+p_6", momentum-signature: (loops: (0,0,1,), external: (1,1,1,-1,-1,1,1,0,)))
    edge(source(<v7>), <e17>, id: 17, orientation: "undirected", particle: "g", pdg: 21, directed: false, numerator: "1", inspection: (edge: 17, source: 7, sink: none), momentum: "-p_0-p_1-p_2+p_3+p_4-p_5-p_6", momentum-signature: (loops: (0,0,0,), external: (-1,-1,-1,1,1,-1,-1,0,)), external-state: "outgoing", external-index: 7, external-name: "ext7", external-connection: 7)
  }, name: "", data: (symmetry-factor: 1, overall-factor: "1", numerator: "1", loop-count: 3))
  raw = graph.map(raw, edge: e => (inspection: e.data.inspection + (
    source-hedge: if e.source == none { none } else { e.source.hedge },
    sink-hedge: if e.sink == none { none } else { e.sink.hedge },
  )))

  let config = _linnet_config
  let options = config.at("options", default: (:))
  let options = (label-fill: palette.ink) + if options == none { (:) } else { options }
  if not ("mode", "amplitude-mode", "cross-section-mode").any(key => options.keys().contains(key)) {
    options += (mode: "amplitude",)
  }
  // Open only the sewn initial-state connections; final-state cut edges remain paired.
  if options.at("split-initial-state", default: true) {
    let initial = graph.edges(raw).filter(e => e.source != none and e.sink != none and e.data.at("is_cut", default: none) != none).map(e => e.edge)
    if initial.len() > 0 {
      raw = graph.cut(raw, left: subgraph.select(raw, sink: initial), right: subgraph.select(raw, source: initial))
    }
  }
  let style = config.at("style", default: (:))
  let node-label-default = if options.at("show-node-index", default: false) or options.at("debug", default: false) { (:) } else { (node-label: none) }
  let style = node-label-default + (:) + if style == none { (:) } else { style }
  let draw = config.at("draw", default: (:))
  let draw = if draw == none { (:) } else { draw }
  let drawing = (
    :
  )
  physics-layout.render-layout(
    config + (options: options, style: style, draw: drawing.at("draw", default: (:)) + draw),
    input: raw,
    graph: graph,
    renderer: renderer,
    physics: physics,
    edge-style: (map: particle-map, default-edge: physics.default-edge),
  )
}
